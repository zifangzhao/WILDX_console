#ifndef NP_SD_STAGE_TIMING_H
#define NP_SD_STAGE_TIMING_H
#include <stdint.h>

#ifndef NP_SD_STAGE_TIMING
#define NP_SD_STAGE_TIMING 0
#endif
#if NP_SD_STAGE_TIMING
#define NP_SD_STAGE_TIMING_ONLY(statement) do { statement; } while(0)
#else
/* No argument evaluation, storage, clock reads or admission work by default. */
#define NP_SD_STAGE_TIMING_ONLY(statement) ((void)0)
#endif

#define NP_SD_STAGE_TIMING_ENTRIES 64U
enum {
    NP_SD_STAGE_TIMING_TC=1U, NP_SD_STAGE_TIMING_NEXT=2U,
    NP_SD_STAGE_TIMING_FIFO=1U, NP_SD_STAGE_TIMING_POOL=2U,
    NP_SD_STAGE_TIMING_SCRATCH=4U, NP_SD_STAGE_TIMING_SOURCE_WAIT=8U,
    NP_SD_STAGE_TIMING_FULL=1U, NP_SD_STAGE_TIMING_STOPPED=2U,
    NP_SD_STAGE_TIMING_ORDER=3U
};
typedef struct {
    /* Unsigned cycle differences wrap modulo 2^32; flags, not zero, mark validity. */
    uint32_t sequence,probe,launch_cycle,tc_cycle,service_cycle,next_launch_cycle;
    uint32_t flags,blocked_reasons,first_block_cycle,last_block_cycle;
    uint32_t launch_lead,min_lead;
} NpSdStageTimingEntry;
typedef struct {
    uint32_t magic,version,count,frozen,fault,source_fault;
    NpSdStageTimingEntry entries[NP_SD_STAGE_TIMING_ENTRIES];
} NpSdStageTiming;
_Static_assert(sizeof(NpSdStageTiming)==3096U,"Review bounded stage trace RAM");

static inline void np_sd_stage_timing_reset(volatile NpSdStageTiming *t)
{
    /* Entries beyond count are deliberately not cleared or inspected. */
    t->magic=0x3154534EU;t->version=1U;t->count=0;t->frozen=0;
    t->fault=0;t->source_fault=0;
}
static inline uint32_t np_sd_stage_timing_lead(uint32_t published,uint32_t consumed)
{return consumed>published?UINT32_MAX:published-consumed;}
static inline uint32_t np_sd_stage_timing_admission(unsigned fifo_room,
    unsigned pool_ready,unsigned scratch_full)
{
    if(!fifo_room)return NP_SD_STAGE_TIMING_FIFO;
    if(!pool_ready)return NP_SD_STAGE_TIMING_POOL|
        (scratch_full?NP_SD_STAGE_TIMING_SCRATCH:0U);
    return 0U; /* Full scratch alone does not block a free internal owner. */
}
static inline void np_sd_stage_timing_start(volatile NpSdStageTiming *t,
    uint32_t cycle,uint32_t sequence,uint32_t probe,uint32_t published,uint32_t consumed)
{
    if(t->frozen)return;
    if(t->count) {
        volatile NpSdStageTimingEntry *previous=&t->entries[t->count-1U];
        if(!(previous->flags&NP_SD_STAGE_TIMING_TC)) {
            t->frozen=NP_SD_STAGE_TIMING_ORDER;return;
        }
        previous->next_launch_cycle=cycle;previous->flags|=NP_SD_STAGE_TIMING_NEXT;
    }
    if(t->count==NP_SD_STAGE_TIMING_ENTRIES) {
        t->frozen=NP_SD_STAGE_TIMING_FULL;return;
    }
    NpSdStageTimingEntry entry={0};
    entry.sequence=sequence;entry.probe=probe;entry.launch_cycle=cycle;
    entry.launch_lead=np_sd_stage_timing_lead(published,consumed);
    entry.min_lead=entry.launch_lead;
    t->entries[t->count]=entry;t->count++;
}
static inline void np_sd_stage_timing_complete(volatile NpSdStageTiming *t,
    uint32_t tc,uint32_t service,uint32_t published,uint32_t consumed)
{
    if(t->frozen || !t->count)return;
    volatile NpSdStageTimingEntry *e=&t->entries[t->count-1U];
    if(e->flags&NP_SD_STAGE_TIMING_TC)return; /* First foreground observation. */
    e->tc_cycle=tc;e->service_cycle=service;
    uint32_t lead=np_sd_stage_timing_lead(published,consumed);
    if(lead<e->min_lead)e->min_lead=lead;
    e->flags|=NP_SD_STAGE_TIMING_TC;
}
static inline void np_sd_stage_timing_wait(volatile NpSdStageTiming *t,
    uint32_t cycle,uint32_t reasons,uint32_t published,uint32_t consumed)
{
    if(t->frozen || !t->count)return;
    volatile NpSdStageTimingEntry *e=&t->entries[t->count-1U];
    if(!(e->flags&NP_SD_STAGE_TIMING_TC) || (e->flags&NP_SD_STAGE_TIMING_NEXT))return;
    uint32_t lead=np_sd_stage_timing_lead(published,consumed);
    if(lead<e->min_lead)e->min_lead=lead;
    if(!reasons)return;
    if(!e->blocked_reasons)e->first_block_cycle=cycle;
    e->blocked_reasons|=reasons;e->last_block_cycle=cycle;
}
static inline void np_sd_stage_timing_freeze(volatile NpSdStageTiming *t,
    uint32_t fault,uint32_t source_fault)
{
    if(!t->fault){t->fault=fault;t->source_fault=source_fault;}
    if(!t->frozen)t->frozen=NP_SD_STAGE_TIMING_STOPPED;
}
#endif
