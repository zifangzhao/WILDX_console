/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32u5xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define NP1_D4_Pin GPIO_PIN_5
#define NP1_D4_GPIO_Port GPIOE
#define NP1_D2_Pin GPIO_PIN_3
#define NP1_D2_GPIO_Port GPIOE
#define NP1_D0_Pin GPIO_PIN_1
#define NP1_D0_GPIO_Port GPIOE
#define HJ_MODE_Pin GPIO_PIN_9
#define HJ_MODE_GPIO_Port GPIOB
#define IO0_Pin GPIO_PIN_12
#define IO0_GPIO_Port GPIOG
#define VEE_EN_Pin GPIO_PIN_15
#define VEE_EN_GPIO_Port GPIOA
#define NP1_D3_Pin GPIO_PIN_4
#define NP1_D3_GPIO_Port GPIOE
#define NP1_D1_Pin GPIO_PIN_2
#define NP1_D1_GPIO_Port GPIOE
#define IMU_SCL_Pin GPIO_PIN_1
#define IMU_SCL_GPIO_Port GPIOD
#define LED_Pin GPIO_PIN_14
#define LED_GPIO_Port GPIOC
#define NP1_D5_Pin GPIO_PIN_6
#define NP1_D5_GPIO_Port GPIOE
#define NP1_SYNC_Pin GPIO_PIN_0
#define NP1_SYNC_GPIO_Port GPIOE
#define EXT_RX_SYNCCLK_Pin GPIO_PIN_10
#define EXT_RX_SYNCCLK_GPIO_Port GPIOG
#define IMU_SDA_Pin GPIO_PIN_0
#define IMU_SDA_GPIO_Port GPIOD
#define USB_MODE_Pin GPIO_PIN_15
#define USB_MODE_GPIO_Port GPIOC
#define TEMP_SDA_Pin GPIO_PIN_0
#define TEMP_SDA_GPIO_Port GPIOF
#define HJ_STATE_Pin GPIO_PIN_3
#define HJ_STATE_GPIO_Port GPIOF
#define HJ_WAKE_Pin GPIO_PIN_9
#define HJ_WAKE_GPIO_Port GPIOA
#define TEMP_SCL_Pin GPIO_PIN_1
#define TEMP_SCL_GPIO_Port GPIOF
#define NP_NRST_Pin GPIO_PIN_7
#define NP_NRST_GPIO_Port GPIOC
#define io1_Pin GPIO_PIN_6
#define io1_GPIO_Port GPIOG
#define EXT_TX_Pin GPIO_PIN_7
#define EXT_TX_GPIO_Port GPIOG
#define NP_REC_NRST_Pin GPIO_PIN_6
#define NP_REC_NRST_GPIO_Port GPIOC
#define EXT_RX_Pin GPIO_PIN_8
#define EXT_RX_GPIO_Port GPIOG
#define NP3_D5_Pin GPIO_PIN_14
#define NP3_D5_GPIO_Port GPIOD
#define NP3_D4_Pin GPIO_PIN_13
#define NP3_D4_GPIO_Port GPIOD
#define NP3_D6_Pin GPIO_PIN_15
#define NP3_D6_GPIO_Port GPIOD
#define BYP_Pin GPIO_PIN_14
#define BYP_GPIO_Port GPIOF
#define NP2_SYNC_Pin GPIO_PIN_8
#define NP2_SYNC_GPIO_Port GPIOE
#define NP2_D1_Pin GPIO_PIN_10
#define NP2_D1_GPIO_Port GPIOE
#define NP2_D3_Pin GPIO_PIN_12
#define NP2_D3_GPIO_Port GPIOE
#define NP3_D0_Pin GPIO_PIN_9
#define NP3_D0_GPIO_Port GPIOD
#define NP3_D2_Pin GPIO_PIN_11
#define NP3_D2_GPIO_Port GPIOD
#define NP3_D3_Pin GPIO_PIN_12
#define NP3_D3_GPIO_Port GPIOD
#define BYPF11_Pin GPIO_PIN_11
#define BYPF11_GPIO_Port GPIOF
#define NP1_D6_Pin GPIO_PIN_7
#define NP1_D6_GPIO_Port GPIOE
#define NP2_D5_Pin GPIO_PIN_14
#define NP2_D5_GPIO_Port GPIOE
#define NP2_SCL_Pin GPIO_PIN_10
#define NP2_SCL_GPIO_Port GPIOB
#define VCC_EN_Pin GPIO_PIN_15
#define VCC_EN_GPIO_Port GPIOB
#define BYPF12_Pin GPIO_PIN_12
#define BYPF12_GPIO_Port GPIOF
#define NP2_D2_Pin GPIO_PIN_11
#define NP2_D2_GPIO_Port GPIOE
#define NP2_D6_Pin GPIO_PIN_15
#define NP2_D6_GPIO_Port GPIOE
#define NP2_SDA_Pin GPIO_PIN_11
#define NP2_SDA_GPIO_Port GPIOB
#define NP3_SYNC_Pin GPIO_PIN_8
#define NP3_SYNC_GPIO_Port GPIOD
#define AUXIN3_Pin GPIO_PIN_4
#define AUXIN3_GPIO_Port GPIOC
#define BYPF13_Pin GPIO_PIN_13
#define BYPF13_GPIO_Port GPIOF
#define SD_VSEL_Pin GPIO_PIN_0
#define SD_VSEL_GPIO_Port GPIOG
#define NP2_D0_Pin GPIO_PIN_9
#define NP2_D0_GPIO_Port GPIOE
#define NP2_D4_Pin GPIO_PIN_13
#define NP2_D4_GPIO_Port GPIOE
#define NP3_D1_Pin GPIO_PIN_10
#define NP3_D1_GPIO_Port GPIOD

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
