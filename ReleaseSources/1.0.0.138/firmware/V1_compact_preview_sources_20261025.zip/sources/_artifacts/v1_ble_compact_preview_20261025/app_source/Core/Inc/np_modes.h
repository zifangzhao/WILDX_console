#ifndef NP_USB_CAPTURE_MODES_H
#define NP_USB_CAPTURE_MODES_H
#include <stdint.h>
#include "np_sd_rate_plan.h"
#define NP_SD_RATE_PROFILES 1U
/* These are admitted implementation modes, not a hardware qualification list. */
static inline int np_mode_valid(uint32_t mask,uint32_t hz) {
    return np_sd_rate_valid(mask,hz);
}
extern volatile uint32_t np_mode_mask,np_mode_hz;
unsigned NP_Triple_Probe(void);
#endif
