#ifndef NP_SD_FAST_STAGE_H
#define NP_SD_FAST_STAGE_H
#include <stdint.h>
/* Static GPDMA linear node ABI, checked against the bundled STM32 HAL.
 * Fixed control words are built once by HAL during session initialization.
 * Hot-path inputs remain bounded/aligned; no recovery or queue traversal. */
#define NP_STAGE_LINK_UPDATE 0xf8010000U
static inline int np_stage_node(uint32_t node[9],const uint32_t control[9],
    uint32_t source,uint32_t destination,uint32_t bytes,uint32_t next)
{
    if(!bytes || bytes>65532U || ((source|destination|bytes|next)&3U))return -1;
    node[0]=control[0];node[1]=control[1];node[2]=bytes;
    node[3]=source;node[4]=destination;
    node[5]=next?NP_STAGE_LINK_UPDATE|(next&0xfffcU):0U;
    node[6]=0;node[7]=0;node[8]=control[8];return 0;
}
static inline int np_stage_region(uint32_t address)
{return !(address&3U) && (address>>16)==((address+8U*36U-1U)>>16);}
#endif
