#ifndef NP_CAPTURE_ANCHOR_H
#define NP_CAPTURE_ANCHOR_H
#include "xe_np_acquisition_anchor.h"
void NP_CaptureAnchor_Query(uint8_t out[64],uint32_t request_id);
int NP_CaptureAnchor_GetMs(uint32_t *before,uint32_t *after);
int NP_CaptureAnchor_GetExportMs(uint32_t *before,uint32_t *after);
int NP_CaptureAnchor_Prearmed(void);
int NP_CaptureAnchor_Unpublished(void);
#endif
