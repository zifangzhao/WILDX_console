#ifndef XE_NP_BOOT_CONTRACT_H
#define XE_NP_BOOT_CONTRACT_H

#include <stdint.h>

/*
 * XE_NP keeps the same application boundary as the CE64 V4 layout.  The
 * logical layout uses only the first 2 MiB, including a separately protected
 * USB-service slot. The attached 004B target reports 4 MiB; flash erase-bank
 * geometry must use the device size register, not this logical capacity.
 */
#define XE_NP_BOOT_FLASH_BASE             0x08000000UL
#define XE_NP_BOOT_LOADER_LIMIT           0x0801C000UL
#define XE_NP_BOOT_CONFIG_BASE            0x0801C000UL
#define XE_NP_BOOT_MANIFEST_BASE          0x0801E000UL
#define XE_NP_BOOT_APPLICATION_BASE       0x08020000UL
#define XE_NP_BOOT_APPLICATION_LIMIT      0x0817E000UL
#define XE_NP_BOOT_USB_MANIFEST_BASE       0x0817E000UL
#define XE_NP_BOOT_USB_SERVICE_BASE        0x08180000UL
#define XE_NP_BOOT_USB_SERVICE_LIMIT       0x08200000UL
#define XE_NP_BOOT_FLASH_PAGE_BYTES       0x00002000UL
#define XE_NP_BOOT_APPLICATION_CAPACITY   \
    (XE_NP_BOOT_APPLICATION_LIMIT - XE_NP_BOOT_APPLICATION_BASE)

#define XE_NP_BOOT_MANIFEST_MAGIC         UINT64_C(0x31464E4D31504E58) /* XENPMNF1 */
#define XE_NP_BOOT_MANIFEST_FORMAT        1UL
#define XE_NP_BOOT_MANIFEST_STATE_VALID   0x56414C44UL /* VALD */
#define XE_NP_BOOT_IMAGE_ID_APPLICATION   0x41505031UL /* APP1 */
#define XE_NP_BOOT_IMAGE_ID_USB_SERVICE   0x55534231UL /* USB1 */
#define XE_NP_BOOT_LOADER_ABI_VERSION     258UL

/* A flagged ABI-4 resident service consumes the explicit stream/download
 * mailbox actions below. An unflagged legacy service remains bootable, but
 * cold boot falls back to the separately validated SD application. */
#define XE_NP_BOOT_MANIFEST_FLAG_UNIFIED_USB 0x00000001UL

#define XE_NP_BOOT_REQUEST_MAGIC          0x584E4255UL /* XNBU */
#define XE_NP_BOOT_REQUEST_COMPLEMENT     (~XE_NP_BOOT_REQUEST_MAGIC)
#define XE_NP_BOOT_REQUEST_USB_SERVICE    0x584E5553UL /* XNUS */
#define XE_NP_BOOT_REQUEST_DOWNLOAD       0x584E444CUL /* XNDL */
#define XE_NP_BOOT_REQUEST_APPLICATION    0x584E4150UL /* XNAP: legacy */
#define XE_NP_BOOT_REQUEST_SD_APP         0x31534441UL /* ABI258 unified loader */
#define XE_NP_BOOT_REQUEST_MSC_RO         0x584E4D53UL /* XNMS */
#define XE_NP_BOOT_REQUEST_MSC_RW         0x584E4D57UL /* XNMW */
#define XE_NP_BOOT_ACTION_APPLICATION     0U
#define XE_NP_BOOT_ACTION_UPDATE          1U
#define XE_NP_BOOT_ACTION_USB_SERVICE     2U
#define XE_NP_BOOT_ACTION_MSC_RO          3U
#define XE_NP_BOOT_ACTION_MSC_RW          4U
#define XE_NP_BOOT_ACTION_DOWNLOAD        5U

#define XE_NP_BOOT_USB_PROTOCOL_MAGIC     0x31564E58UL /* XNBU on the wire */
#define XE_NP_BOOT_USB_PROTOCOL_VERSION   2U
#define XE_NP_BOOT_USB_HEADER_BYTES       32U
#define XE_NP_BOOT_USB_MAX_PAYLOAD_BYTES  480U

typedef enum
{
    XE_NP_BOOT_USB_OP_INFO = 1,
    XE_NP_BOOT_USB_OP_BEGIN = 2,
    XE_NP_BOOT_USB_OP_DATA = 3,
    XE_NP_BOOT_USB_OP_COMMIT = 4,
    XE_NP_BOOT_USB_OP_ABORT = 5,
    XE_NP_BOOT_USB_OP_BOOT = 6,
    XE_NP_BOOT_USB_OP_USB_SERVICE = 7,
    XE_NP_BOOT_USB_OP_MSC_RO = 8,
    XE_NP_BOOT_USB_OP_MSC_RW = 9,
    XE_NP_BOOT_USB_OP_DOWNLOAD = 10
} XE_NP_BootUsbOpcode;

typedef enum
{
    XE_NP_BOOT_STATUS_OK = 0,
    XE_NP_BOOT_STATUS_BAD_HEADER = 1,
    XE_NP_BOOT_STATUS_BAD_COMMAND = 2,
    XE_NP_BOOT_STATUS_BAD_STATE = 3,
    XE_NP_BOOT_STATUS_BAD_RANGE = 4,
    XE_NP_BOOT_STATUS_BAD_SEQUENCE = 5,
    XE_NP_BOOT_STATUS_FLASH_ERROR = 6,
    XE_NP_BOOT_STATUS_IMAGE_CRC = 7,
    XE_NP_BOOT_STATUS_BAD_VECTOR = 8,
    XE_NP_BOOT_STATUS_BAD_MANIFEST = 9
} XE_NP_BootStatus;

typedef struct
{
    uint64_t magic;
    uint32_t format;
    uint32_t state;
    uint32_t image_id;
    uint32_t generation;
    uint32_t image_base;
    uint32_t image_size;
    uint32_t image_crc32;
    uint32_t vector_sp;
    uint32_t vector_reset;
    uint8_t build_id[32];
    uint32_t flags;
    uint32_t min_loader_version;
    uint32_t reserved[10];
    uint32_t header_crc32;
} XE_NP_BootManifest;

typedef char XE_NP_BootManifestMustBe128Bytes[
    (sizeof(XE_NP_BootManifest) == 128U) ? 1 : -1];

uint32_t XE_NP_Boot_Crc32Update(uint32_t crc, const void *data, uint32_t size_bytes);
uint32_t XE_NP_Boot_Crc32(const void *data, uint32_t size_bytes);
int XE_NP_Boot_VectorIsValid(uint32_t vector_sp, uint32_t vector_reset, uint32_t image_size);
int XE_NP_Boot_ManifestIsValid(const XE_NP_BootManifest *manifest, int verify_image_crc);
int XE_NP_Boot_ManifestIsValidForImage(const XE_NP_BootManifest *manifest, uint32_t image_id, int verify_image_crc);
int XE_NP_Boot_UsbServiceIsValid(void);
int XE_NP_Boot_UsbServiceSupportsUnifiedMode(void);
void XE_NP_Boot_RequestUsbUpdate(void);
void XE_NP_Boot_RequestUsbService(void);
void XE_NP_Boot_RequestDownload(void);
void XE_NP_Boot_RequestApplication(void);
void XE_NP_Boot_RequestMsc(int writable);
uint32_t XE_NP_Boot_ConsumeRequest(void);
int XE_NP_Boot_ConsumeUsbUpdateRequest(void);
void XE_NP_Boot_JumpToApplication(void);
void XE_NP_Boot_JumpToUsbService(void);

#define XE_NP_BOOT_DOWNLOAD_MANIFEST_BASE 0x081BE000UL
#define XE_NP_BOOT_DOWNLOAD_BASE 0x081C0000UL
#define XE_NP_BOOT_DOWNLOAD_LIMIT 0x08200000UL
#define XE_NP_BOOT_IMAGE_ID_DOWNLOAD 0x444C4431UL
int XE_NP_Boot_DownloadIsValid(void);
void XE_NP_Boot_JumpToDownload(void);
#endif
