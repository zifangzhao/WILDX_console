#ifndef NP_CAMERA_TIMING_H
#define NP_CAMERA_TIMING_H
#include <stdint.h>

/* NanEyeC SEIM: 75 MHz maximum SCLK, 58 fps sensor ceiling. SPI1 on
 * U595 has no PLL2/PLL3 mux: keep NP/SD clocks and choose a legal divider. */
#define NP_CAMERA_SENSOR_MAX_HZ 58U
#define NP_CAMERA_SCLK_MAX_HZ 75000000U
#define NP_CAMERA_WIRE_BYTES (983U + 984U + 320U * 492U + 12U)
static inline uint32_t np_camera_divider(uint32_t kernel, uint32_t safe)
{
    uint32_t divider=2U;
    while(divider<256U && kernel/divider>NP_CAMERA_SCLK_MAX_HZ)divider*=2U;
    return safe && divider<256U?divider*2U:divider;
}
static inline uint32_t np_camera_max_hz(uint32_t kernel,uint32_t safe)
{
    uint32_t sclk=kernel/np_camera_divider(kernel,safe);
    /* Existing CE64 alignment requires a 1 ms low hold per frame. Round
     * upward so this bound never promises faster than the wire can drain. */
    if(!sclk)return 0U;
    uint32_t wire_us=(uint32_t)(((uint64_t)NP_CAMERA_WIRE_BYTES*8000000U+sclk-1U)/sclk);
    uint32_t rate=1000000U/(wire_us+1000U);
    return rate>NP_CAMERA_SENSOR_MAX_HZ?NP_CAMERA_SENSOR_MAX_HZ:rate;
}
typedef struct {uint32_t next_ms,remainder,missed;} NpCameraCadence;
static inline void np_camera_advance(NpCameraCadence *c,uint32_t hz,uint32_t now)
{
    if(!hz)return;
    uint32_t step=1000U/hz;
    c->remainder+=1000U%hz;
    if(c->remainder>=hz){c->remainder-=hz;step++;}
    c->next_ms+=step;
    if((int32_t)(now-c->next_ms)>=0){c->missed++;c->next_ms=now+step;}
}
#endif
