#ifndef __CE32_macro
#define __CE32_macro

#include "stm32f4xx_hal.h"
#include "dataMGR.h"

#define ADD_CHKBDR(A,B,BDR) ((((A) + (B)) < (BDR)) ? ((A) + (B)) : ((A) + (B) - (BDR)))
#define PIN_SET(__HANDLE__) ((__HANDLE__##_GPIO_Port->BSRR |= (__HANDLE__##_Pin))
#define PIN_RESET(__HANDLE__) ((__HANDLE__##_GPIO_Port->BSRR |= (uint32_t)(__HANDLE__##_Pin) << 16))
#define CE32_NOP(__x__) for(int i = 0; i < (__x__); ++i) { __NOP(); }
#ifndef __nop
#define __nop() __NOP()
#endif
#define FM_VERSION 46U

typedef struct
{
    __IO uint32_t ISR;
    __IO uint32_t Reserved0;
    __IO uint32_t IFCR;
} DMA_Base_Registers;

typedef enum
{
    SPD_24MHz = 0,
    SPD_32MHz,
    SPD_48MHz,
    SPD_64MHz,
    SPD_96MHz,
    SPD_MAX,
} CE32_Clk_Spd;

#define STIM1_ON
#define STIM1_OFF
#define STIM2_ON
#define STIM2_OFF

#define EVT_BUFFER_SIZE 512U
typedef struct
{
    uint32_t rec_svr[3];
    uint32_t prev_svr[3];
    uint32_t cmd_svr[3];
    uint32_t MAIN_HS[3];
    uint32_t MAIN_LS[3];
    uint32_t SD_Write[5];
    uint32_t BLE_Send[3];
    uint16_t evt_id;
    uint8_t Evt_buffer[EVT_BUFFER_SIZE];
    uint32_t last_syscyc;
    dataMGR MGR;
} Profile_CNT;

void Profile_Log(Profile_CNT *h, uint8_t *msg, uint16_t msg_len, int en);
#ifdef __PROFILE
extern Profile_CNT profile;
#define PROFILE_CYC DWT->CYCCNT
#define PROFILE_LOG(__msg__) Profile_Log(&profile, (uint8_t *)(__msg__), sizeof(__msg__), debug_on)
#define PROFILE_LOG_FORCE(__msg__) Profile_Log(&profile, (uint8_t *)(__msg__), sizeof(__msg__), 1)
#define DEBUG_ON static int debug_on = 1;
#define DEBUG_OFF static int debug_on = 0;
#else
#define PROFILE_LOG(__msg__)
#define PROFILE_LOG_FORCE(__msg__)
#define DEBUG_ON
#define DEBUG_OFF
#endif

CE32_FORCE_INLINE int16_t Float2Int(float in)
{
    if(in > (float)INT16_MAX)
    {
        in = (float)INT16_MAX;
    }
    if(in < (float)INT16_MIN)
    {
        in = (float)INT16_MIN;
    }
    return (int16_t)in;
}

#endif
