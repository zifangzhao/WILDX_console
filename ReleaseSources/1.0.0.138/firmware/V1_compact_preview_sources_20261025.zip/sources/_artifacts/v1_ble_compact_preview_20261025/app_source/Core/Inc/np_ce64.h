#ifndef NP_CE64_H
#define NP_CE64_H
#include <stdint.h>
#include <string.h>
#include "np_sd_log.h"
#define NP_CE64_IDENT 16U
#define NP_CE64_SYS 17U
#define NP_CE64_LOG 128U
#define NP_CE64_DATA 8192U
#define NP_CE64_JOURNAL 112U
#define NP_CE64_MAX_LOG_BLOCKS 1024U
#define NP_CE64_ENTRIES 63U
typedef struct {uint32_t count,end[63],event_end[63],continued;} NpCe64SysLog;
_Static_assert(sizeof(NpCe64SysLog)==512,"CE64 sysLog wire size");
typedef int (*NpCe64Read)(uint32_t, uint8_t *);
typedef int (*NpCe64Write)(uint32_t, const uint8_t *);
typedef struct {
    NpCe64SysLog log;
    uint32_t block,index,start,reserved_end,session,active;
} NpCe64Directory;
static inline uint32_t np_get32(const uint8_t *p)
{return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static inline int np_ce64_identified(uint32_t capacity,NpCe64Read read)
{
    uint8_t b[512];
    return capacity<=NP_CE64_DATA || read(NP_CE64_IDENT,b) ||
        memcmp(b,"CE_FILESYSTEM_V1",16) || memcmp(b+32,"NP_CE64_1",9)?-1:0;
}
/* 0: clean, 1: complete pending transaction, -1: unreadable/torn. Neither
 * inspection nor browsing replays a transaction or changes the card. */
static inline int np_ce64_journal(NpCe64Read read,uint32_t *target,uint8_t shadow[512])
{
    uint8_t b[512];*target=0U;
    if(read(NP_CE64_JOURNAL,b))return -1;
    if(!memcmp(b,"NPC64TX1",8)) {
        uint32_t lba=np_get32(b+8);
        if(np_get32(b+508)!=np_crc32(b,508) || lba<NP_CE64_LOG ||
           lba>=NP_CE64_LOG+NP_CE64_MAX_LOG_BLOCKS ||
           read(NP_CE64_JOURNAL+1,shadow) || np_get32(b+12)!=np_crc32(shadow,512))return -1;
        *target=lba;return 1;
    }
    for(unsigned i=0;i<512;i++)if(b[i])return -1;
    return 0;
}
/* Raw directory evidence, not a writable allocation cursor. A valid pending
 * shadow is the logical page even if its target sector was torn. An invalid
 * journal does not hide readable older pages; the caller must label salvage
 * read-only and must not infer extents beyond an invalid boundary. */
static inline int np_ce64_read_log(uint32_t block,NpCe64SysLog *log,NpCe64Read read)
{
    uint32_t target;uint8_t shadow[512];
    if(block>=NP_CE64_MAX_LOG_BLOCKS)return -1;
    if(np_ce64_journal(read,&target,shadow)==1 && target==NP_CE64_LOG+block) {
        memcpy(log,shadow,512);return 0;
    }
    return read(NP_CE64_LOG+block,(uint8_t *)log);
}
static inline int np_ce64_valid_log(const NpCe64SysLog *l,uint32_t previous,uint32_t capacity)
{
    if(l->count>63)return -1;
    for(unsigned i=0;i<l->count;i++) {
        /* NP writes both extent copies identically. A torn but in-range copy
         * must not become a writable cursor into an existing recording. */
        if(l->end[i]<=previous || l->end[i]>capacity || l->event_end[i]!=l->end[i])return -1;
        previous=l->end[i];
    }
    return 0;
}
/* Write-ahead sector protects sysLog publication against a torn metadata write.
 * It does not retry/repair capture data and never changes an older record. */
static inline int np_ce64_publish(NpCe64Directory *d,NpCe64Write write)
{
    uint8_t journal[512]={0},shadow[512];
    memcpy(shadow,&d->log,512);
    /* Full sysLog shadow at113; journal112 names its target and CRC. */
    if(write(NP_CE64_JOURNAL+1,shadow))return -1;
    memcpy(journal,"NPC64TX1",8);np_put32(journal+8,NP_CE64_LOG+d->block);
    np_put32(journal+12,np_crc32(shadow,512));np_put32(journal+508,np_crc32(journal,508));
    if(write(NP_CE64_JOURNAL,journal) || write(NP_CE64_LOG+d->block,shadow))return -1;
    memset(journal,0,512);return write(NP_CE64_JOURNAL,journal);
}
static inline int np_ce64_mount(NpCe64Directory *d,uint32_t capacity,NpCe64Read read,NpCe64Write write)
{
    uint8_t shadow[512];uint32_t target,previous=NP_CE64_DATA;
    memset(d,0,sizeof(*d));
    if(np_ce64_identified(capacity,read))return -1;
    int pending=np_ce64_journal(read,&target,shadow);
    if(pending<0)return -1; /* Invalid journal blocks writes, not raw browsing. */
    for(d->block=0;d->block<NP_CE64_MAX_LOG_BLOCKS;d->block++) {
        if(pending && target==NP_CE64_LOG+d->block)memcpy(&d->log,shadow,512);
        else if(read(NP_CE64_LOG+d->block,(uint8_t*)&d->log))return -1;
        if(np_ce64_valid_log(&d->log,previous,capacity))return -1;
        if(d->log.count)previous=d->log.end[d->log.count-1];
        if(d->log.count<63) {
            if(previous>UINT32_MAX-8191)return -1;
            uint32_t start=(previous+8191U)&~8191U;
            if(pending && target>NP_CE64_LOG+d->block)return -1;
            /* At/beyond capacity means full, not corrupt. Keep the exact
             * aligned cursor for browsing/deletion; reserve/init reject any
             * new extent that cannot fit. Never round it down into old data. */
            /* Only a fully validated allocation may repair metadata. A bad
             * later page must not cause an earlier pending write on mount. */
            if(pending) {
                if(write(target,shadow))return -1;
                memset(shadow,0,512);if(write(NP_CE64_JOURNAL,shadow))return -1;
            }
            d->start=start;d->index=d->log.count;
            return 0;
        }
    }
    return -1;
}
static inline int np_ce64_reserve(NpCe64Directory *d,uint32_t end,uint32_t session,uint32_t capacity,NpCe64Write write)
{
    if(d->active || !session || d->index>=63 || end<=d->start || end>capacity)return -1;
    if(d->index==62) {
        uint8_t zero[512]={0};if(d->block+1>=NP_CE64_MAX_LOG_BLOCKS || write(NP_CE64_LOG+d->block+1,zero))return -1;
    }
    d->log.end[d->index]=end;d->log.event_end[d->index]=end;d->log.count=d->index+1;
    if(np_ce64_publish(d,write))return -1;
    d->session=session;d->reserved_end=end;d->active=1;return 0;
}
static inline int np_ce64_finish(NpCe64Directory *d,uint32_t committed_end,int complete,NpCe64Write write)
{
    if(!d->active || committed_end<d->start || committed_end>d->reserved_end)return -1;
    /* Failed/power-interrupted reservations retain their complete allocation,
     * preventing the next session from erasing potentially recoverable data. */
    if(complete){d->log.end[d->index]=committed_end;d->log.event_end[d->index]=committed_end;}
    if(np_ce64_publish(d,write))return -1;
    d->active=0;return 0;
}
/* CE64 misc is16 frames of32 bytes, test_signal remains at byte22. NP uses
 * formerly auxiliary words for exact source tick plus status validity. IMU/
 * battery values are unavailable unless a measurement producer supplies them. */
static inline void np_ce64_misc(uint8_t *b,uint32_t sequence,uint32_t tick_ms,uint32_t flags,uint32_t width)
{
    memset(b,0,512);
    for(unsigned i=0;i<16;i++) {
        uint8_t *p=b+i*32;
        for(unsigned j=0;j<10;j++){p[2*j]=0;p[2*j+1]=0x80;} /* unavailable sensors, not zero */
        p[20]=(uint8_t)flags;p[21]=(uint8_t)(flags>>8);
        uint32_t frame=sequence*16U+i;p[22]=(uint8_t)frame;p[23]=(uint8_t)(frame>>8);
        np_put32(p+24,tick_ms);np_put32(p+28,sequence);
    }
    (void)width;
}
#endif
