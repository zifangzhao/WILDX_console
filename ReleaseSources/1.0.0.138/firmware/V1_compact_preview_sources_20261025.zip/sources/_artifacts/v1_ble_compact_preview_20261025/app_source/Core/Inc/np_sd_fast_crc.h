#ifndef NP_SD_FAST_CRC_H
#define NP_SD_FAST_CRC_H
#include <stdint.h>
/* Same existing reflected CRC32 metadata format, 64-byte immutable table.
 * Two nibble steps per byte replace eight conditional polynomial steps.
 * This does NOT add a CRC over the ADC payload or change any wire format. */
static inline uint32_t np_sd_metadata_crc_fast(const uint8_t *p,uint32_t n)
{
    static const uint32_t table[16]={
        0x00000000U,0x1db71064U,0x3b6e20c8U,0x26d930acU,
        0x76dc4190U,0x6b6b51f4U,0x4db26158U,0x5005713cU,
        0xedb88320U,0xf00f9344U,0xd6d6a3e8U,0xcb61b38cU,
        0x9b64c2b0U,0x86d3d2d4U,0xa00ae278U,0xbdbdf21cU};
    uint32_t c=~0U;
    while(n--){c^=*p++;c=(c>>4)^table[c&15U];c=(c>>4)^table[c&15U];}
    return ~c;
}
#endif
