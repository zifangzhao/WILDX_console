#ifndef NP_CE64_METADATA_H
#define NP_CE64_METADATA_H

#include <stdint.h>
#include <string.h>

/*
 * CE64 layout with a Neuropixels payload.  Version 0x20 deliberately keeps
 * the ordinary CE64 directory, three-sector per-record header, ephys/misc
 * cadence, and sysLog intact.  It tells a reader that ephys bytes are NP
 * transport data and must be passed to the NP decoder rather than the Intan
 * channel remapper.
 *
 * Nch[0] is the AP channel count and Nch[1] is the LFP channel count.  The
 * two bands share the physical NP byte stream, so stream 1 has no separate
 * CE64 data allocation (spd_rate[1] remains zero).
 */
#define NP_CE64_DATAINFO_VERSION          0x20U
#define NP_CE64_CHANNELS_PER_PROBE        384U
#define NP_CE64_CONTAINER_TAG             0x4E500000UL
#define NP_CE64_TRANSPORT_EPHYS_BLOCKS    127U
#define NP_CE64_TRANSPORT_MISC_BLOCKS     1U
#define NP_CE64_MISC_CHANNELS             16U

static inline uint8_t np_ce64_probe_count(uint32_t probe_mask)
{
    uint8_t count = 0U;

    probe_mask &= 0x7U;
    while(probe_mask != 0U)
    {
        count = (uint8_t)(count + (uint8_t)(probe_mask & 1U));
        probe_mask >>= 1U;
    }
    return count;
}

static inline uint16_t np_ce64_channels_for_mask(uint32_t probe_mask)
{
    return (uint16_t)(np_ce64_probe_count(probe_mask) * NP_CE64_CHANNELS_PER_PROBE);
}

static inline void np_ce64_apply_system_metadata(
    CE32_systemParam *sys,
    uint32_t probe_mask,
    uint32_t ap_hz,
    uint32_t misc_row_hz)
{
    uint32_t camera_hz=sys?sys->sampling_rate[2]:0U,mic_hz=sys?sys->sampling_rate[4]:0U;
    uint16_t channels;
    uint32_t lfp_hz;

    if((sys == NULL) || (!ap_hz && probe_mask))
    {
        return;
    }

    channels = np_ce64_channels_for_mask(probe_mask);
    lfp_hz = ap_hz / 12U;

    /* Keep the standard CE64 fields valid; only the NP-private tag carries
     * the active physical-probe mask for old readers that predate v0x20. */
    sys->unassigned_32 = NP_CE64_CONTAINER_TAG | ((probe_mask & 0x7U) << 8) | 0x0FU;
    memset(sys->Nch, 0, sizeof(sys->Nch));
    memset(sys->spd_rate, 0, sizeof(sys->spd_rate));
    memset(sys->sampling_rate, 0, sizeof(sys->sampling_rate));

    sys->Nch[0] = channels;              /* AP: 384 channels per probe. */
    sys->Nch[1] = channels;              /* LFP: same physical channels. */
    sys->sampling_rate[2]=camera_hz; /* v7 typed camera chunks, not a fixed ephys cadence */
    sys->Nch[2]=camera_hz?320U:0U;
    sys->sampling_rate[4]=mic_hz;sys->Nch[4]=mic_hz?1U:0U;
    sys->Nch[3] = NP_CE64_MISC_CHANNELS;
    sys->spd_rate[0] = probe_mask?NP_CE64_TRANSPORT_EPHYS_BLOCKS:0U;
    sys->spd_rate[3] = NP_CE64_TRANSPORT_MISC_BLOCKS;
    sys->fs = ap_hz;
    sys->sampling_rate[0] = ap_hz;
    sys->sampling_rate[1] = lfp_hz;
    sys->base_fs = misc_row_hz;
    sys->sampling_rate[3] = misc_row_hz;
    sys->MISC_ratio = 1U;
    sys->PREV_ratio = 0U;
    sys->MISC_interval = NP_CE64_TRANSPORT_EPHYS_BLOCKS;

    /* Preserve dataInfo time fields populated by normal CE64 startup. */
    sys->datainfo.version = NP_CE64_DATAINFO_VERSION;
    sys->datainfo.Ntypes = 6U;
    for(uint8_t index = 0U; index < CE32_DATAINFO_TYPE_COUNT; ++index)
    {
        sys->datainfo.type_list[index] = index;
        sys->datainfo.byte_per_base_block[index] = 0U;
    }
    /* byte_per_base_block is u8.  The base ephys unit is 512 and therefore
     * represented as zero in the historic CE64 wire format; misc is 512/127. */
    sys->datainfo.byte_per_base_block[3] =
        (uint8_t)(512U / NP_CE64_TRANSPORT_EPHYS_BLOCKS);
}

#endif
