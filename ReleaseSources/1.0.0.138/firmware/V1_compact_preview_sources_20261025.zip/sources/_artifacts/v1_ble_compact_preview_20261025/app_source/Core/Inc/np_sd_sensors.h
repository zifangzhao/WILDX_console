#ifndef NP_SD_SENSORS_H
#define NP_SD_SENSORS_H
#include "np_sd_log.h"
#include "xe_np_sensors.h"

/* Version-4 CE64 transport extension. Raw lane size and misc counters do not
 * change. One real latest-value snapshot, NOT sixteen independent samples.
 * Fixed little-endian ARM/Windows wire ABI. All remaining padding stays zero. */
#define NP_SD_SENSOR_BYTES 164U
_Static_assert(sizeof(XE_NP_SensorSnapshot)==140U,"Sensor wire ABI changed");
static inline void np_sd_sensor_record(uint8_t *b,const XE_NP_SensorSnapshot *snapshot,
                                      uint32_t sequence,uint32_t now)
{
    XE_NP_SensorSnapshot s=*snapshot;
    XE_NP_Sensors_RefreshValidity(&s,now);
    memcpy(b,"NPSENS01",8);
    np_put32(b+8,sequence);np_put32(b+12,now);np_put32(b+16,140U);
    memcpy(b+20,&s,sizeof(s));np_put32(b+160,np_crc32(b,160));
}
#endif
