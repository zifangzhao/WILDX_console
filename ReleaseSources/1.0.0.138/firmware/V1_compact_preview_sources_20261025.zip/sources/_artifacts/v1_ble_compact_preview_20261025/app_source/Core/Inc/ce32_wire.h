#ifndef XE_NP_CE32_WIRE_H
#define XE_NP_CE32_WIRE_H

#include "xe_np_hal.h"

#define CE32_MAX_NCH_GROUP 8U
#define CE32_CL_UNIT_NUM 4U
#define CE32_DATAINFO_TYPE_COUNT 21U
#define CE32_DSP_CH_ORD_MAX 128U
#define CE32_SYSTEM_LOG_CAPACITY 63U
#define MAX_LOG_PER_BLOCK CE32_SYSTEM_LOG_CAPACITY

typedef struct
{
    uint8_t WeekDay;
    uint8_t Month;
    uint8_t Date;
    uint8_t Year;
} CE32_RTC_DateWire;

typedef struct
{
    uint8_t Hours;
    uint8_t Minutes;
    uint8_t Seconds;
    uint8_t TimeFormat;
    uint32_t SubSeconds;
    uint32_t SecondFraction;
    uint32_t DayLightSaving;
    uint32_t StoreOperation;
} CE32_RTC_TimeWire;

typedef struct
{
    uint8_t version;
    CE32_RTC_DateWire date;
    CE32_RTC_TimeWire time;
    uint8_t Ntypes;
    uint8_t type_list[CE32_DATAINFO_TYPE_COUNT];
    uint8_t byte_per_base_block[CE32_DATAINFO_TYPE_COUNT];
} CE32_dataInfo;

typedef struct
{
    uint32_t fs;
    uint32_t AUX_mode;
    uint16_t Nch[CE32_MAX_NCH_GROUP];
    uint16_t spd_rate[CE32_MAX_NCH_GROUP];
    uint32_t sampling_rate[CE32_MAX_NCH_GROUP];
    uint8_t ch_list[64];
    uint32_t unassigned_32;
    uint32_t dispCH;
    uint32_t func1;
    uint32_t func2;
    uint32_t cmd_ch;
    uint32_t rec_ch;
    uint32_t stim_mode;
    uint32_t cl_mode;
    uint32_t stim_interval[CE32_CL_UNIT_NUM];
    uint32_t pulse_width[CE32_CL_UNIT_NUM];
    uint32_t pulse_cnt[CE32_CL_UNIT_NUM];
    uint32_t stim_delay[CE32_CL_UNIT_NUM];
    uint32_t stim_RndDelay[CE32_CL_UNIT_NUM];
    uint32_t trigger_trainStart;
    uint32_t trigger_trainDuration;
    float trigger_gain[CE32_CL_UNIT_NUM];
    uint32_t SD_capacity;
    uint32_t LED_pulse_CNT;
    uint32_t preview_channel_bank;
    uint32_t system_status;
    uint32_t stim_intensity[CE32_CL_UNIT_NUM];
    uint32_t stim_ch[CE32_CL_UNIT_NUM];
    uint8_t MISC_ratio;
    uint8_t PREV_ratio;
    uint16_t MISC_interval;
    uint32_t error_code;
    uint16_t firmware_version;
    uint16_t hw_version;
    CE32_RTC_DateWire date;
    CE32_RTC_TimeWire time;
    uint8_t MAC[8];
    uint32_t randtrig_min;
    uint32_t randtrig_max;
    float cl_param1[CE32_CL_UNIT_NUM];
    float cl_param2[CE32_CL_UNIT_NUM];
    uint16_t Vbatt_threshold;
    uint8_t Audio_ratio;
    uint8_t Camera_ratio;
    uint8_t unassigned[28];
    uint32_t base_fs;
    CE32_dataInfo datainfo;
} CE32_systemParam;

typedef struct
{
    int32_t Trig_delay_this;
    int32_t Trig_delay;
    int32_t Trig_RndDelay;
    int32_t Trig_duration;
    int32_t Trig_interval;
    float Trig_level;
    float Trig_gain;
    float Trig_mean;
    int32_t Train_sps;
    int32_t Train_start_sps;
    int32_t Trig_state;
    int32_t Trig_elapsed;
    int32_t STIM_CNT;
    int32_t count;
    int32_t id;
} CE32_StimControl;

typedef struct
{
    uint32_t Nrec;
    uint32_t log[CE32_SYSTEM_LOG_CAPACITY];
    uint32_t evt_log[CE32_SYSTEM_LOG_CAPACITY];
    uint32_t continued;
} CE32_systemLog;

typedef struct
{
    uint8_t chOrd[CE32_DSP_CH_ORD_MAX];
    uint32_t formula;
    uint32_t func1;
    uint32_t func2;
    uint32_t MAOrd1;
    float filter1[46];
    float filter2[46];
} CE32_dspParam;

#define CE32_STATIC_ASSERT(name, expr) typedef char static_assert_##name[(expr) ? 1 : -1]

CE32_STATIC_ASSERT(rtc_date_wire_size, sizeof(CE32_RTC_DateWire) == 4U);
CE32_STATIC_ASSERT(rtc_time_wire_size, sizeof(CE32_RTC_TimeWire) == 20U);
CE32_STATIC_ASSERT(datainfo_wire_size, sizeof(CE32_dataInfo) == 72U);
CE32_STATIC_ASSERT(system_param_wire_size, sizeof(CE32_systemParam) == 512U);
CE32_STATIC_ASSERT(system_log_wire_size, sizeof(CE32_systemLog) == 512U);
CE32_STATIC_ASSERT(dsp_param_wire_size, sizeof(CE32_dspParam) == 512U);

void CE32_WireFromHalDate(CE32_RTC_DateWire *dst, const RTC_DateTypeDef *src);
void CE32_WireFromHalTime(CE32_RTC_TimeWire *dst, const RTC_TimeTypeDef *src);
void CE32_HalDateFromWire(RTC_DateTypeDef *dst, const CE32_RTC_DateWire *src);
void CE32_HalTimeFromWire(RTC_TimeTypeDef *dst, const CE32_RTC_TimeWire *src);

#endif
