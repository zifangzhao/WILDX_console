#ifndef NP_CAMERA_ALIGNMENT_H
#define NP_CAMERA_ALIGNMENT_H
#include <stdint.h>
#include <string.h>

/* NanEye: 320 aligned 492-byte rows, 12 sync bytes then 160 SEIM pairs.
 * The masks cover every serial guard, not scene-dependent pixel values. */
#define NP_CAMERA_RASTER_WORDS (320U * 492U / 4U)
static inline int np_camera_raster_valid(const uint32_t *p)
{
    unsigned row, group;
    for(row=0; row<320U; row++){
        if(p[0]!=0x55555555U || p[1]!=0x55555555U || p[2]!=0x55555555U)return 0;
        p+=3;
        for(group=0; group<40U; group++,p+=3){
            if(((p[0]^0x80000880U)&0x80011880U) |
               ((p[1]^0x08800008U)&0x18800118U) |
               ((p[2]^0x00088000U)&0x01188001U))return 0;
        }
    }
    return 1;
}

static inline uint32_t np_camera_shift_left(uint32_t word,uint32_t next)
{return ((word<<1)&0xFEFEFEFEU) | ((word>>15)&0x00010101U) | ((next<<17)&0x01000000U);}
static inline uint32_t np_camera_shift_right(uint32_t word,uint32_t previous)
{return ((word>>1)&0x7F7F7F7FU) | ((word<<15)&0x80808000U) | ((previous>>17)&0x00000080U);}

/* Returns 1 unchanged, 2 aligned, 0 invalid. Only the completed private DMA
 * slot is touched. A captured trailing sync word supplies the final carry. */
static inline unsigned np_camera_align_raster(uint8_t *frame)
{
    uint32_t *p=(uint32_t *)(void *)frame;
    uint32_t previous=0,word;
    unsigned i,left;
    if(np_camera_raster_valid(p))return 1;
    /* A left-shifted stream carries the first pixel's start bit into the
     * last sync byte (0xAB), while the opposite phase leaves 0xAA. */
    if(p[0]!=0xAAAAAAAAU || p[1]!=0xAAAAAAAAU ||
       (p[2]!=0xAAAAAAAAU && p[2]!=0xABAAAAAAU))return 0;
    left=p[2]==0xAAAAAAAAU;
    for(i=0;i<NP_CAMERA_RASTER_WORDS;i++){
        word=p[i];
        p[i]=left?np_camera_shift_left(word,p[i+1]):np_camera_shift_right(word,previous);
        previous=word;
    }
    return np_camera_raster_valid(p)?2U:0U;
}

static inline void np_camera_invalid_raster(uint8_t *frame,unsigned bytes)
{
    static const uint8_t marker[16]={'C','E','6','4','C','A','M','G','A','P',1,0,0xA5,0x5A,0x69,0x96};
    memset(frame,0,bytes);
    memcpy(frame,marker,sizeof(marker));
}
#endif
