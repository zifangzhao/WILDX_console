#ifndef __CE32_system
#define __CE32_system

#include "CE32_ADC.h"
#include "CE32_BMX160.h"
#include "CE32_HJ580.h"
#include "CE32_filesystem.h"

#define BUF_GROUPS 4U
#define SYS_ID_SIG_EPHYS 0U
#define SYS_ID_SIG_PREV 1U
#define SYS_ID_SIG_ADC 2U
#define SYS_ID_SIG_MISC 3U
#define CE32_SWI_IRQ_IMU 5U

extern volatile uint8_t ce32_log_update_pending;
extern uint8_t ACC_buf_raw[20];
extern uint16_t ACC_value[10];
extern uint8_t ACC_buf[8];

void CE32_SWI_TRIG(int IRQn);
void CE32_SystemCompat_InitLegacyAdc(ADC_HandleTypeDef *hadc, uint32_t sample_rate_hz);
void CE32_SystemCompat_Service(void);
uint16_t CE32_SystemCompat_GetLegacyFsError(void);
void CE32_SystemCompat_ClearLegacyFsError(void);

#endif
