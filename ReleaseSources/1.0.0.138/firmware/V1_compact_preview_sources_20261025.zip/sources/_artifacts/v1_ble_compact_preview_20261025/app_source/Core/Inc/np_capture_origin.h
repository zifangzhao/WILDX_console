#ifndef NP_CAPTURE_ORIGIN_H
#define NP_CAPTURE_ORIGIN_H
#include "xe_np_acquisition_anchor.h"

/* Prove an early epoch; never select the lap nearest a nominal prediction.
 * TC supplies an independent lower bound. HSE-derived maximum request rate
 * and a POST-head cycle witness supply the upper bound. Stalls cannot raise
 * this bound. More than one possible lap is unconditionally ambiguous. */
static inline int np_capture_origin(const XE_NP_AcquisitionAnchor *a,
    uint32_t ring,uint32_t head,uint32_t cursor,uint32_t first_tc_samples,
    uint32_t post_cycles,uint32_t post_ms,uint32_t clock_hz,uint32_t source_hz,
    uint64_t *origin)
{
    uint32_t need=NP_ANCHOR_ROOT_VALID|NP_ANCHOR_CYCLES_VALID;
    if(!a || !origin || (a->flags&need)!=need || !ring || head>=ring || cursor>=ring ||
       !first_tc_samples || first_tc_samples>ring || !source_hz || (source_hz&3U) ||
       source_hz!=a->source_hz || clock_hz!=a->counter_hz ||
       !clock_hz || clock_hz%(source_hz/4U))return 0;
    uint32_t period=clock_hz/(source_hz/4U);
    uint32_t span=a->after_cycles-a->before_cycles;
    uint32_t elapsed=post_cycles-a->before_cycles,ms=post_ms-a->before_ms;
    if(!span || span>=clock_hz/1000U || elapsed<span || elapsed>=0x80000000U || ms>=1000U)return 0;
    uint32_t cycle_ms=(uint32_t)((uint64_t)elapsed*1000U/clock_hz);
    if((ms>cycle_ms?ms-cycle_ms:cycle_ms-ms)>2U)return 0;
    /* Include initial compare/pending phase conservatively. A successful
     * prearm witness separately excludes any previously completed reads. */
    uint64_t upper=(uint64_t)elapsed/period+2U;
    uint64_t lower_lap=first_tc_samples>head?
        ((uint64_t)first_tc_samples-head+ring-1U)/ring:0U;
    if(upper<head)return 0;
    uint64_t upper_lap=(upper-head)/ring;
    if(lower_lap!=upper_lap)return 0; /* Including whole-lap stall aliases. */
    uint64_t total=(uint64_t)head+lower_lap*ring;
    /* Only after uniqueness: reject stalled/delayed observations outside the
     * packed-word plus first-phase envelope (at most four time-lane samples).
     * This is not used to pick a preferred lap from an ambiguous interval. */
    uint64_t earliest=(uint64_t)(elapsed-span)/period;
    if(total+4U<earliest)return 0;
    uint32_t behind=(head+ring-cursor)%ring;
    if(total<behind)return 0;
    *origin=(total-behind)*4U; /* Four physical GPIO acquisition edges/lane. */
    return 1;
}
#endif
