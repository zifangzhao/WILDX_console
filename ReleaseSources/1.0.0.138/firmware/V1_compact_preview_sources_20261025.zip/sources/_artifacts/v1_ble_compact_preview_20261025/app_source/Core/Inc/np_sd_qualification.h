#ifndef NP_SD_QUALIFICATION_H
#define NP_SD_QUALIFICATION_H
static int np_sd_profile_qualified(const uint32_t *cid,uint32_t mask,uint32_t hz){
(void)cid;(void)mask;(void)hz;
return 0;}
#endif
