#ifndef NP_STORE_V2_BINDING_H
#define NP_STORE_V2_BINDING_H
#include "np_store_v2.h"

/* Bind every payload metadata sector to its allocation, not a reboot-prone
 * 32-bit session/tick. The caller seals the sector CRC after stamping. */
static inline int nps2_binding_stamp(uint8_t b[512],uint64_t epoch,uint32_t index)
{
    if(!epoch || index>=NPS2_RECORDS)return NPS2_INVALID;
    memcpy(b+464,"NPS2BND1",8);
    nps2_put64(b+472,epoch);nps2_put(b+480,index);return NPS2_OK;
}
static inline int nps2_binding_matches(const uint8_t b[512],uint64_t epoch,uint32_t index)
{
    return epoch && index<NPS2_RECORDS && !memcmp(b+464,"NPS2BND1",8) &&
        nps2_get64(b+472)==epoch && nps2_get(b+480)==index;
}
#endif
