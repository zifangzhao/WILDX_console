#ifndef NP_SD_RATE_PORT_H
#define NP_SD_RATE_PORT_H
#include "np_sd_rate_plan.h"
uint32_t NP_SD_RateCoreHz(void);
void NP_SD_RateRestore(void);
int NP_SD_RateStage(uint32_t mask,uint32_t hz);
#endif
