#ifndef NP_SD_RATE_PLAN_H
#define NP_SD_RATE_PLAN_H
#include <stdint.h>

/* Admission, not a measured-card/lossless qualification. SD remains PLL2Q
 * 120 MHz. High-rate pairs must share the GPIOE bank; three-lane capture
 * retains its implemented 15 kHz ceiling. */
#define NP_SD_RATE_PROFILES_FLAG 1048576U
#define NP_SD_RATE_COOKIE 0x3152504eU
static inline uint32_t np_sd_rate_count(uint32_t mask)
{ return (mask&1U)+((mask>>1)&1U)+((mask>>2)&1U); }
static inline uint32_t np_sd_rate_storage_bps(uint32_t mask,uint32_t hz)
{ return np_sd_rate_count(mask)*hz*832U; }
static inline int np_sd_rate_valid(uint32_t mask,uint32_t hz)
{
    if(!mask && !hz)return 1; /* camera-only; START also requires camera */
    if(mask<1U || mask>7U ||
       (hz!=7500U && hz!=15000U && hz!=20000U && hz!=30000U))return 0;
    uint32_t count=np_sd_rate_count(mask);
    if(count==3U && hz>15000U)return 0;
    if(count==2U && hz>=20000U && mask!=3U)return 0;
    /* The 4-bit SDR104 bus has an absolute 60 MB/s payload ceiling before
     * commands, CRC and card busy time. Never interpret that as sustained speed. */
    return np_sd_rate_storage_bps(mask,hz)<=60000000U;
}
static inline uint32_t np_sd_rate_core_hz(uint32_t hz)
{ return !hz?150000000U:hz==20000U?124800000U:187200000U; }
static inline uint32_t np_sd_rate_mco_divider(uint32_t hz)
{ return !hz?0U:hz>=20000U?2U:(hz==15000U?4U:8U); }
static inline uint32_t np_sd_rate_cookie(uint32_t mask,uint32_t hz)
{ return NP_SD_RATE_COOKIE^mask^hz; }
static inline int np_sd_rate_cookie_valid(uint32_t mask,uint32_t hz,uint32_t cookie,uint32_t inverse)
{ return np_sd_rate_valid(mask,hz) && cookie==np_sd_rate_cookie(mask,hz) && inverse==~cookie; }
#endif
