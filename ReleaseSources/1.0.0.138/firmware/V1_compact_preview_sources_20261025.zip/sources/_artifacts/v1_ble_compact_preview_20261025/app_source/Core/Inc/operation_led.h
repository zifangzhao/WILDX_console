#ifndef WILDX_V1_OPERATION_LED_H
#define WILDX_V1_OPERATION_LED_H

/* PC14 LED is active high. Apply only at lifecycle transitions; never from
 * capture completion or per-packet service. No read/modify/write of ODR. */
enum { WILDX_LED_IDLE, WILDX_LED_RECORDING, WILDX_LED_SLEEP };
static inline void WILDX_OperationLedApply(unsigned state)
{
    LED_GPIO_Port->BSRR = state == WILDX_LED_IDLE ?
        (uint32_t)LED_Pin : (uint32_t)LED_Pin << 16U;
}

#endif
