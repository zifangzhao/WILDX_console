#ifndef NP_SD_CHUNK_POOL_H
#define NP_SD_CHUNK_POOL_H
#include <stdint.h>
#include <string.h>
/* Private SRAM chunks + overflow PSRAM chunks. Logical FIFO slots do not
 * determine physical addresses. Only a consumed SD node releases SRAM. */
#ifndef NP_SD_INTERNAL_CHUNKS
#define NP_SD_INTERNAL_CHUNKS 16U
#endif
#ifndef NP_TX_PRIME_CHUNKS
#define NP_TX_PRIME_CHUNKS 16U
#endif
_Static_assert(NP_SD_INTERNAL_CHUNKS==16U || NP_SD_INTERNAL_CHUNKS==20U || NP_SD_INTERNAL_CHUNKS==21U,"Review SRAM placement for this geometry");
_Static_assert(NP_TX_PRIME_CHUNKS==4U || NP_TX_PRIME_CHUNKS==8U || NP_TX_PRIME_CHUNKS==16U,"Review SD command priming reserve");
_Static_assert(NP_TX_PRIME_CHUNKS<=NP_SD_INTERNAL_CHUNKS,"SD priming must fit private SRAM");
#define NP_SD_INTERNAL_MASK ((1U<<NP_SD_INTERNAL_CHUNKS)-1U)
#ifndef NP_CHUNK_POOL_WORD_VISIT
#define NP_CHUNK_POOL_WORD_VISIT() ((void)0)
#endif
static inline unsigned np_chunk_first_set(uint32_t bits)
{
#if defined(__clang__) || defined(__GNUC__)
    return (unsigned)__builtin_ctz(bits);
#else
    unsigned bit=0U;
    while((bits&1U)==0U){bits>>=1;bit++;}
    return bit;
#endif
}
typedef struct {
    uint32_t used[4], count, peak, external, spills;
    uint8_t physical[128];
    uint32_t head,oldest_external;
} NpSdChunkPool;
static inline void np_chunk_init(NpSdChunkPool *p)
{memset(p,0,sizeof(*p));memset(p->physical,255,sizeof(p->physical));}
static inline int np_chunk_claim(NpSdChunkPool *p,unsigned first,unsigned end)
{
    if(first>=end || end>128U)return -1;
    const unsigned first_word=first/32U,last_word=(end-1U)/32U;
    for(unsigned word=first_word;word<=last_word;word++) {
        NP_CHUNK_POOL_WORD_VISIT();
        uint32_t available=~p->used[word];
        if(word==first_word)available&=0xffffffffU<<(first%32U);
        if(word==last_word && (end%32U))available&=(1U<<(end%32U))-1U;
        if(!available)continue;
        const unsigned bit=np_chunk_first_set(available);
        const unsigned n=word*32U+bit;
        p->used[word]|=1U<<bit;p->count++;
        if(p->count>p->peak)p->peak=p->count;
        if(n>=NP_SD_INTERNAL_CHUNKS)p->external++;
        return (int)n;
    }
    return -1;
}
static inline int np_chunk_drop(NpSdChunkPool *p,unsigned physical)
{
    if(physical>=128U || !(p->used[physical/32U]&(1U<<(physical%32U))))return -1;
    p->used[physical/32U]&=~(1U<<(physical%32U));p->count--;
    if(physical>=NP_SD_INTERNAL_CHUNKS)p->external--;
    return 0;
}
static inline int np_chunk_in_window(const NpSdChunkPool *p,unsigned slot)
{return ((slot-p->head)&127U)<NP_TX_PRIME_CHUNKS;}
static inline int np_chunk_is_external(unsigned physical)
{return physical>=NP_SD_INTERNAL_CHUNKS && physical<128U;}
static inline int np_chunk_set_head(NpSdChunkPool *p,unsigned head)
{
    if(head>=128U)return -1;
    if(head==p->head)return 0;
    if(head==((p->head+1U)&127U)) {
        /* The normal one-chunk retirement needs only two lookups. Release
         * has already removed any leaving entry from the window counter. */
        p->oldest_external-=np_chunk_is_external(p->physical[p->head]);
        p->oldest_external+=np_chunk_is_external(p->physical[(p->head+NP_TX_PRIME_CHUNKS)&127U]);
    }else {
        p->oldest_external=0;
        for(unsigned n=0;n<NP_TX_PRIME_CHUNKS;n++)
            p->oldest_external+=np_chunk_is_external(p->physical[(head+n)&127U]);
    }
    p->head=head;return 0;
}
static inline int np_chunk_can_stage_internal(const NpSdChunkPool *p)
{
    /* A command cannot retire any SRAM until its complete oldest priming
     * window is resident. One reserved bounce target is insufficient: younger
     * direct stages could otherwise strand the FIFO behind external entries.
     * Count only external entries in that window: its already-resident older
     * chunks are themselves the reserve. Reserving another whole window in
     * addition would needlessly force newer data through PSRAM. */
    uint32_t internal=p->count-p->external;
    uint32_t reserve=p->oldest_external;
    return internal<NP_SD_INTERNAL_CHUNKS && NP_SD_INTERNAL_CHUNKS-internal>reserve;
}
static inline int np_chunk_can_stage(const NpSdChunkPool *p,int input_busy)
{
    /* A bounce target briefly owns an extra physical chunk beyond the FIFO
     * count. Backpressure must account for that reservation too. */
    if(p->count>=128U)return 0;
    if(np_chunk_can_stage_internal(p))return 1;
    /* The priming SRAM reserve belongs to bounce recovery, not the producer.
     * If all external chunks are occupied, input availability alone must
     * not admit a stage that the allocator cannot actually satisfy. */
    return !input_busy && p->external<128U-NP_SD_INTERNAL_CHUNKS;
}
static inline int np_chunk_acquire(NpSdChunkPool *p,unsigned slot)
{
    if(slot>=128U || p->physical[slot]!=255U)return -1;
    /* Younger direct stages may use only SRAM beyond the oldest command's
     * missing resident chunks. This is O(1), including an in-flight bounce. */
    int n=np_chunk_can_stage_internal(p)?np_chunk_claim(p,0,NP_SD_INTERNAL_CHUNKS):-1;
    if(n<0){n=np_chunk_claim(p,NP_SD_INTERNAL_CHUNKS,128);if(n>=0)p->spills++;}
    if(n>=0) {
        p->physical[slot]=(uint8_t)n;
        if(np_chunk_is_external((unsigned)n) && np_chunk_in_window(p,slot))p->oldest_external++;
    }
    return n;
}
static inline int np_chunk_move_internal(NpSdChunkPool *p,unsigned slot,unsigned target)
{
    if(slot>=128U || p->physical[slot]<NP_SD_INTERNAL_CHUNKS || p->physical[slot]>=128U || target>=NP_SD_INTERNAL_CHUNKS ||
       !(p->used[0]&(1U<<target)))return -1;
    /* target was reserved by the sole foreground bounce copier. */
    for(unsigned n=0;n<128U;n++)if(p->physical[n]==target)return -1;
    if(np_chunk_drop(p,p->physical[slot]))return -1;
    if(np_chunk_in_window(p,slot))p->oldest_external--;
    p->physical[slot]=(uint8_t)target;return 0;
}
static inline int np_chunk_release(NpSdChunkPool *p,unsigned slot)
{
    if(slot>=128U)return -1;
    unsigned external=np_chunk_is_external(p->physical[slot]);
    if(np_chunk_drop(p,p->physical[slot]))return -1;
    if(external && np_chunk_in_window(p,slot))p->oldest_external--;
    p->physical[slot]=255U;return 0;
}
#endif
