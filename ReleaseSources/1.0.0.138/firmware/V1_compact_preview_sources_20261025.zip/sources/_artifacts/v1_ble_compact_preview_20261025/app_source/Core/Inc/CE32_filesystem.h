#ifndef __CE32_FILE
#define __CE32_FILE

#include "stm32f4xx_hal.h"
#include "dataMGR.h"
#include "HD32_SD_driver.h"
#include "CE32_ClosedLoop.h"
#include "CE32_Sync.h"
#include "CE32_macro.h"

#define EVENT_SECTOR_OFFSET_PER_GB 0x20000U
#define DATA_INFO_VER 0x02U
#define DATA_INFO_HEADER_SIZE 0x2000U
#define LOG_INTERVAL (4U * AU_BLOCKS)
#define MIN_DATA_GUARD 1024U

typedef struct
{
    uint8_t uid;
    uint16_t f_id;
    uint64_t f_bytes;
    uint32_t f_sector_start;
    RTC_TimeTypeDef time;
    RTC_DateTypeDef date;
} CE32_FileInfo;

typedef struct
{
    CE32_FileInfo file_info;
    CE32_systemParam system_parameter;
    CE32_dspParam CE32_dspParam[2];
    CE32_StimControl CE32_StimControl[2];
} CE32_FileHeader;

typedef struct
{
    uint8_t eid;
    uint16_t data;
    RTC_TimeTypeDef evt_time;
} CE32_Event;

#define CE32_FILE_RESP_OK 0
#define CE32_FILE_RESP_INVALID_ADDR 1
#define CE32_FILE_RESP_ERROR 2
#define CE32_FILE_RESP_DATA_NOT_READY 3

#define CE32_FILE_STATE_PEND 0
#define CE32_FILE_STATE_EPHYS 1
#define CE32_FILE_STATE_MISC 2
#define CE32_FILE_STATE_LOG 3
#define CE32_FILE_STATE_EVENT 4
#define CE32_FILE_STATE_STOP 5

#define CE32_FILE_BUFFERID_NONE -1
#define CE32_FILE_BUFFERID_EPHYS 0
#define CE32_FILE_BUFFERID_CAMERA 1
#define CE32_FILE_BUFFERID_ADC 2
#define CE32_FILE_BUFFERID_MISC 3
#define CE32_FILE_BUFFERID_EVENT 4
#define CE32_FILE_BUFFERMGR_COUNT 3

#define CE32_FILE_ERROR_OVR 0x00U
#define CE32_FILE_ERROR_ADDR 0x01U
#define CE32_FILE_ERROR_WRITE 0x02U
#define CE32_FILE_ERROR_READ 0x03U
#define CE32_FILE_ERROR_NOCARD 0x04U
#define CE32_FILE_ERROR_CARDBUSY 0x05U
#define CE32_FILE_ERROR_FORMATERR 0x06U
#define CE32_FILE_ERROR_CARDFULL 0x07U
#define CE32_FILE_ERROR_TRANSERR 0x08U
#define CE32_FILE_WR_THRESHOLD_BYTES 1024U

#define CE32_FILE_IO_DIAG_MAGIC 0x46494F44UL
#define CE32_FILE_IO_DIAG_VERSION 1U

typedef struct
{
    uint32_t magic;
    uint32_t version;
    uint32_t last_read_addr;
    uint32_t last_read_status;
    uint32_t last_read_attempts;
    uint32_t last_write_addr;
    uint32_t last_write_status;
    uint32_t last_write_attempts;
} CE32_FileIoDiag;

extern volatile CE32_FileIoDiag ce32_file_io_diag;

#define CE32_DATABLK_REQUEST 0x01U
#define CE32_DATABLK_READY (0x01U << 1)

typedef struct
{
    uint8_t buf[512];
    uint32_t addr;
    uint16_t state;
} CE32_DataBlock;

#define MAX_MGR_PER_SIG 4U
typedef struct
{
    dataMGR *MGR[MAX_MGR_PER_SIG];
    uint8_t MGR_cnt;
    uint32_t bytes_to_Write;
    uint8_t ptr_in;
    uint8_t ptr_out;
    uint32_t byteRate;
    uint16_t byte_per_base_block;
} streamMGR;

#define MAX_FILESTREAM_DATATYPES 6U

typedef struct
{
    CE32_FileInfo *f_info_ptr;
    uint32_t f_header_sector;
    uint32_t f_data_sector;
    uint32_t f_event_sector;
    uint16_t total_records;
    __IO _Bool data_transfering;
    __IO _Bool block_transfer;
    __IO uint32_t WR_addr;
    uint32_t pending_block_cnt;
    uint32_t file_block_cnt;
    uint32_t event_block_cnt;
    uint32_t last_logged_block;
    uint32_t log_interval_blocks;
    uint32_t ephys_misc_cnt;
    float speed_MBs;
    uint32_t fail_cnt;
    uint32_t preErase_block;
    uint16_t time2sps;
    uint32_t file_addr;
    uint32_t event_addr;
    uint32_t log_addr;
    uint32_t misc_sample_count;
    __IO uint16_t state;
    __IO uint16_t enabled;
    uint16_t power_save;
    uint32_t WR_threshold;
    __IO uint16_t SD_DMA_GUARD;
    __IO int16_t MGR_id;
    __IO int16_t baseMGR_id;
    __IO uint8_t next_valid;
    __IO uint8_t next_mgr_id;
    __IO uint32_t next_addr;
    __IO uint8_t *next_ptr;
    __IO uint16_t next_multi;
    __IO uint8_t stop_pending;
    __IO uint8_t stop_requested;
    streamMGR MGR[MAX_FILESTREAM_DATATYPES];
    dataMGR *WR_MGR;
    CE32_systemParam *sysParam;
    CE32_systemLog *sysLog;
    CE32_dspParam *sysDSP;
    __IO uint16_t stateMachine;
    __IO int16_t evt_next;
    SPI_HandleTypeDef *hspi;
    CE32_DataBlock readBuf;
} CE32_FileStream;

extern CE32_FileStream fs;

void CE32_DATABLK_Init(CE32_DataBlock *db);
int CE32_DATABLK_Request(CE32_DataBlock *db, uint32_t addr);
int CE32_DATABLK_Check(CE32_DataBlock *db, uint32_t flag);

void streamMGR_init(streamMGR *h, dataMGR *mgr, uint32_t byteRate, uint32_t baseRate);
void streamMGR_init_dual(streamMGR *h, dataMGR *mgr1, dataMGR *mgr2, uint32_t byteRate, uint32_t baseRate);
void streamMGR_reset(streamMGR *h);
int CE32_File_FileInfo_Init(CE32_FileInfo *finfo, uint16_t f_id, uint64_t f_bytes, uint32_t f_sector_start, RTC_TimeTypeDef time, RTC_DateTypeDef date);
void CE32_File_FileStream_UpdateFileStructure(CE32_FileStream *fs);
int CE32_File_FileStream_ConfigStream(CE32_FileStream *fs, uint8_t streamID, dataMGR *mgr, uint32_t byteRate);
int CE32_File_FileStream_ConfigStream_dual(CE32_FileStream *fs, uint8_t streamID, dataMGR *mgr, dataMGR *mgr1, uint32_t byteRate);
int CE32_File_FileStream_Init(CE32_FileStream *fs, SPI_HandleTypeDef *hspi, CE32_systemParam *sysParam, CE32_systemLog *sysLog, CE32_dspParam *sysDSP, int state_reset);
int CE32_File_FileStream_RecPrepare(CE32_FileStream *fs);
int CE32_File_FileStream_exec(CE32_FileStream *fs);
int CE32_File_FileStream_WriteBlock(CE32_FileStream *fs, uint32_t addr, uint8_t *dataptr, uint16_t multi_blk);
int CE32_File_FileStream_WriteBlock_DMA(CE32_FileStream *fs, uint32_t addr, uint8_t *dataptr, uint16_t multi_blk);
int CE32_File_FileStream_WriteFileLog(CE32_FileStream *fs, int dma_on);
int CE32_File_FileStream_WriteData(CE32_FileStream *fs);
int CE32_File_FileStream_WriteEvent(CE32_FileStream *fs);
int CE32_File_FileStream_ReadBlock(CE32_FileStream *fs);
int CE32_File_FileStream_LoadParams(CE32_FileStream *fs);
int CE32_File_FileStream_SaveParams(CE32_FileStream *fs);
int CE32_File_FileStream_Init_StartNewFile(CE32_FileStream *fs);
int CE32_File_FileStream_StartNewFile(CE32_FileStream *fs);
int CE32_File_FileStream_StopAndSave(CE32_FileStream *fs);
int CE32_File_FileStream_PostStop(CE32_FileStream *fs);
int CE32_File_FileStream_DataScheduler(CE32_FileStream *fs);
int CE32_File_FileStream_CheckTransfer(CE32_FileStream *fs);
int CE32_File_FileStream_TransOK(CE32_FileStream *fs);
int CE32_File_FileStream_TransERR(CE32_FileStream *fs);
int CE32_File_FileStream_BufferPurge(CE32_FileStream *fs);
int CE32_File_FileStream_GetFileAddr(CE32_FileStream *fs, uint32_t file_id, uint32_t *addr);
void CE32_File_FileStream_PowerSave(CE32_FileStream *fs, int enabled);
void CE32_File_FileStream_TransferCompleteCallback(CE32_FileStream *fs);
void CE32_File_FileStream_ServiceDeferredSignals(void);
void CE32_File_FileStream_InitAct(void);
void CE32_File_FileStream_PreLoadAct(void);
void CE32_File_FileStream_PostLoadAct(void);
void CE32_File_FileStream_RecInitAct(void);
void CE32_File_FileStream_PreStartAct(void);
void CE32_File_FileStream_StartAct(void);
void CE32_File_FileStream_StopAct(void);
void CE32_File_FileStream_ErrorAct(uint16_t error_ID);

#define CE32_FILE_GET_LOGID(__handle__) ((int)((__handle__)->total_records - 1U) / MAX_LOG_PER_BLOCK)
#define CE32_FILE_GET_RECORDID(__handle__) ((int)((__handle__)->total_records - 1U) % MAX_LOG_PER_BLOCK)

typedef enum
{
    sta_uninit = 0,
    sta_pend,
    sta_schedule,
    sta_tranfer,
    sta_stopping,
    sta_error
} CE32_FS_State;

typedef enum
{
    evt_init = 0,
    evt_start,
    evt_schedule,
    evt_transOK,
    evt_transERR,
    evt_stop,
    evt_deinit
} CE32_FS_Event;

typedef struct
{
    CE32_FS_State curState;
    CE32_FS_Event event;
    CE32_FS_State nextState;
    int (*callback)(CE32_FileStream *fs);
} CE32_FS_StateTransform;

void fs_state_action(CE32_FileStream *fs, CE32_FS_StateTransform *statTran);
void fs_state_event(CE32_FileStream *fs, uint16_t event);
void CE32_File_FileStream_Init_PreAct(CE32_FileStream *fs);

#endif
