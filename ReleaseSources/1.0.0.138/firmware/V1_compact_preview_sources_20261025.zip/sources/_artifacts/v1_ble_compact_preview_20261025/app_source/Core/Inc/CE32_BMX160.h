#ifndef __CE32_BMX160
#define __CE32_BMX160

#include "stm32f4xx_hal.h"
#include "CE32_macro.h"

#define LITTLE_ENDIAN 1

#define BMX160_MAG_DATA_ADDR 0x04
#define BMX160_ACCEL_DATA_ADDR 0x12
#define BMX160_ACCEL_CONFIG_ADDR 0x40
#define BMX160_ACCEL_RANGE_ADDR 0x41
#define BMX160_GYRO_CONFIG_ADDR 0x42
#define BMX160_GYRO_RANGE_ADDR 0x43
#define BMX160_MAGN_CONFIG_ADDR 0x44
#define BMX160_MAGN_IF_0_ADDR 0x4C
#define BMX160_MAGN_IF_1_ADDR 0x4D
#define BMX160_MAGN_IF_2_ADDR 0x4E
#define BMX160_MAGN_IF_3_ADDR 0x4F
#define BMX160_COMMAND_REG_ADDR 0x7E

#define BMX160_SOFT_RESET_CMD 0xB6
#define BMX160_SOFT_RESET_DELAY_MS 15U

#define BMX160_ACCEL_SUSPEND_MODE 0x10
#define BMX160_ACCEL_NORMAL_MODE 0x11
#define BMX160_GYRO_SUSPEND_MODE 0x14
#define BMX160_GYRO_NORMAL_MODE 0x15
#define BMX160_MAGN_SUSPEND_MODE 0x18

#define BMX160_ACCEL_RANGE_2G 0x03
#define BMX160_ACCEL_RANGE_4G 0x05
#define BMX160_ACCEL_RANGE_8G 0x08
#define BMX160_ACCEL_RANGE_16G 0x0C

#define BMX160_GYRO_RANGE_2000_DPS 0x00
#define BMX160_GYRO_RANGE_1000_DPS 0x01
#define BMX160_GYRO_RANGE_500_DPS 0x02
#define BMX160_GYRO_RANGE_250_DPS 0x03
#define BMX160_GYRO_RANGE_125_DPS 0x04

#define BMX160_ACCEL_MG_LSB_2G 0.000061035F
#define BMX160_ACCEL_MG_LSB_4G 0.000122070F
#define BMX160_ACCEL_MG_LSB_8G 0.000244141F
#define BMX160_ACCEL_MG_LSB_16G 0.000488281F

#define BMX160_GYRO_SENSITIVITY_125DPS 0.0038110F
#define BMX160_GYRO_SENSITIVITY_250DPS 0.0076220F
#define BMX160_GYRO_SENSITIVITY_500DPS 0.0152439F
#define BMX160_GYRO_SENSITIVITY_1000DPS 0.0304878F
#define BMX160_GYRO_SENSITIVITY_2000DPS 0.0609756F

#define BMX160_ACCEL_BW_NORMAL_AVG4 0x02
#define BMX160_GYRO_BW_NORMAL_MODE 0x02
#define BMX160_ACCEL_ODR_100HZ 0x08
#define BMX160_ACCEL_ODR_200HZ 0x09
#define BMX160_GYRO_ODR_200HZ 0x09
#define BMX160_MAGN_UT_LSB 0.3F

#define BMX160_I2C_ADDR 0x68

#define CE32_BMX160_STATE_IDLE 0x00U
#define CE32_BMX160_STATE_READY 0x01U
#define CE32_BMX160_STATE_BUSY 0x02U

typedef struct
{
    uint8_t power;
    uint8_t odr;
    uint8_t range;
    uint8_t bw;
} sBmx160Cfg_t;

typedef struct
{
    sBmx160Cfg_t magnCfg;
    sBmx160Cfg_t prevMagnCfg;
    sBmx160Cfg_t accelCfg;
    sBmx160Cfg_t prevAccelCfg;
    sBmx160Cfg_t gyroCfg;
    sBmx160Cfg_t prevGyroCfg;
} sBmx160Dev_t;

typedef struct
{
    float x;
    float y;
    float z;
    uint32_t sensortime;
} sBmx160SensorData_t;

typedef enum
{
    eGyroRange_2000DPS = 0,
    eGyroRange_1000DPS,
    eGyroRange_500DPS,
    eGyroRange_250DPS,
    eGyroRange_125DPS
} eGyroRange_t;

typedef enum
{
    eAccelRange_2G = 0,
    eAccelRange_4G,
    eAccelRange_8G,
    eAccelRange_16G
} eAccelRange_t;

typedef enum
{
    PMODE_Normal = 0,
    PMODE_Lowpower,
    PMODE_Stop,
} CE32_IMU_BMX160_PMODE;

typedef struct
{
    uint16_t ACC_buf[9];
    I2C_HandleTypeDef *hi2c;
    DMA_HandleTypeDef *hdma_i2c_rx;
    GPIO_TypeDef *GPIO_SDA;
    uint16_t SDA_Pin;
    GPIO_TypeDef *GPIO_SCL;
    uint16_t SCL_Pin;
    CE32_IMU_BMX160_PMODE PMode;

    uint16_t state;
    int16_t data_cnt;
    uint8_t *data_ptr;
    uint8_t RD_addr;
    int16_t RD_cnt;

    float accelRange;
    float gyroRange;
    uint8_t _addr;

    sBmx160Dev_t *Obmx160;

    sBmx160SensorData_t Omagn;
    sBmx160SensorData_t Oaccel;
    sBmx160SensorData_t Ogyro;
} CE32_IMU_BMX160_handle;

extern CE32_IMU_BMX160_handle ACC_handle;

int CE32_IMU_BMX160_init(
    CE32_IMU_BMX160_handle *handle,
    I2C_HandleTypeDef *hi2c,
    DMA_HandleTypeDef *hdma_i2c_rx,
    GPIO_TypeDef *GPIO_SDA,
    uint16_t SDA_Pin,
    GPIO_TypeDef *GPIO_SCL,
    uint16_t SCL_Pin,
    CE32_IMU_BMX160_PMODE Pmode);
int CE32_IMU_BMX160_begin(CE32_IMU_BMX160_handle *handle);
int CE32_IMU_BMX160_suspend(CE32_IMU_BMX160_handle *handle);
int CE32_IMU_BMX160_setLowPower(CE32_IMU_BMX160_handle *handle);
int CE32_IMU_BMX160_wakeUp(CE32_IMU_BMX160_handle *handle);
int CE32_IMU_BMX160_softReset(CE32_IMU_BMX160_handle *handle);
int CE32_IMU_BMX160__softReset(CE32_IMU_BMX160_handle *handle, sBmx160Dev_t *dev);
int CE32_IMU_BMX160_defaultParamSet(CE32_IMU_BMX160_handle *handle, sBmx160Dev_t *dev);
int CE32_IMU_BMX160_setAccConf(CE32_IMU_BMX160_handle *handle);
int CE32_IMU_BMX160_setGyroConf(CE32_IMU_BMX160_handle *handle);
int CE32_IMU_BMX160_setMagnConf(CE32_IMU_BMX160_handle *handle);
int CE32_IMU_BMX160_setGyroRange(CE32_IMU_BMX160_handle *handle, eGyroRange_t bits);
int CE32_IMU_BMX160_setAccelRange(CE32_IMU_BMX160_handle *handle, eAccelRange_t bits);
int CE32_IMU_BMX160_getAllData(CE32_IMU_BMX160_handle *handle);
int CE32_IMU_BMX160_startScan(CE32_IMU_BMX160_handle *handle, uint8_t *ptr, uint8_t len);

void CE32_IMU_StopTrans(CE32_IMU_BMX160_handle *handle);
void CE32_IMU_ReleaseI2C(CE32_IMU_BMX160_handle *handle);

void CE32_IMU_BMX160_RX_IT_Callback(CE32_IMU_BMX160_handle *handle);
void CE32_IMU_PreInitAct(void);
void CE32_IMU_RXAct(void);

#endif
