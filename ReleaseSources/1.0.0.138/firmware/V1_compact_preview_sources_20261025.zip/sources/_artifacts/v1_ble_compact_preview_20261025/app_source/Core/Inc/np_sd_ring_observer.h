#ifndef NP_SD_RING_OBSERVER_H
#define NP_SD_RING_OBSERVER_H
#include <stdint.h>
/* Independent of SysTick: a masked/coalesced tick must not hide a DMA lap.
 * cycles_per_byte is derived by the caller from the configured core and lane
 * rates. GPIO MCLK and the CPU share a clock source; this mode does not DVFS. */
typedef struct {uint32_t cycles,head,valid;} NpSdRingClock;
static inline int np_sd_ring_observe(NpSdRingClock *s,uint32_t cycles,uint32_t head,
                                    uint32_t size,uint32_t guard,
                                    uint32_t cycles_per_byte,
                                    uint32_t *elapsed,uint32_t *advance)
{
    if(!elapsed || !advance)return -1;
    *elapsed=0U;*advance=0U;
    if(!s || !guard || size<=guard || head>=size || !cycles_per_byte)return -1;
    *elapsed=cycles-s->cycles;*advance=(head+size-s->head)%size;
    if(s->valid) {
        uint32_t expected=*elapsed/cycles_per_byte;
        if(expected>=size-guard)return -2;
        uint32_t difference=expected>*advance?expected-*advance:*advance-expected;
        /* CDAR is packed-word granular and is observed a few instructions
         * after CYCCNT. 128 bytes tolerates about 22 us at 30 kHz, not a lap. */
        if(difference>128U)return -3;
    }
    s->cycles=cycles;s->head=head;s->valid=1;return 0;
}
#endif
