#ifndef __CE32_ADC
#define __CE32_ADC

#include "stm32f4xx_hal.h"
#include "CE32_macro.h"

typedef struct
{
    uint16_t state;
    ADC_HandleTypeDef *hadc;
    TIM_HandleTypeDef *htim_trig;
    TIM_HandleTypeDef *htim_dma;
    uint16_t *buffer_ptr;
    uint16_t JDR[4];
    uint16_t DR;
    uint8_t Nch;
    uint32_t fs;
    dataMGR MGR;
} CE32_ADC;

extern CE32_ADC ADC_handle;

int CE32_ADC_Init(CE32_ADC *h, ADC_HandleTypeDef *hadc, TIM_HandleTypeDef *htim_trig, TIM_HandleTypeDef *htim_dma, uint32_t fs, uint8_t Nch, uint8_t *buffer_ptr, uint16_t buffer_size);
int CE32_ADC_SwitchVbattSense(CE32_ADC *h, int channel);
int CE32_ADC_StartDMA(CE32_ADC *h);
int CE32_ADC_StartTimerDMA(CE32_ADC *h);
int CE32_ADC_Stop(CE32_ADC *h);
int CE32_ADC_StartConversion(CE32_ADC *h);
int CE32_ADC_JStartConversion(CE32_ADC *h);
int CE32_ADC_PollJConvertion(CE32_ADC *h);
int CE32_ADC_ReadInject(CE32_ADC *h);
void CE32_ADC_PreStartConfig(CE32_ADC *h);
void CE32_ADC_DMA_halfCplt(CE32_ADC *h);
int CE32_ADC_preInit_Act(CE32_ADC *h);

#define ADC_JDR_COMP_RATE 1U

#endif
