#ifndef __CE32_CL
#define __CE32_CL

#include "dataMGR.h"

#define CE32_CL_RNDTRIG_SUBSAMPLE 100U
#define SC_STATE_TRIG 0x00000001U
#define SC_STATE_STIM 0x00000002U
#define SC_STATE_RNDELAY 0x00000010U
#define SC_STATE_TRIGREADY 0x00000020U
#define SC_STATE_ON 0x00000800U
#define SC_STATE_TRAINING 0x00001000U
#define SC_STATE_TRAINED 0x00002000U
#define SC_STATE_WAITING 0x00004000U
#define SC_STATE_EXTCTRL 0x00008000U

typedef struct
{
    uint32_t min_delay;
    uint32_t max_delay;
    uint64_t delay_cnt;
    uint8_t state;
} CE32_CL_RndTrig;

#endif
