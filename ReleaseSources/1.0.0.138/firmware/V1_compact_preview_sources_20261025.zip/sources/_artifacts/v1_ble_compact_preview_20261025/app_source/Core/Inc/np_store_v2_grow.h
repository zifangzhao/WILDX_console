#ifndef NP_STORE_V2_GROW_H
#define NP_STORE_V2_GROW_H
#include "np_store_v2.h"

/* One serialized foreground owner, no I/O or polling inside this helper.
 * Zero-initialize the job before first use. The cached OPEN record must have
 * been authenticated under s->epoch (Nps2Record itself has no epoch field).
 * Until DONE/FAILED, do not mount/format/finish or alter s/the cached record.
 * request() describes ONE operation; never reissue it before ack(). Readback
 * must use a separate 512-byte buffer, not expected[]. ack(0) advances a phase;
 * only DONE publishes the grant. A nonzero I/O result fails the job.
 * Odd phases write expected[512], even phases read/compare the same sector:
 *   1/2 checkpoint0, 3/4 checkpoint1, 5/6 record0, 7/8 record1.
 * A timeout must be retired by the outer I/O owner and acked as a failure;
 * this helper neither cancels hardware nor grants payload beyond s->frontier. */
enum {
    NPS2_GROW_IDLE=0,NPS2_GROW_CHECK0_WRITE=1,NPS2_GROW_CHECK0_READ=2,
    NPS2_GROW_CHECK1_WRITE=3,NPS2_GROW_CHECK1_READ=4,
    NPS2_GROW_RECORD0_WRITE=5,NPS2_GROW_RECORD0_READ=6,
    NPS2_GROW_RECORD1_WRITE=7,NPS2_GROW_RECORD1_READ=8,
    NPS2_GROW_DONE=9,NPS2_GROW_FAILED=10
};
enum {NPS2_GROW_NONE=0,NPS2_GROW_WRITE=1,NPS2_GROW_READ=2};
typedef struct {
    Nps2State next;
    Nps2Record record;
    uint8_t expected[512];
    uint32_t old_end,phase;
} Nps2GrowJob;

static inline int nps2_grow_prepare(Nps2GrowJob *j,const Nps2State *s,
                                   const Nps2Record *r,uint32_t end)
{
    if(!j || !s || !r || (j->phase>=1U && j->phase<=8U) ||
       s->ready!=1U || s->live!=1U || s->open!=1U || !s->epoch ||
       !s->generation || s->generation==UINT64_MAX || !s->count ||
       s->count>NPS2_RECORDS || s->capacity<=NPS2_DATA ||
       s->end!=s->frontier || !nps2_aligned(s->start) || !nps2_aligned(s->end) ||
       s->start>=s->end || s->end>s->capacity || !s->session ||
       !nps2_aligned(end) || end<=s->frontier || end>s->capacity ||
       r->generation!=s->generation || r->index!=s->count-1U ||
       r->state!=NPS2_RECORD_OPEN || r->start!=s->start ||
       r->reserved_end!=s->end || r->session!=s->session ||
       r->committed_end<r->start || r->committed_end>r->reserved_end)return NPS2_INVALID;
    j->next=*s;j->next.generation++;j->next.end=j->next.frontier=end;
    j->record=*r;j->record.generation=j->next.generation;j->record.reserved_end=end;
    j->old_end=s->end;
    nps2_record_sector(j->expected,&j->next,&j->record);
    if(!nps2_record_valid(j->expected,&j->next,j->record.index))return NPS2_INVALID;
    nps2_checkpoint(j->expected,&j->next);
    if(!nps2_checkpoint_valid(j->expected,j->next.capacity,j->next.epoch))return NPS2_INVALID;
    j->phase=NPS2_GROW_CHECK0_WRITE;return NPS2_OK;
}
static inline int nps2_grow_request(const Nps2GrowJob *j,uint32_t *lba,
                                   const uint8_t **write_bytes)
{
    uint32_t slot;
    if(!j || !lba || !write_bytes)return NPS2_INVALID;
    *write_bytes=0;
    if(j->phase<1U || j->phase>8U)return NPS2_GROW_NONE;
    if(j->record.index>=NPS2_RECORDS)return NPS2_INVALID;
    slot=(j->phase-1U)/2U;
    *lba=slot==0U?NPS2_CHECK0:slot==1U?NPS2_CHECK1:
        NPS2_RECORD_BASE+2U*j->record.index+slot-2U;
    if(*lba>=NPS2_DATA)return NPS2_INVALID;
    if(j->phase&1U){*write_bytes=j->expected;return NPS2_GROW_WRITE;}
    return NPS2_GROW_READ;
}
static inline int nps2_grow_current(const Nps2GrowJob *j,const Nps2State *s,
                                   const Nps2Record *r)
{
    return s->ready==1U && s->live==1U && s->open==1U &&
        s->epoch==j->next.epoch && s->generation==j->next.generation-1U &&
        s->capacity==j->next.capacity && s->count==j->next.count &&
        s->start==j->next.start && s->end==j->old_end && s->frontier==j->old_end &&
        s->session==j->next.session && r->generation==s->generation &&
        r->index==j->record.index && r->start==j->record.start &&
        r->reserved_end==j->old_end && r->committed_end==j->record.committed_end &&
        r->session==j->record.session && r->state==NPS2_RECORD_OPEN;
}
static inline int nps2_grow_ack(Nps2GrowJob *j,Nps2State *s,Nps2Record *r,
                               int io_result,const uint8_t *readback)
{
    if(!j || !s || !r || j->phase<1U || j->phase>8U)return NPS2_INVALID;
    if(!nps2_grow_current(j,s,r)){
        j->phase=NPS2_GROW_FAILED;s->ready=s->live=0U;return NPS2_INVALID;
    }
    if(io_result || (!(j->phase&1U) && (!readback || readback==j->expected ||
        memcmp(readback,j->expected,512)))){
        j->phase=NPS2_GROW_FAILED;s->ready=s->live=0U;return NPS2_IO;
    }
    if(j->phase==NPS2_GROW_RECORD1_READ){
        *s=j->next;*r=j->record;j->phase=NPS2_GROW_DONE;return NPS2_OK;
    }
    if(j->phase==NPS2_GROW_CHECK1_READ)nps2_record_sector(j->expected,&j->next,&j->record);
    j->phase++;return NPS2_OK;
}
#endif
