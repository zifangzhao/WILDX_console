#ifndef NP_SD_INTERNAL_MEMORY_H
#define NP_SD_INTERNAL_MEMORY_H
#include <stdint.h>
/* U595 internal SRAM address window. Subtraction avoids end-address overflow.
 * This is a cache-maintenance filter, NOT a DMA address/ownership validator. */
static inline int np_sd_internal_range(uintptr_t address,uint32_t bytes)
{
    return bytes && address>=0x20000000UL && address<0x20280000UL &&
           bytes<=0x20280000UL-address;
}
#endif
