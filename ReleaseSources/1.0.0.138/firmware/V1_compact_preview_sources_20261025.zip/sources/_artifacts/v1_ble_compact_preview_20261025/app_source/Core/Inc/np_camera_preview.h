#ifndef NP_CAMERA_PREVIEW_H
#define NP_CAMERA_PREVIEW_H
#include <stdint.h>

/* Existing CE64/WILD 40x40 preview. Only a pinned, complete 160000-byte
 * raster is sampled. UART reads this private cache, never the capture lane. */
static struct {
    uint32_t state,row,frame_id,frames,sent_rows;
    uint8_t pixels[40U][40U];
    uint32_t next_tx_ms;
} np_camera_preview;

/* Full resolution is live and unsynchronized. Retain only one disposable
 * 160-pixel packet, never a camera frame or acquisition-buffer lease. */
static struct {
    uint32_t state,fragment,transfer_id,frame_id,packet_ready;
    uint8_t pixels[160U];
} np_camera_full;

static unsigned np_camera_pixel(const uint8_t *frame,unsigned row,unsigned column)
{
    const uint8_t *p=frame+row*492U+12U+(column/2U)*3U;
    return (column&1U)?((p[1]&7U)<<7U)|((p[2]&0xfeU)>>1U):
        ((p[0]&0x7fU)<<3U)|(p[1]>>5U);
}

static void np_camera_full_request(void)
{
    if(np_camera_full.state)return;
    np_camera_full.transfer_id++;np_camera_full.fragment=0;np_camera_full.packet_ready=0;
    np_camera_full.state=2U;
}
static void np_camera_full_pixels(const uint8_t *frame,unsigned fragment,uint8_t *pixels)
{
    unsigned row=fragment/2U,column=(fragment&1U)*160U;
    for(unsigned x=0;x<160U;x++)
        pixels[x]=(uint8_t)(np_camera_pixel(frame,319U-row,319U-column-x)>>2U);
}
static void np_camera_full_frame(const uint8_t *frame,uint32_t id)
{
    if(!frame || np_camera_full.state!=2U || np_camera_full.packet_ready)return;
    np_camera_full_pixels(frame,np_camera_full.fragment,np_camera_full.pixels);
    np_camera_full.frame_id=id;np_camera_full.packet_ready=1U;
}

static void np_camera_preview_request(void)
{
    if(!np_camera_preview.state)np_camera_preview.state=1U;
}
static void np_camera_preview_frame(const uint8_t *frame,uint32_t id)
{
    if(!frame || np_camera_preview.state!=1U)return;
    for(unsigned y=0;y<40U;y++)for(unsigned x=0;x<40U;x++){
        unsigned column=319U-x*8U,row=319U-y*8U;
        unsigned value=np_camera_pixel(frame,row,column);
        /* WILD shifts each seven-bit code left once for its 8-bit image. */
        np_camera_preview.pixels[y][x]=(uint8_t)(value>>3U);
    }
    np_camera_preview.frame_id=id;np_camera_preview.frames++;
    np_camera_preview.row=0;np_camera_preview.state=2U;
}
static void np_camera_preview_row_sent(void)
{
    np_camera_preview.sent_rows++;
    if(++np_camera_preview.row==40U)np_camera_preview.state=0;
}
#endif
