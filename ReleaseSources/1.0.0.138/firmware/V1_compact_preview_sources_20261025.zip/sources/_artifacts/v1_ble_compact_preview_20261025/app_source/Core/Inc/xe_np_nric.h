#ifndef XE_NP_NRIC_H
#define XE_NP_NRIC_H

#include "xe_np_board.h"
#include "xe_np_hal.h"

#include <stdint.h>

#define XE_NP_NRIC_I2C_ADDR 0xE0U
#define XE_NP_NRIC_I2C_TIMEOUT_MS 100U
#define XE_NP_NRIC_I2C_READY_TRIALS 2U
#define XE_NP_NRIC_SR_PROGRAM_TIMEOUT_MS 50U

#define XE_NP_NRIC_REG_OP_MODE 0x00U
#define XE_NP_NRIC_REG_REC_MOD 0x01U
#define XE_NP_NRIC_REG_CAL_MOD 0x02U
#define XE_NP_NRIC_REG_STATUS 0x08U
#define XE_NP_NRIC_REG_SYNC 0x09U
#define XE_NP_NRIC_REG_SR_CHAIN3 0x0CU
#define XE_NP_NRIC_REG_SR_CHAIN2 0x0DU
#define XE_NP_NRIC_REG_SR_LENGTH2 0x0FU
#define XE_NP_NRIC_REG_SR_LENGTH1 0x10U

#define XE_NP_NRIC_OP_MODE_RECORD 0x40U

#define XE_NP_NRIC_REC_MOD_CH_NRESET 0x80U
#define XE_NP_NRIC_REC_MOD_DIG_NRESET 0x40U
#define XE_NP_NRIC_REC_MOD_SR_DEFAULT 0x20U
#define XE_NP_NRIC_REC_MOD_PSB_HALF_RATE 0x10U

#define XE_NP_NRIC_CAL_MOD_CH_TST 0x40U
#define XE_NP_NRIC_CAL_MOD_GPO_0 0x10U

#define XE_NP_NRIC_STATUS_SR_OUT_OK 0x80U

#define XE_NP_NRIC_DEFAULT_SYNC_VALUE 0x11U

#define XE_NP_NRIC_OP_MODE_DIGITAL_TEST 0x10U

#define XE_NP_NRIC_BASE_CHAIN_BYTES 306U
#define XE_NP_NRIC_SR_READBACK_TEST_COUNT 11U
#define XE_NP_NRIC_USE_SR_DEFAULT_STARTUP 0U
/*
 * Keep full-rate mode for the target recording path. Half-rate was tested as
 * a diagnostic mitigation, but it did not produce a usable PA0/EXTI stream on
 * the current NP2 bench setup.
 */
#define XE_NP_NRIC_USE_PSB_HALF_RATE 0U
#if XE_NP_NRIC_USE_PSB_HALF_RATE
#define XE_NP_NRIC_CONFIGURED_PSB_CLK_HZ XE_NP_BOARD_EFFECTIVE_EXPECTED_PSB_CLK_HALF_HZ
#else
#define XE_NP_NRIC_CONFIGURED_PSB_CLK_HZ XE_NP_BOARD_EFFECTIVE_EXPECTED_PSB_CLK_FULL_HZ
#endif
#ifndef XE_NP_NRIC_DIAG_DIGITAL_TEST_STREAM
#define XE_NP_NRIC_DIAG_DIGITAL_TEST_STREAM 0U
#endif
#ifndef XE_NP_NRIC_STARTUP_CAL_MOD
#define XE_NP_NRIC_STARTUP_CAL_MOD 0U
#endif

typedef struct
{
    uint32_t tick_ms;
    uint32_t i2c_error_code;
    uint32_t i2c_isr;
    uint8_t step;
    uint8_t reg_addr;
    uint8_t hal_status;
    uint8_t status_reg;
    uint8_t read_value;
    uint8_t expected_value;
    uint8_t reserved[2];
} XE_NP_NricDiag;

typedef struct
{
    uint8_t reg_addr;
    uint8_t pattern_id;
    uint8_t status_reg;
    uint8_t fail_step;
    uint8_t hal_status;
    uint8_t sr_ok;
    uint16_t fail_index;
    uint16_t raw_mismatch_count;
    uint16_t reversed_mismatch_count;
    uint16_t first_raw_mismatch_index;
    uint16_t first_reversed_mismatch_index;
    uint8_t sample0_expected;
    uint8_t sample0_raw;
    uint8_t sample0_reversed;
    uint8_t sample_mid_expected;
    uint8_t sample_mid_raw;
    uint8_t sample_mid_reversed;
    uint8_t sample_last_expected;
    uint8_t sample_last_raw;
    uint8_t sample_last_reversed;
    uint8_t chain_length_lo;
    uint8_t chain_length_hi;
    uint8_t status_before_program;
    uint8_t status_immediate;
    uint8_t length1_readback;
    uint8_t length2_readback;
    uint8_t length_readback_valid;
} XE_NP_NricSrReadbackResult;

typedef struct
{
    uint32_t tick_ms;
    uint32_t i2c_error_code;
    uint32_t i2c_isr;
    uint8_t trigger_reg;
    uint8_t test_count;
    uint8_t completed_count;
    uint8_t active;
    XE_NP_NricSrReadbackResult results[XE_NP_NRIC_SR_READBACK_TEST_COUNT];
} XE_NP_NricSrReadbackDiag;

typedef struct
{
    const uint8_t *chain1;
    uint16_t chain1_bytes;
    const uint8_t *chain2;
    uint16_t chain2_bytes;
    const uint8_t *chain3;
    uint16_t chain3_bytes;
    uint8_t sync_value;
    uint8_t op_mode_run;
    uint8_t cal_mod;
    uint8_t rec_mod_boot;
    uint8_t rec_mod_run;
} XE_NP_NricConfig;

extern volatile XE_NP_NricDiag xe_np_nric_diag;
extern volatile XE_NP_NricSrReadbackDiag xe_np_nric_sr_diag;

void XE_NP_Nric_GetDefaultBaseConfig(
    const uint8_t **chain2,
    uint16_t *chain2_bytes,
    const uint8_t **chain3,
    uint16_t *chain3_bytes);
void XE_NP_NricConfig_InitDefaults(XE_NP_NricConfig *config);
HAL_StatusTypeDef XE_NP_Nric_Ping(I2C_HandleTypeDef *hi2c);
HAL_StatusTypeDef XE_NP_Nric_ReadRegister(I2C_HandleTypeDef *hi2c, uint8_t reg_addr, uint8_t *value);
HAL_StatusTypeDef XE_NP_Nric_WriteRegister(I2C_HandleTypeDef *hi2c, uint8_t reg_addr, uint8_t value);
HAL_StatusTypeDef XE_NP_Nric_ProgramShiftRegister(
    I2C_HandleTypeDef *hi2c,
    uint8_t reg_addr,
    const uint8_t *chain_data,
    uint16_t chain_length,
    uint8_t *status_out);
HAL_StatusTypeDef XE_NP_Nric_ApplyConfiguration(
    I2C_HandleTypeDef *hi2c,
    const XE_NP_NricConfig *config,
    uint8_t *status_out);
HAL_StatusTypeDef XE_NP_Nric_ApplyBootConfiguration(
    I2C_HandleTypeDef *hi2c,
    uint8_t sync_value,
    uint8_t *status_out);

#endif

HAL_StatusTypeDef XE_NP_AutoConfigure(uint32_t port,I2C_HandleTypeDef *,XE_NP_NricConfig *,uint8_t *);
