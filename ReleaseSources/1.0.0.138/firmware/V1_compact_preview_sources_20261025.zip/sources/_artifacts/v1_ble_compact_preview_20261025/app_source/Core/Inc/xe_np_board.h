#ifndef XE_NP_BOARD_H
#define XE_NP_BOARD_H

#include <stddef.h>
#include <stdint.h>

/* The 24 MHz HSE is the sole production frequency reference. */
#define XE_NP_BOARD_HSE_ONLY_CLOCKS 1U

#define XE_NP_BOARD_NAME "USB384_NP_BGA_MMC"
#define XE_NP_FW_VERSION 0x0001U
#define XE_NP_HW_VERSION 0x0100U

#define XE_NP_NEUROPIXELS_MAX_PROBES 3U
#define XE_NP_NEUROPIXELS_CHANNELS_PER_PROBE 384U
#define XE_NP_NEUROPIXELS_SAMPLE_RATE_HZ 30000U
#define XE_NP_NEUROPIXELS_MCLK_HZ 93600000UL
#define XE_NP_NEUROPIXELS_MCLK_TOLERANCE_HZ 5000UL
#define XE_NP_NEUROPIXELS_PSB_CLK_FULL_HZ 23400000UL
#define XE_NP_NEUROPIXELS_PSB_CLK_HALF_HZ 11700000UL
#define XE_NP_NEUROPIXELS_PSB_CLK_HZ XE_NP_NEUROPIXELS_PSB_CLK_FULL_HZ
#define XE_NP_NEUROPIXELS_PSB_DATA_LINES 7U

/*
 * USB-only benchmark path: run SYSCLK/HCLK at the STM32U5 VOS1 limit of
 * 160 MHz. PA8/MCO is disabled in this mode because it cannot simultaneously
 * provide the 93.6 MHz Neuropixels MCLK from the same PLL1R system clock.
 */
#ifndef XE_NP_BOARD_USB_BENCH_160MHZ_CORE
#define XE_NP_BOARD_USB_BENCH_160MHZ_CORE 0U
#endif

/*
 * Experimental overclock path: keep SYSCLK/HCLK at 187.2 MHz from PLL1R while
 * prescaling MCO so the Neuropixels MCLK on PA8 remains 93.6 MHz.
 *
 * PLL1P is dedicated to the SDMMC kernel.  Keep it at 93.6 MHz, which is a
 * valid SDR104 clock point and lets the host use CLKDIV=0 without exceeding
 * the card's 104 MHz signalling limit.  PLL1R remains the independent
 * 187.2 MHz SYSCLK/MCO source. This remains outside the STM32U5 VOS1 160 MHz
 * datasheet limit.
 */
#ifndef XE_NP_BOARD_EXPERIMENTAL_1872MHZ_CORE
#define XE_NP_BOARD_EXPERIMENTAL_1872MHZ_CORE 1U
#endif

/* Exact 20 kS/s qualification: PLL1R/HCLK = 124.8 MHz and PA8/MCO /2 =
 * 62.4 MHz. This intentionally preserves the 8 HCLK cycles per 15.6 MHz PSB
 * edge used by the 30 kS/s profile while reducing aggregate request traffic. */
#ifndef XE_NP_BOARD_EXPERIMENTAL_1248MHZ_CORE
#define XE_NP_BOARD_EXPERIMENTAL_1248MHZ_CORE 0U
#endif

/* Extreme, SWD-recoverable 20 kS/s timing experiment: retain the 62.4 MHz
 * probe MCLK via MCO /4 but raise HCLK to 249.6 MHz, providing 16 HCLK cycles
 * per raw PSB edge. This is well outside the 160 MHz VOS1 data-sheet limit. */
#ifndef XE_NP_BOARD_EXPERIMENTAL_2496MHZ_CORE
#define XE_NP_BOARD_EXPERIMENTAL_2496MHZ_CORE 0U
#endif

/* SWD-only bracketing sweep. With the 24 MHz HSE and PLLM=5, PLL1R is
 * 2.4 MHz times this N value. MCO /4 keeps exactly 16 HCLK cycles per PSB
 * edge throughout the sweep. Zero leaves this profile disabled. */
#ifndef XE_NP_BOARD_EXPERIMENTAL_PLL1N_CORE
#define XE_NP_BOARD_EXPERIMENTAL_PLL1N_CORE 0U
#endif

#if ((XE_NP_BOARD_USB_BENCH_160MHZ_CORE + XE_NP_BOARD_EXPERIMENTAL_1872MHZ_CORE + \
      XE_NP_BOARD_EXPERIMENTAL_1248MHZ_CORE + XE_NP_BOARD_EXPERIMENTAL_2496MHZ_CORE + \
      ((XE_NP_BOARD_EXPERIMENTAL_PLL1N_CORE != 0U) ? 1U : 0U)) > 1U)
#error "Select only one core clock profile."
#endif

#if XE_NP_BOARD_USB_BENCH_160MHZ_CORE
#define XE_NP_BOARD_USB_BENCH_PLL1_N 80U
#define XE_NP_BOARD_PLL1_M 6U
#define XE_NP_BOARD_SYSCLK_HZ (2000000UL * XE_NP_BOARD_USB_BENCH_PLL1_N)
#define XE_NP_BOARD_HCLK_HZ XE_NP_BOARD_SYSCLK_HZ
#define XE_NP_BOARD_PLL1_N XE_NP_BOARD_USB_BENCH_PLL1_N
#define XE_NP_BOARD_PLL1_FRACN 0U
#define XE_NP_BOARD_PLL1P_DIV 6U
#define XE_NP_BOARD_PLL1Q_DIV 2U
#define XE_NP_BOARD_PLL1R_DIV 2U
#define XE_NP_BOARD_MCO_DISABLED 1U
#define XE_NP_BOARD_MCO_DIVIDER 1U
#define XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ XE_NP_NEUROPIXELS_PSB_CLK_FULL_HZ
#define XE_NP_BOARD_EXPECTED_PSB_CLK_HALF_HZ XE_NP_NEUROPIXELS_PSB_CLK_HALF_HZ
#if (XE_NP_BOARD_USB_BENCH_PLL1_N > 80U)
#define XE_NP_BOARD_APB_CLK_DIVIDER 2U
#else
#define XE_NP_BOARD_APB_CLK_DIVIDER 1U
#endif
#define XE_NP_BOARD_EXPECTED_MCO_HZ 0UL
#elif XE_NP_BOARD_EXPERIMENTAL_1248MHZ_CORE
#define XE_NP_BOARD_SYSCLK_HZ 124800000UL
#define XE_NP_BOARD_HCLK_HZ 124800000UL
#define XE_NP_BOARD_PLL1_M 5U
#define XE_NP_BOARD_PLL1_N 52U
#define XE_NP_BOARD_PLL1_FRACN 0U
#define XE_NP_BOARD_PLL1P_DIV 4U
#define XE_NP_BOARD_PLL1Q_DIV 2U
#define XE_NP_BOARD_PLL1R_DIV 2U
#define XE_NP_BOARD_MCO_DISABLED 0U
#define XE_NP_BOARD_MCO_DIVIDER 2U
#define XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ 15600000UL
#define XE_NP_BOARD_EXPECTED_PSB_CLK_HALF_HZ 7800000UL
#define XE_NP_BOARD_APB_CLK_DIVIDER 2U
#define XE_NP_BOARD_EXPECTED_MCO_HZ 62400000UL
#elif XE_NP_BOARD_EXPERIMENTAL_2496MHZ_CORE
#define XE_NP_BOARD_SYSCLK_HZ 249600000UL
#define XE_NP_BOARD_HCLK_HZ 249600000UL
#define XE_NP_BOARD_PLL1_M 5U
#define XE_NP_BOARD_PLL1_N 104U
#define XE_NP_BOARD_PLL1_FRACN 0U
#define XE_NP_BOARD_PLL1P_DIV 4U
#define XE_NP_BOARD_PLL1Q_DIV 2U
#define XE_NP_BOARD_PLL1R_DIV 2U
#define XE_NP_BOARD_MCO_DISABLED 0U
#define XE_NP_BOARD_MCO_DIVIDER 4U
#define XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ 15600000UL
#define XE_NP_BOARD_EXPECTED_PSB_CLK_HALF_HZ 7800000UL
#define XE_NP_BOARD_APB_CLK_DIVIDER 2U
#define XE_NP_BOARD_EXPECTED_MCO_HZ 62400000UL
#elif (XE_NP_BOARD_EXPERIMENTAL_PLL1N_CORE != 0U)
#define XE_NP_BOARD_SYSCLK_HZ (2400000UL * XE_NP_BOARD_EXPERIMENTAL_PLL1N_CORE)
#define XE_NP_BOARD_HCLK_HZ XE_NP_BOARD_SYSCLK_HZ
#define XE_NP_BOARD_PLL1_M 5U
#define XE_NP_BOARD_PLL1_N XE_NP_BOARD_EXPERIMENTAL_PLL1N_CORE
#define XE_NP_BOARD_PLL1_FRACN 0U
#define XE_NP_BOARD_PLL1P_DIV 4U
#define XE_NP_BOARD_PLL1Q_DIV 2U
#define XE_NP_BOARD_PLL1R_DIV 2U
#define XE_NP_BOARD_MCO_DISABLED 0U
#define XE_NP_BOARD_MCO_DIVIDER 4U
#define XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ (XE_NP_BOARD_SYSCLK_HZ / 16UL)
#define XE_NP_BOARD_EXPECTED_PSB_CLK_HALF_HZ (XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ / 2UL)
#define XE_NP_BOARD_APB_CLK_DIVIDER 2U
#define XE_NP_BOARD_EXPECTED_MCO_HZ (XE_NP_BOARD_SYSCLK_HZ / 4UL)
#elif XE_NP_BOARD_EXPERIMENTAL_1872MHZ_CORE
#define XE_NP_BOARD_SYSCLK_HZ 187200000UL
#define XE_NP_BOARD_HCLK_HZ 187200000UL
#define XE_NP_BOARD_PLL1_M 5U
#define XE_NP_BOARD_PLL1_N 78U
#define XE_NP_BOARD_PLL1_FRACN 0U
#define XE_NP_BOARD_PLL1P_DIV 4U
#define XE_NP_BOARD_PLL1Q_DIV 2U
#define XE_NP_BOARD_PLL1R_DIV 2U
#define XE_NP_BOARD_MCO_DISABLED 0U
#define XE_NP_BOARD_MCO_DIVIDER 2U
#define XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ XE_NP_NEUROPIXELS_PSB_CLK_FULL_HZ
#define XE_NP_BOARD_EXPECTED_PSB_CLK_HALF_HZ XE_NP_NEUROPIXELS_PSB_CLK_HALF_HZ
#define XE_NP_BOARD_APB_CLK_DIVIDER 2U
#define XE_NP_BOARD_EXPECTED_MCO_HZ XE_NP_NEUROPIXELS_MCLK_HZ
#else
#define XE_NP_BOARD_PLL1_M 6U
#define XE_NP_BOARD_SYSCLK_HZ 93600000UL
#define XE_NP_BOARD_HCLK_HZ 93600000UL
#define XE_NP_BOARD_PLL1_N 93U
#define XE_NP_BOARD_PLL1_FRACN 4915U
#define XE_NP_BOARD_PLL1P_DIV 4U
#define XE_NP_BOARD_PLL1Q_DIV 2U
#define XE_NP_BOARD_PLL1R_DIV 4U
#define XE_NP_BOARD_MCO_DISABLED 0U
#define XE_NP_BOARD_MCO_DIVIDER 1U
#define XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ XE_NP_NEUROPIXELS_PSB_CLK_FULL_HZ
#define XE_NP_BOARD_EXPECTED_PSB_CLK_HALF_HZ XE_NP_NEUROPIXELS_PSB_CLK_HALF_HZ
#define XE_NP_BOARD_APB_CLK_DIVIDER 1U
#define XE_NP_BOARD_EXPECTED_MCO_HZ XE_NP_NEUROPIXELS_MCLK_HZ
#endif

#ifndef XE_NP_BOARD_EXPERIMENT_MCO_DIVIDER
/*
 * Production NP1 recording profile: PLL1R remains 187.2 MHz, while PA8/MCO
 * is divided by eight to supply a 23.4 MHz probe MCLK.  With the NP1 4:1 PSB
 * relationship and 13 PSB frames per AP row, this is 7,500 AP rows/s. Keep
 * the conservative direct-DMA fallback as the boot profile; 15 kHz is only
 * selected by a qualified dedicated-capture build.
 */
#define XE_NP_BOARD_EXPERIMENT_MCO_DIVIDER 8U
#endif

#ifndef XE_NP_BOARD_EXPERIMENT_EXPECTED_MCO_HZ
#define XE_NP_BOARD_EXPERIMENT_EXPECTED_MCO_HZ 23400000UL
#endif

#if (XE_NP_BOARD_EXPERIMENT_EXPECTED_MCO_HZ != 0UL)
#define XE_NP_BOARD_EFFECTIVE_MCO_DIVIDER XE_NP_BOARD_EXPERIMENT_MCO_DIVIDER
#define XE_NP_BOARD_EFFECTIVE_EXPECTED_MCO_HZ XE_NP_BOARD_EXPERIMENT_EXPECTED_MCO_HZ
#define XE_NP_BOARD_EFFECTIVE_EXPECTED_PSB_CLK_FULL_HZ (XE_NP_BOARD_EFFECTIVE_EXPECTED_MCO_HZ / 4UL)
#define XE_NP_BOARD_EFFECTIVE_EXPECTED_PSB_CLK_HALF_HZ (XE_NP_BOARD_EFFECTIVE_EXPECTED_PSB_CLK_FULL_HZ / 2UL)
#else
#define XE_NP_BOARD_EFFECTIVE_MCO_DIVIDER XE_NP_BOARD_MCO_DIVIDER
#define XE_NP_BOARD_EFFECTIVE_EXPECTED_MCO_HZ XE_NP_BOARD_EXPECTED_MCO_HZ
#define XE_NP_BOARD_EFFECTIVE_EXPECTED_PSB_CLK_FULL_HZ XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ
#define XE_NP_BOARD_EFFECTIVE_EXPECTED_PSB_CLK_HALF_HZ XE_NP_BOARD_EXPECTED_PSB_CLK_HALF_HZ
#endif

/*
 * USB OTG HS internal DMA is experimental. Earlier real NP stream tests stalled
 * with PCD tx_busy stuck; keep disabled unless explicitly benchmarking.
 */
#ifndef XE_NP_BOARD_USB_OTG_HS_INTERNAL_DMA
#define XE_NP_BOARD_USB_OTG_HS_INTERNAL_DMA 0U
#endif

/* Diagnostic/recording option: make OTG-HS IDMA yield the system bus after
 * each SRAM1 beat instead of its default INCR4 burst. */
#ifndef XE_NP_BOARD_USB_OTG_HS_IDMA_SINGLE_BURST
#define XE_NP_BOARD_USB_OTG_HS_IDMA_SINGLE_BURST 0U
#endif

/* Bulk endpoint completion must preempt capture bookkeeping.  GPIO requests
 * remain GPDMA-high-priority; their IRQ only accounts completed blocks. */
#ifndef XE_NP_BOARD_USB_OTG_HS_IRQ_PREEMPT_PRIO
#define XE_NP_BOARD_USB_OTG_HS_IRQ_PREEMPT_PRIO 1U
#endif

/*
 * Clock/USB isolation mode: keep the NP MCLK clock tree active but pause
 * automatic NP bring-up, capture, and storage servicing. Use only while
 * characterizing USB throughput with the synthetic source.
 */
#define XE_NP_BOARD_USB_SYNTHETIC_CLOCK_BENCH_ISOLATION 0U

/*
 * Temporary storage characterization image. This runs a raw SD write benchmark
 * at boot and reclaims some NP capture SRAM for a larger SDMMC IDMA buffer.
 * Disable before returning to normal NP USB streaming firmware.
 */
#ifndef XE_NP_BOARD_SD_WRITE_BENCH_IMAGE
#define XE_NP_BOARD_SD_WRITE_BENCH_IMAGE 0U
#endif

/*
 * Clock-isolation experiment: skip SD host initialization and keep the app's
 * runtime SD handle unbound so the USB/NP path can be validated without any
 * SD/UHS/DLYB side effects.
 */
#ifndef XE_NP_BOARD_EXPERIMENT_DISABLE_SD_INIT
#define XE_NP_BOARD_EXPERIMENT_DISABLE_SD_INIT 1U
#endif

/* SD benchmark diagnostic markers visible from SWD parser tooling */
#define XE_NP_SD_BENCH_DIAG_DISABLED 0x64697361U
#define XE_NP_SD_BENCH_STATUS_MAIN_ENTRY 9U
#define XE_NP_SD_BENCH_STATUS_NOT_RUN 0U
#define XE_NP_SD_BENCH_STATUS_RUNNING 1U
#define XE_NP_SD_BENCH_STATUS_OK 2U
#define XE_NP_SD_BENCH_STATUS_SKIPPED 3U
#define XE_NP_SD_BENCH_STATUS_HAL_START_FAIL 4U
#define XE_NP_SD_BENCH_STATUS_TIMEOUT 5U
#define XE_NP_SD_BENCH_STATUS_CARD_ERROR 6U
#define XE_NP_SD_BENCH_STATUS_LL_BUILD_FAIL 7U
#define XE_NP_SD_BENCH_STATUS_DISABLED 8U
#define XE_NP_SD_BENCH_STATUS_PRE_MAIN 10U
#define XE_NP_SD_BENCH_STATUS_UNEXPECTED 11U
#define XE_NP_SD_BENCH_STATUS_DISPATCHED 12U
#define XE_NP_SD_BENCH_STATUS_ZERO 13U
#define XE_NP_SD_BENCH_STATUS_INTEGRITY_FAIL 14U

#define XE_NP_MISC_SAMPLE_RATE_HZ 1250U
#define XE_NP_PREVIEW_SAMPLE_RATE_HZ 625U
#define XE_NP_CAMERA_FRAME_RATE_HZ 16U
#define XE_NP_ADC_SAMPLE_RATE_HZ 160000U
#define XE_NP_STREAM_TYPE_COUNT 6U

typedef struct
{
    const char *signal;
    const char *mcu_pin;
} XE_NP_PinMapEntry;

typedef struct
{
    uint32_t mclk_hz;
    uint32_t psb_clk_hz;
    uint32_t sample_rate_hz;
    uint8_t psb_data_lines;
} XE_NP_NeuropixelsClockPlan;

typedef struct
{
    uint32_t negotiated_speed_mode;
    uint32_t card_speed;
    uint32_t card_speed_raw;
    uint32_t card_type;
    uint32_t last_speed_mode_attempt;
    uint32_t last_speed_mode_error;
    uint32_t last_speed_mode_card_state;
    uint8_t init_failed;
    uint8_t signal_1v8_enabled;
    uint8_t signal_1v8_seen;
    uint8_t last_speed_mode_status;
    uint32_t last_speed_mode_clock_div;
    uint32_t last_speed_mode_clock_edge;
    uint32_t last_speed_mode_selclkrx;
    uint32_t last_speed_mode_sdmmc_clock_source;
    uint32_t last_speed_mode_iclk_clock_source;
    uint32_t last_speed_mode_sdmmc_kernel_hz;
    uint32_t last_speed_mode_sdmmc_bus_hz;
    uint32_t last_speed_mode_sdmmc_target_bus_hz;
} XE_NP_BoardSdDiag;

typedef struct
{
    uint32_t magic;
    uint32_t version;
    uint32_t status;
    uint32_t speed_mode;
    uint32_t sdmmc_kernel_hz;
    uint32_t clock_div;
    uint32_t card_speed;
    uint32_t card_type;
    uint32_t start_block;
    uint32_t total_blocks;
    uint32_t chunk_blocks;
    uint32_t blocks_written;
    uint32_t elapsed_ms;
    uint32_t bytes_per_sec;
    uint32_t worst_chunk_us;
    uint32_t last_chunk_us;
    uint32_t error_code;
    uint32_t card_state;
    uint32_t hal_state;
    uint32_t hal_context;
    uint32_t sdmmc_sta;
    uint32_t sdmmc_dctrl;
    uint32_t fail_block;
    uint32_t fail_status;
    uint32_t signal_1v8_enabled;
    uint32_t signal_1v8_seen;
    uint32_t method;
    uint32_t ll_node_blocks;
    uint32_t ll_node_bytes;
    uint32_t ll_node_count;
    uint32_t ll_node_irq_count;
    uint32_t ll_build_status;
    uint32_t ll_cmd23_error;
    uint32_t sdmmc_idmabsize;
    uint32_t sdmmc_idmabar;
    uint32_t sdmmc_idmalar;
    uint32_t sdmmc_idmactrl;
    uint32_t ll_acmd23_error;
    uint32_t prep_flags;
    uint32_t cmd20_error;
    uint32_t sd_status_speed_class;
    uint32_t sd_status_perf_move;
    uint32_t sd_status_au_size;
    uint32_t sd_status_erase_size;
    uint32_t sd_status_uhs_grade;
    uint32_t sd_status_uhs_au_size;
    uint32_t sd_status_video_class;
    uint64_t bytes_written;
    uint32_t sdmmc_bus_hz;
    uint32_t sdmmc_clkcr;
    uint32_t dlyb_cr;
    uint32_t dlyb_cfgr;
    uint32_t gpio_hslv_enabled;
    uint32_t gpio_c_hslvr;
    uint32_t gpio_d_hslvr;
    uint32_t gpio_b_hslvr;
    uint32_t range_erase_ms;
    uint32_t ll_build_ms;
    uint32_t cmd20_ms;
    uint32_t chunk_count;
    uint32_t last_setup_ms;
    uint32_t worst_setup_ms;
    uint32_t total_setup_ms;
    uint32_t last_transfer_ms;
    uint32_t worst_transfer_ms;
    uint32_t total_transfer_ms;
    uint32_t last_busy_ms;
    uint32_t worst_busy_ms;
    uint32_t total_busy_ms;
    uint32_t dataend_count;
    uint32_t cmd13_poll_count;
    uint32_t wait_loop_count;
    uint32_t dlyb_tune_status;
    uint32_t dlyb_tune_units;
    uint32_t dlyb_tune_period_phase;
    uint32_t dlyb_tune_pass_mask;
    uint32_t dlyb_tune_selected_phase;
    uint32_t last_speed_mode_clock_div;
    uint32_t last_speed_mode_clock_edge;
    uint32_t last_speed_mode_selclkrx;
    uint32_t last_speed_mode_sdmmc_clock_source;
    uint32_t last_speed_mode_iclk_clock_source;
    uint32_t last_speed_mode_sdmmc_kernel_hz;
    uint32_t last_speed_mode_sdmmc_bus_hz;
    uint32_t last_speed_mode_sdmmc_target_bus_hz;
    uint32_t retarget_test_enabled;
    uint32_t retarget_rearm_count;
    uint32_t retarget_verified_segments;
    uint32_t retarget_verify_fail;
} XE_NP_BoardSdBenchDiag;

const XE_NP_NeuropixelsClockPlan *XE_NP_GetNeuropixelsClockPlan(void);
const XE_NP_PinMapEntry *XE_NP_GetPinMap(size_t *count);
uint32_t XE_NP_Board_GetRuntimeMcoDivider(void);
uint32_t XE_NP_Board_GetRuntimeExpectedMcoHz(void);
uint32_t XE_NP_Board_GetRuntimeExpectedPsbClkHz(void);
uint32_t XE_NP_Board_GetRuntimeExpectedPsbClkHalfHz(void);
uint32_t XE_NP_Board_GetRuntimeMcoApplyCount(void);
uint32_t XE_NP_Board_GetRuntimeMcoLastApplyStatus(void);
int XE_NP_Board_SetRuntimeMcoDivider(uint32_t divider);
int XE_NP_Board_SdUhsReadyForNpRaw(void);
uint32_t XE_NP_Board_SdNegotiatedSpeedMode(void);
uint32_t XE_NP_Board_SdEstimatedWriteBudgetBytesPerSec(void);
const volatile XE_NP_BoardSdDiag *XE_NP_Board_SdDiag(void);
const volatile XE_NP_BoardSdBenchDiag *XE_NP_Board_SdBenchDiag(void);
void XE_NP_Board_EnsureSdPowerRail(void);

#endif


