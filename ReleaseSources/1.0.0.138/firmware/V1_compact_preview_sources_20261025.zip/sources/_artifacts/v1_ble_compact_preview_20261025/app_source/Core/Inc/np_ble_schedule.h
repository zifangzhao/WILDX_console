#ifndef NP_BLE_SCHEDULE_H
#define NP_BLE_SCHEDULE_H
#include "xe_np_online_impl.h"
typedef struct {
    uint64_t utc;
    uint32_t tick,active,waiting,before,after,valid;
    XE_NP_OnlineClock clock;
} NpBleSchedule;
/* A future start may wait, but a missed schedule must not suppress the normal
 * startup watchdog forever. Signed subtraction preserves tick wraparound. */
static inline int np_ble_start_expired(const NpBleSchedule *s,uint32_t now,uint32_t start)
{
    /* A gate may rebase start after the caller sampled now. That small
     * negative age is not an elapsed 49-day timeout. All real deadlines here
     * are well within the signed half-range of the millisecond counter. */
    return s->active ? (int32_t)(now-s->tick)>5 : (int32_t)(now-start)>5000;
}
static inline int np_ble_schedule_arm(NpBleSchedule *s,const XE_NP_OnlineClock *c,
    uint64_t utc,uint32_t now)
{
    uint64_t current=XE_NP_Online_Utc(c,now);
    if(!current || utc<current+60000000ULL || utc>current+86400000000ULL)return 0;
    memset(s,0,sizeof(*s));s->clock=*c;s->utc=utc;
    s->tick=now+(uint32_t)((utc-current+999U)/1000U);s->active=1;return 1;
}
/* Called after probe configuration, before starting the unchanged DMA/timer
 * sequence. Millisecond best effort, NOT a synchronized sample clock. */
static inline int np_ble_schedule_gate(NpBleSchedule *s,uint32_t now)
{
    if(!s->active)return 1;
    int32_t remaining=(int32_t)(s->tick-now);
    if(remaining>0){s->waiting=1;return 0;}
    s->waiting=0;s->active=0;
    if(remaining < -5)return -1;
    s->before=now;s->valid=1;return 1;
}
#endif
