#ifndef NP_CONFIG_H
#define NP_CONFIG_H
#include <stdint.h>
#include <stddef.h>
#define NPC_FRAME 64U
#define NPC_BYTES 1576U
#define NPC_CHUNK 32U
#define NPC_TIMEOUT_MS 10000U
enum {NPC_STATUS=0,NPC_BEGIN=1,NPC_WRITE=2,NPC_COMMIT=3,NPC_ABORT=4};
enum {NPC_OK=0,NPC_BAD_FRAME=1,NPC_BUSY=2,NPC_OWNER=3,NPC_RANGE=4,
 NPC_ORDER=5,NPC_CRC=6,NPC_INVALID=7,NPC_UNSUPPORTED=8,NPC_APPLY_FAILED=9,NPC_EXPIRED=10};
enum {NPC_NONE=0,NPC_RECEIVING=1,NPC_STAGED=2,NPC_APPLIED=3,NPC_FAILED=4};
enum {NPC_USB=1,NPC_BLE=2};
typedef struct {
 void *context;
 int (*busy)(void *);
 /* Validation MUST NOT write hardware. Commit adopts for next bring-up. */
 int (*validate)(void *,const uint8_t *,uint32_t);
 int (*adopt)(void *,const uint8_t *,uint32_t);
} NpcIo;
typedef struct {
 NpcIo io;
 uint32_t owner,transaction,total,received,expected_crc,last_ms,state,error;
 uint32_t port,last_commit_owner,last_commit_id,last_commit_crc,last_commit_port;
 uint32_t port_state[3],port_crc[3],verification[3];
 uint8_t pending[NPC_BYTES],active[3][NPC_BYTES];
 uint8_t valid[3];
} NpcState;
uint32_t npc_crc(const uint8_t *,uint32_t);
uint32_t npc_u32(const uint8_t *);
void npc_put32(uint8_t *,uint32_t);
void npc_init(NpcState *,NpcIo);
void npc_command(NpcState *,uint32_t,const uint8_t[NPC_FRAME],uint32_t,uint8_t[NPC_FRAME]);
void npc_expire(NpcState *,uint32_t);
void npc_disconnected(NpcState *,uint32_t);
int npc_validate_selection(const uint8_t *,uint32_t);
void npc_applied(NpcState *,uint8_t,int,uint32_t);
#endif
