#ifndef NP_SD_DMA_CHAIN_H
#define NP_SD_DMA_CHAIN_H
#include <stdint.h>
#include <string.h>
/* STM32U5 static linear DMA_NodeTypeDef: eight link words plus NodeInfo.
 * HAL BuildNode updates configuration but preserves an existing next link.
 * Reset ALL storage when reconstructing a shorter queue, not just its head. */
static inline void np_sd_chain_reset(void *nodes)
{ memset(nodes,0,8U*9U*sizeof(uint32_t)); }
static inline int np_sd_chain_valid(const void *storage,unsigned count,uint32_t address)
{
    const uint32_t (*nodes)[9]=(const uint32_t (*)[9])storage;
    if(!count || count>8 || (address&3U) ||
       (address>>16)!=((address+count*36U-1U)>>16))return 0;
    for(unsigned n=0;n<count;n++) {
        uint32_t expected=n+1U<count?0xf8010000U|((address+(n+1U)*36U)&0xfffcU):0U;
        if(nodes[n][5]!=expected)return 0;
    }
    return 1;
}
#endif
