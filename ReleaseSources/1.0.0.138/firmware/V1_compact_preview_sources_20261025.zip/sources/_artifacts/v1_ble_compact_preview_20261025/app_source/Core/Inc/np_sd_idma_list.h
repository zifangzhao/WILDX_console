#ifndef NP_SD_IDMA_LIST_H
#define NP_SD_IDMA_LIST_H

/* V1's finite 64 KiB ownership units use the same three-word SDMMC nodes
 * as the V2 writer. Called only between commands, after IDMA is quiescent.
 * ABR stays clear until the existing address-before-enable publication. */
_Static_assert(sizeof(SDMMC_DMALinkNodeTypeDef)==12U,
               "SDMMC node must contain exactly three hardware words");
_Static_assert(127U*sizeof(SDMMC_DMALinkNodeTypeDef)<=SDMMC_IDMALAR_IDMALA,
               "128-node SD list must fit the hardware relative-link field");

static int np_sd_idma_list_prepare(SDMMC_DMALinkNodeTypeDef *nodes,
                                  SDMMC_DMALinkedListTypeDef *list,
                                  unsigned chunks)
{
    if(!chunks || chunks>128U)return -1;
    for(unsigned n=0U;n<chunks;n++) {
        nodes[n].IDMABASER=0U;
        nodes[n].IDMABSIZE=65536U;
        nodes[n].IDMALAR=SDMMC_IDMALAR_ULS;
        if(n+1U<chunks)
            nodes[n].IDMALAR|=SDMMC_IDMALAR_ULA|
                ((n+1U)*(uint32_t)sizeof(nodes[0]));
    }
    list->pHeadNode=nodes;
    list->pTailNode=&nodes[chunks-1U];
    list->NodesCounter=chunks;
    return 0;
}

#endif
