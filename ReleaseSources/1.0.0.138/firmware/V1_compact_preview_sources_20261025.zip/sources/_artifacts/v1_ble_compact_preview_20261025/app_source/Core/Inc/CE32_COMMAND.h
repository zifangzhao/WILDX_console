#ifndef XE_NP_CE32_COMMAND_H
#define XE_NP_CE32_COMMAND_H

#include "CE32_Sync.h"

#define CMD_SEQ 12U
#define CMD_MAXSIZE 512U
#define CMD_BUFSIZE (CMD_MAXSIZE * CMD_SEQ)

typedef struct
{
    __IO uint8_t *addr;
    __IO uint32_t idx;
    __IO uint32_t len;
    __IO uint8_t logging;
} CE32_MEMORY_PTR;

typedef struct
{
    __IO uint16_t state;
    __IO uint8_t buffer[CMD_BUFSIZE];
    __IO uint8_t *cmd_buf[CMD_SEQ];
    __IO uint16_t cmd_pad[CMD_SEQ];
    __IO uint32_t cmd_len[CMD_SEQ];
    __IO uint16_t free_buffer;
    __IO uint16_t buffer_boundary_correction;
    CE32_SyncTypeDef cmd_time[CMD_SEQ];
    CE32_MEMORY_PTR stream_in;
    CE32_MEMORY_PTR stream_out;
    __IO uint32_t cmd_idx_in;
    __IO uint32_t cmd_ptr_in;
    __IO uint32_t cmd_idx_out;
    __IO uint32_t cmd_pending;
    uint32_t IN_OK;
    uint32_t IN_Fail;
} CE32_command;

void CE32_COMMAND_SetRtcHandle(RTC_HandleTypeDef *hrtc);
int CE32_COMMAND_Init(CE32_command *handle);
int CE32_COMMAND_EnqueueCmd(CE32_command *handle, unsigned char *data, int cmd_len);
int CE32_COMMAND_EnqueueCmd_MEMCopy(CE32_command *handle, unsigned char *data, int cmd_len);
int CE32_COMMAND_Enqueue_Allocate(CE32_command *handle, int cmd_len, uint8_t **ptr);
int CE32_COMMAND_Enqueue_Byte(CE32_command *handle, unsigned char data);
int CE32_COMMAND_Enqueue_BytesLeft(CE32_command *handle);
int CE32_COMMAND_Enqueue_Byte_Abort(CE32_command *handle);
int CE32_COMMAND_Enqueue_RescanBuffer(CE32_command *handle);
int CE32_COMMAND_EnqueueCmd_buffered(CE32_command *handle);
int CE32_COMMAND_DequeueCmd(CE32_command *handle, uint8_t **data_ptr, uint32_t *cmd_len);
int CE32_COMMAND_DequeueCmdwTime(CE32_command *handle, uint8_t **data_ptr, uint32_t *cmd_len, CE32_SyncTypeDef *time);
int CE32_COMMAND_Dequeue_Byte(CE32_command *handle, uint8_t *data);
int CE32_COMMAND_Dequeue_BytesLeft(CE32_command *handle);
int CE32_COMMAND_Dequeue_Byte_Abort(CE32_command *handle);
int CE32_COMMAND_GetPendingCounts(CE32_command *handle);
int CE32_COMMAND_GetCmdPointer(CE32_command *handle, uint8_t **data_ptr, uint32_t *cmd_len);
int CE32_COMMAND_DiscardAll(CE32_command *handle);

#define CMD_ADD_CHK(a, b, boundary) ((((a) + (b)) < (boundary)) ? ((a) + (b)) : ((a) + (b) - (boundary)))

#endif
