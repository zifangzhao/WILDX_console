#ifndef NP_SD_VSC_DIR_H
#define NP_SD_VSC_DIR_H
#include <stdint.h>
#include <string.h>
/* SDA Physical Layer 9.10, 4.13.4.7.3 / .8. These are slot IDs, not masks
 * in CMD20's CNT/ID field. LBA is bound by the NEXT single-block write. */
typedef struct {
    uint32_t lba[8],count,owned,registered,pending;
} NpSdVscDirs;
typedef int (*NpVscCommand)(uint32_t);
typedef int (*NpVscSectorIo)(uint32_t,uint8_t *);
static inline int np_vdir_plan(NpSdVscDirs *d,const uint32_t *lba,uint32_t count,
                              uint32_t data_start,uint32_t data_end,uint32_t capacity)
{
    if(d->owned || !count || count>8 || data_start>=data_end || data_end>capacity)return -1;
    for(uint32_t i=0;i<count;i++) {
        if(lba[i]>=capacity || (lba[i]>=data_start&&lba[i]<data_end))return -1;
        for(uint32_t j=0;j<i;j++)if(lba[j]==lba[i])return -1;
    }
    memset(d,0,sizeof(*d));d->count=count;d->pending=8;
    memcpy(d->lba,lba,count*sizeof(uint32_t));return 0;
}
static inline int np_vdir_contains(const NpSdVscDirs *d,uint32_t lba)
{
    for(uint32_t i=0;i<d->count;i++)if(d->lba[i]==lba)return 1;
    return 0;
}
static inline int np_vdir_release(NpSdVscDirs *d,NpVscCommand command)
{
    int error=0;
    for(uint32_t i=0;i<d->count;i++)if(d->owned&(1U<<i)) {
        if(command(0x88000000U|(i<<24)))error=-1;
        else {d->owned&=~(1U<<i);d->registered&=~(1U<<i);}
    }
    d->pending=8;return error;
}
static inline int np_vdir_register(NpSdVscDirs *d,uint8_t *scratch,
                                  NpVscCommand command,NpVscSectorIo read,NpVscSectorIo write)
{
    if(d->owned || !d->count || d->count>8)return -1;
    /* Clear these dedicated slots even after an MCU-only reset. Do not assume
     * resetting the host power-cycled the card's directory registrations. */
    for(uint32_t i=0;i<d->count;i++)if(command(0x88000000U|(i<<24)))return -1;
    for(uint32_t i=0;i<d->count;i++) {
        if(read(d->lba[i],scratch))return -1;
        d->pending=i;d->owned|=1U<<i; /* uncertain command completion also needs cleanup */
        if(command(0x18000000U|(i<<24)) || write(d->lba[i],scratch))return -1;
        d->registered|=1U<<i;d->pending=8;
    }
    return 0;
}
static inline int np_vdir_write_allowed(const NpSdVscDirs *d,uint32_t lba,int capture_active,int transfer_active)
{
    if(capture_active || transfer_active)return 0;
    if(!d->owned)return 1; /* ordinary idle metadata, before registration/after release */
    for(uint32_t i=0;i<d->count;i++)if(d->lba[i]==lba)
        return (d->registered&(1U<<i)) || d->pending==i;
    return 0;
}
#endif
