#ifndef NP_BLE_DFU_H
#define NP_BLE_DFU_H
int NP_BleDfuAvailable(void);
void NP_BleEarlyDfu(void);
void NP_BleEnterDfu(void);
#endif
