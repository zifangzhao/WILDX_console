#ifndef NP_BLE_STORAGE_H
#define NP_BLE_STORAGE_H
#include "np_ce64.h"
/* Explicit idle-only recovery of a fully saved V1 final footer. Never scan or
 * repair neural bytes, infer a missing end, or reclaim an incomplete extent. */
static inline int np_ble_recover_end(NpCe64Directory *directory,uint32_t capacity,
    NpCe64Read read,NpCe64Write write)
{
    NpCe64Directory d=*directory;uint8_t h[512],f[512];uint32_t previous;
    if(d.active || (!d.index && !d.block))return -1;
    if(!d.index){
        --d.block;
        if(read(NP_CE64_LOG+d.block,(uint8_t *)&d.log) || d.log.count!=63U)return -1;
        d.index=63U;
    }
    unsigned entry=d.index-1U;
    if(entry)previous=d.log.end[entry-1U];
    else if(!d.block)previous=NP_CE64_DATA;
    else{
        NpCe64SysLog older;
        if(read(NP_CE64_LOG+d.block-1U,(uint8_t *)&older)||older.count!=63U)return -1;
        previous=older.end[62];
    }
    if(previous>UINT32_MAX-8191U)return -1;
    uint32_t start=(previous+8191U)&~8191U,reserved=d.log.end[entry];
    if(start<NP_CE64_DATA || reserved<=start || reserved>capacity || reserved-start<6U ||
       d.log.event_end[entry]!=reserved || read(start+3U,h) || read(start+4U,f))return -1;
    if(memcmp(h,"NPSDLOG1",8)||memcmp(f,"NPSDEND1",8)||np_get32(h+8)!=6U||np_get32(f+8)!=6U||
       np_get32(h+508)!=np_crc32(h,508)||np_get32(f+508)!=np_crc32(f,508)||
       !np_get32(h+12)||memcmp(h+12,f+12,40)||np_get32(h+40)!=start||
       np_get32(h+36)!=128U||np_get32(h+80)!=2U||np_get32(f+80)!=2U||
       np_get32(h+96)!=61632U||np_get32(f+96)!=61632U||
       np_get32(f+60)!=NP_SD_COMPLETE||np_get32(f+64))return -1;
    uint32_t header=8192U+((0U-(start+8192U))&16383U),chunks=np_get32(f+68);
    uint64_t end=(uint64_t)start+header+(uint64_t)chunks*128U;
    if(np_get32(h+48)!=header || !chunks || chunks%8U || end>reserved ||
       end>np_get32(h+44) || np_get32(h+44)>capacity)return -1;
    if(end==reserved)return 0;
    d.log.end[entry]=d.log.event_end[entry]=(uint32_t)end;
    if(np_ce64_publish(&d,write))return -1; /* existing write-ahead journal */
    return np_ce64_mount(directory,capacity,read,write);
}
#endif
