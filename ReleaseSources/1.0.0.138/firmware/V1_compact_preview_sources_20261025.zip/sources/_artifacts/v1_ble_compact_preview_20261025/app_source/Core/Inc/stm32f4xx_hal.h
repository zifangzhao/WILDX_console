#ifndef XE_NP_STM32F4XX_HAL_COMPAT_H
#define XE_NP_STM32F4XX_HAL_COMPAT_H

#include "xe_np_hal.h"

#endif
