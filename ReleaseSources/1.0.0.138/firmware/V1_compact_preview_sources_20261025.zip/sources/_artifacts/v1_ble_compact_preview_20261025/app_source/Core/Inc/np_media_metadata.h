#ifndef NP_MEDIA_METADATA_H
#define NP_MEDIA_METADATA_H
#include <stdint.h>
#include <string.h>

#define NP_MEDIA_METADATA_OFFSET 128U
#define NP_MEDIA_METADATA_END 296U
#define NP_MEDIA_METADATA_VERSION 1U
#define NP_MEDIA_META_START_CLOCK_VALID (1U << 0)
#define NP_MEDIA_META_STOP_CLOCK_VALID (1U << 1)
#define NP_MEDIA_META_FOOTER (1U << 2)
#define NP_MEDIA_META_CAMERA_REQUESTED (1U << 3)
#define NP_MEDIA_META_MIC_REQUESTED (1U << 4)

/* Device ticks are raw uint32 milliseconds (including wrap); UTC anchors and
 * uncertainty are microseconds. Counts are acquisition evidence, not a claim
 * of qualification. The caller owns validity flags, snapshots and sector CRC. */
typedef struct {
    uint32_t flags, start_tick, stop_tick;
    uint32_t start_clock_tick, start_clock_generation;
    uint64_t start_clock_utc_us;
    uint32_t camera_hz, camera_source_completed, camera_saved;
    uint32_t camera_first_id, camera_last_id, camera_first_tick, camera_last_tick;
    uint32_t camera_fault, camera_cadence_misses, camera_baseline_misses;
    uint32_t camera_spi_sr, camera_spi_error, camera_dma_error;
    uint32_t mic_hz, mic_origin;
    uint64_t mic_produced, mic_saved;
    uint32_t mic_fault, mic_overruns;
    uint32_t seed_reg0, effective_reg0, reg1, auto_enabled, mean;
    uint32_t stop_clock_tick, stop_clock_generation;
    uint64_t stop_clock_utc_us;
    uint32_t start_uncertainty_us, stop_uncertainty_us;
} NpMediaMetadata;

static inline void np_media_meta_put32(uint8_t *p, uint32_t v)
{ p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); p[2]=(uint8_t)(v>>16); p[3]=(uint8_t)(v>>24); }
static inline void np_media_meta_put64(uint8_t *p, uint64_t v)
{ np_media_meta_put32(p,(uint32_t)v); np_media_meta_put32(p+4,(uint32_t)(v>>32)); }

/* Writes exactly bytes128..295; preserves the common header, reserved tail
 * and existing CRC at508. No hardware access or checksum calculation. */
static inline void np_media_metadata_write(uint8_t sector[512], const NpMediaMetadata *m)
{
    static const uint8_t magic[8]={'N','P','M','E','D','X','1',0};
    memcpy(sector+128,magic,sizeof(magic));
    np_media_meta_put32(sector+136,NP_MEDIA_METADATA_VERSION);
    np_media_meta_put32(sector+140,m->flags);
    np_media_meta_put32(sector+144,m->start_tick);
    np_media_meta_put32(sector+148,m->stop_tick);
    np_media_meta_put32(sector+152,m->start_clock_tick);
    np_media_meta_put32(sector+156,m->start_clock_generation);
    np_media_meta_put64(sector+160,m->start_clock_utc_us);
    np_media_meta_put32(sector+168,m->camera_hz);
    np_media_meta_put32(sector+172,m->camera_source_completed);
    np_media_meta_put32(sector+176,m->camera_saved);
    np_media_meta_put32(sector+180,m->camera_first_id);
    np_media_meta_put32(sector+184,m->camera_last_id);
    np_media_meta_put32(sector+188,m->camera_first_tick);
    np_media_meta_put32(sector+192,m->camera_last_tick);
    np_media_meta_put32(sector+196,m->camera_fault);
    np_media_meta_put32(sector+200,m->camera_cadence_misses);
    np_media_meta_put32(sector+204,m->camera_baseline_misses);
    np_media_meta_put32(sector+208,m->camera_spi_sr);
    np_media_meta_put32(sector+212,m->camera_spi_error);
    np_media_meta_put32(sector+216,m->camera_dma_error);
    np_media_meta_put32(sector+220,m->mic_hz);
    np_media_meta_put32(sector+224,m->mic_origin);
    np_media_meta_put64(sector+228,m->mic_produced);
    np_media_meta_put64(sector+236,m->mic_saved);
    np_media_meta_put32(sector+244,m->mic_fault);
    np_media_meta_put32(sector+248,m->mic_overruns);
    np_media_meta_put32(sector+252,m->seed_reg0);
    np_media_meta_put32(sector+256,m->effective_reg0);
    np_media_meta_put32(sector+260,m->reg1);
    np_media_meta_put32(sector+264,m->auto_enabled);
    np_media_meta_put32(sector+268,m->mean);
    np_media_meta_put32(sector+272,m->stop_clock_tick);
    np_media_meta_put32(sector+276,m->stop_clock_generation);
    np_media_meta_put64(sector+280,m->stop_clock_utc_us);
    np_media_meta_put32(sector+288,m->start_uncertainty_us);
    np_media_meta_put32(sector+292,m->stop_uncertainty_us);
}
#endif
