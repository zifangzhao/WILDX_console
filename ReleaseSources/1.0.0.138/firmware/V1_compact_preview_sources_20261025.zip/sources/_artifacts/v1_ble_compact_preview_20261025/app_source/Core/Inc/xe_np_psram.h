#ifndef XE_NP_PSRAM_H
#define XE_NP_PSRAM_H

#include "stm32u5xx_hal.h"

#define XE_NP_PSRAM_BASE_ADDR ((uint32_t)OCTOSPI2_BASE)
#define XE_NP_PSRAM_SIZE_BYTES (8UL * 1024UL * 1024UL)
#define XE_NP_PSRAM_VALIDATED_SIZE_BYTES XE_NP_PSRAM_SIZE_BYTES
#define XE_NP_PSRAM_MPU_NONCACHEABLE_EXPERIMENT 1U

#define XE_NP_PSRAM_DIAG_MAGIC 0x5053524DUL
#define XE_NP_PSRAM_DIAG_VERSION 5UL

#define XE_NP_PSRAM_FLAG_ID_READ_OK 0x00000001UL
#define XE_NP_PSRAM_FLAG_SPI_INDIRECT_OK 0x00000002UL
#define XE_NP_PSRAM_FLAG_QSPI_INDIRECT_OK 0x00000004UL
#define XE_NP_PSRAM_FLAG_MEMMAP_CONFIG_OK 0x00000008UL
#define XE_NP_PSRAM_FLAG_MEMMAP_OK 0x00000010UL
#define XE_NP_PSRAM_FLAG_BANDWIDTH_OK 0x00000020UL

typedef struct
{
    uint32_t magic;
    uint32_t version;
    uint32_t stage;
    uint32_t result;
    uint32_t flags;
    uint32_t base_addr;
    uint32_t size_bytes;
    uint32_t ospi_error_code;
    uint32_t ospi_sr;
    uint32_t ospi_cr;
    uint32_t ospi_dcr1;
    uint32_t ospi_dcr2;
    uint32_t ospi_tcr;
    uint32_t dlyb_units;
    uint32_t dlyb_phase;
    uint32_t id_word0;
    uint32_t id_word1;
    uint32_t spi_pass_mask;
    uint32_t qspi_pass_mask;
    uint32_t memmap_pass_mask;
    uint32_t mismatch_addr;
    uint32_t expected_word;
    uint32_t actual_word;
    uint32_t tick_ms;
    uint32_t bench_bytes;
    uint32_t bench_write_cycles;
    uint32_t bench_write_flush_cycles;
    uint32_t bench_write_total_cycles;
    uint32_t bench_read_cycles;
    uint32_t bench_write_bytes_per_sec;
    uint32_t bench_write_total_bytes_per_sec;
    uint32_t bench_read_bytes_per_sec;
    uint32_t bench_checksum;
    uint32_t bench_error_count;
} XE_NP_PsramDiag;

extern volatile XE_NP_PsramDiag xe_np_psram_diag;

static inline uint8_t XE_NP_Psram_RangeContained(const void *addr, uint32_t size_bytes)
{
    uintptr_t start_addr;
    uintptr_t end_addr;
    uintptr_t psram_start;
    uintptr_t psram_end;

    if((addr == NULL) || (size_bytes == 0U))
    {
        return 0U;
    }

    start_addr = (uintptr_t)addr;
    end_addr = start_addr + (uintptr_t)size_bytes;
    if(end_addr < start_addr)
    {
        return 0U;
    }

    psram_start = (uintptr_t)XE_NP_PSRAM_BASE_ADDR;
    psram_end = psram_start + (uintptr_t)XE_NP_PSRAM_SIZE_BYTES;
    return ((start_addr >= psram_start) && (end_addr <= psram_end)) ? 1U : 0U;
}

int XE_NP_Psram_RunBootSelfTest(OSPI_HandleTypeDef *hospi);
const volatile XE_NP_PsramDiag *XE_NP_Psram_GetDiag(void);

#endif
