#ifndef XE_NP_DATA_MGR_H
#define XE_NP_DATA_MGR_H

#include "ce32_wire.h"

#define MGR_STATE_TRANSBUSY 0x00000001UL
#define MGR_STATE_TRANSCPLT 0x00000002UL
#define MGR_STATE_DSPBUSY 0x00000004UL
#define MGR_STATE_LOGGING 0x00000008UL
#define MGR_STATE_TRANSON 0x00000010UL
#define MGR_STATE_SLEEP 0x00000020UL
#define MGR_STATE_STOP 0x00000040UL
#define MGR_STATE_TRANSMISC 0x00000080UL
#define MGR_STATE_TRANSERR 0x00000100UL
#define MGR_STATE_TRANSOVR 0x00000200UL

#define MGR_SYS_RECORDING 0x00000001UL
#define MGR_SYS_PREVIEW 0x00000002UL
#define MGR_SYS_USBCONN 0x00000004UL
#define MGR_SYS_CL_CALIB 0x00000008UL
#define MGR_SYS_CL_PROCESS 0x00000010UL
#define MGR_SYS_TIMEDMODE 0x00000020UL

#define MISC_SIG_TRIG1 0x00000001UL
#define MISC_SIG_STIM1 0x00000002UL
#define MISC_SIG_TRIG2 0x00000004UL
#define MISC_SIG_STIM2 0x00000008UL
#define MISC_SIG_AUX1 0x00000010UL
#define MISC_SIG_AUX2 0x00000020UL
#define MISC_SIG_AUX3 0x00000040UL
#define MISC_SIG_EXT1 0x00000080UL
#define MISC_SIG_EXT2 0x00000100UL
#define MISC_SIG_EXT3 0x00000200UL
#define MISC_SIG_UNDERVOLT 0x00000400UL
#define MISC_SIG_DSP_WAIT 0x00000800UL
#define MISC_SIG_DSP_CAL 0x00001000UL
#define MISC_SIG_DSP_READY 0x00002000UL
#define MISC_SIG_LD1 0x00004000UL
#define MISC_SIG_LD2 0x00008000UL

#define AU_BLOCKS 0x2000U
#define SYS_ADDR 0x0011U
#define DSP1_ADDR 0x0012U
#define DSP2_ADDR 0x0013U
#define SYNCREC_ADDR 0x0020U
#define LOG_ADDR 0x0080U
#define FW_ADDR 0x1000U
#define DATA_ADDR AU_BLOCKS

#define CE32_MAX_FS 20000U
#define CE32_BASE_FS 1250U
#define CE32_PREV_FS 625U
#define CE32_ADC_FS 160000U
#define CE32_CAMERA_FPS 16U
#define MISC_NUMCH 16U

#define PREV_TRANS_BYTES 128U
#define CE32_DSP_COUNT 2U

#define CL_MODE_DISABLE 0U
#define CL_MODE_SINGLE 1U
#define CL_MODE_DOUBLE 2U
#define CL_MODE_CASCADE 3U
#define CL_MODE_GATED 4U

#define STIM_MODE_DISABLE 0U
#define STIM_MODE_EN 1U

#define BUF_SIZE 0x3FFC0U
#define PREV_SIZE 0x400U
#define EXTIN_SIZE 0x0010U

#define CE32_ERRORID_CORE_ERROR 0x0001UL
#define CE32_ERRORID_CORE_LOWVOLT 0x0002UL
#define CE32_ERRORID_CORE_UPGRADEFAIL 0x0004UL
#define CE32_ERRORID_CORE_BOOTFAIL 0x0008UL
#define CE32_ERRORID_INTAN_NOTPRESENT 0x0010UL
#define CE32_ERRORID_INTAN_ERR 0x0020UL
#define CE32_ERRORID_ACC_NOTPRESENT 0x0040UL
#define CE32_ERRORID_ACC_ERR 0x0080UL
#define CE32_ERRORID_SD_NOTPRESENT 0x0100UL
#define CE32_ERRORID_SD_ERR 0x0200UL
#define CE32_ERRORID_SD_CARDFULL 0x0400UL
#define CE32_ERRORID_SD_FORMATERR 0x0800UL
#define CE32_ERRORID_BLE_NOTPRESENT 0x1000UL
#define CE32_ERRORID_BLE_RECPTION 0x2000UL
#define CE32_ERRORID_BLE_DISCONNECT 0x4000UL
#define CE32_ERRORID_BLE_VERSION 0x8000UL
#define CE32_ERRORID_PARAM_ERR 0x10000UL

#define CE32_SYSPARAM_FLAG_NORESET 0x0001U
#define CE32_OUTPTR_COUNT 3U

typedef struct
{
    unsigned long moduleConnected;
} CE32_sysState;

typedef struct
{
    __IO unsigned long logState;
    __IO unsigned long sysState;
    __IO unsigned long dataSize;
    __IO unsigned long inPTR;
    __IO unsigned long ptr_mask;
    __IO unsigned long outPTR[CE32_OUTPTR_COUNT];
    __IO unsigned long bufferUsed[CE32_OUTPTR_COUNT];
    __IO unsigned long bufferMAX[CE32_OUTPTR_COUNT];
    __IO char *dataPtr;
    __IO uint32_t *DMA_RX_NDTR;
    __IO uint32_t *DMA_TX_NDTR;
    __IO uint32_t activeOutMask;
} dataMGR;

void dataMGR_init(dataMGR *mgr, char *dataPtr, unsigned long dataSize);
void dataMGR_init_DMA(dataMGR *mgr, char *dataPtr, unsigned long dataSize, __IO uint32_t *dma_rx_ndtr, __IO uint32_t *dma_tx_ndtr);
void dataMGR_init_515B(dataMGR *mgr, char *dataPtr, unsigned long dataSize);
void dataMGR_IncNrec(CE32_systemLog *sysLog);
void CE32_ReportError(CE32_systemParam *sysParam, unsigned long error_code);
void syslog_init(CE32_systemLog *sysLog, unsigned int *filePTR);
uint32_t largestPowerOf2(uint32_t n);

CE32_FORCE_INLINE void dataMGR_setActiveOutMask(dataMGR *mgr, uint32_t mask)
{
    if(mgr == NULL)
    {
        return;
    }

    mgr->activeOutMask = (uint32_t)(mask & ((1UL << CE32_OUTPTR_COUNT) - 1UL));
}

CE32_FORCE_INLINE uint32_t CE32_CriticalSection_Enter(void)
{
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    return primask;
}

CE32_FORCE_INLINE void CE32_CriticalSection_Exit(uint32_t primask)
{
    if(primask == 0U)
    {
        __enable_irq();
    }
}

CE32_FORCE_INLINE void dataMGR_ArmConsumer(dataMGR *mgr, unsigned short outPTR_idx)
{
    uint32_t primask;

    if((mgr == NULL) || (outPTR_idx >= CE32_OUTPTR_COUNT))
    {
        return;
    }

    primask = CE32_CriticalSection_Enter();
    mgr->outPTR[outPTR_idx] = mgr->inPTR;
    mgr->bufferUsed[outPTR_idx] = 0U;
    mgr->activeOutMask |= (1UL << outPTR_idx);
    CE32_CriticalSection_Exit(primask);
}

CE32_FORCE_INLINE void dataMGR_DisarmConsumer(dataMGR *mgr, unsigned short outPTR_idx)
{
    uint32_t primask;

    if((mgr == NULL) || (outPTR_idx >= CE32_OUTPTR_COUNT))
    {
        return;
    }

    primask = CE32_CriticalSection_Enter();
    mgr->outPTR[outPTR_idx] = mgr->inPTR;
    mgr->bufferUsed[outPTR_idx] = 0U;
    mgr->activeOutMask &= ~(1UL << outPTR_idx);
    CE32_CriticalSection_Exit(primask);
}

CE32_FORCE_INLINE void CE32_AtomicAdd_U32(volatile unsigned long *addr, uint32_t val)
{
    uint32_t primask = CE32_CriticalSection_Enter();
    *addr += (unsigned long)val;
    CE32_CriticalSection_Exit(primask);
}

CE32_FORCE_INLINE void CE32_AtomicSub_U32(volatile unsigned long *addr, uint32_t val)
{
    uint32_t primask = CE32_CriticalSection_Enter();
    *addr -= (unsigned long)val;
    CE32_CriticalSection_Exit(primask);
}

CE32_FORCE_INLINE uint32_t dataMGR_AtomicAddClamp_U32(
    dataMGR *mgr,
    unsigned short outPTR_idx,
    uint32_t val)
{
    uint32_t primask;
    uint32_t data_size;
    uint32_t used;
    uint32_t new_used;

    if((mgr == NULL) || (outPTR_idx >= CE32_OUTPTR_COUNT))
    {
        return 0U;
    }

    data_size = (uint32_t)mgr->dataSize;
    if(data_size == 0U)
    {
        mgr->logState |= MGR_STATE_TRANSERR;
        return 0U;
    }

    primask = CE32_CriticalSection_Enter();
    used = (uint32_t)mgr->bufferUsed[outPTR_idx];
    if(used >= data_size)
    {
        mgr->bufferUsed[outPTR_idx] = data_size;
        mgr->logState |= MGR_STATE_TRANSOVR;
        CE32_CriticalSection_Exit(primask);
        return 1U;
    }

    new_used = used + val;
    if(new_used > data_size)
    {
        mgr->bufferUsed[outPTR_idx] = data_size;
        mgr->logState |= MGR_STATE_TRANSOVR;
        CE32_CriticalSection_Exit(primask);
        return 1U;
    }

    mgr->bufferUsed[outPTR_idx] = new_used;
    CE32_CriticalSection_Exit(primask);
    return 0U;
}

CE32_FORCE_INLINE void dataMGR_enQueue_byte(dataMGR *mgr, char data)
{
    uint32_t data_size;

    if(mgr == NULL)
    {
        return;
    }

    data_size = (uint32_t)mgr->dataSize;
    if(data_size == 0U)
    {
        mgr->logState |= MGR_STATE_TRANSERR;
        return;
    }

    mgr->dataPtr[mgr->inPTR] = data;
    mgr->inPTR++;
    if(mgr->inPTR >= data_size)
    {
        mgr->inPTR -= data_size;
    }

    for(uint32_t i = 0; i < CE32_OUTPTR_COUNT; ++i)
    {
        if((mgr->activeOutMask & (1UL << i)) == 0U)
        {
            continue;
        }
        (void)dataMGR_AtomicAddClamp_U32(mgr, (unsigned short)i, 1U);
    }
}

CE32_FORCE_INLINE void dataMGR_enQueue_Nbytes(dataMGR *mgr, uint32_t nbytes)
{
    uint32_t data_size;

    if(mgr == NULL)
    {
        return;
    }

    data_size = (uint32_t)mgr->dataSize;
    if(data_size == 0U)
    {
        mgr->logState |= MGR_STATE_TRANSERR;
        return;
    }

    mgr->inPTR += nbytes;
    if(mgr->inPTR >= data_size)
    {
        mgr->inPTR -= (mgr->inPTR / data_size) * data_size;
    }

    for(uint32_t i = 0; i < CE32_OUTPTR_COUNT; ++i)
    {
        if((mgr->activeOutMask & (1UL << i)) == 0U)
        {
            continue;
        }
        (void)dataMGR_AtomicAddClamp_U32(mgr, (unsigned short)i, nbytes);
    }
}

CE32_FORCE_INLINE int dataMGR_deQueue_byte_safe(dataMGR *mgr, unsigned short outPTR_idx, char *output)
{
    uint32_t data_size;

    if((mgr == NULL) || (output == NULL) || (outPTR_idx >= CE32_OUTPTR_COUNT))
    {
        return -1;
    }

    if(mgr->bufferUsed[outPTR_idx] == 0U)
    {
        return -1;
    }

    data_size = (uint32_t)mgr->dataSize;
    *output = mgr->dataPtr[mgr->outPTR[outPTR_idx]];
    mgr->outPTR[outPTR_idx]++;
    if(mgr->outPTR[outPTR_idx] >= data_size)
    {
        mgr->outPTR[outPTR_idx] -= data_size;
    }
    CE32_AtomicSub_U32(&mgr->bufferUsed[outPTR_idx], 1U);
    return 0;
}

CE32_FORCE_INLINE void dataMGR_deQueue(dataMGR *mgr, unsigned long numBytes, unsigned short outPTR_idx)
{
    unsigned long temp_ptr;
    uint32_t data_size;
    uint32_t available;
    uint32_t dequeue_bytes;

    if((mgr == NULL) || (outPTR_idx >= CE32_OUTPTR_COUNT))
    {
        return;
    }

    data_size = (uint32_t)mgr->dataSize;
    if(data_size == 0U)
    {
        mgr->logState |= MGR_STATE_TRANSERR;
        return;
    }

    available = (uint32_t)mgr->bufferUsed[outPTR_idx];
    dequeue_bytes = (uint32_t)numBytes;
    if(dequeue_bytes > available)
    {
        dequeue_bytes = available;
        mgr->logState |= MGR_STATE_TRANSERR;
    }

    temp_ptr = mgr->outPTR[outPTR_idx] + dequeue_bytes;
    if(temp_ptr >= data_size)
    {
        temp_ptr -= (temp_ptr / data_size) * data_size;
    }
    mgr->outPTR[outPTR_idx] = temp_ptr;
    CE32_AtomicSub_U32(&mgr->bufferUsed[outPTR_idx], dequeue_bytes);
}

CE32_FORCE_INLINE uint32_t dataMGR_BytesAvailable(const dataMGR *mgr, unsigned short outPTR_idx)
{
    if((mgr == NULL) || (outPTR_idx >= CE32_OUTPTR_COUNT))
    {
        return 0U;
    }

    return (uint32_t)mgr->bufferUsed[outPTR_idx];
}

CE32_FORCE_INLINE uint32_t dataMGR_ContiguousBytesAvailable(
    const dataMGR *mgr,
    unsigned short outPTR_idx)
{
    uint32_t available;
    uint32_t data_size;
    uint32_t until_wrap;

    if((mgr == NULL) || (outPTR_idx >= CE32_OUTPTR_COUNT))
    {
        return 0U;
    }

    available = (uint32_t)mgr->bufferUsed[outPTR_idx];
    data_size = (uint32_t)mgr->dataSize;
    until_wrap = data_size - (uint32_t)mgr->outPTR[outPTR_idx];
    return (available < until_wrap) ? available : until_wrap;
}

CE32_FORCE_INLINE uint8_t *dataMGR_returnPTR(dataMGR *mgr, unsigned short outPTR_idx)
{
    if((mgr == NULL) || (outPTR_idx >= CE32_OUTPTR_COUNT))
    {
        return NULL;
    }

    return (uint8_t *)&mgr->dataPtr[mgr->outPTR[outPTR_idx]];
}

CE32_FORCE_INLINE uint8_t *dataMGR_returnInPTR(dataMGR *mgr)
{
    if(mgr == NULL)
    {
        return NULL;
    }

    return (uint8_t *)&mgr->dataPtr[mgr->inPTR];
}

#endif
