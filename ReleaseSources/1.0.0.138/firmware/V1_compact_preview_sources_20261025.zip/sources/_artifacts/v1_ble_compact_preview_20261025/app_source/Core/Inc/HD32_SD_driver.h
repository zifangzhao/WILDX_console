#ifndef __HD32_SD_DRV
#define __HD32_SD_DRV

#include "stm32f4xx_hal.h"
#include "CE32_macro.h"
#include "dataMGR.h"

/*
 * Legacy CE64 SD driver interface preserved for the filesystem scheduler.
 * XE_NP will map these calls onto SDMMC1 + DMA even though the old API keeps
 * the SPI-oriented naming and hspi parameter.
 */

#define MAX_PREERASE_CNT 0x400000U

typedef struct
{
    __IO uint32_t NDTR;
} XE_NP_SD_DMA_CompatTypeDef;

#define HD32_SD_DIAG_MAGIC 0x53443248UL
#define HD32_SD_DIAG_VERSION 1U

#define HD32_SD_DIAG_OP_NONE 0U
#define HD32_SD_DIAG_OP_READ_SINGLE 1U
#define HD32_SD_DIAG_OP_WRITE_SINGLE 2U
#define HD32_SD_DIAG_OP_WRITE_DMA 3U

#define HD32_SD_DIAG_STAGE_IDLE 0U
#define HD32_SD_DIAG_STAGE_ENTER 1U
#define HD32_SD_DIAG_STAGE_ENSURE_FAIL 2U
#define HD32_SD_DIAG_STAGE_HAL_FAIL 3U
#define HD32_SD_DIAG_STAGE_WAIT_FAIL 4U
#define HD32_SD_DIAG_STAGE_OK 5U
#define HD32_SD_DIAG_STAGE_RECOVER_FAIL 6U

typedef struct
{
    uint32_t magic;
    uint32_t version;
    uint32_t tick_ms;
    uint32_t op;
    uint32_t stage;
    uint32_t addr;
    uint32_t block_count;
    uint32_t hal_status;
    uint32_t error_code;
    uint32_t card_state_before;
    uint32_t card_state_after;
    uint32_t write_flags;
    uint32_t hal_state;
    uint32_t hal_context;
    uint32_t sdmmc_sta;
    uint32_t sdmmc_dctrl;
    uint32_t recover_count;
    uint32_t recover_last_status;
} HD32_SDDiag;

extern XE_NP_SD_DMA_CompatTypeDef xe_np_legacy_sd_dma_compat;
extern volatile HD32_SDDiag hd32_sd_diag;
#define SD_DMA_TX (&xe_np_legacy_sd_dma_compat)

int HD32_SD_init(SPI_HandleTypeDef *hspi);
int HD32_SD_readCSD(SPI_HandleTypeDef *hspi, CE32_systemParam *sys);
int HD32_SD_writeBlock(uint32_t addr);
int HD32_SD_writeSingleBlock(uint32_t addr, uint8_t *data);
int HD32_SD_writeSingleBlock_DMA(uint32_t addr, uint8_t *data);
int HD32_SD_write_DMA(uint8_t *data, uint16_t size);
int HD32_SD_writeBlock_DMA_Check(void);
int HD32_SD_readSingleBlock(uint32_t addr, uint8_t *data);
int HD32_SD_preErase(uint32_t blkNum);
int HD32_SD_stopTrans(void);
void HD32_SD_TxCpltCallback(SD_HandleTypeDef *hsd);
void HD32_SD_RxCpltCallback(SD_HandleTypeDef *hsd);
void HD32_SD_ErrorCallback(SD_HandleTypeDef *hsd);
int HD32_SD_DMAStillBusy(void);
void HD32_SD_Service(void);

#define SDSPI_DMA_Enable() ((void)0)

#endif
