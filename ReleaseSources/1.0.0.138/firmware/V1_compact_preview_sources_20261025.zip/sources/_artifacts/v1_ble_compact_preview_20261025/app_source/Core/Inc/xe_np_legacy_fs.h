#ifndef XE_NP_LEGACY_FS_H
#define XE_NP_LEGACY_FS_H

#include "xe_np_runtime.h"

#define XE_NP_LEGACY_FS_DIAG_MAGIC 0x4453464CUL
#define XE_NP_LEGACY_FS_DIAG_VERSION 1U

#define XE_NP_LEGACY_FS_DIAG_STEP_IDLE 0U
#define XE_NP_LEGACY_FS_DIAG_STEP_RUNTIME_NOT_READY 1U
#define XE_NP_LEGACY_FS_DIAG_STEP_CONFIG_ENTER 2U
#define XE_NP_LEGACY_FS_DIAG_STEP_CONFIG_NO_RATE 3U
#define XE_NP_LEGACY_FS_DIAG_STEP_INIT_ENTER 4U
#define XE_NP_LEGACY_FS_DIAG_STEP_INIT_FAIL 5U
#define XE_NP_LEGACY_FS_DIAG_STEP_INIT_OK 6U
#define XE_NP_LEGACY_FS_DIAG_STEP_START_ENTER 7U
#define XE_NP_LEGACY_FS_DIAG_STEP_START_FAIL 8U
#define XE_NP_LEGACY_FS_DIAG_STEP_START_OK 9U
#define XE_NP_LEGACY_FS_DIAG_STEP_FS_DISABLED 10U
#define XE_NP_LEGACY_FS_DIAG_STEP_ABORT 11U
#define XE_NP_LEGACY_FS_DIAG_STEP_SD_ERROR 12U

typedef struct
{
    uint32_t magic;
    uint32_t version;
    uint32_t tick_ms;
    uint32_t step;
    uint32_t runtime_flags;
    uint32_t capture_flags;
    uint32_t ce32_error;
    uint32_t fs_enabled;
    uint32_t fs_state;
    uint32_t fs_state_machine;
    uint32_t fs_fail_cnt;
    uint32_t init_result;
    uint32_t start_result;
    uint32_t gpioe_rate;
    uint32_t gpiod_rate;
    uint32_t adc_rate;
    uint32_t file_addr;
    uint32_t event_addr;
    uint32_t log_addr;
    uint32_t status_bits;
} XE_NP_LegacyFsDiag;

extern volatile XE_NP_LegacyFsDiag xe_np_legacy_fs_diag;

void XE_NP_LegacyFs_Init(XE_NP_Runtime *runtime);
void XE_NP_LegacyFs_Service(XE_NP_Runtime *runtime);
void XE_NP_LegacyFs_Stop(void);
void XE_NP_LegacyFs_Abort(void);
int XE_NP_LegacyFs_IsActive(void);
void XE_NP_LegacyFs_RefreshMetadata(void);
void XE_NP_LegacyFs_OnSdError(void);

#endif
