#ifndef NPC_PORT_H
#define NPC_PORT_H
#include "np_config.h"
#include "xe_np_nric.h"
extern NpcState np_configuration;
void NP_ConfigInit(void);
void NP_ConfigService(void);
int NP_ConfigSubmit(uint32_t owner,const uint8_t *request,uint32_t length);
int NP_ConfigReply(uint32_t owner,uint8_t reply[64]);
void NP_ConfigReplyConsumed(uint32_t owner);
int NP_ConfigTransferPending(void);
void NP_ConfigDisconnect(uint32_t owner);
int NP_ConfigPrepare(unsigned port,unsigned model,XE_NP_NricConfig *config);
void NP_ConfigApplied(unsigned port,int success,unsigned model);
/* Immutable USB recording receipt; this uses only cached pre-capture state. */
#define NPC_RECORDING_MANIFEST_BYTES (108U+NPC_BYTES)
int NP_ConfigBuildRecordingManifest(unsigned port,uint8_t *dst,uint32_t bytes);
/* Implemented beside each personality's existing ownership/state machine. */
int NP_ConfigBusy(void);
unsigned NP_ConfigActiveMask(void);
void NP_ConfigRearm(void);
#endif
