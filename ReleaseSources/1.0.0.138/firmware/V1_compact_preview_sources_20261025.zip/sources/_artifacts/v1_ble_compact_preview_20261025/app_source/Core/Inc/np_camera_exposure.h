#ifndef NP_CAMERA_EXPOSURE_H
#define NP_CAMERA_EXPOSURE_H
#include <stdint.h>
#include <string.h>

/* CE64 policy, applied only to immutable completed frames in foreground.
 * Nine real packed pixels avoid border/training words and full-frame scans. */
typedef struct {
    uint32_t frame_id, frame_tick, frames, updates;
    uint16_t mean;
    uint8_t rows, gain, automatic, under, over, seen;
} NpCameraExposure;

static inline void np_camera_exposure_reset(NpCameraExposure *s,
    uint8_t rows, uint8_t gain, uint8_t automatic)
{
    memset(s, 0, sizeof(*s));
    s->rows=rows; s->gain=gain; s->automatic=automatic!=0U;
}
static inline uint16_t np_camera_exposure_pixel(const uint8_t *frame,
    unsigned row, unsigned column)
{
    const uint8_t *p=frame+12U+row*492U+(column/2U)*3U;
    return (uint16_t)((column&1U)?((p[1]&7U)<<7U)|((p[2]&0xfeU)>>1U):
        ((p[0]&0x7fU)<<3U)|(p[1]>>5U));
}
/* Returns one for a register change, minus one for unusable metering data.
 * Never modifies pixels or advances AE state from an invalid sample. */
static inline int np_camera_exposure_observe(NpCameraExposure *s,
    const uint8_t *frame, uint32_t bytes, uint32_t id, uint32_t tick)
{
    if(!frame || bytes<157452U || s->gain>3U)return -1;
    if(s->seen && (int32_t)(id-s->frame_id)<=0)return 0;
    unsigned sum=0;
    for(unsigned row=80U;row<=240U;row+=80U)
        for(unsigned col=80U;col<=240U;col+=80U)
        {
            const uint8_t *p=frame+12U+row*492U+(col/2U)*3U;
            /* All nine metering columns are even: start1 / data10 / stop0.
             * Check only those existing samples, not the complete raster. */
            if(!(p[0]&0x80U) || (p[1]&0x10U))return -1;
            sum+=np_camera_exposure_pixel(frame,row,col);
        }
    s->seen=1U; s->frame_id=id; s->frame_tick=tick; s->frames++;
    s->mean=(uint16_t)(sum/9U);
    if(!s->automatic)return 0;
    uint8_t before_rows=s->rows,before_gain=s->gain;
    int rows=(int)s->rows+((int)s->mean-512)/16;
    s->rows=(uint8_t)(rows<0?0:rows>255?255:rows);
    if(s->mean>665U){if(s->over<33U)s->over++;}
    else if(s->mean<358U){if(s->under<33U)s->under++;}
    else {if(s->over)s->over--;if(s->under)s->under--;}
    if(s->over>32U){if(s->gain)s->gain--;s->over=0U;}
    if(s->under>32U){if(s->gain<3U)s->gain++;s->under=0U;}
    if(s->rows==before_rows && s->gain==before_gain)return 0;
    s->updates++; return 1;
}
#endif
