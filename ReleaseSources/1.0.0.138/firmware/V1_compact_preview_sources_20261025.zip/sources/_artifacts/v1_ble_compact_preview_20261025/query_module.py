"""Exact-V1 idle SRAM UART read queries only; never write module configuration."""
import importlib.util
import json
from pathlib import Path
import socket
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent/'uart_query'
OPENOCD=Path('C:/ST/STM32CubeIDE_2.2.0/STM32CubeIDE/plugins/com.st.stm32cube.ide.mcu.externaltools.openocd.win32_2.4.500.202604080855/tools/bin/openocd.exe')
SCRIPTS='C:/ST/STM32CubeIDE_2.2.0/STM32CubeIDE/plugins/com.st.stm32cube.ide.mcu.debug.openocd_2.3.400.202606220929/resources/openocd/st_scripts'
sys.path.insert(0,str(ROOT/'Tools/V1Capture/Ble'))
from probe import Debug
from uart_session import start,exchange

class ExactDebug(Debug):
    def __enter__(self):
        self.s=socket.create_connection(('127.0.0.1',6669),timeout=5);self.s.settimeout(15)
        assert self.read(0x0bfa0700,3)==[0x001d0006,0x5942500b,0x20313354],'Wrong V1; no UART request'
        return self

def main():
    result={'uid':'001D00065942500B20313354','module_configuration_written':False,'queries':[]}
    log=(OUT/'openocd.log').open('w')
    cfg=['gdb_port disabled','tcl_port 6669','telnet_port disabled',
         'source [find interface/stlink-dap.cfg]','adapter serial 001A00423235510D37333439',
         'transport select dapdirect_swd','source [find target/stm32u5x.cfg]',
         'stm32u5.ap0 configure -event examine-end {}','stm32u5.cpu configure -event examine-end {}',
         'adapter speed 24000','init','poll off']
    process=subprocess.Popen([str(OPENOCD),'-s',SCRIPTS,*sum((['-c',x] for x in cfg),[])],stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    loaded=False
    try:
        deadline=time.monotonic()+8
        while True:
            try:d=ExactDebug().__enter__();break
            except (ConnectionRefusedError,TimeoutError):
                if process.poll() is not None or time.monotonic()>deadline:raise
                time.sleep(.1)
        try:
            assert d.read(0x0801e020,1)==[0xcc50d8d2] and d.read(0x0817e020,1)==[0x4f7b521a],'Wrong image'
            assert d.read(0xe000ed08,1)==[0x08020000],'APP not running'
            # CC50 exact map: idle/configuration owners only; no capture or SD transaction.
            assert d.read(0x20008a74,2)==[0,0],'APP recorder not clean idle'
            for address in (0x20008aa0,0x20000824,0x200006b8):assert d.read(address,1)==[0],'Pending owner'
            for address in (0x40012c00,0x40000000,0x40013400):assert d.read(address,1)[0]&1==0,'Capture timer enabled'
            assert d.read(0x420c8034,1)[0]&0x3000==0 and d.read(0x420c8050,1)[0]&1==0,'SD transaction active'
            result['before_uart']={'cr1':d.read(0x40013800,1)[0],'brr':d.read(0x4001380c,1)[0]}
            loaded=True
            start(d,OUT/'uart_session.axf')
            for command in ('<RD_SOFT_VERSION>','<RD_BAUD>'):
                answer=exchange(d,command,wake=0,route=0,pre_ms=100,after=2,timeout_ms=800)
                result['queries'].append(answer)
            result['typed_module_response']=any('<rd_soft_version=' in q['reply'].lower() or '<rd_baud=' in q['reply'].lower() for q in result['queries'])
            result['result']='READ_QUERIES_RESPONDED' if result['typed_module_response'] else 'NO_TYPED_MODULE_REPLY_KEEP_115200'
        finally:
            if loaded:
                result['reset_to_unchanged_app']=d.rpc('reset run')
            d.rpc('poll off');d.rpc('mww 0xe000edf0 0xa05f0000')
            result['debugger_disabled']=(d.read(0xe000edf0,1)[0]&1)==0
            d.rpc('shutdown');d.__exit__()
    finally:
        try:process.wait(timeout=5)
        except subprocess.TimeoutExpired:process.terminate();process.wait(timeout=5)
        log.close();(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
