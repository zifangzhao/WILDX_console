"""Preserve the compact-preview APP source graph; never operate hardware."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile


ROOT = Path('C:/Frank/Code/XE_NP').resolve()
TASK = ROOT / '_artifacts/v1_ble_compact_preview_20261025'
OUT = Path(__file__).resolve().parent
ZIP = OUT / 'V1_compact_preview_sources_20261025.zip'
PARENT = ROOT / '_artifacts/v1_lifecycle_release_20261025/source_archive'


def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def main():
    if OUT != TASK / 'source_archive' or any((OUT / n).exists() for n in
            ('sources', ZIP.name, 'archive_manifest.json', 'verification.json')):
        raise ValueError('Fresh exact compact source archive required')
    build_path = TASK / 'app_build/build.json'
    build = load(build_path)
    parent = load(PARENT / 'verification.json')
    if sha((PARENT / 'V1_lifecycle_sources_20261025.zip').read_bytes()) != parent['sha256']:
        raise ValueError('Referenced parent source archive identity changed')
    if len(build['source_dependencies']) != 159 or len(build['reused_objects']) != 74:
        raise ValueError('Unexpected admitted compiler/object graph')
    entries, external = {}, {}

    def add(path, category, expected=None, synthetic=False):
        p = Path(path).resolve()
        raw = p.read_bytes()
        digest = sha(raw)
        if expected and digest != expected.upper():
            raise ValueError('Admitted source input changed: ' + str(p))
        if not p.is_relative_to(ROOT):
            if not p.is_relative_to(Path('C:/Keil_v5').resolve()):
                raise ValueError('Unexpected external dependency: ' + str(p))
            external[str(p)] = dict(original_path=str(p), sha256=digest, bytes=len(raw),
                reason='Proprietary Keil standard header; external reference only, not redistributed')
            return
        if synthetic:
            if p != TASK / 'native/vectors.bin' or len(raw) != 121 * 224:
                raise ValueError('Only the declared tiny121x224 synthetic fixture is admitted')
        elif p.suffix.lower() in {'.o', '.obj', '.axf', '.exe', '.dll', '.hex', '.bin', '.dat', '.map', '.mp4'}:
            raise ValueError('Non-source artifact rejected: ' + str(p))
        relative = p.relative_to(ROOT)
        if any(part in ('.git', '.aws', '.codex') for part in relative.parts):
            raise ValueError('Private directory is not an archive input')
        member = 'sources/' + relative.as_posix()
        item = entries.setdefault(member, dict(original_path=str(p), archive_member=member,
                sha256=digest, bytes=len(raw), categories=[], synthetic_fixture=synthetic))
        if item['sha256'] != digest:
            raise ValueError('Source changed during inventory')
        if category not in item['categories']:
            item['categories'].append(category)

    for x in build['source_dependencies']:
        add(x['path'], 'APP159_exact_compiler_input', x['sha256'])
    preview = (TASK / 'app_source/Core/Inc/np_ble_preview.h').read_bytes()
    for relative in ('Firmware/V1/Core/Inc/np_ble_preview.h', 'Tools/V1Capture/Ble/np_ble_preview.h'):
        p = ROOT / relative
        if p.read_bytes() != preview:
            raise ValueError('Canonical/mirror preview source differs from admitted ARM input')
        add(p, 'matching_canonical_and_helper_header')
    extras = [
        'Tools/V1Capture/Ble/test_compact_preview.c',
        'Tools/V1Capture/Ble/test_v2_protocols.c',
        'Tools/V1Capture/Ble/uart_session.c',
        'Tools/V1Capture/Ble/uart_session.py',
        'Tools/V1Capture/Ble/probe.py',
        'Tools/V1Capture/UsbSensors/build_compact_preview.ps1',
    ]
    for relative in extras:
        expected = build['build_helper_sha256'] if relative.endswith('build_compact_preview.ps1') else None
        add(ROOT / relative, 'build_native_and_readquery_source', expected)
    for relative in ('app_source/source_manifest.json', 'build_preparation.json',
                     'app_build/build.json', 'app_build/app.d', 'app_build/compact_preview.lnp',
                     'app_sealed/identity.json', 'query_module.py', 'uart_query/result.json'):
        add(TASK / relative, 'source_graph_and_readquery_provenance')
    add(Path(build['scatter']), 'unchanged_scatter', build['scatter_sha256'])
    add(TASK / 'native/vectors.bin', 'synthetic_test_fixture_not_recording', synthetic=True)
    add(Path(__file__), 'archive_helper')
    if len(external) != 4:
        raise ValueError('Expected four external Keil standard-header references')
    records = sorted(entries.values(), key=lambda x: x['archive_member'])
    for item in records:
        p = Path(item['original_path'])
        if sha(p.read_bytes()) != item['sha256']:
            raise ValueError('Source changed before copying: ' + str(p))
        target = OUT / item['archive_member']
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, target)
        if sha(target.read_bytes()) != item['sha256']:
            raise ValueError('Preservation copy mismatch')
    manifest = dict(schema='v1-compact-preview-source-preservation-v1', app_compiler_inputs=159,
        entries=records, external_dependencies=sorted(external.values(), key=lambda x: x['original_path']),
        reused_object_identity_records=build['reused_objects'], toolchain_references=build['toolchain'],
        parent_source_archive_reference=dict(path=parent['zip'], sha256=parent['sha256'],
            bytes=parent['bytes'], manifest_sha256=parent['manifest_sha256'],
            duplicated_payload=False, scope='Prior lifecycle/USB closures, helpers and lineage; referenced, not copied wholesale'),
        build_receipt_sha256=sha(build_path.read_bytes()),
        limits=[
            'Exact159-input incremental APP source graph plus admitted compact/native/read-query provenance, not a standalone whole-product clean-rebuild guarantee.',
            'All74 unchanged linked object identities are recorded; their binary bytes and all historic per-object source closures are not redistributed.',
            'Four proprietary Keil standard headers and toolchain executables are external hash references only.',
            'native/vectors.bin is exactly121 synthetic224-byte test packets, not a real recording or firmware dump.',
            'Original build/query scripts retain absolute workspace/tool paths; archival does not execute them.',
            'No compile/link/seal, hardware, firmware dump, SD/capture operation, package/release/version/Git/publication performed by this archive.'])
    manifest_path = OUT / 'archive_manifest.json'
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    with zipfile.ZipFile(ZIP, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for item in records:
            info = zipfile.ZipInfo(item['archive_member'], date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, (OUT / item['archive_member']).read_bytes())
        z.write(manifest_path, 'archive_manifest.json')
    names = {x['archive_member'] for x in records} | {'archive_manifest.json'}
    with zipfile.ZipFile(ZIP) as z:
        if len(z.namelist()) != len(names) or set(z.namelist()) != names:
            raise ValueError('ZIP entry identity/count mismatch')
        for item in records:
            if sha(z.read(item['archive_member'])) != item['sha256']:
                raise ValueError('ZIP read-back mismatch: ' + item['archive_member'])
        if z.read('archive_manifest.json') != manifest_path.read_bytes():
            raise ValueError('ZIP manifest read-back mismatch')
    result = dict(result='PASS exact compact source ZIP read-back', zip=str(ZIP),
        sha256=sha(ZIP.read_bytes()), bytes=ZIP.stat().st_size, source_entries=len(records),
        zip_entries=len(names), source_bytes=sum(x['bytes'] for x in records),
        external_reference_count=len(external), parent_archive_sha256=parent['sha256'],
        manifest_sha256=sha(manifest_path.read_bytes()), hardware_access=False,
        compiler_run=False, published=False)
    (OUT / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
