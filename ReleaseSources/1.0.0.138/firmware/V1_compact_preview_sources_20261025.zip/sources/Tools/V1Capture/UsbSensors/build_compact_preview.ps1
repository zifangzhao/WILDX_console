# One APP unit against exact CC50 inputs plus the two reviewed preview changes.
# Source preparation, native tests, sealing, hardware and publication are separate.
$ErrorActionPreference='Stop'
$root=(Resolve-Path "$PSScriptRoot/../../..").Path.Replace('\','/')
$task="$root/_artifacts/v1_ble_compact_preview_20261025"
$source="$task/app_source";$out="$task/app_build"
if(Test-Path -LiteralPath $out){throw 'Fresh compact-preview APP output required; do not recompile an existing object'}
function NeedHash([string]$Path,[string]$Expected){
 if((Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash -ne $Expected){throw "Checked input changed: $Path"}
}
$manifest="$source/source_manifest.json"
NeedHash $manifest '634F923B611C308FEC95578504A4A5DE0C0568561FB1C158C06FE3AD80EE41FB'
$m=Get-Content -LiteralPath $manifest -Raw|ConvertFrom-Json
if($m.parent_app_crc32 -ne 'CC50D8D2' -or $m.dependency_count -ne 159 -or
   $m.unchanged_linked_object_count -ne 74 -or $m.changed_files.Count -ne 2){throw 'Unexpected reviewed APP graph'}
NeedHash $m.parent_build_receipt $m.parent_build_receipt_sha256
NeedHash $m.link_response $m.link_response_sha256
NeedHash $m.parent_app_object $m.parent_app_object_sha256
NeedHash $m.scatter $m.scatter_sha256
NeedHash $m.reference_build_helper $m.reference_build_helper_sha256
$known=@{}
foreach($d in $m.source_dependencies){
 NeedHash $d.candidate_path $d.candidate_sha256
 $known[[IO.Path]::GetFullPath($d.candidate_path)]=$d.candidate_sha256
}
$objects=@{}
foreach($d in $m.unchanged_linked_objects){
 NeedHash $d.path $d.sha256
 $objects[[IO.Path]::GetFullPath($d.path)]=$d.sha256
}
if($objects.Count -ne 74){throw 'Exactly74 distinct unchanged linked objects required'}
foreach($d in $m.toolchain){NeedHash $d.path $d.sha256}
$via=[IO.File]::ReadAllText($m.link_response)
$oldApp=$m.parent_app_object.Replace('\','/')
if([regex]::Matches($via,[regex]::Escape($oldApp)).Count -ne 1){throw 'Old APP unit must occur exactly once'}
$linked=0
foreach($line in $via -split "`n"){
 if($line.Trim() -match '^"(.+\.o)"$'){
  $p=[IO.Path]::GetFullPath($Matches[1])
  if($p -eq [IO.Path]::GetFullPath($oldApp)){continue}
  if(!$objects.ContainsKey($p)){throw "Unreviewed linked object: $p"}
  $linked++
 }
}
if($linked -ne 74){throw 'Original CC50 link graph differs'}
$flags=@('-xc','-std=c11','--target=arm-arm-none-eabi','-mcpu=cortex-m33','-mfpu=fpv5-sp-d16','-mfloat-abi=hard','-c','-fno-rtti','-funsigned-char','-fshort-enums','-fshort-wchar','-gdwarf-4','-O3','-ffunction-sections','-Wno-packed','-Wno-nonportable-include-path')
foreach($inc in @("$source/Core/Inc","$source/Drivers/STM32U5xx_HAL_Driver/Inc","$root/Drivers/STM32U5xx_HAL_Driver/Inc","$root/Drivers/STM32U5xx_HAL_Driver/Inc/Legacy","$root/Drivers/CMSIS/Device/ST/STM32U5xx/Include","$root/Drivers/CMSIS/Include","$root/Firmware/V1/MDK-ARM/RTE/_USB384_NP_BGA_MMC","$root/Middlewares/Bosch/BME280_SensorAPI","$root/Middlewares/Bosch/BMM150_SensorAPI")){$flags+=@('-I',$inc)}
$compileArgs=$flags+@($m.defines|ForEach-Object{"-D$_"})
$compiler='C:/Keil_v5/ARM/ARMCLANG/bin'
$object="$out/xe_np_app.o";$name="$out/compact_preview"
New-Item -ItemType Directory -Path $out|Out-Null
# Dependency discovery is not an extra object build. Admit only this exact graph.
& "$compiler/armclang.exe" @compileArgs -M -MF "$out/app.d" "$source/Core/Src/xe_np_app.c"
if($LASTEXITCODE){throw 'Compact APP dependency discovery failed'}
$deps=([IO.File]::ReadAllText("$out/app.d") -replace '\\\r?\n',' ')
$deps=$deps.Substring($deps.IndexOf(': ')+2).Trim()-split '\s+'
$identities=@();$seen=@{}
foreach($d in $deps){
 $p=[IO.Path]::GetFullPath($d);$h=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash
 if(!$known.ContainsKey($p) -or $known[$p] -ne $h){throw "Unreviewed compact APP dependency: $p"}
 $identities+=@{path=$p;sha256=$h};$seen[$p]=$true
}
if($identities.Count -ne 159 -or $seen.Count -ne $known.Count){throw 'Reviewed compiler dependency set differs'}
& "$compiler/armclang.exe" @compileArgs "$source/Core/Src/xe_np_app.c" -o $object 2>&1|Tee-Object "$out/compile.log"
if($LASTEXITCODE){throw 'Compact APP compile failed'}
$oldName="$root/_artifacts/v1_lifecycle_release_20261025/app_build/lifecycle"
foreach($suffix in @('.map','.axf')){
 if([regex]::Matches($via,[regex]::Escape($oldName+$suffix)).Count -ne 1){throw 'Original output path must occur once'}
}
# Preserve scatter, layout, options and all74 objects; replace only these3 paths.
$via=$via.Replace($oldApp,$object).Replace("$oldName.map","$name.map").Replace("$oldName.axf","$name.axf")
[IO.File]::WriteAllText("$out/compact_preview.lnp",$via)
& "$compiler/armlink.exe" --via "$out/compact_preview.lnp" 2>&1|Tee-Object "$out/link.log"
if($LASTEXITCODE){throw 'Compact APP link failed; preserve the compiled object for diagnosis'}
& "$compiler/fromelf.exe" --i32combined --output "$out/compact_preview_UNSEALED.hex" "$name.axf"
if($LASTEXITCODE){throw 'Compact APP raw HEX export failed'}
foreach($d in $identities){NeedHash $d.path $d.sha256}
foreach($d in $m.unchanged_linked_objects){NeedHash $d.path $d.sha256}
foreach($d in $m.toolchain){NeedHash $d.path $d.sha256}
NeedHash $m.scatter $m.scatter_sha256
$report=[ordered]@{
 stage='APP_COMPACT_PREVIEW_INCREMENTAL_UNSEALED';parent_app_crc32='CC50D8D2'
 source_manifest=$manifest;source_manifest_sha256=(Get-FileHash -LiteralPath $manifest).Hash
 build_helper_sha256=(Get-FileHash -LiteralPath $PSCommandPath).Hash
 compiled_units=@('xe_np_app.c');source_dependencies=$identities;compiler_args=$compileArgs
 defines=$m.defines;toolchain=$m.toolchain;reused_objects=$m.unchanged_linked_objects
 scatter=$m.scatter;scatter_sha256=$m.scatter_sha256
 original_link_response_sha256=$m.link_response_sha256
 generated_link_response_sha256=(Get-FileHash -LiteralPath "$out/compact_preview.lnp").Hash
 object_sha256=(Get-FileHash -LiteralPath $object).Hash
 axf_sha256=(Get-FileHash -LiteralPath "$name.axf").Hash
 raw_hex_sha256=(Get-FileHash -LiteralPath "$out/compact_preview_UNSEALED.hex").Hash
 stack_report=(Select-String -LiteralPath "$name.htm" -Pattern 'Maximum Stack Usage =').Line
 resource_acceptance='Pending main link-map/seal review; old240B headroom is not new-build acceptance'
 hardware_access=$false;sealed=$false;published=$false
}
[IO.File]::WriteAllText("$out/build.json",($report|ConvertTo-Json -Depth 7),[Text.UTF8Encoding]::new($false))
'PASS one compact-preview APP compile/link;74 exact CC50 linked objects reused; raw unsealed output only'
