/* V1 UART-only configuration test, loaded into SRAM over a running original
 * image. Preserve the proven clocks, pin mux, UART baud and framing. Reset is
 * required to return to the original image. No DMA, flash or SD operations. */
#include "stm32u5xx.h"
typedef struct {
    uint32_t magic,version,state,request,completed;
    uint32_t wake_before,wake_after,route,pre_ms,gap_ms,timeout_ms,tx_len;
    uint32_t rx_len,errors,status,tick,tx_count,uart_cr1,uart_brr,uart_isr;
    uint32_t gpioa,gpiob,gpiof,systick_load;
    uint8_t tx[96],rx[512];
} Session;
#define S ((volatile Session *)0x20010000UL)
static uint32_t now(void) {
    if(SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk)S->tick++;
    return S->tick;
}
static void receive(void) {
    uint32_t isr=USART1->ISR;
    uint32_t error=isr&(USART_ISR_PE|USART_ISR_FE|USART_ISR_NE|USART_ISR_ORE);
    if(error){S->errors|=error;USART1->ICR=error;}
    if(isr&USART_ISR_RXNE_RXFNE){
        uint8_t b=(uint8_t)USART1->RDR;
        if(S->rx_len<sizeof(S->rx))S->rx[S->rx_len++]=b;
        else S->status=5;
    }
}
static void delay(uint32_t ms) {
    uint32_t start=now();
    while((uint32_t)(now()-start)<ms)receive();
}
static void exchange(void) {
    uint32_t start;
    S->state=2;S->status=S->rx_len=S->errors=S->tx_count=0;
    if(!S->tx_len||S->tx_len>sizeof(S->tx)||S->pre_ms>5000||S->gap_ms>100||S->timeout_ms>5000){S->status=4;return;}
    GPIOA->BSRR=1UL<<(S->wake_before?9:25);
    GPIOB->BSRR=1UL<<(S->route?9:25);
    delay(S->pre_ms);
    start=now();
    for(uint32_t i=0;i<S->tx_len;i++){
        while(!(USART1->ISR&USART_ISR_TXE_TXFNF)){
            receive();if((uint32_t)(now()-start)>5000){S->status=2;return;}
        }
        USART1->TDR=S->tx[i];S->tx_count++;
        receive();
        if(S->gap_ms)delay(S->gap_ms);
    }
    while(!(USART1->ISR&USART_ISR_TC)){
        receive();if((uint32_t)(now()-start)>5000){S->status=3;return;}
    }
    if(S->wake_after<=1)GPIOA->BSRR=1UL<<(S->wake_after?9:25);
    delay(S->timeout_ms);
    S->uart_isr=USART1->ISR;S->gpioa=GPIOA->IDR;
    S->gpiob=GPIOB->IDR;S->gpiof=GPIOF->IDR;
    if(!S->rx_len)S->status=1;
    delay(100);
}
__attribute__((noreturn)) void probe_entry(void){
    __disable_irq();
    uint32_t reload=SysTick->LOAD;
    SysTick->CTRL=0;
    for(uint32_t i=0;i<sizeof(Session)/4;i++)((volatile uint32_t*)S)[i]=0;
    S->magic=0x55535631;S->version=1;S->systick_load=reload;
    /* Prevent the legacy ISR from consuming replies or entering the TC loop. */
    USART1->CR1 &= ~(USART_CR1_RXNEIE_RXFNEIE|USART_CR1_TXEIE_TXFNFIE|
                    USART_CR1_TCIE|USART_CR1_PEIE|USART_CR1_IDLEIE);
    S->uart_cr1=USART1->CR1;S->uart_brr=USART1->BRR;
    SysTick->VAL=0;SysTick->CTRL=SysTick_CTRL_ENABLE_Msk|SysTick_CTRL_CLKSOURCE_Msk;
    S->wake_after=2;S->pre_ms=100;S->timeout_ms=1000;S->state=1;
    for(;;){
        (void)now();
        if(S->request!=S->completed){exchange();S->completed=S->request;S->state=3;}
    }
}
