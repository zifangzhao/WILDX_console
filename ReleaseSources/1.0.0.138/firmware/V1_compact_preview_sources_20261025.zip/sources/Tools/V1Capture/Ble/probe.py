"""Operate the V1 SRAM UART mailbox. Every invocation checks the physical UID."""
import argparse, json, pathlib, re, socket, struct, time
ROOT = pathlib.Path(__file__).resolve().parents[3]
OUT = ROOT / '_artifacts/ble_v1_20260910'
BASE = 0x20010000

class Debug:
    def __enter__(self):
        self.s = socket.create_connection(('127.0.0.1',6669), timeout=5)
        self.s.settimeout(15)
        uid = self.read(0x0bfa0700,3)
        if uid != [0x001e0018,0x5942500b,0x20313354]:
            self.s.close(); raise RuntimeError(f'Wrong MCU UID: {uid}')
        return self
    def __exit__(self,*args): self.s.close()
    def rpc(self,cmd):
        self.s.sendall(cmd.encode()+b'\x1a'); out=b''
        while b'\x1a' not in out:
            b=self.s.recv(4096)
            if not b: raise RuntimeError('Debug server disconnected')
            out+=b
        return out.split(b'\x1a')[0].decode().strip()
    def read(self,addr,count):
        return [int(x,0) for x in self.rpc(f'read_memory {addr} 32 {count}').split()]
    def write(self,addr,values):
        return self.rpc(f'write_memory {addr} 32 {{'+ ' '.join(str(x) for x in values)+'}')
    def start(self,image=None):
        image=pathlib.Path(image) if image else OUT/'probe/probe.axf'
        entry=int(re.search(r'Image Entry point : (0x[0-9a-fA-F]+)',
                  image.with_suffix('.map').read_text()).group(1),16)&~1
        print(self.rpc('reset halt'))
        print(self.rpc('load_image {'+str(image).replace('\\','/')+'}'))
        for cmd in ['reg msp 0x20020000','reg sp 0x20020000','reg control 0','reg primask 1',f'resume 0x{entry:x}']:
            print(self.rpc(cmd))
        deadline=time.monotonic()+5
        while self.read(BASE,3) != [0x424c5631,2,1]:
            if time.monotonic()>deadline: raise TimeoutError('RAM probe did not become ready')
            time.sleep(.05)
        print(self.read(BASE,20))
    def exchange(self,text,baud=115200,even=0,wake=0,route=0):
        if self.read(BASE,2)!=[0x424c5631,2]: raise RuntimeError('Version 2 RAM probe is not running')
        if even not in (0,1,2): raise ValueError('Parity must be 0=none, 1=even, 2=odd')
        payload=text.encode('ascii')
        if not 0<len(payload)<=96: raise ValueError('Command length')
        seq=self.read(BASE+16,1)[0]+1
        self.write(BASE+20,[baud,even,wake,route,len(payload)])
        self.write(BASE+80,struct.unpack('<24I',payload.ljust(96,b'\0')))
        self.write(BASE+12,[seq])
        deadline=time.monotonic()+6
        while self.read(BASE+16,1)[0]!=seq:
            if time.monotonic()>deadline: raise TimeoutError('RAM probe stalled')
            time.sleep(.05)
        w=self.read(BASE,108)
        raw=struct.pack('<64I',*w[44:108])[:w[10]]
        return dict(command=text,baud=baud,parity=['none','even','odd'][even],wake=wake,route=route,
                    status=w[11],errors=w[12],isr=hex(w[13]),rx_hex=raw.hex(),
                    reply=raw.decode('ascii',errors='replace'),gpioa=hex(w[15]),
                    gpiob=hex(w[16]),gpiof=hex(w[17]),elapsed_ms=w[14])

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['start','query','reset','scan'])
    p.add_argument('command',nargs='?',default='<RD_NAME>');p.add_argument('--wake',type=int,default=0)
    p.add_argument('--baud',type=int,default=115200);p.add_argument('--parity','--even',dest='even',type=int,choices=[0,1,2],default=0)
    p.add_argument('--route',type=int,default=0)
    p.add_argument('--image',type=pathlib.Path)
    a=p.parse_args()
    with Debug() as d:
        if a.action=='start': d.start(a.image)
        elif a.action=='reset': print(d.rpc('reset run'))
        else:
            if a.action=='scan':
                results=(d.exchange('<RD_NAME>',b,e,w) for b in [115200,9600,19200,38400,57600,230400,460800,921600,1000000,1500000,4800,2400,1200] for e in [0,1,2] for w in [0,1])
            else: results=[d.exchange(a.command,a.baud,a.even,a.wake,a.route)]
            for result in results:
                print(json.dumps(result),flush=True)
                with (OUT/'exchanges.jsonl').open('a',encoding='utf-8') as f: f.write(json.dumps(result)+'\n')
