"""UART-only queries using the original V1's clock/baud/pin configuration."""
import argparse,json,pathlib,re,struct,time
from probe import BASE,Debug

def start(d,image):
    entry=int(re.search(r'Image Entry point : (0x[0-9a-fA-F]+)',image.with_suffix('.map').read_text()).group(1),16)&~1
    # Deliberately halt rather than reset: preserve the running board setup.
    print(d.rpc('halt'))
    print(d.rpc('load_image {'+image.resolve().as_posix()+'}'))
    for cmd in ['reg msp 0x20020000','reg sp 0x20020000','reg control 0','reg primask 1',f'resume 0x{entry:x}']:
        print(d.rpc(cmd))
    deadline=time.monotonic()+3
    while d.read(BASE,3)!=[0x55535631,1,1]:
        if time.monotonic()>deadline:raise TimeoutError('Session did not start')
        time.sleep(.05)
    print(d.read(BASE,24))

def exchange(d,command,wake=0,route=0,pre_ms=100,gap_ms=0,after=2,timeout_ms=1000):
    return exchange_bytes(d,command.encode('ascii'),wake,route,pre_ms,gap_ms,after,timeout_ms)

def exchange_bytes(d,payload,wake=0,route=0,pre_ms=100,gap_ms=0,after=2,timeout_ms=1000):
    if d.read(BASE,2)!=[0x55535631,1]:raise RuntimeError('UART session is not active')
    payload=bytes(payload)
    if not 0<len(payload)<=96:raise ValueError('Command length')
    seq=d.read(BASE+16,1)[0]+1
    d.write(BASE+20,[wake,after,route,pre_ms,gap_ms,timeout_ms,len(payload)])
    d.write(BASE+96,struct.unpack('<24I',payload.ljust(96,b'\0')))
    readback=struct.pack('<24I',*d.read(BASE+96,24))[:len(payload)]
    if readback!=payload:raise RuntimeError('TX mailbox byte mismatch')
    d.write(BASE+12,[seq])
    deadline=time.monotonic()+pre_ms/1000+gap_ms/1000*len(payload)+timeout_ms/1000+3
    while d.read(BASE+16,1)[0]!=seq:
        if time.monotonic()>deadline:raise TimeoutError('UART exchange stalled')
        time.sleep(.02)
    w=d.read(BASE,176)
    raw=struct.pack('<128I',*w[48:176])[:w[12]]
    return dict(command=payload.decode('ascii',errors='backslashreplace'),tx_hex=payload.hex(),
        tx_readback_hex=readback.hex(),wake=wake,route=route,pre_ms=pre_ms,gap_ms=gap_ms,
        wake_after=after,timeout_ms=timeout_ms,rx_hex=raw.hex(),reply=raw.decode('ascii',errors='replace'),
        errors=w[13],status=w[14],tick=w[15],tx_count=w[16],uart_cr1=hex(w[17]),
        uart_brr=w[18],uart_isr=hex(w[19]),gpioa=hex(w[20]),gpiob=hex(w[21]),gpiof=hex(w[22]))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['start','query'])
    p.add_argument('value');p.add_argument('--wake',type=int,default=0);p.add_argument('--route',type=int,default=0)
    p.add_argument('--after',type=int,default=2);p.add_argument('--pre',type=int,default=100)
    p.add_argument('--gap',type=int,default=0);p.add_argument('--timeout',type=int,default=1000)
    p.add_argument('--hex',action='store_true',help='Interpret query value as explicit raw hexadecimal bytes')
    a=p.parse_args()
    with Debug() as d:
        if a.action=='start':start(d,pathlib.Path(a.value))
        else:
            payload=bytes.fromhex(a.value) if a.hex else a.value.encode('ascii')
            print(json.dumps(exchange_bytes(d,payload,a.wake,a.route,a.pre,a.gap,a.after,a.timeout)))
