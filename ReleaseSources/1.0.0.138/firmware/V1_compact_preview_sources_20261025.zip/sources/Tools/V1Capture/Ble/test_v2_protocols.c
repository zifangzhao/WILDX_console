#include <assert.h>
#include <stdio.h>
#include "xe_np_ble_rescue.h"
#include "np_ble_schedule.h"
#include "np_ble_preview.h"
static uint8_t raw[61440],wire[64],body[224];
static uint8_t sample(uint64_t tick)
{
    unsigned sf=(unsigned)(tick/780U)%12U,f=(unsigned)(tick%780U)/60U;
    unsigned word=(unsigned)(tick%60U)/10U,bit=9U-(unsigned)(tick%10U);
    uint8_t value=0;
    for(unsigned adc=0;adc<32;adc++){
        unsigned w=adc<30?adc%5:adc-30,line=adc<30?adc/5+1:7;
        if(w==word && (((adc*12+(f?f-1:sf))>>bit)&1))value|=(uint8_t)(1U<<line);
    }
    return value;
}
static void fill(uint64_t first,unsigned packed,unsigned probe)
{
    memset(raw,0xcc,sizeof(raw));unsigned ticks=packed?30720:61440;
    for(unsigned i=0;i<ticks;i++){
        unsigned at=(i&3U)*15360U+(i>>2)*(packed?2U:1U)+(packed?probe-1U:0U);
        raw[at]=sample(first+i);
    }
}
static void request(unsigned kind,unsigned channel,unsigned band,unsigned probe)
{
    memset(wire,0,sizeof(wire));uint32_t w[]={NP1_PREVIEW_MAGIC,1,kind,1,probe,channel,0,42,band};
    for(unsigned i=0;i<9;i++)xe_np_online_put(wire+4*i,w[i]);
    xe_np_online_put(wire+60,xe_np_online_crc(wire));
}
static void preview(void)
{
    const unsigned channels[]={0,24,25,26,27,28,29,30,31,32,33,34,35,36,383};
    for(unsigned packed=0;packed<=1;packed++)for(unsigned probe=1;probe<=(packed?2U:3U);probe++)
    for(unsigned band=0;band<2;band++)for(unsigned ci=0;ci<sizeof(channels)/sizeof(channels[0]);ci++){
        unsigned ch=channels[ci],adc=(ch/24U)*2U+(ch&1U),slot=(ch%24U)/2U;
        NpBlePreview p={0};request(2,ch,band,probe);
        assert(np_ble_preview_request(&p,wire,42,15000,7,1,100)&&p.active);
        uint64_t first=0;unsigned ticks=packed?30720:61440;
        while(!p.ready){fill(first,packed,probe);np_ble_preview_tap(&p,raw,first,ticks,packed,probe,0);first+=ticks;assert(first<1000000);}
        np_ble_preview_fragment(&p,body);
        assert(xe_np_online_word(body)==NP1_PREVIEW_MAGIC && (xe_np_online_word(body+24)&65535U)==65535U);
        unsigned line=adc<30?adc/5+1:7;
        for(unsigned n=0;n<16;n++){
            unsigned v=0;for(unsigned b=0;b<10;b++)v=(v<<1)|((body[32+n*10+b]>>line)&1);
            assert(v==adc*12+slot);
        }
        np_ble_preview_retire(&p);request(3,ch,band,probe);
        assert(np_ble_preview_request(&p,wire,42,15000,7,1,200)&&!p.active);
    }
    NpBlePreview p={0};request(0,0,0,1);assert(np_ble_preview_request(&p,wire,42,15000,7,1,0));
    fill(0,0,1);np_ble_preview_tap(&p,raw,0,61440,0,1,0);assert(p.ready&&!p.active);
    for(unsigned at=0;at<1560;at++)assert(p.data[at]==sample(at));
    np_ble_preview_stop(&p);request(2,24,0,1);np_ble_preview_request(&p,wire,42,30000,7,1,0);
    for(unsigned i=0;i<60;i++){fill((uint64_t)i*61440,0,1);np_ble_preview_tap(&p,raw,(uint64_t)i*61440,61440,0,1,1);}
    assert(!p.ready && p.dropped); /* no synthetic samples under pressure */
}
int main(void)
{
    XE_NP_BleRescue r={0};uint8_t reset[]={0x3c,0xab,0xba,0x3e};
    for(unsigned i=0;i<4;i++)assert(XE_NP_BleRescue_Feed(&r,reset[i],i,r.at==1?2:0)==(i==3));
    for(unsigned length=2;length<=519;length++){
        r.at=0;XE_NP_BleRescue_Feed(&r,0x3c,1000,0);XE_NP_BleRescue_Feed(&r,0xb8,1000,length);
        for(unsigned i=0;i<length-1;i++)assert(!XE_NP_BleRescue_Feed(&r,reset[i%4],1000,0));
        assert(!XE_NP_BleRescue_Feed(&r,0x3e,1000,0));
    }
    XE_NP_OnlineClock c={0};c.valid=1;c.utc_us=1790550000000000ULL;c.tick=0xfffffff0U;
    NpBleSchedule s={0};assert(!np_ble_schedule_arm(&s,&c,c.utc_us+1000,c.tick));
    /* Bring-up can rebase start after the service captured its old 'now'. */
    assert(!np_ble_start_expired(&s,1000U,1003U));
    assert(!np_ble_start_expired(&s,0xfffffffeU,2U));
    assert(!np_ble_start_expired(&s,4990U,0xfffffff6U));
    assert(np_ble_start_expired(&s,4991U,0xfffffff6U));
    assert(np_ble_schedule_arm(&s,&c,c.utc_us+60000000,c.tick));
    assert(!np_ble_start_expired(&s,s.tick-1,c.tick));
    assert(!np_ble_start_expired(&s,s.tick+5,c.tick));
    assert(np_ble_start_expired(&s,s.tick+6,c.tick));
    assert(!np_ble_schedule_gate(&s,s.tick-1));assert(np_ble_schedule_gate(&s,s.tick+5)==1);
    assert(np_ble_schedule_arm(&s,&c,c.utc_us+60000000,c.tick));assert(np_ble_schedule_gate(&s,s.tick+6)==-1);
    preview();puts("PASS rescue binary boundaries, schedule rollover/late rejection, AP/LFP preview channels 24-36/all probes/packed ownership/pressure");
    return 0;
}
