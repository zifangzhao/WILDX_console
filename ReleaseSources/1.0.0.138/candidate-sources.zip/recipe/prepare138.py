from pathlib import Path
import hashlib,json,shutil,xml.etree.ElementTree as ET

repo=Path(__file__).resolve().parents[2];root=Path(__file__).resolve().parent
prior=repo/'_artifacts/download_restore_20261025/build137';build=root/'build138'
assert not build.exists(), 'Do not replace a prepared build'
source=build/'changed-sources';source.mkdir(parents=True)
binary=build/'compile-bin';binary.mkdir()
for p in (prior/'compile-bin').iterdir():
 if p.is_file() and p.suffix.lower() in ('.dll','.config'):shutil.copy2(p,binary/p.name)
ns='http://schemas.microsoft.com/developer/msbuild/2003';ET.register_namespace('',ns)
tree=ET.parse(prior/'ui-only.targets')
names={'NpV1BleProtocol.cs','NpV1BlePreviewForm.cs','NpBleConnection.cs','NpBleWire.cs'}
ledger=json.loads((root/'source-ready.json').read_text())
expected={Path(x['path']).name:x['sha256'] for x in ledger['files']}
changed=[]
for node in tree.findall('.//{'+ns+'}Compile'):
 p=Path(node.get('Include',''));name=p.name
 if name in names:
  canonical=repo/'USB512_interface/USB512_interface/Ble'/name
  assert hashlib.sha256(canonical.read_bytes()).hexdigest().upper()==expected[name]
  shutil.copy2(canonical,source/name);node.set('Include',str(source/name));changed.append(name)
 elif name=='AssemblyInfo.cs':
  shutil.copy2(repo/'USB512_interface/USB512_interface/Properties/AssemblyInfo.cs',source/name);node.set('Include',str(source/name))
assert set(changed)==names
for n in tree.findall('.//{'+ns+'}WriteLinesToFile'):n.set('File',str(build/Path(n.get('File')).name))
for n in tree.findall('.//{'+ns+'}Copy'):n.set('DestinationFiles',str(source/'AssemblyInfo.cs'))
ET.indent(tree,space='  ');tree.write(build/'ui-only.targets',encoding='utf-8',xml_declaration=True)
print('Prepared exact137 plus four frozen V1 preview inputs; SDK unchanged.')
