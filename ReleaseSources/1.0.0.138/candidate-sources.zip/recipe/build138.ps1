$ErrorActionPreference='Stop'
$taskRepo='D:/Code/WILDX_console/WILDX_console'
$taskBuild=Join-Path $taskRepo '_artifacts/v1_ble_compact_20261025/build138'
if((Get-Content "$taskRepo/USB512_interface/USB512_interface/Properties/AssemblyInfo.cs" -Raw) -notmatch 'AssemblyVersion\("1\.0\.0\.137"\)'){throw 'Expected137 before the single138 product build'}
& 'C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/MSBuild/Current/Bin/MSBuild.exe' "$taskRepo/USB512_interface/USB512_interface/WILDX_console.csproj" /nologo /v:minimal '/t:Compile;CopyFilesToOutputDirectory' /p:Configuration=Release /p:BuildProjectReferences=false /p:GenerateNsisInstaller=false "/p:OutputPath=$taskBuild/compile-bin/" "/p:IntermediateOutputPath=$taskBuild/compile-obj/" "/p:CustomBeforeMicrosoftCSharpTargets=$taskBuild/ui-only.targets" 2>&1 | Tee-Object "$taskBuild/gui-build.log"
if($LASTEXITCODE){throw '138 compact preview compile failed'}
