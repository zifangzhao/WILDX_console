from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parent;repo=root.parents[1];build=root/'build138'
prior=repo/'_artifacts/download_restore_20261025/build137'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def inputs(folder,name):return [Path(s) for s in (folder/name).read_text(encoding='utf-8-sig').splitlines() if s.strip()]
before={p.name:sha(p) for p in inputs(prior,'compile-inputs.txt')}
files=inputs(build,'compile-inputs.txt');after={p.name:sha(p) for p in files}
assert len(after)==len(files) and set(before)==set(after)
changed=sorted(n for n in before if before[n]!=after[n])
assert changed==['AssemblyInfo.cs','NpBleConnection.cs','NpBleWire.cs','NpV1BlePreviewForm.cs','NpV1BleProtocol.cs'],changed
exe=build/'compile-bin/WILDX_console.exe';sdk=build/'compile-bin/NpV2SdDatExport.dll'
assert sha(sdk)=='79ADB2EA8AE32A0446EB72D5906F917251F94C89FC905AA69F942E365850F4AF'
archive=root/'candidate138-sources.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,'source/'+p.name)
 for name in ['prepare138.py','build138.ps1','receipt138.py','source-ready.json','Actual138Checks.cs','BleCompactSuite.cs']:
  z.write(root/name,'recipe/'+name)
 for name in ['compile-inputs.txt','reference-inputs.txt','ui-only.targets','gui-build.log']:z.write(build/name,'build/'+name)
 for name in ['Tests/NpV1CompactPreviewTests.cs','Tests/NpBleWorkflowTests.cs','Tests/NpPreviewGainTests.cs','Tests/Fixtures/V1CompactPreview/ap-lfp.bin','test_v1_compact_preview.ps1']:z.write(repo/name,'checks/'+name)
 for name in ['source-checks.log','checks/actual138.log']:z.write(root/name,'checks/'+name)
receipt={'version':'1.0.0.138','baseline':'1.0.0.137','gui_sha256':sha(exe),'sdk_sha256':sha(sdk),'new_product_compilations':1,'sdk_compilations':0,'added_sources':[],'changed_sources':changed,'source_archive_sha256':sha(archive),'sources':[{'path':str(p),'sha256':sha(p)} for p in files],'references':[{'path':str(p),'sha256':sha(p)} for p in inputs(build,'reference-inputs.txt')],'software_verification':{'isolated_source_assertions':13336,'actual_assembly_compact_assertions':139,'actual_assembly_legacy_assertions':4251,'actual_assembly_v1_gain_layout_assertions':18},'hardware_acceptance':'Pending firmware owner; no hardware access by WILDX','scope':'Capability-negotiated V1 compact four-channel preview; legacy kind2 retained. Shared framing and admission edits confined to V1. SDK, SD export, USB recording and V2 sources unchanged. UART baud unchanged.'}
(root/'build138-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:receipt[k] for k in ['version','gui_sha256','sdk_sha256','changed_sources','source_archive_sha256']}))
