#include "xe_np_imu_grid_phase_bound.h"
#include <limits.h>

#define COUNTER_PER_SECOND 1000000U
#define PERIOD_US 800U
static int add(uint64_t a,uint64_t b,uint64_t *out)
{if(a>UINT64_MAX-b)return 0;*out=a+b;return 1;}
static int mul(uint64_t a,uint64_t b,uint64_t *out)
{if(b && a>UINT64_MAX/b)return 0;*out=a*b;return 1;}
static void unknown(XE_NP_GridPhaseBound *out)
{out->lower_numerator=INT64_MIN;out->upper_numerator=INT64_MIN;
 out->denominator=0U;out->maximum_relative_jitter_ticks=UINT32_MAX;}
int XE_NP_GridPhaseBound_AfterSource(const XE_NP_GridPhaseInput *x)
{
    uint64_t ticks,slot,grid_low,source_high,relative;
    if(!x || x->continuous_clock_qualified!=1U ||
       (x->source_hz!=12000000U && x->source_hz!=24000000U &&
        x->source_hz!=32000000U && x->source_hz!=48000000U) ||
       x->first_relative_slot==UINT64_MAX || x->source_origin_tick==UINT64_MAX ||
       x->reference_tick==UINT64_MAX || x->source_before_us==0U ||
       x->source_before_us>UINT32_MAX || x->source_after_us<x->source_before_us ||
       x->source_after_us-x->source_before_us>100U || x->timer_start_before_us==0U ||
       x->timer_start_after_us<x->timer_start_before_us ||
       x->max_copy_lateness_us>=PERIOD_US ||
       x->timer_start_after_us-x->timer_start_before_us>x->max_copy_lateness_us)return -1;
    if(!add(x->source_origin_tick,x->reference_tick,&ticks) ||
       !add(x->first_relative_slot,1U,&slot) || !mul(slot,PERIOD_US,&slot) ||
       !add(x->timer_start_before_us-1U,slot,&grid_low) ||
       !add(x->source_after_us,1U,&source_high))return -1;
    if(grid_low<source_high)return 0;
    if(!mul(grid_low-source_high,x->source_hz/COUNTER_PER_SECOND,&relative))return -1;
    return relative>ticks?1:0;
}
int XE_NP_GridPhaseBound_Compute(const XE_NP_GridPhaseInput *x,XE_NP_GridPhaseBound *out)
{
    uint64_t factor,ticks,slot,grid_low,grid_high,source_low,source_high;
    uint64_t low_us,high_us,low_tick,high_tick,jitter;
    if(!out)return 0;unknown(out);
    if(!x || x->continuous_clock_qualified!=1U || x->copy_bound_qualified!=1U ||
       (x->source_hz!=12000000U && x->source_hz!=24000000U &&
        x->source_hz!=32000000U && x->source_hz!=48000000U) ||
       x->max_copy_lateness_us>=PERIOD_US || x->first_relative_slot==UINT64_MAX ||
       x->source_origin_tick==UINT64_MAX || x->reference_tick==UINT64_MAX ||
       x->source_before_us==0U || x->source_before_us>UINT32_MAX ||
       x->source_after_us<x->source_before_us ||
       x->source_after_us-x->source_before_us>100U ||
       x->timer_start_before_us==0U || x->timer_start_after_us<x->timer_start_before_us ||
       x->timer_start_after_us-x->timer_start_before_us>x->max_copy_lateness_us)return 0;
    factor=x->source_hz/COUNTER_PER_SECOND;
    /* Source ROOT is first DMA word; NPSTART reference follows origin + tick. */
    if(!add(x->source_origin_tick,x->reference_tick,&ticks) ||
       !add(x->first_relative_slot,1U,&slot) || !mul(slot,PERIOD_US,&slot))return 0;
    /* Widen both sampled start brackets by one counter tick. The post-copy
     * counter read contributes one more upper tick of read quantization. */
    if(!add(x->timer_start_before_us-1U,slot,&grid_low) ||
       !add(x->timer_start_after_us,slot,&grid_high) ||
       !add(grid_high,x->max_copy_lateness_us,&grid_high) || !add(grid_high,2U,&grid_high) ||
       !add(x->source_after_us,1U,&source_high))return 0;
    source_low=x->source_before_us-1U;
    if(grid_low<source_high || grid_high<source_low)return 0;
    low_us=grid_low-source_high;high_us=grid_high-source_low;
    if(!mul(low_us,factor,&low_tick) || !mul(high_us,factor,&high_tick) ||
       low_tick<ticks || high_tick<ticks)return 0;
    low_tick-=ticks;high_tick-=ticks;
    if(low_tick>INT64_MAX || high_tick>INT64_MAX || high_tick<low_tick ||
       !mul((uint64_t)x->max_copy_lateness_us+1U,factor,&jitter) || jitter>=UINT32_MAX)return 0;
    out->lower_numerator=(int64_t)low_tick;out->upper_numerator=(int64_t)high_tick;
    out->denominator=1U;out->maximum_relative_jitter_ticks=(uint32_t)jitter;return 1;
}

int XE_NP_GridPhaseBound_First(const XE_NP_GridPhaseInput *x,
    uint64_t before,uint64_t after,XE_NP_GridPhaseBound *out)
{
    uint64_t source_high,copy_high,ticks,lo,hi,factor;
    if(!out)return 0;unknown(out);
    if(!x || x->continuous_clock_qualified!=1U ||
       (x->source_hz!=12000000U && x->source_hz!=24000000U &&
        x->source_hz!=32000000U && x->source_hz!=48000000U) ||
       !x->source_before_us || x->source_before_us>UINT32_MAX ||
       x->source_after_us<x->source_before_us || x->source_after_us-x->source_before_us>100U ||
       !before || after<before || x->max_copy_lateness_us>=PERIOD_US ||
       after-before>x->max_copy_lateness_us ||
       !add(x->source_after_us,1U,&source_high) || !add(after,1U,&copy_high) ||
       !add(x->source_origin_tick,x->reference_tick,&ticks))return 0;
    if(before-1U<source_high || copy_high<x->source_before_us-1U)return 0;
    factor=x->source_hz/COUNTER_PER_SECOND;
    if(!mul((before-1U)-source_high,factor,&lo) ||
       !mul(copy_high-(x->source_before_us-1U),factor,&hi) ||
       lo<ticks || hi<ticks)return 0;
    lo-=ticks;hi-=ticks;
    if(lo>INT64_MAX || hi>INT64_MAX || hi<lo)return 0;
    out->lower_numerator=(int64_t)lo;out->upper_numerator=(int64_t)hi;
    out->denominator=1U;out->maximum_relative_jitter_ticks=UINT32_MAX;return 1;
}
