#include "xe_np_imu_grid_runtime.h"
#include "xe_np_imu_grid_timer.h"
#include "xe_np_imu_grid_diag.h"
#include <string.h>
#if defined(XE_NP_GRID_RUNTIME_FAKE)
#include "imu_grid_runtime_fake.h"
#else
#include "xe_np_hal.h"
#include "xe_np_np2_sd_fine_clock.h"
#include "xe_np_sensors_port.h"
#if !NP_FINE_COUNTER64_ENABLE
#error Grid runtime requires the already-qualified continuous64 source clock
#endif
#endif

enum {GRID_IDLE=0U,GRID_PREPARED=1U,GRID_RUNNING=2U,GRID_STOPPED=3U,GRID_FAULT=4U};
static void increment(volatile uint32_t *v){if(*v!=UINT32_MAX)++*v;}
static int bound(const XE_NP_GridRuntime *r,const XE_NP_Np2SdFinePoint64 *p)
{return p->counter_hz==1000000U && p->domain==r->domain &&
        p->generation==r->generation && p->source_epoch==r->epoch;}
typedef struct {
    XE_NP_Np2SdFinePoint64 before,after;
    XE_NP_GridDecision decision;
    int32_t values[9];
    uint32_t ag,mag,valid,error;
} GridSlot;
#if defined(_MSC_VER)
#define XE_NP_GRID_SLOT_INLINE static __forceinline
#else
#define XE_NP_GRID_SLOT_INLINE static inline __attribute__((always_inline))
#endif
XE_NP_GRID_SLOT_INLINE int prepare_slot(XE_NP_GridRuntime *r,GridSlot *slot)
{
    XE_NP_GridEvent event;const XE_NP_SensorSnapshot *s;
    if(r->state!=GRID_RUNNING)return 0;
    /* IRQ-safe bounded read, no qualification scan, RTC or HAL tick. A
     * transient failed read is reconciled as missing on a later good slot. */
    if(!XE_NP_Np2SdFineClock_Read64Irq(0U,&slot->before)){increment(&r->counter_faults);return 0;}
    if(!bound(r,&slot->before)){increment(&r->counter_faults);r->state=GRID_FAULT;return 0;}
    event=XE_NP_GridSchedule_Service(&r->schedule,slot->before.counter,&slot->decision);
    if(event==XE_NP_GRID_INVALID){increment(&r->scheduler_faults);r->state=GRID_FAULT;return 0;}
    if(event!=XE_NP_GRID_SAMPLE)return 0;
    /* Sensor foreground publishes the inactive buffer then flips its index.
     * Its active snapshot cannot change while this IRQ preempts foreground. */
    s=XE_NP_SensorsPort_GetSnapshot();
    if(!s){r->schedule.missed++;return 0;}
    for(uint32_t i=0U;i<3U;i++){
        slot->values[i]=s->accel_micro_g[i];slot->values[i+3U]=s->gyro_milli_dps[i];
        slot->values[i+6U]=s->mag_nano_tesla[i];
    }
    slot->ag=s->imu_sequence;slot->mag=s->mag_sequence;slot->valid=s->valid;slot->error=s->error[0];
    /* Admission alone is not a bound: a higher-priority NP interrupt can
     * preempt the copy. Check again before publishing; never retain the
     * counter per slot or pretend a late copy occurred at the boundary. */
    if(!XE_NP_Np2SdFineClock_Read64Irq(0U,&slot->after)){
        increment(&r->counter_faults);r->schedule.missed++;return 0;
    }
    if(!bound(r,&slot->after) || slot->after.counter<slot->before.counter){
        increment(&r->counter_faults);r->schedule.missed++;r->state=GRID_FAULT;return 0;
    }
    if(slot->after.counter-slot->before.counter>(uint64_t)(r->max_lateness-slot->decision.lateness_us)){
        increment(&r->late_copies);r->schedule.missed++;return 0;
    }
    return 1;
}
static void queue_full(XE_NP_GridRuntime *r,const GridSlot *slot)
{
#if XE_NP_GRID_STARTUP_DIAG
    if(!xe_np_grid_startup_diag.full.valid)
        XE_NP_GridDiag_QueueFull(&xe_np_grid_startup_diag,slot->decision.ordinal,slot->before.counter,
            r->queue.head,r->queue.tail,r->queue.dropped);
#else
    (void)r;(void)slot;
#endif
}
static int queue_slot(XE_NP_GridRuntime *r,const GridSlot *slot)
{
    if(XE_NP_ImuGridQueue_Push(&r->queue,slot->decision.ordinal,slot->values,
        slot->values+3,slot->values+6,slot->ag,slot->mag,slot->valid,slot->error)){
        increment(&r->accepted);return 1;
    }
    queue_full(r,slot);return 0;
}
static void on_slot_steady(void *context)
{
    XE_NP_GridRuntime *r=context;GridSlot slot;
    if(prepare_slot(r,&slot))(void)queue_slot(r,&slot);
}
static void on_slot_first(void *context)
{
    XE_NP_GridRuntime *r=context;GridSlot slot;
    if(!prepare_slot(r,&slot) || !queue_slot(r,&slot))return;
    if(!XE_NP_GridTimer_SwitchCurrentCallback(on_slot_steady,r)){
        r->state=GRID_FAULT;return;
    }
    r->first_accepted.ordinal=slot.decision.ordinal;
    r->first_accepted.before=slot.before.counter;r->first_accepted.after=slot.after.counter;
    r->first_accepted.domain=r->domain;r->first_accepted.generation=r->generation;
    r->first_accepted.epoch=r->epoch;__DMB();r->first_accepted.valid=1U;
}
void XE_NP_GridRuntime_Init(XE_NP_GridRuntime *r)
{
    /* Contract: r has no timer/consumer owner when this function is called. */
    if(r){memset(r,0,sizeof(*r));r->terminal_exclusive=UINT64_MAX;}
}
int XE_NP_GridRuntime_Prepare(XE_NP_GridRuntime *r,uint32_t domain,
    uint32_t generation,uint32_t epoch,uint32_t max_lateness_us)
{
    XE_NP_Np2SdFinePoint64 p;
    if(!r || (r->state!=GRID_IDLE && r->state!=GRID_STOPPED) ||
       r->queue.head!=r->queue.tail || !domain || !generation || !epoch ||
       max_lateness_us>=XE_NP_GRID_PERIOD_US)return 0;
    if(!XE_NP_Np2SdFineClock_Read64Irq(0U,&p) || p.counter_hz!=1000000U ||
       p.domain!=domain || p.generation!=generation || p.source_epoch!=epoch)return 0;
    if(!XE_NP_GridTimer_Prepare(on_slot_first,r))return 0;
    XE_NP_ImuGridQueue_Reset(&r->queue);memset(&r->schedule,0,sizeof(r->schedule));
    r->domain=domain;r->generation=generation;r->epoch=epoch;r->max_lateness=max_lateness_us;
    r->counter_faults=r->scheduler_faults=r->late_copies=r->accepted=0U;r->terminal_known=0U;
    r->terminal_exclusive=UINT64_MAX;r->start_before=r->start_after=0U;
    memset(&r->first_accepted,0,sizeof(r->first_accepted));
    r->state=GRID_PREPARED;return 1;
}
int XE_NP_GridRuntime_Start(XE_NP_GridRuntime *r,uint64_t first_ordinal)
{
    XE_NP_Np2SdFinePoint64 before,after;uint32_t key;int ok=0;
    if(!r || r->state!=GRID_PREPARED || __get_IPSR())return 0;
    key=__get_PRIMASK();__disable_irq();
    if(XE_NP_Np2SdFineClock_Read64Irq(0U,&before) && bound(r,&before) &&
       XE_NP_GridTimer_Start() && XE_NP_Np2SdFineClock_Read64Irq(0U,&after) && bound(r,&after) &&
       after.counter>=before.counter && after.counter-before.counter<=r->max_lateness &&
       before.counter<=UINT64_MAX-XE_NP_GRID_PERIOD_US &&
       XE_NP_GridSchedule_Init(&r->schedule,before.counter+XE_NP_GRID_PERIOD_US,
                               first_ordinal,r->max_lateness)){
        r->start_before=before.counter;r->start_after=after.counter;
        r->state=GRID_RUNNING;__DMB();ok=1;
    }else{
        XE_NP_GridTimer_Release();r->state=GRID_STOPPED;
    }
    __set_PRIMASK(key);return ok;
}
void XE_NP_GridRuntime_ClockFault(XE_NP_GridRuntime *r)
{
    uint32_t key;if(!r || __get_IPSR())return;
    key=__get_PRIMASK();__disable_irq();
    if(r->state==GRID_RUNNING){increment(&r->counter_faults);r->state=GRID_FAULT;__DMB();}
    __set_PRIMASK(key);
}
void XE_NP_GridRuntime_Stop(XE_NP_GridRuntime *r,int cutoff_valid,uint64_t cutoff_us)
{
    uint32_t key;uint64_t end,tail_missing;
    if(!r || __get_IPSR())return;
    key=__get_PRIMASK();__disable_irq();
    if(r->state==GRID_PREPARED || r->state==GRID_RUNNING || r->state==GRID_FAULT){
        XE_NP_GridTimer_Release();
        if(r->state==GRID_RUNNING && cutoff_valid &&
           XE_NP_GridSchedule_Stop(&r->schedule,cutoff_us,&end,&tail_missing)){
            r->terminal_exclusive=end;r->terminal_known=1U;
        }else{r->terminal_exclusive=UINT64_MAX;r->terminal_known=0U;}
        r->state=GRID_STOPPED;
    }
    __set_PRIMASK(key);
}
int XE_NP_GridRuntime_Pop(XE_NP_GridRuntime *r,XE_NP_ImuGridSlot *out)
{return r && out?XE_NP_ImuGridQueue_Pop(&r->queue,out):0;}
void XE_NP_GridRuntime_GetStatus(XE_NP_GridRuntime *r,XE_NP_GridRuntimeStatus *out)
{
    uint32_t key;if(!r || !out)return;
    key=__get_PRIMASK();__disable_irq();
    out->state=r->state;out->counter_faults=r->counter_faults;
    out->scheduler_faults=r->scheduler_faults;out->late_copies=r->late_copies;out->accepted=r->accepted;
    out->queue_dropped=r->queue.dropped;out->scheduler_missing=r->schedule.missed;
    out->terminal_exclusive=r->terminal_exclusive;out->terminal_known=r->terminal_known;
    out->start_before=r->start_before;out->start_after=r->start_after;
    __set_PRIMASK(key);
}
int XE_NP_GridRuntime_GetFirstAccepted(XE_NP_GridRuntime *r,
    XE_NP_GridRuntimeFirstAccepted *out)
{
    uint32_t key;
    if(!r || !out)return 0;
    key=__get_PRIMASK();__disable_irq();
    if(!r->first_accepted.valid){__set_PRIMASK(key);return 0;}
    __DMB();*out=r->first_accepted;__set_PRIMASK(key);return 1;
}
