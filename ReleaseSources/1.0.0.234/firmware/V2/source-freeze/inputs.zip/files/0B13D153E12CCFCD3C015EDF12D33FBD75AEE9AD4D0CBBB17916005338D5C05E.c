#include "xe_np_np2_sd_fine_clock.h"
#include "xe_np_board.h"
#if XE_NP_NP2_FIRST_SYNC_ENABLE && XE_NP_NP2_DUAL_SD_APP_ENABLE
#include "xe_np_hal.h"
#include <string.h>
/* TIM5 has no native NP/ADC/camera owner. No pin, channel, IRQ or DMA use.
 * RM0456 Rev4 55.4.28/Table566: timer runs in plain Sleep, stops in Stop.
 * The compiled APP admits only plain WFI; no STOP continuity is inferred. */
typedef struct {
    volatile uint32_t domain;
    uint32_t serial,owned,old_sleep,psc,generation,epoch;
    volatile uint32_t context;
    uint32_t hclk,cfgr1,cfgr2,pll,div,frac;
} SdFineClock;
static SdFineClock clock_state;
#ifndef XE_NP_SD_FINE_COUNTER
#define XE_NP_SD_FINE_COUNTER() (TIM5->CNT)
#endif
#define FINE_CFGR1_MASK (RCC_CFGR1_SW|RCC_CFGR1_SWS)
#define FINE_CFGR2_MASK (RCC_CFGR2_HPRE|RCC_CFGR2_PPRE1)
static int root_allowed(void)
{
    uint32_t sw=RCC->CFGR1&RCC_CFGR1_SWS;
    return !(CoreDebug->DHCSR&CoreDebug_DHCSR_C_DEBUGEN_Msk) &&
        !(DBGMCU->APB1FZR1&DBGMCU_APB1FZR1_DBG_TIM5_STOP) &&
        !(SCB->SCR&(SCB_SCR_SLEEPDEEP_Msk|SCB_SCR_SLEEPONEXIT_Msk)) &&
        (RCC->CR&RCC_CR_HSERDY) &&
        (sw==RCC_SYSCLKSOURCE_STATUS_HSE ||
         (sw==RCC_SYSCLKSOURCE_STATUS_PLLCLK &&
          (RCC->CR&RCC_CR_PLL1RDY) &&
          (RCC->PLL1CFGR&RCC_PLL1CFGR_PLL1SRC)==RCC_PLLSOURCE_HSE));
}
static int qualified(void)
{
    return clock_state.domain && clock_state.owned && root_allowed() &&
        (RCC->APB1ENR1&RCC_APB1ENR1_TIM5EN) &&
        (RCC->APB1SMENR1&RCC_APB1SMENR1_TIM5SMEN) &&
        !(RCC->APB1RSTR1&RCC_APB1RSTR1_TIM5RST) &&
        (RCC->CFGR1&FINE_CFGR1_MASK)==clock_state.cfgr1 &&
        (RCC->CFGR2&FINE_CFGR2_MASK)==clock_state.cfgr2 &&
        RCC->PLL1CFGR==clock_state.pll && RCC->PLL1DIVR==clock_state.div &&
        RCC->PLL1FRACR==clock_state.frac && SystemCoreClock==clock_state.hclk &&
        TIM5->CR1==TIM_CR1_CEN && !TIM5->CR2 && !TIM5->SMCR && !TIM5->DIER &&
        !TIM5->CCER && !TIM5->CCMR1 && !TIM5->CCMR2 &&
        TIM5->PSC==clock_state.psc && TIM5->ARR==UINT32_MAX;
}
void XE_NP_Np2SdFineClock_Invalidate(void)
{
    clock_state.domain=0U;__DMB();
    if(clock_state.owned){
        TIM5->CR1=0U;TIM5->DIER=0U;
        RCC->APB1SMENR1=(RCC->APB1SMENR1&~RCC_APB1SMENR1_TIM5SMEN)|clock_state.old_sleep;
        RCC->APB1ENR1&=~RCC_APB1ENR1_TIM5EN;__DSB();
        clock_state.owned=0U;
    }
}
int XE_NP_Np2SdFineClock_Start(uint32_t seed,uint32_t generation,uint32_t source_epoch)
{
    uint32_t hz,domain;
    if(!seed || (!!generation!=!!source_epoch))return 0;
    if(!root_allowed()){XE_NP_Np2SdFineClock_Invalidate();return 0;}
    /* A caller must relinquish before reclocking. Do not silently repair an
     * unqualified interval, nor claim an already enabled foreign timer. */
    if(clock_state.owned && !qualified()){
        XE_NP_Np2SdFineClock_Invalidate();return 0;
    }
    if(!clock_state.owned){
        if((RCC->APB1ENR1&RCC_APB1ENR1_TIM5EN) ||
           (RCC->APB1RSTR1&RCC_APB1RSTR1_TIM5RST))return 0;
        hz=HAL_RCC_GetPCLK1Freq();
        if((RCC->CFGR2&RCC_CFGR2_PPRE1)>=RCC_CFGR2_PPRE1_2){
            if(hz>UINT32_MAX/2U)return 0;hz*=2U;
        }
        if(!hz || hz%XE_NP_NP2_SD_FINE_HZ ||
           hz/XE_NP_NP2_SD_FINE_HZ>65536U)return 0;
        clock_state.old_sleep=RCC->APB1SMENR1&RCC_APB1SMENR1_TIM5SMEN;
        clock_state.psc=hz/XE_NP_NP2_SD_FINE_HZ-1U;
        clock_state.hclk=SystemCoreClock;
        clock_state.cfgr1=RCC->CFGR1&FINE_CFGR1_MASK;
        clock_state.cfgr2=RCC->CFGR2&FINE_CFGR2_MASK;
        clock_state.pll=RCC->PLL1CFGR;clock_state.div=RCC->PLL1DIVR;
        clock_state.frac=RCC->PLL1FRACR;
        RCC->APB1ENR1|=RCC_APB1ENR1_TIM5EN;
        (void)RCC->APB1ENR1;
        RCC->APB1SMENR1|=RCC_APB1SMENR1_TIM5SMEN;
        TIM5->CR1=0U;TIM5->CR2=0U;TIM5->SMCR=0U;TIM5->DIER=0U;
        TIM5->CCER=0U;TIM5->CCMR1=0U;TIM5->CCMR2=0U;
        TIM5->PSC=clock_state.psc;TIM5->ARR=UINT32_MAX;
        TIM5->EGR=TIM_EGR_UG;TIM5->SR=0U;TIM5->CNT=0U;
        TIM5->CR1=TIM_CR1_CEN;__DSB();clock_state.owned=1U;
    }
    /* Seed is the explicit native record's negotiated nonce, not a timer
     * fraction. Capture binding is published separately after actual arm. */
    clock_state.domain=0U;__DMB();
    clock_state.context++;__DMB();
    clock_state.generation=generation;clock_state.epoch=source_epoch;
    __DMB();clock_state.context++;
    if(++clock_state.serial==0U)clock_state.serial=1U;
    domain=seed^(clock_state.serial*0x9e3779b9U)^HAL_GetUIDw0();
    if(!domain)domain=clock_state.serial;
    __DMB();clock_state.domain=domain;
    if(!qualified()){XE_NP_Np2SdFineClock_Invalidate();return 0;}
    return 1;
}
int XE_NP_Np2SdFineClock_BindSource(uint32_t generation,uint32_t source_epoch)
{
    if(!generation || !source_epoch)return 0;
    if(!qualified()){XE_NP_Np2SdFineClock_Invalidate();return 0;}
    clock_state.context++;__DMB();
    clock_state.generation=generation;clock_state.epoch=source_epoch;
    __DMB();clock_state.context++;return 1;
}
int XE_NP_Np2SdFineClock_ReadIrq(uint32_t tick,XE_NP_Np2SdFinePoint *out)
{
    uint32_t domain=clock_state.domain,context=clock_state.context;
    if(!out || !domain || (context&1U))return 0;
    out->domain=domain;out->counter_hz=XE_NP_NP2_SD_FINE_HZ;
    out->ms=tick;out->counter=XE_NP_SD_FINE_COUNTER();
    out->generation=clock_state.generation;out->source_epoch=clock_state.epoch;
    __DMB();return domain==clock_state.domain && context==clock_state.context;
}
int XE_NP_Np2SdFineClock_Read(XE_NP_Np2SdFinePoint *out)
{
    uint32_t before,after;
    if(!out)return 0;
    memset(out,0,sizeof(*out));
    if(!qualified()){XE_NP_Np2SdFineClock_Invalidate();return 0;}
    /* At most three attempts for a coherent coarse/counter observation.
     * No fraction is synthesized from HAL ms. Wrap selection is host work. */
    for(unsigned tries=0U;tries<3U;tries++){
        before=HAL_GetTick();
        if(!XE_NP_Np2SdFineClock_ReadIrq(before,out))break;
        after=HAL_GetTick();
        if(before==after && qualified())return 1;
    }
    XE_NP_Np2SdFineClock_Invalidate();memset(out,0,sizeof(*out));return 0;
}
#endif
