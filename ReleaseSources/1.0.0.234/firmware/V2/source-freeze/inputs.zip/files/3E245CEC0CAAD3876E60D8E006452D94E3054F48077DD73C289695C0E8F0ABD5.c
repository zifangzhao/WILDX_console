#include "xe_np_np2_closed_loop_sd.h"

#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
#include <string.h>

static uint32_t get32(const uint8_t *p)
{return (uint32_t)p[0]|((uint32_t)p[1]<<8U)|((uint32_t)p[2]<<16U)|((uint32_t)p[3]<<24U);}
static void put32(uint8_t *p,uint32_t v)
{p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8U);p[2]=(uint8_t)(v>>16U);p[3]=(uint8_t)(v>>24U);}
static void seal(uint8_t p[512])
{put32(p+508U,XE_NP_Np2DualSd_Crc32(p,508U));}
static int zero(const uint8_t *p,uint32_t bytes)
{while(bytes--)if(*p++)return 0;return 1;}
static int cl_seal(const uint8_t p[512],const char magic[8])
{
    return p && !memcmp(p,magic,8U) && get32(p+8U)==XE_NP_NP2_CL_SD_VERSION &&
        get32(p+508U)==XE_NP_Np2DualSd_Crc32(p,508U);
}
static int flags_valid(uint32_t base,uint32_t flags)
{
    if(!(flags&XE_NP_NP2_CL_SD_FLAG))return 0;
    flags&=~XE_NP_NP2_CL_SD_FLAG;
    if(base==XE_NP_NP2_DUAL_SD_META_VERSION)return flags==15U;
    if(base==XE_NP_NP2_DUAL_SD_META_AU_VERSION)return flags==31U;
    if(base==XE_NP_NP2_DUAL_SD_META_LEGACY_AU_VERSION)return flags==47U;
    return base==XE_NP_NP2_SD_APPEND_VERSION &&
        (flags==79U || flags==95U || flags==111U);
}

/* Validate the ACTUAL v15 envelope before changing any byte of a private
 * copy. The legacy decoder alone decides whether its base geometry is valid. */
static int descriptor_base(const uint8_t in[512],uint8_t legacy[512],
    XE_NP_Np2DualSdMeta *meta,uint32_t *base,uint32_t *crc)
{
    if(!cl_seal(in,"N2SDLOG1") || get32(in+140U)!=XE_NP_NP2_CL_SD_MARKER ||
       !zero(in+144U,508U-144U))return -1;
    uint32_t version=get32(in+136U),flags=get32(in+96U);
    if(!flags_valid(version,flags))return -1;
    memcpy(legacy,in,512U);
    put32(legacy+8U,version);put32(legacy+96U,flags&~XE_NP_NP2_CL_SD_FLAG);
    memset(legacy+132U,0,12U);seal(legacy);
    int result=version==XE_NP_NP2_SD_APPEND_VERSION?
        XE_NP_Np2SdAppend_DecodeDescriptor(legacy,meta):
        XE_NP_Np2DualSd_DecodeDescriptor(legacy,meta);
    if(result)return -1;
    *base=version;*crc=get32(in+132U);return 0;
}

int XE_NP_Np2ClSd_EncodeDescriptor(uint8_t out[512],
    const XE_NP_Np2DualSdMeta *meta,uint32_t base,uint32_t crc)
{
    uint8_t sector[512];
    if(!out || !meta)return -1;
    int result=base==XE_NP_NP2_SD_APPEND_VERSION?
        XE_NP_Np2SdAppend_EncodeDescriptor(sector,meta):
        XE_NP_Np2DualSd_EncodeDescriptor(sector,meta);
    if(result || get32(sector+8U)!=base ||
       !flags_valid(base,get32(sector+96U)|XE_NP_NP2_CL_SD_FLAG))return -1;
    put32(sector+8U,XE_NP_NP2_CL_SD_VERSION);
    put32(sector+96U,get32(sector+96U)|XE_NP_NP2_CL_SD_FLAG);
    put32(sector+132U,crc);put32(sector+136U,base);
    put32(sector+140U,XE_NP_NP2_CL_SD_MARKER);seal(sector);
    memcpy(out,sector,512U);return 0;
}

int XE_NP_Np2ClSd_DecodeDescriptor(const uint8_t in[512],
    XE_NP_Np2DualSdMeta *meta,uint32_t *base,uint32_t *crc)
{
    uint8_t legacy[512];XE_NP_Np2DualSdMeta m;uint32_t version,binding;
    if(!meta || !base || !crc || descriptor_base(in,legacy,&m,&version,&binding))return -1;
    *meta=m;*base=version;*crc=binding;return 0;
}

int XE_NP_Np2ClSd_EncodeFooter(uint8_t out[512],const uint8_t descriptor[512],
    uint32_t state,uint32_t error,const XE_NP_Np2SdAppendCounts *counts,
    const uint8_t summary[64],int allow_unfinalized)
{
    uint8_t sector[512];XE_NP_Np2DualSdMeta meta;uint32_t base,crc;
    XE_NP_Np2ClCarrierStatus status;uint32_t summary_flags;
    if(!out || !counts || (allow_unfinalized!=0 && allow_unfinalized!=1) ||
       descriptor_base(descriptor,sector,&meta,&base,&crc))return -1;
    int missing=!summary || zero(summary,64U);
    if(missing){
        if(!allow_unfinalized ||
           (state!=XE_NP_NP2_DUAL_SD_META_RESERVED &&
            !(state==XE_NP_NP2_DUAL_SD_META_FAILED &&
              error==XE_NP_NP2_DUAL_SD_META_VERIFY_PENDING)))return -1;
    }else if(XE_NP_Np2ClCarrier_SummaryDecode(summary,meta.session_id,crc,
                                            &status,&summary_flags))return -1;
    if(base!=XE_NP_NP2_SD_APPEND_VERSION &&
       (counts->physical_blocks!=counts->logical_prefix_blocks ||
        counts->physical_blocks!=counts->logical_high_water_blocks))return -1;
    int result=base==XE_NP_NP2_SD_APPEND_VERSION?
        XE_NP_Np2SdAppend_EncodeFooter(sector,&meta,state,error,counts):
        XE_NP_Np2DualSd_EncodeFooter(sector,&meta,state,error,counts->physical_blocks);
    if(result)return -1;
    put32(sector+8U,XE_NP_NP2_CL_SD_VERSION);
    put32(sector+96U,get32(sector+96U)|XE_NP_NP2_CL_SD_FLAG);
    if(!missing)memcpy(sector+144U,summary,64U);
    seal(sector);memcpy(out,sector,512U);return 0;
}

int XE_NP_Np2ClSd_DecodeFooter(const uint8_t descriptor[512],const uint8_t footer[512],
    int allow_prefix_recovery,uint32_t *state,uint32_t *error,
    XE_NP_Np2SdAppendCounts *counts,XE_NP_Np2ClCarrierStatus *summary_status,
    int *drops_unknown)
{
    uint8_t legacy_descriptor[512],legacy_footer[512];XE_NP_Np2DualSdMeta meta;
    XE_NP_Np2SdAppendCounts c;XE_NP_Np2ClCarrierStatus status={0};
    uint32_t base,crc,decoded_state,decoded_error,summary_flags=0U;
    if(!state || !error || !counts || !summary_status || !drops_unknown ||
       (allow_prefix_recovery!=0 && allow_prefix_recovery!=1) ||
       descriptor_base(descriptor,legacy_descriptor,&meta,&base,&crc) ||
       !cl_seal(footer,"N2SDEND1") ||
       memcmp(footer+8U,descriptor+8U,92U) || get32(footer+140U) ||
       !zero(footer+208U,508U-208U) ||
       (base!=XE_NP_NP2_SD_APPEND_VERSION && !zero(footer+132U,12U)))return -1;
    int missing=zero(footer+144U,64U);
    if(!missing && XE_NP_Np2ClCarrier_SummaryDecode(footer+144U,meta.session_id,crc,
                                                  &status,&summary_flags))return -1;
    memcpy(legacy_footer,footer,512U);
    put32(legacy_footer+8U,base);
    put32(legacy_footer+96U,get32(legacy_footer+96U)&~XE_NP_NP2_CL_SD_FLAG);
    memset(legacy_footer+144U,0,64U);seal(legacy_footer);
    if(base==XE_NP_NP2_SD_APPEND_VERSION){
        if(XE_NP_Np2SdAppend_DecodeFooter(legacy_descriptor,legacy_footer,
                                        &decoded_state,&decoded_error,&c))return -1;
    }else{
        uint32_t blocks;
        if(XE_NP_Np2DualSd_DecodeFooter(legacy_descriptor,legacy_footer,
                                      &decoded_state,&decoded_error,&blocks))return -1;
        c.physical_blocks=c.logical_prefix_blocks=c.logical_high_water_blocks=blocks;
    }
    if(missing){
        if(!allow_prefix_recovery || decoded_state==XE_NP_NP2_DUAL_SD_META_COMPLETE)return -1;
        status.session=meta.session_id;status.config_crc=crc;
    }
    *state=decoded_state;*error=decoded_error;*counts=c;*summary_status=status;
    *drops_unknown=missing || (summary_flags&4U)!=0U;return 0;
}
#endif
