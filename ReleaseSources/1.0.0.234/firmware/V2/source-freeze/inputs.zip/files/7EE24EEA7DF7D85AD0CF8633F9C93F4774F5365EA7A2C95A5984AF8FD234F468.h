#ifndef XE_NP_NP2_D8_COPY_H
#define XE_NP_NP2_D8_COPY_H
#include <stdint.h>
#include <string.h>

#ifndef XE_NP_NP2_D8_WORD_CARRY_TEST
#define XE_NP_NP2_D8_WORD_CARRY_TEST 0U
#endif
#ifndef XE_NP_NP2_D8_ALIGNED_CARRY_TEST
#define XE_NP_NP2_D8_ALIGNED_CARRY_TEST 0U
#endif
#if XE_NP_NP2_D8_ALIGNED_CARRY_TEST!=0U && XE_NP_NP2_D8_ALIGNED_CARRY_TEST!=1U
#error "D8 aligned carry flag must be boolean"
#endif

/* Little-endian M33: copy a phase-shifted bit lane without per-byte ring
 * wrapping. Caller owns retention/cache checks; these pointers never alias.
 * memcpy word accesses are defined even for unaligned byte-array addresses.
 * Five source bytes contribute to a shifted word, including at wrap. The
 * aligned trial also reads discarded bits of their containing ring words. */
static inline void XE_NP_Np2D8Copy(uint8_t *destination,const uint8_t *ring,
                                uint32_t ring_bytes,uint32_t bit,uint32_t bytes)
{
    uint32_t index=bit>>3U,shift=bit&7U;
#if XE_NP_NP2_D8_ALIGNED_CARRY_TEST
    if(shift && bytes>=4U && ring_bytes>=4U && !(ring_bytes&3U) &&
       !((uintptr_t)ring&3U) && !((uintptr_t)destination&3U)){
        uint32_t funnel=(index&3U)*8U+shift; /* 1..31; never shift by 32. */
        while(bytes>=4U){
            uint32_t base=index&~3U,word,count=ring_bytes-base-4U;
            if(count>bytes)count=bytes&~3U;
            memcpy(&word,ring+base,4U);
            if(count){
                /* Bound the run once; the word loop has no ring arithmetic. */
                for(uint32_t i=0U;i<count;i+=4U){
                    uint32_t next,shifted;
                    memcpy(&next,ring+base+4U+i,4U);
                    shifted=(word>>funnel)|(next<<(32U-funnel));
                    memcpy(destination+i,&shifted,4U);
                    word=next;
                }
            }else{
                /* The final aligned word needs the first word as lookahead. */
                uint32_t next,shifted;
                memcpy(&next,ring,4U);
                shifted=(word>>funnel)|(next<<(32U-funnel));
                memcpy(destination,&shifted,4U);
                count=4U;
            }
            destination+=count;bytes-=count;index+=count;
            if(index>=ring_bytes)index-=ring_bytes;
        }
    }
#endif
    while(bytes){
        uint32_t count=ring_bytes-index;
        if(!shift){
            if(count>bytes)count=bytes;
            memcpy(destination,ring+index,count);
        }else if(count==1U){
            destination[0]=(uint8_t)((ring[index]>>shift)|(ring[0]<<(8U-shift)));
        }else{
            count--; /* keep the lookahead byte inside the physical ring */
            if(count>bytes)count=bytes;
            uint32_t i=0U;
#if XE_NP_NP2_D8_WORD_CARRY_TEST
            /* Reuse each lookahead word on the next iteration. All loads
             * stay inside count; the original loop handles the final word. */
            if(count>=8U){
                uint32_t word;
                memcpy(&word,ring+index,4U);
                for(;i+8U<=count;i+=4U){
                    uint32_t next,shifted;
                    memcpy(&next,ring+index+i+4U,4U);
                    shifted=(word>>shift)|(next<<(32U-shift));
                    memcpy(destination+i,&shifted,4U);
                    word=next;
                }
            }
#endif
            for(;i+4U<=count;i+=4U){
                uint32_t word;
                memcpy(&word,ring+index+i,4U);
                word=(word>>shift)|((uint32_t)ring[index+i+4U]<<(32U-shift));
                memcpy(destination+i,&word,4U);
            }
            for(;i<count;i++)destination[i]=(uint8_t)((ring[index+i]>>shift)|
                                                       (ring[index+i+1U]<<(8U-shift)));
        }
        destination+=count;bytes-=count;index+=count;
        if(index==ring_bytes)index=0U;
    }
}
#endif
