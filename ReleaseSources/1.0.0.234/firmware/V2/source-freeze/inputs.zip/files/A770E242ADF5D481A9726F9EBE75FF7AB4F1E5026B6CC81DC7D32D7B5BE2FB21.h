#ifndef XE_NP_NP2_DUAL_SD_CATALOG_PORT_H
#define XE_NP_NP2_DUAL_SD_CATALOG_PORT_H

#include "xe_np_np2_dual_sd_catalog.h"
#include "xe_np_np2_grid16_meta.h"
#include "xe_np_hal.h"
#include "xe_np_np2_live_sd.h"

#ifndef XE_NP_NP2_DUAL_SD_CATALOG_PORT_ENABLE
#define XE_NP_NP2_DUAL_SD_CATALOG_PORT_ENABLE 0U
#endif

#if XE_NP_NP2_DUAL_SD_CATALOG_PORT_ENABLE
/* Stopped-only metadata adapter; never called by live PSSI/SD service. */
int XE_NP_Np2DualSdCatalogPort_Bind(SD_HandleTypeDef *card);
int XE_NP_Np2DualSdCatalogPort_Format(uint32_t key,const uint8_t system_sector[512]);
int XE_NP_Np2DualSdCatalogPort_Mount(uint32_t *next_start_lba);
int XE_NP_Np2DualSdCatalogPort_MountAvailable(uint32_t *next_start_lba);
int XE_NP_Np2DualSdCatalogPort_Rewind(uint32_t key,uint32_t expected_start_lba,
                                     uint32_t *next_start_lba);
int XE_NP_Np2DualSdCatalogPort_Recover(uint32_t *next_start_lba);
int XE_NP_Np2DualSdCatalogPort_Plan(uint32_t sample_hz,uint32_t blocks,
                                   uint32_t session_id,uint32_t config_crc,
                                   XE_NP_Np2DualSdMeta *out);
int XE_NP_Np2DualSdCatalogPort_PlanProfile(uint32_t probe_mask,uint32_t sample_hz,
                                          uint32_t blocks,uint32_t session_id,
                                          uint32_t config_crc,XE_NP_Np2DualSdMeta *out);
#if XE_NP_NP2_SD_GRID16_ENABLE
int XE_NP_Np2DualSdCatalogPort_PlanGrid16(uint32_t mask,uint32_t hz,uint32_t blocks,
    uint32_t session,uint32_t config_crc,uint32_t base,uint32_t au,XE_NP_Grid16Meta *meta);
int XE_NP_Np2DualSdCatalogPort_ReserveGrid16(const XE_NP_Grid16Meta *meta,
    const uint8_t configuration[2048],const struct XE_NP_Np2ClCarrierTag *cl);
int XE_NP_Np2DualSdCatalogPort_FinishGrid16(const XE_NP_Grid16Footer *footer);
#endif
#if XE_NP_NP2_LIVE_SD_VSC_TEST
#if XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST
#if XE_NP_NP2_SD_CARD_AU_POLICY_TEST
/* Fresh stopped SSR decides the AU kind before reserving media. */
int XE_NP_Np2DualSdCatalogPort_PlanCardAuProfile(uint32_t probe_mask,uint32_t sample_hz,
                                                uint32_t blocks,uint32_t session_id,
                                                uint32_t config_crc,XE_NP_Np2DualSdMeta *out);
#endif
int XE_NP_Np2DualSdCatalogPort_PlanLegacyAuProfile(uint32_t probe_mask,uint32_t sample_hz,
                                                  uint32_t blocks,uint32_t session_id,
                                                  uint32_t config_crc,XE_NP_Np2DualSdMeta *out);
#endif
int XE_NP_Np2DualSdCatalogPort_PlanVsc(uint32_t sample_hz,uint32_t blocks,
                                      uint32_t session_id,uint32_t config_crc,
                                      XE_NP_Np2DualSdMeta *out);
int XE_NP_Np2DualSdCatalogPort_PlanVscProfile(uint32_t probe_mask,uint32_t sample_hz,
                                             uint32_t blocks,uint32_t session_id,
                                             uint32_t config_crc,XE_NP_Np2DualSdMeta *out);
/* Bind slot0 to the unchanged descriptor, outside all assigned payload AUs.
 * Called once after the final pre-capture metadata write, never while live. */
int XE_NP_Np2DualSdCatalogPort_PrepareVsc(const XE_NP_Np2DualSdMeta *meta);
#if XE_NP_NP2_SD_VSC_FEED_TEST
/* Bounded scratch-only DIR preparation; does not reserve/publish a recording. */
int XE_NP_Np2DualSdCatalogPort_PrepareStoppedVscFeed(uint32_t catalog_front);
#endif
/* Legacy CMD20 UpdateDIR, VSC bit clear; same unchanged descriptor sector.
 * Called before Init/Start only, never from an acquisition or SD service. */
int XE_NP_Np2DualSdCatalogPort_PrepareClassic(const XE_NP_Np2DualSdMeta *meta);
#endif
int XE_NP_Np2DualSdCatalogPort_Reserve(const XE_NP_Np2DualSdMeta *meta,
                                      const uint8_t configuration[2048]);
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
struct XE_NP_Np2ClCarrierTag;
int XE_NP_Np2DualSdCatalogPort_ReserveClosedLoop(const XE_NP_Np2DualSdMeta *,
    const uint8_t configuration[2048],uint32_t append,const struct XE_NP_Np2ClCarrierTag *);
#endif
int XE_NP_Np2DualSdCatalogPort_CheckpointWritten(uint32_t committed_blocks);
int XE_NP_Np2DualSdCatalogPort_Finish(uint32_t state,uint32_t error,uint32_t blocks);
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
int XE_NP_Np2DualSdCatalogPort_ReserveAppend(const XE_NP_Np2DualSdMeta *,const uint8_t configuration[2048]);
int XE_NP_Np2DualSdCatalogPort_CheckpointAppend(const XE_NP_Np2SdAppendCounts *);
int XE_NP_Np2DualSdCatalogPort_FinishAppend(uint32_t state,uint32_t error,const XE_NP_Np2SdAppendCounts *);
#endif
int XE_NP_Np2DualSdCatalogPort_Time(const uint8_t sector[512]);
#if NP_FINE_COUNTER64_ENABLE
int XE_NP_Np2DualSdCatalogPort_FineCounter64Time(const uint8_t utc2[512],const uint8_t anchor[64],
    const uint32_t uid[3],uint64_t token);
int XE_NP_Np2DualSdCatalogPort_RtcTime(const uint8_t utc2[512],const uint8_t anchor[64],
    const uint8_t rtc[128],const uint32_t uid[3],uint64_t token);
#endif

#if XE_NP_NP2_SD_CATALOG_ENABLE
int XE_NP_Np2DualSdCatalogPort_Ready(void);
int XE_NP_Np2DualSdCatalogPort_Info(XE_NP_Np2DualSdCatalogInfo *out);
int XE_NP_Np2DualSdCatalogPort_Entry(uint32_t token,uint32_t count,uint32_t ordinal,
                                    XE_NP_Np2DualSdCatalogEntry *out);
int XE_NP_Np2DualSdCatalogPort_CheckDelete(const XE_NP_Np2DualSdCatalogDelete *request);
int XE_NP_Np2DualSdCatalogPort_DeleteLast(const XE_NP_Np2DualSdCatalogDelete *request,uint32_t *next);
#endif
#endif
#endif
