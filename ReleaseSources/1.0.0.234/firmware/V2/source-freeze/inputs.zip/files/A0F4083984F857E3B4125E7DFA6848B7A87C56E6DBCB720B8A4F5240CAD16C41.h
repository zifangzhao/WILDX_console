#ifndef XE_NP_IMU_GRID_TIMER_H
#define XE_NP_IMU_GRID_TIMER_H
#include <stdint.h>

/* Unwired prototype: one exclusive TIM3 owner. The callback must only copy
 * cached values and perform bounded bookkeeping; never perform I2C, storage,
 * UART, CRC, serialization, or waits. No recording origin is implied. */
typedef void (*XE_NP_GridTimerCallback)(void *context);
int XE_NP_GridTimer_Prepare(XE_NP_GridTimerCallback callback,void *context);
int XE_NP_GridTimer_Start(void);
/* Only the active TIM3 callback may replace itself, and only while retaining
 * the single owner's context.  It is deliberately not a foreground control. */
int XE_NP_GridTimer_SwitchCurrentCallback(XE_NP_GridTimerCallback callback,void *context);
int XE_NP_GridTimer_Qualified(void);
void XE_NP_GridTimer_Release(void);
#endif
