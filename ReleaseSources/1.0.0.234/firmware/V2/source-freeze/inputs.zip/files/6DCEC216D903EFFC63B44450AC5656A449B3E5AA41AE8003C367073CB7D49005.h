#ifndef XE_NP_NP2_FIRST_SYNC_H
#define XE_NP_NP2_FIRST_SYNC_H

#include <stdint.h>

/* Bounded offline/foreground proof for one immutable NP2 USB-format block.
 * It establishes only native SuperSync framing.  The caller binds any result
 * to its selected generation, receipt, and retention proof. */
#define XE_NP_NP2_FIRST_SYNC_BLOCK_BYTES 46592U
#define XE_NP_NP2_FIRST_SYNC_HEADER_BYTES 512U
#define XE_NP_NP2_FIRST_SYNC_PAYLOAD_BYTES 46080U
#define XE_NP_NP2_FIRST_SYNC_UNKNOWN_TICK UINT64_MAX
#define XE_NP_NP2_FIRST_SYNC_UNKNOWN_PHASE UINT16_MAX

typedef struct {
    uint8_t mask;
    uint8_t reference; /* lowest admitted connector, 0..2 */
    uint8_t reserved;
    uint16_t phase[3]; /* add to absolute source tick, modulo 1600 */
    uint64_t first_tick[3]; /* first complete superframe start in block */
    uint32_t checked_positions;
} XE_NP_Np2FirstSync;

/* Requires exactly one 46,592-byte block and all admitted ports live in its
 * header.  Returns 1 only when every admitted port has a unique phase among
 * 1600 candidates and every in-block native sync position agrees.  It never
 * mutates input and does not decode ADC words or infer a sample counter. */
int XE_NP_Np2FirstSync_Prove(const uint8_t *block,uint32_t block_bytes,
                             uint32_t admitted_mask,XE_NP_Np2FirstSync *out);

#endif
