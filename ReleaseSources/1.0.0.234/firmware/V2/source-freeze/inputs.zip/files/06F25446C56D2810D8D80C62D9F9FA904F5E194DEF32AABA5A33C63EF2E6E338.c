#include "xe_np_np2_online.h"
#include "xe_np_online_impl.h"
#include "xe_np_np2_capture_port.h"
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
#include "xe_np_sensor_query.h"
#include "xe_np_sensors_port.h"
static XE_NP_SensorQuery sensor_query;
#endif
#if XE_NP_RTC_ENABLE
#include "xe_np_np2_dual_sd_app.h"
#include "xe_np_np2_sd_control.h"
#include "xe_np_np2_preparation.h"
static XE_NP_Np2OnlineClock *rtc_legacy_clock;
static uint32_t rtc_mirror_generation,rtc_pending_generation;
static void rtc_idle(void){}
static void (*rtc_service)(void)=rtc_idle;
static int rtc_idle_admission(uint32_t state)
{
    if(state!=0U && state!=1U && state!=5U && state!=7U)return 0;
    if(XE_NP_Np2CapturePort_Armed() || XE_NP_Np2Preparation_Holding())return 0;
#if XE_NP_NP2_DUAL_SD_APP_ENABLE
    if(xe_np_np2_dual_sd_app_mailbox.command || XE_NP_Np2SdControl_PendingMode() ||
       XE_NP_Np2SdControl_PendingStart())return 0;
#endif
    return 1;
}
static void rtc_mirror_pending(void)
{
    XE_NP_RtcSample sample;uint64_t utc;
#if XE_NP_NP2_DUAL_SD_APP_ENABLE
    if(!rtc_idle_admission(xe_np_np2_dual_sd_app_mailbox.state)){
        rtc_service=rtc_idle;return;
    }
#endif
    (void)XE_NP_RtcOnline_Service();
    if(!rtc_legacy_clock || !rtc_pending_generation ||
       rtc_pending_generation==rtc_mirror_generation){rtc_service=rtc_idle;return;}
    if(!XE_NP_Rtc_Read(&sample))return;
    if((sample.status&(XE_NP_RTC_STATUS_PC_CALIBRATED|XE_NP_RTC_STATUS_TRANSACTION_BUSY|
                      XE_NP_RTC_STATUS_LOCAL_UNAVAILABLE))!=XE_NP_RTC_STATUS_PC_CALIBRATED ||
       sample.calibration_generation!=rtc_pending_generation || !XE_NP_RtcOnline_Utc(&sample,&utc))return;
    rtc_legacy_clock->tick=HAL_GetTick();rtc_legacy_clock->utc_us=utc;
    rtc_legacy_clock->uncertainty_us=XE_NP_RtcOnline_Uncertainty();rtc_legacy_clock->valid=1U;
    if(++rtc_legacy_clock->generation==0U)rtc_legacy_clock->generation=1U;
    /* V1 idempotency belongs to its old command, not the new RTC generation. */
    rtc_mirror_generation=rtc_pending_generation;rtc_service=rtc_idle;
}
void XE_NP_Np2Online_RtcService(void){rtc_service();}
void XE_NP_Np2Online_RtcFreeze(void)
{rtc_service=rtc_idle;XE_NP_Rtc_SetTransactionBusy(1U);}
void XE_NP_Np2Online_RtcIdle(void){XE_NP_Rtc_SetTransactionBusy(0U);}
void XE_NP_Np2Online_RtcInvalidate(void)
{rtc_service=rtc_idle;XE_NP_RtcOnline_Invalidate();}
#endif
void XE_NP_Np2Online_Init(XE_NP_Np2OnlineClock *c)
{
    XE_NP_Online_Init(c);
#if XE_NP_RTC_ENABLE
    rtc_legacy_clock=c;rtc_mirror_generation=rtc_pending_generation=0U;
    rtc_service=rtc_idle;XE_NP_RtcOnline_Init();
#endif
}
uint64_t XE_NP_Np2Online_Utc(const XE_NP_Np2OnlineClock *c,uint32_t now)
{return XE_NP_Online_Utc(c,now);}
int XE_NP_Np2Online_Exchange(XE_NP_Np2OnlineClock *c,const uint8_t in[64],
    uint8_t out[64],uint32_t received,uint32_t sent,uint32_t state)
{
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
    if(XE_NP_SensorQuery_Exchange(&sensor_query,in,out,
        XE_NP_SensorsPort_GetSnapshot(),sent))return 0;
#endif
    /* The checked BLE dispatcher already calls this command-only exchange.
     * Add the optional query here without rebuilding its capture/UART owner. */
#if XE_NP_NP2_CAPTURE_PORT_ENABLE
    if(XE_NP_AcquisitionAnchor_Request(in)){
        XE_NP_AcquisitionAnchor anchor;
        XE_NP_Np2CapturePort_GetAnchor(&anchor);
        XE_NP_AcquisitionAnchor_Reply(&anchor,xe_np_online_word(in+8U),out);
        return 0;
    }
#endif
#if XE_NP_RTC_ENABLE
    if(in && out && xe_np_online_word(in)==NP_ONLINE_REQUEST && xe_np_online_word(in+4U)==2U){
        uint32_t admitted=(uint32_t)rtc_idle_admission(state);
        XE_NP_Rtc_SetTransactionBusy(!admitted);
        int result=XE_NP_RtcOnline_Exchange(in,out,received,state,admitted);
        if(!result && xe_np_online_word(in+8U)==1U && !xe_np_online_word(out+16U) && admitted){
            rtc_pending_generation=xe_np_online_word(out+28U);
            if(rtc_pending_generation!=rtc_mirror_generation){
                rtc_service=rtc_mirror_pending;rtc_mirror_pending();
            }
        }
        return result;
    }
#endif
    /* UTC is a RAM-only control feature: it does not require a mounted SD
       catalog. Still never step it while preparing, armed, or recording. */
    return XE_NP_Online_Exchange(c,in,out,received,sent,state,
        state==0 || state==1 || state==5 || state==7);
}
