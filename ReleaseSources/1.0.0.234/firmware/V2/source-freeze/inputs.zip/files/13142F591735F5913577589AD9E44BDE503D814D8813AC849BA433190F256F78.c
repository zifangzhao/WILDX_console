#include "CE32_SubMod.h"
//global variable
CE32_SUBMOD SUBMOD_handle;
void CE32_SUBMOD_INIT(CE32_SUBMOD *SUBMOD_handle,UART_HandleTypeDef *huart, CE32_systemParam *sysParam)
{
	//Check if Submodule is connected
	//HAL_UART_DeInit(huart);
	CE32_SUBMOD_PreInitAct(SUBMOD_handle);
	CE32_INTERCOM_Init((CE32_INTERCOM_Handle*)SUBMOD_handle,huart);

	//Send settings
	SUBMOD_handle->sysParam=sysParam;
	CE32_SUBMOD_Enable(SUBMOD_handle);
	CE32_SUBMOD_Handshake(SUBMOD_handle);
	//resp=0;//Manual Override
}

void CE32_SUBMOD_Enable(CE32_SUBMOD *SUBMOD_handle)
{
//	if(((((CE32_INTERCOM_Handle*)SUBMOD_handle)->huart->Instance->CR1 & USART_CR1_UE ) & (((CE32_INTERCOM_Handle*)SUBMOD_handle)->huart->hdmatx->Instance->CR& DMA_SxCR_EN ))==0)
//	{
		CE32_SUBMOD_PreEnableAct(SUBMOD_handle);
		/* UART may be de-inited in low-power path; refresh cached UART instance after re-init. */
		if(((CE32_INTERCOM_Handle*)SUBMOD_handle)->huart != NULL)
		{
			((CE32_INTERCOM_Handle*)SUBMOD_handle)->UART = ((CE32_INTERCOM_Handle*)SUBMOD_handle)->huart->Instance;
		}
		CE32_INTERCOM_UART_TX_DMA_Init((CE32_INTERCOM_Handle*)SUBMOD_handle);
		/* Ensure UART RX interrupt path is restored after low-power deinit/reinit. */
		if(((CE32_INTERCOM_Handle*)SUBMOD_handle)->UART != NULL)
		{
			volatile uint8_t dr_dummy = CE32_UART_RX_READ(((CE32_INTERCOM_Handle*)SUBMOD_handle)->UART);
			CE32_UART_RX_CLEAR(((CE32_INTERCOM_Handle*)SUBMOD_handle)->UART);
			(void)dr_dummy;
			/* Keep half-duplex direction control unchanged; only ensure UE+RXNEIE are set. */
			((CE32_INTERCOM_Handle*)SUBMOD_handle)->UART->CR1 |= (USART_CR1_UE | USART_CR1_RXNEIE);
		}
	  if(SUBMOD_handle->COMM.CMD_RX.cmd_pending>0)
		{
			CE32_SUBMOD_PreTXAct(SUBMOD_handle);
			CE32_INTERCOM_TX_Start_DMA((CE32_INTERCOM_Handle*)SUBMOD_handle);
		}
		//CE32_SUBMOD_Handshake(SUBMOD_handle);
//	}
}

void CE32_SUBMOD_Transmit(CE32_SUBMOD *SUBMOD_handle,uint8_t * cmd, uint16_t len)
{
	CE32_INTERCOM_Handle* ic = (CE32_INTERCOM_Handle*)SUBMOD_handle;
	int st;

	CE32_SUBMOD_PreTXAct(SUBMOD_handle);
	/* Enqueue may fail when TX queue is temporarily saturated. */
	st = CE32_INTERCOM_TX_EnqueueCmd(ic,cmd,len); //Send query message
	if(st != 0)
	{
		/* One-shot recovery kick: refresh TX DMA path and retry once. */
		CE32_INTERCOM_TX_restart(ic);
		st = CE32_INTERCOM_TX_EnqueueCmd(ic,cmd,len);
		if(st != 0)
		{
			return;
		}
	}

	/* Ensure DMA launch is not lost due to stale TX state bits. */
	st = CE32_INTERCOM_TX_Start_DMA(ic);
	if(st < 0)
	{
		CE32_INTERCOM_TX_restart(ic);
		(void)CE32_INTERCOM_TX_Start_DMA(ic);
	}

}

void CE32_SUBMOD_Disable(CE32_SUBMOD *SUBMOD_handle)
{
	if(SUBMOD_handle->COMM.huart!=NULL)
	{
		CE32_INTERCOM_UART_TX_DMA_Disable((CE32_INTERCOM_Handle*)SUBMOD_handle);
		HAL_UART_DeInit(SUBMOD_handle->COMM.huart);
	}
}

void CE32_SUBMOD_Handshake(CE32_SUBMOD *SUBMOD_handle)
{
	char msg[3]={0x3c,0x80,0x3e};
	CE32_SUBMOD_PreTXAct(SUBMOD_handle);
	CE32_INTERCOM_TX_EnqueueCmd((CE32_INTERCOM_Handle*)SUBMOD_handle,(uint8_t*)&msg,3); //Send query message
	CE32_SUBMOD_SyncParam(SUBMOD_handle);
	CE32_INTERCOM_TX_Start_DMA((CE32_INTERCOM_Handle*)SUBMOD_handle);

}

void CE32_SUBMOD_SyncParam(CE32_SUBMOD *SUBMOD_handle)
{
	uint8_t* addr;
	if(CE32_COMMAND_Enqueue_Allocate(&((CE32_INTERCOM_Handle*)SUBMOD_handle)->CMD_TX,512+3,&addr)!=0)
	{
		/* TX queue saturated; skip this sync frame and let caller retry later. */
		return;
	}
	addr[0]='<';
	addr[1]=0x01;
	memcpy(&addr[2],SUBMOD_handle->sysParam,512);							//Copy the data to TX buffer
	addr[514]='>';
	CE32_SUBMOD_PreTXAct(SUBMOD_handle);
	if(CE32_COMMAND_EnqueueCmd_buffered(&((CE32_INTERCOM_Handle*)SUBMOD_handle)->CMD_TX)!=0)
	{
		/* Keep queue state consistent if enqueue commit failed. */
		CE32_COMMAND_Enqueue_Byte_Abort(&((CE32_INTERCOM_Handle*)SUBMOD_handle)->CMD_TX);
	}
	//((CE32_INTERCOM_Handle*)SUBMOD_handle)->UART->CR1|=USART_CR1_TXEIE|USART_CR1_UE|USART_CR1_TE;
}

void CE32_SUBMOD_Trig(CE32_SUBMOD *SUBMOD_handle,uint8_t trigSig)
{
	char msg[]={0x3c,0x83,trigSig,0x3e};
	CE32_SUBMOD_PreTXAct(SUBMOD_handle);
	CE32_INTERCOM_TX_EnqueueCmd((CE32_INTERCOM_Handle*)SUBMOD_handle,(uint8_t*)&msg,4); //Send query message
	CE32_INTERCOM_TX_Start_DMA((CE32_INTERCOM_Handle*) SUBMOD_handle);
}

void CE32_SUBMOD_SetIntensity(CE32_SUBMOD *SUBMOD_handle,uint16_t lvl,uint8_t id)
{
	char msg[]={0x3c,0x13,id,lvl,0x3e};
	CE32_SUBMOD_PreTXAct(SUBMOD_handle);
	CE32_INTERCOM_TX_EnqueueCmd((CE32_INTERCOM_Handle*)SUBMOD_handle,(uint8_t*)&msg,6); //Send query message
	CE32_INTERCOM_TX_Start_DMA((CE32_INTERCOM_Handle*) SUBMOD_handle);
}

__weak void CE32_SUBMOD_PreInitAct(CE32_SUBMOD *CE32_SUBMOD_handle)
{
	__nop();
}

__weak void CE32_SUBMOD_PreEnableAct(CE32_SUBMOD *CE32_SUBMOD_handle)
{
	__nop();
}

__weak void CE32_SUBMOD_PreTXAct(CE32_SUBMOD *CE32_SUBMOD_handle)
{
	__nop();
}

__weak void CE32_SUBMOD_PostTXAct(CE32_SUBMOD *CE32_SUBMOD_Enable)
{
	__nop();
}
