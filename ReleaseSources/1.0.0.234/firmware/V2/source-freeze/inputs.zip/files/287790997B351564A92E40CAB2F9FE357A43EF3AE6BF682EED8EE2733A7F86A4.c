#include "CE32_filesystem.h"
#include "CE32_system.h"

#include <string.h>

extern RTC_HandleTypeDef hrtc;
CE32_FileStream fs;
volatile CE32_FileIoDiag ce32_file_io_diag = {
	CE32_FILE_IO_DIAG_MAGIC,
	CE32_FILE_IO_DIAG_VERSION,
	0U,
	0U,
	0U,
	0U,
	0U,
	0U,
};
static volatile uint8_t ce32_ephys_ovr_ble_pending = 0U;
static volatile uint32_t ce32_ephys_ovr_ble_used = 0U;

#define CE32_FILE_LAYOUT_TAG_FAMILY_MASK 0xFFFF0000UL
#define CE32_FILE_LAYOUT_TAG_XE_NP_RAW 0x4E500000UL
#define CE32_FILE_DMA_BLOCK_TRANSFER_IDLE_GRACE_MS 20U
#define CE32_FILE_METADATA_WRITE_RETRY_MAX 3U
#define CE32_FILE_METADATA_READ_RETRY_MAX 3U
#define CE32_FILE_LOG_BLOCK_LIMIT ((DATA_ADDR > LOG_ADDR) ? (DATA_ADDR - LOG_ADDR) : 0U)

static uint32_t CE32_File_AlignUpAU(uint32_t addr)
{
#if ((AU_BLOCKS & (AU_BLOCKS - 1)) == 0)
	return (addr + (AU_BLOCKS - 1U)) & ~(AU_BLOCKS - 1U);
#else
	uint32_t rem = addr % AU_BLOCKS;
	return (rem == 0U) ? addr : (addr + (AU_BLOCKS - rem));
#endif
}

static uint8_t CE32_File_IsXeNpRawLayout(const CE32_FileStream *fs)
{
	if((fs == NULL) || (fs->sysParam == NULL))
	{
		return 0U;
	}

	return ((fs->sysParam->unassigned_32 & CE32_FILE_LAYOUT_TAG_FAMILY_MASK) ==
	        CE32_FILE_LAYOUT_TAG_XE_NP_RAW) ? 1U : 0U;
}

static uint8_t CE32_File_HasPendingBlockWrite(CE32_FileStream *fs)
{
	if(fs->MGR[fs->baseMGR_id].MGR[0]->bufferUsed[0] >= MIN_DATA_GUARD)
	{
		return 1U;
	}
	for(int idx=0; idx<MAX_FILESTREAM_DATATYPES; idx++)
	{
		if(fs->MGR[idx].bytes_to_Write >= 512U)
		{
			return 1U;
		}
	}
	return 0U;
}

static int CE32_File_WriteSingleBlockRetry(uint32_t addr, uint8_t *data)
{
	for(uint32_t attempt = 0U; attempt < CE32_FILE_METADATA_WRITE_RETRY_MAX; ++attempt)
	{
		int status = HD32_SD_writeSingleBlock(addr, data);
		ce32_file_io_diag.last_write_addr = addr;
		ce32_file_io_diag.last_write_status = (uint32_t)status;
		ce32_file_io_diag.last_write_attempts = attempt + 1U;
		if(status == 0)
		{
			return 0;
		}
	}

	ce32_file_io_diag.last_write_status = 0xFFFFFFFFUL;
	return -1;
}

static int CE32_File_ReadSingleBlockRetry(uint32_t addr, uint8_t *data)
{
	for(uint32_t attempt = 0U; attempt < CE32_FILE_METADATA_READ_RETRY_MAX; ++attempt)
	{
		int status = HD32_SD_readSingleBlock(addr, data);
		ce32_file_io_diag.last_read_addr = addr;
		ce32_file_io_diag.last_read_status = (uint32_t)status;
		ce32_file_io_diag.last_read_attempts = attempt + 1U;
		if(status == 0)
		{
			return 0;
		}
	}

	ce32_file_io_diag.last_read_status = 0xFFFFFFFFUL;
	return -1;
}

static int CE32_File_ValidateSystemLogBlock(const CE32_systemLog *sys_log)
{
	uint32_t rec;

	if((sys_log == NULL) || (sys_log->Nrec > MAX_LOG_PER_BLOCK))
	{
		return -1;
	}

	for(rec = 0U; rec < sys_log->Nrec; ++rec)
	{
		if((sys_log->log[rec] < DATA_ADDR) || (sys_log->evt_log[rec] < DATA_ADDR))
		{
			return -1;
		}
	}

	return 0;
}

static void CE32_File_ClearSystemLogBlock(CE32_systemLog *sys_log)
{
	if(sys_log == NULL)
	{
		return;
	}

	memset(sys_log, 0, sizeof(*sys_log));
}

static uint8_t CE32_File_ShouldKeepBlockTransferHot(const CE32_FileStream *fs)
{
	const streamMGR *base;

	if(fs == NULL)
	{
		return 0U;
	}

	if(fs->power_save != 0U)
	{
		return 1U;
	}

	/*
	 * XE_NP uses power_save=0 for the low-threshold raw recorder path, but it
	 * still benefits from CE64-style short-gap multiblock reuse. Detect that
	 * local raw layout explicitly instead of relying on the old "never stop"
	 * side effect from power_save=0.
	 */
	if((fs->sysParam == NULL) ||
	   ((fs->sysParam->unassigned_32 & CE32_FILE_LAYOUT_TAG_FAMILY_MASK) !=
	    CE32_FILE_LAYOUT_TAG_XE_NP_RAW) ||
	   (fs->baseMGR_id < 0) ||
	   (fs->baseMGR_id >= MAX_FILESTREAM_DATATYPES))
	{
		return 0U;
	}

	base = &fs->MGR[fs->baseMGR_id];
	return (base->MGR_cnt == 1U) ? 1U : 0U;
}

static uint8_t CE32_File_ShouldDeferLogUpdate(const CE32_FileStream *fs)
{
	const streamMGR *base;
	const dataMGR *mgr;
	uint32_t used_bytes;
	uint32_t high_water_bytes;

	if((fs == NULL) ||
	   (fs->sysParam == NULL) ||
	   ((fs->sysParam->unassigned_32 & CE32_FILE_LAYOUT_TAG_FAMILY_MASK) !=
	    CE32_FILE_LAYOUT_TAG_XE_NP_RAW) ||
	   (fs->baseMGR_id < 0) ||
	   (fs->baseMGR_id >= MAX_FILESTREAM_DATATYPES))
	{
		return 0U;
	}

	base = &fs->MGR[fs->baseMGR_id];
	if((base->MGR_cnt != 1U) || (base->MGR[0] == NULL))
	{
		return 0U;
	}

	mgr = base->MGR[0];
	used_bytes = mgr->bufferUsed[0];
	high_water_bytes = mgr->dataSize / 2U;

	/*
	 * During direct Neuropixels raw logging, periodic file-log refresh is not
	 * urgent enough to justify stealing SD bandwidth when the base ring is
	 * already running hot. Leave ce32_log_update_pending latched and retry on a
	 * later AU boundary instead of interrupting the hotter raw path.
	 */
	if((high_water_bytes != 0U) && (used_bytes >= high_water_bytes))
	{
		return 1U;
	}

	return 0U;
}

#define CE32_FILE_DMA_BATCH_BLOCKS_DEFAULT 16U
#define CE32_FILE_DMA_BATCH_BLOCKS_ELEVATED 64U
#define CE32_FILE_DMA_BATCH_BLOCKS_STRESSED 120U

static uint16_t CE32_File_FileStream_SelectBatchLimit(
	const CE32_FileStream *fs,
	const streamMGR *sMGR,
	const dataMGR *mgr,
	uint32_t candidate_blocks)
{
	uint32_t ring_blocks;

	if((fs == NULL) || (sMGR == NULL) || (mgr == NULL))
	{
		return CE32_FILE_DMA_BATCH_BLOCKS_DEFAULT;
	}

	/*
	 * Keep the original CE64 cadence for non-base or multi-ring streams. Only
	 * the single-ring base stream gets larger DMA bursts when backlog is high,
	 * which is the active Neuropixels raw logging case on XE_NP.
	 */
	if((sMGR->MGR_cnt != 1U) || (fs->MGR_id != fs->baseMGR_id))
	{
		return CE32_FILE_DMA_BATCH_BLOCKS_DEFAULT;
	}

	ring_blocks = (uint32_t)mgr->dataSize / 512U;
	if((candidate_blocks >= CE32_FILE_DMA_BATCH_BLOCKS_ELEVATED) &&
	   (ring_blocks != 0U) &&
	   (candidate_blocks * 2U >= ring_blocks))
	{
		return CE32_FILE_DMA_BATCH_BLOCKS_STRESSED;
	}

	if(candidate_blocks >= CE32_FILE_DMA_BATCH_BLOCKS_ELEVATED)
	{
		return CE32_FILE_DMA_BATCH_BLOCKS_ELEVATED;
	}

	return CE32_FILE_DMA_BATCH_BLOCKS_DEFAULT;
}

static uint32_t CE32_File_BlocksUntilNextAU(uint32_t addr)
{
#if ((AU_BLOCKS & (AU_BLOCKS - 1)) == 0)
	uint32_t offset = addr & (AU_BLOCKS - 1U);
#else
	uint32_t offset = addr % AU_BLOCKS;
#endif
	return (offset == 0U) ? AU_BLOCKS : (AU_BLOCKS - offset);
}

static uint16_t CE32_File_FileStream_SelectBlockWriteCount(
	CE32_FileStream *fs,
	streamMGR *sMGR,
	dataMGR *mgr)
{
	uint32_t available_blocks;
	uint32_t contiguous_blocks;
	uint32_t block_count;
	uint32_t remaining_blocks;
	uint32_t au_limited_blocks;
	uint16_t batch_limit;

	if((fs == NULL) || (sMGR == NULL) || (mgr == NULL))
	{
		return 1U;
	}

	/*
	 * Multi-block writes are only safe for a single backing ring. Dual-bank
	 * paced streams must keep the old one-block cadence so their sub-bank
	 * ordering remains unchanged.
	 */
	if(sMGR->MGR_cnt != 1U)
	{
		return 1U;
	}

	available_blocks = dataMGR_BytesAvailable(mgr, 0U) / 512U;
	contiguous_blocks = dataMGR_ContiguousBytesAvailable(mgr, 0U) / 512U;
	block_count = (available_blocks < contiguous_blocks) ? available_blocks : contiguous_blocks;

	if(block_count == 0U)
	{
		return 1U;
	}

	if(fs->MGR_id != fs->baseMGR_id)
	{
		uint32_t due_blocks = sMGR->bytes_to_Write / 512U;
		if(due_blocks == 0U)
		{
			return 1U;
		}
		if(block_count > due_blocks)
		{
			block_count = due_blocks;
		}
	}

	remaining_blocks = (fs->f_event_sector - LOG_INTERVAL) - fs->file_addr;
	if(block_count > remaining_blocks)
	{
		block_count = remaining_blocks;
	}

	/*
	 * Preserve CE64 scheduler semantics around AU boundaries. The log-update
	 * path and the old pre-erase restart logic both observe file_addr on each
	 * boundary, so do not batch across one in a single transfer.
	 */
	au_limited_blocks = CE32_File_BlocksUntilNextAU(fs->file_addr);
	if(block_count > au_limited_blocks)
	{
		block_count = au_limited_blocks;
	}

	batch_limit = CE32_File_FileStream_SelectBatchLimit(fs, sMGR, mgr, block_count);
	if(block_count > batch_limit)
	{
		block_count = batch_limit;
	}

	return (block_count == 0U) ? 1U : (uint16_t)block_count;
}

DEBUG_OFF
typedef enum{
	fs_profile_init = 0,
	fs_profile_schedule,
	fs_profile_wdata,
	fs_profile_wlog,
	fs_profile_transfercplt,
}FS_PROFILE_TYPE;
//#define __FS_PROFILE__
#ifdef __FS_PROFILE__
uint32_t FS_time[8];
uint32_t FS_period[8];
#define FS_PROFILE_TIME(__ID__) FS_time[__ID__]=DWT->CYCCNT
#define FS_PROFILE_PERIOD(__ID1__,__ID2__) FS_period[__ID1__]=DWT->CYCCNT-FS_time[__ID2__]
#else
#define FS_PROFILE_TIME(__ID__) 
#define FS_PROFILE_PERIOD(__ID1__,__ID2__) 
#endif

CE32_FS_StateTransform stateTran_0[]={
 {sta_uninit,evt_init,        sta_pend,CE32_File_FileStream_RecPrepare},
 {sta_uninit,evt_start,       sta_schedule,CE32_File_FileStream_Init_StartNewFile},
 {sta_uninit,evt_schedule,        sta_uninit,NULL},
 {sta_uninit,evt_transOK,        sta_uninit,NULL},
 {sta_uninit,evt_transERR,        sta_uninit,NULL},
 {sta_uninit,evt_stop,  sta_uninit,NULL},
 {sta_uninit,evt_deinit,  sta_uninit,NULL},
}; 

CE32_FS_StateTransform stateTran_1[]={
 {sta_pend,evt_init,        sta_pend,NULL},
 {sta_pend,evt_start,       sta_schedule,CE32_File_FileStream_StartNewFile},
 {sta_pend,evt_schedule,        sta_pend,CE32_File_FileStream_CheckTransfer},
 {sta_pend,evt_transOK,        sta_pend,CE32_File_FileStream_TransOK},
 {sta_pend,evt_transERR,        sta_pend,CE32_File_FileStream_TransERR},
 {sta_pend,evt_stop,  sta_pend,NULL},
 {sta_pend,evt_deinit,  sta_uninit,NULL},
}; 

CE32_FS_StateTransform stateTran_2[]={
 {sta_schedule,evt_init,        sta_pend,NULL},
 {sta_schedule,evt_start,       sta_schedule,NULL},
 {sta_schedule,evt_schedule,        sta_schedule,CE32_File_FileStream_DataScheduler},
 {sta_schedule,evt_transOK,        sta_schedule,CE32_File_FileStream_TransOK},
 {sta_schedule,evt_transERR,        sta_schedule,CE32_File_FileStream_TransERR},
 {sta_schedule,evt_stop,  sta_stopping,CE32_File_FileStream_StopAndSave},
 {sta_schedule,evt_deinit,  sta_uninit,NULL},
}; 

CE32_FS_StateTransform stateTran_3[]={
 {sta_tranfer,evt_init,        sta_pend,NULL},
 {sta_tranfer,evt_start,       sta_tranfer,NULL},
 {sta_tranfer,evt_schedule,        sta_tranfer,CE32_File_FileStream_CheckTransfer},
 {sta_tranfer,evt_transOK,        sta_schedule,CE32_File_FileStream_TransOK},
 {sta_tranfer,evt_transERR,        sta_schedule,CE32_File_FileStream_TransERR},
 {sta_tranfer,evt_stop,  sta_stopping,CE32_File_FileStream_StopAndSave},
 {sta_tranfer,evt_deinit,  sta_uninit,NULL},
}; 

CE32_FS_StateTransform stateTran_4[]={
 {sta_stopping,evt_init,        sta_stopping,NULL},
 {sta_stopping,evt_start,       sta_stopping,NULL},
 {sta_stopping,evt_schedule,        sta_stopping,CE32_File_FileStream_CheckTransfer},
 {sta_stopping,evt_transOK,        sta_uninit,CE32_File_FileStream_PostStop},
 {sta_stopping,evt_transERR,        sta_uninit,NULL},
 {sta_stopping,evt_stop,  sta_stopping,NULL},
 {sta_stopping,evt_deinit,  sta_uninit,NULL},
}; 

CE32_FS_StateTransform stateTran_5[]={
 {sta_error,evt_init,        sta_pend,NULL},
 {sta_error,evt_start,       sta_error,NULL},
 {sta_error,evt_schedule,        sta_error,NULL},
 {sta_error,evt_transOK,        sta_error,NULL},
 {sta_error,evt_transERR,        sta_schedule,NULL},
 {sta_error,evt_stop,  sta_stopping,CE32_File_FileStream_StopAndSave},
 {sta_error,evt_deinit,  sta_uninit,NULL},
}; 

#define STATETRANS(n)  (stateTran_##n)

void CE32_DATABLK_Init(CE32_DataBlock *db)
{
	db->addr=0;
	db->state=0;
}
int CE32_DATABLK_Request(CE32_DataBlock *db,uint32_t addr)
{
	if(CE32_DATABLK_Check(db,CE32_DATABLK_REQUEST)==0)
	{
		return -1;
	}
	db->addr = addr;
	db->state = CE32_DATABLK_REQUEST;
	return 0;
}
int CE32_DATABLK_Check(CE32_DataBlock *db,uint32_t flag)
{
	if((db->state&flag)!=0)
	{
		return 0;
	}
	return -1;
}

void streamMGR_init(streamMGR* h,dataMGR* mgr,uint32_t byteRate,uint32_t baseRate)
{
	streamMGR_reset(h);
	h->byteRate=byteRate;
	uint64_t temp = byteRate*512;
	temp /=baseRate;
	h->byte_per_base_block = temp;
	h->MGR_cnt = 1;
	h->MGR[0]= mgr;
}
void streamMGR_init_dual(streamMGR* h,dataMGR* mgr1, dataMGR* mgr2,uint32_t byteRate,uint32_t baseRate)
{
	streamMGR_init(h,mgr1,byteRate,baseRate);
	h->MGR_cnt = 2;
	h->MGR[1]= mgr2;
}
void streamMGR_reset(streamMGR* h)
{
	h->ptr_in = 0;
	h->ptr_out = 0;
	h->bytes_to_Write=0;
}

void CE32_File_FileStream_UpdateFileStructure(CE32_FileStream *fs)
{
	uint32_t base_rate = 0;
	for(int i=0;i<MAX_FILESTREAM_DATATYPES;i++)
	{
		if(fs->MGR[i].byteRate!=0)
		{
			if(base_rate==0) //first non-zero id is base unit
			{
				base_rate = fs->MGR[i].byteRate;//update base rate to first non-zero datatype
				fs->baseMGR_id = i; //log base MGR id
			}
			uint64_t temp = ((uint64_t)fs->MGR[i].byteRate)*512;
			temp /=base_rate;
			fs->MGR[i].byte_per_base_block = temp;
		}
		else
		{
			fs->MGR[i].byte_per_base_block = 0;
		}
		fs->sysParam->datainfo.type_list[i]=i;
		fs->sysParam->datainfo.byte_per_base_block[i]=fs->MGR[i].byte_per_base_block ;
	}
	fs->sysParam->datainfo.Ntypes = MAX_FILESTREAM_DATATYPES;
	fs->sysParam->datainfo.version = DATA_INFO_VER;
	
}
int CE32_File_FileInfo_Init(CE32_FileInfo *finfo,	uint16_t f_id,uint64_t f_bytes,uint32_t f_sector_start,RTC_TimeTypeDef time,RTC_DateTypeDef date);

int CE32_File_FileStream_ConfigStream(CE32_FileStream *fs, uint8_t streamID,dataMGR* MGR,uint32_t byteRate)
{
	if(streamID>MAX_FILESTREAM_DATATYPES)
		return -1;
	streamMGR_init(&fs->MGR[streamID],MGR,byteRate,0);
	return 0;
}
int CE32_File_FileStream_ConfigStream_dual(CE32_FileStream *fs, uint8_t streamID,dataMGR* MGR,dataMGR* MGR1,uint32_t byteRate)
{
	if(streamID>MAX_FILESTREAM_DATATYPES)
		return -1;
	streamMGR_init_dual(&fs->MGR[streamID],MGR,MGR1,byteRate,0);
	return 0;
}
int CE32_File_FileStream_Init(CE32_FileStream *fs,	SPI_HandleTypeDef *hspi, CE32_systemParam *sysParam, CE32_systemLog *sysLog,	CE32_dspParam  *sysDSP, int state_reset)
{
	if(fs->enabled ==0)
	{
		CE32_File_FileStream_Init_PreAct(fs);
		PROFILE_LOG("SD_FSINIT");
		//0. Check storage system
		//1. Prepare data buffer
		//2. Prepare Periphrial hardware
		fs->hspi=hspi;
		fs->sysDSP=sysDSP;
		fs->sysLog=sysLog;
		fs->sysParam=sysParam;
		fs->f_header_sector=SYS_ADDR;
		fs->f_data_sector=DATA_ADDR;
		fs->f_event_sector = DATA_ADDR;
		
		fs->ephys_misc_cnt = 0;
		fs->file_block_cnt = 0;
		fs->event_block_cnt = 0;
		fs->fail_cnt = 0;
		fs->misc_sample_count=0;
		fs->data_transfering = 0;
		fs->pending_block_cnt = 0U;
		fs->stop_pending = 0;
		CE32_File_FileStream_UpdateFileStructure(fs);
		if(CE32_File_FileStream_LoadParams(fs) != 0)
		{
			return -1;
		}
		CE32_File_FileStream_InitAct();
		fs->time2sps = sysParam->sampling_rate[SYS_ID_SIG_MISC];
		fs->evt_next = evt_schedule; //default event as constant input
		CE32_DATABLK_Init(&fs->readBuf);
		CE32_File_FileStream_PowerSave(fs,fs->power_save);
		
		__IO uint64_t data_rate=0;
		for(int i=0;i<BUF_GROUPS;i++)
		{
			data_rate+=fs->MGR[i].byteRate;
		}
		int log_interval_sec = 16;
		fs->log_interval_blocks = (log_interval_sec*(data_rate)/512/AU_BLOCKS+1)*AU_BLOCKS;
		if(state_reset!=0)
		{
			fs->state = CE32_FILE_STATE_STOP;
			fs->stateMachine = 0;
		}
		return 0;
	}
	else
	{
		PROFILE_LOG("SD_FSINIT_BUSY");
		return -1;
	}
}

int CE32_File_FileStream_2CH_Init(CE32_FileStream *fs,	SPI_HandleTypeDef *hspi, CE32_systemParam *sysParam, CE32_systemLog *sysLog,	CE32_dspParam  *sysDSP,int state_reset)
{
	if(fs->enabled ==0)
	{
		PROFILE_LOG("SD_FSINIT");
		//0. Check storage system
		//1. Prepare data buffer
		//2. Prepare Periphrial hardware
		fs->hspi=hspi;
		fs->sysDSP=sysDSP;
		fs->sysLog=sysLog;
		fs->sysParam=sysParam;
		fs->f_header_sector=SYS_ADDR;
		fs->f_data_sector=DATA_ADDR;
		fs->log_interval_blocks = LOG_INTERVAL;
		fs->ephys_misc_cnt = 0;
		fs->file_block_cnt = 0;
		fs->event_block_cnt = 0;
		fs->fail_cnt = 0;
		fs->misc_sample_count=0;
		fs->data_transfering = 0;
		fs->pending_block_cnt = 0U;
		
		if(CE32_File_FileStream_LoadParams(fs) != 0)
		{
			return -1;
		}
		CE32_File_FileStream_UpdateFileStructure(fs);
		CE32_File_FileStream_InitAct();
		fs->time2sps = sysParam->sampling_rate[SYS_ID_SIG_MISC];
		fs->evt_next = evt_schedule; //default event as constant input
		CE32_DATABLK_Init(&fs->readBuf);
		CE32_File_FileStream_PowerSave(fs,fs->power_save);
		
		__IO uint64_t data_rate=0;
		for(int i=0;i<BUF_GROUPS;i++)
		{
			data_rate+=fs->MGR[i].byteRate;
		}
				int log_interval_sec = 30;
	


		fs->log_interval_blocks = (log_interval_sec*(data_rate)/512/AU_BLOCKS+1)*AU_BLOCKS;
		
		if(state_reset!=0)
		{
			fs->state = CE32_FILE_STATE_STOP;
			fs->stateMachine = 0;
		}
		return 0;
	}
	else
	{
		PROFILE_LOG("SD_FSINIT_BUSY");
		return -1;
	}
}


//int CE32_File_FileStream_ConfigFormat(CE32_FileStream *fs,uint32_t ephys_datarate,uint32_t misc_datarate,uint32_t cam_datarate, uint32_t audio_datarate)
//{
//	fs->ephys_misc_ratio = ephys_datarate/misc_datarate;
//	fs->sysParam->MISC_ratio = fs->ephys_misc_ratio;
//	fs->ephys_camera_ratio = ephys_datarate/cam_datarate;
//	fs->sysParam->Camera_ratio = fs->ephys_camera_ratio;
//	fs->ephys_audio_ratio = ephys_datarate/audio_datarate;
//	fs->sysParam->Audio_ratio = fs->ephys_audio_ratio;
//}

int CE32_File_FileStream_RecPrepare(CE32_FileStream *fs)
{
	CE32_File_FileStream_RecInitAct();
	return 0;
}

int CE32_File_FileStream_exec(CE32_FileStream *fs)
{
	if (fs->stop_requested && fs->stateMachine != sta_stopping) {
		fs->stop_requested = 0;

		// Clear any stale deferred event so it cannot trigger PostStop early
		fs->evt_next = evt_schedule;

		fs_state_event(fs, evt_stop);
		return 0;
	}
	int evt_next = fs->evt_next;
	if(evt_next!=evt_schedule)
	{
		fs->evt_next = evt_schedule;
		fs_state_event(fs,evt_next);
	}
	else
	{
		fs_state_event(fs,evt_schedule);
	}
	return 0;
}


int CE32_File_FileStream_WriteFileLog(CE32_FileStream *fs,int dma_on)
{
	PROFILE_LOG("SD_WRL");
	fs->state=CE32_FILE_STATE_LOG;
	//write speed estimation
	{
		static uint32_t last_addr = 0;
		static uint32_t last_time = 0;

		uint32_t blks = fs->file_block_cnt;
		uint32_t cur_time = DWT->CYCCNT;

		uint32_t d_blks  = blks - last_addr;     // wrap-safe
		uint32_t d_time  = cur_time - last_time; // wrap-safe (cycles)

		if (d_time != 0)
		{
				float bytes = 512.0f * (float)d_blks;
				float seconds = (float)d_time / (float)SystemCoreClock;

				fs->speed_MBs = bytes / seconds / (1024.0f * 1024.0f);
		}
		else
		{
				fs->speed_MBs = 0.0f;
		}

		last_addr = blks;
		last_time = cur_time;
	}
	if(fs->block_transfer)
	{
		HD32_SD_stopTrans();																//Stop current BlockWrite flow
		fs->block_transfer=0;
	}
	//fs->total_records++; //increase one recording
	int rec_id=CE32_FILE_GET_RECORDID(fs);
	
	CE32_systemLog *sysLog=fs->sysLog;
	{
		uint32_t logged_addr = fs->file_addr;
		uint32_t next_start_addr = CE32_File_AlignUpAU(logged_addr);
		/*
		 * Log the exact data end for download. During stop, still advance the
		 * live write pointer so the next recording starts at an AU boundary.
		 */
		if(fs->stop_pending != 0U)
		{
			fs->file_addr = next_start_addr;
		}
		sysLog->log[rec_id] = logged_addr;
	}
	sysLog->evt_log[rec_id]=(fs->event_addr);
	fs->MGR_id = CE32_FILE_BUFFERID_NONE;
	fs->state=CE32_FILE_STATE_LOG;														//Set up logging flag
	if(dma_on)
	{
		if(CE32_File_FileStream_WriteBlock_DMA(fs,fs->log_addr,(uint8_t*)fs->sysLog,0)==-1)
		{
			return -1;
		}
	}
	else
	{
		if(CE32_File_FileStream_WriteBlock(fs,fs->log_addr,(uint8_t*)fs->sysLog,0)==-1)
		{
			return -1;
		}
	}
	return 0;
}

int CE32_File_FileStream_WriteEvent(CE32_FileStream *fs)
{
	PROFILE_LOG("SD_WRE");
	dataMGR *MGR=(dataMGR*) &fs->MGR[CE32_FILE_BUFFERID_EVENT];
	fs->state=CE32_FILE_STATE_EVENT;
	fs->MGR_id=CE32_FILE_BUFFERID_EVENT;
	CE32_File_FileStream_WriteBlock_DMA(fs,fs->event_addr,(uint8_t*)(MGR->dataPtr)+MGR->outPTR[0],1);
	return 0;
}

int CE32_File_FileStream_ReadBlock(CE32_FileStream *fs)
{
	PROFILE_LOG("SD_RD");
	if(fs->block_transfer)
	{
		HD32_SD_stopTrans();																//Stop current BlockWrite flow
		fs->block_transfer=0;
	}
	if(CE32_File_ReadSingleBlockRetry(fs->readBuf.addr,fs->readBuf.buf) != 0)
	{
		CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_READ);
		return -1;
	}
	fs->readBuf.state = CE32_DATABLK_READY;
	return 0;
}

int CE32_File_FileStream_LoadParams(CE32_FileStream *fs)
{
	CE32_File_FileStream_PreLoadAct();
	PROFILE_LOG("SD_LD");
	if(CE32_File_IsXeNpRawLayout(fs) != 0U)
	{
		/*
		 * XE_NP runtime owns the active NRIC/Neuropixels configuration. Avoid
		 * CE64 startup reads from stale SYS/DSP sectors; they are not needed to
		 * open a raw NP session and can wedge SDMMC when the card is in UHS mode.
		 */
		fs->sysParam->firmware_version = FM_VERSION;
		CE32_File_ClearSystemLogBlock(fs->sysLog);
		fs->log_addr = LOG_ADDR;
		fs->total_records = 0U;
		(void)HD32_SD_readCSD(fs->hspi, fs->sysParam);
		if(fs->sysParam->SD_capacity > 0x8000U)
		{
			uint64_t event_offset_sector = ((uint64_t)fs->sysParam->SD_capacity - 0x8000ULL);
			fs->f_event_sector = (uint32_t)event_offset_sector;
		}
		CE32_File_FileStream_PostLoadAct();
		CE32_File_FileStream_UpdateFileStructure(fs);
		return 0;
	}

	if(CE32_File_ReadSingleBlockRetry(SYS_ADDR,(uint8_t*)fs->sysParam) != 0)
	{
		CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_READ);
		return -1;
	}
	fs->sysParam->firmware_version = FM_VERSION;
	if((CE32_File_ReadSingleBlockRetry(DSP1_ADDR,(uint8_t*)&fs->sysDSP[0]) != 0) ||
	   (CE32_File_ReadSingleBlockRetry(DSP2_ADDR,(uint8_t*)&fs->sysDSP[1]) != 0))
	{
		CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_READ);
		return -1;
	}
	uint32_t log_id=0U;
	uint32_t total_records = 0U;
	int read_next=1;
	fs->total_records=0;
	if(CE32_FILE_LOG_BLOCK_LIMIT == 0U)
	{
		CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_FORMATERR);
		return -1;
	}
	while(read_next)
	{
		if(log_id >= CE32_FILE_LOG_BLOCK_LIMIT)
		{
			CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_FORMATERR);
			return -1;
		}
		if(CE32_File_ReadSingleBlockRetry(LOG_ADDR+log_id,(uint8_t*)fs->sysLog) != 0)
		{
			CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_READ);
			return -1;
		}
		if(CE32_File_ValidateSystemLogBlock(fs->sysLog) != 0)
		{
			if(log_id == 0U)
			{
				/*
				 * An erased/stale card can contain a small nonzero Nrec with
				 * zero record addresses. Treat the first bad log block as an
				 * empty log instead of letting StartNewFile write sector 0.
				 */
				CE32_File_ClearSystemLogBlock(fs->sysLog);
				fs->log_addr = LOG_ADDR;
				fs->total_records = 0U;
				read_next = 0;
				break;
			}
			CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_FORMATERR);
			return -1;
		}
		if(total_records > (uint32_t)0xFFFFU - fs->sysLog->Nrec)
		{
			CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_FORMATERR);
			return -1;
		}
		total_records += fs->sysLog->Nrec;
		if(fs->sysLog->Nrec==MAX_LOG_PER_BLOCK)
		{
			++log_id;
			read_next=1;
		}
		else
		{
			fs->log_addr=LOG_ADDR+log_id;
			fs->total_records = (uint16_t)total_records;
			read_next=0;
		}
	}
	
	HD32_SD_readCSD(fs->hspi,fs->sysParam);
	if(fs->sysParam->SD_capacity>0)
	{
		int sd_GB= fs->sysParam->SD_capacity/0x200000; //Block count(512B) calculate event recording sectors for the offset location
		//uint64_t event_offset_sector = (fs->sysParam->SD_capacity-sd_GB*EVENT_SECTOR_OFFSET_PER_GB);
		uint64_t event_offset_sector = (fs->sysParam->SD_capacity-0x8000);
		fs->f_event_sector=event_offset_sector;
	}
	CE32_File_FileStream_PostLoadAct();
	CE32_File_FileStream_UpdateFileStructure(fs);
	return 0;
}
int CE32_File_FileStream_SaveParams(CE32_FileStream *fs)
{
	//Save recording configurations
	if((CE32_File_WriteSingleBlockRetry(SYS_ADDR,(uint8_t*)fs->sysParam)!=0) ||
	   (CE32_File_WriteSingleBlockRetry(DSP1_ADDR,(uint8_t*)&fs->sysDSP[0])!=0) ||
	   (CE32_File_WriteSingleBlockRetry(DSP2_ADDR,(uint8_t*)&fs->sysDSP[1])!=0))
	{
		CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_WRITE);
		return -1;
	}
#ifdef __CE32_SYNC
	if(CE32_File_WriteSingleBlockRetry(SYNCREC_ADDR,(uint8_t*)&delay_estimate)!=0)
	{
		CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_WRITE);
		return -1;
	}
#endif
	return 0;
}

int CE32_File_FileStream_RemoveFile(CE32_FileStream *fs,uint16_t n);

int CE32_File_FileStream_Init_StartNewFile(CE32_FileStream *fs)
{
	CE32_File_FileStream_RecPrepare(fs);
	return CE32_File_FileStream_StartNewFile(fs);
}



int CE32_File_FileStream_StartNewFile(CE32_FileStream *fs)
{
	PROFILE_LOG("SD_NEW");
	if(fs->enabled==1)
		return -1;
	
//	// HARD RESET SESSION STATE
//	fs->file_block_cnt = 0;
//	fs->event_block_cnt = 0;
//	fs->last_logged_block = 0;
//	fs->ephys_misc_cnt = 0;

//	fs->WR_addr = fs->file_addr;
//	fs->block_transfer = 0;
//	fs->data_transfering = 0;

//	for(int i=0;i<MAX_FILESTREAM_DATATYPES;i++){
//		fs->MGR[i].bytes_to_Write = 0;
//		fs->MGR[i].ptr_in = 0;
//		
//	}

//	fs->stateMachine = sta_pend;
//	fs->evt_next = evt_schedule;
	for(int i=0;i<MAX_FILESTREAM_DATATYPES;i++)
	{
		streamMGR_reset(&fs->MGR[i]);
	}
	CE32_File_FileStream_PreStartAct();
	CE32_systemLog *sysLog=fs->sysLog;
	CE32_systemLog prevLog;
	const CE32_systemLog *lastLog = sysLog;
	uint32_t existing_records = fs->total_records;
	uint32_t write_log_id = existing_records / MAX_LOG_PER_BLOCK;
	uint32_t rec_id;
	uint32_t last_rec_id = 0U;
	uint8_t starts_new_log_block = ((existing_records % MAX_LOG_PER_BLOCK) == 0U) ? 1U : 0U;

	if(existing_records >= 0xFFFFU)
	{
		CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_FORMATERR);
		return -1;
	}
	if((LOG_ADDR + write_log_id) >= DATA_ADDR)
	{
		CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_FORMATERR);
		return -1;
	}
	
	if(existing_records==0U) //If card is empty, start logging from default header address
	{
		fs->file_addr=fs->f_data_sector;
		fs->event_addr=fs->f_event_sector;
	}
	else
	{
		last_rec_id = (existing_records - 1U) % MAX_LOG_PER_BLOCK;
		if((starts_new_log_block != 0U) && (sysLog->Nrec == 0U))
		{
			if((fs->log_addr <= LOG_ADDR) ||
			   (CE32_File_ReadSingleBlockRetry(fs->log_addr - 1U, (uint8_t*)&prevLog) != 0))
			{
				CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_READ);
				return -1;
			}
			if((CE32_File_ValidateSystemLogBlock(&prevLog) != 0) ||
			   (prevLog.Nrec != MAX_LOG_PER_BLOCK))
			{
				CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_FORMATERR);
				return -1;
			}
			lastLog = &prevLog;
		}
		fs->file_addr=lastLog->log[last_rec_id];
		fs->event_addr=lastLog->evt_log[last_rec_id];
		if((fs->file_addr < DATA_ADDR) || (fs->event_addr < DATA_ADDR))
		{
			CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_FORMATERR);
			return -1;
		}
		/* Backward compatibility: normalize legacy non-AU-aligned log entries. */
		fs->file_addr = CE32_File_AlignUpAU(fs->file_addr);
	}
	
	fs->log_addr = LOG_ADDR + write_log_id;
	if(starts_new_log_block != 0U)
	{
		sysLog->Nrec=0;
		//log first address to the first recording of each block
		sysLog->log[0]=fs->file_addr;
		sysLog->evt_log[0]=fs->event_addr;
		if(CE32_File_WriteSingleBlockRetry(fs->log_addr,(uint8_t*)sysLog)!=0)
		{
			CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_WRITE);
			return -1;
		}
	}
	fs->misc_sample_count=0;
	
	fs->total_records++; //increase one recording
	rec_id=(fs->total_records - 1U) % MAX_LOG_PER_BLOCK;
	sysLog->Nrec = rec_id+1;
	//Clear next log sector's when the current log space uses up, to avoid data reading issue
	if(rec_id==(MAX_LOG_PER_BLOCK - 1U))
	{
		uint8_t seudo_data[512] = {0};
		if(((fs->log_addr + 1U) < DATA_ADDR) &&
		   (CE32_File_WriteSingleBlockRetry(fs->log_addr + 1U,(uint8_t*)seudo_data)!=0))
		{
			CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_WRITE);
			return -1;
		}
	}
		
	//update time
	HAL_RTC_GetTime(&hrtc,(RTC_TimeTypeDef*)&fs->sysParam->time,RTC_FORMAT_BIN);
	HAL_RTC_GetDate(&hrtc,(RTC_DateTypeDef*)&fs->sysParam->date,RTC_FORMAT_BIN);
	//log recording configurations
	if((CE32_File_WriteSingleBlockRetry(fs->file_addr,(uint8_t*)fs->sysParam)!=0) ||
	   (CE32_File_WriteSingleBlockRetry(fs->file_addr+1,(uint8_t*)&fs->sysDSP[0])!=0) ||
	   (CE32_File_WriteSingleBlockRetry(fs->file_addr+2,(uint8_t*)&fs->sysDSP[1])!=0))
	{
		CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_WRITE);
		return -1;
	}
	//fs->file_addr+= fs->sysParam->MISC_interval+1; //move to next full block
	fs->file_addr+= DATA_INFO_HEADER_SIZE; //move to next full block

	fs->enabled=1;
	{	//Start writing Header using DMA
		fs->state=CE32_FILE_STATE_PEND;														//Set up logging flag
		//SDSPI_DMA_Enable();  //Enable DMA stream, fix made by ZZ 190522 to avoid event setup flag after ISR fire																																//Header update transmittion started
	}
	CE32_File_FileStream_StartAct();
	return 0;
}

int CE32_File_FileStream_StopAndSave(CE32_FileStream *fs)
{
	PROFILE_LOG("SD_STOP");
	fs->stop_pending = 1;
	uint32_t stop_guard = 0U;
	while(fs->data_transfering)
	{
		CE32_File_FileStream_CheckTransfer(fs);
		if(++stop_guard > 2000000U)
		{
			/* Do not deadlock stop sequence on a stuck DMA/SD state. */
			fs->data_transfering = 0;
			break;
		}
	}
	if(fs->block_transfer)
	{
		HD32_SD_stopTrans();																//Stop current BlockWrite flow
		fs->block_transfer=0;
	}
	fs->pending_block_cnt = 0U;
	uint8_t log_retry = 0U;
	while(CE32_File_FileStream_WriteFileLog(fs,0)!=0)
	{
		CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_WRITE);
		if(++log_retry >= 3U)
		{
			break;
		}
	}
	if(log_retry < 3U)
	{
		CE32_File_FileStream_SaveParams(fs);
	}
	fs->stop_pending = 0;
	/* Ensure sta_stopping can transition through PostStop on next exec tick. */
	fs->evt_next = evt_transOK;
	return 0;
}

int CE32_File_FileStream_StopAndDiscard(CE32_FileStream *fs);
//check if buffer has pending data to transfer, return 0 if nothing is pending.
int CE32_File_FileStream_SleepCheck(CE32_FileStream *fs)
{
	int resp=0;
	for(int i=0;i<CE32_FILE_BUFFERMGR_COUNT;i++)
	{
		dataMGR* mgr = (dataMGR*)&fs->MGR[i];
		resp|=mgr->bufferUsed[0]>512;
	}
	return resp;
}

int CE32_File_FileStream_PostStop(CE32_FileStream *fs)
{
	PROFILE_LOG("SD_POSSTOP");
	if(fs->enabled)
	{
		fs->enabled=0;
	}
	fs->pending_block_cnt = 0U;
	fs->state=CE32_FILE_STATE_STOP;
	CE32_File_FileStream_StopAct();
	return 0;
}

int CE32_File_FileStream_DataScheduler(CE32_FileStream *fs)
{
	//State of the file-logging
	//1. Stop 2.Config writing Ephys 3.Block Write Ephys 4.Stop writing 5.Configure writing MISC 6. Block writing MISC 7.Writing log 8.Writing Event
	//IT events: DMA transfer complete
	
	/*Process:
		Start logging in pending mode
	Pending service configure target write address and block counts(transfer_block_cnt).
		Then program enter each process(since they have the same routine, should handle them with same function with different address.
		
	Inside each routine
		1. check if DMA transfer is finished
		2. check with SD card to see if DMA transfer is successful
		3a. start a new writing if transfer_block_cnt not reach to target
		3b. terminate block write and set back to pend
		
	*/
	//Task planner (Only execute after main process is finished)

	//Check buffer status
	//PROFILE_LOG("SD_SCH");
	FS_PROFILE_TIME(fs_profile_schedule);
	if (fs->data_transfering) return 0;
	static uint32_t stream_idle_since_tick = 0U;
	streamMGR *mgrs = fs->MGR;

	dataMGR* MGR_ephys = (mgrs[CE32_FILE_BUFFERID_EPHYS].MGR[0]);
	dataMGR* MGR_misc = (mgrs[CE32_FILE_BUFFERID_MISC].MGR[0]);
	static uint8_t ephys_buf_full_report_latched = 0U;
	/* Use the active ephys ring size; BUF_SIZE is global backing store and can mask real overruns. */
	if(MGR_ephys->bufferUsed[0] >= MGR_ephys->dataSize)
	{
		if(ephys_buf_full_report_latched == 0U)
		{
			uint32_t used = MGR_ephys->bufferUsed[0];
			if(used > 0xFFFFFU){ used = 0xFFFFFU; }
			ce32_ephys_ovr_ble_used = used;
			ce32_ephys_ovr_ble_pending = 1U;
			ephys_buf_full_report_latched = 1U;
		}
		//CE32_File_FileStream_BufferPurge(fs);
	}
	else
	{
		ephys_buf_full_report_latched = 0U;
	}
	
	//Configure block write address here
	//System timer requests metadata update every fixed period (10s).
	//Flush log only at AU boundary to keep log address AU-aligned.
	{
		uint8_t do_log_update = 0U;
		if(ce32_log_update_pending != 0U)
		{
#if ((AU_BLOCKS & (AU_BLOCKS - 1)) == 0)
			do_log_update = ((fs->file_addr & (AU_BLOCKS - 1U)) == 0U) ? 1U : 0U;
#else
			do_log_update = ((fs->file_addr % AU_BLOCKS) == 0U) ? 1U : 0U;
#endif
			if((do_log_update != 0U) && (CE32_File_ShouldDeferLogUpdate(fs) != 0U))
			{
				do_log_update = 0U;
			}
		}
		if(do_log_update != 0U)
		{
			if(CE32_File_FileStream_WriteFileLog(fs,1)==0)
			{
				ce32_log_update_pending = 0U;
				fs->last_logged_block=fs->file_block_cnt;
			}
			else
			{
				CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_WRITE);
			}
		}
		else
	{
		if(fs->block_transfer)
		{
			if(CE32_File_HasPendingBlockWrite(fs) != 0U)
			{
				stream_idle_since_tick = 0U;
				#ifdef __PROFILE
					profile.SD_Write[0]=DWT->CYCCNT;
				#endif
				
				CE32_File_FileStream_WriteData(fs);
				
				#ifdef __PROFILE
					profile.SD_Write[1]=DWT->CYCCNT - profile.SD_Write[0];
				#endif
			}
			else
			{
				if(CE32_File_ShouldKeepBlockTransferHot(fs) != 0U)
				{
					/* Keep CMD25 stream hot across short producer gaps to avoid
					   stop/start churn; only stop after sustained idle. */
					uint32_t now_tick = HAL_GetTick();
					if(stream_idle_since_tick == 0U)
					{
						stream_idle_since_tick = now_tick;
					}
					else if((int32_t)(now_tick - stream_idle_since_tick) >=
					        CE32_FILE_DMA_BLOCK_TRANSFER_IDLE_GRACE_MS)
					{
						if(fs->block_transfer)
						{
							HD32_SD_stopTrans(); //stop block transfer
							fs->block_transfer=0;
						}
						stream_idle_since_tick = 0U;
					}
				}
			}
		}
		else //not in block transfer
		{//wait until a full super page ready
			stream_idle_since_tick = 0U;
			if(MGR_misc->bufferUsed[0]>=fs->WR_threshold) //check if data buffer fills one sector(512B)
			{
				#ifdef __PROFILE
					profile.SD_Write[0]=DWT->CYCCNT;
				#endif
				
				CE32_File_FileStream_WriteData(fs);
				
				#ifdef __PROFILE
					profile.SD_Write[1]=DWT->CYCCNT - profile.SD_Write[0];
				#endif
			}
			else
			{
				if(CE32_DATABLK_Check(&fs->readBuf,CE32_DATABLK_REQUEST)==0)
				{
					CE32_File_FileStream_ReadBlock(fs);
				}
			}
			//Do nothing.
		}
	}
	}

	return 0;
}

void CE32_File_FileStream_ServiceDeferredSignals(void)
{
	if(ce32_ephys_ovr_ble_pending == 0U)
	{
		return;
	}
	if((BLE_handle.state & HJ580_STATE_CONNECTED) == 0U)
	{
		return;
	}
	{
		CE32_INTERCOM_Handle* ic = (CE32_INTERCOM_Handle*)&BLE_handle;
		if(ic->CMD_TX.cmd_pending >= 8U)
		{
			return;
		}
		char ovr_msg[7];
		uint32_t used = ce32_ephys_ovr_ble_used;
		ovr_msg[0] = 'O';
		for(int i=0;i<5;i++)
		{
			uint8_t nib = (uint8_t)((used >> (4U * (4U - (uint32_t)i))) & 0x0FU);
			ovr_msg[1+i] = (char)(nib < 10U ? ('0' + nib) : ('A' + (nib - 10U)));
		}
		ovr_msg[6] = '\0';
		if(CE32_INTERCOM_TX_Message(ic,ovr_msg)==0)
		{
			CE32_INTERCOM_TX_Start_DMA(ic);
			ce32_ephys_ovr_ble_pending = 0U;
		}
	}
}

int CE32_File_FileStream_WriteData(CE32_FileStream *fs)
{
	streamMGR *mgrs = fs->MGR;
	streamMGR *sMGR = NULL;
	int start_next_cycle = 1;

	/*
	 * Keep dual-bank paced stream writes atomic.
	 * If base stream is mid-cycle (ptr_in != 0), finish remaining sub-bank(s)
	 * before switching to lower-priority streams; otherwise block ordering can
	 * drift and appear as a continuous shift until the next stream boundary.
	 */
	{
		streamMGR *base = &mgrs[fs->baseMGR_id];
		if((base->MGR_cnt > 1U) && (base->ptr_in != 0U))
		{
			if(base->MGR[0]->bufferUsed[0] < 512U)
			{
				return CE32_FILE_RESP_DATA_NOT_READY;
			}
			fs->MGR_id = fs->baseMGR_id;
			sMGR = base;
			start_next_cycle = 0;
		}
	}

	if(start_next_cycle != 0)
	{
		for(int idx=0;idx<MAX_FILESTREAM_DATATYPES;idx++)//chech if lower rank buffer is ready
		{
			if(mgrs[idx].bytes_to_Write>=512)
			{
				fs->MGR_id=idx;
				sMGR=&mgrs[idx];
				start_next_cycle=0;
				break;
			}
		}
	}
	if(start_next_cycle!=0) //start writing base unit
	{
		if(mgrs[fs->baseMGR_id].MGR[0]->bufferUsed[0]>=512)
		{
			fs->MGR_id=fs->baseMGR_id; //log current MGR
			sMGR=&mgrs[fs->MGR_id];
		}
		else
		{
			return CE32_FILE_RESP_DATA_NOT_READY;
		}
	}
	if(fs->file_addr<(fs->f_event_sector-LOG_INTERVAL))
	{	
		dataMGR* MGR = sMGR->MGR[sMGR->ptr_in]; //Get current using MGR inside same stream
		uint32_t dataptr;
		uint16_t block_count;
		if((sMGR->MGR_cnt > 1U) && (fs->MGR_id == fs->baseMGR_id))
		{
			/* Dual-ephys banks share the paced read pointer from MGR[0]. */
			dataptr = sMGR->MGR[0]->outPTR[0];
		}
		else
		{
			dataptr = MGR->outPTR[0];
		}
		fs->state = CE32_FILE_STATE_EPHYS; //All data part falling to EPhys block as its continuous blocks
		block_count = CE32_File_FileStream_SelectBlockWriteCount(fs, sMGR, MGR);
		if(CE32_File_FileStream_WriteBlock_DMA(
			fs,
			fs->file_addr,
			(uint8_t*)(MGR->dataPtr)+dataptr,
			block_count) != 0)
		{
			CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_WRITE);
			return CE32_FILE_RESP_ERROR;
		}
	}
	else
	{
		/* Capacity boundary reached during scheduler path; map to card-full behavior. */
		CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_CARDFULL);
		return CE32_FILE_RESP_INVALID_ADDR;
	}
	return CE32_FILE_RESP_OK;
}


int CE32_File_FileStream_WriteBlock(CE32_FileStream *fs,uint32_t addr,uint8_t* dataptr,uint16_t multi_blk)
{
	(void)multi_blk;
	{ //start single block transfer
		PROFILE_LOG("SD_WRBLKCPU");
		if(fs->block_transfer)
		{
			HD32_SD_stopTrans(); //stop block transfer
			fs->block_transfer=0;
		}
		fs->WR_addr = addr;
		fs->pending_block_cnt = 1U;
		fs->data_transfering = 1;
		if(HD32_SD_writeSingleBlock(addr,dataptr)!=0)
		{
			fs->pending_block_cnt = 0U;
			return -1;
		}
		fs->evt_next = evt_transOK;
		//fs_state_event(fs,evt_transOK);
	}
	return 0;
}

int CE32_File_FileStream_WriteBlock_DMA(CE32_FileStream *fs,
                                       uint32_t addr,
                                       uint8_t *dataptr,
                                       uint16_t multi_blk)
{
	uint16_t block_count = (multi_blk == 0U) ? 1U : multi_blk;

    fs->SD_DMA_GUARD = 0;

    if (!multi_blk) {
        PROFILE_LOG("SD_WRBLK");
        if (fs->block_transfer) {
            HD32_SD_stopTrans();
            fs->block_transfer = 0;
        }
        fs->WR_addr = addr;
        fs->pending_block_cnt = 1U;
        fs->data_transfering = 1;
        fs->stateMachine = sta_tranfer;

        if (HD32_SD_writeSingleBlock_DMA(addr, dataptr) == 0) {
            SDSPI_DMA_Enable();
            return 0;
        }
        fs->pending_block_cnt = 0U;
        return -1;
    }

    // -------- multi-block path --------
    int need_restart = 0;

    if (!fs->block_transfer) {
        need_restart = 1;
    } else if (fs->WR_addr != addr) {
        need_restart = 1;
    } else {
        // Only check preerase limit when we are at an AU boundary
        // (optimize %AU_BLOCKS if AU_BLOCKS is power-of-two)
#if ((AU_BLOCKS & (AU_BLOCKS - 1)) == 0)
        if ((fs->file_addr & (AU_BLOCKS - 1)) == 0)
#else
        if ((fs->file_addr % AU_BLOCKS) == 0)
#endif
        {
            if ((fs->file_addr - fs->preErase_block) >= MAX_PREERASE_CNT) {
                need_restart = 1;
            }
        }
    }

    if (need_restart) {
        if (fs->block_transfer) {
            HD32_SD_stopTrans();
            fs->block_transfer = 0;
        }
        if (fs->power_save == 0) {
            if (HD32_SD_preErase(MAX_PREERASE_CNT) != 0) {
                fs->data_transfering = 0;
                return -1;
            }
        }
        fs->preErase_block = addr;
        if (HD32_SD_writeBlock(addr) != 0) {
            fs->data_transfering = 0;
            return -1;
        }
        fs->block_transfer = 1;
    }

#ifdef __PROFILE
    profile.SD_Write[2] = DWT->CYCCNT - profile.SD_Write[0];
#endif
    PROFILE_LOG("SD_WRBLKM");
		FS_PROFILE_PERIOD(fs_profile_wdata,fs_profile_transfercplt);
		//FS_PROFILE_PERIOD(fs_profile_wdata,fs_profile_wdata);
		FS_PROFILE_TIME(fs_profile_wdata);
		
    fs->WR_addr = addr;
    fs->pending_block_cnt = block_count;
    fs->data_transfering = 1;

    if (fs->stateMachine == sta_schedule) {
        fs->stateMachine = sta_tranfer;
    }

    if (HD32_SD_write_DMA(dataptr, (uint16_t)(block_count * 512U)) != 0) {
        fs->pending_block_cnt = 0U;
        fs->data_transfering = 0;
        return -1;
    }
    return 0;
}

int CE32_File_FileStream_WriteBlock_DMA_(CE32_FileStream *fs,uint32_t addr,uint8_t* dataptr,uint16_t multi_blk)
{
	//check if currently in multiblock stream mode
	if(multi_blk)
	{
		int send_wr_cmd = 0; //Send CMD25 before data
		if(fs->block_transfer)
		{
			if((fs->WR_addr!=addr))
			{
				HD32_SD_stopTrans(); //stop block transfer
				fs->block_transfer=0;
				send_wr_cmd = 1;
			}
			else
			{
				if(fs->file_addr%AU_BLOCKS==0) //Only check when a Full AU block is written
				{
					if(fs->file_addr-fs->preErase_block>=MAX_PREERASE_CNT) //Check if max preerase count is reached
					{
						HD32_SD_stopTrans(); //stop block transfer
						fs->block_transfer=0;
						send_wr_cmd = 1;
					}
				}
			}
		}
		else
		{
			send_wr_cmd = 1;
		}
		if(send_wr_cmd)
		{
			if(fs->power_save==0)
			{
				HD32_SD_preErase(MAX_PREERASE_CNT); 
			}
			fs->preErase_block = addr;
			if(HD32_SD_writeBlock(addr)!=0)
			{
				return -1;
			}
		}
		#ifdef __PROFILE
			profile.SD_Write[2]=DWT->CYCCNT-profile.SD_Write[0];
		#endif
		PROFILE_LOG("SD_WRBLKM");
		fs->WR_addr = addr;
		fs->block_transfer = 1;
		fs->data_transfering = 1;
		if(fs->stateMachine==sta_schedule)
		{
			fs->stateMachine = sta_tranfer;
		}
		HD32_SD_write_DMA(dataptr,512); //sending a block of data with DMA

	}
	else
	{ //start single block transfer
		PROFILE_LOG("SD_WRBLK");
		if(fs->block_transfer)
		{
			HD32_SD_stopTrans(); //stop block transfer
			fs->block_transfer=0;
		}
		fs->WR_addr = addr;
		fs->data_transfering = 1;
		fs->stateMachine = sta_tranfer;
		if(HD32_SD_writeSingleBlock_DMA(addr,dataptr)==0)
		{
			SDSPI_DMA_Enable();		
		}
		else
		{
			return -1;
		}
	}
	fs->SD_DMA_GUARD = 0;
	return 0;
}

int CE32_File_FileStream_CheckTransfer(CE32_FileStream *fs)
{
	if(fs->data_transfering) 
	{
		//finish transmittion if interrupt routine is not triggered
		if(SD_DMA_TX->NDTR==0 )
		{
			if(fs->SD_DMA_GUARD++>10)
			{
				PROFILE_LOG("SD_TRMAN");
				fs_state_event(fs,evt_transOK);
				fs_state_event(fs,evt_schedule);
			}
		}
	}
	else
	{
		/* Keep sta_stopping until explicit evt_transOK drives PostStop. */
		if(!fs->stop_pending)
		{
			fs->stateMachine = sta_schedule;
		}
	}
	return 0;
}

int CE32_File_FileStream_TransOK(CE32_FileStream *fs)
{
	#ifdef __PROFILE
		profile.SD_Write[3]=DWT->CYCCNT - profile.SD_Write[0];
	#endif
	uint32_t completed_blocks = (fs->pending_block_cnt == 0U) ? 1U : fs->pending_block_cnt;
	fs->data_transfering=0;
	if(fs->file_addr>=fs->f_event_sector)
	{
		fs->state = CE32_FILE_STATE_STOP;//
		CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_CARDFULL);
	}
	if(HD32_SD_writeBlock_DMA_Check()==0)
	{ //check if the data transmittion was successful
		PROFILE_LOG("SD_TROK");
		FS_PROFILE_TIME(fs_profile_transfercplt);
		FS_PROFILE_PERIOD(fs_profile_transfercplt,fs_profile_wdata);
		if(fs->block_transfer==1)
		{
			fs->WR_addr += completed_blocks; //advancing the data pointer for block mode
		}
		
		// handling data receition
		if(fs->MGR_id!=CE32_FILE_BUFFERID_NONE) //for logging other signals without MGR,like log
		{
			if(fs->MGR_id == CE32_FILE_BUFFERID_EVENT) //Event is treating as conventional MGR
			{
					dataMGR_deQueue(fs->MGR[fs->MGR_id].MGR[0],512U * completed_blocks,0);
					fs->event_block_cnt += completed_blocks; //increase current block file size
					fs->event_addr += completed_blocks;
			}
			else //Stream MGRs
			{
				streamMGR* sMGR = &fs->MGR[fs->MGR_id];
				if(sMGR->MGR_cnt == 1U)
				{
					dataMGR_deQueue(sMGR->MGR[0],512U * completed_blocks,0);
					if(fs->MGR_id == fs->baseMGR_id) //if this is the highest priority pace signal
					{
						for(int idx=fs->baseMGR_id+1;idx<MAX_FILESTREAM_DATATYPES;idx++)//update counts for non-paced signals
						{
							fs->MGR[idx].bytes_to_Write+=fs->MGR[idx].byte_per_base_block*completed_blocks;
						}
					}
					else
					{
						sMGR->bytes_to_Write-=512U * completed_blocks;//decrease counter after success
					}
				}
				else if(sMGR->ptr_in==sMGR->MGR_cnt-1) //only update pointer when all subMGR finished Xfer
				{
					sMGR->ptr_in=0;
					dataMGR_deQueue(sMGR->MGR[0],512,0);
					if(fs->MGR_id == fs->baseMGR_id) //if this is the highest priority pace signal
					{
						for(int idx=fs->baseMGR_id+1;idx<MAX_FILESTREAM_DATATYPES;idx++)//update counts for non-paced signals
						{
							fs->MGR[idx].bytes_to_Write+=fs->MGR[idx].byte_per_base_block*sMGR->MGR_cnt; //advance per block*blocks in pacing stream
						}
					}
					else
					{
						sMGR->bytes_to_Write-=512;//decrease counter after success
					}
				}
				else
				{
					sMGR->ptr_in++; //move to next subMGR in same data stream
				}
				fs->file_block_cnt += completed_blocks; //increase current file size
				fs->file_addr += completed_blocks;
			}
		}
		fs->pending_block_cnt = 0U;

		fs->state = CE32_FILE_STATE_PEND;
		//Kick next schedule immediately
		if (fs->stateMachine != sta_stopping && fs->data_transfering == 0)
		{
				// Keep the state machine in scheduling mode so DataScheduler can start a new DMA write
				fs->stateMachine = sta_schedule;
				CE32_File_FileStream_DataScheduler(fs);
				// If DataScheduler starts a write, it will set data_transfering=1 and move to sta_tranfer.
		}
	}
else
{
	PROFILE_LOG("SD_TRERR");
	//Data transfer failed.
	if(fs->block_transfer)
	{
		HD32_SD_stopTrans();																//Stop current BlockWrite flow
		fs->block_transfer=0;
	}
	fs->fail_cnt++;
	fs->state = CE32_FILE_STATE_PEND;
	fs->pending_block_cnt = 0U;
	
}
	//fs_state_event(fs,evt_schedule);

	#ifdef __PROFILE
		profile.SD_Write[4]=DWT->CYCCNT - profile.SD_Write[0];
	#endif
	return 0;
}
int CE32_File_FileStream_TransERR(CE32_FileStream *fs)
{
	fs->data_transfering=0;
	fs->pending_block_cnt = 0U;
	CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_TRANSERR);
	//fs_state_event(fs,evt_schedule);
	return 0;
}

int CE32_File_FileStream_BufferPurge(CE32_FileStream *fs)
{
	return 0;
//	PROFILE_LOG("SD_BFOV");
//	fs->state=CE32_FILE_STATE_PEND;														//Set up pending flag
//	//Discard all avaliable data in the buffer(does not affect data alignment)
//	//Only purge high data rate buffer(Ephys)
//	//MGR keeps a record of acquired Ephys data
//	dataMGR *mgr = (dataMGR*) &fs->MGR[0];
//	int pagecnt = (mgr->bufferUsed[0]-BUF_SIZE/8) / (512);		//count the number of byte to be flushed of Ephys block
//	dataMGR_deQueue(mgr, pagecnt * 512, 0);																							//Flush dataPTR to rollback outPTR
//	//dataMGR_init(&MGR_misc, (char*)misc_buf, sizeof(misc_buf));		//misc FIFO setup 
//	//pagecnt *= 2 ; //for 64ch
//	fs->fail_cnt+= 2 * pagecnt;
//	fs->file_addr += 2 * pagecnt;
//	fs->file_block_cnt += 2 * pagecnt;
//	fs->ephys_misc_cnt += 2* pagecnt;
//	
//	int rec_skip=fs->ephys_misc_cnt / MISC_INTERVAL; //calculate MISC data need to be discarded based on the Ephys flushed block numbers
//	fs->file_addr += rec_skip;
//	fs->file_block_cnt += rec_skip;
//	fs->ephys_misc_cnt -=rec_skip*MISC_INTERVAL;
//	dataMGR *mgr1 = (dataMGR*) &fs->MGR[1];
//	dataMGR_deQueue(mgr1, rec_skip * 512, 0);							//Flush dataPTR to rollback outPTR
//	if(pagecnt>BUF_SIZE/512)
//	{
//		CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_OVR);
//	}
//	return 0;
}

int CE32_File_FileStream_GetFileAddr(CE32_FileStream *fs,uint32_t file_id,uint32_t* addr)
{
	CE32_systemLog log_block;
	const CE32_systemLog *src_log;
	uint32_t rec_index;
	uint32_t log_id;
	uint32_t rec_id;
	uint32_t current_log_id;

	if((fs == NULL) || (addr == NULL) || (file_id == 0U) || (file_id > fs->total_records))
	{
		return -1;
	}

	rec_index = file_id - 1U;
	log_id = rec_index / MAX_LOG_PER_BLOCK;
	rec_id = rec_index % MAX_LOG_PER_BLOCK;

	if((LOG_ADDR + log_id) >= DATA_ADDR)
	{
		CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_FORMATERR);
		return -1;
	}

	current_log_id = (fs->log_addr >= LOG_ADDR) ? (fs->log_addr - LOG_ADDR) : 0xFFFFFFFFU;
	if((current_log_id == log_id) && (fs->sysLog != NULL))
	{
		src_log = fs->sysLog;
	}
	else
	{
		if(CE32_File_ReadSingleBlockRetry(LOG_ADDR + log_id, (uint8_t*)&log_block) != 0)
		{
			CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_READ);
			return -1;
		}
		if(CE32_File_ValidateSystemLogBlock(&log_block) != 0)
		{
			CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_FORMATERR);
			return -1;
		}
		src_log = &log_block;
	}

	if(rec_id >= src_log->Nrec)
	{
		CE32_File_FileStream_ErrorAct(CE32_FILE_ERROR_FORMATERR);
		return -1;
	}

	*addr = src_log->log[rec_id];
	return 0;
}

void CE32_File_FileStream_PowerSave(CE32_FileStream *fs,int enabled)
{
	//enabled=0;//Temp solution to disable PWRsave
	if(enabled==0)
	{
		fs->power_save = 0;
		fs->WR_threshold = CE32_FILE_WR_THRESHOLD_BYTES;
	}
	else
	{
		fs->power_save = 1;
		fs->WR_threshold = fs->MGR[CE32_FILE_BUFFERID_MISC].MGR[0]->dataSize*0.8;

		//fs->WR_threshold = fs->MGR[CE32_FILE_BUFFERID_MISC].MGR[0]->dataSize*fs->sysParam->MISC_ratio-CE32_FILE_WR_THRESHOLD_BYTES*2;
	}
}

void CE32_File_FileStream_TransferCompleteCallback(CE32_FileStream *fs)
{
	fs->data_transfering=0;
	if (!fs->stop_pending) {
			fs->evt_next = evt_transOK;
	}
}

void fs_state_action(CE32_FileStream *fs,CE32_FS_StateTransform *statTran)
{
 if(NULL == statTran)
 {
  return;
 }
 int prev_state = fs->stateMachine;
 fs->stateMachine = statTran->nextState;
 if(statTran->callback != NULL)
 {
	 char txt[]="SD_Call_Sx-x";
	 txt[sizeof(txt)-4] = '0' + prev_state;
	 txt[sizeof(txt)-2] = '0' + fs->stateMachine;
	 //PROFILE_LOG_FORCE(txt);
  statTran->callback(fs);
 }
}

void fs_state_event(CE32_FileStream *fs,uint16_t event)
{
	int report =0;
 switch(fs->stateMachine)
 {
  case sta_uninit:
   fs_state_action(fs,&STATETRANS(0)[event]);
   break;
  case sta_pend:
   fs_state_action(fs,&STATETRANS(1)[event]);
	 report=0;
   break;
  case sta_schedule:
   fs_state_action(fs,&STATETRANS(2)[event]); 
	 report=1;
   break;
  case sta_tranfer:
   fs_state_action(fs,&STATETRANS(3)[event]); 
	 report=1;
   break;
	case sta_stopping:
	 fs_state_action(fs,&STATETRANS(4)[event]); 
	 report=1;
	 break;
  case sta_error:
   fs_state_action(fs,&STATETRANS(5)[event]); 
	 report=1;
   break;
  default:
   break;
 }
 if(report==1)
 {
	 char txt[]="SD_Call_SxEx";
	 txt[sizeof(txt)-4] = '0' + fs->stateMachine;
	 txt[sizeof(txt)-2] = '0' + event;
	 //PROFILE_LOG_FORCE(txt);
 }
}

__weak void CE32_File_FileStream_InitAct(void)
{
	__nop();
}
;
__weak void CE32_File_FileStream_PreLoadAct(void)
{
	__nop();
}
;
__weak void CE32_File_FileStream_PostLoadAct(void)
{
	__nop();
}
;
__weak void CE32_File_FileStream_RecInitAct(void)
{
	__nop();
}
;
__weak void CE32_File_FileStream_PreStartAct(void)
{
	__nop();
}
;

__weak void CE32_File_FileStream_StartAct(void)
{
	__nop();
}
;

__weak void CE32_File_FileStream_StopAct(void)
{
	__nop();
}
;


__weak void CE32_File_FileStream_ErrorAct(uint16_t error_ID)
{
	__nop();
}
;

__weak void CE32_File_FileStream_Init_PreAct(CE32_FileStream *fs)
{
	__nop();
}
;
