#ifndef XE_NP_IMU_GRID_BATCH_H
#define XE_NP_IMU_GRID_BATCH_H
#include <stddef.h>
#include <stdint.h>
#include "xe_np_imu_grid_queue.h"
#include "np_imu_grid_wire.h" /* shared WILDX codec, supplied by the integrator */

/* Foreground-only SPSC consumer; no device/carrier activation. Reset only
 * while producer and consumer are stopped. Output belongs to the caller.
 * Gaps within a frame clear observed bits; gaps between frames are expressed
 * by their first_slot values. A caller must retain q->dropped and the final
 * scheduler ordinal to report a lost tail for which no later slot exists. */
typedef struct {
    NpImuGridHeader header;
    int32_t rows[NP_IMU_GRID_MAX_SLOTS][9];
    XE_NP_ImuGridSlot pending;
    uint64_t last_ordinal;
    uint32_t generation,dropped; /* last observed saturated queue drop count */
    uint8_t rows_count,active,has_pending,has_last,fault;
} XE_NP_ImuGridBatch;

void XE_NP_ImuGridBatch_Reset(XE_NP_ImuGridBatch *batch,uint32_t generation);
/* At most 13 queue pops; cap must be >=480 before any pop. Returns 1 for a
 * complete caller-owned NSG1 frame, 0 for none, -1 for invalid state/input.
 * flush closes a partial batch without inventing any trailing observations.
 * Call again with an available output buffer after 1. No I/O or waiting. */
int XE_NP_ImuGridBatch_Next(XE_NP_ImuGridBatch *batch,XE_NP_ImuGridQueue *queue,
                            uint8_t *out,size_t capacity,size_t *bytes,int flush);
#endif
