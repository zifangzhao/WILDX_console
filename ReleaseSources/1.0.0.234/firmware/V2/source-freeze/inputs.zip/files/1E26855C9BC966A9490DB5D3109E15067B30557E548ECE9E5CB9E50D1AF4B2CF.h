#ifndef XE_NP_IMU_GRID_DIAG_H
#define XE_NP_IMU_GRID_DIAG_H
#include <stdint.h>

/* Lab-only, one capture owner. Reset/read only when timer IRQ is quiescent.
 * Foreground is the sole Mark writer; queue-full IRQ is the sole Full writer.
 * Caller supplies coherent snapshots. Ticks/counters are raw and do not prove
 * phase or resolve wrap; valid==0 means stage was not recorded. */
#ifndef XE_NP_GRID_STARTUP_DIAG
#define XE_NP_GRID_STARTUP_DIAG 0U
#endif
enum {
    XE_NP_GRID_DIAG_TIMER_START, XE_NP_GRID_DIAG_PROOF_ATTACH,
    XE_NP_GRID_DIAG_PHASE_SCHEDULED, XE_NP_GRID_DIAG_PHASE_COMPLETED,
    XE_NP_GRID_DIAG_ROW_SCHEDULED, XE_NP_GRID_DIAG_ROW_COMPLETED,
    XE_NP_GRID_DIAG_OPPORTUNITY_DEFERRED,
    XE_NP_GRID_DIAG_EMPTY_TAKE_AFTER_ATTACH, XE_NP_GRID_DIAG_NP_CAPTURE_FAULT,
    XE_NP_GRID_DIAG_EP82_BUSY_WITH_QUEUED, XE_NP_GRID_DIAG_FIRSTSYNC_BLOCKED_WITH_QUEUED,
    XE_NP_GRID_DIAG_PROVIDER_POLLED, XE_NP_GRID_DIAG_PRIME_BEGIN,
    XE_NP_GRID_DIAG_PRIME_END, XE_NP_GRID_DIAG_STAGE_COUNT
};
enum {
    XE_NP_GRID_DIAG_INDEX_WRAP_AMBIGUOUS=1U, XE_NP_GRID_DIAG_DROP_SATURATED=2U,
    XE_NP_GRID_DIAG_ORDINAL_UNKNOWN=4U, XE_NP_GRID_DIAG_COUNTER_UNKNOWN=8U
};
#if XE_NP_GRID_STARTUP_DIAG
typedef struct { uint32_t valid,tick_ms,head,tail,dropped,flags; } XE_NP_GridDiagEvent;
typedef struct { uint32_t valid,head,tail,dropped,flags;uint64_t ordinal,counter; } XE_NP_GridDiagFull;
typedef struct { uint32_t valid,tick_ms,error,filled,submitted,completed,partial,tx_active,tx_started_ms; } XE_NP_GridDiagNpFault;
typedef struct {
    uint32_t valid,code,state,borrowed,source_bytes_per_tick,published_offset,consumer_offset,max_backlog;
    uint32_t snapshot_valid,snapshot_ms,snapshot_offset,snapshot_events,snapshot_fault,snapshot_active;
    uint64_t produced,consumed,held_source_end;
    uint32_t held_ticks,held_bytes;
} XE_NP_GridDiagProducerFault;
typedef struct { XE_NP_GridDiagEvent stage[XE_NP_GRID_DIAG_STAGE_COUNT];XE_NP_GridDiagFull full;XE_NP_GridDiagNpFault np_fault;XE_NP_GridDiagProducerFault producer_fault; } XE_NP_GridStartupDiag;
extern XE_NP_GridStartupDiag xe_np_grid_startup_diag;
/* Foreground only; captures a single coherent queue snapshot. */
void XE_NP_Np2FirstSyncRuntime_GridDiagMark(uint32_t stage);
void XE_NP_GridDiag_Reset(XE_NP_GridStartupDiag *d);
void XE_NP_GridDiag_Mark(XE_NP_GridStartupDiag *d,uint32_t stage,uint32_t tick_ms,
                         uint32_t head,uint32_t tail,uint32_t dropped);
void XE_NP_GridDiag_NpFault(XE_NP_GridStartupDiag *d,uint32_t tick,uint32_t error,
                             uint32_t filled,uint32_t submitted,uint32_t completed,
                             uint32_t partial,uint32_t active,uint32_t tx_started_ms);
void XE_NP_GridDiag_QueueFull(XE_NP_GridStartupDiag *d,uint64_t ordinal,uint64_t counter,
                              uint32_t head,uint32_t tail,uint32_t dropped);
#else
/* No argument evaluation, storage or function calls in production builds. */
typedef struct { uint8_t unused; } XE_NP_GridStartupDiag;
#define XE_NP_GridDiag_Reset(...) ((void)0)
#define XE_NP_GridDiag_Mark(...) ((void)0)
#define XE_NP_GridDiag_QueueFull(...) ((void)0)
#define XE_NP_GridDiag_NpFault(...) ((void)0)
#endif
#endif
