#include "xe_np_usb_fault.h"

#include <string.h>

/* The device headers expose mask names but some U5 variants omit the raw
 * DIEPINT AHBERR alias.  The bit is architecturally paired with AHBERRM. */
#define XE_NP_USB_FAULT_EP1_BIT       (1UL << 1U)
#define XE_NP_USB_FAULT_ERROR_BITS \
    (XE_NP_USB_FAULT_CAUSE_EPDISD | XE_NP_USB_FAULT_CAUSE_AHBERR | \
     XE_NP_USB_FAULT_CAUSE_TOC)
#define XE_NP_USB_FAULT_BUS_TEARDOWN_BITS \
    (USB_OTG_GINTSTS_USBRST | USB_OTG_GINTSTS_USBSUSP | USB_OTG_GINTSTS_DISCINT)

static volatile XE_NP_UsbFaultSnapshot xe_np_usb_fault_snapshot =
{
    .magic = XE_NP_USB_FAULT_MAGIC,
    .version = XE_NP_USB_FAULT_VERSION
};
static volatile uint32_t xe_np_usb_fault_ep1_active;

void XE_NP_UsbFault_SetEp1Active(uint32_t active)
{
    xe_np_usb_fault_ep1_active = (active != 0U) ? 1U : 0U;
    __DMB();
}

void XE_NP_UsbFault_Clear(void)
{
    memset((void *)&xe_np_usb_fault_snapshot, 0, sizeof(xe_np_usb_fault_snapshot));
    xe_np_usb_fault_snapshot.magic = XE_NP_USB_FAULT_MAGIC;
    xe_np_usb_fault_snapshot.version = XE_NP_USB_FAULT_VERSION;
    xe_np_usb_fault_ep1_active = 0U;
    __DMB();
}

const volatile XE_NP_UsbFaultSnapshot *XE_NP_UsbFault_GetSnapshot(void)
{
    return &xe_np_usb_fault_snapshot;
}

void XE_NP_UsbFault_BeforeIrq(PCD_HandleTypeDef *hpcd)
{
#if defined(USB_OTG_FS) || defined(USB_OTG_HS)
    USB_OTG_DeviceTypeDef *device;
    USB_OTG_INEndpointTypeDef *ep1;
    uint32_t gintsts;
    uint32_t daint;
    uint32_t daintmsk;
    uint32_t diepmsk;
    uint32_t diepint1;
    uint32_t cause;

    if((hpcd == NULL) || (hpcd->Instance == NULL) ||
       (xe_np_usb_fault_ep1_active == 0U))
    {
        return;
    }

    /* Take every raw value before HAL_PCD_IRQHandler acknowledges it. */
    device = (USB_OTG_DeviceTypeDef *)(void *)
        ((uintptr_t)hpcd->Instance + USB_OTG_DEVICE_BASE);
    ep1 = (USB_OTG_INEndpointTypeDef *)(void *)
        ((uintptr_t)hpcd->Instance + USB_OTG_IN_ENDPOINT_BASE + USB_OTG_EP_REG_SIZE);
    gintsts = hpcd->Instance->GINTSTS;
    daint = device->DAINT;
    daintmsk = device->DAINTMSK;
    diepmsk = device->DIEPMSK;
    diepint1 = ep1->DIEPINT;

    /* A set raw status alone is not evidence: it must have been routed to
     * the IRQ through global, EP1, and DIEP masks.  This observer does not
     * unmask TOC/AHBERR, so an absent bit remains an observed absence. */
    if(((gintsts & USB_OTG_GINTSTS_IEPINT) == 0U) ||
       ((daint & daintmsk & XE_NP_USB_FAULT_EP1_BIT) == 0U))
    {
        return;
    }
    cause = diepint1 & diepmsk & XE_NP_USB_FAULT_ERROR_BITS;
    /* Reset, suspend, and disconnect can legitimately disable an otherwise
     * active endpoint before foreground state has observed the teardown.  Do
     * not call that EPDISD an ownership failure; retain a simultaneous TOC or
     * AHBERR because it is independently diagnostic. */
    if((gintsts & XE_NP_USB_FAULT_BUS_TEARDOWN_BITS) != 0U)
    {
        cause &= ~XE_NP_USB_FAULT_CAUSE_EPDISD;
    }
    if(cause == 0U)
    {
        return;
    }

    /* Preserve the first qualifying event.  A later event cannot overwrite
     * the register state that identifies the original USB failure. */
    if(xe_np_usb_fault_snapshot.fault_count != 0U)
    {
        return;
    }
    xe_np_usb_fault_snapshot.cause = cause;
    xe_np_usb_fault_snapshot.tick_ms = HAL_GetTick();
    xe_np_usb_fault_snapshot.gintsts = gintsts;
    xe_np_usb_fault_snapshot.daint = daint;
    xe_np_usb_fault_snapshot.diepint1 = diepint1;
    xe_np_usb_fault_snapshot.diepctl1 = ep1->DIEPCTL;
    xe_np_usb_fault_snapshot.dieptsiz1 = ep1->DIEPTSIZ;
    xe_np_usb_fault_snapshot.dtxfsts1 = ep1->DTXFSTS;
    xe_np_usb_fault_snapshot.gahbcfg = hpcd->Instance->GAHBCFG;
    xe_np_usb_fault_snapshot.diepmsk = diepmsk;
    xe_np_usb_fault_snapshot.daintmsk = daintmsk;
    xe_np_usb_fault_snapshot.ep1_active = 1U;
    __DMB();
    xe_np_usb_fault_snapshot.fault_count = 1U;
#else
    (void)hpcd;
#endif
}
