#include "xe_np_board.h"
#include "xe_np_np2_sd_ble.h"
#include "xe_np_np2_preparation.h"
#include "xe_np_nric.h"
#include "xe_np_hal.h"
#include "xe_np_usb_aux.h"
#if (XE_NP_NP2_SD_SINGLE20_CORE64_TEST || XE_NP_NP2_SD_MULTI20_CORE64_TEST) && \
    (XE_NP_NP2_SD_SINGLE20_CORE64_TEST>1U || XE_NP_NP2_SD_MULTI20_CORE64_TEST>1U || \
     (XE_NP_NP2_SD_SINGLE20_CORE64_TEST && XE_NP_NP2_SD_MULTI20_CORE64_TEST) || \
     !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
     !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_PSRAM_OVERFLOW_PLL1Q128)
#error "Select one20k core-power trial only in the runtime-profile PLL1Q SD APP"
#endif
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
#include "xe_np_sensors_port.h"
#endif

#define XE_NP_BOARD_MCO_APPLY_STATUS_OK 0U
#define XE_NP_BOARD_MCO_APPLY_STATUS_DISABLED 1U
#define XE_NP_BOARD_MCO_APPLY_STATUS_DIVIDER_INVALID 2U
#define XE_NP_BOARD_MCO_APPLY_STATUS_HAL_FAIL 3U
#define XE_NP_BOARD_MCO_APPLY_STATUS_RATE_LOCKED 4U

static uint32_t xe_np_runtime_mco_divider = XE_NP_BOARD_EFFECTIVE_MCO_DIVIDER;
/* TRIPLE7500_CORE64_SOURCE_BEGIN */
#if XE_NP_NP2_SD_TRIPLE7500_CORE64_TEST
/* This closed trial has exactly one HSE-source profile; retain no new state. */
#define xe_np_runtime_mco_source (xe_np_runtime_mco_source_hz==HSE_VALUE?RCC_MCO1SOURCE_HSE:RCC_MCO1SOURCE_PLL1CLK)
#else
static uint32_t xe_np_runtime_mco_source = RCC_MCO1SOURCE_PLL1CLK;
#endif
/* TRIPLE7500_CORE64_SOURCE_END */
static uint32_t xe_np_runtime_mco_source_hz =
    XE_NP_BOARD_EFFECTIVE_EXPECTED_MCO_HZ * XE_NP_BOARD_EFFECTIVE_MCO_DIVIDER;
#if XE_NP_BOARD_DEFER_PROBE_MCO_START
static uint8_t xe_np_np2_mco_enabled;
static uint32_t xe_np_runtime_expected_mco_hz;
static uint32_t xe_np_runtime_expected_psb_clk_hz;
static uint32_t xe_np_runtime_expected_psb_clk_half_hz;
#else
static uint32_t xe_np_runtime_expected_mco_hz = XE_NP_BOARD_EFFECTIVE_EXPECTED_MCO_HZ;
static uint32_t xe_np_runtime_expected_psb_clk_hz = XE_NP_BOARD_EFFECTIVE_EXPECTED_PSB_CLK_FULL_HZ;
static uint32_t xe_np_runtime_expected_psb_clk_half_hz = XE_NP_BOARD_EFFECTIVE_EXPECTED_PSB_CLK_HALF_HZ;
#endif
static uint32_t xe_np_runtime_mco_apply_count;
static uint32_t xe_np_runtime_mco_last_apply_status;
static uint32_t xe_np_np2_sample_rate_hz = XE_NP_NEUROPIXELS_SAMPLE_RATE_HZ;
static uint32_t xe_np_runtime_core_clock_hz = XE_NP_BOARD_SYSCLK_HZ;
static XE_NP_NeuropixelsClockPlan xe_np_clock_plan = {
#if XE_NP_BOARD_DEFER_PROBE_MCO_START
    0U, 0U,
#else
    XE_NP_BOARD_EFFECTIVE_EXPECTED_MCO_HZ,
    XE_NP_BOARD_EFFECTIVE_EXPECTED_PSB_CLK_FULL_HZ,
#endif
    XE_NP_NEUROPIXELS_SAMPLE_RATE_HZ,
    XE_NP_NEUROPIXELS_PSB_DATA_LINES
};

static const XE_NP_PinMapEntry xe_np_pin_map[] = {
    {"SDIO_CKIN", "PB8"},
    {"SDIO_CMD", "PD2"},
    {"SDIO_D0", "PC8"},
    {"SDIO_D1", "PC9"},
    {"SDIO_D2", "PC10"},
    {"SDIO_D3", "PC11"},
    {"SDIO_CLK", "PC12"},
    {"SD_VSEL", "PG0"},
    {"HJ_UART_RX_EN", "PA9"},
    {"HJ_UART_PATH_SEL", "PE3"},
    {"HJ_SLV_CONN_STATE", "PF3"},
    {"HJ_DATARDY", "PG9"},
    {"BLE_UART_TX", "PD5"},
    {"BLE_UART_RX", "PA15"},
    {"IMU_SDA", "PD0"},
    {"IMU_SCL", "PD1"},
    {"TEMP_SDA", "PF0"},
    {"TEMP_SCL", "PF1"},
    {"NP_VEE_EN", "PF2"},
    {"NP_VCC_EN", "PD10"},
    {"NP_NRST", "PE13"},
    {"NP_PSB_CLK_CONNECTOR", "PA5"},
#if (XE_NP_BOARD_NP1_PSSI_PDCK_USE_PA6 != 0U)
    {"NP1_PSSI_PDCK", "PA6"},
#else
    {"NP1_PSSI_PDCK", "PD9"},
#endif
    {"NP_MCLK_MCO", "PA8"},
#if XE_NP_BOARD_V2_PSSI_NP1_ENABLE
    {"PSRAM_SIO0", "PC1"},
    {"PSRAM_SIO1", "PC2"},
    {"PSRAM_SIO2", "PD6"},
    {"PSRAM_SIO3", "PC4"},
#endif
    {"NP1_PSSI_D0", "PC6"},
    {"NP1_PSSI_D1", "PA10"},
    {"NP1_PSSI_D2", "PE0"},
    {"NP1_PSSI_D3", "PE1"},
    {"NP1_PSSI_D4", "PE4"},
    {"NP1_PSSI_D5", "PB6"},
    {"NP1_PSSI_D6", "PE5"},
    {"NP1_PSSI_D7_SYNC", "PB9"},
    {"NP1_I2C_SCL", "PD12"},
    {"NP1_I2C_SDA", "PD13"},
    {"NP2_I2C_SCL", "PB10"},
    {"NP2_I2C_SDA", "PB14"},
    {"NP3_I2C_SCL", "PC0"},
    {"NP3_I2C_SDA", "PB4"},
    {"NP_CAL_DAC", "PA4"},
#if !XE_NP_BOARD_V2_PSSI_NP1_ENABLE
    {"ADC1_IN3", "PC2"},
#endif
    {"ADC_BATT", "PB2"},
    {"LED", "PC14"},
    {"USB_MODE", "PC15"}
};

static uint32_t XE_NP_Board_BaseMcoSourceHz(void)
{
    if((xe_np_runtime_mco_source_hz == 0U) ||
       (xe_np_runtime_mco_divider == 0U))
    {
        return 0U;
    }

    return xe_np_runtime_mco_source_hz;
}

static void XE_NP_Board_RefreshRuntimeClockPlan(void)
{
    uint32_t base_hz = XE_NP_Board_BaseMcoSourceHz();

    if((base_hz == 0U) || (xe_np_runtime_mco_divider == 0U)
#if XE_NP_BOARD_DEFER_PROBE_MCO_START
       || !xe_np_np2_mco_enabled
#endif
       )
    {
        xe_np_runtime_expected_mco_hz = 0U;
        xe_np_runtime_expected_psb_clk_hz = 0U;
        xe_np_runtime_expected_psb_clk_half_hz = 0U;
    }
    else
    {
        xe_np_runtime_expected_mco_hz = base_hz / xe_np_runtime_mco_divider;
#if XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE
        xe_np_runtime_expected_psb_clk_hz = xe_np_runtime_expected_mco_hz;
        xe_np_runtime_expected_psb_clk_half_hz = 0U;
#else
        xe_np_runtime_expected_psb_clk_hz = xe_np_runtime_expected_mco_hz / 4U;
        xe_np_runtime_expected_psb_clk_half_hz = xe_np_runtime_expected_psb_clk_hz / 2U;
#endif
    }

    xe_np_clock_plan.mclk_hz = xe_np_runtime_expected_mco_hz;
    xe_np_clock_plan.psb_clk_hz = xe_np_runtime_expected_psb_clk_hz;
    xe_np_clock_plan.sample_rate_hz = xe_np_np2_sample_rate_hz;
}

static int XE_NP_Board_McoDividerToHal(uint32_t divider, uint32_t *hal_divider)
{
    if(hal_divider == NULL)
    {
        return -1;
    }

    switch(divider)
    {
        case 1U:
            *hal_divider = RCC_MCODIV_1;
            return 0;
        case 2U:
            *hal_divider = RCC_MCODIV_2;
            return 0;
        case 4U:
            *hal_divider = RCC_MCODIV_4;
            return 0;
        case 8U:
            *hal_divider = RCC_MCODIV_8;
            return 0;
        case 16U:
            *hal_divider = RCC_MCODIV_16;
            return 0;
        default:
            *hal_divider = RCC_MCODIV_1;
            return -1;
    }
}

const XE_NP_NeuropixelsClockPlan *XE_NP_GetNeuropixelsClockPlan(void)
{
    return &xe_np_clock_plan;
}

const XE_NP_PinMapEntry *XE_NP_GetPinMap(size_t *count)
{
    if(count != NULL)
    {
        *count = sizeof(xe_np_pin_map) / sizeof(xe_np_pin_map[0]);
    }

    return xe_np_pin_map;
}

uint32_t XE_NP_Board_GetRuntimeMcoDivider(void)
{
    return xe_np_runtime_mco_divider;
}

uint32_t XE_NP_Board_GetRuntimeExpectedMcoHz(void)
{
    return xe_np_runtime_expected_mco_hz;
}

uint32_t XE_NP_Board_GetRuntimeExpectedPsbClkHz(void)
{
    return xe_np_runtime_expected_psb_clk_hz;
}

uint32_t XE_NP_Board_GetRuntimeExpectedPsbClkHalfHz(void)
{
    return xe_np_runtime_expected_psb_clk_half_hz;
}

uint32_t XE_NP_Board_GetRuntimeMcoApplyCount(void)
{
    return xe_np_runtime_mco_apply_count;
}

uint32_t XE_NP_Board_GetRuntimeMcoLastApplyStatus(void)
{
    return xe_np_runtime_mco_last_apply_status;
}

int XE_NP_Board_SetRuntimeMcoDivider(uint32_t divider)
{
#if XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE
    /* Existing USB/NRIC commands must not bypass NP2 startup sequencing. */
    (void)divider;
    xe_np_runtime_mco_apply_count++;
    xe_np_runtime_mco_last_apply_status = XE_NP_BOARD_MCO_APPLY_STATUS_RATE_LOCKED;
    return -1;
#else
    uint32_t hal_divider;
    uint32_t base_hz = XE_NP_Board_BaseMcoSourceHz();

    xe_np_runtime_mco_apply_count++;

    if(base_hz == 0U)
    {
        xe_np_runtime_mco_last_apply_status = XE_NP_BOARD_MCO_APPLY_STATUS_DISABLED;
        return -1;
    }

    if(XE_NP_Board_McoDividerToHal(divider, &hal_divider) != 0)
    {
        xe_np_runtime_mco_last_apply_status = XE_NP_BOARD_MCO_APPLY_STATUS_DIVIDER_INVALID;
        return -1;
    }

#if XE_NP_BOARD_NP1_30KSPS_CLOCK_LOCK
    /* Never let a USB control request turn a 30 kS/s image into a reduced-rate
     * capture. The probe derives the returned 23.4 MHz PSB clock from MCO. */
    if(((base_hz % divider) != 0U) ||
       ((base_hz / divider) != XE_NP_NEUROPIXELS_MCLK_HZ))
    {
        xe_np_runtime_mco_last_apply_status = XE_NP_BOARD_MCO_APPLY_STATUS_RATE_LOCKED;
        return -1;
    }
#endif

    __HAL_RCC_PLLCLKOUT_ENABLE(RCC_PLL1_DIVR);
    HAL_RCC_MCOConfig(RCC_MCO1, RCC_MCO1SOURCE_PLL1CLK, hal_divider);
    if((RCC->CFGR1 & (RCC_CFGR1_MCOSEL | RCC_CFGR1_MCOPRE)) !=
       (RCC_MCO1SOURCE_PLL1CLK | hal_divider))
    {
        xe_np_runtime_mco_last_apply_status = XE_NP_BOARD_MCO_APPLY_STATUS_HAL_FAIL;
        return -1;
    }

    xe_np_runtime_mco_divider = divider;
    XE_NP_Board_RefreshRuntimeClockPlan();
    xe_np_runtime_mco_last_apply_status = XE_NP_BOARD_MCO_APPLY_STATUS_OK;
    return 0;
#endif
}

uint32_t XE_NP_Board_GetRuntimeMcoRegisterBits(void)
{
    uint32_t hal_divider;
    if(XE_NP_Board_McoDividerToHal(xe_np_runtime_mco_divider,&hal_divider)!=0)
        return RCC_MCO1SOURCE_NOCLOCK|RCC_MCODIV_1;
    return xe_np_runtime_mco_source|hal_divider;
}

uint32_t XE_NP_Board_GetNp2SampleRateHz(void)
{
    return xe_np_np2_sample_rate_hz;
}

uint32_t XE_NP_Board_GetRuntimeCoreClockHz(void)
{
    return xe_np_runtime_core_clock_hz;
}

#if XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE
#if XE_NP_PSRAM_OVERFLOW_PLL2Q108
int XE_NP_Board_Np2Pll2Q108Ready(void)
{
    /* SD owns PLL2. Validate its existing output; never repair or retune it. */
    const uint32_t ready=RCC_CR_HSEON|RCC_CR_HSERDY|RCC_CR_PLL2ON|RCC_CR_PLL2RDY;
    const uint32_t cfgr_mask=RCC_PLL2CFGR_PLL2SRC|RCC_PLL2CFGR_PLL2M|
        RCC_PLL2CFGR_PLL2RGE|RCC_PLL2CFGR_PLL2QEN;
    const uint32_t divr_mask=RCC_PLL2DIVR_PLL2N|RCC_PLL2DIVR_PLL2P|
        RCC_PLL2DIVR_PLL2Q|RCC_PLL2DIVR_PLL2R;
    return HSE_VALUE==24000000UL && (RCC->CR&ready)==ready &&
        (RCC->PLL2CFGR&cfgr_mask)==(RCC_PLLSOURCE_HSE|
            (5U<<RCC_PLL2CFGR_PLL2M_Pos)|RCC_PLL2CFGR_PLL2QEN|RCC_PLLVCIRANGE_0) &&
        (RCC->PLL2DIVR&divr_mask)==(53U|(1U<<RCC_PLL2DIVR_PLL2P_Pos)|
            (1U<<RCC_PLL2DIVR_PLL2Q_Pos)|(1U<<RCC_PLL2DIVR_PLL2R_Pos)) &&
        !(RCC->PLL2FRACR&RCC_PLL2FRACR_PLL2FRACN);
}
#endif
#if XE_NP_PSRAM_OVERFLOW_PLL1Q128
static int XE_NP_Board_Np2Pll1Q128Ready(uint32_t pll_n,uint32_t pll_q,uint32_t pll_r)
{
    const uint32_t ready=RCC_CR_HSEON|RCC_CR_HSERDY|RCC_CR_PLL1ON|RCC_CR_PLL1RDY;
    const uint32_t cfgr_mask=RCC_PLL1CFGR_PLL1SRC|RCC_PLL1CFGR_PLL1M|RCC_PLL1CFGR_PLL1RGE|
        RCC_PLL1CFGR_PLL1QEN|RCC_PLL1CFGR_PLL1REN;
    const uint32_t divr_mask=RCC_PLL1DIVR_PLL1N|RCC_PLL1DIVR_PLL1P|
        RCC_PLL1DIVR_PLL1Q|RCC_PLL1DIVR_PLL1R;
    return HSE_VALUE==24000000UL && __HAL_RCC_GET_SYSCLK_SOURCE()==RCC_SYSCLKSOURCE_STATUS_PLLCLK &&
        (RCC->CR&ready)==ready &&
        (RCC->PLL1CFGR&cfgr_mask)==(RCC_PLLSOURCE_HSE|(5U<<RCC_PLL1CFGR_PLL1M_Pos)|
            RCC_PLL1CFGR_PLL1QEN|RCC_PLL1CFGR_PLL1REN|RCC_PLLVCIRANGE_0) &&
        (RCC->PLL1DIVR&divr_mask)==((pll_n-1U)|(3U<<RCC_PLL1DIVR_PLL1P_Pos)|
            ((pll_q-1U)<<RCC_PLL1DIVR_PLL1Q_Pos)|((pll_r-1U)<<RCC_PLL1DIVR_PLL1R_Pos)) &&
        !(RCC->PLL1FRACR&RCC_PLL1FRACR_PLL1FRACN);
}
#endif

static int XE_NP_Board_SetNp2CoreClock(uint32_t target_hz,uint32_t pll_n,uint32_t apb_divider,
                                     uint32_t psram_q_override)
{
    RCC_ClkInitTypeDef clocks={0};
    RCC_OscInitTypeDef oscillator={0};
    /* Extra wait states do NOT qualify an out-of-spec CPU/AHB frequency.
     * HAL raises latency before increasing SYSCLK, lowers it after HSE on
     * the return transition; all ordinary profiles retain exactly5WS. */
#if XE_NP_NP2_SD_RAW20_CORE256_TEST
    const uint32_t flash_latency=target_hz==256000000U?FLASH_LATENCY_8:FLASH_LATENCY_5;
    if(target_hz==256000000U && (pll_n!=128U || apb_divider!=RCC_HCLK_DIV4 ||
       psram_q_override))return -1;
#else
    const uint32_t flash_latency=FLASH_LATENCY_5;
#endif
#if XE_NP_NP2_SD_SINGLE20_CORE64_TEST || XE_NP_NP2_SD_MULTI20_CORE64_TEST
    /* Raw20 VCO256/N64 owns PCLK64; packed15 VCO384/N96 needs PCLK32. */
    if(target_hz==64000000U && pll_n==64U)apb_divider=RCC_HCLK_DIV1;
#endif
#if XE_NP_NP2_SD_RAW15_CORE48_TEST
    if(target_hz==48000000U && pll_n==48U)apb_divider=RCC_HCLK_DIV1;
#endif
    uint32_t pclk_hz=target_hz/(apb_divider==RCC_HCLK_DIV1?1U:
        (apb_divider==RCC_HCLK_DIV4?4U:2U));
#if XE_NP_NP2_SD_SINGLE30_APB24_TEST
    if(apb_divider==RCC_HCLK_DIV8)pclk_hz=target_hz/8U;
#endif
#if XE_NP_PSRAM_OVERFLOW_PLL1Q128
    uint32_t pll_q=(target_hz==128000000U || target_hz==64000000U)?2U:
        (target_hz==192000000U?XE_NP_PSRAM_OVERFLOW_PLL1Q_30KHZ_DIV:4U);
#if XE_NP_NP2_SD_DUAL30_PSRAM_Q128_TEST
    /* Stopped profile preparation only; no CPU/P/R/MCO/SPI change. */
    if(psram_q_override){
        if(psram_q_override!=3U || target_hz!=192000000U || pll_n!=96U ||
           apb_divider!=RCC_HCLK_DIV2)return -1;
        pll_q=psram_q_override;
    }
#elif !XE_NP_NP2_SD_SINGLE7500_SQR_LINEAR_TEST
    (void)psram_q_override;
#endif
#if XE_NP_NP2_SD_SINGLE7500_SQR_LINEAR_TEST
    if(psram_q_override){
        if(psram_q_override!=5U || target_hz!=48000000U || pll_n!=96U ||
           apb_divider!=RCC_HCLK_DIV2)return -1;
        pll_q=psram_q_override;
    }
#endif
    uint32_t pll_r=target_hz==48000000U?8U:
        ((target_hz==96000000U || target_hz==64000000U)?4U:2U);
#if XE_NP_NP2_SD_SINGLE7500_CORE32_TEST
    if(target_hz==32000000U){
        if(pll_n!=96U || apb_divider!=RCC_HCLK_DIV2)return -1;
        pll_q=4U;pll_r=12U;
    }
#endif
/* SINGLE15_CORE64_PLL_BEGIN */
#if XE_NP_NP2_SD_SINGLE15_CORE64_TEST
    if(target_hz==64000000U && pll_n==96U){pll_q=4U;pll_r=6U;}
#endif
/* SINGLE15_CORE64_PLL_END */
/* TRIPLE7500_CORE64_PLL_BEGIN */
#if XE_NP_NP2_SD_TRIPLE7500_CORE64_TEST
    if(target_hz==64000000U && pll_n==96U){
        if(apb_divider!=RCC_HCLK_DIV2)return -1;
        pll_q=4U;pll_r=6U;
    }
#endif
/* TRIPLE7500_CORE64_PLL_END */
#if XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST || XE_NP_NP2_SD_SINGLE7500_CORE40_TEST
#if XE_NP_NP2_SD_PACKED_LOW_VCO384_TEST
    if(target_hz==38400000U || (target_hz==64000000U && pll_n!=64U)){
        if(pll_n!=96U || apb_divider!=RCC_HCLK_DIV2)return -1;
        pll_q=4U;pll_r=target_hz==38400000U?10U:6U;
    }
#else
    if(target_hz==40000000U || target_hz==80000000U){
        /* HSE24/M6/N120 gives VCO480; Q5 preserves PSRAM96. */
        if(pll_n!=120U || apb_divider!=RCC_HCLK_DIV2)return -1;
        pll_q=5U;pll_r=target_hz==40000000U?12U:6U;
    }
#endif
#endif
#if XE_NP_NP2_SD_RAW15_CORE48_TEST
    /* VCO192/Q2 keeps the checked PSRAM96 feed; R4 yields CPU48.
     * Legacy7.5k also uses CPU48, but VCO384/Q4/R8 must remain distinct. */
    if(target_hz==48000000U && pll_n==48U){pll_q=2U;pll_r=4U;}
#endif
#if XE_NP_NP2_SD_SINGLE7500_VCO192_TEST
    if(target_hz==48000000U && pll_n==48U){
        /* Only the explicit 1p7.5k caller selects N48. No unknown PLL1P
         * consumer may be silently slowed; Q/R output clocks stay intact. */
        if(RCC->PLL1CFGR&RCC_PLL1CFGR_PLL1PEN)return -1;
        pll_q=2U;pll_r=4U;
    }
#endif
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
    /* The OSPI mux is shared. Overflow preparation aborts/disables OSPI2
     * first; even the same-rate shortcut requires stopped consumers. */
    if((OCTOSPI1->CR&OCTOSPI_CR_EN) || (OCTOSPI1->SR&OCTOSPI_SR_BUSY) ||
       (OCTOSPI2->CR&OCTOSPI_CR_EN) || (OCTOSPI2->SR&OCTOSPI_SR_BUSY))return -1;
#endif
#if XE_NP_NP2_SD_SINGLE7500_FLASH1_TEST
    /* Restore before any clock increase, including the same-clock shortcut.
     * A failed write must not allow a higher-frequency transition. */
    __HAL_FLASH_SET_LATENCY(FLASH_LATENCY_5);
    if(__HAL_FLASH_GET_LATENCY()!=FLASH_LATENCY_5)return -1;
#endif
    if(HAL_RCC_GetSysClockFreq()==target_hz && HAL_RCC_GetHCLKFreq()==target_hz &&
       HAL_RCC_GetPCLK1Freq()==pclk_hz && HAL_RCC_GetPCLK2Freq()==pclk_hz &&
       HAL_RCC_GetPCLK3Freq()==pclk_hz
#if XE_NP_NP2_SD_RAW20_CORE256_TEST
       && __HAL_FLASH_GET_LATENCY()==flash_latency
#endif
#if XE_NP_PSRAM_OVERFLOW_PLL1Q128
       && XE_NP_Board_Np2Pll1Q128Ready(pll_n,pll_q,pll_r)
#endif
      ) {
        xe_np_runtime_core_clock_hz=target_hz;
        return 0;
    }
    /* USBPHYC is sourced directly from HSE on V2. With bulk traffic stopped,
     * temporarily move the core/AHB directly to HSE, rebuild PLL1, then return
     * to PLL1R. Thus even the rate-change transition remains HSE-derived. APB
     * preserves the requested SPI/UART kernel rate. FLASH latency 5 is conservative at 128 MHz
     * and is required by the reviewed 192 MHz experiment. */
    clocks.ClockType=RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK|
        RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2|RCC_CLOCKTYPE_PCLK3;
    clocks.SYSCLKSource=RCC_SYSCLKSOURCE_HSE;
    clocks.AHBCLKDivider=RCC_SYSCLK_DIV1;
    clocks.APB1CLKDivider=apb_divider;
    clocks.APB2CLKDivider=apb_divider;
    clocks.APB3CLKDivider=apb_divider;
    if(HAL_RCC_ClockConfig(&clocks,flash_latency)!=HAL_OK)return -1;
    oscillator.OscillatorType=RCC_OSCILLATORTYPE_NONE;
    oscillator.PLL.PLLState=RCC_PLL_ON;
    oscillator.PLL.PLLSource=RCC_PLLSOURCE_HSE;
    oscillator.PLL.PLLMBOOST=RCC_PLLMBOOST_DIV2;
    oscillator.PLL.PLLM=6U;
    oscillator.PLL.PLLN=pll_n;
    oscillator.PLL.PLLP=4U;
#if XE_NP_PSRAM_OVERFLOW_PLL1Q128
    oscillator.PLL.PLLQ=pll_q;
#else
    oscillator.PLL.PLLQ=4U;
#endif
#if XE_NP_PSRAM_OVERFLOW_PLL1Q128
    oscillator.PLL.PLLR=pll_r;
#else
    oscillator.PLL.PLLR=2U;
#endif
    oscillator.PLL.PLLRGE=RCC_PLLVCIRANGE_0;
    oscillator.PLL.PLLFRACN=0U;
    if(HAL_RCC_OscConfig(&oscillator)!=HAL_OK)return -1;
    clocks.SYSCLKSource=RCC_SYSCLKSOURCE_PLLCLK;
    if(HAL_RCC_ClockConfig(&clocks,flash_latency)!=HAL_OK)return -1;
    if(HAL_RCC_GetSysClockFreq()!=target_hz || HAL_RCC_GetHCLKFreq()!=target_hz ||
       HAL_RCC_GetPCLK1Freq()!=pclk_hz || HAL_RCC_GetPCLK2Freq()!=pclk_hz ||
       HAL_RCC_GetPCLK3Freq()!=pclk_hz)return -1;
#if XE_NP_PSRAM_OVERFLOW_PLL1Q128
    __HAL_RCC_PLLCLKOUT_ENABLE(RCC_PLL1_DIVQ);
    if(!XE_NP_Board_Np2Pll1Q128Ready(pll_n,pll_q,pll_r))return -1;
#endif
    xe_np_runtime_core_clock_hz=target_hz;
    return 0;
}

#if XE_NP_V2_AUX_ENABLE
int XE_NP_Board_SetAvCoreClock(void)
{
    /* Stopped AV-only role. USB PHY remains on HSE; NP sample-rate metadata
     * is not relabeled to this non-NP clock. No acquisition runs here. */
    if(xe_np_np2_mco_enabled || (PSSI->CR&PSSI_CR_ENABLE) ||
       (TIM8->CR1&TIM_CR1_CEN) || (GPDMA1_Channel15->CCR&DMA_CCR_EN))return -1;
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
    XE_NP_SensorsPort_Pause();
#endif
    int result=XE_NP_Board_SetNp2CoreClock(150000000U,75U,RCC_HCLK_DIV2,0U);
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
    XE_NP_SensorsPort_Resume();
#endif
    XE_NP_Board_RefreshRuntimeClockPlan();
    return result;
}
#endif

#if XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST || XE_NP_NP2_SD_SINGLE7500_CORE40_TEST
static int np2_packed_low_profile(uint32_t sample_hz,uint32_t probe_mask)
{
    return (XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST &&
            (probe_mask==1U || probe_mask==3U) && (sample_hz==7500U || sample_hz==15000U)) ||
           (XE_NP_NP2_SD_SINGLE7500_CORE40_TEST && probe_mask==1U && sample_hz==7500U);
}
#endif
uint32_t XE_NP_Board_Np2ProfileCoreHz(uint32_t sample_hz,uint32_t probe_mask)
{
    if(probe_mask!=0U && probe_mask!=1U && probe_mask!=3U && probe_mask!=7U)return 0U;
#if XE_NP_NP2_SD_SINGLE7500_CORE32_TEST
    if(sample_hz==7500U && probe_mask==1U)return 32000000U;
#endif
#if XE_NP_NP2_SD_SINGLE15_CORE64_TEST
    if(sample_hz==15000U && probe_mask==1U)return 64000000U;
#endif
/* TRIPLE7500_CORE64_CORE_BEGIN */
#if XE_NP_NP2_SD_TRIPLE7500_CORE64_TEST
    if(sample_hz==7500U && probe_mask==7U)return 64000000U;
#endif
/* TRIPLE7500_CORE64_CORE_END */
#if XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST || XE_NP_NP2_SD_SINGLE7500_CORE40_TEST
    if(np2_packed_low_profile(sample_hz,probe_mask)){
#if XE_NP_NP2_SD_PACKED_LOW_VCO384_TEST
        return sample_hz==7500U?38400000U:64000000U;
#else
        return sample_hz==7500U?40000000U:80000000U;
#endif
    }
#endif
#if XE_NP_NP2_DUAL_SD_APP_ENABLE && XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES && XE_NP_PSRAM_OVERFLOW_PLL1Q128
    /* SD-only7.5k: HSE VCO384/R8, MCO/4 and PCLK/2 SPI all yield12MHz.
     * Mask0 remains the stopped legacy SD preparation wrapper. */
    if(sample_hz==7500U){
#if XE_NP_NP2_SD_CLASSIC7500_CORE96_TEST
        if(probe_mask==7U)return 96000000U;
#endif
        return 48000000U;
    }
#endif
    if(sample_hz!=15000U && sample_hz!=20000U && sample_hz!=30000U)return 0U;
#if XE_NP_NP2_DUAL_SD_APP_ENABLE && XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES && XE_NP_PSRAM_OVERFLOW_PLL1Q128 && XE_NP_NP2_SD_CLASSIC15_CORE192_TEST
    if(sample_hz==15000U && (probe_mask==3U || probe_mask==7U))return 192000000U;
#endif
    /* Mask0 never opts into either private20k core-power trial. */
#if XE_NP_NP2_SD_SINGLE20_CORE64_TEST
    if(probe_mask==1U && sample_hz==20000U)return 64000000U;
#endif
#if XE_NP_NP2_SD_MULTI20_CORE64_TEST
#if XE_NP_NP2_SD_RAW20_CORE256_TEST
    if(probe_mask==7U && sample_hz==20000U)return 256000000U;
#endif
    if(probe_mask==7U && sample_hz==20000U)
        return XE_NP_NP2_SD_RAW20_CORE128_TEST?128000000U:64000000U;
#endif
#if XE_NP_NP2_SD_RAW15_CORE48_TEST
    if(probe_mask==7U && sample_hz==15000U)return 48000000U;
#endif
    return sample_hz*6400U;
}

int XE_NP_Board_SetNp2SampleRateProfile(uint32_t sample_hz,uint32_t probe_mask)
{
    /* Rate changes are a profile-selection operation, not a live MCO mux.
     * The source coordinator calls this while power/reset and MCO are off. */
#if XE_NP_NP2_PREPARATION_ENABLE
    /* The preparation's own stopped clock setup is admitted once. A different
     * clock owner retires a held preparation first; IRQ cleanup stays deferred. */
    if(XE_NP_Np2Preparation_Holding() && !XE_NP_Np2Preparation_ClockPending()){
        if(!XE_NP_Board_Np2ProfileCoreHz(sample_hz,probe_mask))return -1;
        XE_NP_Np2Preparation_Invalidate(NP2_PREP_CLOCK);
        if(XE_NP_Np2Preparation_Holding())return -1;
    }
#endif
    if(xe_np_np2_mco_enabled || !XE_NP_Board_Np2ProfileCoreHz(sample_hz,probe_mask))return -1;
#if XE_NP_PSRAM_OVERFLOW_PLL1Q128 || XE_NP_PSRAM_OVERFLOW_PLL2Q108
    if(HSE_VALUE!=24000000UL || (sample_hz!=20000U && sample_hz!=30000U
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES && XE_NP_PSRAM_OVERFLOW_PLL1Q128
       && sample_hz!=15000U
#if XE_NP_NP2_DUAL_SD_APP_ENABLE
       && sample_hz!=7500U
#endif
#endif
       ))return -1;
#endif
    uint32_t core_hz,pll_n;
    switch(sample_hz) {
#if XE_NP_NP2_DUAL_SD_APP_ENABLE && XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES && XE_NP_PSRAM_OVERFLOW_PLL1Q128
    case 7500U:
        core_hz=48000000U;pll_n=96U;
        break;
#endif
    case 15000U:
        /* Keep PSSI MCLK and SPI2-D8 on the same exact 24-MHz edge train.
         * At 96-MHz HCLK, APB1 is 48 MHz and SPI2 /2 is 24 MHz. A 128-MHz
         * direct-HSE MCO profile leaves APB1 at 64 MHz, where SPI2 /2 would
         * be 32 MHz; SPI2 has no integer divider that yields 24 MHz there. */
        if(HSE_VALUE!=24000000UL)return -1;
        core_hz=96000000U;pll_n=48U;
#if XE_NP_PSRAM_OVERFLOW_PLL1Q128
        /* CPU96/MCO24/SPI24 remain exact. PSRAM uses Q4=96MHz: Q3=128MHz
         * corrupted spilled blocks in the three-probe 15k SD workload. */
        pll_n=96U;
#endif
        break;
    case 20000U:
        core_hz=128000000U;pll_n=64U;
        break;
    case 30000U:
        core_hz=192000000U;pll_n=96U;
        break;
    default:
        return -1;
    }
    core_hz=XE_NP_Board_Np2ProfileCoreHz(sample_hz,probe_mask);
#if XE_NP_NP2_SD_RAW20_CORE256_TEST
    if(sample_hz==20000U && probe_mask==7U)pll_n=128U;
#endif
    uint32_t mco_source=RCC_MCO1SOURCE_PLL1CLK,mco_source_hz=core_hz;
#if XE_NP_NP2_SD_SINGLE7500_CORE32_TEST
    if(sample_hz==7500U && probe_mask==1U){
        mco_source=RCC_MCO1SOURCE_HSE;mco_source_hz=HSE_VALUE;
    }
#endif
/* SINGLE15_CORE64_MCO_BEGIN */
#if XE_NP_NP2_SD_SINGLE15_CORE64_TEST
    if(sample_hz==15000U && probe_mask==1U){
        mco_source=RCC_MCO1SOURCE_HSE;mco_source_hz=HSE_VALUE;
    }
#endif
/* SINGLE15_CORE64_MCO_END */
/* TRIPLE7500_CORE64_MCO_BEGIN */
#if XE_NP_NP2_SD_TRIPLE7500_CORE64_TEST
    if(sample_hz==7500U && probe_mask==7U){
        mco_source=RCC_MCO1SOURCE_HSE;mco_source_hz=HSE_VALUE;
    }
#endif
/* TRIPLE7500_CORE64_MCO_END */
#if XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST || XE_NP_NP2_SD_SINGLE7500_CORE40_TEST
    if(np2_packed_low_profile(sample_hz,probe_mask)){
        pll_n=XE_NP_NP2_SD_PACKED_LOW_VCO384_TEST?96U:120U;
        mco_source=RCC_MCO1SOURCE_HSE;mco_source_hz=HSE_VALUE;
    }
#endif
#if XE_NP_NP2_SD_RAW15_CORE48_TEST
    if(sample_hz==15000U && probe_mask==7U)pll_n=48U;
#endif
#if XE_NP_NP2_SD_SINGLE7500_VCO192_TEST
    if(sample_hz==7500U && probe_mask==1U)pll_n=48U;
#endif
#if XE_NP_NP2_SD_BLE_ENABLE
    /* Overflow preparation has already quiesced OSPI. Drain/mask UART before
     * the first RCC write, not after a baud-corrupting HSE/PLL transition. */
    if(XE_NP_Np2SdBle_BeginClockChange()!=0)return -1;
#endif
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
    XE_NP_SensorsPort_Pause();
#endif
    uint32_t apb_divider=RCC_HCLK_DIV2;
#if XE_NP_NP2_SD_RAW20_CORE256_TEST
    /* VCO512/R2 CPU256, Q4 PSRAM128, MCO/8=32; preserve PCLK64/SPI2/2. */
    if(sample_hz==20000U && probe_mask==7U)apb_divider=RCC_HCLK_DIV4;
#endif
#if XE_NP_NP2_SD_SINGLE15_APB24_TEST
    /* No SPI2-D8 consumer for mask1. Retain HCLK96 for packing/PSSI/IDMA. */
    if(sample_hz==15000U && probe_mask==1U)apb_divider=RCC_HCLK_DIV4;
#endif
#if XE_NP_NP2_SD_SINGLE20_APB32_TEST
    /* Mask1 has no SPI2-D8 consumer. Retain HCLK128 and every data clock. */
    if(sample_hz==20000U && probe_mask==1U)apb_divider=RCC_HCLK_DIV4;
#endif
#if XE_NP_NP2_SD_SINGLE30_APB24_TEST
    /* Mask1 has no SPI2-D8 consumer. Do not slow PSSI, IDMA, RAM or MCO. */
    if(sample_hz==30000U && probe_mask==1U)apb_divider=RCC_HCLK_DIV8;
#endif
#if XE_NP_NP2_SD_CLASSIC7500_CORE96_TEST
    /* Same PLL as15k, different PCLK: never shortcut on PLL/core alone. */
    if(sample_hz==7500U && probe_mask==7U)apb_divider=RCC_HCLK_DIV4;
#endif
/* TRIPLE7500_CORE64_APB_BEGIN */
#if XE_NP_NP2_SD_TRIPLE7500_CORE64_TEST
    if(sample_hz==7500U && probe_mask==7U)apb_divider=RCC_HCLK_DIV2;
#endif
/* TRIPLE7500_CORE64_APB_END */
#if XE_NP_NP2_SD_CLASSIC15_CORE192_TEST
    if(sample_hz==15000U && (probe_mask==3U || probe_mask==7U))apb_divider=RCC_HCLK_DIV4;
#endif
    int changed=XE_NP_Board_SetNp2CoreClock(core_hz,pll_n,apb_divider,
#if XE_NP_NP2_SD_SINGLE7500_SQR_LINEAR_TEST
        XE_NP_Board_Np2Single7500SqrLinear(sample_hz,probe_mask)?5U:
#endif
        XE_NP_Board_Np2Dual30PsramQ128(sample_hz,probe_mask)?3U:0U);
#if XE_NP_NP2_SD_SINGLE7500_FLASH1_TEST
    if(changed==0 && sample_hz==7500U && probe_mask==1U){
        /* ST HAL RCC table1: VOS1,32<HCLK<=64MHz permits1WS. VOS is not
         * lowered: PSRAM96/SD108 keep their existing electrical margin. */
        if(HAL_RCC_GetHCLKFreq()!=48000000U ||
           (PWR->VOSR&(PWR_VOSR_VOS|PWR_VOSR_VOSRDY))!=
               (PWR_REGULATOR_VOLTAGE_SCALE1|PWR_VOSR_VOSRDY) ||
           (PWR->SVMSR&(PWR_SVMSR_ACTVOS|PWR_SVMSR_ACTVOSRDY))!=
               (PWR_REGULATOR_VOLTAGE_SCALE1|PWR_SVMSR_ACTVOSRDY))changed=-1;
        else{
            __HAL_FLASH_SET_LATENCY(FLASH_LATENCY_1);
            if(__HAL_FLASH_GET_LATENCY()!=FLASH_LATENCY_1){
                __HAL_FLASH_SET_LATENCY(FLASH_LATENCY_5);changed=-1;
            }
        }
    }
#endif
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
    XE_NP_SensorsPort_Resume();
#endif
#if XE_NP_NP2_SD_BLE_ENABLE
    /* A failed RCC helper may leave the core on HSE. Restore actual PCLK,
     * never the requested profile; no failed transition can skip retirement. */
    XE_NP_Np2SdBle_EndClockChange();
#endif
    if(changed!=0)return -1;
/* TRIPLE7500_CORE64_ASSIGN_BEGIN */
#if XE_NP_NP2_SD_TRIPLE7500_CORE64_TEST
    (void)mco_source;
#else
    xe_np_runtime_mco_source=mco_source;
#endif
/* TRIPLE7500_CORE64_ASSIGN_END */
    xe_np_runtime_mco_source_hz=mco_source_hz;
    xe_np_runtime_mco_divider=mco_source_hz/(sample_hz*1600U);
    xe_np_np2_sample_rate_hz=sample_hz;
    XE_NP_Board_RefreshRuntimeClockPlan();
    return 0;
}

int XE_NP_Board_SetNp2SampleRateHz(uint32_t sample_hz)
{
    return XE_NP_Board_SetNp2SampleRateProfile(sample_hz,0U);
}

void XE_NP_Board_StopNp2Mco(void)
{
    HAL_RCC_MCOConfig(RCC_MCO1, RCC_MCO1SOURCE_NOCLOCK, RCC_MCODIV_1);
    xe_np_np2_mco_enabled=0U;
    XE_NP_Board_RefreshRuntimeClockPlan();
}

int XE_NP_Board_StartNp2Mco(uint32_t supply_stable_ms)
{
    /* The complete idle rate profile has already selected and attested PLL1.
     * Failure keeps MCO off. A repeated start while active is rejected without
     * glitching the running clock. Coordinator must hold NRST appropriately. */
    if (xe_np_np2_mco_enabled) return -1;
    uint32_t hal_divider;
    uint32_t expected_source_hz=xe_np_runtime_mco_source==RCC_MCO1SOURCE_HSE?
        HSE_VALUE:xe_np_runtime_core_clock_hz;
    if (supply_stable_ms<10U || HAL_RCC_GetSysClockFreq()!=xe_np_runtime_core_clock_hz ||
        HAL_RCC_GetHCLKFreq()!=xe_np_runtime_core_clock_hz ||
        __HAL_RCC_GET_SYSCLK_SOURCE()!=RCC_SYSCLKSOURCE_STATUS_PLLCLK ||
        (xe_np_runtime_mco_source!=RCC_MCO1SOURCE_PLL1CLK &&
         xe_np_runtime_mco_source!=RCC_MCO1SOURCE_HSE) ||
        xe_np_runtime_mco_source_hz!=expected_source_hz ||
        xe_np_runtime_mco_source_hz%xe_np_runtime_mco_divider!=0U ||
        xe_np_runtime_mco_source_hz/xe_np_runtime_mco_divider!=
            xe_np_np2_sample_rate_hz*1600U ||
        (RCC->PLL1CFGR & (RCC_PLL1CFGR_PLL1SRC|RCC_PLL1CFGR_PLL1REN)) !=
        (RCC_PLLSOURCE_HSE|RCC_PLL1CFGR_PLL1REN) ||
        XE_NP_Board_McoDividerToHal(xe_np_runtime_mco_divider,&hal_divider)) {
        XE_NP_Board_StopNp2Mco();
        return -1;
    }
    /* The lean NP2 APP bypasses XE_NP_App's sensitive-pin setup. Restore
     * PA8's provisioned low-voltage drive BEFORE starting the shared MCLK;
     * neither option bytes nor the running acquisition are touched here. */
#if (XE_NP_BOARD_NP_MCO_HSLV_ENABLE != 0U)
    if((FLASH->OPTR & FLASH_OPTR_IO_VDD_HSLV)==0U){
        XE_NP_Board_StopNp2Mco();return -1;
    }
    HAL_GPIO_EnableHighSPeedLowVoltage(GPIOA, GPIO_PIN_8);
    if((GPIOA->HSLVR & GPIO_PIN_8)==0U){
        XE_NP_Board_StopNp2Mco();return -1;
    }
#endif
    if(xe_np_runtime_mco_source==RCC_MCO1SOURCE_PLL1CLK)
        __HAL_RCC_PLLCLKOUT_ENABLE(RCC_PLL1_DIVR);
    HAL_RCC_MCOConfig(RCC_MCO1, xe_np_runtime_mco_source, hal_divider);
    if ((RCC->CFGR1 & (RCC_CFGR1_MCOSEL|RCC_CFGR1_MCOPRE)) !=
        (xe_np_runtime_mco_source|hal_divider)) {
        XE_NP_Board_StopNp2Mco();
        return -1;
    }
    xe_np_np2_mco_enabled=1U;
    XE_NP_Board_RefreshRuntimeClockPlan();
    return 0;
}
#endif
