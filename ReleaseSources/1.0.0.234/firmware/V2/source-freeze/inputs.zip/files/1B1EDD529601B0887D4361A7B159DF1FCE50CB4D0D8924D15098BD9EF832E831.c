#include "xe_np_rtc.h"

#if XE_NP_RTC_ENABLE
#include "main.h"
#include "xe_np_board.h"
#include <string.h>

#define RTC_WAIT_LIMIT 4096U
#define RTC_SHIFT_SERVICE_MAX_MS 2000U
#define RTC_SHIFT_AWAIT_ASSERT 1U
#define RTC_SHIFT_ASSERT_SEEN 2U
#define RTC_EXPECTED_PRER ((XE_NP_RTC_PREDIV_A<<16U)|XE_NP_RTC_PREDIV_S)

typedef struct {
    volatile uint32_t revision;
    uint32_t pending_revision;
    uint32_t write_admitted,transaction_busy,source_ok,calendar_valid;
    uint32_t pc_calibrated,calibration_generation,discontinuity,conflict;
    uint32_t local_unavailable,shift_pending,pending_tr,pending_dr;
    uint32_t pending_ticks,pending_generation,pending_ms;
} XE_NP_RtcState;
static XE_NP_RtcState rtc_state;

typedef struct {
    uint32_t pwr_was_on,dbp_was_set,rtcapb_was_on;
} XE_NP_RtcBackupGuard;

static uint32_t rtc_bcd(uint32_t value)
{ return ((value/10U)<<4U)|(value%10U); }
static int rtc_unbcd(uint32_t value,uint32_t max,uint32_t *out)
{
    uint32_t tens=value>>4U,ones=value&15U;
    if(tens>9U || ones>9U || tens*10U+ones>max)return 0;
    *out=tens*10U+ones;return 1;
}
static int rtc_leap(uint32_t year)
{ return (year&3U)==0U; }
static uint32_t rtc_days(uint32_t year,uint32_t month)
{
    static const uint8_t days[12]={31U,28U,31U,30U,31U,30U,31U,31U,30U,31U,30U,31U};
    return month==2U && rtc_leap(year)?29U:days[month-1U];
}
static int rtc_calendar_valid(uint32_t tr,uint32_t dr,XE_NP_RtcSample *out)
{
    uint32_t y,mo,d,wd,h,mi,s;
    if(!rtc_unbcd((tr>>16U)&255U,23U,&h) || !rtc_unbcd((tr>>8U)&127U,59U,&mi) ||
       !rtc_unbcd(tr&127U,59U,&s) || !rtc_unbcd((dr>>16U)&255U,99U,&y) ||
       !rtc_unbcd((dr>>8U)&31U,12U,&mo) || !mo || !rtc_unbcd(dr&63U,31U,&d) ||
       !rtc_unbcd((dr>>13U)&7U,7U,&wd) || !mo || !wd || !d || d>rtc_days(2000U+y,mo))return 0;
    if(out){
        out->year=(uint16_t)(2000U+y);out->month=(uint8_t)mo;out->day=(uint8_t)d;
        out->weekday=(uint8_t)wd;out->hour=(uint8_t)h;out->minute=(uint8_t)mi;out->second=(uint8_t)s;
    }
    return 1;
}
static int rtc_hse_ready(void)
{ return HSE_VALUE==24000000UL && (RCC->CR&RCC_CR_HSERDY); }
static int rtc_write_allowed(void)
{ return rtc_state.write_admitted && !rtc_state.transaction_busy && !rtc_state.shift_pending; }
/* Only register/trust publication is atomic. INIT/RSF waits and coherent
 * calendar reads always run with the caller's interrupt state restored. */
static int rtc_epoch_enter(uint32_t revision,uint32_t *key)
{
    *key=__get_PRIMASK();__disable_irq();__DMB();
    if(revision==rtc_state.revision && !rtc_state.transaction_busy)return 1;
    __set_PRIMASK(*key);return 0;
}
static void rtc_epoch_leave(uint32_t key){__DMB();__set_PRIMASK(key);}
static int rtc_backup_open(XE_NP_RtcBackupGuard *guard)
{
    if(!rtc_write_allowed())return 0;
    guard->pwr_was_on=RCC->AHB3ENR&RCC_AHB3ENR_PWREN;
    guard->rtcapb_was_on=RCC->APB3ENR&RCC_APB3ENR_RTCAPBEN;
    if(!guard->pwr_was_on)RCC->AHB3ENR|=RCC_AHB3ENR_PWREN;
    if(!guard->rtcapb_was_on)RCC->APB3ENR|=RCC_APB3ENR_RTCAPBEN;
    (void)RCC->APB3ENR;
    guard->dbp_was_set=PWR->DBPR&PWR_DBPR_DBP;
    if(!guard->dbp_was_set)PWR->DBPR|=PWR_DBPR_DBP;
    (void)PWR->DBPR;__DSB();
    return (PWR->DBPR&PWR_DBPR_DBP)!=0U;
}
static void rtc_backup_close(const XE_NP_RtcBackupGuard *guard,uint32_t keep_rtcapb)
{
    if(!guard->dbp_was_set)PWR->DBPR&=~PWR_DBPR_DBP;
    if(!guard->pwr_was_on)RCC->AHB3ENR&=~RCC_AHB3ENR_PWREN;
    /* Reads are explicitly non-mutating, so retain RTC APB only after a
     * successful provider setup; otherwise restore the caller's gate. */
    if(!keep_rtcapb && !guard->rtcapb_was_on)RCC->APB3ENR&=~RCC_APB3ENR_RTCAPBEN;
}
static void rtc_unlock(void)
{ RTC->WPR=0xCAU;RTC->WPR=0x53U; }
static void rtc_lock(void)
{ RTC->WPR=0xFFU; }
static int rtc_wait(uint32_t mask,uint32_t value)
{
    for(uint32_t i=0U;i<RTC_WAIT_LIMIT;i++)if((RTC->ICSR&mask)==value)return 1;
    return 0;
}
static int rtc_enter_init(uint32_t revision)
{
    uint32_t key;
    if(!rtc_epoch_enter(revision,&key))return 0;
    if(!rtc_write_allowed() || (RTC->ICSR&(RTC_ICSR_SHPF|RTC_ICSR_INIT|RTC_ICSR_BIN))){rtc_epoch_leave(key);return 0;}
    rtc_unlock();RTC->ICSR|=RTC_ICSR_INIT;rtc_epoch_leave(key);
    if(rtc_wait(RTC_ICSR_INITF,RTC_ICSR_INITF) && revision==rtc_state.revision)return 1;
    /* Abort cleanup only: never leave an interrupted provider freezing RTC. */
    RTC->ICSR&=~RTC_ICSR_INIT;rtc_lock();return 0;
}
static void rtc_leave_init(void)
{ RTC->ICSR&=~RTC_ICSR_INIT;rtc_lock();__DSB(); }
static int rtc_source(uint32_t provision)
{
    uint32_t bdcr=RCC->BDCR,source=bdcr&RCC_BDCR_RTCSEL;
    if(!rtc_hse_ready())return 0;
    if(!(RCC->APB3ENR&RCC_APB3ENR_RTCAPBEN))return 0;
    if(!source){
        if(!provision || !rtc_write_allowed())return 0;
        RCC->BDCR=(bdcr&~RCC_BDCR_RTCSEL)|RCC_BDCR_RTCSEL|RCC_BDCR_RTCEN;__DSB();
        source=RCC->BDCR&RCC_BDCR_RTCSEL;
    }
    if(source!=RCC_BDCR_RTCSEL)return 0;
    if(!(RCC->BDCR&RCC_BDCR_RTCEN)){
        if(!provision || !rtc_write_allowed())return 0;
        RCC->BDCR|=RCC_BDCR_RTCEN;__DSB();
    }
    return (RCC->BDCR&(RCC_BDCR_RTCSEL|RCC_BDCR_RTCEN))==(RCC_BDCR_RTCSEL|RCC_BDCR_RTCEN);
}
static int rtc_prescaler_admissible(uint32_t prer,uint32_t icsr)
{
    /* U5 reset prescalers are not a configured calendar. Only the stopped,
     * revision-checked INIT transaction below may replace this cold default. */
    return prer==RTC_EXPECTED_PRER ||
           (!(icsr&RTC_ICSR_INITS) && prer==UINT32_C(0x007F00FF));
}
static int rtc_config_ok(void)
{
    if(RTC->CALR || (RTC->CR&(RTC_CR_FMT|RTC_CR_REFCKON)) ||
       (RTC->ICSR&(RTC_ICSR_INIT|RTC_ICSR_BIN)))return 0;
    return rtc_prescaler_admissible(RTC->PRER,RTC->ICSR);
}
static void rtc_refresh(uint32_t provision)
{
    XE_NP_RtcSample sample;
    rtc_state.source_ok=rtc_source(provision);
    if(!rtc_state.source_ok){
        rtc_state.calendar_valid=0U;rtc_state.pc_calibrated=0U;
        if((RCC->BDCR&RCC_BDCR_RTCSEL) && (RCC->BDCR&RCC_BDCR_RTCSEL)!=RCC_BDCR_RTCSEL)rtc_state.conflict=1U;
        return;
    }
    if(!rtc_config_ok()){
        rtc_state.conflict=1U;rtc_state.calendar_valid=0U;rtc_state.pc_calibrated=0U;return;
    }
    rtc_state.conflict=0U;
    rtc_state.calendar_valid=(RTC->ICSR&RTC_ICSR_INITS) && rtc_calendar_valid(RTC->TR,RTC->DR,&sample);
    if(!rtc_state.calendar_valid){rtc_state.pc_calibrated=0U;rtc_state.calibration_generation=0U;rtc_state.discontinuity=1U;}
}
static uint32_t rtc_status(void)
{
    uint32_t s=0U;
    if(rtc_state.source_ok)s|=XE_NP_RTC_STATUS_SOURCE_OK;
    if(rtc_state.calendar_valid)s|=XE_NP_RTC_STATUS_CALENDAR_VALID;
    if(rtc_state.pc_calibrated)s|=XE_NP_RTC_STATUS_PC_CALIBRATED;
    if(rtc_state.write_admitted)s|=XE_NP_RTC_STATUS_WRITE_ADMITTED;
    if(rtc_state.transaction_busy)s|=XE_NP_RTC_STATUS_TRANSACTION_BUSY;
    if(rtc_state.discontinuity)s|=XE_NP_RTC_STATUS_DISCONTINUITY;
    if(rtc_state.conflict)s|=XE_NP_RTC_STATUS_CONFLICT;
    if(rtc_state.local_unavailable)s|=XE_NP_RTC_STATUS_LOCAL_UNAVAILABLE;
    if(rtc_state.shift_pending)s|=XE_NP_RTC_STATUS_SHIFT_PENDING;
    return s;
}
int XE_NP_Rtc_Init(void)
{
    XE_NP_RtcBackupGuard guard;
    if(!rtc_backup_open(&guard))return 0;
    rtc_refresh(1U);rtc_backup_close(&guard,rtc_state.source_ok);
    return rtc_state.source_ok && !rtc_state.conflict;
}
uint32_t XE_NP_Rtc_Status(void)
{ rtc_refresh(0U);return rtc_status(); }
uint32_t XE_NP_Rtc_ShiftPending(void)
{ return rtc_state.shift_pending!=0U; }
void XE_NP_Rtc_AdmitIdle(uint32_t admitted)
{
    rtc_state.write_admitted=admitted && !rtc_state.transaction_busy;
    if(rtc_state.write_admitted)rtc_state.local_unavailable=0U;
}
void XE_NP_Rtc_SetTransactionBusy(uint32_t busy)
{
    rtc_state.transaction_busy=!!busy;
    if(busy){
        rtc_state.revision++;__DMB();rtc_state.write_admitted=0U;
        if(rtc_state.shift_pending || (RTC->ICSR&RTC_ICSR_SHPF)){
            rtc_state.local_unavailable=1U;rtc_state.pc_calibrated=0U;
            rtc_state.calibration_generation=0U;
        }
    }
}
void XE_NP_Rtc_Invalidate(void)
{
    rtc_state.revision++;__DMB();rtc_state.write_admitted=0U;rtc_state.pc_calibrated=0U;
    rtc_state.calibration_generation=0U;rtc_state.discontinuity=1U;
    rtc_state.shift_pending=0U;rtc_state.local_unavailable=1U;
    rtc_refresh(0U);
}
int XE_NP_Rtc_Read(XE_NP_RtcSample *out)
{
    uint32_t ssr0,ssr1,tr0,tr1,dr0,dr1;
    if(!out)return 0;
    memset(out,0,sizeof(*out));rtc_refresh(0U);
    /* Unknown calendar still returns actual readable configuration diagnostics;
     * flags/return value never turn them into a qualified time observation. */
    out->bdcr=RCC->BDCR;out->status=rtc_status();
    if(RCC->APB3ENR&RCC_APB3ENR_RTCAPBEN){out->prer=RTC->PRER;out->calr=RTC->CALR;}
    if(!rtc_state.source_ok || !rtc_state.calendar_valid)return 0;
    if(!(RTC->CR&RTC_CR_BYPSHAD) && !(RTC->ICSR&RTC_ICSR_RSF))return 0;
    /* RM0456 54.3.12 bypass-safe sequence: require two complete matching
     * SSR/TR/DR tuples; never compose a calendar across a rollover. */
    for(uint32_t tries=0U;tries<3U;tries++){
        ssr0=RTC->SSR;tr0=RTC->TR;dr0=RTC->DR;
        ssr1=RTC->SSR;tr1=RTC->TR;dr1=RTC->DR;
        if(ssr0==ssr1 && tr0==tr1 && dr0==dr1 && ssr1<=XE_NP_RTC_PREDIV_S &&
           rtc_calendar_valid(tr1,dr1,out)){
            out->raw_ssr=ssr1;out->raw_tr=tr1;out->raw_dr=dr1;out->prer=RTC->PRER;
            out->calr=RTC->CALR;out->bdcr=RCC->BDCR;
            out->lower_us=(XE_NP_RTC_PREDIV_S-ssr1)*XE_NP_RTC_QUANTUM_US;
            out->upper_us=out->lower_us+XE_NP_RTC_QUANTUM_US;
            out->calibration_generation=rtc_state.calibration_generation;
            out->status=rtc_status();return 1;
        }
    }
    return 0;
}
static int rtc_increment(XE_NP_RtcSample *utc)
{
    if(++utc->second<60U)return 1;utc->second=0U;
    if(++utc->minute<60U)return 1;utc->minute=0U;
    if(++utc->hour<24U)return 1;utc->hour=0U;
    utc->weekday=utc->weekday==7U?1U:(uint8_t)(utc->weekday+1U);
    if(++utc->day<=rtc_days(utc->year,utc->month))return 1;utc->day=1U;
    if(++utc->month<=12U)return 1;utc->month=1U;
    if(++utc->year<=2099U)return 1;return 0;
}
static int rtc_calendar_not_before(const XE_NP_RtcSample *actual,
                                   const XE_NP_RtcSample *expected)
{
    if(actual->year!=expected->year)return actual->year>expected->year;
    if(actual->month!=expected->month)return actual->month>expected->month;
    if(actual->day!=expected->day)return actual->day>expected->day;
    if(actual->hour!=expected->hour)return actual->hour>expected->hour;
    if(actual->minute!=expected->minute)return actual->minute>expected->minute;
    return actual->second>=expected->second;
}
int XE_NP_Rtc_Service(void)
{
    XE_NP_RtcSample readback,expected;
    uint32_t revision=rtc_state.pending_revision,key;
    if(!rtc_state.shift_pending)return 0;
    if(revision!=rtc_state.revision ||
       rtc_state.transaction_busy || rtc_state.local_unavailable){
        rtc_state.shift_pending=0U;rtc_state.pc_calibrated=0U;
        rtc_state.calibration_generation=0U;return 0;
    }
    if((uint32_t)(HAL_GetTick()-rtc_state.pending_ms)>RTC_SHIFT_SERVICE_MAX_MS ||
       !rtc_state.pending_generation || !rtc_state.pending_ticks ||
       rtc_state.pending_ticks>XE_NP_RTC_PREDIV_S)goto failed;
    rtc_refresh(0U);
    if(!rtc_state.source_ok || rtc_state.conflict)goto failed;
    /* SHIFTR is write-only. Completion uses the owned pending RAM request and
     * a fresh calendar/fraction, never a readback of the command register.
     * Status and SS>PREDIV_S normalization may take nearly1s after ADD1S+SUBFS.
     * The existing deadline is a software policy, not a hardware latency bound. */
    if(RTC->ICSR&RTC_ICSR_SHPF){rtc_state.shift_pending=RTC_SHIFT_ASSERT_SEEN;return 0;}
    /* A pre-write/stale tuple can already exceed a small requested fraction.
     * Require the owned SHPF assertion followed by clear. A missed pulse is
     * deliberately unknown at the deadline, never inferred from elapsed time. */
    if(rtc_state.shift_pending!=RTC_SHIFT_ASSERT_SEEN || !rtc_state.calendar_valid ||
       !XE_NP_Rtc_Read(&readback))return 0;
    memset(&expected,0,sizeof(expected));
    if(!rtc_calendar_valid(rtc_state.pending_tr,rtc_state.pending_dr,&expected))goto failed;
    if(!rtc_calendar_not_before(&readback,&expected) ||
       (readback.raw_tr==rtc_state.pending_tr && readback.raw_dr==rtc_state.pending_dr &&
        readback.lower_us<rtc_state.pending_ticks*XE_NP_RTC_QUANTUM_US))return 0;
    if(!rtc_epoch_enter(revision,&key))return 0;
    if(rtc_state.shift_pending!=RTC_SHIFT_ASSERT_SEEN || rtc_state.pending_revision!=revision ||
       rtc_state.local_unavailable){rtc_epoch_leave(key);return 0;}
    rtc_state.shift_pending=0U;rtc_state.pc_calibrated=1U;
    rtc_state.calibration_generation=rtc_state.pending_generation;
    rtc_state.discontinuity=0U;rtc_epoch_leave(key);return 1;
failed:
    rtc_state.shift_pending=0U;rtc_state.pc_calibrated=0U;
    rtc_state.calibration_generation=0U;rtc_state.conflict=1U;return 0;
}

int XE_NP_Rtc_SetCalendarPhase(const XE_NP_RtcSample *in,uint32_t subsecond_us,
                               uint32_t calibration_generation)
{
    XE_NP_RtcSample utc,readback;
    XE_NP_RtcBackupGuard guard;
    uint32_t ticks,tr,dr,key,revision=rtc_state.revision;
    if(!in || subsecond_us>=1000000U || !calibration_generation || !rtc_write_allowed())return 0;
    rtc_state.pc_calibrated=0U;rtc_state.calibration_generation=0U;
    utc=*in;
    if(utc.year<2000U || utc.year>2099U || !utc.month || utc.month>12U ||
       !utc.day || utc.day>rtc_days(utc.year,utc.month) || !utc.weekday || utc.weekday>7U ||
       utc.hour>23U || utc.minute>59U || utc.second>59U)return 0;
    ticks=(subsecond_us+XE_NP_RTC_QUANTUM_US/2U)/XE_NP_RTC_QUANTUM_US;
    if(ticks>XE_NP_RTC_PREDIV_S){if(!rtc_increment(&utc))return 0;ticks=0U;}
    if(!rtc_backup_open(&guard))return 0;
    if(!rtc_epoch_enter(revision,&key)){rtc_backup_close(&guard,0U);return 0;}
    int source_ok=rtc_source(1U);rtc_epoch_leave(key);
    if(!source_ok){rtc_backup_close(&guard,0U);return 0;}
    if(RTC->ICSR&RTC_ICSR_SHPF){rtc_state.conflict=1U;rtc_backup_close(&guard,1U);return 0;}
    if(RTC->CALR || (RTC->CR&(RTC_CR_FMT|RTC_CR_REFCKON)) ||
       (RTC->ICSR&(RTC_ICSR_INIT|RTC_ICSR_BIN)) ||
       !rtc_prescaler_admissible(RTC->PRER,RTC->ICSR)){
        rtc_state.conflict=1U;rtc_backup_close(&guard,1U);return 0;
    }
    tr=rtc_bcd(utc.second)|(rtc_bcd(utc.minute)<<8U)|(rtc_bcd(utc.hour)<<16U);
    dr=rtc_bcd(utc.day)|(rtc_bcd(utc.month)<<8U)|((uint32_t)utc.weekday<<13U)|
       (rtc_bcd(utc.year-2000U)<<16U);
    if(!rtc_enter_init(revision)){rtc_backup_close(&guard,1U);return 0;}
    if(!rtc_epoch_enter(revision,&key)){rtc_leave_init();rtc_backup_close(&guard,1U);return 0;}
    if(!rtc_write_allowed()){rtc_leave_init();rtc_epoch_leave(key);rtc_backup_close(&guard,1U);return 0;}
    RTC->PRER=RTC_EXPECTED_PRER;RTC->TR=tr;RTC->DR=dr;rtc_leave_init();rtc_epoch_leave(key);
    if(!(RTC->CR&RTC_CR_BYPSHAD) && !rtc_wait(RTC_ICSR_RSF,RTC_ICSR_RSF)){
        rtc_backup_close(&guard,1U);return 0;
    }
    if(ticks){
        if(!rtc_epoch_enter(revision,&key)){rtc_backup_close(&guard,1U);return 0;}
        if(!rtc_write_allowed() || (RTC->ICSR&RTC_ICSR_SHPF)){rtc_state.conflict=1U;rtc_epoch_leave(key);rtc_backup_close(&guard,1U);return 0;}
        rtc_unlock();RTC->SHIFTR=RTC_SHIFTR_ADD1S|
            ((XE_NP_RTC_PREDIV_S+1U-ticks)&RTC_SHIFTR_SUBFS);rtc_lock();
        rtc_state.shift_pending=RTC_SHIFT_AWAIT_ASSERT;rtc_state.pending_tr=tr;rtc_state.pending_dr=dr;
        rtc_state.pending_ticks=ticks;rtc_state.pending_generation=calibration_generation;
        rtc_state.pending_ms=HAL_GetTick();rtc_state.pending_revision=revision;rtc_epoch_leave(key);
        rtc_backup_close(&guard,1U);
        /* SHPF may assert after this CPU write.  Progress is foreground and
         * read-only so an accepted request never mistakes that race for a
         * calendar conflict. */
        return 1;
    }
    rtc_backup_close(&guard,1U);
    rtc_refresh(0U);
    if(!rtc_state.calendar_valid || !XE_NP_Rtc_Read(&readback) ||
       readback.raw_tr!=tr || readback.raw_dr!=dr ||
       readback.lower_us<ticks*XE_NP_RTC_QUANTUM_US)return 0;
    if(!rtc_epoch_enter(revision,&key))return 0;
    rtc_state.pc_calibrated=1U;rtc_state.calibration_generation=calibration_generation;
    rtc_state.discontinuity=0U;rtc_epoch_leave(key);return 1;
}
#else
int XE_NP_Rtc_Init(void){return 0;}
uint32_t XE_NP_Rtc_Status(void){return 0U;}
uint32_t XE_NP_Rtc_ShiftPending(void){return 0U;}
int XE_NP_Rtc_Read(XE_NP_RtcSample *out){(void)out;return 0;}
void XE_NP_Rtc_AdmitIdle(uint32_t admitted){(void)admitted;}
void XE_NP_Rtc_SetTransactionBusy(uint32_t busy){(void)busy;}
void XE_NP_Rtc_Invalidate(void){}
int XE_NP_Rtc_SetCalendarPhase(const XE_NP_RtcSample *utc,uint32_t phase,uint32_t generation)
{(void)utc;(void)phase;(void)generation;return 0;}
int XE_NP_Rtc_Service(void){return 0;}
#endif
