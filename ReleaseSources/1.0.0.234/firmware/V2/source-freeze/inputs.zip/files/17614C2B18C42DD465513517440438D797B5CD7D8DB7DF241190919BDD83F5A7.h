#ifndef XE_NP_NP2_SD_FINE_CLOCK_H
#define XE_NP_NP2_SD_FINE_CLOCK_H
#include <stdint.h>
#ifndef NP_FINE_COUNTER64_ENABLE
#define NP_FINE_COUNTER64_ENABLE 0U
#endif
#define XE_NP_NP2_SD_FINE_HZ 1000000U
typedef struct {
    uint32_t domain,counter_hz,ms,counter,generation,source_epoch;
} XE_NP_Np2SdFinePoint;
/* APP opt-in owner only. Call after SD/UHS and profile clocks have settled,
 * before final capture arm. A new context gets a new logical domain. Never
 * call Start from a read-only query. Unknown optional time cannot gate NP. */
int XE_NP_Np2SdFineClock_Start(uint32_t seed,uint32_t generation,uint32_t source_epoch);
/* Publish only a genuinely armed final source context. The counter/domain
 * continue unchanged; a UART frame spanning this update is not CaptureBound. */
int XE_NP_Np2SdFineClock_BindSource(uint32_t generation,uint32_t source_epoch);
/* Required before card reinit/CMD11, reclock, STOP or mode handover. */
void XE_NP_Np2SdFineClock_Invalidate(void);
/* Foreground ownership/clock qualification. */
int XE_NP_Np2SdFineClock_Read(XE_NP_Np2SdFinePoint *out);
/* UART-tail observation only; foreground Read must still qualify its domain.
 * tick is the existing HAL tick observed at the matching RDR retirement. */
int XE_NP_Np2SdFineClock_ReadIrq(uint32_t tick,XE_NP_Np2SdFinePoint *out);
#if NP_FINE_COUNTER64_ENABLE
/* Same actual TIM5 domain as the NP root. No HAL-based wrap inference. */
typedef struct {
    uint64_t counter;
    uint32_t domain,counter_hz,ms,generation,source_epoch;
} XE_NP_Np2SdFinePoint64;
/* Startup-only failure evidence; it is never a steady health monitor. */
typedef enum {
    XE_NP_FINE_DIAG_NONE=0U,
    XE_NP_FINE_DIAG_CLOCK_BEGIN=1U,
    XE_NP_FINE_DIAG_RUNTIME_FINE_BOUND=2U,
    XE_NP_FINE_DIAG_CAPTURE_DESCRIPTOR=3U,
    XE_NP_FINE_DIAG_CAPTURE_BEFORE=4U,
    XE_NP_FINE_DIAG_CAPTURE_FIRST_WORD=5U,
    XE_NP_FINE_DIAG_CAPTURE_AFTER=6U,
    XE_NP_FINE_DIAG_READ_OWNED=7U
} XE_NP_Np2SdFineDiagnosticStage;
typedef enum {
    XE_NP_FINE_DIAG_DETAIL_NONE=0U,
    XE_NP_FINE_DIAG_DETAIL_ARGUMENT=1U,
    XE_NP_FINE_DIAG_DETAIL_ROOT=2U,
    XE_NP_FINE_DIAG_DETAIL_OWNED=3U,
    XE_NP_FINE_DIAG_DETAIL_FOREIGN_NVIC=4U,
    XE_NP_FINE_DIAG_DETAIL_FOREIGN_TIMER=5U,
    XE_NP_FINE_DIAG_DETAIL_APB_CLOCK=6U,
    XE_NP_FINE_DIAG_DETAIL_QUALIFICATION=7U,
    XE_NP_FINE_DIAG_DETAIL_BIND_ARGUMENT=8U,
    XE_NP_FINE_DIAG_DETAIL_BIND_QUALIFICATION=9U,
    XE_NP_FINE_DIAG_DETAIL_READ_QUALIFICATION=10U
} XE_NP_Np2SdFineDiagnosticDetail;
#define XE_NP_FINE_PROGRESS_BEGIN_OPEN       0x00000001U
#define XE_NP_FINE_PROGRESS_CLOCK_BEGIN_CALLED 0x00000002U
#define XE_NP_FINE_PROGRESS_CLOCK_BEGIN_OK   0x00000004U
#define XE_NP_FINE_PROGRESS_CLOCK_BEGIN_FAIL 0x00000008U
#define XE_NP_FINE_PROGRESS_FINE_BOUND_CALLED 0x00000010U
#define XE_NP_FINE_PROGRESS_FINE_BOUND_OK    0x00000020U
#define XE_NP_FINE_PROGRESS_FINE_BOUND_FAIL  0x00000040U
#define XE_NP_FINE_PROGRESS_END              0x00000080U
#define XE_NP_FINE_PROGRESS_START64_CALLED   0x00000100U
#define XE_NP_FINE_PROGRESS_START64_OK       0x00000200U
#define XE_NP_FINE_PROGRESS_START64_FAIL     0x00000400U
/* Exactly 56 words (224 bytes). stage is stored last after a DMB, making a
 * nonzero stage the publication marker for a complete first-failure image. */
typedef struct {
    volatile uint32_t stage;
    uint32_t detail,window_open,progress,nonce,features,generation,epoch;
    uint32_t before_counter_lo,before_counter_hi,before_domain,before_hz,before_generation,before_epoch;
    uint32_t after_counter_lo,after_counter_hi,after_domain,after_hz,after_generation,after_epoch;
    uint32_t dhcsr,dbg_tim5_freeze,scr;
    uint32_t rcc_cr,rcc_cfgr1,rcc_cfgr2,rcc_pll1cfgr,rcc_pll1divr,rcc_pll1fracr;
    uint32_t rcc_apb1enr1,rcc_apb1smenr1,rcc_apb1rstr1;
    uint32_t tim5_cr1,tim5_cr2,tim5_smcr,tim5_dier,tim5_psc,tim5_arr,tim5_cnt,tim5_sr;
    uint32_t nvic_enabled,nvic_pending,nvic_priority;
    uint32_t saved_owned,saved_continuous,saved_bound,saved_domain,saved_generation,saved_epoch;
    uint32_t saved_hclk,saved_cfgr1,saved_cfgr2,saved_pll1cfgr,saved_pll1divr,saved_pll1fracr;
    uint32_t saved_context;
} XE_NP_Np2SdFineDiagnostic;
extern volatile XE_NP_Np2SdFineDiagnostic xe_np_np2_sd_fine_diagnostic;
void XE_NP_Np2SdFineDiagnosticBegin(uint32_t nonce,uint32_t features);
void XE_NP_Np2SdFineDiagnosticEnd(void);
void XE_NP_Np2SdFineDiagnosticProgress(uint32_t flags);
void XE_NP_Np2SdFineDiagnosticFailure(uint32_t stage,uint32_t detail,
    uint32_t generation,uint32_t epoch,const XE_NP_Np2SdFinePoint64 *before,
    const XE_NP_Np2SdFinePoint64 *after);
const volatile XE_NP_Np2SdFineDiagnostic *XE_NP_Np2SdFineDiagnosticGet(void);
int XE_NP_Np2SdFineClock_Start64(uint32_t seed,uint32_t generation,uint32_t source_epoch);
/* Private startup bridge only: allowed before final generation binding. */
int XE_NP_Np2SdFineClock_ReadOwned64(XE_NP_Np2SdFinePoint64 *out);
/* One independent actual first-source bracket. BEFORE must have highword0;
 * AFTER may cross one wrap, with raw/full span <=100us. */
int XE_NP_Np2SdFineClock_BindSource64(uint32_t generation,uint32_t source_epoch,
    const XE_NP_Np2SdFinePoint64 *before,const XE_NP_Np2SdFinePoint64 *after);
/* Public sensor observations require the independently bound final source. */
int XE_NP_Np2SdFineClock_Read64(XE_NP_Np2SdFinePoint64 *out);
int XE_NP_Np2SdFineClock_Read64Irq(uint32_t tick,XE_NP_Np2SdFinePoint64 *out);
/* Foreground read-only owner/config check. Never reconfigures TIM5 or reads RTC. */
int XE_NP_Np2SdFineClock_BoundQualified64(uint32_t domain,uint32_t generation,uint32_t epoch);
#endif
#endif
