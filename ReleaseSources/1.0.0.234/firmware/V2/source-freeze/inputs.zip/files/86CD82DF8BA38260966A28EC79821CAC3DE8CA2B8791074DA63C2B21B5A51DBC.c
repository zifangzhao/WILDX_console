#include "CE32_BMX160.h"
#include "xe_np_sensors_port.h"

#include <string.h>

CE32_IMU_BMX160_handle ACC_handle = {0};

static sBmx160Dev_t xe_np_bmx160_dev = {0};

extern uint8_t ACC_buf_raw[20];
extern uint16_t ACC_value[10];

static HAL_StatusTypeDef XE_NP_BMX160_WriteReg(
    CE32_IMU_BMX160_handle *handle,
    uint8_t reg,
    uint8_t value)
{
    if((handle == NULL) || (handle->hi2c == NULL))
    {
        return HAL_ERROR;
    }

    return HAL_I2C_Mem_Write(
        handle->hi2c,
        (uint16_t)(BMX160_I2C_ADDR << 1),
        reg,
        I2C_MEMADD_SIZE_8BIT,
        &value,
        1U,
        100U);
}

static HAL_StatusTypeDef XE_NP_BMX160_ReadReg(
    CE32_IMU_BMX160_handle *handle,
    uint8_t reg,
    uint8_t *buffer,
    uint16_t len)
{
    if((handle == NULL) || (handle->hi2c == NULL) || (buffer == NULL) || (len == 0U))
    {
        return HAL_ERROR;
    }

    return HAL_I2C_Mem_Read(
        handle->hi2c,
        (uint16_t)(BMX160_I2C_ADDR << 1),
        reg,
        I2C_MEMADD_SIZE_8BIT,
        buffer,
        len,
        100U);
}

static void XE_NP_BMX160_Delay(uint32_t delay_ms)
{
    HAL_Delay(delay_ms);
}

static void XE_NP_BMX160_InitLine(
    GPIO_TypeDef *port,
    uint16_t pin,
    uint32_t mode,
    uint32_t pull)
{
    GPIO_InitTypeDef init = {0};

    if(port == NULL)
    {
        return;
    }

    init.Pin = pin;
    init.Mode = mode;
    init.Pull = pull;
    init.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(port, &init);
}

static void XE_NP_BMX160_CopyRawToValueArray(CE32_IMU_BMX160_handle *handle)
{
    if((handle == NULL) || (handle->data_ptr == NULL))
    {
        return;
    }

    if(handle->data_ptr == ACC_buf_raw)
    {
        memcpy(ACC_value, ACC_buf_raw, sizeof(ACC_buf_raw));
    }
}

int CE32_IMU_BMX160_init(
    CE32_IMU_BMX160_handle *handle,
    I2C_HandleTypeDef *hi2c,
    DMA_HandleTypeDef *hdma_i2c_rx,
    GPIO_TypeDef *GPIO_SDA,
    uint16_t SDA_Pin,
    GPIO_TypeDef *GPIO_SCL,
    uint16_t SCL_Pin,
    CE32_IMU_BMX160_PMODE Pmode)
{
    if((handle == NULL) || (hi2c == NULL) || (hi2c->Instance == NULL))
    {
        return -1;
    }

    memset(handle, 0, sizeof(*handle));
    memset(&xe_np_bmx160_dev, 0, sizeof(xe_np_bmx160_dev));
    handle->hi2c = hi2c;
    handle->hdma_i2c_rx = hdma_i2c_rx;
    handle->GPIO_SDA = GPIO_SDA;
    handle->GPIO_SCL = GPIO_SCL;
    handle->SDA_Pin = SDA_Pin;
    handle->SCL_Pin = SCL_Pin;
    handle->PMode = Pmode;
    handle->state = CE32_BMX160_STATE_IDLE;
    handle->accelRange = BMX160_ACCEL_MG_LSB_2G * 9.8f;
    handle->gyroRange = BMX160_GYRO_SENSITIVITY_250DPS;
    handle->_addr = BMX160_I2C_ADDR;
    handle->Obmx160 = &xe_np_bmx160_dev;
    XE_NP_BMX160_Delay(1U);

    CE32_IMU_ReleaseI2C(handle);
    CE32_IMU_PreInitAct();

    if(HAL_I2C_IsDeviceReady(handle->hi2c, (uint16_t)(BMX160_I2C_ADDR << 1), 3U, 50U) != HAL_OK)
    {
        return -2;
    }

    if(CE32_IMU_BMX160_softReset(handle) != 0)
    {
        return -3;
    }

    if(handle->PMode == PMODE_Stop)
    {
        (void)CE32_IMU_BMX160_suspend(handle);
        handle->state = CE32_BMX160_STATE_IDLE;
        return 0;
    }

    if(handle->PMode == PMODE_Normal)
    {
        if((CE32_IMU_BMX160_begin(handle) != 0) ||
           (CE32_IMU_BMX160_setAccConf(handle) != 0) ||
           (CE32_IMU_BMX160_setGyroConf(handle) != 0) ||
           (CE32_IMU_BMX160_setMagnConf(handle) != 0))
        {
            return -4;
        }
    }
    else
    {
        if((CE32_IMU_BMX160_setLowPower(handle) != 0) ||
           (CE32_IMU_BMX160_setAccConf(handle) != 0))
        {
            return -5;
        }
    }

    (void)CE32_IMU_BMX160_getAllData(handle);
    handle->state = CE32_BMX160_STATE_READY;
    return 0;
}

int CE32_IMU_BMX160_begin(CE32_IMU_BMX160_handle *handle)
{
    if((XE_NP_BMX160_WriteReg(handle, BMX160_COMMAND_REG_ADDR, 0x11U) != HAL_OK) ||
       (XE_NP_BMX160_WriteReg(handle, BMX160_COMMAND_REG_ADDR, 0x15U) != HAL_OK) ||
       (XE_NP_BMX160_WriteReg(handle, BMX160_COMMAND_REG_ADDR, 0x19U) != HAL_OK))
    {
        return -1;
    }

    XE_NP_BMX160_Delay(10U);
    return 0;
}

void CE32_IMU_StopTrans(CE32_IMU_BMX160_handle *handle)
{
    if(handle == NULL)
    {
        return;
    }

    handle->state = CE32_BMX160_STATE_IDLE;
    (void)CE32_IMU_BMX160_suspend(handle);
    CE32_IMU_ReleaseI2C(handle);
}

int CE32_IMU_BMX160_suspend(CE32_IMU_BMX160_handle *handle)
{
    if(handle == NULL)
    {
        return -1;
    }

    if(XE_NP_BMX160_WriteReg(handle, BMX160_COMMAND_REG_ADDR, BMX160_ACCEL_SUSPEND_MODE) != HAL_OK)
    {
        return -2;
    }
    if(XE_NP_BMX160_WriteReg(handle, BMX160_COMMAND_REG_ADDR, BMX160_GYRO_SUSPEND_MODE) != HAL_OK)
    {
        return -3;
    }
    if(XE_NP_BMX160_WriteReg(handle, BMX160_COMMAND_REG_ADDR, BMX160_MAGN_SUSPEND_MODE) != HAL_OK)
    {
        return -4;
    }

    XE_NP_BMX160_Delay(20U);
    return 0;
}

int CE32_IMU_BMX160_setLowPower(CE32_IMU_BMX160_handle *handle)
{
    if((handle == NULL) ||
       (CE32_IMU_BMX160_softReset(handle) != 0) ||
       (CE32_IMU_BMX160_setMagnConf(handle) != 0))
    {
        return -1;
    }

    if((XE_NP_BMX160_WriteReg(handle, BMX160_COMMAND_REG_ADDR, 0x11U) != HAL_OK) ||
       (XE_NP_BMX160_WriteReg(handle, BMX160_COMMAND_REG_ADDR, 0x17U) != HAL_OK) ||
       (XE_NP_BMX160_WriteReg(handle, BMX160_COMMAND_REG_ADDR, 0x1BU) != HAL_OK))
    {
        return -2;
    }

    XE_NP_BMX160_Delay(10U);
    return 0;
}

int CE32_IMU_BMX160_wakeUp(CE32_IMU_BMX160_handle *handle)
{
    if((handle == NULL) ||
       (CE32_IMU_BMX160_softReset(handle) != 0) ||
       (CE32_IMU_BMX160_setMagnConf(handle) != 0))
    {
        return -1;
    }

    if((XE_NP_BMX160_WriteReg(handle, BMX160_COMMAND_REG_ADDR, 0x11U) != HAL_OK) ||
       (XE_NP_BMX160_WriteReg(handle, BMX160_COMMAND_REG_ADDR, 0x15U) != HAL_OK) ||
       (XE_NP_BMX160_WriteReg(handle, BMX160_COMMAND_REG_ADDR, 0x19U) != HAL_OK))
    {
        return -2;
    }

    XE_NP_BMX160_Delay(10U);
    return 0;
}

int CE32_IMU_BMX160_softReset(CE32_IMU_BMX160_handle *handle)
{
    if((handle == NULL) || (XE_NP_BMX160_WriteReg(handle, BMX160_COMMAND_REG_ADDR, BMX160_SOFT_RESET_CMD) != HAL_OK))
    {
        return -1;
    }

    XE_NP_BMX160_Delay(BMX160_SOFT_RESET_DELAY_MS);
    if(handle->Obmx160 != NULL)
    {
        (void)CE32_IMU_BMX160_defaultParamSet(handle, handle->Obmx160);
    }
    return 0;
}

int CE32_IMU_BMX160__softReset(CE32_IMU_BMX160_handle *handle, sBmx160Dev_t *dev)
{
    if((handle == NULL) || (dev == NULL))
    {
        return -1;
    }

    return CE32_IMU_BMX160_softReset(handle);
}

int CE32_IMU_BMX160_defaultParamSet(CE32_IMU_BMX160_handle *handle, sBmx160Dev_t *dev)
{
    (void)handle;
    if(dev == NULL)
    {
        return -1;
    }

    dev->gyroCfg.bw = BMX160_GYRO_BW_NORMAL_MODE;
    dev->gyroCfg.odr = BMX160_GYRO_ODR_200HZ;
    dev->gyroCfg.power = BMX160_GYRO_NORMAL_MODE;
    dev->gyroCfg.range = BMX160_GYRO_RANGE_2000_DPS;
    dev->accelCfg.bw = BMX160_ACCEL_BW_NORMAL_AVG4;
    dev->accelCfg.odr = BMX160_ACCEL_ODR_200HZ;
    dev->accelCfg.power = BMX160_ACCEL_SUSPEND_MODE;
    dev->accelCfg.range = BMX160_ACCEL_RANGE_2G;
    dev->prevMagnCfg = dev->magnCfg;
    dev->prevGyroCfg = dev->gyroCfg;
    dev->prevAccelCfg = dev->accelCfg;
    return 0;
}

int CE32_IMU_BMX160_setAccConf(CE32_IMU_BMX160_handle *handle)
{
    uint8_t config;

    if(handle == NULL)
    {
        return -1;
    }

    config = (handle->PMode == PMODE_Normal) ? BMX160_ACCEL_ODR_200HZ : BMX160_ACCEL_ODR_100HZ;
    config |= (uint8_t)(BMX160_ACCEL_BW_NORMAL_AVG4 << 4U);
    if(XE_NP_BMX160_WriteReg(handle, BMX160_ACCEL_CONFIG_ADDR, config) != HAL_OK)
    {
        return -2;
    }

    return CE32_IMU_BMX160_setAccelRange(handle, eAccelRange_8G);
}

int CE32_IMU_BMX160_setGyroConf(CE32_IMU_BMX160_handle *handle)
{
    if((handle == NULL) ||
       (XE_NP_BMX160_WriteReg(
            handle,
            BMX160_GYRO_CONFIG_ADDR,
            (uint8_t)(BMX160_GYRO_ODR_200HZ | (BMX160_GYRO_BW_NORMAL_MODE << 4U))) != HAL_OK))
    {
        return -1;
    }

    return CE32_IMU_BMX160_setGyroRange(handle, eGyroRange_2000DPS);
}

int CE32_IMU_BMX160_setMagnConf(CE32_IMU_BMX160_handle *handle)
{
    if(handle == NULL)
    {
        return -1;
    }

    if((XE_NP_BMX160_WriteReg(handle, BMX160_MAGN_IF_0_ADDR, 0x80U) != HAL_OK) ||
       (XE_NP_BMX160_WriteReg(handle, BMX160_MAGN_IF_3_ADDR, 0x01U) != HAL_OK) ||
       (XE_NP_BMX160_WriteReg(handle, BMX160_MAGN_IF_2_ADDR, 0x4BU) != HAL_OK) ||
       (XE_NP_BMX160_WriteReg(handle, BMX160_MAGN_IF_3_ADDR, 0x04U) != HAL_OK) ||
       (XE_NP_BMX160_WriteReg(handle, BMX160_MAGN_IF_2_ADDR, 0x51U) != HAL_OK) ||
       (XE_NP_BMX160_WriteReg(handle, BMX160_MAGN_IF_3_ADDR, 0x0EU) != HAL_OK) ||
       (XE_NP_BMX160_WriteReg(handle, BMX160_MAGN_IF_2_ADDR, 0x52U) != HAL_OK) ||
       (XE_NP_BMX160_WriteReg(handle, BMX160_MAGN_IF_3_ADDR, 0x02U) != HAL_OK) ||
       (XE_NP_BMX160_WriteReg(handle, BMX160_MAGN_IF_2_ADDR, 0x4CU) != HAL_OK) ||
       (XE_NP_BMX160_WriteReg(handle, BMX160_MAGN_IF_1_ADDR, 0x42U) != HAL_OK) ||
       (XE_NP_BMX160_WriteReg(handle, BMX160_MAGN_CONFIG_ADDR, 0x08U) != HAL_OK) ||
       (XE_NP_BMX160_WriteReg(handle, BMX160_MAGN_IF_0_ADDR, 0x03U) != HAL_OK))
    {
        return -2;
    }

    XE_NP_BMX160_Delay(10U);
    return 0;
}

int CE32_IMU_BMX160_setGyroRange(CE32_IMU_BMX160_handle *handle, eGyroRange_t bits)
{
    uint8_t reg_value;
    float sensitivity;

    if(handle == NULL)
    {
        return -1;
    }

    switch(bits)
    {
        case eGyroRange_125DPS:
            reg_value = BMX160_GYRO_RANGE_125_DPS;
            sensitivity = BMX160_GYRO_SENSITIVITY_125DPS;
            break;
        case eGyroRange_250DPS:
            reg_value = BMX160_GYRO_RANGE_250_DPS;
            sensitivity = BMX160_GYRO_SENSITIVITY_250DPS;
            break;
        case eGyroRange_500DPS:
            reg_value = BMX160_GYRO_RANGE_500_DPS;
            sensitivity = BMX160_GYRO_SENSITIVITY_500DPS;
            break;
        case eGyroRange_1000DPS:
            reg_value = BMX160_GYRO_RANGE_1000_DPS;
            sensitivity = BMX160_GYRO_SENSITIVITY_1000DPS;
            break;
        case eGyroRange_2000DPS:
        default:
            reg_value = BMX160_GYRO_RANGE_2000_DPS;
            sensitivity = BMX160_GYRO_SENSITIVITY_2000DPS;
            break;
    }

    if(XE_NP_BMX160_WriteReg(handle, BMX160_GYRO_RANGE_ADDR, reg_value) != HAL_OK)
    {
        return -2;
    }

    handle->gyroRange = sensitivity;
    return 0;
}

int CE32_IMU_BMX160_setAccelRange(CE32_IMU_BMX160_handle *handle, eAccelRange_t bits)
{
    uint8_t reg_value;
    float scale;

    if(handle == NULL)
    {
        return -1;
    }

    switch(bits)
    {
        case eAccelRange_2G:
            reg_value = BMX160_ACCEL_RANGE_2G;
            scale = BMX160_ACCEL_MG_LSB_2G * 10.0f;
            break;
        case eAccelRange_4G:
            reg_value = BMX160_ACCEL_RANGE_4G;
            scale = BMX160_ACCEL_MG_LSB_4G * 10.0f;
            break;
        case eAccelRange_8G:
            reg_value = BMX160_ACCEL_RANGE_8G;
            scale = BMX160_ACCEL_MG_LSB_8G * 10.0f;
            break;
        case eAccelRange_16G:
            reg_value = BMX160_ACCEL_RANGE_16G;
            scale = BMX160_ACCEL_MG_LSB_16G * 10.0f;
            break;
        default:
            reg_value = BMX160_ACCEL_RANGE_2G;
            scale = BMX160_ACCEL_MG_LSB_2G * 10.0f;
            break;
    }

    if(XE_NP_BMX160_WriteReg(handle, BMX160_ACCEL_RANGE_ADDR, reg_value) != HAL_OK)
    {
        return -2;
    }

    handle->accelRange = scale;
    return 0;
}

int CE32_IMU_BMX160_getAllData(CE32_IMU_BMX160_handle *handle)
{
    uint8_t data[20] = {0};
    int16_t x;
    int16_t y;
    int16_t z;

    if((handle == NULL) || (XE_NP_BMX160_ReadReg(handle, BMX160_MAG_DATA_ADDR, data, sizeof(data)) != HAL_OK))
    {
        return -1;
    }

    x = (int16_t)(((uint16_t)data[1] << 8U) | data[0]);
    y = (int16_t)(((uint16_t)data[3] << 8U) | data[2]);
    z = (int16_t)(((uint16_t)data[5] << 8U) | data[4]);
    handle->Omagn.x = (float)x * BMX160_MAGN_UT_LSB;
    handle->Omagn.y = (float)y * BMX160_MAGN_UT_LSB;
    handle->Omagn.z = (float)z * BMX160_MAGN_UT_LSB;

    x = (int16_t)(((uint16_t)data[9] << 8U) | data[8]);
    y = (int16_t)(((uint16_t)data[11] << 8U) | data[10]);
    z = (int16_t)(((uint16_t)data[13] << 8U) | data[12]);
    handle->Ogyro.x = (float)x * handle->gyroRange;
    handle->Ogyro.y = (float)y * handle->gyroRange;
    handle->Ogyro.z = (float)z * handle->gyroRange;

    x = (int16_t)(((uint16_t)data[15] << 8U) | data[14]);
    y = (int16_t)(((uint16_t)data[17] << 8U) | data[16]);
    z = (int16_t)(((uint16_t)data[19] << 8U) | data[18]);
    handle->Oaccel.x = (float)x * handle->accelRange;
    handle->Oaccel.y = (float)y * handle->accelRange;
    handle->Oaccel.z = (float)z * handle->accelRange;
    return 0;
}

int CE32_IMU_BMX160_startScan(CE32_IMU_BMX160_handle *handle, uint8_t *ptr, uint8_t len)
{
    uint8_t reg;
    uint8_t *target_ptr;
    uint16_t read_len;

    if((handle == NULL) || (handle->hi2c == NULL) || (ptr == NULL) ||
       (handle->state != CE32_BMX160_STATE_READY))
    {
        return -1;
    }

    reg = BMX160_MAG_DATA_ADDR;
    target_ptr = ptr;
    read_len = len;
    if(handle->PMode != PMODE_Normal)
    {
        reg = BMX160_ACCEL_DATA_ADDR;
        if(len >= 20U)
        {
            target_ptr = &ptr[14];
        }
        read_len = 6U;
    }

    handle->data_ptr = ptr;
    handle->RD_addr = reg;
    handle->RD_cnt = (int16_t)len;
    handle->state = CE32_BMX160_STATE_BUSY;
    if(HAL_I2C_Mem_Read_IT(
           handle->hi2c,
           (uint16_t)(BMX160_I2C_ADDR << 1),
           reg,
           I2C_MEMADD_SIZE_8BIT,
           target_ptr,
           read_len) != HAL_OK)
    {
        handle->state = CE32_BMX160_STATE_READY;
        return -2;
    }

    return 0;
}

void CE32_IMU_BMX160_RX_IT_Callback(CE32_IMU_BMX160_handle *handle)
{
    if(handle == NULL)
    {
        return;
    }

    XE_NP_BMX160_CopyRawToValueArray(handle);
    /* Never issue a second blocking I2C read from an IRQ. New sensor service
     * decodes/compensates the completed bytes in the foreground. */
    handle->state = CE32_BMX160_STATE_READY;
    CE32_IMU_RXAct();
}

void CE32_IMU_ReleaseI2C(CE32_IMU_BMX160_handle *handle)
{
    if((handle == NULL) || (handle->GPIO_SCL == NULL) || (handle->GPIO_SDA == NULL))
    {
        return;
    }

    XE_NP_BMX160_InitLine(handle->GPIO_SCL, handle->SCL_Pin, GPIO_MODE_OUTPUT_OD, GPIO_PULLUP);
    if(handle->GPIO_SDA != handle->GPIO_SCL)
    {
        XE_NP_BMX160_InitLine(handle->GPIO_SDA, handle->SDA_Pin, GPIO_MODE_OUTPUT_OD, GPIO_PULLUP);
    }
    else
    {
        XE_NP_BMX160_InitLine(
            handle->GPIO_SDA,
            (uint16_t)(handle->SCL_Pin | handle->SDA_Pin),
            GPIO_MODE_OUTPUT_OD,
            GPIO_PULLUP);
    }

    HAL_GPIO_WritePin(handle->GPIO_SCL, handle->SCL_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(handle->GPIO_SDA, handle->SDA_Pin, GPIO_PIN_SET);
    XE_NP_BMX160_Delay(1U);
    HAL_GPIO_WritePin(handle->GPIO_SDA, handle->SDA_Pin, GPIO_PIN_RESET);
    XE_NP_BMX160_Delay(1U);
    HAL_GPIO_WritePin(handle->GPIO_SCL, handle->SCL_Pin, GPIO_PIN_RESET);
    XE_NP_BMX160_Delay(1U);
    HAL_GPIO_WritePin(handle->GPIO_SCL, handle->SCL_Pin, GPIO_PIN_SET);
    XE_NP_BMX160_Delay(1U);
    HAL_GPIO_WritePin(handle->GPIO_SDA, handle->SDA_Pin, GPIO_PIN_SET);
    XE_NP_BMX160_Delay(1U);

    XE_NP_BMX160_InitLine(handle->GPIO_SCL, handle->SCL_Pin, GPIO_MODE_INPUT, GPIO_PULLUP);
    if(handle->GPIO_SDA != handle->GPIO_SCL)
    {
        XE_NP_BMX160_InitLine(handle->GPIO_SDA, handle->SDA_Pin, GPIO_MODE_INPUT, GPIO_PULLUP);
    }
    else
    {
        XE_NP_BMX160_InitLine(
            handle->GPIO_SDA,
            (uint16_t)(handle->SCL_Pin | handle->SDA_Pin),
            GPIO_MODE_INPUT,
            GPIO_PULLUP);
    }
}

__weak void CE32_IMU_PreInitAct(void)
{
}

__weak void CE32_IMU_RXAct(void)
{
}

void HAL_I2C_ErrorCallback(I2C_HandleTypeDef *hi2c)
{
    if(XE_NP_SensorsPort_Complete(hi2c,hi2c->ErrorCode?hi2c->ErrorCode:1U))return;
    if((ACC_handle.hi2c != NULL) && (hi2c == ACC_handle.hi2c))
    {
        ACC_handle.state = CE32_BMX160_STATE_READY;
    }
}
