D:\Code\XE_NP_V2\_artifacts\v2_ble_cold_start_20261007_build\usb\base_string.o: \
  D:\Code\XE_NP_V2\Core\Src\BASE_string.c \
  D:\Code\XE_NP_V2\Core\Inc\BASE_string.h
