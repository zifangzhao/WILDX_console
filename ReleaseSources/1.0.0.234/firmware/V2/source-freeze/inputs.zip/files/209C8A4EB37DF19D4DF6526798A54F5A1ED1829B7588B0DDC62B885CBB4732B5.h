#ifndef XE_NP_MSC_BOT_H
#define XE_NP_MSC_BOT_H
#include "usbd_msc.h"

/* Hardware-independent adapter around ST BOT/SCSI. All protocol/media work
 * runs in foreground. HAL IRQ callbacks only enqueue completion flags. */
typedef struct {
    int (*transmit)(void *, const uint8_t *, uint32_t);
    int (*receive)(void *, uint8_t *, uint32_t);
    void (*stall)(void *, uint8_t);
    void (*clear_stall)(void *, uint8_t);
    void (*flush)(void *, uint8_t);
    int (*ready)(void *);
    uint32_t (*capacity)(void *);
    int (*write_protected)(void *);
    int (*read)(void *, uint8_t *, uint32_t, uint32_t);
    int (*write)(void *, const uint8_t *, uint32_t, uint32_t);
    int (*sync)(void *);
    int (*control)(void *, uint8_t, uint8_t *, uint32_t *);
    void (*mode_ack)(void *);
} XE_NP_MscOps;

typedef struct {
    USBD_HandleTypeDef device;
    USBD_MSC_BOT_HandleTypeDef bot;
    const XE_NP_MscOps *ops;
    void *context;
    /* A malformed OUT packet must never DMA/FIFO-write beyond the 32-byte CBW.
     * Receive into a full-size hardware buffer, then validate before copying. */
    _Alignas(32) uint8_t rx_scratch[MSC_MEDIA_PACKET];
    uint8_t *rx_destination;
    uint32_t rx_expected, rx_received;
    uint32_t commands, errors;
    uint8_t configured, reset_required, reset_seen, clear_mask, tx_is_csw;
    uint8_t tx_pending, rx_deferred, rx_armed;
    uint8_t mode_pending, halt_mask;
} XE_NP_MscBot;

void XE_NP_MscBot_Init(XE_NP_MscBot *, const XE_NP_MscOps *, void *);
void XE_NP_MscBot_Configure(XE_NP_MscBot *);
void XE_NP_MscBot_Receive(XE_NP_MscBot *, uint32_t bytes);
void XE_NP_MscBot_TransmitDone(XE_NP_MscBot *);
void XE_NP_MscBot_ClassReset(XE_NP_MscBot *);
void XE_NP_MscBot_ClearHalt(XE_NP_MscBot *, uint8_t endpoint);
int8_t XE_NP_MscScsiExtension(USBD_HandleTypeDef *, uint8_t lun, uint8_t *cdb);
#endif
