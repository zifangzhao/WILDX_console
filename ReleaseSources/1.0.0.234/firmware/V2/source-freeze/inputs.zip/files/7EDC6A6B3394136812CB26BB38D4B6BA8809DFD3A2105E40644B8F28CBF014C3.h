#ifndef XE_NP_USBD_CONF_H
#define XE_NP_USBD_CONF_H
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#ifndef __STATIC_INLINE
#define __STATIC_INLINE static inline
#endif
#ifndef __IO
#define __IO volatile
#endif
#ifdef _MSC_VER
#define __PACKED_STRUCT struct
#define __packed
#define __PACKED
#else
#ifndef __PACKED
#define __PACKED __attribute__((packed))
#endif
#ifndef __PACKED_STRUCT
#define __PACKED_STRUCT struct __attribute__((packed))
#endif
#ifndef __packed
#define __packed __attribute__((packed))
#endif
#endif
#define USBD_MAX_NUM_INTERFACES 1U
#define USBD_MAX_NUM_CONFIGURATION 1U
#define USBD_MAX_SUPPORTED_CLASS 1U
#define USBD_MAX_STR_DESC_SIZ 128U
#define USBD_SELF_POWERED 0U
#define USBD_LPM_ENABLED 0U
#define USBD_DEBUG_LEVEL 0U
#define MSC_MEDIA_PACKET 32768U
#define MSC_BOT_MAX_LUN 1U
#define USBD_memset memset
#define USBD_memcpy memcpy
#define USBD_UsrLog(...) ((void)0)
#define USBD_ErrLog(...) ((void)0)
#define USBD_DbgLog(...) ((void)0)
#ifndef UNUSED
#define UNUSED(x) ((void)(x))
#endif
#endif
