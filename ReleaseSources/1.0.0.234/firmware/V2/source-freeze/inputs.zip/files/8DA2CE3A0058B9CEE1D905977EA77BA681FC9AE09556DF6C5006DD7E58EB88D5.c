#include "HD32_SD_driver.h"

#include "main.h"
#include "xe_np_board.h"

extern SD_HandleTypeDef hsd1;
extern uint8_t xe_np_sd_init_failed;

#define XE_NP_LEGACY_SD_DCACHE_LINE_BYTES 32U
#define XE_NP_LEGACY_SD_IRQ_PREEMPT_PRIO 1U
#define XE_NP_LEGACY_SD_IRQ_SUBPRIO 0U

typedef struct
{
    SD_HandleTypeDef *hsd;
    volatile uint8_t write_in_flight;
    volatile uint8_t write_dma_done;
    volatile uint8_t write_complete;
    volatile uint8_t write_error;
    volatile uint8_t read_in_flight;
    volatile uint8_t read_dma_done;
    volatile uint8_t read_complete;
    volatile uint8_t read_error;
    volatile uint32_t next_block;
    volatile uint32_t next_block_after_write;
} XE_NP_LegacySdState;

static XE_NP_LegacySdState xe_np_legacy_sd = {0};
XE_NP_SD_DMA_CompatTypeDef xe_np_legacy_sd_dma_compat = {0};
volatile HD32_SDDiag hd32_sd_diag = {
    HD32_SD_DIAG_MAGIC,
    HD32_SD_DIAG_VERSION,
    0U,
    HD32_SD_DIAG_OP_NONE,
    HD32_SD_DIAG_STAGE_IDLE,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
};

#define XE_NP_LEGACY_SD_TIMEOUT_MS 1000U
#define XE_NP_LEGACY_SD_RECOVER_TIMEOUT_MS 200U

static void XE_NP_LegacySd_ResetHostDataPath(void)
{
    if((xe_np_legacy_sd.hsd == NULL) || (xe_np_legacy_sd.hsd->Instance == NULL))
    {
        return;
    }

    __HAL_SD_DISABLE_IT(xe_np_legacy_sd.hsd,
                        SDMMC_IT_DATAEND | SDMMC_IT_DCRCFAIL | SDMMC_IT_DTIMEOUT |
                        SDMMC_IT_TXUNDERR | SDMMC_IT_RXOVERR);
    __SDMMC_CMDTRANS_DISABLE(xe_np_legacy_sd.hsd->Instance);
    xe_np_legacy_sd.hsd->Instance->IDMACTRL = SDMMC_DISABLE_IDMA;
    xe_np_legacy_sd.hsd->Instance->DLEN = 0U;
    xe_np_legacy_sd.hsd->Instance->DCTRL |= SDMMC_DCTRL_FIFORST;
    xe_np_legacy_sd.hsd->Instance->DCTRL = 0U;
    __HAL_SD_CLEAR_FLAG(xe_np_legacy_sd.hsd, SDMMC_FLAG_BUSYD0END);
    __HAL_SD_CLEAR_FLAG(xe_np_legacy_sd.hsd, SDMMC_STATIC_DATA_FLAGS);
}

static void XE_NP_LegacySd_EnableIrq(void)
{
    HAL_NVIC_SetPriority(SDMMC1_IRQn, XE_NP_LEGACY_SD_IRQ_PREEMPT_PRIO, XE_NP_LEGACY_SD_IRQ_SUBPRIO);
    HAL_NVIC_EnableIRQ(SDMMC1_IRQn);
}

static void HD32_SD_RecordDiag(
    uint32_t op,
    uint32_t stage,
    uint32_t addr,
    uint32_t block_count,
    HAL_StatusTypeDef hal_status)
{
    hd32_sd_diag.magic = HD32_SD_DIAG_MAGIC;
    hd32_sd_diag.version = HD32_SD_DIAG_VERSION;
    hd32_sd_diag.tick_ms = HAL_GetTick();
    hd32_sd_diag.op = op;
    hd32_sd_diag.stage = stage;
    hd32_sd_diag.addr = addr;
    hd32_sd_diag.block_count = block_count;
    hd32_sd_diag.hal_status = (uint32_t)hal_status;
    hd32_sd_diag.error_code =
        (xe_np_legacy_sd.hsd != NULL) ? xe_np_legacy_sd.hsd->ErrorCode : 0U;
    hd32_sd_diag.card_state_after =
        (xe_np_legacy_sd.hsd != NULL) ? (uint32_t)HAL_SD_GetCardState(xe_np_legacy_sd.hsd) : 0U;
    hd32_sd_diag.write_flags =
        ((uint32_t)xe_np_legacy_sd.write_in_flight) |
        ((uint32_t)xe_np_legacy_sd.write_dma_done << 8U) |
        ((uint32_t)xe_np_legacy_sd.write_complete << 16U) |
        ((uint32_t)xe_np_legacy_sd.write_error << 24U) |
        ((uint32_t)xe_np_legacy_sd.read_in_flight << 4U) |
        ((uint32_t)xe_np_legacy_sd.read_dma_done << 12U) |
        ((uint32_t)xe_np_legacy_sd.read_complete << 20U) |
        ((uint32_t)xe_np_legacy_sd.read_error << 28U);
    hd32_sd_diag.hal_state =
        (xe_np_legacy_sd.hsd != NULL) ? (uint32_t)xe_np_legacy_sd.hsd->State : 0U;
    hd32_sd_diag.hal_context =
        (xe_np_legacy_sd.hsd != NULL) ? xe_np_legacy_sd.hsd->Context : 0U;
    hd32_sd_diag.sdmmc_sta =
        (xe_np_legacy_sd.hsd != NULL) ? xe_np_legacy_sd.hsd->Instance->STA : 0U;
    hd32_sd_diag.sdmmc_dctrl =
        (xe_np_legacy_sd.hsd != NULL) ? xe_np_legacy_sd.hsd->Instance->DCTRL : 0U;
}

static void XE_NP_LegacySd_DCachePrepare(void *addr, uint32_t size_bytes)
{
#if defined(__DCACHE_PRESENT) && (__DCACHE_PRESENT == 1U)
    uintptr_t start_addr;
    uintptr_t end_addr;

    if((addr == NULL) || (size_bytes == 0U))
    {
        return;
    }

    start_addr = ((uintptr_t)addr) & ~((uintptr_t)XE_NP_LEGACY_SD_DCACHE_LINE_BYTES - 1U);
    end_addr = (((uintptr_t)addr) + (uintptr_t)size_bytes +
                (XE_NP_LEGACY_SD_DCACHE_LINE_BYTES - 1U)) &
               ~((uintptr_t)XE_NP_LEGACY_SD_DCACHE_LINE_BYTES - 1U);
    SCB_CleanInvalidateDCache_by_Addr((void *)start_addr, (int32_t)(end_addr - start_addr));
#else
    (void)addr;
    (void)size_bytes;
#endif
}

static void XE_NP_LegacySd_DCacheClean(const void *addr, uint32_t size_bytes)
{
#if defined(__DCACHE_PRESENT) && (__DCACHE_PRESENT == 1U)
    uintptr_t start_addr;
    uintptr_t end_addr;

    if((addr == NULL) || (size_bytes == 0U))
    {
        return;
    }

    start_addr = ((uintptr_t)addr) & ~((uintptr_t)XE_NP_LEGACY_SD_DCACHE_LINE_BYTES - 1U);
    end_addr = (((uintptr_t)addr) + (uintptr_t)size_bytes +
                (XE_NP_LEGACY_SD_DCACHE_LINE_BYTES - 1U)) &
               ~((uintptr_t)XE_NP_LEGACY_SD_DCACHE_LINE_BYTES - 1U);
    SCB_CleanDCache_by_Addr((void *)start_addr, (int32_t)(end_addr - start_addr));
#else
    (void)addr;
    (void)size_bytes;
#endif
}

static void XE_NP_LegacySd_DCacheInvalidate(const void *addr, uint32_t size_bytes)
{
#if defined(__DCACHE_PRESENT) && (__DCACHE_PRESENT == 1U)
    uintptr_t start_addr;
    uintptr_t end_addr;

    if((addr == NULL) || (size_bytes == 0U))
    {
        return;
    }

    start_addr = ((uintptr_t)addr) & ~((uintptr_t)XE_NP_LEGACY_SD_DCACHE_LINE_BYTES - 1U);
    end_addr = (((uintptr_t)addr) + (uintptr_t)size_bytes +
                (XE_NP_LEGACY_SD_DCACHE_LINE_BYTES - 1U)) &
               ~((uintptr_t)XE_NP_LEGACY_SD_DCACHE_LINE_BYTES - 1U);
    SCB_InvalidateDCache_by_Addr((void *)start_addr, (int32_t)(end_addr - start_addr));
#else
    (void)addr;
    (void)size_bytes;
#endif
}

static int XE_NP_LegacySd_EnsureReady(void)
{
    XE_NP_Board_EnsureSdPowerRail();

    if(xe_np_legacy_sd.hsd == NULL)
    {
        xe_np_legacy_sd.hsd = &hsd1;
    }

    if(xe_np_sd_init_failed != 0U)
    {
        return -1;
    }

    if((xe_np_legacy_sd.hsd == NULL) || (HAL_SD_GetCardState(xe_np_legacy_sd.hsd) == HAL_SD_CARD_ERROR))
    {
        return -1;
    }

    XE_NP_LegacySd_EnableIrq();
    return 0;
}

static int XE_NP_LegacySd_ForceStopDataPath(void)
{
    uint32_t start_tick;
    uint32_t card_state;
    uint32_t stop_error = HAL_SD_ERROR_NONE;
    uint32_t sdmmc_irq_was_enabled;

    if((xe_np_legacy_sd.hsd == NULL) || (xe_np_legacy_sd.hsd->Instance == NULL))
    {
        hd32_sd_diag.recover_last_status = 0xFFFFFFFFUL;
        return -1;
    }

    sdmmc_irq_was_enabled = NVIC_GetEnableIRQ(SDMMC1_IRQn);
    HAL_NVIC_DisableIRQ(SDMMC1_IRQn);

    card_state = (uint32_t)HAL_SD_GetCardState(xe_np_legacy_sd.hsd);
    XE_NP_LegacySd_ResetHostDataPath();

    if((card_state == HAL_SD_CARD_RECEIVING) || (card_state == HAL_SD_CARD_SENDING))
    {
        stop_error = SDMMC_CmdStopTransfer(xe_np_legacy_sd.hsd->Instance);
        if((stop_error != HAL_SD_ERROR_NONE) && (stop_error != HAL_SD_ERROR_CMD_RSP_TIMEOUT))
        {
            xe_np_legacy_sd.hsd->ErrorCode |= stop_error;
        }
    }

    XE_NP_LegacySd_ResetHostDataPath();

    xe_np_legacy_sd.hsd->State = HAL_SD_STATE_READY;
    xe_np_legacy_sd.hsd->Context = SD_CONTEXT_NONE;
    xe_np_legacy_sd.write_in_flight = 0U;
    xe_np_legacy_sd.write_dma_done = 0U;
    xe_np_legacy_sd.write_complete = 0U;
    xe_np_legacy_sd.write_error = 0U;
    xe_np_legacy_sd.read_in_flight = 0U;
    xe_np_legacy_sd.read_dma_done = 0U;
    xe_np_legacy_sd.read_complete = 0U;
    xe_np_legacy_sd.read_error = 0U;
    xe_np_legacy_sd_dma_compat.NDTR = 0U;

    start_tick = HAL_GetTick();
    do
    {
        card_state = (uint32_t)HAL_SD_GetCardState(xe_np_legacy_sd.hsd);
        if((card_state == HAL_SD_CARD_TRANSFER) &&
           ((xe_np_legacy_sd.hsd->Instance->STA & SDMMC_FLAG_DPSMACT) == 0U))
        {
            hd32_sd_diag.recover_count++;
            hd32_sd_diag.recover_last_status = stop_error;
            if(sdmmc_irq_was_enabled != 0U)
            {
                HAL_NVIC_EnableIRQ(SDMMC1_IRQn);
            }
            return 0;
        }
    } while((HAL_GetTick() - start_tick) < XE_NP_LEGACY_SD_RECOVER_TIMEOUT_MS);

    hd32_sd_diag.recover_count++;
    hd32_sd_diag.recover_last_status = stop_error | (card_state << 16U);
    if(sdmmc_irq_was_enabled != 0U)
    {
        HAL_NVIC_EnableIRQ(SDMMC1_IRQn);
    }
    return -1;
}

static int XE_NP_LegacySd_WaitCardTransfer(void)
{
    uint32_t start_tick = HAL_GetTick();
    uint8_t recover_attempted = 0U;
    uint32_t card_state;
    uint32_t host_active;

    if(XE_NP_LegacySd_EnsureReady() != 0)
    {
        return -1;
    }

    while(1)
    {
        card_state = (uint32_t)HAL_SD_GetCardState(xe_np_legacy_sd.hsd);
        host_active = xe_np_legacy_sd.hsd->Instance->STA & SDMMC_FLAG_DPSMACT;
        if(card_state == HAL_SD_CARD_TRANSFER)
        {
            if((host_active != 0U) &&
               (xe_np_legacy_sd.hsd->State == HAL_SD_STATE_READY) &&
               (xe_np_legacy_sd.hsd->Context == SD_CONTEXT_NONE) &&
               (xe_np_legacy_sd.write_in_flight == 0U) &&
               (xe_np_legacy_sd.read_in_flight == 0U))
            {
                hd32_sd_diag.recover_count++;
                hd32_sd_diag.recover_last_status = 0xB5000000UL | host_active;
            }
            return 0;
        }

        if((recover_attempted == 0U) &&
           ((card_state == HAL_SD_CARD_RECEIVING) ||
            (card_state == HAL_SD_CARD_SENDING) ||
            ((host_active != 0U) && (xe_np_legacy_sd.hsd->State != HAL_SD_STATE_READY))))
        {
            if(XE_NP_LegacySd_ForceStopDataPath() == 0)
            {
                return 0;
            }
            recover_attempted = 1U;
        }

        if((HAL_GetTick() - start_tick) >= XE_NP_LEGACY_SD_TIMEOUT_MS)
        {
            return -1;
        }
    }

    return 0;
}

static int XE_NP_LegacySd_StartWriteDma(uint32_t addr, uint8_t *data, uint32_t block_count)
{
    if((data == NULL) || (block_count == 0U) || (XE_NP_LegacySd_WaitCardTransfer() != 0))
    {
        HD32_SD_RecordDiag(
            HD32_SD_DIAG_OP_WRITE_DMA,
            HD32_SD_DIAG_STAGE_ENSURE_FAIL,
            addr,
            block_count,
            HAL_ERROR);
        return -1;
    }

    XE_NP_LegacySd_DCacheClean(data, block_count * 512U);
    /*
     * Publish in-flight state before starting HAL SD DMA so a fast completion
     * callback cannot race ahead of the bookkeeping and get lost.
     */
    xe_np_legacy_sd.write_complete = 0U;
    xe_np_legacy_sd.write_error = 0U;
    xe_np_legacy_sd.write_in_flight = 1U;
    xe_np_legacy_sd.write_dma_done = 0U;
    xe_np_legacy_sd.next_block = addr;
    xe_np_legacy_sd.next_block_after_write = addr + block_count;
    xe_np_legacy_sd_dma_compat.NDTR = 1U;
    XE_NP_LegacySd_EnableIrq();
    if(HAL_SD_WriteBlocks_DMA(xe_np_legacy_sd.hsd, data, addr, block_count) != HAL_OK)
    {
        (void)XE_NP_LegacySd_ForceStopDataPath();
        xe_np_legacy_sd.write_in_flight = 0U;
        xe_np_legacy_sd.write_dma_done = 0U;
        xe_np_legacy_sd.write_complete = 0U;
        xe_np_legacy_sd.write_error = 0U;
        xe_np_legacy_sd_dma_compat.NDTR = 0U;
        HD32_SD_RecordDiag(
            HD32_SD_DIAG_OP_WRITE_DMA,
            HD32_SD_DIAG_STAGE_HAL_FAIL,
            addr,
            block_count,
            HAL_ERROR);
        return -1;
    }
    return 0;
}

static int XE_NP_LegacySd_StartReadDma(uint32_t addr, uint8_t *data, uint32_t block_count)
{
    if((data == NULL) || (block_count == 0U) || (XE_NP_LegacySd_WaitCardTransfer() != 0))
    {
        HD32_SD_RecordDiag(
            HD32_SD_DIAG_OP_READ_SINGLE,
            HD32_SD_DIAG_STAGE_ENSURE_FAIL,
            addr,
            block_count,
            HAL_ERROR);
        return -1;
    }

    XE_NP_LegacySd_DCachePrepare(data, block_count * 512U);
    xe_np_legacy_sd.read_complete = 0U;
    xe_np_legacy_sd.read_error = 0U;
    xe_np_legacy_sd.read_in_flight = 1U;
    xe_np_legacy_sd.read_dma_done = 0U;
    XE_NP_LegacySd_EnableIrq();
    if(HAL_SD_ReadBlocks_DMA(xe_np_legacy_sd.hsd, data, addr, block_count) != HAL_OK)
    {
        (void)XE_NP_LegacySd_ForceStopDataPath();
        xe_np_legacy_sd.read_in_flight = 0U;
        xe_np_legacy_sd.read_dma_done = 0U;
        xe_np_legacy_sd.read_complete = 0U;
        xe_np_legacy_sd.read_error = 0U;
        HD32_SD_RecordDiag(
            HD32_SD_DIAG_OP_READ_SINGLE,
            HD32_SD_DIAG_STAGE_HAL_FAIL,
            addr,
            block_count,
            HAL_ERROR);
        return -1;
    }
    return 0;
}

static void XE_NP_LegacySd_ServiceCompletion(void)
{
    if(xe_np_legacy_sd.hsd == NULL)
    {
        return;
    }

    if((xe_np_legacy_sd.write_in_flight != 0U) &&
       (xe_np_legacy_sd.write_dma_done != 0U) &&
       (xe_np_legacy_sd.write_complete == 0U) &&
       (xe_np_legacy_sd.write_error == 0U) &&
       (HAL_SD_GetCardState(xe_np_legacy_sd.hsd) == HAL_SD_CARD_TRANSFER))
    {
        /*
         * The HAL SD TX callback fires after the SDMMC/IDMA DATAEND path has
         * completed, but the card can still be internally programming. Only
         * publish the legacy completion edge once both have happened: SDMMC is
         * done (write_dma_done) and the card reports TRANSFER state.
         */
        xe_np_legacy_sd.write_complete = 1U;
        xe_np_legacy_sd_dma_compat.NDTR = 0U;
    }

    if((xe_np_legacy_sd.read_in_flight != 0U) &&
       (xe_np_legacy_sd.read_dma_done != 0U) &&
       (xe_np_legacy_sd.read_complete == 0U) &&
       (xe_np_legacy_sd.read_error == 0U) &&
       (HAL_SD_GetCardState(xe_np_legacy_sd.hsd) == HAL_SD_CARD_TRANSFER))
    {
        xe_np_legacy_sd.read_complete = 1U;
    }
}

static int XE_NP_LegacySd_WaitWriteDmaComplete(uint32_t timeout_ms)
{
    uint32_t start_tick = HAL_GetTick();

    while(1)
    {
        XE_NP_LegacySd_ServiceCompletion();

        if(xe_np_legacy_sd.write_error != 0U)
        {
            (void)XE_NP_LegacySd_ForceStopDataPath();
            return -1;
        }

        if(xe_np_legacy_sd.write_complete != 0U)
        {
            xe_np_legacy_sd.write_in_flight = 0U;
            xe_np_legacy_sd.write_dma_done = 0U;
            xe_np_legacy_sd.write_complete = 0U;
            xe_np_legacy_sd.write_error = 0U;
            xe_np_legacy_sd.next_block = xe_np_legacy_sd.next_block_after_write;
            xe_np_legacy_sd_dma_compat.NDTR = 0U;
            return 0;
        }

        if((HAL_GetTick() - start_tick) >= timeout_ms)
        {
            (void)XE_NP_LegacySd_ForceStopDataPath();
            return -1;
        }
    }
}

static int XE_NP_LegacySd_WaitReadDmaComplete(void *data, uint32_t size_bytes, uint32_t timeout_ms)
{
    uint32_t start_tick = HAL_GetTick();

    while(1)
    {
        XE_NP_LegacySd_ServiceCompletion();

        if(xe_np_legacy_sd.read_error != 0U)
        {
            (void)XE_NP_LegacySd_ForceStopDataPath();
            return -1;
        }

        if(xe_np_legacy_sd.read_complete != 0U)
        {
            xe_np_legacy_sd.read_in_flight = 0U;
            xe_np_legacy_sd.read_dma_done = 0U;
            xe_np_legacy_sd.read_complete = 0U;
            xe_np_legacy_sd.read_error = 0U;
            XE_NP_LegacySd_DCacheInvalidate(data, size_bytes);
            return 0;
        }

        if((HAL_GetTick() - start_tick) >= timeout_ms)
        {
            (void)XE_NP_LegacySd_ForceStopDataPath();
            return -1;
        }
    }
}

int HD32_SD_init(SPI_HandleTypeDef *hspi)
{
    (void)hspi;
    xe_np_legacy_sd.hsd = &hsd1;
    xe_np_legacy_sd.write_in_flight = 0U;
    xe_np_legacy_sd.write_dma_done = 0U;
    xe_np_legacy_sd.write_complete = 0U;
    xe_np_legacy_sd.write_error = 0U;
    xe_np_legacy_sd.read_in_flight = 0U;
    xe_np_legacy_sd.read_dma_done = 0U;
    xe_np_legacy_sd.read_complete = 0U;
    xe_np_legacy_sd.read_error = 0U;
    xe_np_legacy_sd.next_block = 0U;
    xe_np_legacy_sd.next_block_after_write = 0U;
    XE_NP_LegacySd_EnableIrq();
    return XE_NP_LegacySd_EnsureReady();
}

int HD32_SD_readCSD(SPI_HandleTypeDef *hspi, CE32_systemParam *sys)
{
    HAL_SD_CardInfoTypeDef card_info;

    (void)hspi;
    XE_NP_Board_EnsureSdPowerRail();
    if((sys == NULL) || (XE_NP_LegacySd_WaitCardTransfer() != 0))
    {
        return -1;
    }

    if(HAL_SD_GetCardInfo(xe_np_legacy_sd.hsd, &card_info) != HAL_OK)
    {
        return -1;
    }

    sys->SD_capacity = card_info.LogBlockNbr;
    return 0;
}

int HD32_SD_writeBlock(uint32_t addr)
{
    XE_NP_Board_EnsureSdPowerRail();

    if(XE_NP_LegacySd_EnsureReady() != 0)
    {
        return -1;
    }

    xe_np_legacy_sd.next_block = addr;
    xe_np_legacy_sd.next_block_after_write = addr;
    return 0;
}

int HD32_SD_writeSingleBlock(uint32_t addr, uint8_t *data)
{
    XE_NP_Board_EnsureSdPowerRail();
    HD32_SD_RecordDiag(
        HD32_SD_DIAG_OP_WRITE_SINGLE,
        HD32_SD_DIAG_STAGE_ENTER,
        addr,
        1U,
        HAL_OK);
    if((data == NULL) || (XE_NP_LegacySd_WaitCardTransfer() != 0))
    {
        HD32_SD_RecordDiag(
            HD32_SD_DIAG_OP_WRITE_SINGLE,
            HD32_SD_DIAG_STAGE_ENSURE_FAIL,
            addr,
            1U,
            HAL_ERROR);
        return -1;
    }

    hd32_sd_diag.card_state_before = (uint32_t)HAL_SD_GetCardState(xe_np_legacy_sd.hsd);
    if(XE_NP_LegacySd_StartWriteDma(addr, data, 1U) != 0)
    {
        HD32_SD_RecordDiag(
            HD32_SD_DIAG_OP_WRITE_SINGLE,
            HD32_SD_DIAG_STAGE_HAL_FAIL,
            addr,
            1U,
            HAL_ERROR);
        return -1;
    }

    if(XE_NP_LegacySd_WaitWriteDmaComplete(XE_NP_LEGACY_SD_TIMEOUT_MS) != 0)
    {
        HD32_SD_RecordDiag(
            HD32_SD_DIAG_OP_WRITE_SINGLE,
            HD32_SD_DIAG_STAGE_WAIT_FAIL,
            addr,
            1U,
            HAL_TIMEOUT);
        return -1;
    }

    hd32_sd_diag.card_state_after = (uint32_t)HAL_SD_GetCardState(xe_np_legacy_sd.hsd);
    HD32_SD_RecordDiag(
        HD32_SD_DIAG_OP_WRITE_SINGLE,
        HD32_SD_DIAG_STAGE_OK,
        addr,
        1U,
        HAL_OK);
    return 0;
}

int HD32_SD_writeSingleBlock_DMA(uint32_t addr, uint8_t *data)
{
    return XE_NP_LegacySd_StartWriteDma(addr, data, 1U);
}

int HD32_SD_write_DMA(uint8_t *data, uint16_t size)
{
    uint32_t block_count;

    XE_NP_Board_EnsureSdPowerRail();
    if((data == NULL) || ((size % 512U) != 0U))
    {
        return -1;
    }

    block_count = (uint32_t)size / 512U;
    return XE_NP_LegacySd_StartWriteDma(xe_np_legacy_sd.next_block, data, block_count);
}

int HD32_SD_writeBlock_DMA_Check(void)
{
    XE_NP_Board_EnsureSdPowerRail();
    XE_NP_LegacySd_ServiceCompletion();

    if(xe_np_legacy_sd.write_error != 0U)
    {
        xe_np_legacy_sd.write_in_flight = 0U;
        xe_np_legacy_sd.write_dma_done = 0U;
        xe_np_legacy_sd.write_complete = 0U;
        xe_np_legacy_sd.write_error = 0U;
        return -1;
    }

    if(xe_np_legacy_sd.write_in_flight == 0U)
    {
        return 0;
    }

    if(xe_np_legacy_sd.write_complete == 0U)
    {
        /*
         * XE_NP promotes evt_transOK only after the U5 shim has observed both
         * SDMMC DMA completion and card TRANSFER state via HD32_SD_Service().
         * Keep this check non-blocking so the CE64 scheduler never spins here
         * and starves Neuropixels DMA/recorder servicing under high raw load.
         */
        return -1;
    }

    xe_np_legacy_sd.write_in_flight = 0U;
    xe_np_legacy_sd.write_dma_done = 0U;
    xe_np_legacy_sd.write_complete = 0U;
    xe_np_legacy_sd.next_block = xe_np_legacy_sd.next_block_after_write;
    return 0;
}

int HD32_SD_readSingleBlock(uint32_t addr, uint8_t *data)
{
    XE_NP_Board_EnsureSdPowerRail();
    HD32_SD_RecordDiag(
        HD32_SD_DIAG_OP_READ_SINGLE,
        HD32_SD_DIAG_STAGE_ENTER,
        addr,
        1U,
        HAL_OK);
    if((data == NULL) || (XE_NP_LegacySd_WaitCardTransfer() != 0))
    {
        HD32_SD_RecordDiag(
            HD32_SD_DIAG_OP_READ_SINGLE,
            HD32_SD_DIAG_STAGE_ENSURE_FAIL,
            addr,
            1U,
            HAL_ERROR);
        return -1;
    }

    hd32_sd_diag.card_state_before = (uint32_t)HAL_SD_GetCardState(xe_np_legacy_sd.hsd);
    if(XE_NP_LegacySd_StartReadDma(addr, data, 1U) != 0)
    {
        HD32_SD_RecordDiag(
            HD32_SD_DIAG_OP_READ_SINGLE,
            HD32_SD_DIAG_STAGE_HAL_FAIL,
            addr,
            1U,
            HAL_ERROR);
        return -1;
    }

    if(XE_NP_LegacySd_WaitReadDmaComplete(data, 512U, XE_NP_LEGACY_SD_TIMEOUT_MS) != 0)
    {
        HD32_SD_RecordDiag(
            HD32_SD_DIAG_OP_READ_SINGLE,
            HD32_SD_DIAG_STAGE_WAIT_FAIL,
            addr,
            1U,
            HAL_TIMEOUT);
        return -1;
    }

    hd32_sd_diag.card_state_after = (uint32_t)HAL_SD_GetCardState(xe_np_legacy_sd.hsd);
    HD32_SD_RecordDiag(
        HD32_SD_DIAG_OP_READ_SINGLE,
        HD32_SD_DIAG_STAGE_OK,
        addr,
        1U,
        HAL_OK);
    return 0;
}

int HD32_SD_preErase(uint32_t blkNum)
{
    (void)blkNum;
    /*
     * SDMMC HAL does not expose the old SPI CMD23-style pre-erase control at
     * this layer. Keep the API for CE64 filesystem compatibility and treat it
     * as an optional hint.
     */
    return 0;
}

int HD32_SD_stopTrans(void)
{
    XE_NP_Board_EnsureSdPowerRail();

    if(xe_np_legacy_sd.hsd == NULL)
    {
        return 0;
    }

    if((xe_np_legacy_sd.write_in_flight != 0U) || (xe_np_legacy_sd.read_in_flight != 0U))
    {
        (void)XE_NP_LegacySd_ForceStopDataPath();
    }

    xe_np_legacy_sd.write_in_flight = 0U;
    xe_np_legacy_sd.write_dma_done = 0U;
    xe_np_legacy_sd.write_complete = 0U;
    xe_np_legacy_sd.write_error = 0U;
    xe_np_legacy_sd.read_in_flight = 0U;
    xe_np_legacy_sd.read_dma_done = 0U;
    xe_np_legacy_sd.read_complete = 0U;
    xe_np_legacy_sd.read_error = 0U;
    xe_np_legacy_sd_dma_compat.NDTR = 0U;
    return 0;
}

int HD32_SD_DMAStillBusy(void)
{
    XE_NP_Board_EnsureSdPowerRail();
    XE_NP_LegacySd_ServiceCompletion();
    return ((xe_np_legacy_sd.write_in_flight != 0U) || (xe_np_legacy_sd.read_in_flight != 0U)) ? 1 : 0;
}

void HD32_SD_Service(void)
{
    XE_NP_Board_EnsureSdPowerRail();
    XE_NP_LegacySd_ServiceCompletion();
}

void HD32_SD_TxCpltCallback(SD_HandleTypeDef *hsd)
{
    if((hsd == xe_np_legacy_sd.hsd) && (xe_np_legacy_sd.write_in_flight != 0U))
    {
        /*
         * HAL SD TX complete means the DMA/FIFO path is drained, not
         * necessarily that the card has finished the write/program step. Keep
         * the legacy completion edge tied to card-transfer readiness so the
         * CE64 filesystem does not enter TransOK early and block the main loop
         * waiting for the card state to settle.
         */
        xe_np_legacy_sd.write_dma_done = 1U;
        if(HAL_SD_GetCardState(hsd) == HAL_SD_CARD_TRANSFER)
        {
            xe_np_legacy_sd.write_complete = 1U;
            xe_np_legacy_sd_dma_compat.NDTR = 0U;
        }
    }
}

void HD32_SD_RxCpltCallback(SD_HandleTypeDef *hsd)
{
    if((hsd == xe_np_legacy_sd.hsd) && (xe_np_legacy_sd.read_in_flight != 0U))
    {
        xe_np_legacy_sd.read_dma_done = 1U;
        if(HAL_SD_GetCardState(hsd) == HAL_SD_CARD_TRANSFER)
        {
            xe_np_legacy_sd.read_complete = 1U;
        }
    }
}

void HD32_SD_ErrorCallback(SD_HandleTypeDef *hsd)
{
    if((hsd == xe_np_legacy_sd.hsd) && (xe_np_legacy_sd.write_in_flight != 0U))
    {
        xe_np_legacy_sd.write_error = 1U;
        xe_np_legacy_sd_dma_compat.NDTR = 0U;
    }
    if((hsd == xe_np_legacy_sd.hsd) && (xe_np_legacy_sd.read_in_flight != 0U))
    {
        xe_np_legacy_sd.read_error = 1U;
    }
}
