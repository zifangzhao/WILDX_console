#include "xe_np_ep81_fault_snapshot.h"
#if XE_NP_EP81_FAULT_SNAPSHOT
#include <stddef.h>
#include <string.h>
#ifndef XE_NP_EP81_READ
#define XE_NP_EP81_READ(reg) (reg)
#endif
volatile XE_NP_Ep81FaultSnapshot xe_np_ep81_fault_snapshot;
void XE_NP_Ep81Fault_Reset(void)
{memset((void *)&xe_np_ep81_fault_snapshot,0,sizeof(xe_np_ep81_fault_snapshot));}
void XE_NP_Ep81Fault_Capture(const XE_NP_Ep81FaultSoft *soft,const PCD_HandleTypeDef *pcd)
{
    uint32_t key=__get_PRIMASK(),flags=0U,rcc;
    const USB_OTG_GlobalTypeDef *core;
    const USB_OTG_DeviceTypeDef *dev;
    const USB_OTG_INEndpointTypeDef *ep;
    __disable_irq();
    if(xe_np_ep81_fault_snapshot.attempted){__set_PRIMASK(key);return;}
    if(soft){xe_np_ep81_fault_snapshot.soft=*soft;flags|=XE_NP_EP81_SOFT_VALID;}
    else flags|=XE_NP_EP81_NULL_SOFT;
    rcc=XE_NP_EP81_READ(RCC->AHB2ENR1);xe_np_ep81_fault_snapshot.rcc_ahb2enr1=rcc;
    if(!pcd)flags|=XE_NP_EP81_NULL_PCD;
    else if(pcd->Instance!=USB_OTG_HS)flags|=XE_NP_EP81_WRONG_INSTANCE;
    else if(!(rcc&RCC_AHB2ENR1_OTGEN))flags|=XE_NP_EP81_CLOCK_OFF;
    else{
        core=pcd->Instance;
        dev=(const USB_OTG_DeviceTypeDef *)((uintptr_t)core+USB_OTG_DEVICE_BASE);
        ep=(const USB_OTG_INEndpointTypeDef *)((uintptr_t)core+USB_OTG_IN_ENDPOINT_BASE+USB_OTG_EP_REG_SIZE);
        xe_np_ep81_fault_snapshot.pcd_instance=(uint32_t)(uintptr_t)pcd->Instance;
        xe_np_ep81_fault_snapshot.pcd_dma_enable=pcd->Init.dma_enable;
        xe_np_ep81_fault_snapshot.pcd_state=(uint32_t)pcd->State;
        xe_np_ep81_fault_snapshot.pcd_error=pcd->ErrorCode;
        xe_np_ep81_fault_snapshot.ep_xfer_buffer=(uint32_t)(uintptr_t)pcd->IN_ep[1].xfer_buff;
        xe_np_ep81_fault_snapshot.ep_xfer_len=pcd->IN_ep[1].xfer_len;
        xe_np_ep81_fault_snapshot.ep_xfer_count=pcd->IN_ep[1].xfer_count;
        xe_np_ep81_fault_snapshot.ep_dma_addr=pcd->IN_ep[1].dma_addr;
        xe_np_ep81_fault_snapshot.ep_maxpacket=pcd->IN_ep[1].maxpacket;
        xe_np_ep81_fault_snapshot.gintsts=XE_NP_EP81_READ(core->GINTSTS);
        xe_np_ep81_fault_snapshot.gintmsk=XE_NP_EP81_READ(core->GINTMSK);
        xe_np_ep81_fault_snapshot.gahbcfg=XE_NP_EP81_READ(core->GAHBCFG);
        xe_np_ep81_fault_snapshot.dsts=XE_NP_EP81_READ(dev->DSTS);
        xe_np_ep81_fault_snapshot.daint=XE_NP_EP81_READ(dev->DAINT);
        xe_np_ep81_fault_snapshot.daintmsk=XE_NP_EP81_READ(dev->DAINTMSK);
        xe_np_ep81_fault_snapshot.diepmsk=XE_NP_EP81_READ(dev->DIEPMSK);
        xe_np_ep81_fault_snapshot.diepctl=XE_NP_EP81_READ(ep->DIEPCTL);
        xe_np_ep81_fault_snapshot.diepint=XE_NP_EP81_READ(ep->DIEPINT);
        xe_np_ep81_fault_snapshot.dieptsiz=XE_NP_EP81_READ(ep->DIEPTSIZ);
        xe_np_ep81_fault_snapshot.diepdma=XE_NP_EP81_READ(ep->DIEPDMA);
        xe_np_ep81_fault_snapshot.dtxfsts=XE_NP_EP81_READ(ep->DTXFSTS);
        flags|=XE_NP_EP81_HW_VALID|XE_NP_EP81_HW_NONATOMIC;
    }
    xe_np_ep81_fault_snapshot.flags=flags;__DMB();xe_np_ep81_fault_snapshot.attempted=1U;
    __set_PRIMASK(key);
}
#endif
