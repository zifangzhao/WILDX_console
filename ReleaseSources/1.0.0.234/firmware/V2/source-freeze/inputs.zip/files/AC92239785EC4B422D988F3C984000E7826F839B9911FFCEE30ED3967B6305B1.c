#include "CE32_COMMAND.h"

#include <stddef.h>
#include <string.h>

static RTC_HandleTypeDef *ce32_command_rtc = NULL;

void CE32_COMMAND_SetRtcHandle(RTC_HandleTypeDef *hrtc)
{
    ce32_command_rtc = hrtc;
}

int CE32_COMMAND_Init(CE32_command *handle)
{
    if(handle == NULL)
    {
        return -1;
    }

    memset(handle, 0, sizeof(*handle));
    handle->free_buffer = CMD_BUFSIZE;
    return 0;
}

int CE32_COMMAND_EnqueueCmd(CE32_command *handle, unsigned char *data, int cmd_len)
{
    if((handle == NULL) || (data == NULL) || (cmd_len <= 0))
    {
        return -1;
    }

    if((handle->cmd_pending >= CMD_SEQ) || ((uint32_t)cmd_len > handle->free_buffer))
    {
        return -1;
    }

    handle->cmd_buf[handle->cmd_idx_in] = data;
    handle->cmd_len[handle->cmd_idx_in] = (uint32_t)cmd_len;
    handle->cmd_pad[handle->cmd_idx_in] = 0U;
    handle->free_buffer = (uint16_t)(handle->free_buffer - (uint16_t)cmd_len);
    handle->cmd_idx_in = CMD_ADD_CHK(handle->cmd_idx_in, 1U, CMD_SEQ);
    handle->cmd_pending++;
    handle->IN_OK++;
    return 0;
}

int CE32_COMMAND_EnqueueCmd_MEMCopy(CE32_command *handle, unsigned char *data, int cmd_len)
{
    uint8_t *ptr = NULL;

    if((handle == NULL) || (data == NULL))
    {
        return -1;
    }

    if(CE32_COMMAND_Enqueue_Allocate(handle, cmd_len, &ptr) != 0)
    {
        return -1;
    }

    memcpy(ptr, data, (size_t)cmd_len);
    return CE32_COMMAND_EnqueueCmd_buffered(handle);
}

int CE32_COMMAND_Enqueue_Allocate(CE32_command *handle, int cmd_len, uint8_t **ptr)
{
    uint16_t start_ptr;
    uint16_t byte_till_end;
    uint16_t padding = 0U;
    uint32_t idx;

    if((handle == NULL) || (cmd_len <= 0))
    {
        return -1;
    }

    if(((uint32_t)cmd_len > CMD_BUFSIZE) || (handle->cmd_pending >= CMD_SEQ))
    {
        return -1;
    }

    start_ptr = (uint16_t)handle->cmd_ptr_in;
    byte_till_end = (uint16_t)(CMD_BUFSIZE - start_ptr);
    if((uint32_t)cmd_len >= byte_till_end)
    {
        padding = byte_till_end;
        start_ptr = 0U;
    }

    if(handle->free_buffer < (uint16_t)(cmd_len + padding))
    {
        return -1;
    }

    idx = handle->cmd_idx_in;
    handle->stream_in.addr = &handle->buffer[start_ptr];
    handle->stream_in.len = (uint32_t)cmd_len;
    handle->stream_in.idx = 0U;
    handle->stream_in.logging = 1U;
    handle->cmd_pad[idx] = padding;

    if(ce32_command_rtc != NULL)
    {
        CE32_RTC_GetTime(ce32_command_rtc, &handle->cmd_time[idx]);
    }
    else
    {
        memset(&handle->cmd_time[idx], 0, sizeof(handle->cmd_time[idx]));
    }

    if(ptr != NULL)
    {
        *ptr = (uint8_t *)handle->stream_in.addr;
    }

    return 0;
}

int CE32_COMMAND_Enqueue_Byte(CE32_command *handle, unsigned char data)
{
    if(handle == NULL)
    {
        return -1;
    }

    if(handle->stream_in.idx < handle->stream_in.len)
    {
        handle->stream_in.addr[handle->stream_in.idx++] = data;
        return 0;
    }

    handle->stream_in.idx++;
    return -1;
}

int CE32_COMMAND_Enqueue_BytesLeft(CE32_command *handle)
{
    if(handle == NULL)
    {
        return -1;
    }

    return (int)(handle->stream_in.len - handle->stream_in.idx);
}

int CE32_COMMAND_Enqueue_Byte_Abort(CE32_command *handle)
{
    if(handle == NULL)
    {
        return -1;
    }

    handle->stream_in.logging = 0U;
    handle->stream_in.len = 0U;
    handle->stream_in.idx = 0U;
    handle->IN_Fail++;
    return 0;
}

int CE32_COMMAND_Enqueue_RescanBuffer(CE32_command *handle)
{
    (void)handle;
    return 0;
}

int CE32_COMMAND_EnqueueCmd_buffered(CE32_command *handle)
{
    uint32_t idx;
    uint16_t start_ptr;
    uint16_t pad;

    if(handle == NULL)
    {
        return -1;
    }

    if((handle->stream_in.logging == 0U) || (handle->cmd_pending >= CMD_SEQ))
    {
        return -1;
    }

    idx = handle->cmd_idx_in;
    start_ptr = (uint16_t)((uint8_t *)handle->stream_in.addr - (uint8_t *)handle->buffer);
    pad = handle->cmd_pad[idx];

    if(handle->free_buffer < (uint16_t)(handle->stream_in.len + pad))
    {
        return -1;
    }

    handle->cmd_buf[idx] = (uint8_t *)handle->stream_in.addr;
    handle->cmd_len[idx] = handle->stream_in.len;
    handle->free_buffer = (uint16_t)(handle->free_buffer - (uint16_t)(handle->stream_in.len + pad));
    handle->cmd_ptr_in = CMD_ADD_CHK(start_ptr, handle->stream_in.len, CMD_BUFSIZE);
    handle->cmd_idx_in = CMD_ADD_CHK(handle->cmd_idx_in, 1U, CMD_SEQ);
    handle->cmd_pending++;
    handle->IN_OK++;
    handle->stream_in.logging = 0U;
    handle->stream_in.len = 0U;
    handle->stream_in.idx = 0U;
    return 0;
}

int CE32_COMMAND_DequeueCmd(CE32_command *handle, uint8_t **data_ptr, uint32_t *cmd_len)
{
    uint32_t idx;
    uint32_t out_len;
    uint16_t pad;

    if((handle == NULL) || (handle->cmd_pending == 0U))
    {
        return -1;
    }

    idx = handle->cmd_idx_out;
    out_len = handle->cmd_len[idx];
    pad = handle->cmd_pad[idx];

    if(data_ptr != NULL)
    {
        *data_ptr = (uint8_t *)handle->cmd_buf[idx];
    }
    if(cmd_len != NULL)
    {
        *cmd_len = out_len;
    }

    handle->cmd_idx_out = CMD_ADD_CHK(handle->cmd_idx_out, 1U, CMD_SEQ);
    handle->cmd_pending--;
    handle->free_buffer = (uint16_t)(handle->free_buffer + (uint16_t)out_len + pad);
    handle->cmd_pad[idx] = 0U;
    return 0;
}

int CE32_COMMAND_DequeueCmdwTime(CE32_command *handle, uint8_t **data_ptr, uint32_t *cmd_len, CE32_SyncTypeDef *time)
{
    uint32_t idx;

    if((handle == NULL) || (handle->cmd_pending == 0U))
    {
        return -1;
    }

    idx = handle->cmd_idx_out;
    if(time != NULL)
    {
        *time = handle->cmd_time[idx];
    }

    return CE32_COMMAND_DequeueCmd(handle, data_ptr, cmd_len);
}

int CE32_COMMAND_Dequeue_Byte(CE32_command *handle, uint8_t *data)
{
    if((handle == NULL) || (data == NULL) || (handle->cmd_pending == 0U))
    {
        return -1;
    }

    if(handle->stream_out.logging == 0U)
    {
        handle->stream_out.addr = handle->cmd_buf[handle->cmd_idx_out];
        handle->stream_out.len = handle->cmd_len[handle->cmd_idx_out];
        handle->stream_out.idx = 0U;
        handle->stream_out.logging = 1U;
    }

    *data = handle->stream_out.addr[handle->stream_out.idx++];
    if(handle->stream_out.idx >= handle->stream_out.len)
    {
        handle->stream_out.logging = 0U;
        return CE32_COMMAND_DequeueCmd(handle, NULL, NULL);
    }

    return 0;
}

int CE32_COMMAND_Dequeue_BytesLeft(CE32_command *handle)
{
    if(handle == NULL)
    {
        return -1;
    }

    return (int)(handle->stream_out.len - handle->stream_out.idx);
}

int CE32_COMMAND_Dequeue_Byte_Abort(CE32_command *handle)
{
    if(handle == NULL)
    {
        return -1;
    }

    handle->stream_out.idx = 0U;
    handle->stream_out.logging = 0U;
    return 0;
}

int CE32_COMMAND_GetPendingCounts(CE32_command *handle)
{
    if(handle == NULL)
    {
        return -1;
    }

    return (int)handle->cmd_pending;
}

int CE32_COMMAND_GetCmdPointer(CE32_command *handle, uint8_t **data_ptr, uint32_t *cmd_len)
{
    if((handle == NULL) || (handle->cmd_pending == 0U))
    {
        return -1;
    }

    if(data_ptr != NULL)
    {
        *data_ptr = (uint8_t *)handle->cmd_buf[handle->cmd_idx_out];
    }
    if(cmd_len != NULL)
    {
        *cmd_len = handle->cmd_len[handle->cmd_idx_out];
    }

    return 0;
}

int CE32_COMMAND_DiscardAll(CE32_command *handle)
{
    if(handle == NULL)
    {
        return -1;
    }

    while(CE32_COMMAND_DequeueCmd(handle, NULL, NULL) == 0)
    {
    }
    return 0;
}
