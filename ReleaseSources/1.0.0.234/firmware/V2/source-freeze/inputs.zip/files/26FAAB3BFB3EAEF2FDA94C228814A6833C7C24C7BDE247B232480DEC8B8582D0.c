#include "xe_np_imu_grid_admission.h"
#if XE_NP_GRID_FAIRNESS_TEST
#include <limits.h>

int XE_NP_GridAdmission_Allow(const XE_NP_GridAdmission *s)
{
    uint32_t occupancy,inflight,unsent,queued,retained;
    uint64_t age,horizon,reserve,risk;
    if(!s || s->coherent!=1U || s->clock_qualified!=1U || s->bound_qualified!=1U ||
       s->transport_qualified!=1U || s->transport_idle!=1U || s->producer_active!=1U ||
       s->producer_error || s->producer_borrowed || s->stopping || s->interrupted ||
       s->provider_ready!=1U || s->provider_inflight || !s->snapshot_epoch ||
       s->snapshot_epoch!=s->current_epoch || s->probe_mask!=7U || s->sample_hz!=20000U ||
       s->source_bytes_per_tick!=1U || s->held>1U || s->phase_done>1U ||
       !s->max_age_us || !s->service_window_us || !s->safety_bytes || s->now_us<s->snapshot_us)return 0;
    age=s->now_us-s->snapshot_us;
    if(age>s->max_age_us || age>UINT64_MAX-s->service_window_us)return 0;
    horizon=age+s->service_window_us;
    /* 20 kHz * 1600 PSSI source ticks = 32 bytes/us for this exact profile. */
    if(horizon>UINT64_MAX/32U)return 0;
    reserve=horizon*32U;
    if(reserve>UINT64_MAX-s->safety_bytes)return 0;
    reserve+=s->safety_bytes;
    if(!s->ring_bytes || !s->retention_bytes || s->retention_bytes>s->ring_bytes ||
       !s->unpublished_bytes || s->unpublished_bytes>=s->retention_bytes ||
       s->published_offset>=s->ring_bytes || s->consumer_offset>=s->ring_bytes)return 0;
    retained=s->published_offset>=s->consumer_offset?s->published_offset-s->consumer_offset:
             s->ring_bytes-(s->consumer_offset-s->published_offset);
    risk=(uint64_t)retained+s->unpublished_bytes;
    if(reserve>=s->retention_bytes || risk>=s->retention_bytes-reserve)return 0;
    if(s->slot_count<2U || s->slot_count>32U || s->active>1U || s->segment_pending>1U)return 0;
    occupancy=s->filled-s->completed;inflight=s->submitted-s->completed;unsent=s->filled-s->submitted;
    if(occupancy>s->slot_count || inflight>1U || unsent>occupancy ||
       inflight>occupancy || (uint64_t)inflight+unsent!=occupancy ||
       occupancy>s->slot_count-2U || (s->active!=(uint32_t)(inflight!=0U)))return 0;
    /* Never start optional work ahead of an idle EP81's published block or
     * an unarmed second segment. Active EP81 retains its existing owner. */
    if(!s->active && (unsent || s->segment_pending))return 0;
    if(!s->queue_capacity || s->queue_capacity>UINT32_C(0x7fffffff))return 0;
    queued=s->queue_head-s->queue_tail;
    if(queued>s->queue_capacity)return 0;
    if(!s->phase_done)return s->held || queued;
    return (uint64_t)queued+s->held>=12U;
}
#endif
