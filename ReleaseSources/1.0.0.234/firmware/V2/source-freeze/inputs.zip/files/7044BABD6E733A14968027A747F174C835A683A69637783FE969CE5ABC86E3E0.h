#ifndef XE_NP_IMU_GRID_PHASE_BOUND_H
#define XE_NP_IMU_GRID_PHASE_BOUND_H
#include <stdint.h>

/* Startup-only arithmetic. Caller must verify identity, first-source proof,
 * continuous HSE clock and the actual session-wide copy-lateness bound. This
 * helper provides no hardware proof, absolute UTC or SAMPLE0_LOCK claim. */
typedef struct {
    uint64_t source_before_us,source_after_us;
    uint64_t timer_start_before_us,timer_start_after_us;
    uint64_t source_origin_tick,reference_tick;
    /* Slot ordinal relative to the timer start, where slot 0 is at +800 us. */
    uint64_t first_relative_slot;
    uint32_t source_hz,max_copy_lateness_us;
    uint8_t continuous_clock_qualified,copy_bound_qualified;
} XE_NP_GridPhaseInput;
typedef struct {
    int64_t lower_numerator,upper_numerator;
    uint32_t denominator,maximum_relative_jitter_ticks;
} XE_NP_GridPhaseBound;
/* On any failure, output is the NSGP unknown interval/jitter sentinel. Bounds
 * use source ticks with denominator 1 for the admitted exact MHz rates. */
/* Returns 1 only if the earliest possible grid instant is strictly after the
 * latest possible NP reference; 0 means before/overlapping, -1 means unknown
 * or invalid. This ordering proof does not require a qualified copy bound. */
int XE_NP_GridPhaseBound_AfterSource(const XE_NP_GridPhaseInput *input);
int XE_NP_GridPhaseBound_Compute(const XE_NP_GridPhaseInput *input,XE_NP_GridPhaseBound *out);
/* Actual first accepted copy bracket in the same source counter domain.
 * Caller must match the held ordinal and source identity. The source-clock
 * relationship is conditional on the local startup clock model; no later
 * clock continuity, sample jitter, or physical sensor phase is claimed. */
int XE_NP_GridPhaseBound_First(const XE_NP_GridPhaseInput *input,
    uint64_t before_us,uint64_t after_us,XE_NP_GridPhaseBound *out);
#endif
