#ifndef XE_NP_NP2_PREPARATION_H
#define XE_NP_NP2_PREPARATION_H
#include <stdint.h>
#ifndef XE_NP_NP2_PREPARATION_ENABLE
#define XE_NP_NP2_PREPARATION_ENABLE 0U
#endif
#if XE_NP_NP2_PREPARATION_ENABLE
#include "np_preparation_wire.h"
/* Configuration/start/stop boundaries only; never call from sample services. */
enum { NP2_PREP_CONFIG=1U,NP2_PREP_PROFILE,NP2_PREP_OWNER,NP2_PREP_STOP,
       NP2_PREP_CLOCK,NP2_PREP_SOURCE,NP2_PREP_CANCEL,NP2_PREP_RESET };
int XE_NP_Np2Preparation_Exchange(uint32_t owner,uint32_t mode,const uint8_t request[64],
    uint32_t busy,uint32_t mask,uint32_t hz,const uint32_t uid[3],uint8_t reply[64]);
void XE_NP_Np2Preparation_Service(uint32_t mode);
int XE_NP_Np2Preparation_StartCold(uint32_t mask);
/* Adopt a same-key in-progress/READY source once;0 means ordinary cold setup.
 * Consumer remains responsible for final source arm and a fresh timestamp. */
int XE_NP_Np2Preparation_Consume(uint32_t owner,uint32_t mode,uint32_t mask,uint32_t hz);
void XE_NP_Np2Preparation_Invalidate(uint32_t detail);
void XE_NP_Np2Preparation_SourceStopped(void);
uint32_t XE_NP_Np2Preparation_ConfigBusy(void);
uint32_t XE_NP_Np2Preparation_Holding(void);
uint32_t XE_NP_Np2Preparation_ClockPending(void);
/* SD owns these stopped-only clock dependencies and UART ACK barrier. */
int XE_NP_Np2Preparation_SdClockReady(void);
int XE_NP_Np2Preparation_SdClock(uint32_t mask,uint32_t hz);
#else
#define XE_NP_Np2Preparation_Invalidate(detail) ((void)0)
#define XE_NP_Np2Preparation_SourceStopped() ((void)0)
#define XE_NP_Np2Preparation_ConfigBusy() 0U
#define XE_NP_Np2Preparation_Holding() 0U
#define XE_NP_Np2Preparation_ClockPending() 0U
#define XE_NP_Np2Preparation_Consume(owner,mode,mask,hz) 0
#endif
#endif