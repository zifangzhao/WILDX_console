#include "xe_np_imu_grid_control_wire.h"
#include "np_first_sync_wire.h"

static int uid_valid(const uint32_t uid[3])
{return uid && (uid[0] || uid[1] || uid[2]) &&
    (uid[0]!=UINT32_MAX || uid[1]!=UINT32_MAX || uid[2]!=UINT32_MAX);}
static int context_valid(const XE_NP_GridWireContext *c)
{return c && uid_valid(c->uid) && c->session && c->generation && c->epoch && c->domain && c->token;}
static int terminal_valid(const XE_NP_GridWireTerminal *t)
{
    int saturated;
    if(!t || !context_valid(&t->context) || (t->flags&~7U))return 0;
    if(((t->flags&XE_NP_GRID_END_FINAL_KNOWN)!=0U)!=(t->final_exclusive!=UINT64_MAX))return 0;
    saturated=(t->queue_dropped==UINT32_MAX || t->scheduler_missing==UINT32_MAX);
    return ((t->flags&XE_NP_GRID_END_SATURATED)!=0U)==saturated;
}
uint32_t XE_NP_GridWire_ClampCount(uint64_t value,uint32_t *flags)
{
    if(value>=UINT32_MAX){if(flags)*flags|=XE_NP_GRID_END_SATURATED;return UINT32_MAX;}
    return (uint32_t)value;
}
int XE_NP_GridWire_PackStatus(uint8_t out[XE_NP_GRID_STATUS_BYTES],
    const uint32_t uid[3],uint32_t flags,uint32_t revision)
{
    if(!out || !uid_valid(uid) || (flags&~7U))return 0;
    memcpy(out,"NSGC",4U);np_first_put32(out+4U,XE_NP_GRID_STATUS_VERSION);np_first_put32(out+8U,flags);
    for(uint32_t i=0U;i<3U;i++)np_first_put32(out+12U+4U*i,uid[i]);
    np_first_put32(out+24U,revision);np_first_put32(out+28U,np_first_crc(out,28U));return 1;
}
int XE_NP_GridWire_ValidateStatus(const uint8_t *wire,size_t length,const uint32_t uid[3])
{
    if(!wire || length!=XE_NP_GRID_STATUS_BYTES || !uid_valid(uid) || memcmp(wire,"NSGC",4U) ||
       np_first_u32(wire+4U)!=XE_NP_GRID_STATUS_VERSION || (np_first_u32(wire+8U)&~7U) ||
       np_first_u32(wire+28U)!=np_first_crc(wire,28U))return 0;
    for(uint32_t i=0U;i<3U;i++)if(np_first_u32(wire+12U+4U*i)!=uid[i])return 0;
    return 1;
}
int XE_NP_GridWire_PackTerminal(uint8_t out[XE_NP_GRID_TERMINAL_BYTES],const XE_NP_GridWireTerminal *t)
{
    if(!out || !terminal_valid(t))return 0;
    memset(out,0,XE_NP_GRID_TERMINAL_BYTES);memcpy(out,"NPGEND01",8U);
    np_first_put32(out+8U,1U);np_first_put32(out+12U,XE_NP_GRID_TERMINAL_BYTES);
    for(uint32_t i=0U;i<3U;i++)np_first_put32(out+16U+4U*i,t->context.uid[i]);
    np_first_put32(out+28U,t->context.session);np_first_put32(out+32U,t->context.generation);
    np_first_put32(out+36U,t->context.epoch);np_first_put32(out+40U,t->context.domain);
    np_first_put64(out+44U,t->context.token);np_first_put64(out+52U,t->final_exclusive);
    np_first_put32(out+60U,t->queue_dropped);np_first_put32(out+64U,t->scheduler_missing);
    np_first_put32(out+68U,t->flags);np_first_put32(out+76U,np_first_crc(out,76U));return 1;
}
int XE_NP_GridWire_ParseTerminal(const uint8_t *w,size_t n,const XE_NP_GridWireContext *expected,
    XE_NP_GridWireTerminal *out)
{
    XE_NP_GridWireTerminal t;
    if(!w || n!=XE_NP_GRID_TERMINAL_BYTES || !context_valid(expected) || memcmp(w,"NPGEND01",8U) ||
       np_first_u32(w+8U)!=1U || np_first_u32(w+12U)!=XE_NP_GRID_TERMINAL_BYTES ||
       np_first_u32(w+72U)!=0U || np_first_u32(w+76U)!=np_first_crc(w,76U))return 0;
    for(uint32_t i=0U;i<3U;i++)t.context.uid[i]=np_first_u32(w+16U+4U*i);
    t.context.session=np_first_u32(w+28U);t.context.generation=np_first_u32(w+32U);
    t.context.epoch=np_first_u32(w+36U);t.context.domain=np_first_u32(w+40U);
    t.context.token=np_first_u64(w+44U);t.final_exclusive=np_first_u64(w+52U);
    t.queue_dropped=np_first_u32(w+60U);t.scheduler_missing=np_first_u32(w+64U);t.flags=np_first_u32(w+68U);
    if(!terminal_valid(&t) || t.context.uid[0]!=expected->uid[0] || t.context.uid[1]!=expected->uid[1] ||
       t.context.uid[2]!=expected->uid[2] || t.context.session!=expected->session ||
       t.context.generation!=expected->generation || t.context.epoch!=expected->epoch ||
       t.context.domain!=expected->domain || t.context.token!=expected->token)return 0;
    if(out)*out=t;return 1;
}
