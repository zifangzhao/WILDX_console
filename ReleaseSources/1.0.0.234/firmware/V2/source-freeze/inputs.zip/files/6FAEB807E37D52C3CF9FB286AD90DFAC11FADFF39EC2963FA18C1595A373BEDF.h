#ifndef XE_NP_NP2_CLOSED_LOOP_CARRIER_H
#define XE_NP_NP2_CLOSED_LOOP_CARRIER_H
#include <stdint.h>
#include "np_cl_kernel.h"
#include "xe_np_np2_closed_loop_spi.h"
#include "xe_np_np2_closed_loop_perf.h"
#ifndef XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
#define XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE 0U
#endif
#ifndef XE_NP_NP2_CLOSED_LOOP_WORKSPACE_ENABLE
#define XE_NP_NP2_CLOSED_LOOP_WORKSPACE_ENABLE 0U
#endif
#define NP2_CL_CARRIER_FLAG 0x400U
#define NP2_CL_CARRIER_SLOT 184U
#define NP2_CL_CARRIER_BYTES 64U
#define NP2_CL_CARRIER_DROPS 248U
#define NP2_CL_CARRIER_CONFIG_CRC 252U
#define NP2_CL_CARRIER_ROWS 16U
/* One foreground owner. Caller allocates this state outside DMA/capture arenas.
 * The event queue is metadata best effort; commit means immutable publication,
 * NOT USB host receipt, SD DATAEND, readback, or durable storage. */
typedef struct XE_NP_Np2ClCarrierTag {
    uint8_t event[NP2_CL_CARRIER_ROWS][64],confirmed_config[64];
    uint32_t session,config_crc,generation,head,tail,next_sequence;
    uint32_t attempted,committed,dropped,tail_dropped,rejected;
    uint32_t claim_tail,claim_sequence,quality_unknown;
    uint8_t initialized,stopped,claimed,sequence_exhausted;
} XE_NP_Np2ClCarrier;
typedef struct { uint32_t generation,tail,sequence; } XE_NP_Np2ClTicket;
/* Explicit caller workspace; never instantiate this inside an acquisition/DMA
 * section. Source/kernel/queue state is owned and placed by the integrator. */
typedef struct {
    XE_NP_Np2ClosedLoopSpi source;
    NpClLane lane[2];
    XE_NP_Np2ClCarrier carrier;
    uint64_t input_end;
    uint32_t epoch,event_time_flags;
    uint32_t staged,prepared,failure,session_counter;
    uint32_t arm_state; /* 0=disarmed, 1=fresh CONFIGURE, 2=accepted START pending Prepare. */
    uint64_t timing_token;
#if XE_NP_NP2_CLOSED_LOOP_PERF_ENABLE
    XE_NP_Np2ClPerf perf;
#endif
} XE_NP_Np2ClWorkspace;
typedef struct {
    uint32_t session,generation,native_hz,record_mask,source_epoch;
    uint16_t phase;
    uint8_t phase_verified,origin_valid,copied;
} XE_NP_Np2ClSourceProof;
typedef struct {
    uint32_t source_epoch,source_hz,native_hz,origin_lo,origin_hi,anchor_flags;
    uint32_t phase,matches,error,record_mask,copied;
    uint32_t session,timing_generation,core_hz;
    uint64_t timing_token;
} XE_NP_Np2ClStartupReceipt;
/* Proof is acquisition-owned, NEVER built from the last recording or a host
 * request. A failed optional configuration does not change the NP recorder. */
int XE_NP_Np2ClWorkspace_Configure(XE_NP_Np2ClWorkspace *,const uint8_t request[64],const XE_NP_Np2ClSourceProof *);
void XE_NP_Np2ClWorkspace_Drain(XE_NP_Np2ClWorkspace *);
typedef struct {
    uint32_t session,native_hz,source_hz,epoch,delay_ticks,phase[2];
    uint32_t tap,flags,filter_id,source_step,record_mask;
} XE_NP_Np2ClConfigMeta;
typedef struct {
    uint32_t session,config_crc,generation,queued,attempted,committed;
    uint32_t dropped,tail_dropped,rejected,last_sequence,stopped;
} XE_NP_Np2ClCarrierStatus;
/* confirmed_config is the full opaque64B confirmed snapshot. The configuration
 * owner supplies its already-confirmed binding CRC; this layer never interprets
 * an NPCC request/ACK as configuration, nor creates a protocol allocation. */
int XE_NP_Np2ClCarrier_Init(XE_NP_Np2ClCarrier *,uint32_t session,uint32_t generation,
                           const uint8_t confirmed_config[64],uint32_t config_crc);
int XE_NP_Np2ClCarrier_Push(XE_NP_Np2ClCarrier *,const NpClEvent *,uint64_t input_end,
                           uint32_t epoch,uint32_t reason,uint32_t time_flags);
/* Cold header-template call only: sets the SESSION-STATIC0x400 flag and clears
 * the event slot. RAW_D8_PHASE is rejected, never modified/stripped silently. */
int XE_NP_Np2ClCarrier_BindHeader(const XE_NP_Np2ClCarrier *,uint8_t header[512]);
/* Claim writes only184..255; header must already carry the negotiated flag.
 * Empty queue writes an all-zero64Bslot while the session flag remains set.
 * A ticket borrows an event until Commit; Abort preserves it for a later block. */
int XE_NP_Np2ClCarrier_Claim(XE_NP_Np2ClCarrier *,uint8_t header[512],XE_NP_Np2ClTicket *);
int XE_NP_Np2ClCarrier_Commit(XE_NP_Np2ClCarrier *,const XE_NP_Np2ClTicket *);
void XE_NP_Np2ClCarrier_Abort(XE_NP_Np2ClCarrier *,const XE_NP_Np2ClTicket *);
/* Never wait/inject padding blocks at Stop. Counts every still-queued event as
 * final-tail loss and invalidates an uncommitted ticket. Caller must preserve
 * this status in its negotiated stopped summary/footer, not claim it was saved. */
void XE_NP_Np2ClCarrier_Stop(XE_NP_Np2ClCarrier *);
int XE_NP_Np2ClCarrier_SummaryUnknown(uint32_t session,uint32_t config_crc,uint32_t generation,uint8_t out[64]);
int XE_NP_Np2ClCarrier_SummaryEncode(const XE_NP_Np2ClCarrier *,int delivery_unknown,uint8_t out[64]);
int XE_NP_Np2ClCarrier_SummaryDecode(const uint8_t in[64],uint32_t expected_session,uint32_t config_crc,XE_NP_Np2ClCarrierStatus *,uint32_t *flags);
int XE_NP_Np2ClCarrier_PatchPhase(uint8_t header[512],uint32_t phase);
int XE_NP_Np2ClCarrier_ValidateHeader(const XE_NP_Np2ClCarrier *,const uint8_t header[512]);
/* Approved versioned extension is config[1888..2047]; static before capture.
 * Decoding requires an explicit matching descriptor flag, not just a marker. */
int XE_NP_Np2ClCarrier_ConfigEncode(const XE_NP_Np2ClCarrier *,const XE_NP_Np2ClConfigMeta *,uint8_t config[2048]);
int XE_NP_Np2ClCarrier_ConfigDecode(const uint8_t config[2048],int descriptor_has_cl,XE_NP_Np2ClConfigMeta *,uint8_t snapshot[64]);
void XE_NP_Np2ClCarrier_Status(const XE_NP_Np2ClCarrier *,XE_NP_Np2ClCarrierStatus *);
#if XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
/* Optional integration holds one pointer only. Workspace stays caller-owned. */
void XE_NP_Np2ClCarrier_PortBind(XE_NP_Np2ClWorkspace *);
int XE_NP_Np2ClCarrier_PortControl(const uint8_t request[64],uint8_t reply[64],int busy,uint32_t mask,uint32_t hz,int copied);
/* Accepted START consumes one fresh CONFIGURE. Call before acquisition or
 * any start validation that may fail. Retained snapshots never opt in again. */
void XE_NP_Np2ClCarrier_PortBeginAttempt(void);
int XE_NP_Np2ClCarrier_PortPrepare(uint32_t session,uint32_t mask,uint32_t hz,uint32_t codec,uint32_t flags,int copied);
int XE_NP_Np2ClCarrier_PortNeedsProof(void);
void XE_NP_Np2ClCarrier_PortTiming(uint64_t token);
int XE_NP_Np2ClCarrier_PortAttest(const XE_NP_Np2ClStartupReceipt *,uint64_t first_tick,uint32_t published);
int XE_NP_Np2ClCarrier_PortAdmit(const XE_NP_Np2ClSourceProof *,uint64_t first_tick,uint32_t published);
const XE_NP_Np2ClCarrier *XE_NP_Np2ClCarrier_PortOwner(void);
int XE_NP_Np2ClCarrier_PortConfig(uint8_t config[2048]);
uint32_t XE_NP_Np2ClCarrier_PortFlag(uint32_t mask,uint32_t hz,uint32_t codec,uint32_t flags);
int XE_NP_Np2ClCarrier_PortHeader(uint8_t header[512]);
int XE_NP_Np2ClCarrier_PortClaim(uint8_t header[512],XE_NP_Np2ClTicket *);
int XE_NP_Np2ClCarrier_PortCommit(const XE_NP_Np2ClTicket *);
int XE_NP_Np2ClCarrier_PortValidate(const uint8_t header[512]);
void XE_NP_Np2ClCarrier_PortStop(void);
void XE_NP_Np2ClCarrier_PortFault(void);
void XE_NP_Np2ClCarrier_PortDrain(void);
#endif
#endif
