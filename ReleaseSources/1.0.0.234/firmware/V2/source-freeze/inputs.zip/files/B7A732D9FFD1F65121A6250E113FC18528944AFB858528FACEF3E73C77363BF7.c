#include "ce32_wire.h"

void CE32_WireFromHalDate(CE32_RTC_DateWire *dst, const RTC_DateTypeDef *src)
{
    if((dst == NULL) || (src == NULL))
    {
        return;
    }

    dst->WeekDay = src->WeekDay;
    dst->Month = src->Month;
    dst->Date = src->Date;
    dst->Year = src->Year;
}

void CE32_WireFromHalTime(CE32_RTC_TimeWire *dst, const RTC_TimeTypeDef *src)
{
    if((dst == NULL) || (src == NULL))
    {
        return;
    }

    dst->Hours = src->Hours;
    dst->Minutes = src->Minutes;
    dst->Seconds = src->Seconds;
    dst->TimeFormat = src->TimeFormat;
    dst->SubSeconds = src->SubSeconds;
    dst->SecondFraction = src->SecondFraction;
    dst->DayLightSaving = src->DayLightSaving;
    dst->StoreOperation = src->StoreOperation;
}

void CE32_HalDateFromWire(RTC_DateTypeDef *dst, const CE32_RTC_DateWire *src)
{
    if((dst == NULL) || (src == NULL))
    {
        return;
    }

    dst->WeekDay = src->WeekDay;
    dst->Month = src->Month;
    dst->Date = src->Date;
    dst->Year = src->Year;
}

void CE32_HalTimeFromWire(RTC_TimeTypeDef *dst, const CE32_RTC_TimeWire *src)
{
    if((dst == NULL) || (src == NULL))
    {
        return;
    }

    dst->Hours = src->Hours;
    dst->Minutes = src->Minutes;
    dst->Seconds = src->Seconds;
    dst->TimeFormat = src->TimeFormat;
    dst->SubSeconds = src->SubSeconds;
    dst->SecondFraction = src->SecondFraction;
    dst->DayLightSaving = src->DayLightSaving;
    dst->StoreOperation = src->StoreOperation;
}
