#include "xe_np_imu_grid_diag.h"
#if XE_NP_GRID_STARTUP_DIAG
#include <string.h>
static uint32_t snapshot_flags(uint32_t head,uint32_t tail,uint32_t dropped)
{return (head<tail?XE_NP_GRID_DIAG_INDEX_WRAP_AMBIGUOUS:0U)|
        (dropped==UINT32_MAX?XE_NP_GRID_DIAG_DROP_SATURATED:0U);}
void XE_NP_GridDiag_Reset(XE_NP_GridStartupDiag *d)
{if(d)memset(d,0,sizeof(*d));}
void XE_NP_GridDiag_Mark(XE_NP_GridStartupDiag *d,uint32_t stage,uint32_t tick,
                         uint32_t head,uint32_t tail,uint32_t dropped)
{
    volatile XE_NP_GridDiagEvent *e;
    if(!d || stage>=XE_NP_GRID_DIAG_STAGE_COUNT)return;
    e=&d->stage[stage];if(e->valid)return;
    e->tick_ms=tick;e->head=head;e->tail=tail;e->dropped=dropped;
    e->flags=snapshot_flags(head,tail,dropped);e->valid=1U;
}
void XE_NP_GridDiag_NpFault(XE_NP_GridStartupDiag *d,uint32_t tick,uint32_t error,
                             uint32_t filled,uint32_t submitted,uint32_t completed,
                             uint32_t partial,uint32_t active,uint32_t tx_started_ms)
{
    volatile XE_NP_GridDiagNpFault *f;
    if(!d)return;f=&d->np_fault;if(f->valid)return;
    f->tick_ms=tick;f->error=error;f->filled=filled;f->submitted=submitted;
    f->completed=completed;f->partial=partial;f->tx_active=active;
    f->tx_started_ms=tx_started_ms;f->valid=1U;
}
void XE_NP_GridDiag_QueueFull(XE_NP_GridStartupDiag *d,uint64_t ordinal,uint64_t counter,
                              uint32_t head,uint32_t tail,uint32_t dropped)
{
    volatile XE_NP_GridDiagFull *f;
    if(!d)return;f=&d->full;if(f->valid)return;
    f->ordinal=ordinal;f->counter=counter;f->head=head;f->tail=tail;f->dropped=dropped;
    f->flags=snapshot_flags(head,tail,dropped)|
        (ordinal==UINT64_MAX?XE_NP_GRID_DIAG_ORDINAL_UNKNOWN:0U)|
        (counter==UINT64_MAX?XE_NP_GRID_DIAG_COUNTER_UNKNOWN:0U);
    f->valid=1U;
}
#endif
