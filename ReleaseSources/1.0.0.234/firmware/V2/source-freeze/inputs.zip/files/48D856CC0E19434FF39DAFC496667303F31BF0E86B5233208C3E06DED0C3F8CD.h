#ifndef XE_NP_NP2_DMA_EVENTS_H
#define XE_NP_NP2_DMA_EVENTS_H
#include "xe_np_np2_producer.h"

/* Shared policy for normal snapshots, post-W1C checks, acknowledgements and
 * final-stop diagnostics. In full-node mode HT is deliberately sticky/ignored
 * until TC acknowledges both flags; it must not become a terminal stop error. */
static inline uint32_t XE_NP_Np2DmaEventsFromFlags(uint32_t flags,
                                                   uint32_t half_mask,
                                                   uint32_t complete_mask)
{
#if XE_NP_NP2_FULL_NODE_IRQ
    (void)half_mask;
    return (flags&complete_mask)?XE_NP_NP2_EVENT_TC:0U;
#else
    return ((flags&half_mask)?XE_NP_NP2_EVENT_HT:0U)|
           ((flags&complete_mask)?XE_NP_NP2_EVENT_TC:0U);
#endif
}

static inline uint32_t XE_NP_Np2DmaAckFlags(uint32_t event,
                                            uint32_t half_mask,
                                            uint32_t complete_mask)
{
    if(event==XE_NP_NP2_EVENT_HT)return half_mask;
    if(event==XE_NP_NP2_EVENT_TC){
#if XE_NP_NP2_FULL_NODE_IRQ
        return half_mask|complete_mask;
#else
        return complete_mask;
#endif
    }
    return 0U;
}
#endif
