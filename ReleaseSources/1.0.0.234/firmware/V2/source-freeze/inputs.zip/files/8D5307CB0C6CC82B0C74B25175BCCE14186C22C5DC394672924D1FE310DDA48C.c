#include "CE32_ADC.h"

CE32_ADC ADC_handle = {0};

#define XE_NP_ADC_REGULAR_CHANNEL_DEFAULT ADC_CHANNEL_13
#define XE_NP_ADC_REGULAR_SAMPLE_TIME_DEFAULT ADC_SAMPLETIME_5CYCLES
#define XE_NP_ADC_BATT_CH0 ADC_CHANNEL_3
#define XE_NP_ADC_BATT_CH1 ADC_CHANNEL_17
#define XE_NP_ADC_BATT_SAMPLE_TIME ADC_SAMPLETIME_68CYCLES
#define XE_NP_ADC_INJECTED_TIMEOUT_MS 10U

static uint8_t xe_np_adc_regular_dma_configured;
static uint8_t xe_np_adc_injected_batt_configured;
static uint8_t xe_np_adc_injected_single_configured;

static void XE_NP_ADC_StopRegularSafely(ADC_HandleTypeDef *hadc)
{
    if(hadc == NULL)
    {
        return;
    }

    if(hadc->DMA_Handle != NULL)
    {
        (void)HAL_ADC_Stop_DMA(hadc);
    }
    (void)HAL_ADC_Stop(hadc);
}

static uint32_t XE_NP_ADC_GetTimClock(TIM_TypeDef *timx)
{
    uint32_t pclk;
    uint32_t prescaler_bits;

    if(timx == NULL)
    {
        return 0U;
    }

    if((timx == TIM1) || (timx == TIM8) || (timx == TIM15) || (timx == TIM16) || (timx == TIM17))
    {
        pclk = HAL_RCC_GetPCLK2Freq();
        prescaler_bits = RCC->CFGR2 & RCC_CFGR2_PPRE2;
        if(prescaler_bits != RCC_HCLK_DIV1)
        {
            pclk *= 2U;
        }
        return pclk;
    }

    pclk = HAL_RCC_GetPCLK1Freq();
    prescaler_bits = RCC->CFGR2 & RCC_CFGR2_PPRE1;
    if(prescaler_bits != RCC_HCLK_DIV1)
    {
        pclk *= 2U;
    }
    return pclk;
}

static uint32_t XE_NP_ADC_MapRegularTrigger(const TIM_HandleTypeDef *htim)
{
    if((htim == NULL) || (htim->Instance == NULL))
    {
        return ADC_SOFTWARE_START;
    }

    if(htim->Instance == TIM2)
    {
        return ADC_EXTERNALTRIG_T2_TRGO;
    }
    if(htim->Instance == TIM8)
    {
        return ADC_EXTERNALTRIG_T8_TRGO;
    }

    return ADC_SOFTWARE_START;
}

static HAL_StatusTypeDef XE_NP_ADC_ConfigRegularChannel(ADC_HandleTypeDef *hadc)
{
    ADC_ChannelConfTypeDef sConfig = {0};

    if(hadc == NULL)
    {
        return HAL_ERROR;
    }

    sConfig.Channel = XE_NP_ADC_REGULAR_CHANNEL_DEFAULT;
    sConfig.Rank = ADC_REGULAR_RANK_1;
    sConfig.SamplingTime = XE_NP_ADC_REGULAR_SAMPLE_TIME_DEFAULT;
    sConfig.SingleDiff = ADC_SINGLE_ENDED;
    sConfig.OffsetNumber = ADC_OFFSET_NONE;
    sConfig.Offset = 0;
    return HAL_ADC_ConfigChannel(hadc, &sConfig);
}

static HAL_StatusTypeDef XE_NP_ADC_ReinitRegular(
    CE32_ADC *h,
    uint32_t external_trig,
    uint32_t external_edge,
    uint32_t data_mgmt,
    FunctionalState continuous)
{
    if((h == NULL) || (h->hadc == NULL))
    {
        return HAL_ERROR;
    }

    XE_NP_ADC_StopRegularSafely(h->hadc);
    (void)HAL_ADCEx_InjectedStop(h->hadc);

    if(HAL_ADC_DeInit(h->hadc) != HAL_OK)
    {
        return HAL_ERROR;
    }

    h->hadc->Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
    h->hadc->Init.Resolution = ADC_RESOLUTION_14B;
    h->hadc->Init.GainCompensation = 0U;
    h->hadc->Init.DataAlign = ADC_DATAALIGN_RIGHT;
    h->hadc->Init.ScanConvMode = ADC_SCAN_ENABLE;
    h->hadc->Init.EOCSelection = ADC_EOC_SINGLE_CONV;
    h->hadc->Init.LowPowerAutoWait = DISABLE;
    h->hadc->Init.ContinuousConvMode = continuous;
    h->hadc->Init.NbrOfConversion = 1U;
    h->hadc->Init.DiscontinuousConvMode = DISABLE;
    h->hadc->Init.ExternalTrigConv = external_trig;
    h->hadc->Init.ExternalTrigConvEdge = external_edge;
    h->hadc->Init.DMAContinuousRequests =
        (data_mgmt == ADC_CONVERSIONDATA_DR) ? DISABLE : ENABLE;
    h->hadc->Init.TriggerFrequencyMode = ADC_TRIGGER_FREQ_HIGH;
    h->hadc->Init.Overrun = ADC_OVR_DATA_PRESERVED;
    h->hadc->Init.LeftBitShift = ADC_LEFTBITSHIFT_NONE;
    h->hadc->Init.ConversionDataManagement = data_mgmt;
    h->hadc->Init.OversamplingMode = DISABLE;

    if(HAL_ADC_Init(h->hadc) != HAL_OK)
    {
        return HAL_ERROR;
    }

    if(XE_NP_ADC_ConfigRegularChannel(h->hadc) != HAL_OK)
    {
        return HAL_ERROR;
    }

    xe_np_adc_regular_dma_configured = (data_mgmt == ADC_CONVERSIONDATA_DR) ? 0U : 1U;
    xe_np_adc_injected_batt_configured = 0U;
    xe_np_adc_injected_single_configured = 0U;
    return HAL_OK;
}

static HAL_StatusTypeDef XE_NP_ADC_ConfigInjectedChannel(
    CE32_ADC *h,
    uint32_t rank,
    uint32_t channel,
    uint32_t count)
{
    ADC_InjectionConfTypeDef injected = {0};

    if((h == NULL) || (h->hadc == NULL))
    {
        return HAL_ERROR;
    }

    injected.InjectedChannel = channel;
    injected.InjectedRank = rank;
    injected.InjectedSamplingTime = XE_NP_ADC_BATT_SAMPLE_TIME;
    injected.InjectedSingleDiff = ADC_SINGLE_ENDED;
    injected.InjectedOffsetNumber = ADC_OFFSET_NONE;
    injected.InjectedOffset = 0U;
    injected.InjectedOffsetSignedSaturation = DISABLE;
    injected.InjectedOffsetSign = ADC_OFFSET_SIGN_NEGATIVE;
    injected.InjectedOffsetSaturation = DISABLE;
    injected.InjectedLeftBitShift = ADC_LEFTBITSHIFT_NONE;
    injected.InjectedNbrOfConversion = count;
    injected.InjectedDiscontinuousConvMode = DISABLE;
    injected.AutoInjectedConv = DISABLE;
    injected.ExternalTrigInjecConv = ADC_INJECTED_SOFTWARE_START;
    injected.ExternalTrigInjecConvEdge = ADC_EXTERNALTRIGINJECCONV_EDGE_NONE;
    injected.InjecOversamplingMode = DISABLE;
    return HAL_ADCEx_InjectedConfigChannel(h->hadc, &injected);
}

static HAL_StatusTypeDef XE_NP_ADC_EnsureInjectedBatterySequence(CE32_ADC *h)
{
    if((h == NULL) || (h->hadc == NULL))
    {
        return HAL_ERROR;
    }

    if(xe_np_adc_injected_batt_configured != 0U)
    {
        return HAL_OK;
    }

    if(xe_np_adc_regular_dma_configured == 0U)
    {
        if(XE_NP_ADC_ReinitRegular(
               h,
               ADC_SOFTWARE_START,
               ADC_EXTERNALTRIGCONVEDGE_NONE,
               ADC_CONVERSIONDATA_DR,
               DISABLE) != HAL_OK)
        {
            return HAL_ERROR;
        }
    }

    if(XE_NP_ADC_ConfigInjectedChannel(h, ADC_INJECTED_RANK_1, XE_NP_ADC_BATT_CH0, 2U) != HAL_OK)
    {
        return HAL_ERROR;
    }
    if(XE_NP_ADC_ConfigInjectedChannel(h, ADC_INJECTED_RANK_2, XE_NP_ADC_BATT_CH1, 2U) != HAL_OK)
    {
        return HAL_ERROR;
    }

    xe_np_adc_injected_batt_configured = 1U;
    xe_np_adc_injected_single_configured = 0U;
    return HAL_OK;
}

static HAL_StatusTypeDef XE_NP_ADC_ConfigureInjectedSingle(CE32_ADC *h, uint32_t channel)
{
    if((h == NULL) || (h->hadc == NULL))
    {
        return HAL_ERROR;
    }

    if(xe_np_adc_regular_dma_configured == 0U)
    {
        if(XE_NP_ADC_ReinitRegular(
               h,
               ADC_SOFTWARE_START,
               ADC_EXTERNALTRIGCONVEDGE_NONE,
               ADC_CONVERSIONDATA_DR,
               DISABLE) != HAL_OK)
        {
            return HAL_ERROR;
        }
    }

    if(XE_NP_ADC_ConfigInjectedChannel(h, ADC_INJECTED_RANK_1, channel, 1U) != HAL_OK)
    {
        return HAL_ERROR;
    }

    xe_np_adc_injected_batt_configured = 0U;
    xe_np_adc_injected_single_configured = 1U;
    return HAL_OK;
}

static HAL_StatusTypeDef XE_NP_ADC_ConfigTriggerTimer(TIM_HandleTypeDef *htim, uint32_t fs_hz)
{
    TIM_MasterConfigTypeDef master = {0};
    uint32_t tim_clk;
    uint32_t ticks_per_update;
    uint32_t prescaler;
    uint32_t period;

    if((htim == NULL) || (htim->Instance == NULL) || (fs_hz == 0U))
    {
        return HAL_ERROR;
    }

    tim_clk = XE_NP_ADC_GetTimClock(htim->Instance);
    if(tim_clk == 0U)
    {
        return HAL_ERROR;
    }

    ticks_per_update = tim_clk / fs_hz;
    if(ticks_per_update == 0U)
    {
        ticks_per_update = 1U;
    }

    prescaler = (ticks_per_update / 65536U) + 1U;
    period = (tim_clk / (fs_hz * prescaler));
    if(period == 0U)
    {
        period = 1U;
    }

    htim->Init.Prescaler = prescaler - 1U;
    htim->Init.CounterMode = TIM_COUNTERMODE_UP;
    htim->Init.Period = period - 1U;
    htim->Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim->Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;

    if(HAL_TIM_Base_Init(htim) != HAL_OK)
    {
        return HAL_ERROR;
    }

    master.MasterOutputTrigger = TIM_TRGO_UPDATE;
#if defined(TIM_TRGO2_RESET)
    master.MasterOutputTrigger2 = TIM_TRGO2_RESET;
#endif
    master.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
    if(HAL_TIMEx_MasterConfigSynchronization(htim, &master) != HAL_OK)
    {
        return HAL_ERROR;
    }

    __HAL_TIM_SET_COUNTER(htim, 0U);
    __HAL_TIM_CLEAR_FLAG(htim, TIM_FLAG_UPDATE);
    return HAL_OK;
}

int CE32_ADC_Init(
    CE32_ADC *h,
    ADC_HandleTypeDef *hadc,
    TIM_HandleTypeDef *htim_trig,
    TIM_HandleTypeDef *htim_dma,
    uint32_t fs,
    uint8_t Nch,
    uint8_t *buffer_ptr,
    uint16_t buffer_size)
{
    if((h == NULL) || (hadc == NULL) || (buffer_ptr == NULL) || (buffer_size == 0U))
    {
        return -1;
    }

    memset(h, 0, sizeof(*h));
    h->hadc = hadc;
    h->htim_trig = htim_trig;
    h->htim_dma = htim_dma;
    h->buffer_ptr = (uint16_t *)buffer_ptr;
    h->fs = fs;
    h->Nch = Nch;
    dataMGR_init(&h->MGR, (char *)buffer_ptr, buffer_size);
    xe_np_adc_regular_dma_configured = 0U;
    xe_np_adc_injected_batt_configured = 0U;
    xe_np_adc_injected_single_configured = 0U;

    (void)CE32_ADC_preInit_Act(h);
    return 0;
}

int CE32_ADC_SwitchVbattSense(CE32_ADC *h, int channel)
{
    return (XE_NP_ADC_ConfigureInjectedSingle(h, (uint32_t)channel) == HAL_OK) ? 0 : -1;
}

int CE32_ADC_StartDMA(CE32_ADC *h)
{
    uint32_t sample_count;

    if((h == NULL) || (h->hadc == NULL) || (h->buffer_ptr == NULL))
    {
        return -1;
    }

    if(h->fs == 0U)
    {
        return 0;
    }

    CE32_ADC_PreStartConfig(h);
    if(XE_NP_ADC_ReinitRegular(
           h,
           ADC_SOFTWARE_START,
           ADC_EXTERNALTRIGCONVEDGE_NONE,
           ADC_CONVERSIONDATA_DMA_CIRCULAR,
           ENABLE) != HAL_OK)
    {
        return -2;
    }

    sample_count = (uint32_t)h->MGR.dataSize / sizeof(uint16_t);
    if(sample_count == 0U)
    {
        return -3;
    }

    if(HAL_ADC_Start_DMA(h->hadc, (uint32_t *)h->buffer_ptr, sample_count) != HAL_OK)
    {
        return -4;
    }

    return 0;
}

int CE32_ADC_StartTimerDMA(CE32_ADC *h)
{
    uint32_t trigger;
    uint32_t sample_count;
    TIM_HandleTypeDef *htim;

    if((h == NULL) || (h->hadc == NULL) || (h->buffer_ptr == NULL))
    {
        return -1;
    }

    if(h->fs == 0U)
    {
        return 0;
    }

    trigger = XE_NP_ADC_MapRegularTrigger(h->htim_trig);
    if(trigger == ADC_SOFTWARE_START)
    {
        return CE32_ADC_StartDMA(h);
    }

    CE32_ADC_PreStartConfig(h);
    if(XE_NP_ADC_ReinitRegular(
           h,
           trigger,
           ADC_EXTERNALTRIGCONVEDGE_RISING,
           ADC_CONVERSIONDATA_DMA_CIRCULAR,
           DISABLE) != HAL_OK)
    {
        return -2;
    }

    htim = h->htim_trig;
    if(XE_NP_ADC_ConfigTriggerTimer(htim, h->fs) != HAL_OK)
    {
        return -3;
    }

    sample_count = (uint32_t)h->MGR.dataSize / sizeof(uint16_t);
    if(sample_count == 0U)
    {
        return -4;
    }

    if(HAL_ADC_Start_DMA(h->hadc, (uint32_t *)h->buffer_ptr, sample_count) != HAL_OK)
    {
        return -5;
    }

    if(HAL_TIM_Base_Start(htim) != HAL_OK)
    {
        XE_NP_ADC_StopRegularSafely(h->hadc);
        return -6;
    }

    return 0;
}

int CE32_ADC_Stop(CE32_ADC *h)
{
    if(h == NULL)
    {
        return -1;
    }

    if((h->htim_trig != NULL) && (h->htim_trig->Instance != NULL))
    {
        (void)HAL_TIM_Base_Stop(h->htim_trig);
    }
    if((h->htim_dma != NULL) && (h->htim_dma->Instance != NULL))
    {
        (void)HAL_TIM_Base_Stop(h->htim_dma);
    }
    if(h->hadc != NULL)
    {
        (void)HAL_ADCEx_InjectedStop(h->hadc);
        XE_NP_ADC_StopRegularSafely(h->hadc);
        xe_np_adc_regular_dma_configured = 0U;
        xe_np_adc_injected_batt_configured = 0U;
        xe_np_adc_injected_single_configured = 0U;
    }
    return 0;
}

int CE32_ADC_StartConversion(CE32_ADC *h)
{
    if((h == NULL) || (h->hadc == NULL))
    {
        return -1;
    }

    if(XE_NP_ADC_ReinitRegular(
           h,
           ADC_SOFTWARE_START,
           ADC_EXTERNALTRIGCONVEDGE_NONE,
           ADC_CONVERSIONDATA_DR,
           DISABLE) != HAL_OK)
    {
        return -2;
    }

    return (HAL_ADC_Start(h->hadc) == HAL_OK) ? 0 : -3;
}

int CE32_ADC_JStartConversion(CE32_ADC *h)
{
    if((h == NULL) || (h->hadc == NULL))
    {
        return -1;
    }

    if((xe_np_adc_injected_batt_configured == 0U) && (xe_np_adc_injected_single_configured == 0U))
    {
        if(XE_NP_ADC_EnsureInjectedBatterySequence(h) != HAL_OK)
        {
            return -2;
        }
    }

    return (HAL_ADCEx_InjectedStart(h->hadc) == HAL_OK) ? 0 : -3;
}

int CE32_ADC_PollJConvertion(CE32_ADC *h)
{
    if((h == NULL) || (h->hadc == NULL))
    {
        return -1;
    }

    if(HAL_ADCEx_InjectedPollForConversion(h->hadc, XE_NP_ADC_INJECTED_TIMEOUT_MS) != HAL_OK)
    {
        return -2;
    }

    h->JDR[0] = (uint16_t)HAL_ADCEx_InjectedGetValue(h->hadc, ADC_INJECTED_RANK_1);
    h->JDR[1] = (uint16_t)HAL_ADCEx_InjectedGetValue(h->hadc, ADC_INJECTED_RANK_2);
    h->JDR[2] = (uint16_t)HAL_ADCEx_InjectedGetValue(h->hadc, ADC_INJECTED_RANK_3);
    h->JDR[3] = (uint16_t)HAL_ADCEx_InjectedGetValue(h->hadc, ADC_INJECTED_RANK_4);
    return 0;
}

int CE32_ADC_ReadInject(CE32_ADC *h)
{
    if((h == NULL) || (h->hadc == NULL))
    {
        return -1;
    }

    if(XE_NP_ADC_EnsureInjectedBatterySequence(h) != HAL_OK)
    {
        return -2;
    }
    if(CE32_ADC_JStartConversion(h) != 0)
    {
        return -3;
    }
    return CE32_ADC_PollJConvertion(h);
}

__weak int CE32_ADC_preInit_Act(CE32_ADC *h)
{
    (void)h;
    return 0;
}

__weak void CE32_ADC_PreStartConfig(CE32_ADC *h)
{
    (void)h;
}

__weak void CE32_ADC_DMA_halfCplt(CE32_ADC *h)
{
    if(h != NULL)
    {
        dataMGR_enQueue_Nbytes(&h->MGR, h->MGR.dataSize / 2U);
    }
}

void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef *hadc)
{
    if((hadc != NULL) && (hadc == ADC_handle.hadc))
    {
        CE32_ADC_DMA_halfCplt(&ADC_handle);
    }
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    if((hadc != NULL) && (hadc == ADC_handle.hadc))
    {
        CE32_ADC_DMA_halfCplt(&ADC_handle);
    }
}

void HAL_ADC_ErrorCallback(ADC_HandleTypeDef *hadc)
{
    if((hadc != NULL) && (hadc == ADC_handle.hadc))
    {
        ADC_handle.MGR.logState |= MGR_STATE_TRANSERR;
    }
}
