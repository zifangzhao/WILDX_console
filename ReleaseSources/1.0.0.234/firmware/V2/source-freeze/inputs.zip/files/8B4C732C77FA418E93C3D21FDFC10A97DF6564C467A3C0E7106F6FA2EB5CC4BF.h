#ifndef XE_NP_IMU_GRID_CONTROL_WIRE_H
#define XE_NP_IMU_GRID_CONTROL_WIRE_H
#include <stddef.h>
#include <stdint.h>

/* Version 2 is advertised only by a build enforcing the grid contract. */
#ifndef XE_NP_GRID_ENFORCED
#define XE_NP_GRID_ENFORCED 0U
#endif
#if XE_NP_GRID_ENFORCED != 0U && XE_NP_GRID_ENFORCED != 1U
#error XE_NP_GRID_ENFORCED must be 0 or 1
#endif
#define XE_NP_GRID_STATUS_VERSION (1U + XE_NP_GRID_ENFORCED)

/* Pure wire serializers; no request dispatch, timer or recording ownership. */
#define XE_NP_GRID_STATUS_BYTES 32U
#define XE_NP_GRID_TERMINAL_BYTES 80U
#define XE_NP_GRID_STATUS_SUPPORTED 1U
#define XE_NP_GRID_STATUS_SELECTED 2U
#define XE_NP_GRID_STATUS_FROZEN 4U
#define XE_NP_GRID_END_FINAL_KNOWN 1U
#define XE_NP_GRID_END_SATURATED 2U
#define XE_NP_GRID_END_ERROR 4U

typedef struct {
    uint32_t uid[3],session,generation,epoch,domain;
    uint64_t token;
} XE_NP_GridWireContext;
typedef struct {
    XE_NP_GridWireContext context;
    uint64_t final_exclusive;
    uint32_t queue_dropped,scheduler_missing,flags;
} XE_NP_GridWireTerminal;

/* Set SATURATED conservatively when the 32-bit representation reaches MAX. */
uint32_t XE_NP_GridWire_ClampCount(uint64_t value,uint32_t *flags);
int XE_NP_GridWire_PackStatus(uint8_t out[XE_NP_GRID_STATUS_BYTES],
    const uint32_t uid[3],uint32_t flags,uint32_t control_revision);
int XE_NP_GridWire_ValidateStatus(const uint8_t *wire,size_t length,
    const uint32_t expected_uid[3]);
int XE_NP_GridWire_PackTerminal(uint8_t out[XE_NP_GRID_TERMINAL_BYTES],
    const XE_NP_GridWireTerminal *terminal);
/* expected must come from the separately admitted recording owner. */
int XE_NP_GridWire_ParseTerminal(const uint8_t *wire,size_t length,
    const XE_NP_GridWireContext *expected,XE_NP_GridWireTerminal *out);
#endif
