#include "xe_np_np2_first_sync_runtime.h"
#include "xe_np_sensors_port.h"
#include "xe_np_board.h"
#if XE_NP_NP2_USB_SOURCE_ENABLE
#include "xe_np_np2_usb_source.h"
#include "xe_np_np2_capture_port.h"
#include "xe_np_usb_aux.h"
#endif
#include <stddef.h>
#include <string.h>

static XE_NP_Sensors sensors;
static I2C_HandleTypeDef *buses[2];
static uint32_t tokens[2];
static uint8_t initialized;
static volatile uint8_t paused;
static uint32_t resume_retry_ms;
#if XE_NP_NP2_FIRST_SYNC_ENABLE
enum {SENSOR_ARCHIVE_LEGACY=0U,SENSOR_ARCHIVE_WAIT=1U,SENSOR_ARCHIVE_FILTER=2U};
static XE_NP_Np2FirstSyncGate *archive_gate;
static uint32_t archive_tick[3];
static uint8_t archive_mode;
#endif
static const XE_NP_SensorSnapshot paused_snapshot={
    .magic=0x31534e53U,.version=1U,
    .error={XE_NP_SENSOR_ERR_BUSY,XE_NP_SENSOR_ERR_DISABLED}
};
XE_NP_SensorSnapshot xe_np_sensor_snapshot[2];
volatile uint32_t xe_np_sensor_snapshot_index;
static const IRQn_Type event_irq[2]={I2C5_EV_IRQn,I2C6_EV_IRQn};
static const IRQn_Type error_irq[2]={I2C5_ER_IRQn,I2C6_ER_IRQn};
typedef char sensor_snapshot_wire_size[(sizeof(XE_NP_SensorSnapshot)==140U)?1:-1];
#if XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE
typedef char sns2_prefix_layout[(offsetof(XE_NP_SensorSnapshot,error)==104U &&
                                 sizeof(XE_NP_SensorSnapshot)>=XE_NP_SENSOR_SD_PACKET_PREFIX_BYTES)?1:-1];
static uint8_t sd_packet[2][XE_NP_SENSOR_SD_PACKET_BYTES];
static XE_NP_SensorSnapshot sd_basis;
static uint32_t sd_packet_index,sd_packet_id;
static uint8_t sd_basis_valid,sd_packet_available;
static int sd_changed(const XE_NP_SensorSnapshot *snapshot)
{
    return snapshot->enabled!=sd_basis.enabled || snapshot->valid!=sd_basis.valid ||
        snapshot->imu_sequence!=sd_basis.imu_sequence ||
        snapshot->mag_sequence!=sd_basis.mag_sequence ||
        snapshot->env_sequence!=sd_basis.env_sequence ||
        snapshot->chip_id[0]!=sd_basis.chip_id[0] || snapshot->chip_id[1]!=sd_basis.chip_id[1] ||
        snapshot->error[0]!=sd_basis.error[0] || snapshot->error[1]!=sd_basis.error[1];
}
static void sd_publish(const XE_NP_SensorSnapshot *snapshot)
{
    uint32_t inactive;
    if(!sd_basis_valid) { sd_basis=*snapshot;sd_basis_valid=1U;return; }
    if(!sd_changed(snapshot))return;
    inactive=sd_packet_index^1U;
    (void)XE_NP_Sensors_EncodeSdPacket(snapshot,sd_packet[inactive]);
    sd_basis=*snapshot;__DMB();sd_packet_index=inactive;
    if(++sd_packet_id==0U)sd_packet_id=1U;
    sd_packet_available=1U;
}
#endif

#if XE_NP_NP2_FIRST_SYNC_ENABLE
static void archive_reset_packet(void)
{
#if XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE
    sd_basis_valid=0U;sd_packet_available=0U;
#endif
}
static void archive_zero_group(XE_NP_SensorSnapshot *out,uint8_t bit)
{
    if(bit==XE_NP_SENSOR_VALID_AG){
        out->imu_sequence=out->imu_tick_ms=out->sensor_time_24=0U;
        memset(out->accel_micro_g,0,sizeof(out->accel_micro_g));
        memset(out->gyro_milli_dps,0,sizeof(out->gyro_milli_dps));
    }else if(bit==XE_NP_SENSOR_VALID_MAG){
        out->mag_sequence=out->mag_tick_ms=0U;
        memset(out->mag_nano_tesla,0,sizeof(out->mag_nano_tesla));
    }else if(bit==XE_NP_SENSOR_VALID_ENV){
        out->env_sequence=out->env_tick_ms=0U;
        out->temperature_centi_c=0;out->pressure_pa=out->humidity_milli_percent=0U;
    }
}
static int archive_copy(const XE_NP_SensorSnapshot *source,XE_NP_SensorSnapshot *out)
{
    uint32_t sequence[3],tick[3];uint8_t available,advancing=0U,admitted,missing;
    if(!source || !out || archive_mode==SENSOR_ARCHIVE_WAIT)return 0;
    *out=*source;
    if(archive_mode!=SENSOR_ARCHIVE_FILTER)return 1;
    if(!archive_gate || !archive_gate->bound || !archive_gate->live ||
       !(archive_gate->released&1U))return 0;
    sequence[0]=source->imu_sequence;sequence[1]=source->mag_sequence;sequence[2]=source->env_sequence;
    tick[0]=source->imu_tick_ms;tick[1]=source->mag_tick_ms;tick[2]=source->env_tick_ms;
    available=(uint8_t)(source->valid&7U);
    /* A group that went invalid cannot truthfully delay an unrelated healthy
     * group forever. Its error/missing state remains in the private copy. */
    missing=(uint8_t)(archive_gate->imu_needed&~available);
    archive_gate->imu_needed&=(uint8_t)~missing;
    archive_gate->imu_flushed&=(uint8_t)~missing;
    archive_gate->imu_ready&=(uint8_t)~missing;
    for(uint8_t i=0U;i<3U;i++)if((archive_gate->imu_needed&(1U<<i)) &&
       (available&(1U<<i)) && sequence[i]!=archive_gate->imu_baseline[i] &&
       (uint32_t)(sequence[i]-archive_gate->imu_baseline[i])<=0x7fffffffU &&
       tick[i]!=archive_tick[i])advancing|=(uint8_t)(1U<<i);
    if(advancing){
        (void)XE_NP_Np2FirstSyncGate_AllowImu(archive_gate,sequence,advancing);
        for(uint8_t i=0U;i<3U;i++)if(advancing&(1U<<i))archive_tick[i]=tick[i];
    }
    admitted=(uint8_t)(archive_gate->imu_ready&archive_gate->imu_needed);
    for(uint8_t i=0U;i<3U;i++)if(!(admitted&(1U<<i)))archive_zero_group(out,(uint8_t)(1U<<i));
    out->valid&=admitted;
    if(archive_gate->imu_ready==archive_gate->imu_needed){
        archive_mode=SENSOR_ARCHIVE_LEGACY;archive_gate=NULL;
    }
    return 1;
}
#endif

static int start(void *ctx,uint8_t bus,uint8_t address,uint8_t reg,uint8_t *data,
                 uint16_t length,uint8_t write,uint32_t token)
{
    HAL_StatusTypeDef status;I2C_HandleTypeDef *h=buses[bus];(void)ctx;
    if(paused)return 1;
    if(!h||!h->Instance)return -1;
    tokens[bus]=token;__DMB();
    /* U5 Mem_*_IT returns HAL_BUSY immediately, without a polling timeout. */
    status=write?HAL_I2C_Mem_Write_IT(h,(uint16_t)(address<<1),reg,I2C_MEMADD_SIZE_8BIT,data,length):
                 HAL_I2C_Mem_Read_IT(h,(uint16_t)(address<<1),reg,I2C_MEMADD_SIZE_8BIT,data,length);
    return status==HAL_OK?0:(status==HAL_BUSY?1:-1);
}
static void stop(void *ctx,uint8_t bus)
{
    I2C_HandleTypeDef *h=buses[bus];(void)ctx;
    HAL_NVIC_DisableIRQ(event_irq[bus]);HAL_NVIC_DisableIRQ(error_irq[bus]);
    if(h&&h->Instance) {
        /* No DMA. Disable IRQs and PE before relinquishing the buffer, even
         * when SDA stays low or a STOP never arrives. No waits or GPIO clocks. */
        CLEAR_BIT(h->Instance->CR1,I2C_CR1_TXIE|I2C_CR1_RXIE|I2C_CR1_ADDRIE|
            I2C_CR1_NACKIE|I2C_CR1_STOPIE|I2C_CR1_TCIE|I2C_CR1_ERRIE|I2C_CR1_PE);
        __DSB();h->XferISR=NULL;
    }
    HAL_NVIC_ClearPendingIRQ(event_irq[bus]);HAL_NVIC_ClearPendingIRQ(error_irq[bus]);
}
static int recover(void *ctx,uint8_t bus)
{
    I2C_HandleTypeDef *h=buses[bus];(void)ctx;
    if(!h||!h->Instance)return -1;
    /* Called only at idle, never in an IRQ or during NP recording. */
    stop(ctx,bus);
    if(HAL_I2C_DeInit(h)!=HAL_OK||HAL_I2C_Init(h)!=HAL_OK)return -1;
    if(HAL_I2CEx_ConfigAnalogFilter(h,I2C_ANALOGFILTER_ENABLE)!=HAL_OK||
       HAL_I2CEx_ConfigDigitalFilter(h,0)!=HAL_OK)return -1;
    HAL_NVIC_EnableIRQ(event_irq[bus]);HAL_NVIC_EnableIRQ(error_irq[bus]);return 0;
}
static void publish(uint32_t now)
{
    uint32_t inactive=xe_np_sensor_snapshot_index^1U;
    XE_NP_Sensors_Snapshot(&sensors,&xe_np_sensor_snapshot[inactive],now);
#if XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE
    const XE_NP_SensorSnapshot *archival=&xe_np_sensor_snapshot[inactive];
#if XE_NP_NP2_FIRST_SYNC_ENABLE
    XE_NP_SensorSnapshot archive;
    if(archive_mode!=SENSOR_ARCHIVE_LEGACY &&
       !archive_copy(&xe_np_sensor_snapshot[inactive],&archive))archival=NULL;
    else if(archive_mode!=SENSOR_ARCHIVE_LEGACY)archival=&archive;
#endif
    if(archival)sd_publish(archival);
#endif
    __DMB();xe_np_sensor_snapshot_index=inactive;
}
void XE_NP_SensorsPort_Init(I2C_HandleTypeDef *imu,I2C_HandleTypeDef *environment)
{
    XE_NP_SensorIo io={NULL,start,stop,recover};uint32_t enabled=XE_NP_SENSOR_MASK_BMX;
#if XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE
    uint8_t resuming=(uint8_t)(initialized && paused==2U);
#endif
    buses[0]=imu;buses[1]=environment;
#if XE_NP_BOARD_BME280_I2C_WIRING_CONFIRMED
    enabled|=XE_NP_SENSOR_MASK_BME;
#endif
    XE_NP_Sensors_Init(&sensors,&io,enabled,HAL_GetTick());
#if XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE
    memset(&sd_basis,0,sizeof(sd_basis));sd_basis_valid=0U;sd_packet_available=0U;
    if(!resuming) {
        memset(sd_packet,0,sizeof(sd_packet));sd_packet_index=sd_packet_id=0U;
    }
#endif
    for(uint8_t i=0;i<2;i++) {
        HAL_NVIC_SetPriority(event_irq[i],7U,0U);HAL_NVIC_SetPriority(error_irq[i],7U,0U);
        if((enabled&(1UL<<i))&&buses[i]&&buses[i]->Instance) {
            HAL_NVIC_ClearPendingIRQ(event_irq[i]);HAL_NVIC_ClearPendingIRQ(error_irq[i]);
            HAL_NVIC_EnableIRQ(event_irq[i]);HAL_NVIC_EnableIRQ(error_irq[i]);
        } else stop(NULL,i);
    }
    paused=0U;initialized=1;publish(HAL_GetTick());
}
void XE_NP_SensorsPort_Pause(void)
{
    if(!initialized)return;
    uint32_t key=__get_PRIMASK();__disable_irq();
    paused=1U;
    for(uint8_t i=0U;i<2U;i++)stop(NULL,i);
    sensors.snapshot.valid=0U;__DMB();__set_PRIMASK(key);
}
void XE_NP_SensorsPort_Resume(void)
{
    /* Re-initialize dedicated controllers/driver only on the next foreground
     * pass. No sensor transaction spans a PCLK transition; IRQ never waits. */
    if(initialized && paused){__DMB();paused=2U;}
}
void XE_NP_SensorsPort_Service(uint8_t recording)
{
    uint32_t now;
    if(!initialized)return;
    if(paused==1U)return;
#if XE_NP_NP2_USB_SOURCE_ENABLE
    /* The retained USB consumer calls all probe preparation busy. Its stable
     * analog settle is safe for setup on these dedicated I2C controllers.
     * Never query source status after setup, or while acquisition/aux is armed. */
    if(recording && (paused==2U || (!paused && !sensors.device[0].configured)) &&
       !XE_NP_Np2CapturePort_Armed()
#if XE_NP_IMAGE_ROLE==2U
       && !XE_NP_UsbAux_IsRunning()
#endif
       ){
        XE_NP_Np2UsbSourceStatus source_status;
        XE_NP_Np2UsbSource_GetStatus(&source_status);
        if(source_status.state==XE_NP_NP2_USB_SOURCE_SETTLING)recording=0U;
    }
#endif
    now=HAL_GetTick();
    if(paused==3U){
        /* A failed stopped-clock resume must not latch the sensors off.
         * Retry only at idle, never during NP preparation or recording. */
        if(recording || (int32_t)(now-resume_retry_ms)<0)return;
        paused=2U;
    }
    if(paused==2U){
        if(recording)return;
        for(uint8_t i=0U;i<2U;i++){
            I2C_HandleTypeDef *h=buses[i];
            if(!h || !h->Instance || !sensors.device[i].enabled)continue;
            /* One bounded initialization after an explicit stopped profile
             * change, not periodic fault recovery while recording. */
            h->State=HAL_I2C_STATE_READY;h->Lock=HAL_UNLOCKED;
            if(HAL_I2C_Init(h)!=HAL_OK ||
               HAL_I2CEx_ConfigAnalogFilter(h,I2C_ANALOGFILTER_ENABLE)!=HAL_OK ||
               HAL_I2CEx_ConfigDigitalFilter(h,0U)!=HAL_OK){
                for(uint8_t bus=0U;bus<2U;bus++)stop(NULL,bus);
                resume_retry_ms=now+2000U;paused=3U;return;
            }
        }
        XE_NP_SensorsPort_Init(buses[0],buses[1]);
    }
    now=HAL_GetTick();XE_NP_Sensors_Service(&sensors,now,recording);
    if(xe_np_sensor_snapshot[xe_np_sensor_snapshot_index].published_ms!=now)publish(now);
}
int XE_NP_SensorsPort_Complete(I2C_HandleTypeDef *h,uint32_t error)
{
    if(!initialized || paused)return 0;
    for(uint8_t i=0;i<2;i++)if(h==buses[i]) {
        __DMB();XE_NP_Sensors_Complete(&sensors,i,tokens[i],error,HAL_GetTick());__DMB();
        return 1;
    }
    return 0;
}
const XE_NP_SensorSnapshot *XE_NP_SensorsPort_GetSnapshot(void)
{
    if(paused)return &paused_snapshot;
    uint32_t index=xe_np_sensor_snapshot_index;__DMB();return &xe_np_sensor_snapshot[index];
}
void XE_NP_SensorsPort_FirstSyncWait(void)
{
#if XE_NP_NP2_FIRST_SYNC_ENABLE
    archive_gate=NULL;archive_mode=SENSOR_ARCHIVE_WAIT;archive_reset_packet();
#endif
}
int XE_NP_SensorsPort_FirstSyncRelease(XE_NP_Np2FirstSyncGate *gate)
{
#if XE_NP_NP2_FIRST_SYNC_ENABLE
    const XE_NP_SensorSnapshot *snapshot;uint32_t sequence[3];uint8_t groups;
    if(!initialized || paused || !gate || !gate->bound || !gate->live || !(gate->released&1U) ||
       archive_mode!=SENSOR_ARCHIVE_WAIT)return 0;
    snapshot=XE_NP_SensorsPort_GetSnapshot();groups=(uint8_t)(snapshot->valid&7U);
    sequence[0]=snapshot->imu_sequence;sequence[1]=snapshot->mag_sequence;sequence[2]=snapshot->env_sequence;
    archive_tick[0]=snapshot->imu_tick_ms;archive_tick[1]=snapshot->mag_tick_ms;archive_tick[2]=snapshot->env_tick_ms;
    XE_NP_Np2FirstSyncGate_ImuBaseline(gate,sequence,groups);
    archive_gate=gate;archive_mode=SENSOR_ARCHIVE_FILTER;archive_reset_packet();return 1;
#else
    (void)gate;return 0;
#endif
}
void XE_NP_SensorsPort_FirstSyncLegacy(void)
{
#if XE_NP_NP2_FIRST_SYNC_ENABLE
    archive_gate=NULL;archive_mode=SENSOR_ARCHIVE_LEGACY;archive_reset_packet();
#endif
}
int XE_NP_SensorsPort_CopyArchive(XE_NP_SensorSnapshot *out)
{
    if(!out || !initialized || paused)return 0;
#if XE_NP_NP2_FIRST_SYNC_ENABLE
    return archive_copy(XE_NP_SensorsPort_GetSnapshot(),out);
#else
    *out=*XE_NP_SensorsPort_GetSnapshot();return 1;
#endif
}
const uint8_t *XE_NP_SensorsPort_GetSdPacket(uint32_t *publication_id)
{
#if XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE
    uint32_t index;
    if(publication_id)*publication_id=0U;
    if(!initialized || paused || !sd_packet_available
#if XE_NP_NP2_FIRST_SYNC_ENABLE
       || archive_mode==SENSOR_ARCHIVE_WAIT
#endif
       )return NULL;
    index=sd_packet_index;__DMB();if(publication_id)*publication_id=sd_packet_id;
#if XE_NP_NP2_FIRST_SYNC_ENABLE
    if((np_first_u32(sd_packet[index]+12U)&XE_NP_SENSOR_VALID_AG) && np_first_u32(sd_packet[index]+20U))
        XE_NP_Np2FirstSyncRuntime_AuxAccepted(1U,np_first_u32(sd_packet[index]+20U),32U,200U,1U);
#endif
    return sd_packet[index];
#else
    if(publication_id)*publication_id=0U;
    return NULL;
#endif
}
