#include "xe_np_np2_first_sync_port.h"
#if XE_NP_NP2_FIRST_SYNC_ENABLE
static XE_NP_Np2FirstSyncPort *port;
typedef void (*Observer)(const uint8_t *,uint32_t,XE_NP_Np2FirstSyncViewRetained,void *);
static void idle(const uint8_t *b,uint32_t n,XE_NP_Np2FirstSyncViewRetained r,void *u)
{(void)b;(void)n;(void)r;(void)u;}
static Observer observer=idle;
static void idle_commit(const uint8_t *b){(void)b;}
static void commit(const uint8_t *);
static void (*committer)(const uint8_t *)=idle_commit;
static int same(const NpFirstSyncBinding *a,const NpFirstSyncBinding *b)
{return a->session==b->session && a->generation==b->generation && a->source_epoch==b->source_epoch &&
    a->domain==b->domain && a->counter_hz==b->counter_hz && a->profile_crc==b->profile_crc &&
    a->family==b->family && a->mask==b->mask && a->ap_hz==b->ap_hz;}
static int retained(void *user)
{
    XE_NP_Np2FirstSyncPort *s=user;NpFirstSyncBinding current;XE_NP_Np2FirstSyncPoint point;
    if(port!=s || !s->gate.bound || (s->retained && !s->retained(s->private_block,XE_NP_NP2_FIRST_SYNC_BLOCK_BYTES,s->retained_user)) ||
       !s->owner(s->user,&current,&point) || !same(&s->observed,&current))return 0;
    s->discovery=point;return 1;
}
static void observe(const uint8_t *block,uint32_t bytes,XE_NP_Np2FirstSyncViewRetained guard,void *user)
{
    XE_NP_Np2FirstSyncPort *s=port;observer=idle;
    if(!s || !s->owner(s->user,&s->observed,&s->discovery) ||
       !XE_NP_Np2FirstSyncGate_Begin(&s->gate,&s->observed,s->aux_mask,s->source_mapping))return;
    s->private_block=block;s->retained=guard;s->retained_user=user;
    s->pending=(uint8_t)XE_NP_Np2FirstSyncGate_Stage(&s->gate,&s->observed,block,bytes,&s->discovery,retained,s);
    if(s->pending)committer=commit;
}
int XE_NP_Np2FirstSyncPort_Bind(XE_NP_Np2FirstSyncPort *s,XE_NP_Np2FirstSyncOwner owner,XE_NP_Np2FirstSyncOpened opened,void *user,uint8_t aux,int mapped)
{
    if(!s || !owner || (aux&~15U) || (port && port->gate.bound))return 0;
    memset(s,0,sizeof(*s));s->owner=owner;s->opened=opened;s->user=user;s->aux_mask=aux;s->source_mapping=(uint8_t)(mapped!=0);
    port=s;observer=observe;committer=idle_commit;return 1;
}
void XE_NP_Np2FirstSyncPort_Private(const uint8_t *b,uint32_t n,XE_NP_Np2FirstSyncViewRetained r,void *u)
{observer(b,n,r,u);}
static void commit(const uint8_t *block)
{
    XE_NP_Np2FirstSyncPort *s=port;
    if(!s || !s->pending || block!=s->private_block)return;
    s->pending=0U;committer=idle_commit;
    if(XE_NP_Np2FirstSyncGate_Commit(&s->gate,&s->observed,retained,s) && s->opened)
        s->opened(s->user,&s->gate,&s->observed);
    s->private_block=NULL;s->retained=NULL;s->retained_user=NULL;
}
void XE_NP_Np2FirstSyncPort_Commit(const uint8_t *b){committer(b);}
void XE_NP_Np2FirstSyncPort_Invalidate(void)
{observer=idle;committer=idle_commit;if(port){XE_NP_Np2FirstSyncGate_Invalidate(&port->gate);port->pending=0U;}}
XE_NP_Np2FirstSyncGate *XE_NP_Np2FirstSyncPort_Gate(void)
{return port?&port->gate:NULL;}
#endif
