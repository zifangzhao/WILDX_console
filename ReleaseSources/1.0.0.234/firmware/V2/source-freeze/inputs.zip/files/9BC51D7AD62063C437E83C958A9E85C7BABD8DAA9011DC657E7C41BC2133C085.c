#include "xe_np_imu_grid_provider.h"
#include "np_first_sync_wire.h"
#include "np_imu_grid_wire.h"
#include "np_imu_grid_phase.h"
#include <string.h>

#define TYPE_GRID 5U
#define TYPE_PHASE 6U
#define TYPE_END 7U

void XE_NP_GridProvider_Init(XE_NP_GridProvider *p)
{if(p)memset(p,0,sizeof(*p));}
int XE_NP_GridProvider_Attach(XE_NP_GridProvider *p,XE_NP_GridRuntime *r,
    const XE_NP_GridWireContext *id,const uint8_t *receipt,uint32_t receipt_bytes,
    const uint8_t *anchor,uint32_t anchor_bytes,uint64_t base_ordinal,
    uint32_t clock_qualified,uint32_t copy_bound_qualified)
{
    NpImuGridPhaseBinding b={0};XE_NP_GridRuntimeStatus st;
    uint32_t low,width;
    if(!p || p->attached || !r || !id || !receipt || !anchor || receipt_bytes!=NP_FIRST_SYNC_BYTES ||
       anchor_bytes!=64U || base_ordinal==UINT64_MAX || clock_qualified>1U || copy_bound_qualified>1U)return 0;
    for(uint32_t i=0U;i<3U;i++)np_first_put32(b.uid+4U*i,id->uid[i]);
    b.session=id->session;b.capture_generation=id->generation;b.source_epoch=id->epoch;
    b.counter_domain=id->domain;b.token=id->token;
    if(!np_imu_grid_phase_binding_valid(&b) || !np_first_sync_source_anchor_valid(anchor,receipt) ||
       ((np_first_u32(receipt+12U)>>8U)&255U)!=2U ||
       np_first_u32(receipt+16U)!=id->session || np_first_u32(receipt+20U)!=id->generation ||
       np_first_u32(receipt+24U)!=id->epoch || np_first_u32(receipt+28U)!=id->domain ||
       np_first_u32(receipt+40U)!=1000000U)return 0;
    XE_NP_GridRuntime_GetStatus(r,&st);
    if(r->domain!=id->domain || r->generation!=id->generation || r->epoch!=id->epoch ||
       !r->schedule.active || st.terminal_known)return 0;
    memset(p,0,sizeof(*p));p->runtime=r;p->identity=*id;p->base_ordinal=base_ordinal;
    low=np_first_u32(anchor+28U);width=np_first_u32(anchor+32U)-low;
    p->phase.source_before_us=low;p->phase.source_after_us=(uint64_t)low+width;
    p->phase.timer_start_before_us=st.start_before;p->phase.timer_start_after_us=st.start_after;
    p->phase.source_origin_tick=np_first_u64(anchor+44U);p->phase.reference_tick=np_first_u64(receipt+52U);
    p->phase.source_hz=np_first_u32(receipt+32U);p->phase.max_copy_lateness_us=r->max_lateness;
    p->phase.continuous_clock_qualified=(uint8_t)clock_qualified;
    p->phase.copy_bound_qualified=(uint8_t)copy_bound_qualified;p->attached=1U;return 1;
}
void XE_NP_GridProvider_Finish(XE_NP_GridProvider *p,int cutoff_valid,uint64_t cutoff_us)
{
    if(!p || !p->attached || p->stopped)return;
    XE_NP_GridRuntime_Stop(p->runtime,cutoff_valid,cutoff_us);p->stopped=1U;
}
/* At most twelve rows per call; don't let an uncertain or pre-origin prefix
 * become valid-looking NP-aligned signal. No source-clock proof => incomplete. */
static int first_after_source(XE_NP_GridProvider *p)
{
    for(uint32_t i=0U;i<NP_IMU_GRID_MAX_SLOTS;i++){
        int after;
        if(!p->has_held){
            if(!XE_NP_GridRuntime_Pop(p->runtime,&p->held))return 0;
            p->has_held=1U;
        }
        if(p->held.ordinal<p->base_ordinal)return -1;
        p->phase.first_relative_slot=p->held.ordinal-p->base_ordinal;
        after=XE_NP_GridPhaseBound_AfterSource(&p->phase);
        if(after<0)return -1;
        if(after)return 1;
        if(p->discarded_prefix==UINT64_MAX)return -1;
        p->discarded_prefix++;p->has_held=0U;
    }
    return 0;
}
int XE_NP_GridProvider_Prime(XE_NP_GridProvider *p,uint64_t *ordinal)
{
    int result;
    if(!p || !ordinal || !p->attached || !p->runtime || p->stopped || p->incomplete ||
       p->phase_done || p->pending || p->inflight || p->terminal_done)return -1;
    result=first_after_source(p);
    if(result<0){p->incomplete=1U;return -1;}
    if(result>0)*ordinal=p->held.ordinal;
    return result;
}
static int phase_record(XE_NP_GridProvider *p)
{
    NpImuGridPhaseRecord q={0};XE_NP_GridPhaseBound bound;
    XE_NP_GridRuntimeFirstAccepted first;
    if(p->held.ordinal<p->base_ordinal)return 0;
    for(uint32_t i=0U;i<3U;i++)np_first_put32(q.binding.uid+4U*i,p->identity.uid[i]);
    q.binding.session=p->identity.session;q.binding.capture_generation=p->identity.generation;
    q.binding.source_epoch=p->identity.epoch;q.binding.counter_domain=p->identity.domain;
    q.binding.token=p->identity.token;q.first_accepted_slot=p->held.ordinal;
    p->phase.first_relative_slot=p->held.ordinal-p->base_ordinal;
    if(XE_NP_GridPhaseBound_Compute(&p->phase,&bound)){
        q.lower_numerator=bound.lower_numerator;q.upper_numerator=bound.upper_numerator;
        q.denominator=bound.denominator;q.maximum_jitter=bound.maximum_relative_jitter_ticks;
        q.flags=NP_IMU_GRID_PHASE_INTERVAL_VALID|NP_IMU_GRID_PHASE_JITTER_VALID;
    }else if(XE_NP_GridRuntime_GetFirstAccepted(p->runtime,&first) &&
             first.ordinal==p->held.ordinal && first.domain==p->identity.domain &&
             first.generation==p->identity.generation && first.epoch==p->identity.epoch &&
             XE_NP_GridPhaseBound_First(&p->phase,first.before,first.after,&bound)){
        /* A real first copy only. Later jitter and clock continuity are unknown. */
        q.lower_numerator=bound.lower_numerator;q.upper_numerator=bound.upper_numerator;
        q.denominator=bound.denominator;q.maximum_jitter=UINT32_MAX;
        q.flags=NP_IMU_GRID_PHASE_INTERVAL_VALID;
    }else{
        q.lower_numerator=INT64_MIN;q.upper_numerator=INT64_MIN;
        q.denominator=0U;q.maximum_jitter=UINT32_MAX;q.flags=0U;
    }
    if(!np_imu_grid_phase_pack(p->body,NP_IMU_GRID_PHASE_BYTES,&q))return 0;
    p->pending_type=TYPE_PHASE;p->pending_bytes=NP_IMU_GRID_PHASE_BYTES;
    p->pending_source=q.first_accepted_slot;p->pending_end=q.first_accepted_slot;p->pending=1U;return 1;
}
static int rows_record(XE_NP_GridProvider *p,uint32_t draining)
{
    NpImuGridHeader h={0};int32_t rows[NP_IMU_GRID_MAX_SLOTS][9];
    uint32_t n=0U;uint64_t first,last;size_t count;
    if(!p->has_held){
        if(!XE_NP_GridRuntime_Pop(p->runtime,&p->held))return 0;
        p->has_held=1U;
    }
    if(!draining && !p->stopped &&
       (uint32_t)(p->runtime->queue.head-p->runtime->queue.tail)+1U<NP_IMU_GRID_MAX_SLOTS)return 0;
    first=p->held.ordinal;last=first;
    if((p->have_last && first<p->last_end) || first>UINT64_MAX-NP_IMU_GRID_MAX_SLOTS)return -1;
    h.first_slot=first;h.capture_generation=p->identity.generation;
    for(;;){
        XE_NP_ImuGridSlot *s=&p->held;uint64_t index;
        if(s->ordinal<first || (n && s->ordinal<=last))return -1;
        index=s->ordinal-first;
        if(index>=NP_IMU_GRID_MAX_SLOTS)break;
        uint16_t bit=(uint16_t)(1U<<(uint32_t)index);
        h.observed_mask|=bit;
        if(s->flags&XE_NP_IMU_GRID_AG_VALID)h.ag_valid|=bit;
        if(s->flags&XE_NP_IMU_GRID_MAG_VALID)h.mag_valid|=bit;
        if(s->flags&XE_NP_IMU_GRID_AG_REPEAT)h.ag_repeat|=bit;
        if(s->flags&XE_NP_IMU_GRID_MAG_REPEAT)h.mag_repeat|=bit;
        if(s->flags&XE_NP_IMU_GRID_ERROR)h.error_mask|=bit;
        memcpy(rows[n],s->values,sizeof(rows[n]));n++;last=s->ordinal;p->has_held=0U;
        if(n==NP_IMU_GRID_MAX_SLOTS || !XE_NP_GridRuntime_Pop(p->runtime,&p->held))break;
        p->has_held=1U;
    }
    h.slot_count=(uint16_t)(last-first+1U);
    count=np_imu_grid_pack(p->body,sizeof(p->body),&h,(const int32_t (*)[9])rows,n);
    if(!count)return -1;
    p->pending_type=TYPE_GRID;p->pending_bytes=(uint32_t)count;
    p->pending_source=first;p->pending_end=last+1U;p->pending=1U;return 1;
}
static int terminal_record(XE_NP_GridProvider *p)
{
    XE_NP_GridRuntimeStatus s;XE_NP_GridWireTerminal end={0};uint64_t missing;
    XE_NP_GridRuntime_GetStatus(p->runtime,&s);end.context=p->identity;
    end.final_exclusive=s.terminal_known?s.terminal_exclusive:UINT64_MAX;
    if(s.terminal_known)end.flags|=XE_NP_GRID_END_FINAL_KNOWN;
    /* Unknown cutoff is distinct from a detected scheduler/data fault. */
    if(s.counter_faults || s.scheduler_faults || s.late_copies || p->discarded_prefix)
        end.flags|=XE_NP_GRID_END_ERROR;
    end.queue_dropped=XE_NP_GridWire_ClampCount(s.queue_dropped,&end.flags);
    missing=s.scheduler_missing>UINT64_MAX-p->discarded_prefix?UINT64_MAX:
        s.scheduler_missing+p->discarded_prefix;
    end.scheduler_missing=XE_NP_GridWire_ClampCount(missing,&end.flags);
    if(!XE_NP_GridWire_PackTerminal(p->body,&end))return 0;
    p->pending_type=TYPE_END;p->pending_bytes=XE_NP_GRID_TERMINAL_BYTES;
    p->pending_source=end.final_exclusive;p->pending_end=end.final_exclusive;p->pending=1U;return 1;
}
int XE_NP_GridProvider_Next(void *context,uint8_t *staging,uint32_t capacity,
    uint32_t *type,uint32_t *bytes,uint64_t *source,uint32_t draining)
{
    XE_NP_GridProvider *p=context;int status;
    if(!p || !p->attached || !staging || !type || !bytes || !source)return -1;
    if(p->incomplete)return 2;
    if(p->terminal_done || p->inflight)return 0;
    if(!p->pending){
        if(!p->phase_done){
            status=first_after_source(p);
            if(status<0){p->incomplete=1U;return -1;}
            if(status>0 && !phase_record(p)){p->incomplete=1U;return -1;}
            /* A bounded scan may have more discarded prefix waiting. */
            if(!status && (uint32_t)(p->runtime->queue.head-p->runtime->queue.tail))return 0;
            if(!status && (!draining || !p->stopped))return 0;
        }
        if(!p->pending && p->phase_done){
            status=rows_record(p,draining);
            if(status<0){p->incomplete=1U;return -1;}
        }
        if(!p->pending){
            if(!draining || !p->stopped || p->has_held)return 0;
            if(!terminal_record(p)){p->incomplete=1U;return -1;}
        }
    }
    if(capacity<p->pending_bytes){p->incomplete=1U;return -1;}
    memcpy(staging,p->body,p->pending_bytes);*type=p->pending_type;
    *bytes=p->pending_bytes;*source=p->pending_source;p->inflight=1U;return 1;
}
void XE_NP_GridProvider_Complete(void *context,uint32_t type,uint32_t delivered)
{
    XE_NP_GridProvider *p=context;
    if(!p || !p->attached || !p->pending || !p->inflight || type!=p->pending_type){
        if(p)p->incomplete=1U;return;
    }
    p->inflight=0U;
    /* An abort does not tell us which bytes reached host: no blind replay. */
    if(delivered!=1U){p->incomplete=1U;return;}
    if(type==TYPE_PHASE)p->phase_done=1U;
    else if(type==TYPE_GRID){p->last_end=p->pending_end;p->have_last=1U;}
    else if(type==TYPE_END)p->terminal_done=1U;
    else{p->incomplete=1U;return;}
    p->pending=0U;
}
int XE_NP_GridProvider_Incomplete(const XE_NP_GridProvider *p)
{return !p || p->incomplete;}
