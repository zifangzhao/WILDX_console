#ifndef XE_NP_RTC_ONLINE_H
#define XE_NP_RTC_ONLINE_H
#include <stdint.h>
#include "xe_np_rtc.h"
/* Explicit NPT2v2 only. V1 RAM clock is owned by its unchanged adapter. */
void XE_NP_RtcOnline_Init(void);
void XE_NP_RtcOnline_Invalidate(void);
int XE_NP_RtcOnline_Service(void);
int XE_NP_RtcOnline_Exchange(const uint8_t in[64],uint8_t out[64],
    uint32_t received_ms,uint32_t state,uint32_t can_commit);
/* Tagged64B existing mailbox. Return1 if NPT2 owns the body (including an
 * invalid/unsupported request),0 leaves the original NPC2 dispatch untouched. */
int XE_NP_RtcOnline_Mailbox(const uint8_t in[64],uint8_t out[64],
    uint32_t received_ms,uint32_t state,uint32_t can_commit);
uint32_t XE_NP_RtcOnline_Generation(void);
uint32_t XE_NP_RtcOnline_Uncertainty(void);
/* RAM declaration only; caller must bind a cached calibrated RTC sample. */
uint32_t XE_NP_RtcOnline_DeclaredUncertainty(void);
/* Calendar conversion is command/startup-only, never in acquisition service. */
int XE_NP_RtcOnline_Utc(const XE_NP_RtcSample *sample,uint64_t *utc_us);
#endif
