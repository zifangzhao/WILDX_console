#include "imu_grid_schedule.h"
#include <limits.h>

int XE_NP_GridSchedule_Init(XE_NP_GridSchedule *s,uint64_t first_due_us,
    uint64_t first_ordinal,uint32_t max_lateness_us)
{
    if(!s || max_lateness_us>=XE_NP_GRID_PERIOD_US ||
       first_due_us>UINT64_MAX-XE_NP_GRID_PERIOD_US || first_ordinal==UINT64_MAX)return 0;
    s->next_due_us=first_due_us;s->next_ordinal=first_ordinal;
    s->last_now_us=0U;s->missed=0U;s->max_lateness_us=max_lateness_us;
    s->active=1U;s->has_now=0U;return 1;
}

/* A small 32-bit divide by a compile-time constant remains bounded on M33;
 * keeping the checked delta 32-bit avoids 64-bit division in the slot path. */
static int advance(XE_NP_GridSchedule *s,uint32_t periods,uint64_t missing)
{
    uint64_t delta=(uint64_t)periods*XE_NP_GRID_PERIOD_US;
    if(s->next_due_us>UINT64_MAX-delta || s->next_ordinal>UINT64_MAX-periods ||
       s->missed>UINT64_MAX-missing){s->active=0U;return 0;}
    s->next_due_us+=delta;s->next_ordinal+=periods;s->missed+=missing;return 1;
}

XE_NP_GridEvent XE_NP_GridSchedule_Service(XE_NP_GridSchedule *s,
    uint64_t now_us,XE_NP_GridDecision *d)
{
    uint64_t elapsed,ordinal;uint32_t before,late,periods;uint64_t missing;
    if(!s || !d || !s->active)return XE_NP_GRID_INVALID;
    if(s->has_now && now_us<s->last_now_us){s->active=0U;return XE_NP_GRID_INVALID;}
    s->last_now_us=now_us;s->has_now=1U;
    if(now_us<s->next_due_us)return XE_NP_GRID_WAIT;
    elapsed=now_us-s->next_due_us;
    if(elapsed>XE_NP_GRID_MAX_UNSERVICED_US){s->active=0U;return XE_NP_GRID_INVALID;}
    before=(uint32_t)elapsed/XE_NP_GRID_PERIOD_US;
    late=(uint32_t)elapsed-before*XE_NP_GRID_PERIOD_US;
    periods=before+1U;missing=(uint64_t)before+(late>s->max_lateness_us?1U:0U);
    if(s->next_ordinal>UINT64_MAX-before){s->active=0U;return XE_NP_GRID_INVALID;}
    ordinal=s->next_ordinal+before;
    if(!advance(s,periods,missing))return XE_NP_GRID_INVALID;
    d->ordinal=ordinal;d->skipped=missing;d->lateness_us=late;
    return late>s->max_lateness_us?XE_NP_GRID_MISSED:XE_NP_GRID_SAMPLE;
}

int XE_NP_GridSchedule_Stop(XE_NP_GridSchedule *s,uint64_t stop_us,
    uint64_t *final_exclusive_ordinal,uint64_t *newly_missed)
{
    uint64_t elapsed;uint32_t periods=0U;
    if(!s || !s->active || !final_exclusive_ordinal || !newly_missed)return 0;
    if(s->has_now && stop_us<s->last_now_us){s->active=0U;return 0;}
    if(stop_us>=s->next_due_us){
        elapsed=stop_us-s->next_due_us;
        if(elapsed>XE_NP_GRID_MAX_UNSERVICED_US){s->active=0U;return 0;}
        periods=(uint32_t)elapsed/XE_NP_GRID_PERIOD_US+1U;
        if(!advance(s,periods,periods))return 0;
    }
    *final_exclusive_ordinal=s->next_ordinal;*newly_missed=periods;
    s->active=0U;return 1;
}
