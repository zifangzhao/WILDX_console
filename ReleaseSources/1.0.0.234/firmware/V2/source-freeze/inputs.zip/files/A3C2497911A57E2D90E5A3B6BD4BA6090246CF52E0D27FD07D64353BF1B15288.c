#include "CE32_UART_INTERCOM.h"
#include "CE32_ClosedLoop.h"
#include "CE32_Sync.h"
#include <string.h>
extern RTC_HandleTypeDef hrtc;
static volatile uint8_t ce32_intercom_reset_isr_req = 0U;

__weak void CE32_INTERCOM_TX_Launch_Act(CE32_INTERCOM_Handle *handle_IC, const uint8_t *data, uint32_t data_len)
{
	(void)handle_IC;
	(void)data;
	(void)data_len;
}

__weak void CE32_INTERCOM_RX_Byte_Act(CE32_INTERCOM_Handle *handle_IC, uint8_t data)
{
	(void)handle_IC;
	(void)data;
}

__weak void CE32_INTERCOM_RX_FrameComplete_Act(
	CE32_INTERCOM_Handle *handle_IC,
	const uint8_t *data,
	uint32_t data_len)
{
	(void)handle_IC;
	(void)data;
	(void)data_len;
}

static uint8_t CE32_INTERCOM_ResetPatternDetect(uint8_t b)
{
	/* Detect exact framed reset command: < 0xAB 0xBA > */
	static uint8_t st = 0U;
	switch(st)
	{
		case 0U:
			if(b==INTERCOM_PKG_HEAD){ st = 1U; }
			break;
		case 1U:
			if(b==0xABU){ st = 2U; }
			else if(b==INTERCOM_PKG_HEAD){ st = 1U; }
			else { st = 0U; }
			break;
		case 2U:
			if(b==0xBAU){ st = 3U; }
			else if(b==INTERCOM_PKG_HEAD){ st = 1U; }
			else { st = 0U; }
			break;
		case 3U:
			if(b==INTERCOM_PKG_TAIL)
			{
				st = 0U;
				return 1U;
			}
			if(b==INTERCOM_PKG_HEAD){ st = 1U; }
			else { st = 0U; }
			break;
		default:
			st = 0U;
			break;
	}
	return 0U;
}

/* Binary V1 configuration and mode packets use arbitrary 64-byte payloads.
 * They must retain the legacy `< AB BA >` reset detector outside a frame, but
 * an identical byte sequence inside B8/B9 must remain ordinary payload data. */
static uint8_t CE32_INTERCOM_ResetSniffByte(const CE32_command *command, uint8_t data)
{
	if((command != NULL) && (command->stream_in.logging != 0U) &&
	   (command->stream_in.addr != NULL))
	{
		const uint8_t command_id = ((const uint8_t *)command->stream_in.addr)[0];
		if((command_id == 0xB8U) || (command_id == 0xB9U))
		{
			return 0U;
		}
	}
	return data;
}

#define PUSH_RX_CMD handle->cmd_RX_idx_rec=ADD_CHKBDR(handle->cmd_RX_idx_rec,1,INTERCOM_CMD_SEQ);\
										handle->cmd_RX_pending++;\
										handle->state&=~CMD_STATE_RX_BUSY;
										
#define ENABLE_TX(__handle__) (__handle__)->UART->CR1|=USART_CR1_TXEIE|USART_CR1_UE|USART_CR1_TE;


void CE32_INTERCOM_Init(CE32_INTERCOM_Handle *handle,UART_HandleTypeDef *huart)
{
	CE32_INTERCOM_UART_Init(huart);
	handle->huart=huart;
	handle->UART=huart->Instance;
	handle->state = 0;
	CE32_COMMAND_Init(&handle->CMD_RX);
	CE32_COMMAND_Init(&handle->CMD_TX);
	dataMGR_init(&handle->MGR_RX,(char*) handle->CMD_RX.buffer,INTERCOM_RX_BUF_SIZE);//init RX buffer
}

void CE32_INTERCOM_UART_Init(UART_HandleTypeDef *huart)
{
//  huart->Init.BaudRate = 115200;
//  huart->Init.WordLength = UART_WORDLENGTH_8B;
//  huart->Init.StopBits = UART_STOPBITS_1;
//  huart->Init.Parity = UART_PARITY_NONE;
//  huart->Init.Mode = UART_MODE_TX_RX;
//  huart->Init.HwFlowCtl = UART_HWCONTROL_NONE;
//  huart->Init.OverSampling = UART_OVERSAMPLING_16;
//  if (HAL_UART_Init(huart) != HAL_OK)
//  {
//    //Error_Handler();
//  }
}
#ifdef __BLE_HOST
//Return incoming data load length
int CE32_INTERCOM_Incoming_CMD_Len(int index)
{
	int resp=-1;
	switch(index) //Check if received data length fulfilled standard
	{
		case 0x01:   //SUBMOD: sync sysParam payload
			resp=513;
			break;
		case 0x30:
			resp=1;
			break;
		case 0x31:
			resp=1;
			break;
		case 0x40:
			resp=1;
			break;
		case 0x41:
			resp=1;
			break;
		case 0x42:
			resp=2;
			break;
		case 0x80:   //SUBMOD handshake V1
			resp=1;
			break;
		case 0x82:   //SUBMOD sync-state / ready report
			resp=4;
			break;
		case 0x83:   //SUBMOD force trigger
			resp=2;
			break;
		case 0x89:   //SUBMOD resync request
			resp=1;
			break;
		case 0x8A:   //SUBMOD RTC write (date+time)
			resp=1+sizeof(RTC_DateTypeDef)+sizeof(RTC_TimeTypeDef);
			break;
		case 0xA1: //SUBMOD role override
			resp=2;
			break;
		case 0xAB:   //SUBMOD software reset
			resp=2;
			break;
		case 0x90:   //Send system parameter
			resp=513;
			break;
		case 0x91:	//Send DSP1
			resp=513;
			break;
		case 0x92:	//Send DSP2
			resp=513;
			break;
		case 0xAD:	//Incoming data
			resp=9+128;
			break;
		
		case 0xB0:	//Interface: report version
			resp=3;
			break;
		
		case 0xB1:	//Interface: report version
			resp=3;
			break;
		
		case 0xC0:	//Control Port function
			resp=2;
			break;
		
		case 0xF0: //LPF test
			resp=513;
			break;
		case 0xF1: //mainFil1 test
			resp=513;
			break;
		case 0xF2: //mainFIl2 test
			resp=513;
			break;
		case 0xF3: //maFIL1 test
			resp=513;
			break;
		case 0xF4: //maFil2 test
			resp=513;
			break;
	}
	return resp;
}
#else
int CE32_INTERCOM_Incoming_CMD_Len(int index)
{
	int resp=0;
	switch(index){ //Check if received data length fulfilled standard
	case 0x01: //send sysParam
		resp=513;
		break;
	case 0x02: //send sysDSP0
		resp=513;
		break;
	case 0x03: //send sysDSP1
		resp=513;								
		break;
	case 0x10: //update Stimulate_controller info
		resp=1+sizeof(CE32_StimControl);
		break;
	case 0x11: //CL online control
		resp=2;
		break;									
	case 0x12: //LED pulse count
		resp=5;
		break;
	case 0x13: //set stim intensity
		resp=4;
		break;
	case 0x14: //set DSP trigger level
		resp=6;
		break;
	case 0x15:  //set Trigger gain 
		resp=6;
		break;
	case 0x18: //Set Camera params
		resp = 5;
		break;
	case 0x20: //set stimulator 0 profile
		resp=21;
		break;
	case 0x21: //set stimulator 1 profile
		resp=21;
		break;
	case 0x22: //DSP0 online configuration
		resp=25;
		break;
	case 0x23: //DSP1 online configuration
		resp=25;
		break;
	case 0x30: //start logging
		resp=1;
		break;
	case 0x31: //Stop logging
		resp=1;
		break;
	case 0x32: //Sampling Rate (Nch*res_rate)
		resp=3;
		break;
	case 0x33: //Sampling  4B * MAX_NCH_GROUP
		resp=1+4*MAX_NCH_GROUP;
		break;
	case 0x40: //enable preview
		resp=1;
		break;
	case 0x41: //disable preview
		resp=1;
		break;
	case 0x42: //preview channel control
		resp=2;
		break;
	case 0x43: //additional preview control (event)
		resp=2;
		break;
	case 0x45: //debug ascii ping
		resp=1;
		break;
	case 0x51: //impedance test
		resp=1;
		break;
	case 0x60: //forced trigger
		resp=2;
		break;
	case 0x61://GPIO control
		resp=3;
		break;
	case 0x80: //handshake V1
		resp=1;
		break;
	case 0x81:  //Time Sync
		resp=3;
		break;
	case 0x82: //handshake V2
		resp=4;
		break;
	case 0x83: //force trigger stimulator
		resp=2;
		break;
	case 0x84: //event logging (synced uint16 time source)
		resp=1+sizeof(uint16_t)+sizeof(uint8_t);
		break;
	case 0x85: //message
		resp=1+32;
		break;
	case 0x89: //Request resync
		resp=1;
		break;
	case 0x8A:	//Write time
		resp=1+sizeof(RTC_DateTypeDef)+sizeof(RTC_TimeTypeDef);
		break;
	case 0x8C: //request time
		resp=1+2*sizeof(CE32_SyncTypeDef);
		break;
	case 0x8D: //precision sync V2 (t0,t1,t2)
		resp=1+3*sizeof(CE32_SyncTypeDef);
		break;
	case 0x8E: //Time Report Control
		resp=2;
		break;
	case 0x8F: //Compressed Time report
		resp = 5;
		break;
	case 0x90:   //request system parameter
		resp=1;
		break;
	case 0x91:	//request DSP1
		resp=1;
		break;
	case 0x92:	//request DSP2
		resp=1;
		break;
	case 0x93:  //request Sc
		resp=2;
		break;
	case 0x94: //request SD/sysLog block
		resp=3; //ID + block_lsb + block_msb
		break;
	case 0x95: //delete previous recording(s)
		resp=2; //ID + delete_count
		break;
	case 0x9D: //request hcam info
		resp = 1;
		break;
	case 0x9E: //Read Snapshot
		resp = 1;
		break;
	case 0x9F: //Read data
		resp = 4+1;
		break;
	case 0xA0:  //Signaling deep sleep
		resp=2;
		break;
	case 0xA1: //Role override (auto/master/slave)
		resp=2;
		break;
	case 0xAB:	//Software reset
		resp=2;
		break;
//	case 0xAC:	//DFU mode
//		resp=2;
//		break;
	case 0xAD:	//reply chip ID
		resp=137;
		break;
	case 0xB8: //NP staged configuration, fixed binary frame
		resp=65;
		break;
	case 0xB9: //NP SD-mode control, fixed binary frame
		resp=65;
		break;
//	case 0xB0:	//Interface: report version
//		resp=3;
//		break;
//	case 0xB1:	//Interface: report Device info
//		resp=25;
//		break;
	case 0xBA: //READ SD block
		resp = 6; //ID+32b address +512 data + CRC16 
		break;
	case 0xBB: //WRITE SD block
		resp = 5+512+2; //ID+32b address + status 
		break;
//	case 0xF0: //LPF test
//		resp=513;
//		break;
//	case 0xF1: //mainFil1 test
//		resp=513;
//		break;
//	case 0xF2: //mainFIl2 test
//		resp=513;
//		break;
//	case 0xF3: //maFIL1 test
//		resp=513;
//		break;
//	case 0xF4: //maFil2 test
//		resp=513;
//		break;
	}
	return resp;
}
#endif
//Enqueue data to buffer
//Push to command buffer
int CE32_INTERCOM_RX_Enqueue_Byte(CE32_INTERCOM_Handle *handle_IC,unsigned char data)
{
	return CE32_COMMAND_Enqueue_Byte(&handle_IC->CMD_RX,data);
}


int CE32_INTERCOM_RX_EnqueueCmd(CE32_INTERCOM_Handle *handle_IC)
{
	return CE32_COMMAND_EnqueueCmd_buffered(&handle_IC->CMD_RX);
}

int CE32_INTERCOM_RX_DequeueCmd(CE32_INTERCOM_Handle *handle_IC,uint8_t** data_ptr,uint32_t* cmd_len)
{
	return CE32_COMMAND_DequeueCmd(&handle_IC->CMD_RX,data_ptr,cmd_len);
}

int CE32_INTERCOM_TX_EnqueueCmd(CE32_INTERCOM_Handle *handle_IC,unsigned char* data,int cmd_len)
{
	uint8_t* addr;
	if(CE32_COMMAND_Enqueue_Allocate(&handle_IC->CMD_TX,cmd_len,&addr)!=0)
	{
		return -1;
	}
	memcpy((uint8_t*)addr,(uint8_t*)data,cmd_len);							//Copy the data to TX buffer
	if(CE32_COMMAND_EnqueueCmd_buffered(&handle_IC->CMD_TX)!=0)
	{
		return -1;
	}
	CE32_INTERCOM_TX_EnqueueCmd_Act(handle_IC);
	return 0;
}

int CE32_INTERCOM_TX_DequeueCmd(CE32_INTERCOM_Handle *handle_IC)
{
	CE32_COMMAND_DequeueCmd(&handle_IC->CMD_TX,NULL,NULL);
	return 0;
}

int CE32_INTERCOM_TX_Dequeue_Byte(CE32_INTERCOM_Handle *handle_IC,uint8_t* data)
{
	return CE32_COMMAND_Dequeue_Byte(&handle_IC->CMD_TX,data);
}

int CE32_INTERCOM_TX_Message(CE32_INTERCOM_Handle *handle,char* txt)
{
	uint8_t cmd[32+4]="";
	cmd[0]=0xAD;
	cmd[1]=0x85;
	int str_len = strlen(txt);
	str_len = str_len>32?32:str_len;
	memcpy(&cmd[2],txt,str_len);
	cmd[sizeof(cmd)-2]=0xDA;
	cmd[sizeof(cmd)-1]=0xDA;
	return CE32_INTERCOM_TX_EnqueueCmd(handle,cmd,sizeof(cmd));
}

int CE32_INTERCOM_RX_ISR(CE32_INTERCOM_Handle *handle_IC)
{
	int resp=-1;
	CE32_command* handle=&handle_IC->CMD_RX;
	if(INTERCOM_UART_CHECK_RXNEIE(handle_IC))
	{
		if(INTERCOM_CHECK_RXNE(handle_IC))
		{
			CE32_UART_RX_CLEAR(handle_IC->UART);
			uint8_t data_temp=CE32_UART_RX_READ(handle_IC->UART); //Read data into buffer first
			CE32_INTERCOM_RX_Byte_Act(handle_IC, data_temp);
			if(CE32_INTERCOM_ResetPatternDetect(
					CE32_INTERCOM_ResetSniffByte(handle, data_temp))!=0U)
			{
				ce32_intercom_reset_isr_req = 1U;
			}
			if(INTERCOM_RX_IS_ON(handle_IC)) //check if already in cmd receiveing mode
			{
				if(handle->stream_in.logging==0)
				{
					if(CE32_INTERCOM_Incoming_CMD_Len(data_temp)>0)
					{
						uint8_t* ptr;
						if(CE32_COMMAND_Enqueue_Allocate(handle,CE32_INTERCOM_Incoming_CMD_Len(data_temp),&ptr)!=0) //Preallocate space
						{
							CE32_COMMAND_Enqueue_Byte_Abort(handle);
							INTERCOM_STATE_END_RX_RECEIVE(handle_IC); //Reset flags to no cmd detected mode
							resp=-1;
							return resp;
						}
					}
					else
					{
						CE32_COMMAND_Enqueue_Byte_Abort(handle);
					}
				}
				if(CE32_COMMAND_Enqueue_BytesLeft(handle)>0)
				{
					if(CE32_INTERCOM_RX_Enqueue_Byte(handle_IC,data_temp)==-1) //Enqueue data to current RX buffer
					{
						//Buffer is full
						CE32_COMMAND_Enqueue_Byte_Abort(handle);
						INTERCOM_STATE_END_RX_RECEIVE(handle_IC); //Reset flags to no cmd detected mode
						resp=0;
					}
				}
				else
				{
					if(data_temp==INTERCOM_PKG_TAIL) //If end package detectected at desinated length
					{
						CE32_INTERCOM_RX_FrameComplete_Act(
							handle_IC,
							(const uint8_t *)handle->stream_in.addr,
							handle->stream_in.len);
						CE32_INTERCOM_RX_EnqueueCmd(handle_IC);
						INTERCOM_STATE_END_RX_RECEIVE(handle_IC); //Reset flags to no cmd detected mode
						resp=0;
					}
					else
					{
						CE32_COMMAND_Enqueue_Byte_Abort(handle);
						INTERCOM_STATE_END_RX_RECEIVE(handle_IC); //Reset flags to no cmd detected mode
						resp=-1;
					}
				}
			}
			else //If recording is not started
			{
				if(data_temp==INTERCOM_PKG_HEAD)
				{
					INTERCOM_STATE_START_RX_RECEIVE(handle_IC);
					resp=0;
				}
			}
		}
	}
	
	return resp;
}

uint8_t CE32_INTERCOM_TakeResetISRRequest(void)
{
	uint8_t req = ce32_intercom_reset_isr_req;
	ce32_intercom_reset_isr_req = 0U;
	return req;
}

int CE32_INTERCOM_RX_ISR_SWI(CE32_INTERCOM_Handle *handle_IC)
{
	int resp=-1;
	CE32_command* handle=&handle_IC->CMD_RX;
	if(INTERCOM_UART_CHECK_RXNEIE(handle_IC))
	{
		if(INTERCOM_CHECK_RXNE(handle_IC))
		{
			CE32_UART_RX_CLEAR(handle_IC->UART);
			uint8_t data_temp=CE32_UART_RX_READ(handle_IC->UART); //Read data into buffer first
			CE32_INTERCOM_RX_Byte_Act(handle_IC, data_temp);
			CE32_INTERCOM_RX_Inputdata_byte(handle_IC,data_temp);
		}
	}
	return resp;
}

int CE32_INTERCOM_RX_ProcBuffer(CE32_INTERCOM_Handle *handle_IC)
{
	char data_temp;
	CE32_command* handle=&handle_IC->CMD_RX;
	while(dataMGR_deQueue_byte_safe(&handle_IC->MGR_RX,0,&data_temp)==0)
	{
		if(INTERCOM_RX_IS_ON(handle_IC)) //check if already in cmd receiveing mode
		{
			if(handle->stream_in.logging==0)
			{
				if(CE32_INTERCOM_Incoming_CMD_Len(data_temp)>0)
				{
					uint8_t* ptr;
					if(CE32_COMMAND_Enqueue_Allocate(handle,CE32_INTERCOM_Incoming_CMD_Len(data_temp),&ptr)!=0) //Preallocate space
					{
						CE32_COMMAND_Enqueue_Byte_Abort(handle);
						INTERCOM_STATE_END_RX_RECEIVE(handle_IC);
						continue;
					}
				}
				else
				{
					CE32_COMMAND_Enqueue_Byte_Abort(handle);
				}
			}
			if(CE32_COMMAND_Enqueue_BytesLeft(handle)>0)
			{
				if(CE32_INTERCOM_RX_Enqueue_Byte(handle_IC,data_temp)==-1) //Enqueue data to current RX buffer
				{
					//Buffer is full
					CE32_COMMAND_Enqueue_Byte_Abort(handle);
					INTERCOM_STATE_END_RX_RECEIVE(handle_IC); //Reset flags to no cmd detected mode
				}
			}
			else
			{
				if(data_temp==INTERCOM_PKG_TAIL) //If end package detectected at desinated length
				{
					CE32_INTERCOM_RX_FrameComplete_Act(
						handle_IC,
						(const uint8_t *)handle->stream_in.addr,
						handle->stream_in.len);
					CE32_INTERCOM_RX_EnqueueCmd(handle_IC);
					INTERCOM_STATE_END_RX_RECEIVE(handle_IC); //Reset flags to no cmd detected mode
				}
				else
				{
					CE32_COMMAND_Enqueue_Byte_Abort(handle);
					INTERCOM_STATE_END_RX_RECEIVE(handle_IC); //Reset flags to no cmd detected mode
				}
			}
		}
		else //If recording is not started
		{
			if(data_temp==INTERCOM_PKG_HEAD)
			{
				INTERCOM_STATE_START_RX_RECEIVE(handle_IC);
			}
		}
	}
	return 0;
}

int CE32_INTERCOM_TX_ISR(CE32_INTERCOM_Handle *handle_IC)
{
	int resp=-1;
	CE32_command* handle=&handle_IC->CMD_TX;
	if(INTERCOM_UART_CHECK_TXEIE(handle_IC))
	{
		if(INTERCOM_CHECK_TXE(handle_IC))
		{
			if(CE32_COMMAND_GetPendingCounts(handle)>0)
			{
				uint8_t data;
				if(CE32_INTERCOM_TX_Dequeue_Byte(handle_IC,&data)==0)
				{
					INTERCOM_TX_SEND(handle_IC,data);
					if(CE32_COMMAND_Dequeue_BytesLeft(handle)<=0)
					{
						CE32_INTERCOM_TX_DequeueCmd(handle_IC);
					}
					resp=0;
				}
				else
				{
					//Disable TX transmission
					INTERCOM_UART_TXEIE_DISABLE(handle_IC);
					resp=0;
				}
			}
			else
			{
				//Disable TX transmission
				INTERCOM_UART_TXEIE_DISABLE(handle_IC);
				resp=0;
			}
		}
	}
	return resp;
}

int CE32_INTERCOM_RX_Inputdata_byte(CE32_INTERCOM_Handle *handle,uint8_t data)
{
	dataMGR_enQueue_byte(&handle->MGR_RX,data);
	CE32_INTERCOM_RX_dataCached_Act(handle);
	return 0;
}

int CE32_INTERCOM_TX_DMA_ISR(CE32_INTERCOM_Handle *handle)
{
	if((handle->state&INTERCOM_STATE_TX_DMABUSY)!=0)
	{
		handle->state&=~INTERCOM_STATE_TX_DMABUSY;
		uint8_t *data_ptr;
		uint32_t cmd_len;
		CE32_COMMAND_DequeueCmd((CE32_command*)handle,&data_ptr,&cmd_len);
		if(CE32_INTERCOM_TX_Start_DMA(handle)!=0) //start sending next command
		{
			CE32_INTERCOM_UART_TX_DMA_Disable(handle); //stop DMA service
			
			return 0;
		}
	}
	return -1;
}

int CE32_INTERCOM_TX_Start_DMA(CE32_INTERCOM_Handle *handle)
{	
	if((handle->state&INTERCOM_STATE_TX_DMABUSY)==0)
	{
		if(CE32_COMMAND_GetPendingCounts((CE32_command*)handle)>0)
		{
			//load command
			uint8_t *data_ptr;
			uint32_t cmd_len;
			CE32_COMMAND_GetCmdPointer((CE32_command*)handle,&data_ptr,&cmd_len);
			/* Refresh sync timestamps at actual DMA launch time to avoid
			   queue-delay bias when BLE TX is congested. */
			if((cmd_len >= (uint32_t)(1U + 1U + sizeof(uint32_t) + 2U)) &&
			   (data_ptr[0] == 0xADU) && (data_ptr[1] == 0x8FU))
			{
				CE32_SyncTypeDef dev_time;
				uint32_t dev_ms;
				CE32_RTC_GetTime(&hrtc,&dev_time);
				dev_ms = (uint32_t)(dev_time.Seconds * 1000U + (dev_time.SubSeconds / 10U));
				memcpy(&data_ptr[2], &dev_ms, sizeof(uint32_t));
			}
			else if((data_ptr[0] == 0xADU) &&
			        ((data_ptr[1] == 0x8CU) || (data_ptr[1] == 0x8DU)) &&
			        (cmd_len >= (uint32_t)(1U + 1U + sizeof(CE32_SyncTypeDef) + 2U)))
			{
				CE32_SyncTypeDef dev_time;
				/* For 0x8C/0x8D, refresh t0 (bytes [2..9]) at actual TX launch. */
				CE32_RTC_GetTime(&hrtc,&dev_time);
				memcpy(&data_ptr[2], &dev_time, sizeof(CE32_SyncTypeDef));
			}
			CE32_INTERCOM_TX_Launch_Act(handle, data_ptr, cmd_len);
#if defined(DMA_SxCR_EN)
			if(CE32_UART_DMA_CONFIGURED(handle))
			{
				USART_TypeDef* uart_handle = handle->UART;
				DMA_Stream_TypeDef* dma_handle = handle->huart->hdmatx->Instance;
				CLEAR_BIT(uart_handle->CR3, USART_CR3_DMAT); //disable uart _DMA_request
				UART_DMA_DISABLE(dma_handle);
				dma_handle->M0AR=(uint32_t)data_ptr;//Set the memory address in the DMA_SxMA0R register
				dma_handle->NDTR=cmd_len;//Configure the total number of data items to be transferred in the DMA_SxNDTR register
				dma_handle->CR|=DMA_IT_TC;
				handle->state|=INTERCOM_STATE_TX_DMABUSY;
				CE32_INTERCOM_UART_TX_DMA_Enable(handle); //Activate the stream by setting the EN bit in the DMA_SxCR register.
				return 0;
			}
#endif
			if(CE32_UART_DMA_CONFIGURED(handle))
			{
				HAL_StatusTypeDef hal_status;
				handle->state|=INTERCOM_STATE_TXON;
				hal_status = HAL_UART_Transmit_DMA(handle->huart, data_ptr, (uint16_t)cmd_len);
				if(hal_status == HAL_OK)
				{
					handle->state|=INTERCOM_STATE_TX_DMABUSY;
					return 0;
				}
				handle->state&=~(INTERCOM_STATE_TX_DMABUSY|INTERCOM_STATE_TXON);
				if(hal_status == HAL_BUSY)
				{
					return -2;
				}
				return -1;
			}
			/*
			 * U5 fallback: if no legacy TX DMA stream is configured, keep the
			 * CE32 command queue/state machine and use the existing byte-TX ISR
			 * path instead of rewriting transport logic.
			 */
			handle->state|=INTERCOM_STATE_TXON;
			INTERCOM_UART_ENABLE(handle);
			INTERCOM_UART_TXIT_ENABLE(handle);
			return 0;
		}
		return -1;
	}
	else
	{
#if defined(DMA_SxCR_EN)
		if(CE32_UART_DMA_CONFIGURED(handle))
		{
			DMA_Stream_TypeDef* dma_handle = handle->huart->hdmatx->Instance;
			if(dma_handle->NDTR==0)
			{
				CE32_INTERCOM_TX_DMA_ISR(handle);//force triggering ISR
			}
		}
#endif
	}
	return -2;
}

int CE32_INTERCOM_TX_Stop_DMA(CE32_INTERCOM_Handle *handle)
{
#if defined(DMA_SxCR_EN)
	if(CE32_UART_DMA_CONFIGURED(handle) &&
	   ((handle->huart->Instance->CR3&USART_CR3_DMAT)!=0)) //if in DMA transfer
	{
		while((handle->state&INTERCOM_STATE_TX_DMABUSY)!=0) //wait DMA transfer to end
		{
			if(handle->huart->hdmatx->Instance->NDTR==0)
			{
				break;
			}
		}
		CE32_INTERCOM_UART_TX_DMA_Disable(handle);
		return 0;
	}
#endif
	if(CE32_UART_DMA_CONFIGURED(handle))
	{
		(void)HAL_UART_DMAStop(handle->huart);
		INTERCOM_UART_TXEIE_DISABLE(handle);
		handle->state&=~(INTERCOM_STATE_TX_DMABUSY|INTERCOM_STATE_TXON);
		return 0;
	}
	if((handle != NULL) && (handle->UART != NULL))
	{
		INTERCOM_UART_TXEIE_DISABLE(handle);
		handle->state&=~(INTERCOM_STATE_TX_DMABUSY|INTERCOM_STATE_TXON);
		return 0;
	}
	return -1;
}

int CE32_INTERCOM_TX_Stop_All(CE32_INTERCOM_Handle *handle)
{
#if defined(DMA_SxCR_EN)
	if((handle->huart->Instance->CR3&USART_CR3_DMAT)!=0) //if in DMA transfer
	{
		while((handle->state&INTERCOM_STATE_TX_DMABUSY)!=0) //wait DMA transfer to end
		{
			if(handle->huart->hdmatx->Instance->NDTR==0)
			{
				break;
			}
		}
		CE32_INTERCOM_UART_TX_DMA_Disable(handle);
		return 0;
	}
	if((handle->huart->Instance->CR3&USART_CR3_DMAT)!=0) //if in DMA transfer
	{
		return CE32_INTERCOM_TX_Stop_DMA(handle);
	}
#endif
	if(CE32_UART_DMA_CONFIGURED(handle))
	{
		return CE32_INTERCOM_TX_Stop_DMA(handle);
	}
	if((handle != NULL) && (handle->UART != NULL))
	{
		INTERCOM_UART_TXEIE_DISABLE(handle);
		handle->state&=~(INTERCOM_STATE_TX_DMABUSY|INTERCOM_STATE_TXON);
	}
	return 0;
}

void CE32_INTERCOM_UART_TX_DMA_Init(CE32_INTERCOM_Handle *handle)
{
#if defined(DMA_SxCR_EN)
	if(CE32_UART_DMA_CONFIGURED(handle)==0)
	{
		return;
	}
	USART_TypeDef* uart_handle = handle->UART;
	DMA_Stream_TypeDef* dma_handle = handle->huart->hdmatx->Instance;
	if((uart_handle->CR1&USART_CR1_UE)!=0)
	{
		PULL_UART_BSY(uart_handle)
	}
	/* Configure DMA Channel source address */
	dma_handle->PAR = (uint32_t)&uart_handle->DR;
	UART_DISABLE(uart_handle);
	SET_BIT(uart_handle->CR3, USART_CR3_DMAT); //enable UART_DMA_request
	UART_ENABLE(uart_handle);
#else
	if(handle != NULL)
	{
		handle->state&=~INTERCOM_STATE_TX_DMABUSY;
	}
#endif
}

void CE32_INTERCOM_UART_TX_DMA_Enable(CE32_INTERCOM_Handle *handle)
{
	handle->state|=INTERCOM_STATE_TXON;
#if defined(DMA_SxCR_EN)
	if(CE32_UART_DMA_CONFIGURED(handle)==0)
	{
		return;
	}
	USART_TypeDef* uart_handle = handle->UART;
	DMA_Stream_TypeDef* dma_handle = handle->huart->hdmatx->Instance;
	//PULL_UART_BSY(uart_handle)
	/* Configure DMA Channel source address */
	//SD_DMA_TX->PAR = (uint32_t)&SD_SPI->DR;
	//SD_DMA_TX->NDTR=256;
	//UART_DISABLE(uart_handle);
	UART_DMA_ENABLE(dma_handle); //Activate the stream by setting the EN bit in the DMA_SxCR register.
	SET_BIT(uart_handle->CR3, USART_CR3_DMAT); //enable UART_DMA_request
	
	//UART_ENABLE(uart_handle);
#else
	(void)handle;
#endif
}

void CE32_INTERCOM_UART_TX_DMA_Disable(CE32_INTERCOM_Handle *handle)
{
	handle->state&=~(INTERCOM_STATE_TX_DMABUSY|INTERCOM_STATE_TXON);
#if defined(DMA_SxCR_EN)
	if(CE32_UART_DMA_CONFIGURED(handle)==0)
	{
		return;
	}
	USART_TypeDef* uart_handle = handle->UART;
	DMA_Stream_TypeDef* dma_handle = handle->huart->hdmatx->Instance;
	dma_handle->CR&=~DMA_IT_TC; //disable interrupt
	//PULL_UART_BSY(uart_handle)
	UART_DMA_DISABLE(dma_handle);
	//UART_DISABLE(uart_handle);
	CLEAR_BIT(uart_handle->CR3, USART_CR3_DMAT); //disable uart _DMA_request
	//UART_ENABLE(uart_handle);
#else
	if((handle != NULL) && (handle->UART != NULL))
	{
		INTERCOM_UART_TXEIE_DISABLE(handle);
	}
#endif
}

int CE32_INTERCOM_TX_WaitTillSent(CE32_INTERCOM_Handle *handle_IC)
{
	if((handle_IC->huart->Instance->CR1&(USART_CR1_TE|USART_CR1_UE))==(USART_CR1_TE|USART_CR1_UE))
	{
		__IO CE32_command *handle=&handle_IC->CMD_TX;
		uint32_t t0 = HAL_GetTick();
#if defined(DMA_SxCR_EN)
		if(CE32_UART_DMA_CONFIGURED(handle_IC))
		{
		uint16_t last_ndtr = 0xFFFFU;
		uint32_t dma_stall_guard = 0U;
		while(handle->cmd_pending>0)
		{
			DMA_Stream_TypeDef* dma_handle = handle_IC->huart->hdmatx->Instance;
			/* Keep actively kicking TX state machine while waiting:
			   this recovers from rare stale DMA/flag states without requiring caller retries. */
			(void)CE32_INTERCOM_TX_Start_DMA(handle_IC);

			/* TXON lives in intercom-handle state, not command state. */
			if(((handle_IC->state&INTERCOM_STATE_TXON)==0) ||
			   ((handle_IC->huart->Instance->CR3 & USART_CR3_DMAT)==0)) //if TX off
			{
				CE32_INTERCOM_TX_restart(handle_IC);
			}

			/* Recover from a wedged DMA stream where DMABUSY remains set but NDTR stops changing. */
			if((handle_IC->state&INTERCOM_STATE_TX_DMABUSY)!=0U)
			{
				uint16_t ndtr_now = (uint16_t)dma_handle->NDTR;
				uint32_t dma_enabled = ((dma_handle->CR & DMA_SxCR_EN)!=0U);
				/* Completion IRQ may be delayed/missed under heavy load; retire now if stream drained. */
				if(ndtr_now == 0U)
				{
					(void)CE32_INTERCOM_TX_DMA_ISR(handle_IC);
				}
				if((dma_enabled==0U) || (ndtr_now==last_ndtr))
				{
					dma_stall_guard++;
				}
				else
				{
					dma_stall_guard = 0U;
				}
				last_ndtr = ndtr_now;
				if(dma_stall_guard>200000U)
				{
					CE32_INTERCOM_TX_restart(handle_IC);
					dma_stall_guard = 0U;
				}
			}
			else
			{
				dma_stall_guard = 0U;
			}
			/* Avoid hard deadlock if DMA/IRQ path is lost. */
			if((HAL_GetTick()-t0)>2000U)
			{
				return -2;
			}
			__NOP();
		}
		return 0;
		}
#endif
		while(handle->cmd_pending>0)
		{
			(void)CE32_INTERCOM_TX_Start_DMA(handle_IC);
			(void)CE32_INTERCOM_TX_ISR(handle_IC);
			if((HAL_GetTick()-t0)>2000U)
			{
				return -2;
			}
			__NOP();
		}
		return 0;
	}
	else
	{
		return -1;
	}
}

__weak void CE32_INTERCOM_TX_restart(CE32_INTERCOM_Handle *handle_IC)
{
	__nop();
}

__weak void CE32_INTERCOM_RX_dataCached_Act(CE32_INTERCOM_Handle *handle_IC)
{
	CE32_INTERCOM_RX_ProcBuffer(handle_IC);
}

__weak void CE32_INTERCOM_TX_EnqueueCmd_Act(CE32_INTERCOM_Handle *handle_IC)
{
	__nop();
	//ENABLE_TX(handle_IC);//Enable UART transfer
}
