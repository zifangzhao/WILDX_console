#include "xe_np_media_adc.h"

#if XE_NP_V2_MEDIA_ENABLE || XE_NP_V2_AUX_ENABLE
#include <string.h>

extern DCACHE_HandleTypeDef hdcache1;
static ADC_HandleTypeDef *media_adc;
static DMA_HandleTypeDef media_dma;
static DMA_QListTypeDef media_list;
#if defined(_MSC_VER)
__declspec(align(32)) static DMA_NodeTypeDef media_nodes[XE_NP_MEDIA_ADC_NODE_COUNT];
#else
static DMA_NodeTypeDef media_nodes[XE_NP_MEDIA_ADC_NODE_COUNT] __attribute__((aligned(32)));
#endif
static uint8_t *media_ring;
static volatile uint32_t media_blocks, media_irq_error;
#if XE_NP_NP2_FIRST_SYNC_ENABLE
static uint32_t media_generation;
#endif
static struct {
    uint32_t prepared, running, stopped, start_ms, fault;
    uint32_t ring_bytes, node_bytes;
    uint64_t stop_bytes;
#if XE_NP_NP2_FIRST_SYNC_ENABLE
    uint32_t generation,first_sync_generation;
#endif
} media;

#define MEDIA_DMA_ERRORS (DMA_FLAG_DTE | DMA_FLAG_ULE | DMA_FLAG_USE | DMA_FLAG_TO)

static int media_fault(uint32_t error)
{
    if (!media.fault) media.fault = error;
    return -1;
}

uint32_t XE_NP_MediaAdc_Error(void)
{
    if (media_irq_error && !media.fault) media.fault = media_irq_error;
    if (media_adc && (media_adc->Instance->ISR & ADC_ISR_OVR))
        media_fault(XE_NP_MEDIA_ADC_ERROR_ADC);
    return media.fault;
}

void XE_NP_MediaAdc_DmaIrq(void)
{
    uint32_t flags = GPDMA1_Channel7->CSR;
    GPDMA1_Channel7->CFCR = flags & (DMA_FLAG_TC | MEDIA_DMA_ERRORS);
    if ((flags & MEDIA_DMA_ERRORS) && !media_irq_error) media_irq_error = flags;
    if (flags & DMA_FLAG_TC) { __DMB(); media_blocks++; }
}

static int media_cache(uint8_t *data, uint32_t bytes, uint32_t clean)
{
    uintptr_t first = (uintptr_t)data & ~(uintptr_t)31U;
    uint32_t size = (uint32_t)((uintptr_t)data - first) + bytes;
    size = (size + 31U) & ~31U;
    HAL_StatusTypeDef result = clean ?
        HAL_DCACHE_CleanByAddr(&hdcache1, (const uint32_t *)first, size) :
        HAL_DCACHE_InvalidateByAddr(&hdcache1, (const uint32_t *)first, size);
    __DSB();
    return result == HAL_OK ? 0 : media_fault(XE_NP_MEDIA_ADC_ERROR_CACHE);
}

static int media_prepare_failed(uint32_t error)
{
    TIM8->CR1 &= ~TIM_CR1_CEN;
    (void)HAL_ADC_Stop(media_adc);
    HAL_NVIC_DisableIRQ(GPDMA1_Channel7_IRQn);
    HAL_NVIC_ClearPendingIRQ(GPDMA1_Channel7_IRQn);
    media.prepared = 0U;
    return media_fault(error);
}

int XE_NP_MediaAdc_Prepare(ADC_HandleTypeDef *admitted_adc,
                         uint8_t *caller_owned_ring, uint32_t ring_bytes)
{
    uint32_t node_bytes = ring_bytes / XE_NP_MEDIA_ADC_NODE_COUNT;

    /* Admission precedes any register mutation or clearing of retained state.
     * Never DeInit a fresh-zero ADC handle: MSP owns the shared ADC clock. */
    if (!admitted_adc || admitted_adc->Instance != ADC1 ||
        admitted_adc->State != HAL_ADC_STATE_READY || admitted_adc->Lock != HAL_UNLOCKED ||
        (ADC1->CR & (ADC_CR_ADSTART | ADC_CR_JADSTART)) || media.running ||
        (TIM8->CR1 & TIM_CR1_CEN) || TIM8->DIER ||
        (GPDMA1_Channel7->CCR & (DMA_CCR_EN | DMA_CCR_SUSP | DMA_CCR_RESET)) ||
        !caller_owned_ring || ((uintptr_t)caller_owned_ring & 31U) ||
        ring_bytes % XE_NP_MEDIA_ADC_NODE_COUNT || (node_bytes & 31U) ||
        node_bytes < 8192U || node_bytes > DMA_CBR1_BNDT ||
        (uintptr_t)caller_owned_ring > UINTPTR_MAX - ring_bytes)
        return -1;
    uint32_t timer_hz = HAL_RCC_GetPCLK2Freq();
    if (RCC->CFGR2 & RCC_CFGR2_PPRE2) {
        if (timer_hz > UINT32_MAX / 2U) return -1;
        timer_hz *= 2U;
    }
    uint32_t period = XE_NP_MediaAdcTimerPeriod(timer_hz);
    if (period == UINT32_MAX) return -1;

    HAL_NVIC_DisableIRQ(GPDMA1_Channel7_IRQn);
    memset(&media, 0, sizeof(media));
    media_adc = admitted_adc;
    media_ring = caller_owned_ring;
    media.ring_bytes = ring_bytes;
    media.node_bytes = node_bytes;
    media_blocks = media_irq_error = 0U;
    __HAL_RCC_GPIOB_CLK_ENABLE();
    GPIO_InitTypeDef gpio = {0};
    gpio.Pin = GPIO_PIN_0; gpio.Mode = GPIO_MODE_ANALOG; gpio.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOB, &gpio); /* PB0/IN15 only; never PC2/PC4 PSRAM pins. */
    if (HAL_ADC_Stop(media_adc) != HAL_OK)
        return media_prepare_failed(XE_NP_MEDIA_ADC_ERROR_ADC);
    memset(&media_adc->Init, 0, sizeof(media_adc->Init));
    media_adc->Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
    media_adc->Init.Resolution = ADC_RESOLUTION_14B;
    media_adc->Init.DataAlign = ADC_DATAALIGN_LEFT;
    media_adc->Init.LeftBitShift = ADC_LEFTBITSHIFT_2;
    media_adc->Init.EOCSelection = ADC_EOC_SINGLE_CONV;
    media_adc->Init.NbrOfConversion = 1U;
    media_adc->Init.ExternalTrigConv = ADC_EXTERNALTRIG_T8_TRGO;
    media_adc->Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_RISING;
    media_adc->Init.ConversionDataManagement = ADC_CONVERSIONDATA_DMA_CIRCULAR;
    media_adc->Init.DMAContinuousRequests = ENABLE;
    media_adc->Init.Overrun = ADC_OVR_DATA_PRESERVED;
    media_adc->Init.TriggerFrequencyMode = ADC_TRIGGER_FREQ_HIGH;
    if (HAL_ADC_Init(media_adc) != HAL_OK ||
        HAL_ADCEx_Calibration_Start(media_adc, ADC_CALIB_OFFSET, ADC_SINGLE_ENDED) != HAL_OK)
        return media_prepare_failed(XE_NP_MEDIA_ADC_ERROR_ADC);
    ADC_ChannelConfTypeDef adc_channel = {0};
    adc_channel.Channel = ADC_CHANNEL_15; adc_channel.Rank = ADC_REGULAR_RANK_1;
    adc_channel.SamplingTime = ADC_SAMPLETIME_36CYCLES;
    adc_channel.SingleDiff = ADC_SINGLE_ENDED;
    if (HAL_ADC_ConfigChannel(media_adc, &adc_channel) != HAL_OK)
        return media_prepare_failed(XE_NP_MEDIA_ADC_ERROR_ADC);

    __HAL_RCC_TIM8_CLK_ENABLE();
    TIM8->CR1 = 0U; TIM8->DIER = 0U; TIM8->PSC = 0U; TIM8->ARR = period;
    TIM8->RCR = 0U; TIM8->CNT = 0U; TIM8->CR2 = 0U;
    TIM8->EGR = TIM_EGR_UG; TIM8->SR = 0U; TIM8->CR2 = TIM_TRGO_UPDATE;
    __HAL_RCC_GPDMA1_CLK_ENABLE();
    memset(&media_dma, 0, sizeof(media_dma));
    memset(&media_list, 0, sizeof(media_list));
    memset(media_nodes, 0, sizeof(media_nodes));
    DMA_NodeConfTypeDef node = {0};
    node.NodeType = DMA_GPDMA_LINEAR_NODE;
    node.Init.Request = GPDMA1_REQUEST_ADC1; node.Init.Direction = DMA_PERIPH_TO_MEMORY;
    node.Init.SrcInc = DMA_SINC_FIXED; node.Init.DestInc = DMA_DINC_INCREMENTED;
    node.Init.SrcDataWidth = DMA_SRC_DATAWIDTH_HALFWORD;
    node.Init.DestDataWidth = DMA_DEST_DATAWIDTH_HALFWORD;
    node.Init.SrcBurstLength = node.Init.DestBurstLength = 1U;
    node.Init.TransferAllocatedPort = DMA_SRC_ALLOCATED_PORT0 | DMA_DEST_ALLOCATED_PORT1;
    node.Init.TransferEventMode = DMA_TCEM_EACH_LL_ITEM_TRANSFER;
    node.DataHandlingConfig.DataAlignment = DMA_DATA_RIGHTALIGN_ZEROPADDED;
    node.SrcAddress = (uint32_t)(uintptr_t)&ADC1->DR;
    node.DataSize = media.node_bytes;
    for (uint32_t i = 0; i < XE_NP_MEDIA_ADC_NODE_COUNT; i++) {
        node.DstAddress = (uint32_t)(uintptr_t)(media_ring + i * media.node_bytes);
        if (HAL_DMAEx_List_BuildNode(&node, &media_nodes[i]) != HAL_OK ||
            HAL_DMAEx_List_InsertNode_Tail(&media_list, &media_nodes[i]) != HAL_OK)
            return media_prepare_failed(XE_NP_MEDIA_ADC_ERROR_CONFIG);
    }
    if (HAL_DMAEx_List_SetCircularMode(&media_list) != HAL_OK)
        return media_prepare_failed(XE_NP_MEDIA_ADC_ERROR_CONFIG);
    media_dma.Instance = GPDMA1_Channel7;
    media_dma.InitLinkedList.Priority = DMA_HIGH_PRIORITY;
    media_dma.InitLinkedList.LinkAllocatedPort = DMA_LINK_ALLOCATED_PORT0;
    media_dma.InitLinkedList.LinkedListMode = DMA_LINKEDLIST_CIRCULAR;
    media_dma.InitLinkedList.TransferEventMode = DMA_TCEM_EACH_LL_ITEM_TRANSFER;
    if (HAL_DMAEx_List_Init(&media_dma) != HAL_OK ||
        HAL_DMAEx_List_LinkQ(&media_dma, &media_list) != HAL_OK ||
        HAL_DMA_ConfigChannelAttributes(&media_dma, DMA_CHANNEL_NPRIV) != HAL_OK)
        return media_prepare_failed(XE_NP_MEDIA_ADC_ERROR_CONFIG);
    if (media_cache((uint8_t *)media_nodes, (uint32_t)sizeof(media_nodes), 1U) ||
        media_cache(media_ring, ring_bytes, 1U) || media_cache(media_ring, ring_bytes, 0U))
        return media_prepare_failed(XE_NP_MEDIA_ADC_ERROR_CACHE);
    GPDMA1_Channel7->CFCR = DMA_FLAG_TC | DMA_FLAG_HT | MEDIA_DMA_ERRORS | DMA_FLAG_SUSP;
    __DSB();
    HAL_NVIC_ClearPendingIRQ(GPDMA1_Channel7_IRQn);
    HAL_NVIC_SetPriority(GPDMA1_Channel7_IRQn, 3U, 0U);
    HAL_NVIC_EnableIRQ(GPDMA1_Channel7_IRQn);
    media.prepared = 1U;
    return 0;
}

static HAL_StatusTypeDef media_start_dma(void)
{
    DMA_Channel_TypeDef *ch = GPDMA1_Channel7;
    if (media.running || media.stopped || media_dma.State != HAL_DMA_STATE_READY ||
        media_list.State != HAL_DMA_QUEUE_STATE_READY || media_dma.Lock != HAL_UNLOCKED ||
        media_dma.Instance != ch || media_dma.LinkedListQueue != &media_list ||
        media_list.Head != &media_nodes[0] ||
        (ch->CCR & (DMA_CCR_EN | DMA_CCR_SUSP | DMA_CCR_RESET)) || !(ch->CSR & DMA_CSR_IDLEF))
        return HAL_BUSY;
    /* Prime actual node zero, retaining its link to node one. List_Start_IT
     * can start a zero-byte item and publish a phantom TC with EACH_LL_ITEM. */
    __HAL_LOCK(&media_dma);
    ch->CFCR = DMA_FLAG_TC | DMA_FLAG_HT | MEDIA_DMA_ERRORS | DMA_FLAG_SUSP;
    ch->CTR1 = media_nodes[0].LinkRegisters[NODE_CTR1_DEFAULT_OFFSET];
    ch->CTR2 = media_nodes[0].LinkRegisters[NODE_CTR2_DEFAULT_OFFSET];
    ch->CBR1 = media_nodes[0].LinkRegisters[NODE_CBR1_DEFAULT_OFFSET];
    ch->CSAR = media_nodes[0].LinkRegisters[NODE_CSAR_DEFAULT_OFFSET];
    ch->CDAR = media_nodes[0].LinkRegisters[NODE_CDAR_DEFAULT_OFFSET];
    ch->CLBAR = (uint32_t)(uintptr_t)&media_nodes[0] & DMA_CLBAR_LBA;
    ch->CLLR = media_nodes[0].LinkRegisters[NODE_CLLR_LINEAR_DEFAULT_OFFSET];
    media_dma.State = HAL_DMA_STATE_BUSY; media_list.State = HAL_DMA_QUEUE_STATE_BUSY;
    media_dma.ErrorCode = HAL_DMA_ERROR_NONE; media_list.ErrorCode = HAL_DMA_QUEUE_ERROR_NONE;
    HAL_NVIC_ClearPendingIRQ(GPDMA1_Channel7_IRQn);
    __HAL_DMA_ENABLE_IT(&media_dma, DMA_IT_TC | DMA_IT_DTE | DMA_IT_ULE | DMA_IT_USE | DMA_IT_TO);
    __DSB(); __HAL_DMA_ENABLE(&media_dma);
    return HAL_OK;
}

int XE_NP_MediaAdc_Arm(uint32_t start_ms)
{
#if XE_NP_NP2_FIRST_SYNC_ENABLE
    if (media_generation == UINT32_MAX) return media_fault(XE_NP_MEDIA_ADC_ERROR_STATE);
#endif
    if (!media.prepared || XE_NP_MediaAdc_Error() || (TIM8->CR1 & TIM_CR1_CEN) ||
        media_start_dma() != HAL_OK) return media_fault(XE_NP_MEDIA_ADC_ERROR_STATE);
    if (HAL_ADC_Start(media_adc) != HAL_OK || XE_NP_MediaAdc_Error()) {
        (void)HAL_ADC_Stop(media_adc);
        (void)HAL_DMA_Abort(&media_dma);
        media.prepared = 0U;
        return media_fault(XE_NP_MEDIA_ADC_ERROR_ADC);
    }
    __HAL_ADC_DISABLE_IT(media_adc, ADC_IT_OVR);
#if XE_NP_NP2_FIRST_SYNC_ENABLE
    media.generation = ++media_generation;
#endif
    media.start_ms = start_ms; media.running = 1U;
    TIM8->CNT = 0U; TIM8->CR1 |= TIM_CR1_CEN;
    return 0;
}

int XE_NP_MediaAdc_Stop(void)
{
    if (media.stopped) return XE_NP_MediaAdc_Error() ? -1 : 0;
    if (!media.prepared) return XE_NP_MediaAdc_Error() ? -1 : 0;
    (void)XE_NP_MediaAdc_Error(); /* Preserve ADC OVR before HAL stops it. */
    TIM8->CR1 &= ~TIM_CR1_CEN; __DSB();
    if (HAL_ADC_Stop(media_adc) != HAL_OK) media_fault(XE_NP_MEDIA_ADC_ERROR_STOP);
    if (!media.running) {
        if (GPDMA1_Channel7->CCR & DMA_CCR_EN)
            return media_fault(XE_NP_MEDIA_ADC_ERROR_STOP);
        HAL_NVIC_DisableIRQ(GPDMA1_Channel7_IRQn);
        HAL_NVIC_ClearPendingIRQ(GPDMA1_Channel7_IRQn);
        media.stop_bytes = 0U; media.stopped = 1U; media.prepared = 0U;
        return XE_NP_MediaAdc_Error() ? -1 : 0;
    }
    if (GPDMA1_Channel7->CCR & DMA_CCR_EN) {
        SET_BIT(GPDMA1_Channel7->CCR, DMA_CCR_SUSP);
        uint32_t began = HAL_GetTick(), polls = 0U;
        while (!(GPDMA1_Channel7->CSR & DMA_CSR_SUSPF) ||
               (GPDMA1_Channel7->CSR & DMA_CSR_FIFOL)) {
            /* No reset/abort of an unproven active channel on timeout. */
            if (HAL_GetTick() - began >= 2U || ++polls >= 65536U)
                return media_fault(XE_NP_MEDIA_ADC_ERROR_STOP);
        }
    }
    uint32_t mask = __get_PRIMASK(); __disable_irq();
    if (GPDMA1_Channel7->CSR & (DMA_FLAG_TC | MEDIA_DMA_ERRORS)) XE_NP_MediaAdc_DmaIrq();
    uint32_t left = GPDMA1_Channel7->CBR1 & DMA_CBR1_BNDT;
    uint32_t invalid = left > media.node_bytes || (left & 1U);
    /* Zero BNDT is the real exhausted item already counted by TC. */
    uint64_t final_bytes = (uint64_t)media_blocks * media.node_bytes +
        (left ? media.node_bytes - left : 0U);
    __set_PRIMASK(mask);
    if (invalid) media_fault(XE_NP_MEDIA_ADC_ERROR_STOP);
    if (media_dma.State == HAL_DMA_STATE_BUSY && HAL_DMA_Abort(&media_dma) != HAL_OK)
        return media_fault(XE_NP_MEDIA_ADC_ERROR_STOP);
    if ((GPDMA1_Channel7->CCR & DMA_CCR_EN) || (ADC1->CR & ADC_CR_ADSTART))
        return media_fault(XE_NP_MEDIA_ADC_ERROR_STOP);
    HAL_NVIC_DisableIRQ(GPDMA1_Channel7_IRQn);
    HAL_NVIC_ClearPendingIRQ(GPDMA1_Channel7_IRQn);
    media.stop_bytes = invalid ? 0U : final_bytes;
    media.running = 0U; media.stopped = 1U; media.prepared = 0U;
    return XE_NP_MediaAdc_Error() ? -1 : 0;
}

uint64_t XE_NP_MediaAdc_ProducedBytes(void)
{
    return media.stopped ? media.stop_bytes :
        (uint64_t)media_blocks * media.node_bytes;
}

static int media_retained(uint64_t cursor, uint64_t produced)
{
    return cursor <= produced && (media.stopped ?
        produced - cursor <= media.ring_bytes :
        produced - cursor < media.ring_bytes - media.node_bytes);
}

int XE_NP_MediaAdc_Copy(uint64_t cursor, uint8_t *dest, uint32_t bytes)
{
    if ((!media.running && !media.stopped) || !dest || !bytes ||
        bytes > XE_NP_MEDIA_COPY_BYTES || ((cursor | bytes) & 1U) ||
        cursor > UINT64_MAX - bytes || (uintptr_t)dest > UINTPTR_MAX - bytes ||
        ((uintptr_t)dest < (uintptr_t)media_ring + media.ring_bytes &&
         (uintptr_t)dest + bytes > (uintptr_t)media_ring)) return -1;
    if (XE_NP_MediaAdc_Error()) return -1;
    uint64_t produced = XE_NP_MediaAdc_ProducedBytes();
    if (cursor > produced || bytes > produced - cursor) return 1;
    if (!media_retained(cursor, produced)) return media_fault(XE_NP_MEDIA_ADC_ERROR_RETENTION);
    uint32_t offset = (uint32_t)(cursor % media.ring_bytes);
    uint32_t first = media.ring_bytes - offset;
    if (first > bytes) first = bytes;
    if (media_cache(media_ring + offset, first, 0U)) return -1;
    memcpy(dest, media_ring + offset, first);
    if (first < bytes) {
        if (media_cache(media_ring, bytes - first, 0U)) return -1;
        memcpy(dest + first, media_ring, bytes - first);
    }
    if (XE_NP_MediaAdc_Error()) return -1;
    if (!media_retained(cursor, XE_NP_MediaAdc_ProducedBytes()))
        return media_fault(XE_NP_MEDIA_ADC_ERROR_RETENTION);
    return 0;
}

uint32_t XE_NP_MediaAdc_IsRunning(void) { return media.running; }
uint32_t XE_NP_MediaAdc_StartTick(void) { return media.start_ms; }

#if XE_NP_NP2_FIRST_SYNC_ENABLE
typedef struct {
    uint32_t blocks,node,left,offset;
} MediaFirstSyncSample;

static uint32_t media_first_sync_cycles(void)
{
#if defined(DWT_CTRL_CYCCNTENA_Msk) && defined(CoreDebug_DEMCR_TRCENA_Msk)
    if ((CoreDebug->DEMCR & CoreDebug_DEMCR_TRCENA_Msk) &&
        (DWT->CTRL & DWT_CTRL_CYCCNTENA_Msk)) return DWT->CYCCNT;
#endif
    return UINT32_MAX;
}

static int media_first_sync_sample(MediaFirstSyncSample *out)
{
    DMA_Channel_TypeDef *ch=GPDMA1_Channel7;
    uint32_t flags=ch->CSR;
    if (media.fault || media_irq_error || (media_adc && (media_adc->Instance->ISR&ADC_ISR_OVR))) return -1;
    if (flags & (MEDIA_DMA_ERRORS | DMA_FLAG_TC)) {
        if ((flags & DMA_FLAG_TC) && media_blocks==UINT32_MAX) return -1;
        XE_NP_MediaAdc_DmaIrq();
        flags=ch->CSR;
    }
    if (media.fault || media_irq_error || (flags & (MEDIA_DMA_ERRORS | DMA_FLAG_TC)) || !(ch->CCR&DMA_CCR_EN) ||
        (ch->CCR&(DMA_CCR_SUSP|DMA_CCR_RESET))) return -1;
    out->blocks=media_blocks;
    if (out->blocks>=UINT32_MAX-1U) return -1; /* no 32-bit epoch inference */
    out->left=ch->CBR1&DMA_CBR1_BNDT;
    if (!out->left || out->left>media.node_bytes || (out->left&1U)) return -1;
    uint32_t destination=ch->CDAR,base=(uint32_t)(uintptr_t)media_ring,relative;
    if (destination<base || (relative=destination-base)>=media.ring_bytes) return -1;
    out->node=relative/media.node_bytes;
    out->offset=relative-out->node*media.node_bytes;
    if (out->node>=XE_NP_MEDIA_ADC_NODE_COUNT || (out->blocks%XE_NP_MEDIA_ADC_NODE_COUNT)!=out->node ||
        out->offset!=media.node_bytes-out->left) return -1;
    return 0;
}

uint32_t XE_NP_MediaAdc_Generation(void)
{
    return media.running ? media.generation : 0U;
}

int XE_NP_MediaAdc_FirstSync(uint32_t generation,XE_NP_MediaAdcFirstSync *out)
{
    MediaFirstSyncSample first,last;
    uint32_t retry,irq_key;
    if (!out) return -1;
    memset(out,0,sizeof(*out));
    out->discard_cursor=UINT64_MAX;out->before_cycles=out->after_cycles=UINT32_MAX;
    out->before_ms=HAL_GetTick();out->before_cycles=media_first_sync_cycles();
    if (!media.prepared || !media.running || media.stopped || media.fault ||
        !media_ring || !media.node_bytes || media.ring_bytes!=media.node_bytes*XE_NP_MEDIA_ADC_NODE_COUNT ||
        generation!=media.generation || media.first_sync_generation==generation ||
        media_dma.Instance!=GPDMA1_Channel7 || media_dma.State!=HAL_DMA_STATE_BUSY ||
        media_list.State!=HAL_DMA_QUEUE_STATE_BUSY || !(TIM8->CR1&TIM_CR1_CEN) ||
        !(ADC1->CR&ADC_CR_ADSTART) || XE_NP_MediaAdc_Error()) goto failed;
    for (retry=0U;retry<3U;retry++) {
        irq_key=__get_PRIMASK();__disable_irq();
        if (!media_first_sync_sample(&first) && !media_first_sync_sample(&last) &&
            first.blocks==last.blocks && first.node==last.node && last.left<=first.left &&
            last.offset>=first.offset) {
            __set_PRIMASK(irq_key);
            out->discard_cursor=((uint64_t)last.blocks+1U)*media.node_bytes;
            out->generation=generation;
            out->flags=(out->before_cycles!=UINT32_MAX)?XE_NP_MEDIA_ADC_FIRST_SYNC_DWT_VALID:0U;
            media.first_sync_generation=generation;
            out->after_ms=HAL_GetTick();out->after_cycles=media_first_sync_cycles();
            if (out->after_cycles==UINT32_MAX) out->flags&=~XE_NP_MEDIA_ADC_FIRST_SYNC_DWT_VALID;
            return 0;
        }
        __set_PRIMASK(irq_key);
    }
    /* The producer is still demonstrably ours, but the paired cursor crossed
     * a node. Discard the sampled inflight node and its successor; mark the
     * gap rather than claiming a sample-zero boundary. */
    irq_key=__get_PRIMASK();__disable_irq();
    if (!media_first_sync_sample(&last)) {
        __set_PRIMASK(irq_key);
        out->discard_cursor=((uint64_t)last.blocks+2U)*media.node_bytes;
        out->generation=generation;
        out->flags=XE_NP_MEDIA_ADC_FIRST_SYNC_GAP|
            ((out->before_cycles!=UINT32_MAX)?XE_NP_MEDIA_ADC_FIRST_SYNC_DWT_VALID:0U);
        media.first_sync_generation=generation;
        out->after_ms=HAL_GetTick();out->after_cycles=media_first_sync_cycles();
        if (out->after_cycles==UINT32_MAX) out->flags&=~XE_NP_MEDIA_ADC_FIRST_SYNC_DWT_VALID;
        return 0;
    }
    __set_PRIMASK(irq_key);
failed:
    out->after_ms=HAL_GetTick();out->after_cycles=media_first_sync_cycles();
    return -1;
}
#endif
#endif
