#include "xe_np_usb_msc.h"
#include "xe_np_msc_bot.h"
#include "xe_np_boot_contract.h"
#include "xe_np_board.h"
#include "main.h"

extern SD_HandleTypeDef hsd1;
extern DCACHE_HandleTypeDef hdcache1;
static uint8_t boot_mode;
static XE_NP_MscBot bot;
static PCD_HandleTypeDef *pcd;
/* Dedicated whole cache lines: USB DMA must not share protocol-state lines.
 * Copying CSW/short replies here also guarantees the required DMA alignment. */
static _Alignas(32) uint8_t tx_scratch[MSC_MEDIA_PACKET];
static uint32_t rx_cache_bytes;
enum { EV_RESET=1, EV_CONFIG=2, EV_BOT_RESET=4, EV_CLEAR_IN=8, EV_CLEAR_OUT=16, EV_IN=32, EV_OUT=64 };
static volatile uint32_t events, rx_bytes;
static volatile uint8_t wanted_config;
static uint8_t medium_ready, media_attempted, switch_target, switch_armed;
static uint32_t blocks, next_probe_ms, switch_tick;
volatile struct {
    uint32_t magic, version, configured, ready, writable, blocks, error;
    uint32_t commands, protocol_errors, blocks_read, blocks_written, init_attempts;
} xe_np_msc_diag;

void XE_NP_UsbMsc_SelectBootMode(void)
{
    uint32_t action=XE_NP_Boot_ConsumeRequest();
    boot_mode=(action==XE_NP_BOOT_ACTION_MSC_RO || action==XE_NP_BOOT_ACTION_MSC_RW) ? (uint8_t)action : 0U;
}
int XE_NP_UsbMsc_IsSelected(void) { return boot_mode != 0U; }
static int cancelled(void) { return (events & (EV_RESET|EV_CONFIG|EV_BOT_RESET)) != 0U; }
static int tx(void *c,const uint8_t *p,uint32_t n)
{
    (void)c;
    if(cancelled() || n>sizeof(tx_scratch)) { return -1; }
    memcpy(tx_scratch,p,n);
    if(pcd->Init.dma_enable && n && HAL_DCACHE_CleanByAddr(&hdcache1,(const uint32_t *)tx_scratch,(n+31U)&~31U)!=HAL_OK) { return -1; }
    __DSB();return HAL_PCD_EP_Transmit(pcd,0x81,tx_scratch,n)==HAL_OK ? 0 : -1;
}
static int rx(void *c,uint8_t *p,uint32_t n)
{
    (void)c;
    if(cancelled() || switch_armed || p!=bot.rx_scratch || n>sizeof(bot.rx_scratch)) { return -1; }
    /* HAL rounds OUT DMA to a complete packet, including a 31-byte CBW. */
    uint32_t mps=pcd->Init.speed==PCD_SPEED_HIGH?512U:64U;
    rx_cache_bytes=(n+mps-1U)&~(mps-1U);
    if(pcd->Init.dma_enable && HAL_DCACHE_CleanInvalidByAddr(&hdcache1,(const uint32_t *)p,rx_cache_bytes)!=HAL_OK) { return -1; }
    __DSB();return HAL_PCD_EP_Receive(pcd,1,p,n)==HAL_OK ? 0 : -1;
}
static void stall(void *c,uint8_t ep) { (void)c;(void)HAL_PCD_EP_SetStall(pcd,ep); }
static void clear(void *c,uint8_t ep) { (void)c;(void)HAL_PCD_EP_ClrStall(pcd,ep); }
static void flush(void *c,uint8_t ep) { (void)c;(void)HAL_PCD_EP_Flush(pcd,ep); }
static int ready(void *c) { (void)c;return medium_ready && !cancelled(); }
static uint32_t capacity(void *c) { (void)c;return blocks; }
static int protected(void *c) { (void)c;return boot_mode != XE_NP_BOOT_ACTION_MSC_RW; }
static int sync_card(void *c)
{
    uint32_t start=HAL_GetTick(); (void)c;
    if(!medium_ready) { return -1; }
    while(HAL_SD_GetCardState(&hsd1) != HAL_SD_CARD_TRANSFER) {
        if(cancelled() || (uint32_t)(HAL_GetTick()-start)>=1000U) { return -1; }
    }
    return 0;
}
static int read_card(void *c,uint8_t *dst,uint32_t lba,uint32_t n)
{
    (void)c;
    if(!ready(NULL) || lba>blocks || n>blocks-lba) { return -1; }
    /* MSC is exclusive: polling avoids cache/DMA ownership hazards and keeps
     * this first implementation independent of the acquisition DMA rings. */
    if(HAL_SD_ReadBlocks(&hsd1,dst,lba,n,250U)!=HAL_OK || cancelled()) {
        xe_np_msc_diag.error=hsd1.ErrorCode; medium_ready=0U;return -1;
    }
    xe_np_msc_diag.blocks_read+=n;return 0;
}
static int write_card(void *c,const uint8_t *src,uint32_t lba,uint32_t n)
{
    (void)c;
    if(protected(NULL) || !ready(NULL) || lba>blocks || n>blocks-lba) { return -1; }
    if(HAL_SD_WriteBlocks(&hsd1,(uint8_t *)src,lba,n,250U)!=HAL_OK || sync_card(NULL)!=0) {
        xe_np_msc_diag.error=hsd1.ErrorCode; medium_ready=0U;return -1;
    }
    xe_np_msc_diag.blocks_written+=n;return 0;
}
static void put32(uint8_t *p,uint32_t n) { for(uint32_t i=0;i<4;i++)p[i]=(uint8_t)(n>>(8U*i)); }
static int control(void *c,uint8_t op,uint8_t *dst,uint32_t *n)
{
    (void)c;
    if(op==0U && dst && *n>=64U) {
        memset(dst,0,64);memcpy(dst,"XNMS",4);put32(dst+4,1U);
        put32(dst+8,(uint32_t)medium_ready | ((uint32_t)!protected(NULL)<<1U));
        put32(dst+12,blocks);put32(dst+16,512);put32(dst+20,hsd1.ErrorCode);
        put32(dst+24,XE_NP_BOOT_LOADER_ABI_VERSION);put32(dst+28,bot.commands);
        put32(dst+32,bot.errors);put32(dst+36,xe_np_msc_diag.blocks_read);put32(dst+40,xe_np_msc_diag.blocks_written);
        *n=64;return 0;
    }
    if(op<1U || op>5U) { return -1; }
    if(op==2U && !XE_NP_Boot_ManifestIsValid((const XE_NP_BootManifest *)XE_NP_BOOT_MANIFEST_BASE,1)) { return -1; }
    switch_target=op;return 0;
}
static void ack(void *c) { (void)c;switch_armed=1U;switch_tick=HAL_GetTick(); }
static const XE_NP_MscOps ops={tx,rx,stall,clear,flush,ready,capacity,protected,read_card,write_card,sync_card,control,ack};

void XE_NP_UsbMsc_Init(PCD_HandleTypeDef *h)
{
    pcd=h;events=0U;wanted_config=0U;medium_ready=media_attempted=switch_armed=switch_target=0U;
    blocks=next_probe_ms=0U;
    memset((void *)&xe_np_msc_diag,0,sizeof(xe_np_msc_diag));
    xe_np_msc_diag.magic=0x534D4E58UL;xe_np_msc_diag.version=1U;
    XE_NP_MscBot_Init(&bot,&ops,NULL);
}
void XE_NP_UsbMsc_Configure(uint8_t value) { wanted_config=value;events|=EV_CONFIG; }
void XE_NP_UsbMsc_Reset(void) { wanted_config=0U;events|=EV_RESET; }
void XE_NP_UsbMsc_DataIn(void) { events|=EV_IN; }
void XE_NP_UsbMsc_DataOut(uint32_t n) { rx_bytes=n;events|=EV_OUT; }
void XE_NP_UsbMsc_ClassReset(void) { events|=EV_BOT_RESET; }
void XE_NP_UsbMsc_ClearHalt(uint8_t ep) { if(ep==0x81)events|=EV_CLEAR_IN;else if(ep==1)events|=EV_CLEAR_OUT; }

void XE_NP_UsbMsc_Service(void)
{
    uint32_t primask=__get_PRIMASK(), pending, received;
    __disable_irq();pending=events;events=0U;received=rx_bytes;__set_PRIMASK(primask);
    if(pending&(EV_RESET|EV_CONFIG)) {
        (void)HAL_PCD_EP_Abort(pcd,0x81);(void)HAL_PCD_EP_Abort(pcd,1);
        XE_NP_MscBot_Init(&bot,&ops,NULL);switch_armed=switch_target=0U;
        if(wanted_config) { XE_NP_MscBot_Configure(&bot); }
        pending&=~(EV_IN|EV_OUT|EV_BOT_RESET|EV_CLEAR_IN|EV_CLEAR_OUT);
    }
    if(pending&EV_BOT_RESET) {
        (void)HAL_PCD_EP_Abort(pcd,0x81);(void)HAL_PCD_EP_Abort(pcd,1);
        XE_NP_MscBot_ClassReset(&bot);switch_armed=switch_target=0U;pending&=~(EV_IN|EV_OUT);
    }
    if(pending&EV_CLEAR_IN)XE_NP_MscBot_ClearHalt(&bot,0x81);
    if(pending&EV_CLEAR_OUT)XE_NP_MscBot_ClearHalt(&bot,1);
    if(pending&EV_IN)XE_NP_MscBot_TransmitDone(&bot);
    if(pending&EV_OUT) {
        if(pcd->Init.dma_enable && HAL_DCACHE_InvalidateByAddr(&hdcache1,(const uint32_t *)bot.rx_scratch,rx_cache_bytes)!=HAL_OK) {
            /* Fail closed; an impossible RX count enters BOT reset recovery. */
            received=sizeof(bot.rx_scratch)+1U;
        }
        __DSB();XE_NP_MscBot_Receive(&bot,received);
    }
    if(switch_armed && (uint32_t)(HAL_GetTick()-switch_tick)>=50U) {
        if(switch_target==1U)XE_NP_Boot_RequestUsbService();
        else if(switch_target==3U)XE_NP_Boot_RequestUsbUpdate();
        else if(switch_target>=4U)XE_NP_Boot_RequestMsc(switch_target==4U);
        (void)HAL_PCD_DevDisconnect(pcd);
        HAL_Delay(100U);
        NVIC_SystemReset();
    }
    if((int32_t)(HAL_GetTick()-next_probe_ms)>=0 && wanted_config && !switch_armed) {
        next_probe_ms=HAL_GetTick()+250U;
        if(HAL_GPIO_ReadPin(SD_DET_GPIO_Port,SD_DET_Pin)==GPIO_PIN_SET) {
            medium_ready=0U;blocks=0U;media_attempted=0U;
        } else if(!medium_ready && !media_attempted && bot.bot.bot_state==USBD_BOT_IDLE && !bot.tx_pending) {
            HAL_SD_CardInfoTypeDef info;
            media_attempted=1U;xe_np_msc_diag.init_attempts++;
            if(XE_NP_Board_InitSdForUsb()==0 && HAL_SD_GetCardInfo(&hsd1,&info)==HAL_OK && info.LogBlockSize==512U && info.LogBlockNbr>0U) {
                blocks=info.LogBlockNbr;medium_ready=1U;
            }
            xe_np_msc_diag.error=hsd1.ErrorCode;
        }
    }
    xe_np_msc_diag.configured=wanted_config;xe_np_msc_diag.ready=medium_ready;
    xe_np_msc_diag.writable=!protected(NULL);xe_np_msc_diag.blocks=blocks;
    xe_np_msc_diag.commands=bot.commands;xe_np_msc_diag.protocol_errors=bot.errors;
}
