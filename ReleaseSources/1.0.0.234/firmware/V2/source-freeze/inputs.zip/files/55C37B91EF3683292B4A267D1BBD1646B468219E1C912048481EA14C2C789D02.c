#include "xe_np_np2_grid16_stage.h"
#include "xe_np_np2_grid16_sector.h"
#include <string.h>

int XE_NP_Grid16Stage_Init(XE_NP_Grid16Stage *s,uint8_t *sectors,size_t capacity,
                            uint32_t generation,uint64_t preceding,uint32_t k)
{
    if(!s || !sectors || ((uintptr_t)sectors&31U) || k<1U || k>5U ||
       capacity<(size_t)k*512U || !generation || preceding==UINT64_MAX ||
       (preceding&3U)!=3U || np_imu_grid_overlap(s,sizeof(*s),sectors,(size_t)k*512U))return 0;
    memset(s,0,sizeof(*s));s->sectors=sectors;s->generation=generation;
    s->preceding=preceding;s->k=k;return 1;
}
int XE_NP_Grid16Stage_Add(XE_NP_Grid16Stage *s,const uint8_t *frame,size_t bytes)
{
    if(!s || !s->sectors || s->sealed || s->used>=s->k || !frame || bytes<48U)return 0;
    uint32_t count=np_imu_grid_count(np_imu_grid_u16(frame+20U));
    if(!XE_NP_Grid16Sector_Wrap(s->sectors+s->used*512U,s->generation,s->preceding,frame,bytes))return 0;
    s->observed+=count;s->used++;return 1;
}
int XE_NP_Grid16Stage_Seal(XE_NP_Grid16Stage *s)
{
    if(!s || !s->sectors || s->sealed || s->used>s->k)return 0;
    for(uint32_t i=s->used;i<s->k;i++)
        if(!XE_NP_Grid16Sector_Wrap(s->sectors+i*512U,s->generation,s->preceding,NULL,0U))return 0;
    s->sealed=1U;return 1;
}
