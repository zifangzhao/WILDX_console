#ifndef XE_NP_NP2_GRID16_STAGE_H
#define XE_NP_NP2_GRID16_STAGE_H
#include <stddef.h>
#include <stdint.h>

/* Caller owns an aligned K-sector DMA buffer until the SD writer retires it.
 * One stage corresponds to one ordered four-NP-block group. */
typedef struct {
    uint8_t *sectors;
    uint64_t preceding,observed;
    uint32_t generation,k,used,sealed;
} XE_NP_Grid16Stage;
int XE_NP_Grid16Stage_Init(XE_NP_Grid16Stage *stage,uint8_t *sectors,size_t capacity,
                            uint32_t generation,uint64_t preceding,uint32_t k);
/* Call only with a producer-owned NSG1 packet and only if used < k. */
int XE_NP_Grid16Stage_Add(XE_NP_Grid16Stage *stage,const uint8_t *frame,size_t bytes);
/* Fill remaining positions with explicit empty sectors; no waiting for data. */
int XE_NP_Grid16Stage_Seal(XE_NP_Grid16Stage *stage);
#endif
