#include "xe_np_capture.h"
#include "xe_np_psram.h"

#include <string.h>

#if defined(__has_include)
#if __has_include("main.h")
#include "main.h"
#define XE_NP_CAPTURE_HAVE_MAIN_HEADER 1
#endif
#endif

#if defined(XE_NP_CAPTURE_HAVE_MAIN_HEADER)
extern DCACHE_HandleTypeDef hdcache1;

#if (XE_NP_BOARD_V2_PSSI_NP1_ENABLE == 0U)
#if defined(__STDC_VERSION__) && (__STDC_VERSION__ >= 201112L)
#define XE_NP_CAPTURE_STATIC_ASSERT(cond, msg) _Static_assert(cond, msg)
#else
#define XE_NP_CAPTURE_STATIC_ASSERT3(cond, line) typedef char xe_np_capture_static_assert_##line[(cond) ? 1 : -1]
#define XE_NP_CAPTURE_STATIC_ASSERT2(cond, line) XE_NP_CAPTURE_STATIC_ASSERT3(cond, line)
#define XE_NP_CAPTURE_STATIC_ASSERT(cond, msg) XE_NP_CAPTURE_STATIC_ASSERT2(cond, __LINE__)
#endif

/*
 * The direct GPIO DMA path assumes each probe occupies one contiguous 8-bit
 * lane snapshot:
 *   NP1 -> GPIOE bits 0..7   (SYNC, DATA0..6)
 *   NP2 -> GPIOE bits 8..15  (SYNC, DATA0..6)
 *   NP3 -> GPIOD bits 8..15  (SYNC, DATA0..6)
 * If CubeMX or the board mapping drifts away from that layout, fail the build
 * rather than silently decoding the wrong bits as Neuropixels frames.
 */
XE_NP_CAPTURE_STATIC_ASSERT(NP1_SYNC_Pin == GPIO_PIN_0, "NP1 sync must stay on GPIOE bit 0");
XE_NP_CAPTURE_STATIC_ASSERT(NP1_D0_Pin == GPIO_PIN_1, "NP1 D0 must stay on GPIOE bit 1");
XE_NP_CAPTURE_STATIC_ASSERT(NP1_D1_Pin == GPIO_PIN_2, "NP1 D1 must stay on GPIOE bit 2");
XE_NP_CAPTURE_STATIC_ASSERT(NP1_D2_Pin == GPIO_PIN_3, "NP1 D2 must stay on GPIOE bit 3");
XE_NP_CAPTURE_STATIC_ASSERT(NP1_D3_Pin == GPIO_PIN_4, "NP1 D3 must stay on GPIOE bit 4");
XE_NP_CAPTURE_STATIC_ASSERT(NP1_D4_Pin == GPIO_PIN_5, "NP1 D4 must stay on GPIOE bit 5");
XE_NP_CAPTURE_STATIC_ASSERT(NP1_D5_Pin == GPIO_PIN_6, "NP1 D5 must stay on GPIOE bit 6");
XE_NP_CAPTURE_STATIC_ASSERT(NP1_D6_Pin == GPIO_PIN_7, "NP1 D6 must stay on GPIOE bit 7");
XE_NP_CAPTURE_STATIC_ASSERT(NP2_SYNC_Pin == GPIO_PIN_8, "NP2 sync must stay on GPIOE bit 8");
XE_NP_CAPTURE_STATIC_ASSERT(NP2_D0_Pin == GPIO_PIN_9, "NP2 D0 must stay on GPIOE bit 9");
XE_NP_CAPTURE_STATIC_ASSERT(NP2_D1_Pin == GPIO_PIN_10, "NP2 D1 must stay on GPIOE bit 10");
XE_NP_CAPTURE_STATIC_ASSERT(NP2_D2_Pin == GPIO_PIN_11, "NP2 D2 must stay on GPIOE bit 11");
XE_NP_CAPTURE_STATIC_ASSERT(NP2_D3_Pin == GPIO_PIN_12, "NP2 D3 must stay on GPIOE bit 12");
XE_NP_CAPTURE_STATIC_ASSERT(NP2_D4_Pin == GPIO_PIN_13, "NP2 D4 must stay on GPIOE bit 13");
XE_NP_CAPTURE_STATIC_ASSERT(NP2_D5_Pin == GPIO_PIN_14, "NP2 D5 must stay on GPIOE bit 14");
XE_NP_CAPTURE_STATIC_ASSERT(NP2_D6_Pin == GPIO_PIN_15, "NP2 D6 must stay on GPIOE bit 15");
XE_NP_CAPTURE_STATIC_ASSERT(NP3_SYNC_Pin == GPIO_PIN_8, "NP3 sync must stay on GPIOD bit 8");
XE_NP_CAPTURE_STATIC_ASSERT(NP3_D0_Pin == GPIO_PIN_9, "NP3 D0 must stay on GPIOD bit 9");
XE_NP_CAPTURE_STATIC_ASSERT(NP3_D1_Pin == GPIO_PIN_10, "NP3 D1 must stay on GPIOD bit 10");
XE_NP_CAPTURE_STATIC_ASSERT(NP3_D2_Pin == GPIO_PIN_11, "NP3 D2 must stay on GPIOD bit 11");
XE_NP_CAPTURE_STATIC_ASSERT(NP3_D3_Pin == GPIO_PIN_12, "NP3 D3 must stay on GPIOD bit 12");
XE_NP_CAPTURE_STATIC_ASSERT(NP3_D4_Pin == GPIO_PIN_13, "NP3 D4 must stay on GPIOD bit 13");
XE_NP_CAPTURE_STATIC_ASSERT(NP3_D5_Pin == GPIO_PIN_14, "NP3 D5 must stay on GPIOD bit 14");
XE_NP_CAPTURE_STATIC_ASSERT(NP3_D6_Pin == GPIO_PIN_15, "NP3 D6 must stay on GPIOD bit 15");

static int XE_NP_Capture_HasExpectedGpioPortLayout(void)
{
    return ((NP1_SYNC_GPIO_Port == GPIOE) &&
            (NP1_D0_GPIO_Port == GPIOE) &&
            (NP1_D1_GPIO_Port == GPIOE) &&
            (NP1_D2_GPIO_Port == GPIOE) &&
            (NP1_D3_GPIO_Port == GPIOE) &&
            (NP1_D4_GPIO_Port == GPIOE) &&
            (NP1_D5_GPIO_Port == GPIOE) &&
            (NP1_D6_GPIO_Port == GPIOE) &&
            (NP2_SYNC_GPIO_Port == GPIOE) &&
            (NP2_D0_GPIO_Port == GPIOE) &&
            (NP2_D1_GPIO_Port == GPIOE) &&
            (NP2_D2_GPIO_Port == GPIOE) &&
            (NP2_D3_GPIO_Port == GPIOE) &&
            (NP2_D4_GPIO_Port == GPIOE) &&
            (NP2_D5_GPIO_Port == GPIOE) &&
            (NP2_D6_GPIO_Port == GPIOE) &&
            (NP3_SYNC_GPIO_Port == GPIOD) &&
            (NP3_D0_GPIO_Port == GPIOD) &&
            (NP3_D1_GPIO_Port == GPIOD) &&
            (NP3_D2_GPIO_Port == GPIOD) &&
            (NP3_D3_GPIO_Port == GPIOD) &&
            (NP3_D4_GPIO_Port == GPIOD) &&
            (NP3_D5_GPIO_Port == GPIOD) &&
            (NP3_D6_GPIO_Port == GPIOD)) ? 1 : 0;
}
#endif
#endif

#define XE_NP_CAPTURE_ALIGNMENT_VALIDATION_FRAMES XE_NP_CAPTURE_FRAMES_PER_SUPERFRAME
#if (XE_NP_BOARD_V2_PSSI_NP1_ENABLE != 0U)
#define XE_NP_CAPTURE_LANE_SYNC_MASK 0x80U
#define XE_NP_CAPTURE_LANE_DATA_SHIFT 0U
#else
#define XE_NP_CAPTURE_LANE_SYNC_MASK 0x01U
#define XE_NP_CAPTURE_LANE_DATA_SHIFT 1U
#endif
#define XE_NP_PSB_VALIDATOR_LOCK_FATAL_FLAGS \
    (XE_NP_PSB_VALIDATOR_FLAG_SYNC_ERROR | XE_NP_PSB_VALIDATOR_FLAG_FILL_ERROR | \
     XE_NP_PSB_VALIDATOR_FLAG_HEARTBEAT_ERROR)
#define XE_NP_CAPTURE_FORCE_NP2_HALFWORD 0U

static uint32_t XE_NP_PsbValidator_ConsumeFrameInternal(
    XE_NP_PsbValidator *validator,
    const XE_NP_PsbFrame *frame,
    uint8_t enforce_counter_step);
static uint32_t XE_NP_PsbValidator_LockFatalFlags(uint32_t flags);
static int XE_NP_Capture_ValidateFrameAlignmentAtOffset(
    const uint16_t *snapshots,
    size_t tick_count,
    uint8_t probe_index,
    size_t offset);
static int XE_NP_Capture_PortFrameAlignedAtOffset(
    const XE_NP_CaptureState *state,
    uint8_t port_index,
    const uint16_t *snapshots,
    size_t tick_count,
    size_t offset);
static int XE_NP_Capture_FindPortFrameAlignment(
    XE_NP_CaptureState *state,
    uint8_t port_index,
    const uint16_t *snapshots,
    size_t tick_count,
    size_t *aligned_offset);

static uint8_t XE_NP_Capture_LaneByteFromSnapshot(uint16_t snapshot, uint8_t probe_index)
{
    switch(probe_index)
    {
        case 0U:
            return XE_NP_Capture_ExtractNp1LaneByte(snapshot);
        case 1U:
            return XE_NP_Capture_ExtractNp2LaneByte(snapshot);
        case 2U:
            return XE_NP_Capture_ExtractNp3LaneByte(snapshot);
        default:
            return 0U;
    }
}

static uint8_t XE_NP_Capture_CountActiveProbes(uint8_t mask)
{
    uint8_t count = 0U;

    mask &= XE_NP_CAPTURE_ALL_PROBES_MASK;
    while(mask != 0U)
    {
        count += (uint8_t)(mask & 0x01U);
        mask >>= 1U;
    }

    return count;
}

static void XE_NP_CapturePort_Reset(XE_NP_CapturePort *port)
{
    if(port == NULL)
    {
        return;
    }

    memset(port, 0, sizeof(*port));
}

static void XE_NP_CapturePort_Assign(
    XE_NP_CapturePort *port,
    uint8_t *storage,
    uint32_t storage_bytes,
    uint8_t active_probe_mask,
    uint8_t bytes_per_tick,
    uint32_t psb_clk_hz)
{
    if(port == NULL)
    {
        return;
    }

    port->storage = storage;
    port->storage_bytes = storage_bytes;
    port->storage_physical_bytes = storage_bytes;
    port->total_bytes_captured = 0ULL;
    port->dma_windows_captured = 0U;
    port->active_probe_mask = active_probe_mask;
    port->bytes_per_tick = bytes_per_tick;
    port->raw_bytes_per_sec = psb_clk_hz * (uint32_t)bytes_per_tick;

    if((storage != NULL) && (storage_bytes != 0U))
    {
        dataMGR_init(&port->raw_mgr, (char *)storage, storage_bytes);
        dataMGR_setActiveOutMask(&port->raw_mgr, 0U);
    }

    if((port->raw_bytes_per_sec != 0U) && (storage_bytes != 0U))
    {
        uint64_t window = (uint64_t)storage_bytes * 1000000ULL;
        window /= port->raw_bytes_per_sec;
        port->ring_window_us = (uint32_t)window;
    }
    else
    {
        port->ring_window_us = 0U;
    }
}

static uint32_t XE_NP_Capture_ActivePortCount(uint8_t mask)
{
    uint32_t count = 0U;

    if((mask & (XE_NP_CAPTURE_PROBE1_MASK | XE_NP_CAPTURE_PROBE2_MASK)) != 0U)
    {
        count++;
    }
    if((mask & XE_NP_CAPTURE_PROBE3_MASK) != 0U)
    {
        count++;
    }

    return count;
}

static XE_NP_CapturePort *XE_NP_Capture_GetPort(XE_NP_CaptureState *state, uint8_t port_index)
{
    if(state == NULL)
    {
        return NULL;
    }

    if(port_index == 0U)
    {
        return &state->gpioe;
    }
    if(port_index == 1U)
    {
        return &state->gpiod;
    }

    return NULL;
}

static int XE_NP_Capture_GetPortProbeIds(
    const XE_NP_CaptureState *state,
    uint8_t port_index,
    uint8_t *probe_ids,
    uint8_t *probe_count)
{
    uint8_t count = 0U;

    if((state == NULL) || (probe_ids == NULL) || (probe_count == NULL))
    {
        return -1;
    }

    if(port_index == 0U)
    {
        if((state->gpioe.active_probe_mask & XE_NP_CAPTURE_PROBE1_MASK) != 0U)
        {
            probe_ids[count++] = 0U;
        }
        if((state->gpioe.active_probe_mask & XE_NP_CAPTURE_PROBE2_MASK) != 0U)
        {
            probe_ids[count++] = 1U;
        }
    }
    else if(port_index == 1U)
    {
        if((state->gpiod.active_probe_mask & XE_NP_CAPTURE_PROBE3_MASK) != 0U)
        {
            probe_ids[count++] = 2U;
        }
    }
    else
    {
        return -1;
    }

    *probe_count = count;
    return (count != 0U) ? 0 : -1;
}

static int XE_NP_Capture_FindFrameAlignment(
    XE_NP_CapturePort *port,
    const uint16_t *snapshots,
    size_t tick_count,
    uint8_t probe_index,
    size_t *aligned_offset)
{
    size_t search_limit;

    if((port == NULL) || (snapshots == NULL) || (aligned_offset == NULL) ||
       (tick_count < XE_NP_CAPTURE_FRAME_BIT_COUNT))
    {
        return -1;
    }

    search_limit = XE_NP_CAPTURE_FRAME_BIT_COUNT - 1U;
    if(tick_count < (search_limit + XE_NP_CAPTURE_FRAME_BIT_COUNT))
    {
        search_limit = tick_count - XE_NP_CAPTURE_FRAME_BIT_COUNT;
    }

    for(size_t offset = 0U; offset <= search_limit; ++offset)
    {
        if(XE_NP_Capture_ValidateFrameAlignmentAtOffset(
               snapshots,
               tick_count,
               probe_index,
               offset) != 0)
        {
            continue;
        }

        port->frame_alignment_ticks = (uint16_t)offset;
        port->frame_alignment_locked = 1U;
        *aligned_offset = offset;
        return 0;
    }

    port->frame_alignment_ticks = 0U;
    port->frame_alignment_locked = 0U;
    *aligned_offset = 0U;
    return -1;
}

static int XE_NP_Capture_ValidateFrameAlignmentAtOffset(
    const uint16_t *snapshots,
    size_t tick_count,
    uint8_t probe_index,
    size_t offset)
{
    XE_NP_PsbFrame frame;
    XE_NP_PsbValidator validator;
    size_t frames_to_check;
    size_t frame_index;

    if((snapshots == NULL) ||
       ((offset + XE_NP_CAPTURE_FRAME_BIT_COUNT) > tick_count))
    {
        return -1;
    }

    if(XE_NP_PsbFrame_DecodeFromSnapshots(
           &frame,
           &snapshots[offset],
           tick_count - offset,
           probe_index) != 0)
    {
        return -1;
    }

    frames_to_check = (tick_count - offset) / XE_NP_CAPTURE_FRAME_BIT_COUNT;
    if(frames_to_check > XE_NP_CAPTURE_ALIGNMENT_VALIDATION_FRAMES)
    {
        frames_to_check = XE_NP_CAPTURE_ALIGNMENT_VALIDATION_FRAMES;
    }
    if(frames_to_check < 2U)
    {
        return -1;
    }

    XE_NP_PsbValidator_Init(&validator);
    for(frame_index = 0U; frame_index < frames_to_check; ++frame_index)
    {
        size_t frame_offset = offset + (frame_index * XE_NP_CAPTURE_FRAME_BIT_COUNT);
        if(XE_NP_PsbFrame_DecodeFromSnapshots(
               &frame,
               &snapshots[frame_offset],
               tick_count - frame_offset,
               probe_index) != 0)
        {
            return -1;
        }
        /*
         * GPIO-DMA is a mitigation receiver: it can prove PSB presence and
         * frame cadence from the sync/fill/heartbeat fields, but the data-line
         * counter can be phase-sensitive without an external latch. Do not
         * reject alignment solely because the decoded counter/superframe phase
         * is imperfect; strict packet decode still checks those later.
         */
        if(XE_NP_PsbValidator_LockFatalFlags(
               XE_NP_PsbValidator_ConsumeFrameInternal(&validator, &frame, 0U)) != 0U)
        {
            return -1;
        }
    }

    return 0;
}

static int XE_NP_Capture_PortFrameAlignedAtOffset(
    const XE_NP_CaptureState *state,
    uint8_t port_index,
    const uint16_t *snapshots,
    size_t tick_count,
    size_t offset)
{
    XE_NP_PsbFrame frame;
    uint8_t probe_ids[2];
    uint8_t probe_count = 0U;

    if((state == NULL) || (snapshots == NULL) ||
       ((offset + XE_NP_CAPTURE_FRAME_BIT_COUNT) > tick_count) ||
       (XE_NP_Capture_GetPortProbeIds(state, port_index, probe_ids, &probe_count) != 0))
    {
        return 0;
    }

    for(uint8_t idx = 0U; idx < probe_count; ++idx)
    {
        if(XE_NP_PsbFrame_DecodeFromSnapshots(
               &frame,
               &snapshots[offset],
               tick_count - offset,
               probe_ids[idx]) != 0)
        {
            return 0;
        }
    }

    return 1;
}

static int XE_NP_Capture_FindPortFrameAlignment(
    XE_NP_CaptureState *state,
    uint8_t port_index,
    const uint16_t *snapshots,
    size_t tick_count,
    size_t *aligned_offset)
{
    XE_NP_CapturePort *port;
    uint8_t probe_ids[2];
    uint8_t probe_count = 0U;
    size_t search_limit;

    if((state == NULL) || (snapshots == NULL) || (aligned_offset == NULL) ||
       (tick_count < XE_NP_CAPTURE_FRAME_BIT_COUNT))
    {
        return -1;
    }

    port = XE_NP_Capture_GetPort(state, port_index);
    if((port == NULL) ||
       (XE_NP_Capture_GetPortProbeIds(state, port_index, probe_ids, &probe_count) != 0))
    {
        return -1;
    }

    search_limit = XE_NP_CAPTURE_FRAME_BIT_COUNT - 1U;
    if(tick_count < (search_limit + XE_NP_CAPTURE_FRAME_BIT_COUNT))
    {
        search_limit = tick_count - XE_NP_CAPTURE_FRAME_BIT_COUNT;
    }

    for(size_t offset = 0U; offset <= search_limit; ++offset)
    {
        uint8_t idx;
        {
            for(idx = 0U; idx < probe_count; ++idx)
            {
                if(XE_NP_Capture_ValidateFrameAlignmentAtOffset(
                       snapshots,
                       tick_count,
                       probe_ids[idx],
                       offset) != 0)
                {
                    break;
                }
            }
        }
        if(idx != probe_count)
        {
            continue;
        }

        port->frame_alignment_ticks = (uint16_t)offset;
        port->frame_alignment_locked = 1U;
        *aligned_offset = offset;
        return 0;
    }

    port->frame_alignment_ticks = 0U;
    port->frame_alignment_locked = 0U;
    *aligned_offset = 0U;
    return -1;
}

void XE_NP_Capture_Init(XE_NP_CaptureState *state, uint8_t *storage, uint32_t storage_bytes)
{
    if(state == NULL)
    {
        return;
    }

    memset(state, 0, sizeof(*state));
    state->raw_storage = storage;
    state->raw_storage_bytes = storage_bytes;

    for(uint8_t i = 0U; i < XE_NP_NEUROPIXELS_MAX_PROBES; ++i)
    {
        XE_NP_PsbValidator_Init(&state->validators[i]);
    }
}

void XE_NP_Capture_BindTimers(
    XE_NP_CaptureState *state,
    TIM_HandleTypeDef *tim_gpioe,
    TIM_HandleTypeDef *tim_gpiod)
{
    if(state == NULL)
    {
        return;
    }

    state->gpioe.htim = tim_gpioe;
    state->gpiod.htim = tim_gpiod;
}

uint32_t XE_NP_Capture_MinimumBytesPerTick(uint8_t active_probe_mask)
{
#if XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE
    /* U$1/U$3 share PSSI[5:0] in ONE byte; not V1 low/high GPIO bytes. */
    return active_probe_mask==XE_NP_BOARD_PSSI_PROBE_MASK ? 1U : 0U;
#else
    uint32_t bytes_per_tick = 0U;

    active_probe_mask &= XE_NP_CAPTURE_ALL_PROBES_MASK;
    if((active_probe_mask & (XE_NP_CAPTURE_PROBE1_MASK | XE_NP_CAPTURE_PROBE2_MASK)) ==
       (XE_NP_CAPTURE_PROBE1_MASK | XE_NP_CAPTURE_PROBE2_MASK))
    {
        /*
         * NP1 and NP2 share GPIOE as low/high bytes, so dual-probe capture
         * needs the aligned 16-bit GPIOE snapshot.
         */
        bytes_per_tick += sizeof(uint16_t);
    }
#if (XE_NP_CAPTURE_FORCE_NP2_HALFWORD != 0U)
    else if((active_probe_mask & XE_NP_CAPTURE_PROBE2_MASK) != 0U)
    {
        /*
         * Bench experiment: capture NP2 through the aligned 16-bit GPIOE
         * snapshot path, then repack to lane8 for USB. If the remaining seam
         * disappears here, the byte-wide GPIOE->IDR+1 DMA path is the real
         * culprit, not the Neuropixels stream itself.
         */
        bytes_per_tick += sizeof(uint16_t);
    }
#else
    else if((active_probe_mask & XE_NP_CAPTURE_PROBE2_MASK) != 0U)
    {
        bytes_per_tick += sizeof(uint8_t);
    }
#endif
    else if((active_probe_mask & XE_NP_CAPTURE_PROBE1_MASK) != 0U)
    {
        bytes_per_tick += sizeof(uint8_t);
    }
    if((active_probe_mask & XE_NP_CAPTURE_PROBE3_MASK) != 0U)
    {
        bytes_per_tick += sizeof(uint8_t);
    }

    return bytes_per_tick;
#endif
}

uint32_t XE_NP_Capture_DecodedBytesPerSecond(uint8_t active_probe_mask)
{
    uint32_t probe_count;

    probe_count = XE_NP_Capture_CountActiveProbes(active_probe_mask);
    return probe_count * XE_NP_NEUROPIXELS_CHANNELS_PER_PROBE * XE_NP_NEUROPIXELS_SAMPLE_RATE_HZ * sizeof(int16_t);
}

int XE_NP_Capture_Configure(XE_NP_CaptureState *state, uint8_t active_probe_mask, uint32_t psb_clk_hz)
{
    uint32_t active_port_count;
    uint32_t total_node_count;
    uint32_t first_port_nodes = 0U;
    uint32_t second_port_nodes = 0U;
    uint32_t first_port_bytes = 0U;
    uint32_t second_port_bytes = 0U;
    uint8_t *storage_cursor;
    TIM_HandleTypeDef *tim_gpioe;
    TIM_HandleTypeDef *tim_gpiod;

    if(state == NULL)
    {
        return -1;
    }

    #if !XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE
    active_probe_mask &= XE_NP_CAPTURE_ALL_PROBES_MASK;
    #endif
    tim_gpioe = state->gpioe.htim;
    tim_gpiod = state->gpiod.htim;
    XE_NP_CapturePort_Reset(&state->gpioe);
    XE_NP_CapturePort_Reset(&state->gpiod);
    state->gpioe.htim = tim_gpioe;
    state->gpiod.htim = tim_gpiod;
    state->flags = XE_NP_CAPTURE_FLAG_RAW_ONLY;
    state->layout = XE_NP_CAPTURE_LAYOUT_NONE;
    state->active_probe_mask = active_probe_mask;
    state->active_probe_count = XE_NP_Capture_CountActiveProbes(active_probe_mask);
    state->active_port_count = 0U;
    state->psb_clk_hz = psb_clk_hz;

    for(uint8_t i = 0U; i < XE_NP_NEUROPIXELS_MAX_PROBES; ++i)
    {
        XE_NP_PsbValidator_Init(&state->validators[i]);
    }

#if defined(XE_NP_CAPTURE_HAVE_MAIN_HEADER) && (XE_NP_BOARD_V2_PSSI_NP1_ENABLE == 0U)
    if(XE_NP_Capture_HasExpectedGpioPortLayout() == 0)
    {
        state->flags |= XE_NP_CAPTURE_FLAG_GPIO_LAYOUT_UNSUPPORTED;
        return -1;
    }
#endif

    if(state->active_probe_count == 0U)
    {
        state->flags |= XE_NP_CAPTURE_FLAG_UNSUPPORTED_PROBE_MASK;
        return -1;
    }

#if (XE_NP_BOARD_V2_PSSI_NP1_ENABLE != 0U)
    if(active_probe_mask != XE_NP_BOARD_PSSI_PROBE_MASK)
    {
        /* Exact generation-specific PSSI connector set, no mixed probes. */
        state->flags |= XE_NP_CAPTURE_FLAG_UNSUPPORTED_PROBE_MASK;
        return -1;
    }
#endif

#if XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE
    if(psb_clk_hz!=48000000U || psb_clk_hz!=XE_NP_Board_GetRuntimeExpectedPsbClkHz())
#else
    if((psb_clk_hz != XE_NP_Board_GetRuntimeExpectedPsbClkHz()) &&
       (psb_clk_hz != XE_NP_Board_GetRuntimeExpectedPsbClkHalfHz()))
#endif
    {
        /*
         * This board reads the direct 7-bit PSB bus with timer-paced GPIO
         * snapshots. Accept only the two documented NRIC PSB rates so buffer
         * math and frame cadence cannot silently drift from the chip config.
         */
        state->flags |= XE_NP_CAPTURE_FLAG_CLOCK_MODE_UNSUPPORTED;
    }

    if((active_probe_mask & (XE_NP_CAPTURE_PROBE1_MASK | XE_NP_CAPTURE_PROBE2_MASK)) != 0U)
    {
        state->flags |= XE_NP_CAPTURE_FLAG_GPIOE_ACTIVE;
    }
    if((active_probe_mask & XE_NP_CAPTURE_PROBE3_MASK) != 0U)
    {
        state->flags |= XE_NP_CAPTURE_FLAG_GPIOD_ACTIVE;
    }

    state->bytes_per_tick = (uint8_t)XE_NP_Capture_MinimumBytesPerTick(active_probe_mask);
    state->raw_bytes_per_sec = state->bytes_per_tick * psb_clk_hz;
    state->decoded_bytes_per_sec = XE_NP_Capture_DecodedBytesPerSecond(active_probe_mask);
#if XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE
    state->frame_rate_hz = psb_clk_hz / 100U;
    state->superframe_rate_hz = state->frame_rate_hz / 16U;
    state->ultraframe_rate_hz = 0U; /* NP1 LFP ultraframe does not exist on NP2 */
    state->raw_bytes_per_frame = 100U;
    state->raw_bytes_per_superframe = 1600U;
    state->raw_bytes_per_ultraframe = 0U;
#else
    state->frame_rate_hz = psb_clk_hz / XE_NP_CAPTURE_FRAME_BIT_COUNT;
    state->superframe_rate_hz = state->frame_rate_hz / XE_NP_CAPTURE_FRAMES_PER_SUPERFRAME;
    state->ultraframe_rate_hz = state->superframe_rate_hz / XE_NP_CAPTURE_SUPERFRAMES_PER_ULTRAFRAME;
    state->raw_bytes_per_frame = state->bytes_per_tick * XE_NP_CAPTURE_FRAME_BIT_COUNT;
    state->raw_bytes_per_superframe = state->raw_bytes_per_frame * XE_NP_CAPTURE_FRAMES_PER_SUPERFRAME;
    state->raw_bytes_per_ultraframe = state->raw_bytes_per_superframe * XE_NP_CAPTURE_SUPERFRAMES_PER_ULTRAFRAME;
#endif

    active_port_count = XE_NP_Capture_ActivePortCount(active_probe_mask);
    state->active_port_count = (uint8_t)active_port_count;
    total_node_count = state->raw_storage_bytes / XE_NP_CAPTURE_DMA_NODE_BYTES;

    if((state->raw_storage == NULL) ||
       (state->raw_storage_bytes == 0U) ||
       ((state->raw_storage_bytes % XE_NP_CAPTURE_DMA_NODE_BYTES) != 0U))
    {
        state->flags |= XE_NP_CAPTURE_FLAG_STORAGE_LAYOUT_UNSUPPORTED;
    }

    if(active_port_count == 1U)
    {
        first_port_nodes = total_node_count;
        first_port_bytes = first_port_nodes * XE_NP_CAPTURE_DMA_NODE_BYTES;
        second_port_bytes = 0U;
    }
    else if(active_port_count == 2U)
    {
        first_port_nodes = total_node_count / 2U;
        second_port_nodes = total_node_count - first_port_nodes;
        first_port_bytes = first_port_nodes * XE_NP_CAPTURE_DMA_NODE_BYTES;
        second_port_bytes = second_port_nodes * XE_NP_CAPTURE_DMA_NODE_BYTES;
    }

    if(((state->flags & XE_NP_CAPTURE_FLAG_GPIOE_ACTIVE) != 0U) && (first_port_bytes == 0U))
    {
        state->flags |= XE_NP_CAPTURE_FLAG_STORAGE_LAYOUT_UNSUPPORTED;
    }
    if(((state->flags & XE_NP_CAPTURE_FLAG_GPIOD_ACTIVE) != 0U) &&
       (((active_port_count == 1U) ? first_port_bytes : second_port_bytes) == 0U))
    {
        state->flags |= XE_NP_CAPTURE_FLAG_STORAGE_LAYOUT_UNSUPPORTED;
    }
    if(first_port_nodes > XE_NP_CAPTURE_DMA_NODE_COUNT_MAX)
    {
        state->flags |= XE_NP_CAPTURE_FLAG_STORAGE_LAYOUT_UNSUPPORTED;
    }
    if(second_port_nodes > XE_NP_CAPTURE_DMA_NODE_COUNT_MAX)
    {
        state->flags |= XE_NP_CAPTURE_FLAG_STORAGE_LAYOUT_UNSUPPORTED;
    }

    storage_cursor = state->raw_storage;
    if((state->flags & XE_NP_CAPTURE_FLAG_GPIOE_ACTIVE) != 0U)
    {
        XE_NP_CapturePort_Assign(
            &state->gpioe,
            storage_cursor,
            first_port_bytes,
            (uint8_t)(active_probe_mask & (XE_NP_CAPTURE_PROBE1_MASK | XE_NP_CAPTURE_PROBE2_MASK)),
            (uint8_t)XE_NP_Capture_MinimumBytesPerTick(
                (uint8_t)(active_probe_mask & (XE_NP_CAPTURE_PROBE1_MASK | XE_NP_CAPTURE_PROBE2_MASK))),
            psb_clk_hz);
        storage_cursor += first_port_bytes;
    }

    if((state->flags & XE_NP_CAPTURE_FLAG_GPIOD_ACTIVE) != 0U)
    {
        XE_NP_CapturePort_Assign(
            &state->gpiod,
            storage_cursor,
            (active_port_count == 1U) ? first_port_bytes : second_port_bytes,
            (uint8_t)(active_probe_mask & XE_NP_CAPTURE_PROBE3_MASK),
            (uint8_t)XE_NP_Capture_MinimumBytesPerTick(
                (uint8_t)(active_probe_mask & XE_NP_CAPTURE_PROBE3_MASK)),
            psb_clk_hz);
    }

    if(((state->flags & XE_NP_CAPTURE_FLAG_GPIOE_ACTIVE) != 0U) &&
       ((state->flags & XE_NP_CAPTURE_FLAG_GPIOD_ACTIVE) != 0U))
    {
        state->layout = XE_NP_CAPTURE_LAYOUT_GPIOE_AND_GPIOD;
    }
    else if((state->flags & XE_NP_CAPTURE_FLAG_GPIOE_ACTIVE) != 0U)
    {
        state->layout = XE_NP_CAPTURE_LAYOUT_GPIOE_ONLY;
    }
    else if((state->flags & XE_NP_CAPTURE_FLAG_GPIOD_ACTIVE) != 0U)
    {
        state->layout = XE_NP_CAPTURE_LAYOUT_GPIOD_ONLY;
    }

    state->ring_window_us = 0U;
    if((state->flags & XE_NP_CAPTURE_FLAG_GPIOE_ACTIVE) != 0U)
    {
        state->ring_window_us = state->gpioe.ring_window_us;
    }
    if(((state->flags & XE_NP_CAPTURE_FLAG_GPIOD_ACTIVE) != 0U) &&
       ((state->ring_window_us == 0U) || (state->gpiod.ring_window_us < state->ring_window_us)))
    {
        state->ring_window_us = state->gpiod.ring_window_us;
    }

#if (XE_NP_BOARD_V2_PSSI_NP1_ENABLE == 0U)
    if((state->flags & XE_NP_CAPTURE_FLAG_GPIOE_ACTIVE) != 0U)
    {
        if(state->gpioe.htim == NULL)
        {
            state->flags |= XE_NP_CAPTURE_FLAG_TIMER_MISSING;
        }
    }
    if((state->flags & XE_NP_CAPTURE_FLAG_GPIOD_ACTIVE) != 0U)
    {
        if(state->gpiod.htim == NULL)
        {
            state->flags |= XE_NP_CAPTURE_FLAG_TIMER_MISSING;
        }
    }
#else
    /* Keep the legacy TIMERS_READY status contract for USB/SD consumers. On
     * V2 the source is paced directly by PSSI_PDCK and requires no TIM handle. */
#endif
    if((state->flags & XE_NP_CAPTURE_FLAG_TIMER_MISSING) == 0U)
    {
        state->flags |= XE_NP_CAPTURE_FLAG_TIMERS_READY;
    }

    if(state->raw_bytes_per_sec >= XE_NP_CAPTURE_DMA_STRESS_BYTES_PER_SEC)
    {
        state->flags |= XE_NP_CAPTURE_FLAG_DMA_RATE_STRESSED;
    }
    if((state->ring_window_us != 0U) && (state->ring_window_us < XE_NP_CAPTURE_RING_TIGHT_WINDOW_US))
    {
        state->flags |= XE_NP_CAPTURE_FLAG_BUFFER_TIGHT;
    }
    if((state->ring_window_us != 0U) && (state->ring_window_us < XE_NP_CAPTURE_RING_SHORT_WINDOW_US))
    {
        state->flags |= XE_NP_CAPTURE_FLAG_BUFFER_SHORT;
    }

    return XE_NP_Capture_IsDmaPacedFeasible(state) ? 0 : -1;
}

int XE_NP_Capture_EnableGpioeInterleavedLanes(XE_NP_CaptureState *state)
{
#if XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE
    (void)state;
    return -1; /* NP1/V1 time-lane experiments cannot reconfigure the NP2 source. */
#else
    uint8_t *storage;
    uint32_t lane_bytes;
    uint32_t lane_psb_clk_hz;
    TIM_HandleTypeDef *gpioe_timer;
    TIM_HandleTypeDef *gpiod_timer;
    uint8_t active_gpioe_probe_mask;

    if((state == NULL) ||
       ((state->flags & XE_NP_CAPTURE_FLAG_GPIOE_ACTIVE) == 0U) ||
       ((state->flags & XE_NP_CAPTURE_FLAG_GPIOD_ACTIVE) != 0U) ||
       (state->layout != XE_NP_CAPTURE_LAYOUT_GPIOE_ONLY) ||
       (state->gpioe.storage == NULL) ||
       (state->gpioe.bytes_per_tick != sizeof(uint8_t)) ||
       ((state->gpioe.active_probe_mask != XE_NP_CAPTURE_PROBE1_MASK) &&
        (state->gpioe.active_probe_mask != XE_NP_CAPTURE_PROBE2_MASK)) ||
       ((state->gpioe.storage_bytes & 0x01U) != 0U) ||
       ((state->psb_clk_hz & 0x01U) != 0U))
    {
        return -1;
    }

    storage = state->gpioe.storage;
    lane_bytes = state->gpioe.storage_bytes / 2U;
#if (XE_NP_APP_EXPERIMENT_GPIOE_DUAL_DMA_PHASE_PROBE_ENABLE != 0U)
    /* Both lanes acquire a timed DDR phase of every PSB cell. */
    lane_psb_clk_hz = state->psb_clk_hz;
#else
    lane_psb_clk_hz = state->psb_clk_hz / 2U;
#endif
    active_gpioe_probe_mask = state->gpioe.active_probe_mask;
    gpioe_timer = state->gpioe.htim;
    gpiod_timer = state->gpiod.htim;
    if((lane_bytes == 0U) || (lane_psb_clk_hz == 0U) ||
       (gpioe_timer == NULL) || (gpiod_timer == NULL))
    {
        return -1;
    }

    XE_NP_CapturePort_Reset(&state->gpioe);
    XE_NP_CapturePort_Reset(&state->gpiod);
    state->gpioe.htim = gpioe_timer;
    state->gpiod.htim = gpiod_timer;


    /*
     * Each DMA channel receives every other GPIO sample.  Giving each lane a
     * half-rate producer keeps the raw-byte rate and ring window honest for
     * its own consumer, while state->raw_bytes_per_sec remains the aggregate
     * GPIOE rate established by XE_NP_Capture_Configure().
     */
    XE_NP_CapturePort_Assign(
        &state->gpioe,
        storage,
        lane_bytes,
        active_gpioe_probe_mask,
        sizeof(uint8_t),
        lane_psb_clk_hz);
    XE_NP_CapturePort_Assign(
        &state->gpiod,
        storage + lane_bytes,
        lane_bytes,
        active_gpioe_probe_mask,
        sizeof(uint8_t),
        lane_psb_clk_hz);
    state->gpioe.htim = gpioe_timer;
    state->gpiod.htim = gpiod_timer;

    state->flags |= XE_NP_CAPTURE_FLAG_GPIOD_ACTIVE;
    state->layout = XE_NP_CAPTURE_LAYOUT_GPIOE_AND_GPIOD;
    state->active_port_count = 2U;
    state->ring_window_us = state->gpioe.ring_window_us;
    return 0;
#endif
}

int XE_NP_Capture_IsDmaPacedFeasible(const XE_NP_CaptureState *state)
{
    uint32_t blocking_flags;

    if(state == NULL)
    {
        return 0;
    }

    blocking_flags = XE_NP_CAPTURE_FLAG_CLOCK_MODE_UNSUPPORTED |
                     XE_NP_CAPTURE_FLAG_TIMER_MISSING |
                     XE_NP_CAPTURE_FLAG_UNSUPPORTED_PROBE_MASK |
                     XE_NP_CAPTURE_FLAG_STORAGE_LAYOUT_UNSUPPORTED |
                     XE_NP_CAPTURE_FLAG_GPIO_LAYOUT_UNSUPPORTED;
    return ((state->flags & blocking_flags) == 0U) ? 1 : 0;
}

void XE_NP_Capture_RecordGpioeBytes(XE_NP_CaptureState *state, uint32_t nbytes)
{
    if((state == NULL) || (state->gpioe.storage == NULL) || (state->gpioe.storage_bytes == 0U))
    {
        return;
    }

    dataMGR_enQueue_Nbytes(&state->gpioe.raw_mgr, nbytes);
    state->gpioe.total_bytes_captured += (uint64_t)nbytes;
    state->gpioe.dma_windows_captured++;
}

void XE_NP_Capture_RecordGpiodBytes(XE_NP_CaptureState *state, uint32_t nbytes)
{
    if((state == NULL) || (state->gpiod.storage == NULL) || (state->gpiod.storage_bytes == 0U))
    {
        return;
    }

    dataMGR_enQueue_Nbytes(&state->gpiod.raw_mgr, nbytes);
    state->gpiod.total_bytes_captured += (uint64_t)nbytes;
    state->gpiod.dma_windows_captured++;
}

void XE_NP_Capture_DCacheInvalidate(const void *addr, uint32_t size_bytes)
{
#if (XE_NP_CAPTURE_SRAM3_MPU_NONCACHEABLE != 0U)
    if(XE_NP_Capture_Sram3RangeContained(addr, size_bytes) != 0U)
    {
        return;
    }
#endif
#if (XE_NP_PSRAM_MPU_NONCACHEABLE_EXPERIMENT != 0U)
    if(XE_NP_Psram_RangeContained(addr, size_bytes) != 0U)
    {
        return;
    }
#endif
#if defined(DCACHE1) && defined(HAL_DCACHE_MODULE_ENABLED)
    uintptr_t start_addr;
    uintptr_t end_addr;

    if((addr == NULL) || (size_bytes == 0U))
    {
        return;
    }

    start_addr = ((uintptr_t)addr) & ~((uintptr_t)XE_NP_CAPTURE_DCACHE_LINE_BYTES - 1U);
    end_addr = (((uintptr_t)addr) + (uintptr_t)size_bytes + (XE_NP_CAPTURE_DCACHE_LINE_BYTES - 1U)) &
               ~((uintptr_t)XE_NP_CAPTURE_DCACHE_LINE_BYTES - 1U);
    (void)HAL_DCACHE_InvalidateByAddr(
        &hdcache1,
        (const uint32_t *const)start_addr,
        (uint32_t)(end_addr - start_addr));
#elif defined(__DCACHE_PRESENT) && (__DCACHE_PRESENT == 1U)
    uintptr_t start_addr;
    uintptr_t end_addr;

    if((addr == NULL) || (size_bytes == 0U))
    {
        return;
    }

    start_addr = ((uintptr_t)addr) & ~((uintptr_t)XE_NP_CAPTURE_DCACHE_LINE_BYTES - 1U);
    end_addr = (((uintptr_t)addr) + (uintptr_t)size_bytes + (XE_NP_CAPTURE_DCACHE_LINE_BYTES - 1U)) &
               ~((uintptr_t)XE_NP_CAPTURE_DCACHE_LINE_BYTES - 1U);
    SCB_InvalidateDCache_by_Addr((void *)start_addr, (int32_t)(end_addr - start_addr));
#else
    (void)addr;
    (void)size_bytes;
#endif
}

void XE_NP_PsbFrame_Reset(XE_NP_PsbFrame *frame)
{
    if(frame == NULL)
    {
        return;
    }

    memset(frame, 0, sizeof(*frame));
}

int XE_NP_PsbFrame_Decode(XE_NP_PsbFrame *frame, const uint8_t *lane_bytes, size_t lane_count)
{
    size_t tick_index;
    size_t word_index;
    uint32_t bit_mask;

    if((frame == NULL) || (lane_bytes == NULL) || (lane_count < XE_NP_CAPTURE_FRAME_BIT_COUNT))
    {
        if(frame != NULL)
        {
            XE_NP_PsbFrame_Reset(frame);
            frame->flags |= XE_NP_PSB_FRAME_FLAG_SIZE_ERROR;
        }
        return -1;
    }

    XE_NP_PsbFrame_Reset(frame);

    for(tick_index = 0U; tick_index < XE_NP_CAPTURE_FRAME_BIT_COUNT; ++tick_index)
    {
        uint8_t lane_byte = lane_bytes[tick_index];
        uint8_t bit_index = (uint8_t)(XE_NP_CAPTURE_FRAME_WORD_BITS - 1U - (tick_index % XE_NP_CAPTURE_FRAME_WORD_BITS));

        word_index = tick_index / XE_NP_CAPTURE_FRAME_WORD_BITS;
        bit_mask = 1UL << bit_index;

        if(tick_index < XE_NP_CAPTURE_FRAME_WORD_BITS)
        {
            if((lane_byte & XE_NP_CAPTURE_LANE_SYNC_MASK) != 0U)
            {
                frame->sync_word |= (uint16_t)bit_mask;
            }
        }

        for(uint8_t line_index = 0U; line_index < XE_NP_CAPTURE_FRAME_DATA_LINES; ++line_index)
        {
            if(((lane_byte >> (line_index + XE_NP_CAPTURE_LANE_DATA_SHIFT)) & 0x01U) != 0U)
            {
                frame->line_words[line_index][word_index] |= (uint16_t)bit_mask;
            }
        }
    }

    /*
     * The PSB_SYNC line is not only the first 10-bit frame marker. After those
     * 10 bits, the remaining 50 bits in the 60-bit frame carry a heartbeat
     * level which stays constant across the frame. Ignoring that line-state
     * leaves room for false lock on a shifted or noisy snapshot stream.
     */
    if(lane_count > XE_NP_CAPTURE_FRAME_WORD_BITS)
    {
        uint8_t heartbeat_level =
            lane_bytes[XE_NP_CAPTURE_FRAME_WORD_BITS] & XE_NP_CAPTURE_LANE_SYNC_MASK;

        for(tick_index = XE_NP_CAPTURE_FRAME_WORD_BITS + 1U;
            tick_index < XE_NP_CAPTURE_FRAME_BIT_COUNT;
            ++tick_index)
        {
            if((lane_bytes[tick_index] & XE_NP_CAPTURE_LANE_SYNC_MASK) != heartbeat_level)
            {
                frame->flags |= XE_NP_PSB_FRAME_FLAG_HEARTBEAT_ERROR;
                break;
            }
        }
    }

    if((frame->sync_word == XE_NP_PSB_SYNC_WORD_FRAME) ||
       (frame->sync_word == XE_NP_PSB_SYNC_WORD_SUPERFRAME))
    {
        frame->flags |= XE_NP_PSB_FRAME_FLAG_SYNC_VALID;
        if(frame->sync_word == XE_NP_PSB_SYNC_WORD_SUPERFRAME)
        {
            frame->flags |= XE_NP_PSB_FRAME_FLAG_SUPERFRAME;
        }
    }

    frame->fixed_word = frame->line_words[6][XE_NP_PSB_FIXED_WORD_INDEX];
    frame->counter_value = ((uint32_t)frame->line_words[6][XE_NP_PSB_COUNTER1_WORD_INDEX] << XE_NP_CAPTURE_FRAME_WORD_BITS) |
                           (uint32_t)frame->line_words[6][XE_NP_PSB_COUNTER0_WORD_INDEX];
    frame->flags |= XE_NP_PSB_FRAME_FLAG_COUNTER_VALID | XE_NP_PSB_FRAME_FLAG_FIXED_PRESENT;

    for(uint8_t line_index = 0U; line_index < XE_NP_CAPTURE_FRAME_DATA_LINES; ++line_index)
    {
        if(frame->line_words[line_index][XE_NP_PSB_FILL_WORD_INDEX] != 0U)
        {
            frame->flags |= XE_NP_PSB_FRAME_FLAG_FILL_ERROR;
            break;
        }
    }

    return ((frame->flags & XE_NP_PSB_FRAME_FLAG_SYNC_VALID) != 0U) ? 0 : -1;
}

int XE_NP_PsbFrame_DecodeFromSnapshots(
    XE_NP_PsbFrame *frame,
    const uint16_t *snapshots,
    size_t tick_count,
    uint8_t probe_index)
{
    uint8_t lane_bytes[XE_NP_CAPTURE_FRAME_BIT_COUNT];

    if((frame == NULL) || (snapshots == NULL) || (tick_count < XE_NP_CAPTURE_FRAME_BIT_COUNT))
    {
        if(frame != NULL)
        {
            XE_NP_PsbFrame_Reset(frame);
            frame->flags |= XE_NP_PSB_FRAME_FLAG_SIZE_ERROR;
        }
        return -1;
    }

    if(probe_index > 2U)
    {
        XE_NP_PsbFrame_Reset(frame);
        frame->flags |= XE_NP_PSB_FRAME_FLAG_SIZE_ERROR;
        return -1;
    }

    for(size_t i = 0U; i < XE_NP_CAPTURE_FRAME_BIT_COUNT; ++i)
    {
        lane_bytes[i] = XE_NP_Capture_LaneByteFromSnapshot(snapshots[i], probe_index);
    }

    return XE_NP_PsbFrame_Decode(frame, lane_bytes, XE_NP_CAPTURE_FRAME_BIT_COUNT);
}

void XE_NP_ElectrodePacket_Reset(XE_NP_ElectrodePacket *packet)
{
    if(packet == NULL)
    {
        return;
    }

    memset(packet, 0, sizeof(*packet));
}

int XE_NP_PsbFrame_ExtractAdcWords(
    const XE_NP_PsbFrame *frame,
    uint16_t *adc_words,
    size_t adc_word_count)
{
    if((frame == NULL) || (adc_words == NULL) ||
       (adc_word_count < XE_NP_CAPTURE_FRAME_ADC_WORDS))
    {
        return -1;
    }

    /*
     * Each frame carries 32 ADC words: 30 words on PSB data lines 0..5 across
     * the first five word slots, then ADC31/ADC32 on data line 6 word slots 0/1.
     * The remaining line-6 words are fixed/counter/fill metadata.
     */
    for(uint8_t word_index = 0U; word_index < 5U; ++word_index)
    {
        for(uint8_t line_index = 0U; line_index < 6U; ++line_index)
        {
            adc_words[(word_index * 6U) + line_index] = frame->line_words[line_index][word_index];
        }
    }

    adc_words[30] = frame->line_words[6][0];
    adc_words[31] = frame->line_words[6][1];
    return 0;
}

static uint32_t XE_NP_PsbFrame_RequiredPacketFlags(uint8_t expect_superframe)
{
    uint32_t required_flags = XE_NP_PSB_FRAME_FLAG_SYNC_VALID;

    if(expect_superframe != 0U)
    {
        required_flags |= XE_NP_PSB_FRAME_FLAG_SUPERFRAME;
    }

    return required_flags;
}

static int XE_NP_PsbFrame_HasPacketFormatError(
    const XE_NP_PsbFrame *frame,
    uint8_t expect_superframe)
{
    uint32_t required_flags;

    if(frame == NULL)
    {
        return 1;
    }

    required_flags = XE_NP_PsbFrame_RequiredPacketFlags(expect_superframe);
    if((frame->flags & required_flags) != required_flags)
    {
        return 1;
    }
    if((expect_superframe == 0U) &&
       ((frame->flags & XE_NP_PSB_FRAME_FLAG_SUPERFRAME) != 0U))
    {
        return 1;
    }
    if((frame->flags & (XE_NP_PSB_FRAME_FLAG_HEARTBEAT_ERROR |
                        XE_NP_PSB_FRAME_FLAG_FILL_ERROR)) != 0U)
    {
        return 1;
    }

    return 0;
}

static uint16_t XE_NP_PsbSuperframe_StatusFlags(
    const XE_NP_PsbFrame *superframe_frames,
    uint8_t *have_expected_counter,
    uint32_t *expected_counter)
{
    uint16_t status = XE_NP_ELECTRODE_STATUS_FLAG_LFP_NAP;

    if((superframe_frames == NULL) || (have_expected_counter == NULL) || (expected_counter == NULL))
    {
        return (uint16_t)(status |
                          XE_NP_ELECTRODE_STATUS_FLAG_SYNC_ERROR |
                          XE_NP_ELECTRODE_STATUS_FLAG_COUNT_ERROR);
    }

    for(uint8_t frame_index = 0U;
        frame_index < XE_NP_CAPTURE_FRAMES_PER_SUPERFRAME;
        ++frame_index)
    {
        const XE_NP_PsbFrame *frame = &superframe_frames[frame_index];
        uint8_t expect_superframe = (frame_index == 0U) ? 1U : 0U;

        if(XE_NP_PsbFrame_HasPacketFormatError(frame, expect_superframe) != 0)
        {
            status |= XE_NP_ELECTRODE_STATUS_FLAG_SYNC_ERROR;
        }

        if((frame->flags & XE_NP_PSB_FRAME_FLAG_COUNTER_VALID) == 0U)
        {
            status |= XE_NP_ELECTRODE_STATUS_FLAG_COUNT_ERROR;
            continue;
        }

        if((*have_expected_counter != 0U) && (frame->counter_value != *expected_counter))
        {
            status |= XE_NP_ELECTRODE_STATUS_FLAG_COUNT_ERROR;
        }

        *expected_counter = (frame->counter_value + 1U) & 0xFFFFFU;
        *have_expected_counter = 1U;
    }

    return status;
}

static int XE_NP_Psb_AdcWordToChannelIndex(
    uint8_t adc_word_index,
    uint8_t multiplex_index,
    uint16_t *channel_index)
{
    uint16_t block_base;

    if((channel_index == NULL) ||
       (adc_word_index >= XE_NP_CAPTURE_FRAME_ADC_WORDS) ||
       (multiplex_index >= XE_NP_CAPTURE_SUPERFRAMES_PER_ULTRAFRAME))
    {
        return -1;
    }

    /*
     * Table-16 channel ordering groups the 384 electrodes into 32 ADC banks,
     * each bank carrying 12 time-multiplexed channels. Odd/even ADCs alternate
     * odd/even channel numbers within a 24-channel bank.
     */
    block_base = (uint16_t)((adc_word_index / 2U) * 24U);
    *channel_index = (uint16_t)(block_base + (uint16_t)(adc_word_index & 0x01U) +
                                ((uint16_t)multiplex_index * 2U));
    return (*channel_index < XE_NP_NEUROPIXELS_CHANNELS_PER_PROBE) ? 0 : -1;
}

int XE_NP_ElectrodePacket_DecodeUltraframe(
    XE_NP_ElectrodePacket *packet,
    const XE_NP_PsbFrame *frames,
    size_t frame_count)
{
    uint16_t adc_words[XE_NP_CAPTURE_FRAME_ADC_WORDS];
    uint32_t expected_counter = 0U;
    uint8_t have_expected_counter = 0U;

    if((packet == NULL) || (frames == NULL) ||
       (frame_count < XE_NP_CAPTURE_FRAMES_PER_ULTRAFRAME))
    {
        if(packet != NULL)
        {
            XE_NP_ElectrodePacket_Reset(packet);
            packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_SIZE_ERROR;
        }
        return -1;
    }

    XE_NP_ElectrodePacket_Reset(packet);

    for(uint8_t superframe_index = 0U;
        superframe_index < XE_NP_CAPTURE_SUPERFRAMES_PER_ULTRAFRAME;
        ++superframe_index)
    {
        const XE_NP_PsbFrame *superframe_frames =
            &frames[(size_t)superframe_index * XE_NP_CAPTURE_FRAMES_PER_SUPERFRAME];
        const XE_NP_PsbFrame *lfp_frame = &superframe_frames[0];

        if((lfp_frame->flags & XE_NP_PSB_FRAME_FLAG_SYNC_VALID) == 0U)
        {
            packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_SYNC_ERROR;
        }
        if(XE_NP_PsbFrame_HasPacketFormatError(lfp_frame, 1U) != 0)
        {
            packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_FRAME_ERROR;
        }

        packet->timestamp[superframe_index] = lfp_frame->counter_value;
        packet->status[superframe_index] = XE_NP_PsbSuperframe_StatusFlags(
            superframe_frames,
            &have_expected_counter,
            &expected_counter);
        if((packet->status[superframe_index] & XE_NP_ELECTRODE_STATUS_FLAG_COUNT_ERROR) != 0U)
        {
            packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_FRAME_ERROR;
        }
        if((packet->status[superframe_index] & XE_NP_ELECTRODE_STATUS_FLAG_SYNC_ERROR) != 0U)
        {
            packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_SYNC_ERROR;
        }

        if(XE_NP_PsbFrame_ExtractAdcWords(lfp_frame, adc_words, XE_NP_CAPTURE_FRAME_ADC_WORDS) != 0)
        {
            packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_FRAME_ERROR;
            return -1;
        }
        for(uint8_t adc_index = 0U; adc_index < XE_NP_CAPTURE_FRAME_ADC_WORDS; ++adc_index)
        {
            uint16_t channel_index;
            if(XE_NP_Psb_AdcWordToChannelIndex(adc_index, superframe_index, &channel_index) == 0)
            {
                packet->lfp_data[channel_index] = adc_words[adc_index];
            }
        }

        for(uint8_t ap_slot = 0U; ap_slot < 12U; ++ap_slot)
        {
            const XE_NP_PsbFrame *ap_frame = &superframe_frames[ap_slot + 1U];

            if((ap_frame->flags & XE_NP_PSB_FRAME_FLAG_SYNC_VALID) == 0U)
            {
                packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_SYNC_ERROR;
            }
            if(XE_NP_PsbFrame_HasPacketFormatError(ap_frame, 0U) != 0)
            {
                packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_FRAME_ERROR;
            }

            if(XE_NP_PsbFrame_ExtractAdcWords(ap_frame, adc_words, XE_NP_CAPTURE_FRAME_ADC_WORDS) != 0)
            {
                packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_FRAME_ERROR;
                return -1;
            }

            for(uint8_t adc_index = 0U; adc_index < XE_NP_CAPTURE_FRAME_ADC_WORDS; ++adc_index)
            {
                uint16_t channel_index;
                if(XE_NP_Psb_AdcWordToChannelIndex(adc_index, ap_slot, &channel_index) == 0)
                {
                    packet->ap_data[superframe_index][channel_index] = adc_words[adc_index];
                }
            }
        }
    }

    return (packet->flags == 0U) ? 0 : -1;
}

int XE_NP_ElectrodePacket_DecodeUltraframeFromAlignedSnapshots(
    XE_NP_ElectrodePacket *packet,
    const uint16_t *snapshots,
    size_t tick_count,
    uint8_t probe_index)
{
    XE_NP_PsbFrame frame;
    XE_NP_PsbFrame superframe_frames[XE_NP_CAPTURE_FRAMES_PER_SUPERFRAME];
    uint16_t adc_words[XE_NP_CAPTURE_FRAME_ADC_WORDS];
    uint32_t expected_counter = 0U;
    uint8_t have_expected_counter = 0U;

    if((packet == NULL) || (snapshots == NULL) ||
       (tick_count < (XE_NP_CAPTURE_FRAMES_PER_ULTRAFRAME * XE_NP_CAPTURE_FRAME_BIT_COUNT)))
    {
        if(packet != NULL)
        {
            XE_NP_ElectrodePacket_Reset(packet);
            packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_SIZE_ERROR;
        }
        return -1;
    }

    XE_NP_ElectrodePacket_Reset(packet);

    for(uint8_t superframe_index = 0U;
        superframe_index < XE_NP_CAPTURE_SUPERFRAMES_PER_ULTRAFRAME;
        ++superframe_index)
    {
        size_t superframe_offset =
            (size_t)superframe_index * XE_NP_CAPTURE_FRAMES_PER_SUPERFRAME * XE_NP_CAPTURE_FRAME_BIT_COUNT;

        if(XE_NP_PsbFrame_DecodeFromSnapshots(
               &frame,
               &snapshots[superframe_offset],
               tick_count - superframe_offset,
               probe_index) != 0)
        {
            packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_FRAME_ERROR;
            return -1;
        }

        if((frame.flags & XE_NP_PSB_FRAME_FLAG_SYNC_VALID) == 0U)
        {
            packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_SYNC_ERROR;
        }
        if(XE_NP_PsbFrame_HasPacketFormatError(&frame, 1U) != 0)
        {
            packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_FRAME_ERROR;
        }

        packet->timestamp[superframe_index] = frame.counter_value;
        superframe_frames[0] = frame;

        if(XE_NP_PsbFrame_ExtractAdcWords(&frame, adc_words, XE_NP_CAPTURE_FRAME_ADC_WORDS) != 0)
        {
            packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_FRAME_ERROR;
            return -1;
        }
        for(uint8_t adc_index = 0U; adc_index < XE_NP_CAPTURE_FRAME_ADC_WORDS; ++adc_index)
        {
            uint16_t channel_index;
            if(XE_NP_Psb_AdcWordToChannelIndex(adc_index, superframe_index, &channel_index) == 0)
            {
                packet->lfp_data[channel_index] = adc_words[adc_index];
            }
        }

        for(uint8_t ap_slot = 0U; ap_slot < 12U; ++ap_slot)
        {
            size_t frame_offset =
                superframe_offset + ((size_t)(ap_slot + 1U) * XE_NP_CAPTURE_FRAME_BIT_COUNT);

            if(XE_NP_PsbFrame_DecodeFromSnapshots(
                   &frame,
                   &snapshots[frame_offset],
                   tick_count - frame_offset,
                   probe_index) != 0)
            {
                packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_FRAME_ERROR;
                return -1;
            }
            if((frame.flags & XE_NP_PSB_FRAME_FLAG_SYNC_VALID) == 0U)
            {
                packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_SYNC_ERROR;
            }
            if(XE_NP_PsbFrame_HasPacketFormatError(&frame, 0U) != 0)
            {
                packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_FRAME_ERROR;
            }
            superframe_frames[ap_slot + 1U] = frame;
            if(XE_NP_PsbFrame_ExtractAdcWords(&frame, adc_words, XE_NP_CAPTURE_FRAME_ADC_WORDS) != 0)
            {
                packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_FRAME_ERROR;
                return -1;
            }
            for(uint8_t adc_index = 0U; adc_index < XE_NP_CAPTURE_FRAME_ADC_WORDS; ++adc_index)
            {
                uint16_t channel_index;
                if(XE_NP_Psb_AdcWordToChannelIndex(adc_index, ap_slot, &channel_index) == 0)
                {
                    packet->ap_data[superframe_index][channel_index] = adc_words[adc_index];
                }
            }
        }

        packet->status[superframe_index] = XE_NP_PsbSuperframe_StatusFlags(
            superframe_frames,
            &have_expected_counter,
            &expected_counter);
        if((packet->status[superframe_index] & XE_NP_ELECTRODE_STATUS_FLAG_COUNT_ERROR) != 0U)
        {
            packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_FRAME_ERROR;
        }
        if((packet->status[superframe_index] & XE_NP_ELECTRODE_STATUS_FLAG_SYNC_ERROR) != 0U)
        {
            packet->flags |= XE_NP_ELECTRODE_PACKET_FLAG_SYNC_ERROR;
        }
    }

    return (packet->flags == 0U) ? 0 : -1;
}

#if (XE_NP_CAPTURE_SELFTEST_ENABLE != 0U)
static uint16_t XE_NP_Capture_SelfTestExpectedLfpValue(
    uint8_t superframe_index,
    uint16_t channel_index)
{
    return (uint16_t)(((uint16_t)(superframe_index << 6U) ^ channel_index ^ 0x0123U) & 0x03FFU);
}

static uint16_t XE_NP_Capture_SelfTestExpectedApValue(
    uint8_t superframe_index,
    uint8_t ap_slot,
    uint16_t channel_index)
{
    return (uint16_t)(((uint16_t)(superframe_index << 5U) ^
                       (uint16_t)(ap_slot << 2U) ^
                       channel_index ^
                      0x02A5U) &
                     0x03FFU);
}

static uint8_t XE_NP_Capture_SelfTestSyncValue(uint8_t probe_index)
{
    return (uint8_t)((probe_index + 1U) * 0x11U);
}

static void XE_NP_Capture_SelfTestBuildFrame(
    XE_NP_PsbFrame *frame,
    uint8_t superframe_index,
    uint8_t frame_index_in_superframe,
    uint32_t counter_value,
    uint8_t sync_value)
{
    uint16_t adc_words[XE_NP_CAPTURE_FRAME_ADC_WORDS];
    uint16_t fixed_word;

    XE_NP_PsbFrame_Reset(frame);
    if(frame == NULL)
    {
        return;
    }

    fixed_word = (uint16_t)sync_value;
    frame->sync_word = (frame_index_in_superframe == 0U) ?
                           XE_NP_PSB_SYNC_WORD_SUPERFRAME :
                           XE_NP_PSB_SYNC_WORD_FRAME;
    frame->fixed_word = fixed_word;
    frame->counter_value = counter_value & 0xFFFFFU;
    frame->flags = XE_NP_PSB_FRAME_FLAG_SYNC_VALID |
                   XE_NP_PSB_FRAME_FLAG_COUNTER_VALID |
                   XE_NP_PSB_FRAME_FLAG_FIXED_PRESENT;
    if(frame_index_in_superframe == 0U)
    {
        frame->flags |= XE_NP_PSB_FRAME_FLAG_SUPERFRAME;
    }

    for(uint8_t block_index = 0U; block_index < 16U; ++block_index)
    {
        uint16_t block_base = (uint16_t)(block_index * 24U);
        uint8_t multiplex_index = (frame_index_in_superframe == 0U) ?
                                      superframe_index :
                                      (uint8_t)(frame_index_in_superframe - 1U);

        adc_words[(uint8_t)(block_index * 2U)] =
            (frame_index_in_superframe == 0U) ?
                XE_NP_Capture_SelfTestExpectedLfpValue(
                    superframe_index,
                    (uint16_t)(block_base + (uint16_t)(multiplex_index * 2U))) :
                XE_NP_Capture_SelfTestExpectedApValue(
                    superframe_index,
                    multiplex_index,
                    (uint16_t)(block_base + (uint16_t)(multiplex_index * 2U)));
        adc_words[(uint8_t)(block_index * 2U + 1U)] =
            (frame_index_in_superframe == 0U) ?
                XE_NP_Capture_SelfTestExpectedLfpValue(
                    superframe_index,
                    (uint16_t)(block_base + 1U + (uint16_t)(multiplex_index * 2U))) :
                XE_NP_Capture_SelfTestExpectedApValue(
                    superframe_index,
                    multiplex_index,
                    (uint16_t)(block_base + 1U + (uint16_t)(multiplex_index * 2U)));
    }

    for(uint8_t word_index = 0U; word_index < 5U; ++word_index)
    {
        for(uint8_t line_index = 0U; line_index < 6U; ++line_index)
        {
            frame->line_words[line_index][word_index] =
                adc_words[(uint8_t)(word_index * 6U + line_index)];
        }
    }

    frame->line_words[6][0] = adc_words[30];
    frame->line_words[6][1] = adc_words[31];
    frame->line_words[6][XE_NP_PSB_FIXED_WORD_INDEX] = fixed_word;
    frame->line_words[6][XE_NP_PSB_COUNTER1_WORD_INDEX] =
        (uint16_t)((counter_value >> XE_NP_CAPTURE_FRAME_WORD_BITS) & 0x03FFU);
    frame->line_words[6][XE_NP_PSB_COUNTER0_WORD_INDEX] =
        (uint16_t)(counter_value & 0x03FFU);
}

static void XE_NP_Capture_SelfTestAppendFrameSnapshots(
    const XE_NP_PsbFrame *frame,
    uint16_t *snapshots,
    uint8_t probe_index,
    int merge_into_existing)
{
    for(uint8_t tick_index = 0U; tick_index < XE_NP_CAPTURE_FRAME_BIT_COUNT; ++tick_index)
    {
        uint8_t word_index = (uint8_t)(tick_index / XE_NP_CAPTURE_FRAME_WORD_BITS);
        uint8_t bit_index = (uint8_t)(XE_NP_CAPTURE_FRAME_WORD_BITS - 1U -
                                      (tick_index % XE_NP_CAPTURE_FRAME_WORD_BITS));
        uint8_t lane_byte = 0U;
        uint16_t snapshot = 0U;

        if((tick_index < XE_NP_CAPTURE_FRAME_WORD_BITS) &&
           (((frame->sync_word >> bit_index) & 0x01U) != 0U))
        {
            lane_byte |= XE_NP_CAPTURE_LANE_SYNC_MASK;
        }

        for(uint8_t line_index = 0U; line_index < XE_NP_CAPTURE_FRAME_DATA_LINES; ++line_index)
        {
            if(((frame->line_words[line_index][word_index] >> bit_index) & 0x01U) != 0U)
            {
                lane_byte |= (uint8_t)(1U << (line_index + XE_NP_CAPTURE_LANE_DATA_SHIFT));
            }
        }

        switch(probe_index)
        {
            case 0U:
                snapshot = lane_byte;
                break;
            case 1U:
                snapshot = (uint16_t)((uint16_t)lane_byte << 8U);
                break;
            case 2U:
                snapshot = (uint16_t)((uint16_t)lane_byte << 8U);
                break;
            default:
                snapshot = 0U;
                break;
        }

        if(merge_into_existing != 0)
        {
            snapshots[tick_index] |= snapshot;
        }
        else
        {
            snapshots[tick_index] = snapshot;
        }
    }
}

static int XE_NP_Capture_SelfTestVerifyPacket(const XE_NP_ElectrodePacket *packet, uint32_t counter_base)
{
    uint32_t expected_counter = counter_base;

    if(packet == NULL)
    {
        return -1;
    }

    for(uint8_t superframe_index = 0U;
        superframe_index < XE_NP_CAPTURE_SUPERFRAMES_PER_ULTRAFRAME;
        ++superframe_index)
    {
        uint16_t expected_status = XE_NP_ELECTRODE_STATUS_FLAG_LFP_NAP;

        if((packet->timestamp[superframe_index] != expected_counter) ||
           (packet->status[superframe_index] != expected_status))
        {
            return -1;
        }

        for(uint16_t channel_index = 0U;
            channel_index < XE_NP_NEUROPIXELS_CHANNELS_PER_PROBE;
            ++channel_index)
        {
            uint8_t multiplex_index = (uint8_t)((channel_index % 24U) / 2U);
            uint16_t expected_lfp =
                XE_NP_Capture_SelfTestExpectedLfpValue(multiplex_index, channel_index);
            uint16_t expected_ap =
                XE_NP_Capture_SelfTestExpectedApValue(
                    superframe_index,
                    multiplex_index,
                    channel_index);

            if(packet->ap_data[superframe_index][channel_index] != expected_ap)
            {
                return -1;
            }
            if(packet->lfp_data[channel_index] != expected_lfp)
            {
                return -1;
            }
        }

        expected_counter += XE_NP_CAPTURE_FRAMES_PER_SUPERFRAME;
    }

    return 0;
}

enum
{
    XE_NP_CAPTURE_SELFTEST_PREFIX_TICKS = 7U,
    XE_NP_CAPTURE_SELFTEST_TOTAL_TICKS =
        XE_NP_CAPTURE_SELFTEST_PREFIX_TICKS +
        (XE_NP_CAPTURE_FRAMES_PER_ULTRAFRAME * XE_NP_CAPTURE_FRAME_BIT_COUNT)
};

typedef struct
{
    uint16_t snapshots[XE_NP_CAPTURE_SELFTEST_TOTAL_TICKS];
    XE_NP_ElectrodePacket packet;
} XE_NP_CaptureSelfTestScratch;

static XE_NP_CaptureSelfTestScratch xe_np_capture_selftest;

static int XE_NP_Capture_RunSelfTestForProbe(uint8_t probe_index)
{
    uint16_t *snapshots = xe_np_capture_selftest.snapshots;
    XE_NP_ElectrodePacket *packet = &xe_np_capture_selftest.packet;
    XE_NP_CaptureState state;
    XE_NP_PsbFrame frame;
    XE_NP_CapturePort *port;
    size_t aligned_offset = 0U;
    uint32_t counter_value = 0x12345U;
    uint32_t flags;
    uint16_t saved_snapshot;
    uint16_t fill_error_bit;
    size_t tick_cursor = XE_NP_CAPTURE_SELFTEST_PREFIX_TICKS;
    uint8_t port_index;
    uint8_t probe_mask;
    uint8_t sync_value;

    if(probe_index >= XE_NP_NEUROPIXELS_MAX_PROBES)
    {
        return -1;
    }

    memset(&state, 0, sizeof(state));
    memset(snapshots, 0, sizeof(xe_np_capture_selftest.snapshots));

    probe_mask = (uint8_t)(1U << probe_index);
    sync_value = XE_NP_Capture_SelfTestSyncValue(probe_index);
    if(probe_index < 2U)
    {
        port = &state.gpioe;
        port_index = 0U;
        state.gpioe.active_probe_mask = probe_mask;
    }
    else
    {
        port = &state.gpiod;
        port_index = 1U;
        state.gpiod.active_probe_mask = probe_mask;
    }
    state.active_probe_mask = probe_mask;

    for(uint8_t superframe_index = 0U;
        superframe_index < XE_NP_CAPTURE_SUPERFRAMES_PER_ULTRAFRAME;
        ++superframe_index)
    {
        for(uint8_t frame_index = 0U;
            frame_index < XE_NP_CAPTURE_FRAMES_PER_SUPERFRAME;
            ++frame_index)
        {
            XE_NP_Capture_SelfTestBuildFrame(
                &frame,
                superframe_index,
                frame_index,
                counter_value++,
                sync_value);
            XE_NP_Capture_SelfTestAppendFrameSnapshots(
                &frame,
                &snapshots[tick_cursor],
                probe_index,
                0);
            tick_cursor += XE_NP_CAPTURE_FRAME_BIT_COUNT;
        }
    }

    if(XE_NP_Capture_FindFrameAlignment(
           port,
           snapshots,
           XE_NP_CAPTURE_SELFTEST_TOTAL_TICKS,
           probe_index,
           &aligned_offset) != 0)
    {
        return -1;
    }
    if((aligned_offset != XE_NP_CAPTURE_SELFTEST_PREFIX_TICKS) ||
       (port->frame_alignment_locked == 0U))
    {
        return -1;
    }

    XE_NP_PsbValidator_SetExpectedSyncValue(&state.validators[probe_index], sync_value);
    XE_NP_PsbValidator_Init(&state.validators[probe_index]);
    flags = XE_NP_Capture_ValidateSnapshotPrefix(
        &state,
        snapshots,
        XE_NP_CAPTURE_SELFTEST_TOTAL_TICKS,
        port_index,
        4U);
    if(flags != 0U)
    {
        return -1;
    }

    XE_NP_PsbValidator_SetExpectedSyncValue(&state.validators[probe_index], sync_value);
    XE_NP_PsbValidator_Init(&state.validators[probe_index]);
    flags = XE_NP_Capture_ValidateSnapshotBurst(
        &state,
        &snapshots[aligned_offset],
        XE_NP_CAPTURE_FRAMES_PER_ULTRAFRAME * XE_NP_CAPTURE_FRAME_BIT_COUNT,
        port_index);
    if(flags != 0U)
    {
        return -1;
    }

    if(XE_NP_ElectrodePacket_DecodeUltraframeFromAlignedSnapshots(
           packet,
           &snapshots[aligned_offset],
           XE_NP_CAPTURE_FRAMES_PER_ULTRAFRAME * XE_NP_CAPTURE_FRAME_BIT_COUNT,
           probe_index) != 0)
    {
        return -1;
    }
    if(XE_NP_Capture_SelfTestVerifyPacket(packet, 0x12345U) != 0)
    {
        return -1;
    }

    /*
     * Corrupt data-line 0 in the tested probe lane. NP1 occupies GPIOE[7:0],
     * while NP2/NP3 synthetic lanes occupy bits [15:8].
     */
    fill_error_bit = (probe_index == 0U) ?
                         (uint16_t)(1U << XE_NP_CAPTURE_LANE_DATA_SHIFT) :
                         0x0200U;
    saved_snapshot = snapshots[aligned_offset +
                              XE_NP_CAPTURE_FRAME_WORD_BITS * XE_NP_PSB_FILL_WORD_INDEX];
    snapshots[aligned_offset + XE_NP_CAPTURE_FRAME_WORD_BITS * XE_NP_PSB_FILL_WORD_INDEX] ^=
        fill_error_bit;
    XE_NP_PsbValidator_SetExpectedSyncValue(&state.validators[probe_index], sync_value);
    XE_NP_PsbValidator_Init(&state.validators[probe_index]);
    flags = XE_NP_Capture_ValidateSnapshotBurst(
        &state,
        &snapshots[aligned_offset],
        XE_NP_CAPTURE_FRAMES_PER_ULTRAFRAME * XE_NP_CAPTURE_FRAME_BIT_COUNT,
        port_index);
    snapshots[aligned_offset + XE_NP_CAPTURE_FRAME_WORD_BITS * XE_NP_PSB_FILL_WORD_INDEX] =
        saved_snapshot;
    if((flags & XE_NP_PSB_VALIDATOR_FLAG_FILL_ERROR) == 0U)
    {
        return -1;
    }

    return 0;
}

#if (XE_NP_BOARD_V2_PSSI_NP1_ENABLE == 0U)
static int XE_NP_Capture_RunSelfTestForGpioeDual(void)
{
    uint16_t *snapshots = xe_np_capture_selftest.snapshots;
    XE_NP_ElectrodePacket *packet = &xe_np_capture_selftest.packet;
    XE_NP_CaptureState state;
    XE_NP_PsbFrame frame_np1;
    XE_NP_PsbFrame frame_np2;
    size_t aligned_offset_np1 = 0U;
    uint32_t counter_np1 = 0x12345U;
    uint32_t counter_np2 = 0x23456U;
    uint32_t flags;
    uint16_t saved_snapshot;
    size_t fill_tick_offset =
        (size_t)XE_NP_CAPTURE_FRAME_WORD_BITS * XE_NP_PSB_FILL_WORD_INDEX;
    size_t tick_cursor = XE_NP_CAPTURE_SELFTEST_PREFIX_TICKS;
    uint8_t sync_np1 = XE_NP_Capture_SelfTestSyncValue(0U);
    uint8_t sync_np2 = XE_NP_Capture_SelfTestSyncValue(1U);

    memset(&state, 0, sizeof(state));
    memset(snapshots, 0, sizeof(xe_np_capture_selftest.snapshots));

    state.active_probe_mask = XE_NP_CAPTURE_PROBE1_MASK | XE_NP_CAPTURE_PROBE2_MASK;
    state.gpioe.active_probe_mask = state.active_probe_mask;

    for(uint8_t superframe_index = 0U;
        superframe_index < XE_NP_CAPTURE_SUPERFRAMES_PER_ULTRAFRAME;
        ++superframe_index)
    {
        for(uint8_t frame_index = 0U;
            frame_index < XE_NP_CAPTURE_FRAMES_PER_SUPERFRAME;
            ++frame_index)
        {
            XE_NP_Capture_SelfTestBuildFrame(
                &frame_np1,
                superframe_index,
                frame_index,
                counter_np1++,
                sync_np1);
            XE_NP_Capture_SelfTestAppendFrameSnapshots(
                &frame_np1,
                &snapshots[tick_cursor],
                0U,
                0);

            XE_NP_Capture_SelfTestBuildFrame(
                &frame_np2,
                superframe_index,
                frame_index,
                counter_np2++,
                sync_np2);
            XE_NP_Capture_SelfTestAppendFrameSnapshots(
                &frame_np2,
                &snapshots[tick_cursor],
                1U,
                1);

            tick_cursor += XE_NP_CAPTURE_FRAME_BIT_COUNT;
        }
    }

    if((XE_NP_Capture_FindPortFrameAlignment(
            &state,
            0U,
            snapshots,
            XE_NP_CAPTURE_SELFTEST_TOTAL_TICKS,
            &aligned_offset_np1) != 0) ||
       (aligned_offset_np1 != XE_NP_CAPTURE_SELFTEST_PREFIX_TICKS) ||
       (state.gpioe.frame_alignment_locked == 0U))
    {
        return -1;
    }

    XE_NP_PsbValidator_SetExpectedSyncValue(&state.validators[0], sync_np1);
    XE_NP_PsbValidator_SetExpectedSyncValue(&state.validators[1], sync_np2);
    XE_NP_PsbValidator_Init(&state.validators[0]);
    XE_NP_PsbValidator_Init(&state.validators[1]);
    flags = XE_NP_Capture_ValidateSnapshotPrefix(
        &state,
        snapshots,
        XE_NP_CAPTURE_SELFTEST_TOTAL_TICKS,
        0U,
        4U);
    if(flags != 0U)
    {
        return -1;
    }

    XE_NP_PsbValidator_SetExpectedSyncValue(&state.validators[0], sync_np1);
    XE_NP_PsbValidator_SetExpectedSyncValue(&state.validators[1], sync_np2);
    XE_NP_PsbValidator_Init(&state.validators[0]);
    XE_NP_PsbValidator_Init(&state.validators[1]);
    flags = XE_NP_Capture_ValidateSnapshotBurst(
        &state,
        &snapshots[aligned_offset_np1],
        XE_NP_CAPTURE_FRAMES_PER_ULTRAFRAME * XE_NP_CAPTURE_FRAME_BIT_COUNT,
        0U);
    if(flags != 0U)
    {
        return -1;
    }

    if(XE_NP_ElectrodePacket_DecodeUltraframeFromAlignedSnapshots(
           packet,
           &snapshots[aligned_offset_np1],
           XE_NP_CAPTURE_FRAMES_PER_ULTRAFRAME * XE_NP_CAPTURE_FRAME_BIT_COUNT,
           0U) != 0)
    {
        return -1;
    }
    if(XE_NP_Capture_SelfTestVerifyPacket(packet, 0x12345U) != 0)
    {
        return -1;
    }

    if(XE_NP_ElectrodePacket_DecodeUltraframeFromAlignedSnapshots(
           packet,
           &snapshots[aligned_offset_np1],
           XE_NP_CAPTURE_FRAMES_PER_ULTRAFRAME * XE_NP_CAPTURE_FRAME_BIT_COUNT,
           1U) != 0)
    {
        return -1;
    }
    if(XE_NP_Capture_SelfTestVerifyPacket(packet, 0x23456U) != 0)
    {
        return -1;
    }

    saved_snapshot = snapshots[aligned_offset_np1 + fill_tick_offset];
    snapshots[aligned_offset_np1 + fill_tick_offset] ^= 0x0200U;
    XE_NP_PsbValidator_SetExpectedSyncValue(&state.validators[0], sync_np1);
    XE_NP_PsbValidator_SetExpectedSyncValue(&state.validators[1], sync_np2);
    XE_NP_PsbValidator_Init(&state.validators[0]);
    XE_NP_PsbValidator_Init(&state.validators[1]);
    flags = XE_NP_Capture_ValidateSnapshotBurst(
        &state,
        &snapshots[aligned_offset_np1],
        XE_NP_CAPTURE_FRAMES_PER_ULTRAFRAME * XE_NP_CAPTURE_FRAME_BIT_COUNT,
        0U);
    snapshots[aligned_offset_np1 + fill_tick_offset] = saved_snapshot;
    if((flags & (XE_NP_PSB_VALIDATOR_FLAG_FILL_ERROR <<
                 (1U * XE_NP_CAPTURE_VALIDATOR_PROBE_SHIFT))) == 0U)
    {
        return -1;
    }

    return 0;
}
#endif

int XE_NP_Capture_RunSelfTestMask(uint8_t *pass_mask)
{
    uint8_t mask = 0U;

    if(pass_mask != NULL)
    {
        *pass_mask = 0U;
    }

    for(uint8_t probe_index = 0U;
#if (XE_NP_BOARD_V2_PSSI_NP1_ENABLE != 0U)
        probe_index < 1U;
#else
        probe_index < XE_NP_NEUROPIXELS_MAX_PROBES;
#endif
        ++probe_index)
    {
        if(XE_NP_Capture_RunSelfTestForProbe(probe_index) == 0)
        {
            mask |= (uint8_t)(1U << probe_index);
        }
    }

#if (XE_NP_BOARD_V2_PSSI_NP1_ENABLE == 0U)
    if(XE_NP_Capture_RunSelfTestForGpioeDual() == 0)
    {
        mask |= XE_NP_CAPTURE_SELFTEST_GPIOE_DUAL_MASK;
    }
#endif

    if(pass_mask != NULL)
    {
        *pass_mask = mask;
    }

    return ((mask & XE_NP_CAPTURE_SELFTEST_REQUIRED_MASK) ==
            XE_NP_CAPTURE_SELFTEST_REQUIRED_MASK) ?
               0 :
               -1;
}

int XE_NP_Capture_RunSelfTest(void)
{
    return XE_NP_Capture_RunSelfTestMask(NULL);
}
#else
int XE_NP_Capture_RunSelfTestMask(uint8_t *pass_mask)
{
    if(pass_mask != NULL)
    {
        *pass_mask = 0U;
    }

    return 0;
}

int XE_NP_Capture_RunSelfTest(void)
{
    return 0;
}
#endif

void XE_NP_PsbValidator_Init(XE_NP_PsbValidator *validator)
{
    uint16_t expected_fixed_word;
    uint8_t expected_fixed_word_valid;

    if(validator == NULL)
    {
        return;
    }

    expected_fixed_word = validator->expected_fixed_word;
    expected_fixed_word_valid = validator->expected_fixed_word_valid;
    memset(validator, 0, sizeof(*validator));
    validator->expected_fixed_word = expected_fixed_word;
    validator->expected_fixed_word_valid = expected_fixed_word_valid;
}

void XE_NP_PsbValidator_SetExpectedSyncValue(XE_NP_PsbValidator *validator, uint8_t sync_value)
{
    if(validator == NULL)
    {
        return;
    }

    validator->expected_fixed_word = (uint16_t)sync_value;
    validator->expected_fixed_word_valid = 1U;
}

static uint32_t XE_NP_PsbValidator_ConsumeFrameInternal(
    XE_NP_PsbValidator *validator,
    const XE_NP_PsbFrame *frame,
    uint8_t enforce_counter_step)
{
    uint32_t flags = 0U;
    uint32_t frame_index = 0U;

    if((validator == NULL) || (frame == NULL))
    {
        return XE_NP_PSB_VALIDATOR_FLAG_SYNC_ERROR;
    }

    validator->frames_seen++;
    frame_index = validator->frames_seen - 1U;
    validator->last_sync_word = frame->sync_word;
    validator->last_fixed_word = frame->fixed_word;

    if((validator->expected_fixed_word_valid != 0U) &&
       ((frame->flags & XE_NP_PSB_FRAME_FLAG_FIXED_PRESENT) != 0U) &&
       (frame->fixed_word != validator->expected_fixed_word))
    {
        validator->fixed_word_errors++;
        flags |= XE_NP_PSB_VALIDATOR_FLAG_FIXED_MISMATCH;
    }

    if((frame->flags & XE_NP_PSB_FRAME_FLAG_SYNC_VALID) == 0U)
    {
        validator->sync_errors++;
        flags |= XE_NP_PSB_VALIDATOR_FLAG_SYNC_ERROR;
    }
    if((frame->flags & XE_NP_PSB_FRAME_FLAG_FILL_ERROR) != 0U)
    {
        validator->fill_errors++;
        flags |= XE_NP_PSB_VALIDATOR_FLAG_FILL_ERROR;
    }
    if((frame->flags & XE_NP_PSB_FRAME_FLAG_HEARTBEAT_ERROR) != 0U)
    {
        validator->heartbeat_errors++;
        flags |= XE_NP_PSB_VALIDATOR_FLAG_HEARTBEAT_ERROR;
    }

    if((frame->flags & XE_NP_PSB_FRAME_FLAG_COUNTER_VALID) != 0U)
    {
        if((enforce_counter_step != 0U) && (validator->have_counter != 0U))
        {
            uint32_t expected = (validator->last_counter_value + 1U) & 0xFFFFFU;
            if(frame->counter_value != expected)
            {
                validator->counter_errors++;
                flags |= XE_NP_PSB_VALIDATOR_FLAG_COUNTER_JUMP;
            }
        }

        validator->last_counter_value = frame->counter_value & 0xFFFFFU;
        validator->have_counter = 1U;
    }

    if((frame->flags & XE_NP_PSB_FRAME_FLAG_SYNC_VALID) != 0U)
    {
        uint8_t is_superframe = ((frame->flags & XE_NP_PSB_FRAME_FLAG_SUPERFRAME) != 0U) ? 1U : 0U;
        uint8_t frame_mod = (uint8_t)(frame_index % XE_NP_CAPTURE_FRAMES_PER_SUPERFRAME);

        if(is_superframe != 0U)
        {
            validator->superframes_seen++;
            if(validator->have_superframe_phase != 0U)
            {
                if(frame_mod != validator->superframe_counter_mod)
                {
                    validator->superframe_errors++;
                    flags |= XE_NP_PSB_VALIDATOR_FLAG_SUPERFRAME_MISMATCH;
                }
            }
            else
            {
                validator->superframe_counter_mod = frame_mod;
                validator->have_superframe_phase = 1U;
            }
        }
        else if((validator->have_superframe_phase != 0U) &&
                (frame_mod == validator->superframe_counter_mod))
        {
            validator->superframe_errors++;
            flags |= XE_NP_PSB_VALIDATOR_FLAG_SUPERFRAME_MISMATCH;
        }
    }

    return flags;
}

static uint32_t XE_NP_PsbValidator_LockFatalFlags(uint32_t flags)
{
    return flags & XE_NP_PSB_VALIDATOR_LOCK_FATAL_FLAGS;
}

uint32_t XE_NP_PsbValidator_ConsumeFrame(XE_NP_PsbValidator *validator, const XE_NP_PsbFrame *frame)
{
    return XE_NP_PsbValidator_ConsumeFrameInternal(validator, frame, 1U);
}

uint32_t XE_NP_Capture_ValidateSnapshotBurst(
    XE_NP_CaptureState *state,
    const uint16_t *snapshots,
    size_t tick_count,
    uint8_t port_index)
{
    XE_NP_PsbFrame frame;
    uint32_t flags = 0U;
    uint8_t probe_ids[2];
    uint8_t probe_count = 0U;

    if((state == NULL) || (snapshots == NULL) || (tick_count < XE_NP_CAPTURE_FRAME_BIT_COUNT))
    {
        return XE_NP_PSB_VALIDATOR_FLAG_SYNC_ERROR;
    }

    if(port_index == 0U)
    {
        if((state->gpioe.active_probe_mask & XE_NP_CAPTURE_PROBE1_MASK) != 0U)
        {
            probe_ids[probe_count++] = 0U;
        }
        if((state->gpioe.active_probe_mask & XE_NP_CAPTURE_PROBE2_MASK) != 0U)
        {
            probe_ids[probe_count++] = 1U;
        }
    }
    else if((port_index == 1U) &&
            ((state->gpiod.active_probe_mask & XE_NP_CAPTURE_PROBE3_MASK) != 0U))
    {
        probe_ids[probe_count++] = 2U;
    }
    else
    {
        return XE_NP_PSB_VALIDATOR_FLAG_SYNC_ERROR;
    }

    for(size_t frame_offset = 0U;
        (frame_offset + XE_NP_CAPTURE_FRAME_BIT_COUNT) <= tick_count;
        frame_offset += XE_NP_CAPTURE_FRAME_BIT_COUNT)
    {
        for(uint8_t idx = 0U; idx < probe_count; ++idx)
        {
            uint8_t probe_id = probe_ids[idx];
            uint32_t probe_flags;

            (void)XE_NP_PsbFrame_DecodeFromSnapshots(
                &frame,
                &snapshots[frame_offset],
                XE_NP_CAPTURE_FRAME_BIT_COUNT,
                probe_id);
            probe_flags = XE_NP_PsbValidator_ConsumeFrame(&state->validators[probe_id], &frame);
            flags |= (probe_flags << (probe_id * XE_NP_CAPTURE_VALIDATOR_PROBE_SHIFT));
        }
    }

    return flags;
}

uint32_t XE_NP_Capture_ValidateSnapshotPrefix(
    XE_NP_CaptureState *state,
    const uint16_t *snapshots,
    size_t tick_count,
    uint8_t port_index,
    size_t sample_frames)
{
    XE_NP_CapturePort *port;
    XE_NP_PsbFrame frame;
    uint8_t probe_ids[2];
    uint8_t probe_count = 0U;
    size_t aligned_offset = 0U;
    size_t frames_to_check;
    uint32_t flags = 0U;
    uint8_t realigned = 0U;

    if((state == NULL) || (snapshots == NULL) || (sample_frames == 0U) ||
       (tick_count < XE_NP_CAPTURE_FRAME_BIT_COUNT))
    {
        return XE_NP_PSB_VALIDATOR_FLAG_SYNC_ERROR;
    }

    port = XE_NP_Capture_GetPort(state, port_index);
    if((port == NULL) ||
       (XE_NP_Capture_GetPortProbeIds(state, port_index, probe_ids, &probe_count) != 0))
    {
        return XE_NP_PSB_VALIDATOR_FLAG_SYNC_ERROR;
    }

    aligned_offset = (size_t)port->frame_alignment_ticks;
    if((port->frame_alignment_locked == 0U) ||
       ((aligned_offset + XE_NP_CAPTURE_FRAME_BIT_COUNT) > tick_count) ||
       (XE_NP_Capture_PortFrameAlignedAtOffset(
            state,
            port_index,
            snapshots,
            tick_count,
            aligned_offset) == 0))
    {
        if(XE_NP_Capture_FindPortFrameAlignment(
               state,
               port_index,
               snapshots,
               tick_count,
               &aligned_offset) != 0)
        {
            return XE_NP_PSB_VALIDATOR_FLAG_SYNC_ERROR;
        }
        realigned = 1U;
    }

    frames_to_check = (tick_count - aligned_offset) / XE_NP_CAPTURE_FRAME_BIT_COUNT;
    if(frames_to_check > sample_frames)
    {
        frames_to_check = sample_frames;
    }

    for(uint8_t idx = 0U; idx < probe_count; ++idx)
    {
        uint32_t probe_flags = 0U;
        uint8_t probe_id = probe_ids[idx];
        XE_NP_PsbValidator *validator = &state->validators[probe_id];
        uint8_t probe_mask = (uint8_t)(1U << probe_id);

        if(realigned != 0U)
        {
            XE_NP_PsbValidator_Init(validator);
        }
        for(size_t frame_index = 0U; frame_index < frames_to_check; ++frame_index)
        {
            size_t frame_offset = aligned_offset + (frame_index * XE_NP_CAPTURE_FRAME_BIT_COUNT);

            (void)XE_NP_PsbFrame_DecodeFromSnapshots(
                &frame,
                &snapshots[frame_offset],
                tick_count - frame_offset,
                probe_id);
            probe_flags |= XE_NP_PsbValidator_LockFatalFlags(
                XE_NP_PsbValidator_ConsumeFrameInternal(validator, &frame, 0U));
        }

        if(probe_flags == 0U)
        {
            port->validated_probe_mask |= probe_mask;
        }
        else
        {
            port->validated_probe_mask &= (uint8_t)(~probe_mask);
        }
        flags |= (probe_flags << (probe_id * XE_NP_CAPTURE_VALIDATOR_PROBE_SHIFT));
    }

    return flags;
}
