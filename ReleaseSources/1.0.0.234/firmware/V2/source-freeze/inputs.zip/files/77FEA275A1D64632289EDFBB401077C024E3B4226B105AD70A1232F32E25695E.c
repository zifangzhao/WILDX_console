#include "xe_np_np2_first_sync.h"
#include <string.h>

enum { NP2_PERIOD=1600U, NP2_SYNC_INSPECT=4800U, NP2_D8_PHASE=176U,
       NP2_D8_LOOKAHEAD=180U, NP2_D8_DATA=184U };

static uint32_t u32(const uint8_t *p)
{ return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24); }
static uint64_t u64(const uint8_t *p)
{ return (uint64_t)u32(p)|((uint64_t)u32(p+4)<<32); }
static uint32_t rank_mask(uint32_t mask,uint32_t probe)
{ uint32_t n=0U;while(probe--)n+=(mask&(1U<<probe))!=0U;return n; }
static uint8_t expected(uint32_t pos)
{
    static const uint8_t sync[12]={0xd3U,0x6aU,0x59U,0xc5U,0x3eU,0xa7U,
        0x1dU,0xe4U,0xb2U,0x4fU,0x78U,0x96U};
    uint32_t frame=pos/100U,bit=pos%100U,wire=0U,line;
    if(bit==0U)return frame==0U?7U:0U;
    if(bit==1U)return 0U;
    for(line=0U;line<3U;line++){
        uint32_t at=frame*6U+line*2U+bit-2U;
        wire|=((uint32_t)((sync[at/8U]>>(at&7U))&1U))<<line;
    }
    return (uint8_t)wire;
}
static uint8_t group(const uint8_t *payload,const uint8_t *header,uint32_t tick,
                     uint32_t bits,uint32_t ticks,uint32_t codec,uint32_t probe,
                     uint32_t d8_phase,uint32_t raw_d8)
{
    uint32_t at,shift,raw;
    if(codec==5U)return (uint8_t)((payload[tick]>>(probe*3U))&7U);
    if(codec==6U){
        raw=payload[tick];if(probe<2U)return (uint8_t)((raw>>(probe*3U))&7U);
        at=tick+(raw_d8?d8_phase:0U);
        if(raw_d8 && at>=ticks)raw=(header[NP2_D8_DATA+((at-ticks)>>3U)]>>((at-ticks)&7U))&1U;
        else raw=(payload[ticks+(at>>3U)]>>(at&7U))&1U;
        return (uint8_t)(((payload[tick]>>6U)&3U)|(raw<<2U));
    }
    at=tick*bits+rank_mask(u32(header+76U),probe)*3U;shift=at&7U;raw=payload[at>>3U];
    if(shift>5U)raw|=(uint32_t)payload[(at>>3U)+1U]<<8;
    return (uint8_t)((raw>>shift)&7U);
}
static int profile(const uint8_t *h,uint32_t admitted,uint32_t *ticks,uint32_t *bits,
                   uint32_t *codec,uint32_t *mask,uint32_t *live,uint32_t *d8,uint32_t *raw_d8)
{
    uint32_t hz;
    static const uint8_t sync[12]={0xd3U,0x6aU,0x59U,0xc5U,0x3eU,0xa7U,
        0x1dU,0xe4U,0xb2U,0x4fU,0x78U,0x96U};
    if(memcmp(h,"NP2USB03",8U)!=0 || u32(h+8U)!=3U || u32(h+12U)!=512U ||
       u32(h+16U)!=46592U || u32(h+20U)!=46080U)return 0;
    *mask=u32(h+76U);*live=u32(h+80U);*bits=u32(h+156U);*codec=u32(h+160U);*ticks=u32(h+40U);
    hz=u32(h+60U);
    if(!admitted || (admitted&~7U) || (admitted&~*mask) || (admitted&~*live) ||
       (hz!=7500U && hz!=15000U && hz!=20000U && hz!=30000U) || u32(h+44U)!=hz*1600U ||
       memcmp(h+64U,sync,sizeof(sync))!=0 || u32(h+48U)!=
       (((*mask&1U)?7U:0U)|((*mask&2U)?56U:0U)|((*mask&4U)?448U:0U)) ||
       (u32(h+52U)&1U)==0U || (u32(h+52U)&4U)!=0U)return 0;
    if(!((*codec==4U && (((*mask==1U || *mask==2U) && *bits==3U && *ticks==122880U) ||
          (*mask==3U && *bits==6U && *ticks==61440U))) ||
         (*codec==5U && *mask==3U && *bits==8U && *ticks==46080U) ||
         (*codec==6U && *mask==7U && *bits==9U && *ticks==40960U)))return 0;
    *raw_d8=(u32(h+52U)&64U)!=0U;*d8=u32(h+NP2_D8_PHASE);
    if(*raw_d8){if(*codec!=6U || *d8>=NP2_PERIOD || u32(h+NP2_D8_LOOKAHEAD)!=(*d8+7U)/8U ||
        u32(h+NP2_D8_LOOKAHEAD)>200U)return 0;}
    else if(*d8 || u32(h+NP2_D8_LOOKAHEAD))return 0;
    return 1;
}
int XE_NP_Np2FirstSync_Prove(const uint8_t *block,uint32_t block_bytes,uint32_t admitted,XE_NP_Np2FirstSync *out)
{
    const uint8_t *h,*p;uint32_t ticks,bits,codec,mask,live,d8,raw,pn;
    uint64_t start;uint32_t probe;
    if(!block || !out || block_bytes!=46592U)return 0;h=block;p=block+512U;
    if(!profile(h,admitted,&ticks,&bits,&codec,&mask,&live,&d8,&raw) ||
       u64(h+32U)>UINT64_MAX-ticks)return 0;
    memset(out,0,sizeof(*out));out->mask=(uint8_t)admitted;start=u64(h+32U);
    for(probe=0U;(admitted&(1U<<probe))==0U;probe++){}out->reference=(uint8_t)probe;
    for(probe=0U;probe<3U;probe++){
        uint32_t candidate,matches=0U,phase=0U,i,inspect=ticks<NP2_SYNC_INSPECT?ticks:NP2_SYNC_INSPECT;
        if((admitted&(1U<<probe))==0U){out->phase[probe]=XE_NP_NP2_FIRST_SYNC_UNKNOWN_PHASE;
            out->first_tick[probe]=XE_NP_NP2_FIRST_SYNC_UNKNOWN_TICK;continue;}
        for(candidate=0U;candidate<NP2_PERIOD;candidate++){
            int ok=1;uint32_t frame,bit;
            for(frame=0U;frame<16U && ok;frame++)for(bit=0U;bit<4U;bit++){
                uint32_t pos=frame*100U+bit,check=(pos+NP2_PERIOD-candidate)%NP2_PERIOD;
                for(;check<inspect;check+=NP2_PERIOD)
                    if(group(p,h,check,bits,ticks,codec,probe,d8,raw)!=expected(pos)){ok=0;break;}
                if(!ok)break;
            }
            if(ok){phase=candidate;matches++;}
        }
        if(matches!=1U)return 0;
        {uint32_t frame,bit;for(frame=0U;frame<16U;frame++)for(bit=0U;bit<4U;bit++){
            uint32_t pos=frame*100U+bit,check=(pos+NP2_PERIOD-phase)%NP2_PERIOD;
            for(;check<ticks;check+=NP2_PERIOD){
                if(group(p,h,check,bits,ticks,codec,probe,d8,raw)!=expected(pos))return 0;
                out->checked_positions++;
            }
        }}
        pn=(uint32_t)((phase+NP2_PERIOD-(start%NP2_PERIOD))%NP2_PERIOD);
        out->phase[probe]=(uint16_t)pn;
        i=(NP2_PERIOD-phase)%NP2_PERIOD;
        out->first_tick[probe]=start+i;
    }
    return 1;
}
