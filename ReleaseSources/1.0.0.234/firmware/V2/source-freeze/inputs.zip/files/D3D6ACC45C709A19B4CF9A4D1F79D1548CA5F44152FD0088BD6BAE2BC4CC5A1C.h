#ifndef XE_NP_IMU_GRID_ADMISSION_H
#define XE_NP_IMU_GRID_ADMISSION_H
#include <stdint.h>

/* Experimental, foreground-only decision for ONE new grid transfer. This
 * helper does not read hardware, send USB, affect stop/abort, or prove the
 * caller's bounds. A caller must capture the offsets, NP slot counters and
 * producer lifetime as coherent snapshots; sample the snapshot clock no
 * later than those fields, and refresh 'now' from that same qualified clock.
 * service_window_us must conservatively cover decision-to-next-NP-service,
 * both EP82 header/payload starts, interrupt interference and bus contention.
 * Supply transport_qualified only with an independently justified bound. */
#ifndef XE_NP_GRID_FAIRNESS_TEST
#define XE_NP_GRID_FAIRNESS_TEST 0U
#endif
typedef struct {
    uint64_t snapshot_us,now_us,max_age_us,service_window_us;
    uint32_t snapshot_epoch,current_epoch;
    uint32_t ring_bytes,published_offset,consumer_offset,unpublished_bytes,retention_bytes,safety_bytes;
    uint32_t probe_mask,sample_hz,source_bytes_per_tick;
    uint32_t filled,submitted,completed,slot_count,active,segment_pending;
    uint32_t queue_head,queue_tail,queue_capacity,held,phase_done;
    uint32_t producer_active,producer_error,producer_borrowed;
    uint32_t coherent,clock_qualified,bound_qualified,transport_qualified,transport_idle;
    uint32_t stopping,interrupted,provider_ready,provider_inflight;
} XE_NP_GridAdmission;
#if XE_NP_GRID_FAIRNESS_TEST
/* 1 allows a single optional scheduling attempt; 0 preserves NP priority. */
int XE_NP_GridAdmission_Allow(const XE_NP_GridAdmission *s);
#else
/* No argument evaluation or decision overhead in normal firmware. */
#define XE_NP_GridAdmission_Allow(...) 0
#endif
#endif
