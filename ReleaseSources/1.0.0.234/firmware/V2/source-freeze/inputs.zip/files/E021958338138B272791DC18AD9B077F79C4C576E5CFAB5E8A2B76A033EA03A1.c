#include "xe_np_np2_first_sync_runtime.h"
#if XE_NP_NP2_FIRST_SYNC_ENABLE
#include "xe_np_np2_first_sync_sd.h"
#include "xe_np_np2_capture_port.h"
#include "xe_np_sensors_port.h"
#include "xe_np_usb_aux.h"
#include "main.h"
#include "xe_np_np2_sd_fine_clock.h"
#if NP_FINE_COUNTER64_ENABLE
#include "xe_np_np2_sd_fine_clock.h"
#include "xe_np_rtc_start.h"
#endif
/* One explicitly named CPU-only workspace; the software link comparison must
 * account for it without moving any fixed neural/capture/DMA reservation. */
typedef struct {
    XE_NP_Np2FirstSyncPort port;
    XE_NP_Np2FirstSyncSdContext sd;
    NpFirstSyncBinding binding;
    uint64_t token;
    uint32_t mode,nonce,session,mask,hz;
    uint8_t active,aux_mask;
#if NP_FINE_COUNTER64_ENABLE
    XE_NP_Np2SdFinePoint64 fine;
    uint8_t fine_anchor[64];
    uint32_t features;
    uint8_t prepared,clock_mode,fine_bound,fine_anchor_valid;
#endif
} NpFirstRuntime;
#if defined(_MSC_VER)
static NpFirstRuntime runtime;
#else
static NpFirstRuntime runtime __attribute__((section("NP_FIRST_CPU"),aligned(8)));
#endif
enum {FIRST_MODE_NONE=0U,FIRST_MODE_USB=1U,FIRST_MODE_SD=2U};
static void idle(void){}
static void (*service)(void)=idle;
static void freeze_pending(void);
#if NP_FINE_COUNTER64_ENABLE
static uint32_t token_seed(void)
{uint32_t seed=(uint32_t)runtime.token^(uint32_t)(runtime.token>>32U);return seed?seed:1U;}
static int counter64_selected(void)
{return (runtime.mode==FIRST_MODE_SD && runtime.features==25U) ||
        (runtime.mode==FIRST_MODE_USB && (runtime.features==7U || runtime.features==15U));}
static void rtc_bind(void)
{
#if XE_NP_RTC_START_ENABLE
    NpRtcStartBinding b={0};const uint8_t *wire;
    const uint32_t uid[3]={HAL_GetUIDw0(),HAL_GetUIDw1(),HAL_GetUIDw2()};
    if(!runtime.fine_bound || !runtime.fine_anchor_valid)return;
    if(XE_NP_RtcStart_Frozen(runtime.token,runtime.fine.domain,runtime.binding.generation,
        runtime.binding.source_epoch,runtime.fine.counter_hz))return;
    wire=XE_NP_Np2FirstSyncGate_Frozen(&runtime.port.gate);
    if(!wire)return;
    b.receipt=wire;b.anchor=runtime.fine_anchor;memcpy(b.uid,uid,sizeof(uid));
    b.family=2U;b.session=runtime.mode==FIRST_MODE_SD?runtime.binding.session:0U;
    b.token=runtime.token;b.continuous64=1U;(void)XE_NP_RtcStart_Bind(&b);
#endif
}
#endif
static int owner(void *user,NpFirstSyncBinding *b,XE_NP_Np2FirstSyncPoint *p)
{
    XE_NP_AcquisitionAnchor a;(void)user;
    if(!runtime.active || !runtime.binding.generation || !XE_NP_Np2CapturePort_Armed() ||
       !XE_NP_Np2CapturePort_GetAnchor(&a) || (a.flags&0xFF0DU)!=0x020DU ||
       a.generation!=runtime.binding.generation || a.sample_hz!=runtime.hz ||
       a.source_hz!=runtime.hz*1600U)return 0;
    *b=runtime.binding;
    /* No continuously qualified DWT domain is inferred from a raw enable
     * counter. SourceClock remains clear; numeric source framing is useful. */
#if NP_FINE_COUNTER64_ENABLE
    if(runtime.fine_bound){
        XE_NP_Np2SdFinePoint64 point;
        if((a.flags&0xFF1FU)!=0x021FU || !XE_NP_Np2SdFineClock_Read64(&point) ||
           point.domain!=b->domain || point.counter_hz!=b->counter_hz ||
           point.generation!=b->generation || point.source_epoch!=b->source_epoch)return 0;
        p->domain=point.domain;p->ms=point.ms;p->cycles=(uint32_t)point.counter;return 1;
    }
#endif
    if(b->domain){
        XE_NP_Np2SdFinePoint point;
        if((a.flags&0xFF1FU)!=0x021FU || !XE_NP_Np2SdFineClock_Read(&point) ||
           point.domain!=b->domain || point.counter_hz!=b->counter_hz ||
           point.generation!=b->generation || point.source_epoch!=b->source_epoch)return 0;
        p->domain=point.domain;p->ms=point.ms;p->cycles=point.counter;return 1;
    }
    p->domain=0U;p->ms=HAL_GetTick();p->cycles=UINT32_MAX;return 1;
}
static void opened(void *user,XE_NP_Np2FirstSyncGate *gate,const NpFirstSyncBinding *b)
{
    XE_NP_Np2FirstSyncPoint p={0U,HAL_GetTick(),UINT32_MAX};(void)user;
    if(runtime.binding.domain){
        NpFirstSyncBinding actual;
        if(!owner(NULL,&actual,&p) || actual.session!=b->session || actual.generation!=b->generation ||
           actual.source_epoch!=b->source_epoch || actual.domain!=b->domain || actual.counter_hz!=b->counter_hz)return;
    }
    if(!XE_NP_Np2FirstSyncGate_Open(gate,b))return;
    for(uint32_t id=1U;id<=4U;id++)if(runtime.aux_mask&(1U<<(id-1U)))
        (void)XE_NP_Np2FirstSyncGate_Release(gate,b,id,&p);
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
    if(runtime.aux_mask&1U){
#if NP_FINE_COUNTER64_ENABLE
        if(counter64_selected()){
            if(!runtime.fine_bound || !XE_NP_SensorsPort_FirstSyncRelease(gate)){
                XE_NP_SensorsPort_FineStop();XE_NP_SensorsPort_FirstSyncLegacy();
            }
        }else
#endif
        (void)XE_NP_SensorsPort_FirstSyncRelease(gate);
    }
#endif
#if XE_NP_V2_AUX_ENABLE
    if(runtime.mode==FIRST_MODE_USB)XE_NP_UsbAux_FirstSyncRelease(gate);
#endif
    service=freeze_pending;freeze_pending();
}
static void freeze_pending(void)
{
    if(!runtime.active){service=idle;return;}
    XE_NP_Np2FirstSyncGate *gate=&runtime.port.gate;
    if(!gate->receipt.session)return;
    if(XE_NP_Np2FirstSyncGate_Freeze(gate,&runtime.binding,HAL_GetTick(),!gate->bound)){
#if NP_FINE_COUNTER64_ENABLE
        rtc_bind();
#endif
        service=idle;
    }
}
static void runtime_legacy(void)
{
#if NP_FINE_COUNTER64_ENABLE
    XE_NP_Np2SdFineDiagnosticEnd();
#endif
    XE_NP_Np2SdFineClock_Invalidate();
    XE_NP_Np2FirstSyncPort_Invalidate();service=idle;runtime.active=0U;runtime.mode=FIRST_MODE_NONE;
#if NP_FINE_COUNTER64_ENABLE
    XE_NP_SensorsPort_FineStop();XE_NP_RtcStart_Clear();
    runtime.prepared=runtime.clock_mode=runtime.fine_bound=runtime.fine_anchor_valid=0U;
    runtime.features=0U;memset(&runtime.fine,0,sizeof(runtime.fine));
#endif
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
    XE_NP_SensorsPort_FirstSyncLegacy();
#endif
#if XE_NP_V2_AUX_ENABLE
    XE_NP_UsbAux_FirstSyncLegacy();
#endif
}
void XE_NP_Np2FirstSyncRuntime_Init(void)
{
    XE_NP_Np2FirstSyncPort_Invalidate();memset(&runtime,0,sizeof(runtime));service=idle;
#if XE_NP_NP2_DUAL_SD_APP_ENABLE
    XE_NP_Np2FirstSyncSd_Bind(&runtime.sd);
#endif
    runtime_legacy();
}
void XE_NP_Np2FirstSyncRuntime_SdPrepare(uint32_t nonce,uint32_t session,uint32_t mask,uint32_t hz)
{
#if XE_NP_NP2_DUAL_SD_APP_ENABLE
    const XE_NP_Np2FirstSyncSdContext *r=XE_NP_Np2FirstSyncSd_Record();
    runtime_legacy();memset(&runtime.port,0,sizeof(runtime.port));memset(&runtime.binding,0,sizeof(runtime.binding));
    if(!r || r->retired || r->nonce!=nonce || !r->token || !session)return;
    runtime.mode=FIRST_MODE_SD;runtime.active=1U;runtime.nonce=nonce;runtime.token=r->token;
    runtime.session=session;runtime.mask=mask;runtime.hz=hz;
#if NP_FINE_COUNTER64_ENABLE
    runtime.features=XE_NP_Np2FirstSyncSd_CurrentContinuity()?25U:0U;
    XE_NP_Np2SdFineDiagnosticBegin(runtime.features?runtime.nonce:0U,runtime.features);
#endif
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE && XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE
    runtime.aux_mask=1U;
#else
    runtime.aux_mask=0U;
#endif
#else
    (void)nonce;(void)session;(void)mask;(void)hz;runtime_legacy();
#endif
}
int XE_NP_Np2FirstSyncRuntime_SdOpted(void)
{return runtime.active && runtime.mode==FIRST_MODE_SD;}
int XE_NP_Np2FirstSyncRuntime_SdClockBegin(void)
{return XE_NP_Np2FirstSyncRuntime_SdOpted() && runtime.nonce &&
    XE_NP_Np2SdFineClock_Start(runtime.nonce,0U,0U);}
static int legacy_fine_anchor(uint8_t out[64])
{
    XE_NP_AcquisitionAnchor a;
    if(!out || !XE_NP_Np2FirstSyncRuntime_SdOpted() || !runtime.binding.domain ||
       !XE_NP_Np2CapturePort_GetAnchor(&a) || (a.flags&0xFF1FU)!=0x021FU ||
       a.generation!=runtime.binding.generation || a.counter_hz!=runtime.binding.counter_hz ||
       a.source_hz!=runtime.hz*1600U || a.sample_hz!=runtime.hz)return 0;
    XE_NP_AcquisitionAnchor_Reply(&a,runtime.binding.domain,out);return 1;
}
#if !NP_FINE_COUNTER64_ENABLE
int XE_NP_Np2FirstSyncRuntime_SdFineAnchor(uint8_t out[64]){return legacy_fine_anchor(out);}
#endif
#if NP_FINE_COUNTER64_ENABLE
int XE_NP_Np2FirstSyncRuntime_ClockBegin(void)
{
    if(!runtime.active)return 0;
    XE_NP_Np2SdFineDiagnosticProgress(XE_NP_FINE_PROGRESS_CLOCK_BEGIN_CALLED);
    if(counter64_selected()){
        if(!XE_NP_Np2SdFineClock_Start64(token_seed(),0U,0U)){
            XE_NP_Np2SdFineDiagnosticFailure(XE_NP_FINE_DIAG_CLOCK_BEGIN,0U,0U,0U,NULL,NULL);
            XE_NP_Np2SdFineDiagnosticProgress(XE_NP_FINE_PROGRESS_CLOCK_BEGIN_FAIL);
            return 0;
        }
        runtime.clock_mode=2U;
        XE_NP_Np2SdFineDiagnosticProgress(XE_NP_FINE_PROGRESS_CLOCK_BEGIN_OK);
#if XE_NP_RTC_START_ENABLE
        if(runtime.mode==FIRST_MODE_SD || runtime.features==15U)(void)XE_NP_RtcStart_Observe(runtime.token);
#endif
        return 2;
    }
    if(runtime.mode!=FIRST_MODE_SD)return 0;
    if(XE_NP_Np2SdFineClock_Start(token_seed(),0U,0U)){runtime.clock_mode=1U;return 1;}
    return 0;
}
int XE_NP_Np2FirstSyncRuntime_FineBound(uint32_t generation,uint32_t source_epoch,
    const XE_NP_Np2SdFinePoint64 *before,const XE_NP_Np2SdFinePoint64 *after)
{
    XE_NP_Np2SdFinePoint64 point;
    XE_NP_Np2SdFineDiagnosticProgress(XE_NP_FINE_PROGRESS_FINE_BOUND_CALLED);
    if(!runtime.active || runtime.clock_mode!=2U || runtime.fine_bound ||
       !XE_NP_Np2SdFineClock_BindSource64(generation,source_epoch,before,after) ||
       !XE_NP_Np2SdFineClock_Read64(&point) || point.generation!=generation ||
       point.source_epoch!=source_epoch || point.counter_hz!=XE_NP_NP2_SD_FINE_HZ){
        XE_NP_Np2SdFineDiagnosticFailure(XE_NP_FINE_DIAG_RUNTIME_FINE_BOUND,0U,generation,source_epoch,before,after);
        XE_NP_Np2SdFineDiagnosticProgress(XE_NP_FINE_PROGRESS_FINE_BOUND_FAIL);
        return 0;
    }
    runtime.fine=point;runtime.fine_bound=1U;
    XE_NP_Np2SdFineDiagnosticProgress(XE_NP_FINE_PROGRESS_FINE_BOUND_OK);
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
    (void)XE_NP_SensorsPort_FineStart(XE_NP_Np2SdFineClock_Read64Irq,XE_NP_Np2SdFineClock_Read64);
#endif
    return 1;
}
int XE_NP_Np2FirstSyncRuntime_FineCounter64(void)
{return runtime.active && runtime.fine_bound && runtime.clock_mode==2U;}
int XE_NP_Np2FirstSyncRuntime_SdFineAnchor(uint8_t out[64])
{
    if(!runtime.fine_anchor_valid)return legacy_fine_anchor(out);
    if(!out)return 0;
    memcpy(out,runtime.fine_anchor,64U);return 1;
}
const uint8_t *XE_NP_Np2FirstSyncRuntime_RtcFrozen(void)
{
#if XE_NP_RTC_START_ENABLE
    if(!runtime.fine_bound)return NULL;
    return XE_NP_RtcStart_Frozen(runtime.token,runtime.fine.domain,runtime.binding.generation,
                                 runtime.binding.source_epoch,runtime.fine.counter_hz);
#else
    return NULL;
#endif
}
#endif
static int armed(void)
{
    XE_NP_AcquisitionAnchor a;
    if(!runtime.active || !XE_NP_Np2CapturePort_Armed() || !XE_NP_Np2CapturePort_GetAnchor(&a) ||
       (a.flags&0xFF0DU)!=0x020DU || !a.generation || a.sample_hz!=runtime.hz || a.source_hz!=runtime.hz*1600U)return 0;
    runtime.binding=(NpFirstSyncBinding){runtime.mode==FIRST_MODE_USB?a.generation:runtime.session,
        a.generation,a.generation,
#if NP_FINE_COUNTER64_ENABLE
        runtime.fine_bound?runtime.fine.domain:0U,
#else
        0U,
#endif
#if NP_FINE_COUNTER64_ENABLE
        runtime.fine_bound?runtime.fine.counter_hz:0U,
#else
        0U,
#endif
        UINT32_MAX,2U,runtime.mask,runtime.hz};
#if NP_FINE_COUNTER64_ENABLE
    if(runtime.fine_bound && ((a.flags&0xFF1FU)!=0x021FU ||
       runtime.fine.generation!=a.generation || runtime.fine.source_epoch!=a.generation ||
       runtime.fine.counter_hz!=a.counter_hz))return 0;
    if(runtime.fine_bound && !runtime.fine_anchor_valid){
        XE_NP_AcquisitionAnchor_Reply(&a,runtime.fine.domain,runtime.fine_anchor);runtime.fine_anchor_valid=1U;
    }
#endif
    if(!runtime.binding.domain){
        XE_NP_Np2SdFinePoint point;
        if((a.flags&0xFF1FU)==0x021FU && XE_NP_Np2SdFineClock_Read(&point) &&
           point.generation==a.generation && point.source_epoch==a.generation &&
           point.counter_hz==a.counter_hz){runtime.binding.domain=point.domain;runtime.binding.counter_hz=point.counter_hz;}
    }
#if XE_NP_NP2_DUAL_SD_APP_ENABLE
    if(runtime.mode==FIRST_MODE_SD && !XE_NP_Np2FirstSyncSd_Capture(runtime.nonce,runtime.session,
        a.generation,a.generation,UINT32_MAX))return 0;
#endif
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
    if(runtime.aux_mask&1U){
#if NP_FINE_COUNTER64_ENABLE
        if(counter64_selected() && !runtime.fine_bound){
            XE_NP_SensorsPort_FineStop();XE_NP_SensorsPort_FirstSyncLegacy();
        }else
#endif
        XE_NP_SensorsPort_FirstSyncWait();
    }
#endif
#if XE_NP_V2_AUX_ENABLE
    if(runtime.mode==FIRST_MODE_USB)XE_NP_UsbAux_FirstSyncWait();
#endif
    if(!XE_NP_Np2FirstSyncPort_Bind(&runtime.port,owner,opened,NULL,runtime.aux_mask,runtime.binding.domain!=0U))return 0;
    service=freeze_pending;return 1;
}
void XE_NP_Np2FirstSyncRuntime_SdArmed(void)
{if(XE_NP_Np2FirstSyncRuntime_SdOpted() && !armed())runtime_legacy();}
#if NP_FINE_COUNTER64_ENABLE
int XE_NP_Np2FirstSyncRuntime_UsbPrepare(uint64_t token,uint32_t mask,uint32_t hz,uint8_t aux,uint32_t features)
{
    runtime_legacy();memset(&runtime.port,0,sizeof(runtime.port));memset(&runtime.binding,0,sizeof(runtime.binding));
    if(!token)return 1;
    runtime.mode=FIRST_MODE_USB;runtime.active=1U;runtime.token=token;runtime.mask=mask;runtime.hz=hz;runtime.aux_mask=aux;
    if(features!=0U && features!=7U && features!=15U){runtime_legacy();return 0;}
    runtime.features=features;runtime.prepared=1U;
    XE_NP_Np2SdFineDiagnosticBegin(features?token_seed():0U,features);
    return 1;
}
#endif
int XE_NP_Np2FirstSyncRuntime_UsbArmed(uint64_t token,uint32_t mask,uint32_t hz,uint8_t aux)
{
#if NP_FINE_COUNTER64_ENABLE
    if(runtime.active && runtime.mode==FIRST_MODE_USB && runtime.prepared){
        if(runtime.token!=token || runtime.mask!=mask || runtime.hz!=hz || runtime.aux_mask!=aux)return 0;
        runtime.prepared=0U;if(armed())return 1;runtime_legacy();return 0;
    }
    if(!XE_NP_Np2FirstSyncRuntime_UsbPrepare(token,mask,hz,aux,0U))return 0;
    if(!token)return 1;
    if(armed())return 1;runtime_legacy();return 0;
#else
    runtime_legacy();memset(&runtime.port,0,sizeof(runtime.port));memset(&runtime.binding,0,sizeof(runtime.binding));
    if(!token)return 1;
    runtime.mode=FIRST_MODE_USB;runtime.active=1U;runtime.token=token;runtime.mask=mask;runtime.hz=hz;runtime.aux_mask=aux;
    if(armed())return 1;runtime_legacy();return 0;
#endif
}
void XE_NP_Np2FirstSyncRuntime_Stop(void)
{
#if NP_FINE_COUNTER64_ENABLE
    XE_NP_Np2SdFineDiagnosticEnd();
#endif
    if(!runtime.active || !runtime.binding.generation)return;
    if(!runtime.port.gate.receipt.session)
        (void)XE_NP_Np2FirstSyncGate_Begin(&runtime.port.gate,&runtime.binding,runtime.aux_mask,0);
    (void)XE_NP_Np2FirstSyncGate_Freeze(&runtime.port.gate,&runtime.binding,HAL_GetTick(),1);service=idle;
#if NP_FINE_COUNTER64_ENABLE
    rtc_bind();XE_NP_SensorsPort_FineStop();XE_NP_Np2SdFineClock_Invalidate();
#endif
}
void XE_NP_Np2FirstSyncRuntime_Service(void){service();}
void XE_NP_Np2FirstSyncRuntime_AuxAccepted(uint32_t id,uint64_t counter,uint8_t bits,uint32_t rn,uint32_t rd)
{
    XE_NP_Np2FirstSyncGate *gate=&runtime.port.gate;NpFirstSyncAux a={0};
    if(!runtime.active || gate->frozen || id<1U || id>4U || (gate->aux_seen&(1U<<(id-1U))) ||
       !XE_NP_Np2FirstSyncGate_Open(gate,&runtime.binding))return;
    a.id=(uint8_t)id;a.flags=NP_FIRST_AUX_ENABLED|NP_FIRST_AUX_COUNTER;a.counter_bits=bits;a.counter=counter;
    a.rate_num=rn;a.rate_den=rd;a.release_ms=a.release_cycles=a.first_ms=a.first_cycles=UINT32_MAX;a.offset_num=INT64_MIN;
    if(XE_NP_Np2FirstSyncGate_RecordAux(gate,&runtime.binding,&a,0U))freeze_pending();
}
const uint8_t *XE_NP_Np2FirstSyncRuntime_FrozenUsb(uint64_t token)
{
    return runtime.active && runtime.mode==FIRST_MODE_USB && token && token==runtime.token?
        XE_NP_Np2FirstSyncGate_Frozen(&runtime.port.gate):NULL;
}
void XE_NP_Np2FirstSyncRuntime_SdTime(uint8_t sector[512])
{
#if XE_NP_NP2_DUAL_SD_APP_ENABLE
    const XE_NP_Np2FirstSyncSdContext *r=XE_NP_Np2FirstSyncSd_Record();
    const uint8_t *wire=XE_NP_Np2FirstSyncGate_Frozen(&runtime.port.gate);
    const uint32_t uid[3]={HAL_GetUIDw0(),HAL_GetUIDw1(),HAL_GetUIDw2()};
    if(!sector || !XE_NP_Np2FirstSyncRuntime_SdOpted() || !r || !wire || r->token!=runtime.token || r->nonce!=runtime.nonce ||
       r->current.session!=runtime.binding.session || r->current.generation!=runtime.binding.generation ||
       r->current.source_epoch!=runtime.binding.source_epoch || np_first_u32(wire+16)!=runtime.binding.session ||
       np_first_u32(wire+20)!=runtime.binding.generation || np_first_u32(wire+24)!=runtime.binding.source_epoch)return;
    /* One existing foreground metadata write, never a neural/data-path write.
     * Failure preserves the old validated sector and cannot stop recording. */
    (void)np_first_sd_sector_bind(sector,sector,wire,2U,uid,runtime.token);
#else
    (void)sector;
#endif
}
#endif
