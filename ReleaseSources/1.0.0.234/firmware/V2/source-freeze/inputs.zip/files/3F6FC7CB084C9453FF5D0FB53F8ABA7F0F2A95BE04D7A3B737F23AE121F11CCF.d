D:\Code\XE_NP_V2\_artifacts\v2_ble_cold_start_20261007_build\usb\xe_np_bmm_compensation.o: \
  D:\Code\XE_NP_V2\Core\Src\xe_np_bmm_compensation.c \
  D:\Code\XE_NP_V2\Core\Src\..\..\Middlewares\Bosch\BMM150_SensorAPI\bmm150.c \
  D:\Code\XE_NP_V2\Core\Src\..\..\Middlewares\Bosch\BMM150_SensorAPI\bmm150.h \
  D:\Code\XE_NP_V2\Core\Src\..\..\Middlewares\Bosch\BMM150_SensorAPI\bmm150_defs.h
