#include "xe_np_np2_transport.h"
#include <stddef.h>
#include <string.h>

/* This object is deliberately separate from xe_np_np2_transport.c. The
 * resident single-NP2 SD application links only the latter, preserving its
 * already-qualified binary while the triple PSSI profile is developed. */
_Static_assert(XE_NP_NP2_TRIPLE_CHUNK_INPUT_TICKS%
               (XE_NP_NP2_FRAME_TICKS*XE_NP_NP2_FRAMES_PER_SUPERFRAME)==0U,
               "Triple chunk must contain whole NP2 superframes");
_Static_assert(XE_NP_NP2_TRIPLE_CHUNK_INPUT_TICKS%128U==0U,
               "Triple pack quanta");
_Static_assert(XE_NP_NP2_TRIPLE_CHUNK_INPUT_TICKS*9U==
               XE_NP_NP2_TRIPLE_CHUNK_PACKED_BYTES*8U,
               "Triple lossless ratio");
_Static_assert((UINT64_C(54000000)*65536U+
                XE_NP_NP2_TRIPLE_CHUNK_PACKED_BYTES-1U)/
               XE_NP_NP2_TRIPLE_CHUNK_PACKED_BYTES==
               XE_NP_NP2_TRIPLE_CONTAINER_BYTES_PER_SEC,
               "Triple container rate");

/* Collapse two 16-bit PSSI ticks into 18 useful bits using one aligned load.
 * memcpy keeps the public uint16_t input free of strict-aliasing assumptions. */
static inline uint32_t pair9(const uint16_t *source)
{
    uint32_t word;
    memcpy(&word,source,sizeof(word));
#if defined(__ARM_FEATURE_DSP) && defined(__clang__)
    /* SMLAD treats the two halfwords as parallel signed operands. After the
     * explicit 9-bit mask they are positive, so [1,512] collapses both PSSI
     * ticks into the required dense 18-bit pair in one DSP instruction. */
    word&=0x01FF01FFU;
    return (uint32_t)__builtin_arm_smlad((int32_t)word,0x02000001,0);
#else
    return (word&0x1FFU)|((word>>7U)&0x3FE00U);
#endif
}
static inline void store32(uint8_t *destination,uint32_t word)
{
    memcpy(destination,&word,sizeof(word));
}

int XE_NP_Np2Pack9From16(const uint16_t *source,uint32_t input_ticks,
                         uint8_t *destination,uint32_t capacity_bytes)
{
    uintptr_t src=(uintptr_t)source,dst=(uintptr_t)destination;
    uint32_t input_bytes,output_bytes;
    if(!source || !destination || !input_ticks || input_ticks%128U ||
       input_ticks>UINT32_MAX/2U || ((src|dst)&3U))return XE_NP_NP2_PACK_ARGUMENT;
    input_bytes=input_ticks*2U;output_bytes=(input_ticks/8U)*9U;
    if(capacity_bytes<output_bytes)return XE_NP_NP2_PACK_CAPACITY;
    if(src>UINTPTR_MAX-input_bytes || dst>UINTPTR_MAX-output_bytes ||
       (src<dst+output_bytes && dst<src+input_bytes))return XE_NP_NP2_PACK_OVERLAP;
    /* 32 ticks -> nine aligned words (36 bytes).  The previous eight-tick
     * loop advanced by nine bytes, giving six unaligned stores per 32 ticks.
     * Carry only the boundary pair between output words to limit register
     * pressure on M33. Wire order is unchanged: consecutive 9-bit samples,
     * least-significant bit first, with no unused upper PSSI bits retained. */
    for(uint32_t groups=input_ticks/32U;groups;groups--,source+=32U,destination+=36U) {
        uint32_t a=pair9(source),b=pair9(source+2U),c;
        store32(destination,a|(b<<18U));
        a=pair9(source+4U);c=pair9(source+6U);
        store32(destination+4U,(b>>14U)|(a<<4U)|(c<<22U));
        a=pair9(source+8U);b=pair9(source+10U);
        store32(destination+8U,(c>>10U)|(a<<8U)|(b<<26U));
        a=pair9(source+12U);c=pair9(source+14U);
        store32(destination+12U,(b>>6U)|(a<<12U)|(c<<30U));
        b=pair9(source+16U);
        store32(destination+16U,(c>>2U)|(b<<16U));
        a=pair9(source+18U);c=pair9(source+20U);
        store32(destination+20U,(b>>16U)|(a<<2U)|(c<<20U));
        a=pair9(source+22U);b=pair9(source+24U);
        store32(destination+24U,(c>>12U)|(a<<6U)|(b<<24U));
        a=pair9(source+26U);c=pair9(source+28U);
        store32(destination+28U,(b>>8U)|(a<<10U)|(c<<28U));
        a=pair9(source+30U);
        store32(destination+32U,(c>>4U)|(a<<14U));
    }
    return XE_NP_NP2_PACK_OK;
}

/* Two 16-bit PSSI ticks become one compact six-bit/twelve-bit field. These
 * helpers let the M33 use aligned word loads instead of the previous inner
 * per-tick bit-position loop. At 32 MHz the generic loop could not retire a
 * single-probe span before DMA filled the retention ring. */
static inline uint32_t pair3_from16(const uint16_t *source,uint32_t shift)
{
    uint32_t word;
    memcpy(&word,source,sizeof(word));
    word=(word>>shift)&0x00070007U;
    return (word&7U)|((word>>13U)&0x38U);
}

static inline uint32_t four3_from16(const uint16_t *source,uint32_t shift)
{return pair3_from16(source,shift)|(pair3_from16(source+2U,shift)<<6U);}

static inline uint32_t pair6_contiguous_from16(const uint16_t *source,uint32_t shift)
{
    uint32_t word;
    memcpy(&word,source,sizeof(word));
    word=(word>>shift)&0x003F003FU;
    return (word&0x3FU)|((word>>10U)&0xFC0U);
}

static inline uint32_t pair6_split_from16(const uint16_t *source)
{
    uint32_t word;
    memcpy(&word,source,sizeof(word));
    word=(word&0x00070007U)|((word>>3U)&0x00380038U);
    return (word&0x3FU)|((word>>10U)&0xFC0U);
}

static inline uint32_t pair6_from16(const uint16_t *source,uint32_t shift,uint32_t split)
{return split?pair6_split_from16(source):pair6_contiguous_from16(source,shift);}

static inline void pack16_6_from16(const uint16_t *source,uint32_t shift,uint32_t split,
                                   uint8_t *destination)
{
    uint32_t a=pair6_from16(source,shift,split),b=pair6_from16(source+2U,shift,split);
    uint32_t c=pair6_from16(source+4U,shift,split),d=pair6_from16(source+6U,shift,split);
    uint32_t out[3];
    out[0]=a|(b<<12U)|(c<<24U);
    uint32_t carry=(c>>8U)|(d<<4U);
    a=pair6_from16(source+8U,shift,split);b=pair6_from16(source+10U,shift,split);
    c=pair6_from16(source+12U,shift,split);d=pair6_from16(source+14U,shift,split);
    out[1]=carry|(a<<16U)|(b<<28U);
    out[2]=(b>>4U)|(c<<8U)|(d<<20U);
    memcpy(destination,out,sizeof(out));
}

static void pack3_from16(const uint16_t *source,uint32_t input_ticks,uint8_t mask,
                         uint8_t *destination)
{
    uint32_t shift=mask==XE_NP_NP2_PROBE_FIRST?0U:
                   mask==XE_NP_NP2_PROBE_SECOND?3U:6U;
    for(uint32_t groups=input_ticks/32U;groups;groups--,source+=32U,destination+=12U) {
        uint32_t a=four3_from16(source,shift),b=four3_from16(source+4U,shift);
        uint32_t c=four3_from16(source+8U,shift),d=four3_from16(source+12U,shift);
        uint32_t out[3];
        out[0]=a|(b<<12U)|(c<<24U);
        uint32_t carry=(c>>8U)|(d<<4U);
        a=four3_from16(source+16U,shift);b=four3_from16(source+20U,shift);
        c=four3_from16(source+24U,shift);d=four3_from16(source+28U,shift);
        out[1]=carry|(a<<16U)|(b<<28U);
        out[2]=(b>>4U)|(c<<8U)|(d<<20U);
        memcpy(destination,out,sizeof(out));
    }
}

static void pack6_from16(const uint16_t *source,uint32_t input_ticks,uint8_t mask,
                         uint8_t *destination)
{
    uint32_t split=mask==(XE_NP_NP2_PROBE_FIRST|XE_NP_NP2_PROBE_THIRD);
    uint32_t shift=mask==(XE_NP_NP2_PROBE_SECOND|XE_NP_NP2_PROBE_THIRD)?3U:0U;
    for(uint32_t groups=input_ticks/32U;groups;groups--,source+=32U,destination+=24U) {
        pack16_6_from16(source,shift,split,destination);
        pack16_6_from16(source+16U,shift,split,destination+12U);
    }
}

int XE_NP_Np2PackSelectedFrom16(const uint16_t *source,uint32_t input_ticks,
                                uint8_t probe_mask,uint8_t *destination,
                                uint32_t capacity_bytes)
{
    uintptr_t src=(uintptr_t)source,dst=(uintptr_t)destination;
    uint32_t probes,bits,input_bytes,output_bytes;
    if(probe_mask==0U || (probe_mask&~XE_NP_NP2_PROBE_ALL)!=0U)return XE_NP_NP2_PACK_ARGUMENT;
    probes=((probe_mask&1U)!=0U)+((probe_mask&2U)!=0U)+((probe_mask&4U)!=0U);
    bits=probes*3U;
    if(!source || !destination || !input_ticks || input_ticks%128U ||
       input_ticks>UINT32_MAX/2U || ((src|dst)&3U))return XE_NP_NP2_PACK_ARGUMENT;
    input_bytes=input_ticks*2U;output_bytes=(input_ticks/8U)*bits;
    if(capacity_bytes<output_bytes)return XE_NP_NP2_PACK_CAPACITY;
    if(src>UINTPTR_MAX-input_bytes || dst>UINTPTR_MAX-output_bytes ||
       (src<dst+output_bytes && dst<src+input_bytes))return XE_NP_NP2_PACK_OVERLAP;
    if(bits==9U)return XE_NP_Np2Pack9From16(source,input_ticks,destination,capacity_bytes);
    if(bits==6U)pack6_from16(source,input_ticks,probe_mask,destination);
    else pack3_from16(source,input_ticks,probe_mask,destination);
    return XE_NP_NP2_PACK_OK;
}

int XE_NP_Np2SplitPssi8D8From16(const uint16_t *source,uint32_t input_ticks,
                                uint8_t *payload,uint32_t total_ticks,
                                uint32_t tick_offset)
{
    if(!source || !payload || !input_ticks || (input_ticks&7U) ||
       (tick_offset&7U) || (total_ticks&7U) || tick_offset>total_ticks ||
       input_ticks>total_ticks-tick_offset)return XE_NP_NP2_PACK_ARGUMENT;
    uint8_t *raw=payload+tick_offset;
    uint8_t *d8=payload+total_ticks+tick_offset/8U;
    for(uint32_t group=0U;group<input_ticks/8U;group++,source+=8U,raw+=8U) {
        uint8_t high=0U;
        for(uint32_t n=0U;n<8U;n++) {
            uint16_t sample=source[n];
            raw[n]=(uint8_t)sample;
            high|=(uint8_t)(((sample>>8U)&1U)<<n);
        }
        d8[group]=high;
    }
    return XE_NP_NP2_PACK_OK;
}
