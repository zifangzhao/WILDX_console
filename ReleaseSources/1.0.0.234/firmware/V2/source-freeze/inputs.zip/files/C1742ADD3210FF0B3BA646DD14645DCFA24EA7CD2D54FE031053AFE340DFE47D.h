#ifndef XE_NP_NP2_STAGE_SD_NODES_H
#define XE_NP_NP2_STAGE_SD_NODES_H
#include "xe_np_np2_stage_queue.h"
#include "stm32u5xx_hal.h"
#include "stm32u5xx_hal_sd_ex.h"

/* Prepare one ordered CMD25 IDMA list from arbitrary SRAM restore slots.
 * nodes and list must be 32-byte aligned in the descriptor arena. No payload
 * bytes are copied by this function. node_bytes[i] lets the IDMA IRQ retire
 * complete record units at descriptor boundaries. */
int XE_Np2StageSd_BuildNodes(const XE_Np2StageQueue *queue,
    const uint32_t physical_ru_base[13],SD_DMALinkNodeTypeDef *nodes,
    uint32_t node_capacity,SD_DMALinkedListTypeDef *list,
    uint32_t node_bytes[XE_NP2_STAGE_MAX_SD_NODES],
    DCACHE_HandleTypeDef *cache);
#endif
