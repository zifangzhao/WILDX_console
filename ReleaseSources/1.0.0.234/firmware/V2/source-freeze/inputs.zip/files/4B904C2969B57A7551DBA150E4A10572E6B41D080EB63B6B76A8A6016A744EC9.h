#ifndef XE_NP_AUX_COST_DIAG_H
#define XE_NP_AUX_COST_DIAG_H
#include <stdint.h>

/* Lab-only, read after AUX quiesces. DWT is never enabled/reset here. Counts
 * and cycle sums saturate. Invalid includes unavailable/stopped DWT, debug,
 * clock-rate change, zero elapsed or modular delta >=2^31 cycles. A valid
 * sample includes interrupt preemption. Full counter wraps or transient clock
 * changes between the two reads are not detectable; this is not a WCET bound. */
#ifndef XE_NP_GRID_AUX_COST_DIAG
#define XE_NP_GRID_AUX_COST_DIAG 0U
#endif
#if XE_NP_GRID_AUX_COST_DIAG
enum {XE_NP_AUX_COST_PROVIDER, XE_NP_AUX_COST_HEADER, XE_NP_AUX_COST_PAYLOAD, XE_NP_AUX_COST_COUNT};
typedef struct {uint32_t valid,invalid,max_cycles,total_cycles,saturated;} XE_NP_AuxCostBin;
typedef struct {uint32_t core_hz;XE_NP_AuxCostBin bin[XE_NP_AUX_COST_COUNT];} XE_NP_AuxCostDiag;
typedef struct {uint32_t start,hz,valid;} XE_NP_AuxCostStamp;
extern volatile XE_NP_AuxCostDiag xe_np_aux_cost_diag;
static inline uint32_t XE_NP_AuxCost_Ready(void)
{
    return (CoreDebug->DEMCR&CoreDebug_DEMCR_TRCENA_Msk) &&
        (DWT->CTRL&DWT_CTRL_CYCCNTENA_Msk) &&
        !(CoreDebug->DHCSR&CoreDebug_DHCSR_C_DEBUGEN_Msk) && SystemCoreClock;
}
static inline XE_NP_AuxCostStamp XE_NP_AuxCost_Start(void)
{
    XE_NP_AuxCostStamp s={0U,0U,0U};
    if(XE_NP_AuxCost_Ready()){s.hz=SystemCoreClock;s.start=DWT->CYCCNT;s.valid=1U;}
    return s;
}
static inline void XE_NP_AuxCost_Increment(volatile uint32_t *v,volatile uint32_t *sat)
{if(*v!=UINT32_MAX)++*v;else *sat=1U;}
static inline void XE_NP_AuxCost_End(uint32_t kind,XE_NP_AuxCostStamp s)
{
    uint32_t delta;volatile XE_NP_AuxCostBin *b;
    if(kind>=XE_NP_AUX_COST_COUNT)return;b=&xe_np_aux_cost_diag.bin[kind];
    if(!s.valid || !XE_NP_AuxCost_Ready() || s.hz!=SystemCoreClock ||
       (xe_np_aux_cost_diag.core_hz && xe_np_aux_cost_diag.core_hz!=s.hz)){
        XE_NP_AuxCost_Increment(&b->invalid,&b->saturated);return;
    }
    delta=DWT->CYCCNT-s.start;
    if(!delta || delta>=UINT32_C(0x80000000)){
        XE_NP_AuxCost_Increment(&b->invalid,&b->saturated);return;
    }
    xe_np_aux_cost_diag.core_hz=s.hz;XE_NP_AuxCost_Increment(&b->valid,&b->saturated);
    if(delta>b->max_cycles)b->max_cycles=delta;
    if(delta>UINT32_MAX-b->total_cycles){b->total_cycles=UINT32_MAX;b->saturated=1U;}
    else b->total_cycles+=delta;
}
#endif
#endif
