C:\Frank\Code\USB_PCconsole\_artifacts\closed_loop_20261102\V2\build-app\xe_np_np2_closed_loop_sd.o: \
  D:\Code\XE_NP_V2\Core\Src\xe_np_np2_closed_loop_sd.c \
  D:\Code\XE_NP_V2\Core\Inc\xe_np_np2_closed_loop_sd.h \
  D:\Code\XE_NP_V2\Core\Inc\xe_np_np2_sd_append.h \
  D:\Code\XE_NP_V2\Core\Inc\xe_np_np2_dual_sd_meta.h \
  D:\Code\XE_NP_V2\Core\Inc\xe_np_np2_dual_sd_run.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\stdint.h \
  D:\Code\XE_NP_V2\Core\Inc\xe_np_np2_closed_loop_carrier.h \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Inc\np_cl_kernel.h \
  D:\Code\XE_NP_V2\Core\Inc\xe_np_np2_closed_loop_spi.h \
  D:\Code\XE_NP_V2\Core\Inc\xe_np_np2_closed_loop_perf.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\string.h
