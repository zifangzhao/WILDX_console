#include "CE32_macro.h"
#ifdef __PROFILE
void Profile_Log(Profile_CNT *h,uint8_t* msg,uint16_t msg_len,int enable)
{
	if(enable)
	{
		static uint8_t uid=0;
		uint32_t cur_syscyc = PROFILE_CYC;
		uint32_t delay = cur_syscyc-h->last_syscyc;
		h->last_syscyc = cur_syscyc;
		uint8_t* id = (uint8_t*)&h->evt_id;
		dataMGR_enQueue_byte(&h->MGR,'#');
		dataMGR_enQueue_byte(&h->MGR,'0'+((uid/10)%10));
		dataMGR_enQueue_byte(&h->MGR,'0'+((uid++)%10));
		dataMGR_enQueue_byte(&h->MGR,*(id+1));
		dataMGR_enQueue_byte(&h->MGR,*(id));
//		id = (uint8_t*)&delay;
//		dataMGR_enQueue_byte(&h->MGR,*(id+3));
//		dataMGR_enQueue_byte(&h->MGR,*(id+2));
//		dataMGR_enQueue_byte(&h->MGR,*(id+1));
//		dataMGR_enQueue_byte(&h->MGR,*(id));
		for(int idx=0;idx<msg_len;idx++)
		{
			dataMGR_enQueue_byte(&h->MGR,msg[idx]);
		}
		h->evt_id++;
	}
}
#else
	void Profile_Log(Profile_CNT *h,uint8_t* msg,uint16_t msg_len,int enable);
#endif
