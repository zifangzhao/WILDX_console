#include "xe_np_boot_contract.h"

#include "stm32u5xx.h"

#include <stddef.h>

#define XE_NP_BOOT_MAIN_SRAM_BASE  0x20000000UL
#define XE_NP_BOOT_MAIN_SRAM_LIMIT 0x20270000UL
#define XE_NP_BOOT_SRAM4_BASE      0x28000000UL
#define XE_NP_BOOT_SRAM4_LIMIT     0x28004000UL

static int XE_NP_Boot_StackPointerIsValid(uint32_t stack_pointer)
{
    const int in_main_sram =
        (stack_pointer > XE_NP_BOOT_MAIN_SRAM_BASE) &&
        (stack_pointer <= XE_NP_BOOT_MAIN_SRAM_LIMIT);
    const int in_sram4 =
        (stack_pointer > XE_NP_BOOT_SRAM4_BASE) &&
        (stack_pointer <= XE_NP_BOOT_SRAM4_LIMIT);

    return (((stack_pointer & 0x7U) == 0U) && (in_main_sram || in_sram4)) ? 1 : 0;
}

uint32_t XE_NP_Boot_Crc32Update(uint32_t crc, const void *data, uint32_t size_bytes)
{
    const uint8_t *bytes = (const uint8_t *)data;

    while(size_bytes-- != 0U)
    {
        crc ^= *bytes++;
        for(uint32_t bit = 0U; bit < 8U; ++bit)
        {
            crc = (crc >> 1U) ^ ((0U - (crc & 1U)) & 0xEDB88320UL);
        }
    }
    return crc;
}

uint32_t XE_NP_Boot_Crc32(const void *data, uint32_t size_bytes)
{
    return XE_NP_Boot_Crc32Update(0xFFFFFFFFUL, data, size_bytes) ^ 0xFFFFFFFFUL;
}

static int XE_NP_Boot_VectorInSlot(uint32_t vector_sp, uint32_t vector_reset,
    uint32_t image_size, uint32_t base, uint32_t limit)
{
    uint32_t reset_address = vector_reset & ~1UL;
    uint32_t image_limit;

    if((image_size < 8U) || (image_size > (limit-base)))
    {
        return 0;
    }
    image_limit = base + image_size;
    if(XE_NP_Boot_StackPointerIsValid(vector_sp) == 0)
    {
        return 0;
    }
    if(((vector_reset & 1U) == 0U) ||
       (reset_address < base) ||
       (reset_address >= image_limit))
    {
        return 0;
    }
    return 1;
}

int XE_NP_Boot_VectorIsValid(uint32_t vector_sp, uint32_t vector_reset, uint32_t image_size)
{
    return XE_NP_Boot_VectorInSlot(vector_sp, vector_reset, image_size,
        XE_NP_BOOT_APPLICATION_BASE, XE_NP_BOOT_APPLICATION_LIMIT);
}

int XE_NP_Boot_ManifestIsValidForImage(const XE_NP_BootManifest *manifest,
    uint32_t image_id, int verify_image_crc)
{
    uint32_t base, limit;
    const uint32_t *vectors;
    uint32_t header_crc;

    if(image_id == XE_NP_BOOT_IMAGE_ID_APPLICATION) {
        base = XE_NP_BOOT_APPLICATION_BASE; limit = XE_NP_BOOT_APPLICATION_LIMIT;
    } else if(image_id == XE_NP_BOOT_IMAGE_ID_USB_SERVICE) {
        base = XE_NP_BOOT_USB_SERVICE_BASE; limit = XE_NP_BOOT_USB_SERVICE_LIMIT;
    } else { return 0; }
    vectors = (const uint32_t *)base;

    if((manifest == NULL) ||
       (manifest->magic != XE_NP_BOOT_MANIFEST_MAGIC) ||
       (manifest->format != XE_NP_BOOT_MANIFEST_FORMAT) ||
       (manifest->state != XE_NP_BOOT_MANIFEST_STATE_VALID) ||
       (manifest->image_id != image_id) ||
       (manifest->image_base != base) ||
       (manifest->min_loader_version > XE_NP_BOOT_LOADER_ABI_VERSION) ||
       (XE_NP_Boot_VectorInSlot(
            manifest->vector_sp,
            manifest->vector_reset,
            manifest->image_size, base, limit) == 0))
    {
        return 0;
    }

    header_crc = XE_NP_Boot_Crc32(
        manifest,
        (uint32_t)offsetof(XE_NP_BootManifest, header_crc32));
    if(header_crc != manifest->header_crc32)
    {
        return 0;
    }
    if((manifest->vector_sp != vectors[0]) ||
       (manifest->vector_reset != vectors[1]))
    {
        return 0;
    }
    if((verify_image_crc != 0) &&
       (XE_NP_Boot_Crc32(
            (const void *)base,
            manifest->image_size) != manifest->image_crc32))
    {
        return 0;
    }
    return 1;
}

int XE_NP_Boot_ManifestIsValid(const XE_NP_BootManifest *manifest, int verify_image_crc)
{
    return XE_NP_Boot_ManifestIsValidForImage(manifest, XE_NP_BOOT_IMAGE_ID_APPLICATION, verify_image_crc);
}

int XE_NP_Boot_UsbServiceIsValid(void)
{
    return XE_NP_Boot_ManifestIsValidForImage((const XE_NP_BootManifest *)XE_NP_BOOT_USB_MANIFEST_BASE,
        XE_NP_BOOT_IMAGE_ID_USB_SERVICE, 1);
}

int XE_NP_Boot_UsbServiceSupportsUnifiedMode(void)
{
    const XE_NP_BootManifest *manifest =
        (const XE_NP_BootManifest *)XE_NP_BOOT_USB_MANIFEST_BASE;

    return (XE_NP_Boot_ManifestIsValidForImage(
                manifest, XE_NP_BOOT_IMAGE_ID_USB_SERVICE, 1) != 0) &&
           ((manifest->flags & XE_NP_BOOT_MANIFEST_FLAG_UNIFIED_USB) != 0U);
}

int XE_NP_Boot_UsbServiceSupportsAutoApp(void)
{
    const XE_NP_BootManifest *manifest =
        (const XE_NP_BootManifest *)XE_NP_BOOT_USB_MANIFEST_BASE;
    return XE_NP_Boot_UsbServiceSupportsUnifiedMode() &&
        ((manifest->flags & XE_NP_BOOT_MANIFEST_FLAG_AUTO_APP) != 0U);
}

static void XE_NP_Boot_EnableMailboxAccess(void)
{
    RCC->AHB3ENR |= RCC_AHB3ENR_PWREN;
    RCC->APB3ENR |= RCC_APB3ENR_RTCAPBEN;
    (void)RCC->APB3ENR;
    PWR->DBPR |= PWR_DBPR_DBP;
    (void)PWR->DBPR;
    __DSB();
}

void XE_NP_Boot_RequestUsbService(void)
{
    XE_NP_Boot_EnableMailboxAccess();
    TAMP->BKP30R = XE_NP_BOOT_REQUEST_USB_SERVICE;
    TAMP->BKP31R = ~XE_NP_BOOT_REQUEST_USB_SERVICE;
    __DSB();
    __ISB();
}

void XE_NP_Boot_RequestDownload(void)
{
    XE_NP_Boot_EnableMailboxAccess();
    TAMP->BKP30R = XE_NP_BOOT_REQUEST_DOWNLOAD;
    TAMP->BKP31R = ~XE_NP_BOOT_REQUEST_DOWNLOAD;
    __DSB();
    __ISB();
}

void XE_NP_Boot_RequestApplication(void)
{
    XE_NP_Boot_EnableMailboxAccess();
    TAMP->BKP30R = XE_NP_BOOT_REQUEST_APPLICATION;
    TAMP->BKP31R = ~XE_NP_BOOT_REQUEST_APPLICATION;
    __DSB();
    __ISB();
}

void XE_NP_Boot_RequestAutomatic(void)
{
    XE_NP_Boot_EnableMailboxAccess();
    TAMP->BKP30R = XE_NP_BOOT_REQUEST_AUTOMATIC;
    TAMP->BKP31R = ~XE_NP_BOOT_REQUEST_AUTOMATIC;
    __DSB();
    __ISB();
}

void XE_NP_Boot_RequestMsc(int writable)
{
    uint32_t request = writable ? XE_NP_BOOT_REQUEST_MSC_RW : XE_NP_BOOT_REQUEST_MSC_RO;
    XE_NP_Boot_EnableMailboxAccess();
    TAMP->BKP30R = request;
    TAMP->BKP31R = ~request;
    __DSB(); __ISB();
}

void XE_NP_Boot_RequestUsbUpdate(void)
{
    XE_NP_Boot_EnableMailboxAccess();
    TAMP->BKP30R = XE_NP_BOOT_REQUEST_MAGIC;
    TAMP->BKP31R = XE_NP_BOOT_REQUEST_COMPLEMENT;
    __DSB();
    __ISB();
}

uint32_t XE_NP_Boot_ConsumeRequest(void)
{
    uint32_t requested = XE_NP_BOOT_ACTION_AUTOMATIC;

    XE_NP_Boot_EnableMailboxAccess();
    /* Only implicit startup uses the no-host window. Explicit download,
     * streaming and updater requests must never silently enter the APP. */
    if(TAMP->BKP31R == ~TAMP->BKP30R) {
        if(TAMP->BKP30R == XE_NP_BOOT_REQUEST_APPLICATION) { requested = XE_NP_BOOT_ACTION_APPLICATION; }
        else if(TAMP->BKP30R == XE_NP_BOOT_REQUEST_AUTOMATIC) { requested = XE_NP_BOOT_ACTION_AUTOMATIC; }
        else if(TAMP->BKP30R == XE_NP_BOOT_REQUEST_MAGIC) { requested = XE_NP_BOOT_ACTION_UPDATE; }
        else if(TAMP->BKP30R == XE_NP_BOOT_REQUEST_DOWNLOAD) { requested = XE_NP_BOOT_ACTION_DOWNLOAD; }
        else if(TAMP->BKP30R == XE_NP_BOOT_REQUEST_USB_SERVICE) { requested = XE_NP_BOOT_ACTION_USB_SERVICE; }
        else if(TAMP->BKP30R == XE_NP_BOOT_REQUEST_MSC_RO) { requested = XE_NP_BOOT_ACTION_MSC_RO; }
        else if(TAMP->BKP30R == XE_NP_BOOT_REQUEST_MSC_RW) { requested = XE_NP_BOOT_ACTION_MSC_RW; }
    }
    TAMP->BKP30R = 0U;
    TAMP->BKP31R = 0U;
    __DSB();
    return requested;
}

int XE_NP_Boot_ConsumeUsbUpdateRequest(void)
{
    return XE_NP_Boot_ConsumeRequest() == XE_NP_BOOT_ACTION_UPDATE;
}

static void XE_NP_Boot_JumpToImage(uint32_t base)
{
    typedef void (*XE_NP_BootEntry)(void);
    const uint32_t *vectors = (const uint32_t *)base;
    const uint32_t app_stack_pointer = vectors[0];
    XE_NP_BootEntry entry = (XE_NP_BootEntry)vectors[1];

    __disable_irq();
    SysTick->CTRL = 0U;
    SysTick->LOAD = 0U;
    SysTick->VAL = 0U;
    for(uint32_t index = 0U; index < 16U; ++index)
    {
        NVIC->ICER[index] = 0xFFFFFFFFUL;
        NVIC->ICPR[index] = 0xFFFFFFFFUL;
    }
    SCB->ICSR = SCB_ICSR_PENDSTCLR_Msk | SCB_ICSR_PENDSVCLR_Msk;
    __set_BASEPRI(0U);
    __set_FAULTMASK(0U);
    __set_CONTROL(0U);
    __set_PSP(0U);
    SCB->VTOR = base;
    __set_MSP(app_stack_pointer);
    __DSB();
    __ISB();

    /* PRIMASK survives a direct branch. Restore the reset state only after all
     * interrupt sources are disabled and pending exceptions are cleared. */
    __enable_irq();
    entry();
    for(;;)
    {
    }
}

void XE_NP_Boot_JumpToApplication(void) { XE_NP_Boot_JumpToImage(XE_NP_BOOT_APPLICATION_BASE); }
void XE_NP_Boot_JumpToUsbService(void) { XE_NP_Boot_JumpToImage(XE_NP_BOOT_USB_SERVICE_BASE); }
