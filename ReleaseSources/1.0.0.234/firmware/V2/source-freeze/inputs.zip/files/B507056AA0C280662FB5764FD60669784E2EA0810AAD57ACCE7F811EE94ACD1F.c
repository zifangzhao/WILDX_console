#include "xe_np_imu_grid_batch.h"
#include <string.h>

void XE_NP_ImuGridBatch_Reset(XE_NP_ImuGridBatch *b,uint32_t generation)
{
    memset(b,0,sizeof(*b));
    b->generation=generation;
}

int XE_NP_ImuGridBatch_Next(XE_NP_ImuGridBatch *b,XE_NP_ImuGridQueue *q,
                            uint8_t *out,size_t capacity,size_t *bytes,int flush)
{
    if(bytes)*bytes=0U;
    if(!b || !q || !out || !bytes || !b->generation || b->fault ||
       capacity<NP_IMU_GRID_MAX_BYTES ||
       np_imu_grid_overlap(out,capacity,b,sizeof(*b)) ||
       np_imu_grid_overlap(out,capacity,q,sizeof(*q)))return -1;
    b->dropped=q->dropped;
    for(unsigned inspected=0U;inspected<=NP_IMU_GRID_MAX_SLOTS;inspected++) {
        XE_NP_ImuGridSlot s;
        if(b->active && b->header.slot_count==NP_IMU_GRID_MAX_SLOTS)break;
        if(b->has_pending){s=b->pending;b->has_pending=0U;}
        else if(!XE_NP_ImuGridQueue_Pop(q,&s))break;
        /* Invalid order or unrepresentable final ordinal: preserve the popped
         * sample in pending for diagnostics, fail locally, never stop NP. */
        if(s.ordinal==UINT64_MAX || (b->has_last && s.ordinal<=b->last_ordinal)){
            b->pending=s;b->has_pending=1U;b->fault=1U;return -1;
        }
        if(b->active && s.ordinal-b->header.first_slot>=NP_IMU_GRID_MAX_SLOTS){
            b->pending=s;b->has_pending=1U;break;
        }
        if(!b->active){
            memset(&b->header,0,sizeof(b->header));
            b->header.first_slot=s.ordinal;
            b->header.capture_generation=b->generation;
            b->rows_count=0U;b->active=1U;
        }
        unsigned bit=(unsigned)(s.ordinal-b->header.first_slot);
        uint16_t mask=(uint16_t)(1U<<bit);
        b->header.slot_count=(uint16_t)(bit+1U);
        b->header.observed_mask|=mask;
        if(s.flags&XE_NP_IMU_GRID_AG_VALID)b->header.ag_valid|=mask;
        if(s.flags&XE_NP_IMU_GRID_MAG_VALID)b->header.mag_valid|=mask;
        if(s.flags&XE_NP_IMU_GRID_AG_REPEAT)b->header.ag_repeat|=mask;
        if(s.flags&XE_NP_IMU_GRID_MAG_REPEAT)b->header.mag_repeat|=mask;
        if(s.flags&XE_NP_IMU_GRID_ERROR)b->header.error_mask|=mask;
        memcpy(b->rows[b->rows_count++],s.values,sizeof(s.values));
        b->last_ordinal=s.ordinal;b->has_last=1U;
    }
    if(!b->active || (!flush && !b->has_pending &&
                       b->header.slot_count<NP_IMU_GRID_MAX_SLOTS))return 0;
    *bytes=np_imu_grid_pack(out,capacity,&b->header,
                            (const int32_t (*)[9])b->rows,b->rows_count);
    if(!*bytes){b->fault=1U;return -1;}
    b->active=0U;b->rows_count=0U;
    return 1;
}
