#ifndef XE_NP_NP2_STAGE_LONG_NODES_H
#define XE_NP_NP2_STAGE_LONG_NODES_H
#include "xe_np_np2_stage_long_window.h"
#include "stm32u5xx_hal.h"
#include "stm32u5xx_hal_sd_ex.h"

/* Descriptor arena for a bounded, open-ended CMD25 host data phase. Future
 * RUs remain ABR=0 until their exact SRAM contents are ready. */
int XE_Np2StageLong_BuildNodes(const XE_Np2StageLongWindow *window,
    const uint32_t physical_ru_base[13],SD_DMALinkNodeTypeDef *nodes,
    uint32_t node_capacity,SD_DMALinkedListTypeDef *list,
    uint32_t *node_bytes,DCACHE_HandleTypeDef *cache);
int XE_Np2StageLong_PublishNodes(const XE_Np2StageLongWindow *window,
    uint32_t unit,const uint32_t physical_ru_base[13],
    SD_DMALinkNodeTypeDef *nodes,DCACHE_HandleTypeDef *cache);
#endif
