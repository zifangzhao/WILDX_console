#include "xe_np_rtc_online.h"
#if XE_NP_RTC_ENABLE
#include "xe_np_online_impl.h"
#include "xe_np_hal.h"
#include <string.h>
typedef struct {
    uint32_t generation,last_id,last_error,pc_uncertainty;
    uint8_t last_request[64];
} RtcOnline;
static RtcOnline online;
static uint32_t days(uint32_t year,uint32_t month)
{
    static const uint8_t d[12]={31,28,31,30,31,30,31,31,30,31,30,31};
    return d[month-1U]+(month==2U && (year&3U)==0U);
}
int XE_NP_RtcOnline_Utc(const XE_NP_RtcSample *s,uint64_t *out)
{
    uint32_t day=10957U;
    if(!s || !out || s->year<2000U || s->year>2099U || !s->month || s->month>12U ||
       !s->day || s->day>days(s->year,s->month) || s->hour>23U || s->minute>59U ||
       s->second>59U || s->lower_us>=1000000U)return 0;
    for(uint32_t y=2000U;y<s->year;y++)day+=365U+((y&3U)==0U);
    for(uint32_t m=1U;m<s->month;m++)day+=days(s->year,m);
    day+=s->day-1U;
    *out=(((uint64_t)day*24U+s->hour)*3600U+s->minute*60U+s->second)*1000000U+s->lower_us;
    return 1;
}
static void calendar(uint64_t epoch,XE_NP_RtcSample *s,uint32_t *phase)
{
    uint32_t whole=(uint32_t)(epoch/1000000U),day=whole/86400U;
    uint32_t rest=whole%86400U,y=2000U,m=1U,n;
    memset(s,0,sizeof(*s));*phase=(uint32_t)(epoch%1000000U);
    s->weekday=(uint8_t)((day+3U)%7U+1U);day-=10957U;
    while(day>=(n=365U+((y&3U)==0U))){day-=n;y++;}
    while(day>=(n=days(y,m))){day-=n;m++;}
    s->year=(uint16_t)y;s->month=(uint8_t)m;s->day=(uint8_t)(day+1U);
    s->hour=(uint8_t)(rest/3600U);s->minute=(uint8_t)((rest/60U)%60U);s->second=(uint8_t)(rest%60U);
}
void XE_NP_RtcOnline_Init(void)
{
    memset(&online,0,sizeof(online));online.generation=1U;
    XE_NP_Rtc_SetTransactionBusy(0U);XE_NP_Rtc_AdmitIdle(1U);
    (void)XE_NP_Rtc_Init();XE_NP_Rtc_AdmitIdle(0U);
}
void XE_NP_RtcOnline_Invalidate(void)
{XE_NP_Rtc_Invalidate();}
int XE_NP_RtcOnline_Service(void){return XE_NP_Rtc_Service();}
uint32_t XE_NP_RtcOnline_Generation(void){return online.generation;}
uint32_t XE_NP_RtcOnline_DeclaredUncertainty(void){return online.pc_uncertainty;}
uint32_t XE_NP_RtcOnline_Uncertainty(void)
{return (XE_NP_Rtc_Status()&XE_NP_RTC_STATUS_PC_CALIBRATED)?online.pc_uncertainty:0U;}
int XE_NP_RtcOnline_Exchange(const uint8_t in[64],uint8_t out[64],
    uint32_t received,uint32_t state,uint32_t can_commit)
{
    uint32_t op,id,error=0U,status,flags,now;
    uint64_t actual=0U;XE_NP_RtcSample sample;
    if(!in || !out || xe_np_online_word(in)!=NP_ONLINE_REQUEST ||
       xe_np_online_word(in+4U)!=2U || !xe_np_online_word(in+12U) ||
       xe_np_online_word(in+60U)!=xe_np_online_crc(in))return -1;
    op=xe_np_online_word(in+8U);id=xe_np_online_word(in+12U);
    for(unsigned i=36U;i<60U;i++)if(in[i])error=1U;
    if(!op){for(unsigned i=16U;i<36U;i++)if(in[i])error=1U;}
    else if(op==1U){
        if(id==online.last_id){
            error=memcmp(in,online.last_request,64U)?6U:online.last_error;
        }else if(!error){
            uint32_t ref=xe_np_online_word(in+16U),unc=xe_np_online_word(in+28U);
            uint64_t epoch=(uint64_t)xe_np_online_word(in+20U)|((uint64_t)xe_np_online_word(in+24U)<<32U);
            now=HAL_GetTick();
            if(!can_commit)error=2U;
            else if((uint32_t)(received-ref)>10000U || (uint32_t)(now-ref)>10000U || unc<1000U || unc>500000U ||
                epoch<946684800000000ULL || epoch>=4102444800000000ULL ||
                xe_np_online_word(in+32U)!=online.generation || online.generation==UINT32_MAX)error=3U;
            else{
                uint64_t adjusted=epoch+(uint64_t)(uint32_t)(now-ref)*1000U;
                if(adjusted>=4102444800000000ULL)error=3U;
                else{
                    uint32_t phase;
                    /* Pin before the first possible write: partial failures and
                     * exact duplicate commits can never replay a mutation. */
                    memcpy(online.last_request,in,64U);online.last_id=id;
                    online.generation++;online.pc_uncertainty=unc;
                    calendar(adjusted,&sample,&phase);
                    XE_NP_Rtc_SetTransactionBusy(0U);
                    XE_NP_Rtc_Invalidate();
                    XE_NP_Rtc_AdmitIdle(1U);
                    error=XE_NP_Rtc_SetCalendarPhase(&sample,phase,online.generation)?0U:5U;
                    XE_NP_Rtc_AdmitIdle(0U);online.last_error=error;
                }
            }
        }
    }else error=4U;
    if(!op && !error && can_commit)(void)XE_NP_RtcOnline_Service();
    if(XE_NP_Rtc_Read(&sample)) (void)XE_NP_RtcOnline_Utc(&sample,&actual);
    status=XE_NP_Rtc_Status();flags=0U;
    if(status&XE_NP_RTC_STATUS_SOURCE_OK)flags|=17U;
    if(actual && (status&XE_NP_RTC_STATUS_CALENDAR_VALID))flags|=2U;else actual=0U;
    if((flags&2U) && (status&XE_NP_RTC_STATUS_PC_CALIBRATED))flags|=4U;
    if(status&XE_NP_RTC_STATUS_TRANSACTION_BUSY)flags|=8U;
    now=HAL_GetTick();
    uint32_t values[15]={NP_ONLINE_REPLY,2U,op,id,error,received,now,online.generation,
        (flags&4U)?online.pc_uncertainty:0U,!!(flags&2U),(uint32_t)actual,
        (uint32_t)(actual>>32U),state,(flags&1U)?100U:0U,flags};
    for(unsigned i=0U;i<15U;i++)xe_np_online_put(out+4U*i,values[i]);
    xe_np_online_put(out+60U,xe_np_online_crc(out));return 0;
}
int XE_NP_RtcOnline_Mailbox(const uint8_t in[64],uint8_t out[64],
    uint32_t received,uint32_t state,uint32_t can_commit)
{
    if(!in || !out || xe_np_online_word(in)!=NP_ONLINE_REQUEST)return 0;
    if(XE_NP_RtcOnline_Exchange(in,out,received,state,can_commit))memset(out,0,64U);
    return 1;
}
#else
void XE_NP_RtcOnline_Init(void){}
void XE_NP_RtcOnline_Invalidate(void){}
int XE_NP_RtcOnline_Service(void){return 0;}
int XE_NP_RtcOnline_Mailbox(const uint8_t i[64],uint8_t o[64],uint32_t r,uint32_t s,uint32_t c)
{(void)i;(void)o;(void)r;(void)s;(void)c;return 0;}
uint32_t XE_NP_RtcOnline_Generation(void){return 0U;}
uint32_t XE_NP_RtcOnline_Uncertainty(void){return 0U;}
uint32_t XE_NP_RtcOnline_DeclaredUncertainty(void){return 0U;}
int XE_NP_RtcOnline_Utc(const XE_NP_RtcSample *s,uint64_t *u){(void)s;(void)u;return 0;}
int XE_NP_RtcOnline_Exchange(const uint8_t i[64],uint8_t o[64],uint32_t r,uint32_t s,uint32_t c)
{(void)i;(void)o;(void)r;(void)s;(void)c;return -1;}
#endif
