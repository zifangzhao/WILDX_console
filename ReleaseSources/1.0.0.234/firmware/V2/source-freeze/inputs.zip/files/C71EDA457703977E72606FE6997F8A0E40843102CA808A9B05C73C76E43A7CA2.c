#include "xe_np_np2_sd_ble.h"
#if XE_NP_NP2_SD_BLE_ENABLE
#include "main.h"
#include "xe_np_np2_sd_control.h"
#include "xe_np_np2_dual_sd_app.h"
#include "xe_np_np2_preview.h"
#include "xe_np_np2_preparation.h"
#include "xe_np_np2_first_sync_sd.h"
#include "xe_np_np2_live_sd.h"
#include "xe_np_np2_capture_port.h"
#include "xe_np_np2_online.h"
#include "xe_np_np2_ble_frame.h"
#include "xe_np_np2_config.h"
#include "xe_np_np2_usb_source.h"
#include "xe_np_boot_contract.h"
#include "xe_np_ble_uart.h"
#include <string.h>
#if !XE_NP_NP2_DUAL_SD_APP_ENABLE
#error "BLE SD control requires the explicit-start catalog app"
#endif
/* Foreground consumes one complete frame per service; queued byte/tick input
 * absorbs short bursts. Overflow aborts ambiguous controls, never replaying a
 * mutation. Normal IRQ work is bounded FIFO movement, not CRC/SD/parsing. */
static uint8_t rx[67],tx[68];
static volatile uint32_t rx_ready,tx_at,tx_count;
static XE_NP_Np2BleFrame input_frame;
static volatile uint32_t rx_length,rx_received_ms;
/* CPU SRAM is only16KiB in this closed catalog profile. The existing
 * non-cacheable capture arena has spare space; do not shrink the raw ring. */
static XE_NP_BleUart np2_uart __attribute__((section("NP_CAPTURE"),aligned(4)));
static XE_NP_Np2BleFrame rescue_frame;
static XE_NP_Np2OnlineClock online_clock;
static uint32_t mode_deadline,mode_timeout;
static uint32_t start_ack_nonce,start_ack_timeout;
static uint32_t preview_poll_ms;
static uint32_t ble_initialized,clock_change_active;
#define NP2_BLE_CLOCK_DRAIN_MS 1000U
#ifndef XE_NP_NP2_BLE_CONTROL_DIAG_ENABLE
#define XE_NP_NP2_BLE_CONTROL_DIAG_ENABLE 0U
#endif
static void start_ack_observe(void)
{
    uint32_t pending=XE_NP_Np2SdControl_PendingStart();
    if(pending && pending!=start_ack_nonce){start_ack_nonce=pending;start_ack_timeout=HAL_GetTick()+5000U;}
}
#ifndef XE_NP_NP2_BLE_PREVIEW_GAP_MS
#define XE_NP_NP2_BLE_PREVIEW_GAP_MS 40U
#endif
#if XE_NP_NP2_BLE_CONTROL_DIAG_ENABLE
/* Bench-only foreground history. No byte/IRQ/capture work or extra CRC.
 * Flags: fixed frame1, dispatch2, reply queued4, wire TC8, rejected16,
 * accepted preview/no B9 reply32. Zero timestamps are not stage evidence. */
typedef struct {
    uint32_t sequence,magic,op,id,received_ms,dispatch_ms,queued_ms,wire_ms,flags;
} XE_NP_Np2ControlTraceEntry;
typedef struct {
    uint32_t magic,version,total,slots;
    XE_NP_Np2ControlTraceEntry entry[32];
} XE_NP_Np2ControlTrace;
volatile XE_NP_Np2ControlTrace xe_np_np2_control_trace
    __attribute__((aligned(32),section("NP2_CONTROL_TRACE")));
static uint32_t control_rx_sequence,control_tx_sequence;
_Static_assert(sizeof(XE_NP_Np2ControlTrace)==1168U,"Control trace ABI");
static void control_trace_receive(void)
{
    control_rx_sequence=0U;
    if(rx_length!=67U || rx[1]!=0xb9U)return;
    uint32_t sequence=xe_np_np2_control_trace.total+1U;
    if(!sequence)sequence=1U;
    volatile XE_NP_Np2ControlTraceEntry *e=&xe_np_np2_control_trace.entry[(sequence-1U)&31U];
    uint32_t words[4];memcpy(words,rx+2,sizeof(words));
    e->sequence=sequence;e->magic=words[0];e->op=words[2];e->id=words[3];
    e->received_ms=rx_received_ms;e->dispatch_ms=e->queued_ms=e->wire_ms=0U;e->flags=1U;
    xe_np_np2_control_trace.total=sequence;control_rx_sequence=sequence;
}
static void control_trace_mark(uint32_t sequence,uint32_t stage,uint32_t now)
{
    if(!sequence)return;
    volatile XE_NP_Np2ControlTraceEntry *e=&xe_np_np2_control_trace.entry[(sequence-1U)&31U];
    if(e->sequence!=sequence)return;
    if(stage==2U)e->dispatch_ms=now;
    else if(stage==4U)e->queued_ms=now;
    else if(stage==8U)e->wire_ms=now;
    e->flags|=stage;
}
#endif
#define NP2_DFU_TOKEN 0x4e324446U
#define NP2_ROM_BASE 0x0bf90000U
static void mode_mailbox_access(void)
{
    RCC->AHB3ENR|=RCC_AHB3ENR_PWREN;RCC->APB3ENR|=RCC_APB3ENR_RTCAPBEN;
    (void)RCC->APB3ENR;PWR->DBPR|=PWR_DBPR_DBP;__DSB();
}
int XE_NP_Np2SdBle_ModeAvailable(uint32_t mode)
{
    if(mode==XE_NP_NP2_MODE_UPDATE)return 1;
    if(mode==XE_NP_NP2_MODE_USB)return XE_NP_Boot_UsbServiceIsValid();
    if(mode==XE_NP_NP2_MODE_DFU){
        const uint32_t *rom=(const uint32_t *)NP2_ROM_BASE;
        /* Conservative AN2606 Rev70 table220 entry: unprotected, non-secure
         * devices only. Never modify TrustZone or readout-protection options. */
        return !(FLASH->OPTR&FLASH_OPTR_TZEN) &&
            (FLASH->OPTR&FLASH_OPTR_RDP)==OB_RDP_LEVEL_0 && !(rom[0]&7U) &&
            rom[0]>0x20000000U && rom[0]<=0x20270000U &&
            (rom[1]&1U) && rom[1]>=NP2_ROM_BASE && rom[1]<NP2_ROM_BASE+0x10000U;
    }
    return 0;
}
__attribute__((naked,noreturn)) static void enter_rom(uint32_t stack,uint32_t entry)
{__asm volatile("msr msp, r0\n bx r1");}
void XE_NP_Np2SdBle_EarlyDfu(void)
{
    mode_mailbox_access();
    int requested=TAMP->BKP28R==NP2_DFU_TOKEN && TAMP->BKP29R==~NP2_DFU_TOKEN;
    TAMP->BKP28R=0;TAMP->BKP29R=0;__DSB();
    if(!requested || !XE_NP_Np2SdBle_ModeAvailable(XE_NP_NP2_MODE_DFU))return;
    /* Reset trampoline: before SD/probes/DMA start, independently of loader
     * revisions. The ordinary APPLICATION mailbox keeps ABI4 compatibility. */
    if(HAL_RCC_DeInit()!=HAL_OK){XE_NP_Boot_RequestUsbUpdate();NVIC_SystemReset();}
    __HAL_RCC_GPIOC_CLK_ENABLE();
    GPIO_InitTypeDef pin={0};pin.Pin=GPIO_PIN_14|GPIO_PIN_15;pin.Mode=GPIO_MODE_OUTPUT_PP;
    HAL_GPIO_WritePin(GPIOC,GPIO_PIN_15,GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOC,GPIO_PIN_14,GPIO_PIN_SET);HAL_GPIO_Init(GPIOC,&pin);
    __disable_irq();SysTick->CTRL=0;SysTick->LOAD=0;SysTick->VAL=0;
    for(unsigned i=0;i<16;i++){NVIC->ICER[i]=~0U;NVIC->ICPR[i]=~0U;}
    SCB->ICSR=SCB_ICSR_PENDSTCLR_Msk|SCB_ICSR_PENDSVCLR_Msk;
    __set_BASEPRI(0);__set_FAULTMASK(0);__set_CONTROL(0);__set_PSP(0);
    SCB->VTOR=NP2_ROM_BASE;__DSB();__ISB();__enable_irq();
    enter_rom(*(const uint32_t *)NP2_ROM_BASE,*(const uint32_t *)(NP2_ROM_BASE+4U));
}
static void enter_mode(uint32_t mode)
{
    if(mode==XE_NP_NP2_MODE_USB)XE_NP_Boot_RequestUsbService();
    else if(mode==XE_NP_NP2_MODE_DFU){
        mode_mailbox_access();TAMP->BKP28R=NP2_DFU_TOKEN;TAMP->BKP29R=~NP2_DFU_TOKEN;
        XE_NP_Boot_RequestApplication();
    }else XE_NP_Boot_RequestUsbUpdate();
    __DSB();NVIC_SystemReset();
}
void XE_NP_Np2SdBle_ClockSnapshot(XE_NP_Np2OnlineClock *out)
{*out=online_clock;} /* Foreground only; no clock mutation in IRQ. */
/* Same non-cacheable SRAM3 arena as the raw ring, separately map-reserved.
 * Channel 11 is USART2 TX in this exclusive catalog build. No DMA IRQ. */
static XE_NP_Np2Preview preview __attribute__((aligned(32),section("NP_CAPTURE")));
static uint8_t preview_tx[256] __attribute__((aligned(32),section("NP_CAPTURE")));
static uint32_t preview_dma,preview_tx_deadline,preview_service_active;
uint32_t xe_np_np2_preview_active;
volatile uint32_t xe_np_np2_preview_perf[7]; /* tap calls/cycles/max, TX fragments/faults, verified/mismatched ticks */
void XE_NP_Np2SdBle_PreviewVerify(const uint8_t *packed,uint64_t first,uint32_t ticks)
{
    /* Stopped-media check ONLY: compare the retained last preview against its
     * exact SD source ticks. Never turn preview corruption into a log fault. */
    uint32_t mismatched;
    uint32_t checked=XE_NP_Np2Preview_VerifyPacked(&preview,
        xe_np_np2_dual_sd_app_mailbox.session_id,packed,first,ticks,&mismatched);
    xe_np_np2_preview_perf[5]+=checked;
    xe_np_np2_preview_perf[6]+=mismatched;
}
void XE_NP_Np2SdBle_PreviewTap(const uint8_t *raw,uint32_t bytes,uint64_t first,int pressure)
{
    uint32_t began=DWT->CYCCNT;
    XE_NP_Np2Preview_Tap(&preview,raw,bytes,first,pressure);
    xe_np_np2_preview_active=preview.active;
    uint32_t duration=DWT->CYCCNT-began;
    xe_np_np2_preview_perf[0]++;xe_np_np2_preview_perf[1]+=duration;
    if(duration>xe_np_np2_preview_perf[2])xe_np_np2_preview_perf[2]=duration;
}
static int preview_tx_busy(void)
{
    if(!preview_dma)return 0;
    uint32_t status=GPDMA1_Channel11->CSR;
    if(!(status&(DMA_CSR_TCF|DMA_CSR_DTEF|DMA_CSR_ULEF|DMA_CSR_USEF)) &&
       (int32_t)(HAL_GetTick()-preview_tx_deadline)<0)return 1;
    USART2->CR3&=~USART_CR3_DMAT;
    /* A failed preview never resets a capture DMA channel or blocks Stop. */
    if(!(status&DMA_CSR_TCF)){
        GPDMA1_Channel11->CCR|=DMA_CCR_SUSP;
        preview.streaming=preview.ready=preview.active=xe_np_np2_preview_active=0;
        xe_np_np2_preview_perf[4]++;
    }
    if(GPDMA1_Channel11->CCR&DMA_CCR_EN){
        if(!(GPDMA1_Channel11->CSR&DMA_CSR_SUSPF)){
            /* Quarantine TX DMA if suspension itself stalls. DMAT is already
             * off; byte-IRQ command replies remain available. Never wait. */
            preview.streaming=preview.ready=preview.active=xe_np_np2_preview_active=0;
            preview_dma=preview_service_active=0;return 0;
        }
    }
    GPDMA1_Channel11->CCR=DMA_CCR_RESET;
#if XE_NP_NP2_BLE_PREVIEW_GAP_MS
    /* Reuse the timeout timestamp as the last DMA-retirement tick while idle.
     * Only preview waits for module drain; control/rescue never consult it. */
    preview_tx_deadline=HAL_GetTick();
#endif
    preview_dma=0;preview_service_active=preview.active|preview.ready;return 0;
}
static void preview_send(void)
{
    if(!preview.ready || !(USART2->ISR&USART_ISR_TC) || (GPDMA1_Channel11->CCR&DMA_CCR_EN))return;
#if XE_NP_NP2_BLE_PREVIEW_GAP_MS
    if(HAL_GetTick()-preview_tx_deadline<XE_NP_NP2_BLE_PREVIEW_GAP_MS)return;
#endif
    /* The main capture startup resets GPDMA1. Program the owned TX channel
     * per fragment, AFTER that reset; no HAL polling or byte-TXE interrupts. */
    preview_tx[0]=0xad;preview_tx[1]=0xba;
    if(!XE_NP_Np2Preview_Fragment(&preview,preview_tx+2))return;
    preview_tx[226]=preview_tx[227]=0xda;
    GPDMA1_Channel11->CCR=DMA_CCR_RESET;
    GPDMA1_Channel11->CFCR=0x7f00U;
    GPDMA1_Channel11->CTR1=DMA_CTR1_SINC|DMA_CTR1_DAP;
    GPDMA1_Channel11->CTR2=DMA_CTR2_DREQ|GPDMA1_REQUEST_USART2_TX;
    GPDMA1_Channel11->CBR1=228U;
    GPDMA1_Channel11->CSAR=(uint32_t)preview_tx;
    GPDMA1_Channel11->CDAR=(uint32_t)&USART2->TDR;
    GPDMA1_Channel11->CLLR=0;
    __DMB();USART2->CR3|=USART_CR3_DMAT;
    preview_dma=1;preview_tx_deadline=HAL_GetTick()+100;
    GPDMA1_Channel11->CCR=DMA_CCR_EN;
    xe_np_np2_preview_perf[3]++;
}
void XE_NP_Np2SdBle_Reclock(void)
{
    /* An acquired preparation fence owns re-enable, including RCC failure. */
    if(clock_change_active)return;
    /* Called only at idle startup/rate transition, after the prior ACK drains.
     * Use the selected HSE-derived kernel, not the possibly divided APB bus. */
    USART2->CR1=0U;
    USART2->BRR=(HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_USART2)+57600U)/115200U;
    USART2->ICR=USART_ICR_ORECF|USART_ICR_FECF|USART_ICR_NECF;
    USART2->RQR=USART_RQR_RXFRQ;
    input_frame.at=0U;
    rescue_frame.at=0U;
    XE_NP_BleUart_Configure();
}
static int clock_change_preparing(void)
{
    const volatile XE_NP_Np2DualSdAppMailbox *a=&xe_np_np2_dual_sd_app_mailbox;
    uint32_t start=a->state==XE_NP_NP2_DUAL_SD_PREPARING && !a->error && !a->command_error &&
        a->command==XE_NP_NP2_DUAL_SD_CMD_START && a->key==XE_NP_NP2_DUAL_SD_START_KEY &&
        a->nonce && a->accepted_nonce==a->nonce;
#if XE_NP_NP2_PREPARATION_ENABLE
    uint32_t preparation=XE_NP_Np2Preparation_ClockPending() && !a->error && !a->command_error &&
        a->command==XE_NP_NP2_DUAL_SD_CMD_NONE &&
        (a->state==XE_NP_NP2_DUAL_SD_IDLE || a->state==XE_NP_NP2_DUAL_SD_COMPLETE ||
         a->state==XE_NP_NP2_DUAL_SD_CANCELLED) &&
        !XE_NP_Np2UsbSource_IsBusy() && !XE_NP_Np2UsbSource_IsReady();
#else
    uint32_t preparation=0U;
#endif
    return !__get_IPSR() && !__get_PRIMASK() && !__get_BASEPRI() &&
        (SysTick->CTRL&(SysTick_CTRL_ENABLE_Msk|SysTick_CTRL_TICKINT_Msk))==
            (SysTick_CTRL_ENABLE_Msk|SysTick_CTRL_TICKINT_Msk) &&
        a->magic==XE_NP_NP2_DUAL_SD_APP_MAGIC &&
        (start || (preparation && !XE_NP_Np2SdControl_PendingStart())) &&
        !XE_NP_Np2SdControl_PendingMode() &&
        !XE_NP_Np2CapturePort_Armed() && !(RCC->CFGR1&RCC_CFGR1_MCOSEL) &&
        !(PSSI->CR&PSSI_CR_ENABLE) && !(SPI2->CR1&SPI_CR1_SPE) &&
        !((GPDMA1_Channel9->CCR|GPDMA1_Channel12->CCR|GPDMA1_Channel14->CCR)&DMA_CCR_EN) &&
        !SDMMC1->IDMACTRL && !(SDMMC1->DCTRL&SDMMC_DCTRL_DTEN) &&
        !(SDMMC1->STA&(SDMMC_STA_CPSMACT|SDMMC_STA_DPSMACT|SDMMC_STA_BUSYD0));
}
static int clock_change_quiet(void)
{
    uint32_t now=HAL_GetTick();
    return !preview_dma && !(GPDMA1_Channel11->CCR&DMA_CCR_EN) &&
        !(USART2->CR3&(USART_CR3_DMAT|USART_CR3_TXFTIE)) &&
        tx_at==tx_count && (USART2->ISR&USART_ISR_TC) &&
        !rx_ready && np2_uart.rx.head==np2_uart.rx.tail && !np2_uart.rx.fault &&
        (!input_frame.at || XE_NP_Np2BleFrame_Expired(&input_frame,now)) &&
        (!rescue_frame.at || XE_NP_Np2BleFrame_Expired(&rescue_frame,now)) &&
        !(USART2->ISR&(USART_ISR_PE|USART_ISR_FE|USART_ISR_NE|USART_ISR_ORE|
            USART_ISR_RTOF|USART_ISR_RXNE_RXFNE|USART_ISR_BUSY)) &&
        !NVIC_GetPendingIRQ(USART2_IRQn);
}
int XE_NP_Np2SdBle_IdleQuiet(void)
{
    return ble_initialized && !clock_change_active && !start_ack_nonce &&
        !XE_NP_Np2SdControl_PendingStart() && !XE_NP_Np2SdControl_PendingMode() &&
        !preview_dma && !preview_service_active && !xe_np_np2_preview_active &&
        !preview.active && !preview.ready && !preview.streaming &&
        NVIC_GetEnableIRQ(USART2_IRQn) && (USART2->CR1&USART_CR1_UE) &&
        clock_change_quiet();
}
#if XE_NP_NP2_PREPARATION_ENABLE
int XE_NP_Np2Preparation_SdClockReady(void)
{
    const volatile XE_NP_Np2DualSdAppMailbox *a=&xe_np_np2_dual_sd_app_mailbox;
    return XE_NP_Np2SdBle_IdleQuiet() && a->magic==XE_NP_NP2_DUAL_SD_APP_MAGIC &&
        !a->error && !a->command_error && a->command==XE_NP_NP2_DUAL_SD_CMD_NONE &&
        (a->state==XE_NP_NP2_DUAL_SD_IDLE || a->state==XE_NP_NP2_DUAL_SD_COMPLETE ||
         a->state==XE_NP_NP2_DUAL_SD_CANCELLED) && !XE_NP_Np2UsbSource_IsBusy() &&
        !XE_NP_Np2UsbSource_IsReady() && !XE_NP_Np2CapturePort_Armed() &&
        !(RCC->CFGR1&RCC_CFGR1_MCOSEL) && !(PSSI->CR&PSSI_CR_ENABLE) &&
        !(SPI2->CR1&SPI_CR1_SPE) &&
        !((GPDMA1_Channel9->CCR|GPDMA1_Channel12->CCR|GPDMA1_Channel14->CCR)&DMA_CCR_EN) &&
        !SDMMC1->IDMACTRL && !(SDMMC1->DCTRL&SDMMC_DCTRL_DTEN) &&
        !(SDMMC1->STA&(SDMMC_STA_CPSMACT|SDMMC_STA_DPSMACT|SDMMC_STA_BUSYD0));
}
int XE_NP_Np2Preparation_SdClock(uint32_t mask,uint32_t hz)
{
    if(!XE_NP_Np2Preparation_SdClockReady() || !XE_NP_Np2LiveSd_SupportsProfile(mask,hz) ||
       XE_NP_Np2LiveSd_RetireStoppedTailForPreparation())return -1;
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
    return XE_NP_Board_InitNp2OverflowMemoryProfile(hz,mask);
#else
    return XE_NP_Board_SetNp2SampleRateProfile(hz,mask);
#endif
}
#endif
int XE_NP_Np2SdBle_BeginClockChange(void)
{
    /* Cold boot selects its clock before Init; it owns no BLE UART yet. */
    if(!ble_initialized)return 0;
    if(clock_change_active || !clock_change_preparing() ||
       !NVIC_GetEnableIRQ(USART2_IRQn) || !(USART2->CR1&USART_CR1_UE))return -1;
    uint32_t began=HAL_GetTick();
    for(;;){
        if(!clock_change_preparing() || !NVIC_GetEnableIRQ(USART2_IRQn) ||
           !(USART2->CR1&USART_CR1_UE))return -1;
        /* Never re-enter App/LiveSd or SD here. Existing pending START busy
         * gates admit read-only replies, not a second mutation or mode reset. */
        XE_NP_Np2SdBle_Service();
        if(clock_change_quiet()){
            HAL_NVIC_DisableIRQ(USART2_IRQn);__DSB();__ISB();
            if(clock_change_preparing() && clock_change_quiet()){
                /* Only the rechecked, inactive preparation boundary may drop
                 * an expired partial frame. A fresh/late byte stays with RX. */
                uint32_t now=HAL_GetTick();
                if(XE_NP_Np2BleFrame_Expired(&input_frame,now))input_frame.at=0U;
                if(XE_NP_Np2BleFrame_Expired(&rescue_frame,now))rescue_frame.at=0U;
                clock_change_active=1U;USART2->CR1=0U;__DSB();return 0;
            }
            /* A late byte/fault stays with normal RX; do not flush/replay it. */
            HAL_NVIC_EnableIRQ(USART2_IRQn);
        }
        if((uint32_t)(HAL_GetTick()-began)>=NP2_BLE_CLOCK_DRAIN_MS)return -1;
    }
}
void XE_NP_Np2SdBle_EndClockChange(void)
{
    if(!clock_change_active)return;
    /* UART stayed disabled across the clock mutator, even if it failed partway.
     * Discard ambiguous RX only; accepted commands/config state are untouched. */
    np2_uart.rx.tail=np2_uart.rx.head;np2_uart.rx.fault=0U;
    input_frame.at=rescue_frame.at=rx_ready=rx_length=rx_received_ms=0U;
    USART2->ICR=USART_ICR_PECF|USART_ICR_FECF|USART_ICR_NECF|
        USART_ICR_ORECF|USART_ICR_RTOCF|USART_ICR_IDLECF;
    USART2->RQR=USART_RQR_RXFRQ;
    SystemCoreClockUpdate(); /* RCC may have failed before refreshing its cache. */
    clock_change_active=0U;XE_NP_Np2SdBle_Reclock();
    HAL_NVIC_ClearPendingIRQ(USART2_IRQn);__DMB();HAL_NVIC_EnableIRQ(USART2_IRQn);
}
void XE_NP_Np2SdBle_Init(void)
{
    ble_initialized=clock_change_active=0U;
    RCC_PeriphCLKInitTypeDef clock={0};
    clock.PeriphClockSelection=RCC_PERIPHCLK_USART2;
    clock.Usart2ClockSelection=XE_NP_NP2_BLE_UART_CLOCK_SOURCE;
    if(HAL_RCCEx_PeriphCLKConfig(&clock)!=HAL_OK)Error_Handler();
    __HAL_RCC_USART2_CLK_ENABLE();__HAL_RCC_GPIOD_CLK_ENABLE();__HAL_RCC_GPIOA_CLK_ENABLE();
    GPIO_InitTypeDef pin={0};pin.Mode=GPIO_MODE_AF_PP;pin.Pull=GPIO_NOPULL;
    pin.Speed=GPIO_SPEED_FREQ_LOW;pin.Alternate=GPIO_AF7_USART2;
    pin.Pin=GPIO_PIN_5;HAL_GPIO_Init(GPIOD,&pin);
    /* PA15 USART2_RX is AF3; PD5 USART2_TX is AF7 (DS13633). */
    pin.Pin=GPIO_PIN_15;pin.Alternate=GPIO_AF3_USART2;HAL_GPIO_Init(GPIOA,&pin);
    HAL_GPIO_WritePin(HJ_MODE_GPIO_Port,HJ_MODE_Pin,GPIO_PIN_RESET);
    HAL_GPIO_WritePin(HJ_WAKE_GPIO_Port,HJ_WAKE_Pin,GPIO_PIN_RESET);
    USART2->CR2=0;USART2->CR3=0;USART2->PRESC=0;
    rx_ready=tx_at=tx_count=0;memset(&input_frame,0,sizeof(input_frame));
    start_ack_nonce=start_ack_timeout=0U;
#if XE_NP_NP2_BLE_CONTROL_DIAG_ENABLE
    memset((void *)&xe_np_np2_control_trace,0,sizeof(xe_np_np2_control_trace));
    xe_np_np2_control_trace.magic=0x3143424eU;
    xe_np_np2_control_trace.version=1U;xe_np_np2_control_trace.slots=32U;
    control_rx_sequence=control_tx_sequence=0U;
#endif
    memset(&np2_uart,0,sizeof(np2_uart));memset(&rescue_frame,0,sizeof(rescue_frame));
    rx_length=rx_received_ms=0;XE_NP_Np2Online_Init(&online_clock);
    memset(&preview,0,sizeof(preview));preview_service_active=preview_dma=xe_np_np2_preview_active=0;
    preview_poll_ms=HAL_GetTick()-1U;
#if XE_NP_NP2_BLE_PREVIEW_GAP_MS
    preview_tx_deadline=HAL_GetTick();
#endif
    memset((void *)xe_np_np2_preview_perf,0,sizeof(xe_np_np2_preview_perf));
    __HAL_RCC_GPDMA1_CLK_ENABLE();HAL_NVIC_DisableIRQ(GPDMA1_Channel11_IRQn);
    XE_NP_Np2SdControl_Init();XE_NP_Np2SdBle_Reclock();
    HAL_NVIC_SetPriority(USART2_IRQn,7U,0U);HAL_NVIC_ClearPendingIRQ(USART2_IRQn);
    HAL_NVIC_EnableIRQ(USART2_IRQn);
    ble_initialized=1U;
}
static void np2_rescue_byte(uint8_t byte,uint32_t tick)
{
    /* Only the explicit boundary rescue remains IRQ-visible, even if the
     * ordinary RX ring is full or foreground stalls. Never inspect inside a
     * valid B9 payload. UART IRQ must execute; not a hardware-reset guarantee. */
    if(XE_NP_Np2BleFrame_Feed(&rescue_frame,byte,tick)==4U){
        XE_NP_Boot_RequestApplication();NVIC_SystemReset();
    }
}
void XE_NP_Np2SdBle_Irq(void)
{
    if(XE_NP_BleUart_RxIrq(&np2_uart,np2_rescue_byte))rescue_frame.at=0U;
    XE_NP_BleUart_TxIrq(tx,&tx_at,tx_count);
}
static void np2_rx_service(void)
{
    if(XE_NP_BleUart_RecoverRx(&np2_uart)){
        input_frame.at=rx_ready=0U;return;
    }
    uint8_t byte;uint32_t tick;
    for(unsigned budget=0;budget<sizeof(rx) && !rx_ready &&
        np_ble_uart_rx_pop(&np2_uart.rx,&byte,&tick,0U);budget++){
        uint32_t length=XE_NP_Np2BleFrame_Feed(&input_frame,byte,tick);
        if(length && length!=4U){
            memcpy(rx,input_frame.data,length);rx_length=length;rx_received_ms=tick;
#if XE_NP_NP2_BLE_CONTROL_DIAG_ENABLE
            control_trace_receive();
#endif
            __DMB();rx_ready=1U;
        }
    }
}
int XE_NP_Np2SdBle_CommandReady(void)
{
    /* Only START may change the UART clock. TC can still be set immediately
     * after preview DMA is armed; wait for foreground ownership retirement.
     * STOP must never wait for TX. */
    return xe_np_np2_dual_sd_app_mailbox.command!=XE_NP_NP2_DUAL_SD_CMD_START ||
        (!preview_dma && tx_at==tx_count && (USART2->ISR&USART_ISR_TC));
}
void XE_NP_Np2SdBle_Service(void)
{
#if XE_NP_NP2_BLE_CONTROL_DIAG_ENABLE
    if(control_tx_sequence && tx_at==tx_count && (USART2->ISR&USART_ISR_TC)){
        control_trace_mark(control_tx_sequence,8U,HAL_GetTick());control_tx_sequence=0U;
    }
#endif
    if(start_ack_nonce){
        if(XE_NP_Np2SdControl_PendingStart()!=start_ack_nonce)start_ack_nonce=0U;
        else if((int32_t)(HAL_GetTick()-start_ack_timeout)>=0){
            /* Cancel before CommandReady can admit a late START. Retain the
             * response bytes; this neither truncates TX nor repairs UART. */
            XE_NP_Np2SdControl_CancelStart(start_ack_nonce);start_ack_nonce=0U;
        }
    }
    /* Disabled preview preserves the old no-RX fast return: no timer,
     * peripheral access, cache maintenance or DMA polling in this case. */
    uint32_t mode=XE_NP_Np2SdControl_PendingMode();
    if(mode){
        uint32_t now=HAL_GetTick();
        /* Same bounded handoff as V1: no surprise reset after a stalled ACK
         * eventually drains. This cancels the request, not a UART repair. */
        if((int32_t)(now-mode_timeout)>=0)XE_NP_Np2SdControl_CancelMode();
        else if((int32_t)(now-mode_deadline)>=0 && !preview_tx_busy() &&
           tx_at==tx_count && (USART2->ISR&USART_ISR_TC))enter_mode(XE_NP_Np2SdControl_TakeMode());
        return;
    }
    if(!rx_ready && np2_uart.rx.head==np2_uart.rx.tail && !np2_uart.rx.fault){
        if(!preview_service_active)return;
        /* Preview alone needs millisecond deadlines, not capture-rate polls.
         * RX/faults and the START/mode deadlines above always bypass this gate.
         * DMA ownership still retires only after the actual hardware flags. */
        if(xe_np_np2_dual_sd_app_mailbox.command!=XE_NP_NP2_DUAL_SD_CMD_START){
            uint32_t now=HAL_GetTick();
            if(now==preview_poll_ms)return;
            preview_poll_ms=now;
        }
    }
    np2_rx_service();
    if(preview.active && ((int32_t)(HAL_GetTick()-(preview.streaming?preview.lease:preview.deadline))>=0 ||
       xe_np_np2_dual_sd_app_mailbox.state!=XE_NP_NP2_DUAL_SD_RECORDING)){
        XE_NP_Np2Preview_Drop(&preview,5);xe_np_np2_preview_active=0;
        preview_service_active=preview.active|preview.ready|preview_dma;
    }
    if(preview_tx_busy() || tx_at!=tx_count || !(USART2->ISR&USART_ISR_TC))return;
    if(!rx_ready){if(np2_uart.rx.head==np2_uart.rx.tail)preview_send();return;}
#if XE_NP_NP2_SD_IDLE_HCLK_TEST
    /* One complete command, not the acquisition/no-RX service hot path. */
    XE_NP_Np2DualSdApp_WakeClock();
#endif
#if XE_NP_NP2_BLE_CONTROL_DIAG_ENABLE
    control_trace_mark(control_rx_sequence,2U,HAL_GetTick());
#endif
    if(rx[1]==0xb8U){
        uint32_t state=xe_np_np2_dual_sd_app_mailbox.state;
        uint32_t busy=xe_np_np2_dual_sd_app_mailbox.command!=XE_NP_NP2_DUAL_SD_CMD_NONE ||
            state==XE_NP_NP2_DUAL_SD_PREPARING || state==XE_NP_NP2_DUAL_SD_ARMED ||
            state==XE_NP_NP2_DUAL_SD_RECORDING || state==XE_NP_NP2_DUAL_SD_FINALIZING;
        const uint32_t uid[3]={HAL_GetUIDw0(),HAL_GetUIDw1(),HAL_GetUIDw2()};
#if XE_NP_NP2_FIRST_SYNC_ENABLE
        if(XE_NP_Np2FirstSyncSd_Exchange(rx+2,tx+2)){
            start_ack_observe();
            tx[0]=0xadU;tx[1]=0xb8U;tx[66]=tx[67]=0xdaU;
            tx_at=0U;tx_count=68U;__DMB();USART2->CR3|=USART_CR3_TXFTIE;
            __DMB();rx_ready=0U;return;
        }
#endif
#if XE_NP_NP2_PREPARATION_ENABLE
        if(np_prep_get(rx+2)==NP_PREP_REQUEST_MAGIC)
            XE_NP_Np2Preparation_Exchange(N2C_BLE,NP_PREP_SD,rx+2,busy,
                XE_NP_Np2DualSdApp_ProfileMask(),xe_np_np2_dual_sd_app_mailbox.sample_hz,uid,tx+2);
        else
#endif
        XE_NP_Np2Config_Exchange(N2C_BLE,rx+2,HAL_GetTick(),
            busy|XE_NP_Np2Preparation_ConfigBusy(),
            XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES?7U:XE_NP_NP2_LIVE_SD_PROBE_MASK,uid,tx+2);
        /* Configuration staging must not renew START/mode deadlines. */
        tx[0]=0xadU;tx[1]=0xb8U;tx[66]=tx[67]=0xdaU;
        tx_at=0U;tx_count=68U;__DMB();USART2->CR3|=USART_CR3_TXFTIE;
        __DMB();rx_ready=0U;return;
    }
    if(rx[1]==0x82U){
        /* Normal WILD handshake discovers V2; never fabricate CE64 sync success.
         * Return the ordinary read-only status using an internally valid request. */
        if(rx[2]!=0x81U || rx[3] || rx[4]){rx_ready=0;return;}
        uint8_t request[64]={0};
        uint32_t words[4]={XE_NP_NP2_SD_CONTROL_REQUEST,2,0,1};
        memcpy(request,words,sizeof(words));
        uint32_t crc=~0U;
        for(unsigned i=0;i<60;i++){crc^=request[i];for(unsigned b=0;b<8;b++)crc=(crc>>1)^((0U-(crc&1U))&0xedb88320U);}
        crc=~crc;memcpy(request+60,&crc,4);
        XE_NP_Np2SdControl_Exchange(request,tx+2);
        goto reply;
    }
    if(XE_NP_Np2Online_Exchange(&online_clock,rx+2,tx+2,rx_received_ms,HAL_GetTick(),
       xe_np_np2_dual_sd_app_mailbox.command==XE_NP_NP2_DUAL_SD_CMD_START?
         XE_NP_NP2_DUAL_SD_PREPARING:xe_np_np2_dual_sd_app_mailbox.state)==0)goto reply;
    /* Control always wins over the next ~20-ms preview fragment. */
    if(XE_NP_Np2Preview_Request(&preview,rx+2,xe_np_np2_dual_sd_app_mailbox.session_id,
       xe_np_np2_dual_sd_app_mailbox.sample_hz,
       xe_np_np2_dual_sd_app_mailbox.state==XE_NP_NP2_DUAL_SD_RECORDING,HAL_GetTick())){
#if XE_NP_NP2_BLE_CONTROL_DIAG_ENABLE
        control_trace_mark(control_rx_sequence,32U,HAL_GetTick());
#endif
        xe_np_np2_preview_active=preview.active;
        preview_service_active=preview.active|preview.ready;__DMB();rx_ready=0;return;
    }
    if(XE_NP_Np2SdControl_Exchange(rx+2,tx+2)==0){
reply:
        /* PendingStart exists only for a successful newly queued BLE
         * op2/op4; an exact duplicate must not renew its deadline. */
        start_ack_observe();
        if(XE_NP_Np2SdControl_PendingMode()){
            uint32_t now=HAL_GetTick();mode_deadline=now+500U;mode_timeout=now+5000U;
        }
        /* Canonical CE64/V1 notification envelope; requests stay <B9 ...>.
         * The 64-byte versioned body and its control CRC are unchanged. */
        tx[0]=0xadU;tx[1]=0xb9U;tx[66]=tx[67]=0xdaU;
#if XE_NP_NP2_BLE_CONTROL_DIAG_ENABLE
        control_tx_sequence=control_rx_sequence;
        control_trace_mark(control_tx_sequence,4U,HAL_GetTick());
#endif
        tx_at=0U;tx_count=68U;__DMB();USART2->CR3|=USART_CR3_TXFTIE;
    }else{
#if XE_NP_NP2_BLE_CONTROL_DIAG_ENABLE
        control_trace_mark(control_rx_sequence,16U,HAL_GetTick());
#endif
    }
    __DMB();rx_ready=0U;
}
#endif
