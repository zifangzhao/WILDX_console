#ifndef XE_NP_NP2_STAGE_DMA_H
#define XE_NP_NP2_STAGE_DMA_H
#include <stdint.h>
#include "stm32u5xx_hal.h"

/* Opt-in, foreground-polled GPDMA14 RU handoff. A source RU remains owned by
 * acquisition until Service returns 1 for the entire 186,368-byte copy.
 * PSSI/SPI and SDMMC keep their existing, higher-priority DMA ownership. */
typedef struct {
    DMA_HandleTypeDef dma;
    uint32_t source,destination,offset,chunk_bytes;
    uint32_t copies,error,started_cycles,max_copy_cycles;
    uint32_t work_cycles,completed_elapsed_cycles,completed_work_cycles;
    uint8_t active,cpu_active;
} XE_Np2StageDma;

int XE_Np2StageDma_Init(XE_Np2StageDma *engine);
int XE_Np2StageDma_Start(XE_Np2StageDma *engine,uint32_t source,uint32_t destination);
/* 0: in flight; 1: whole RU completed; -1: hardware/ownership fault. */
int XE_Np2StageDma_Service(XE_Np2StageDma *engine);
void XE_Np2StageDma_Stop(XE_Np2StageDma *engine);
#endif
