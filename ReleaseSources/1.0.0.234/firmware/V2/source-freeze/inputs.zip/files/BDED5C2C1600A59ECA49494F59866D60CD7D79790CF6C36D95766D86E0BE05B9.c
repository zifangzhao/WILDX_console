#include "xe_np_np2_transport.h"
#include <stddef.h>
#include <string.h>

/* Private measured M33 DSP comparison. Wire bytes, guards and ABI are unchanged. */
#ifndef XE_NP_NP2_PACK_DSP_TEST
#define XE_NP_NP2_PACK_DSP_TEST 0U
#endif
#if XE_NP_NP2_PACK_DSP_TEST!=0U && XE_NP_NP2_PACK_DSP_TEST!=1U
#error "DSP packing trial must be boolean"
#endif
#if XE_NP_NP2_PACK_DSP_TEST
#if defined(__clang__) && defined(__arm__) && defined(__ARM_FEATURE_DSP)
#define pack_dot(a,b) ((uint32_t)__builtin_arm_smuad((int32_t)(a),(int32_t)(b)))
#define pack_dot_add(a,b,c) ((uint32_t)__builtin_arm_smlad((int32_t)(a),(int32_t)(b),(int32_t)(c)))
#elif defined(XE_NP_NP2_PACK_DSP_NATIVE_MODEL)
/* Exact nonnegative halfword oracle for the native boundary/byte fixture. */
static inline uint32_t pack_dot(uint32_t a,uint32_t b)
{return (a&65535U)*(b&65535U)+(a>>16U)*(b>>16U);}
static inline uint32_t pack_dot_add(uint32_t a,uint32_t b,uint32_t c)
{return pack_dot(a,b)+c;}
#else
#error "DSP trial requires M33 DSP instructions or the explicit native oracle"
#endif
#endif

_Static_assert(XE_NP_NP2_MCLK_HZ/XE_NP_NP2_FRAME_TICKS/XE_NP_NP2_FRAMES_PER_SUPERFRAME==XE_NP_NP2_SAMPLE_HZ,"NP2 sample cadence");
_Static_assert(XE_NP_NP2_CHUNK_INPUT_TICKS%(XE_NP_NP2_FRAME_TICKS*XE_NP_NP2_FRAMES_PER_SUPERFRAME)==0U,"Whole superframe geometry");
_Static_assert(XE_NP_NP2_CHUNK_INPUT_TICKS%XE_NP_NP2_PACK_INPUT_QUANTUM==0U,"Input quanta");
#if (XE_NP_NP2_SINGLE_LANE_3BIT != 0U)
_Static_assert(XE_NP_NP2_CHUNK_PACKED_BYTES*8U==XE_NP_NP2_CHUNK_INPUT_TICKS*3U,"Exact single-lane ratio");
_Static_assert(UINT64_C(18000000)*65536U/XE_NP_NP2_CHUNK_PACKED_BYTES+1U==XE_NP_NP2_DUAL_CONTAINER_BYTES_PER_SEC,"Single-lane container rate");
#else
_Static_assert(XE_NP_NP2_CHUNK_PACKED_BYTES*4U==XE_NP_NP2_CHUNK_INPUT_TICKS*3U,"Exact lossless ratio");
_Static_assert(UINT64_C(36000000)*65536U/XE_NP_NP2_CHUNK_PACKED_BYTES+1U==XE_NP_NP2_DUAL_CONTAINER_BYTES_PER_SEC,"NP2 container rate");
#endif
_Static_assert(XE_NP_NP2_CHUNK_PACKED_BYTES%32U==0U,"Destination cache alignment");

/* Two parallel pairs, then concatenate the two12-bit fields. No lookups,
 * per-bit loops or data-dependent branches in the hot path. */
static inline uint32_t pack4(uint32_t x)
{
#if XE_NP_NP2_PACK_DSP_TEST
    /* Byte fields<=63 and signed-halfword weights<=4096 cannot overflow. */
    x&=0x3F3F3F3FU;
    uint32_t even=pack_dot(x&0x00FF00FFU,0x10000001U);
    uint32_t odd=pack_dot((x>>8U)&0x00FF00FFU,0x10000001U);
    return even|(odd<<6U);
#else
    uint32_t pairs=(x&0x003F003FU)|((x>>2)&0x0FC00FC0U);
    return (pairs&0xFFFU)|((pairs>>4)&0xFFF000U);
#endif
}

int XE_NP_Np2Pack6(const uint8_t *source,uint32_t input_bytes,
                  uint8_t *destination,uint32_t capacity_bytes)
{
    uintptr_t src=(uintptr_t)source,dst=(uintptr_t)destination;
    uint32_t output_bytes=(input_bytes/4U)*3U;
    if(!source || !destination || !input_bytes ||
       input_bytes%XE_NP_NP2_PACK_INPUT_QUANTUM || ((src|dst)&3U))return XE_NP_NP2_PACK_ARGUMENT;
    if(capacity_bytes<output_bytes)return XE_NP_NP2_PACK_CAPACITY;
    if(src>UINTPTR_MAX-input_bytes || dst>UINTPTR_MAX-output_bytes ||
       (src<dst+output_bytes && dst<src+input_bytes))return XE_NP_NP2_PACK_OVERLAP;
#if defined(__clang__)
    /* Expose the alignment already checked above; keep legal memcpy accesses. */
    source=__builtin_assume_aligned(source,4U);
    destination=__builtin_assume_aligned(destination,4U);
#endif
    /* memcpy expresses legal word accesses without C effective-type aliasing.
     * Cortex-M33 O3 lowers these fixed-size copies to word loads/stores. */
    /* The validated nonzero 128-byte quantum gives an exact iteration count. */
    uint32_t remaining=input_bytes/16U;
    do {
        uint32_t a,b,c,d,out[3];
        memcpy(&a,source,4);memcpy(&b,source+4,4);
        memcpy(&c,source+8,4);memcpy(&d,source+12,4);
        a=pack4(a);b=pack4(b);c=pack4(c);d=pack4(d);
        out[0]=a|(b<<24);out[1]=(b>>8)|(c<<16);out[2]=(c>>16)|(d<<8);
        memcpy(destination,out,12);
        source+=16U;destination+=12U;
    } while(--remaining);
    return XE_NP_NP2_PACK_OK;
}

static inline uint32_t pack4shift3(uint32_t x)
{
#if XE_NP_NP2_PACK_DSP_TEST
    x=(x>>3U)&0x07070707U;
    uint32_t even=pack_dot(x&0x00FF00FFU,0x00400001U);
    return pack_dot_add((x>>8U)&0x00FF00FFU,0x02000008U,even);
#else
    uint32_t triples=(x>>3U)&0x07070707U;
    /* Compact two disjoint six-bit pairs, then join them into twelve bits. */
    triples=(triples|(triples>>5U))&0x003F003FU;
    return (triples|(triples>>10U))&0xFFFU;
#endif
}

static inline uint32_t pack4shift0(uint32_t x)
{
#if XE_NP_NP2_PACK_DSP_TEST
    x&=0x07070707U;
    uint32_t even=pack_dot(x&0x00FF00FFU,0x00400001U);
    return pack_dot_add((x>>8U)&0x00FF00FFU,0x02000008U,even);
#else
    uint32_t triples=x&0x07070707U;
    triples=(triples|(triples>>5U))&0x003F003FU;
    return (triples|(triples>>10U))&0xFFFU;
#endif
}

static int pack3shift0(const uint8_t *source,uint32_t input_bytes,
                       uint8_t *destination,uint32_t capacity_bytes)
{
    uintptr_t src=(uintptr_t)source,dst=(uintptr_t)destination;
    uint32_t output_bytes=(input_bytes/8U)*3U;
    if(!source || !destination || !input_bytes || input_bytes%128U || ((src|dst)&3U))return XE_NP_NP2_PACK_ARGUMENT;
    if(capacity_bytes<output_bytes)return XE_NP_NP2_PACK_CAPACITY;
    if(src>UINTPTR_MAX-input_bytes || dst>UINTPTR_MAX-output_bytes ||
       (src<dst+output_bytes && dst<src+input_bytes))return XE_NP_NP2_PACK_OVERLAP;
#if defined(__clang__) && !XE_NP_NP2_PACK_DSP_TEST
    /* Reuse the checked alignment for paired word loads/stores. */
    source=__builtin_assume_aligned(source,4U);
    destination=__builtin_assume_aligned(destination,4U);
#endif
    uint32_t remaining=input_bytes/32U;
    do {
        uint32_t a,b,c,d,first,carry,out[3];
        memcpy(&a,source,4U);memcpy(&b,source+4U,4U);
        memcpy(&c,source+8U,4U);memcpy(&d,source+12U,4U);
        a=pack4shift0(a);b=pack4shift0(b);c=pack4shift0(c);d=pack4shift0(d);
        first=a|(b<<12U)|(c<<24U);carry=(c>>8U)|(d<<4U);
        memcpy(&a,source+16U,4U);memcpy(&b,source+20U,4U);
        memcpy(&c,source+24U,4U);memcpy(&d,source+28U,4U);
        a=pack4shift0(a);b=pack4shift0(b);c=pack4shift0(c);d=pack4shift0(d);
        out[0]=first;out[1]=carry|(a<<16U)|(b<<28U);
        out[2]=(b>>4U)|(c<<8U)|(d<<20U);
        memcpy(destination,out,sizeof(out));
        source+=32U;destination+=12U;
    } while(--remaining);
    return XE_NP_NP2_PACK_OK;
}

int XE_NP_Np2Pack3Shift3(const uint8_t *source,uint32_t input_bytes,
                         uint8_t *destination,uint32_t capacity_bytes)
{
    uintptr_t src=(uintptr_t)source,dst=(uintptr_t)destination;
    uint32_t output_bytes=(input_bytes/8U)*3U;
    if(!source || !destination || !input_bytes || input_bytes%128U || ((src|dst)&3U))return XE_NP_NP2_PACK_ARGUMENT;
    if(capacity_bytes<output_bytes)return XE_NP_NP2_PACK_CAPACITY;
    if(src>UINTPTR_MAX-input_bytes || dst>UINTPTR_MAX-output_bytes ||
       (src<dst+output_bytes && dst<src+input_bytes))return XE_NP_NP2_PACK_OVERLAP;
#if defined(__clang__) && !XE_NP_NP2_PACK_DSP_TEST
    /* Reuse the checked alignment for paired word loads/stores. */
    source=__builtin_assume_aligned(source,4U);
    destination=__builtin_assume_aligned(destination,4U);
#endif
    /* Eight source words become three aligned destination words. Keep only
     * the first group's output/carry while calculating the second group:
     * an all-at-once p0..p7 formulation causes armclang to spill most of the
     * hot loop to the stack. */
    uint32_t remaining=input_bytes/32U;
    do {
        uint32_t a,b,c,d,first,carry,out[3];
        memcpy(&a,source,4U);memcpy(&b,source+4U,4U);
        memcpy(&c,source+8U,4U);memcpy(&d,source+12U,4U);
        a=pack4shift3(a);b=pack4shift3(b);c=pack4shift3(c);d=pack4shift3(d);
        first=a|(b<<12U)|(c<<24U);
        carry=(c>>8U)|(d<<4U);
        memcpy(&a,source+16U,4U);memcpy(&b,source+20U,4U);
        memcpy(&c,source+24U,4U);memcpy(&d,source+28U,4U);
        a=pack4shift3(a);b=pack4shift3(b);c=pack4shift3(c);d=pack4shift3(d);
        out[0]=first;
        out[1]=carry|(a<<16U)|(b<<28U);
        out[2]=(b>>4U)|(c<<8U)|(d<<20U);
        memcpy(destination,out,sizeof(out));
        source+=32U;destination+=12U;
    } while(--remaining);
    return XE_NP_NP2_PACK_OK;
}

int XE_NP_Np2PackSelectedFrom8(const uint8_t *source,uint32_t input_ticks,
                               uint8_t probe_mask,uint8_t *destination,
                               uint32_t capacity_bytes)
{
    if(probe_mask==XE_NP_NP2_PROBE_FIRST)
        return pack3shift0(source,input_ticks,destination,capacity_bytes);
    if(probe_mask==XE_NP_NP2_PROBE_SECOND)
        return XE_NP_Np2Pack3Shift3(source,input_ticks,destination,capacity_bytes);
    if(probe_mask==XE_NP_NP2_PROBE_BOTH)
        return XE_NP_Np2Pack6(source,input_ticks,destination,capacity_bytes);
    return XE_NP_NP2_PACK_ARGUMENT;
}
