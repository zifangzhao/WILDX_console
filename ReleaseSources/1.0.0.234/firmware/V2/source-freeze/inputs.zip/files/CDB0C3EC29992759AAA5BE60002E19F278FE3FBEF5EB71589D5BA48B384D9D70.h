#ifndef XE_NP_NP2_DUAL_SD_CATALOG_H
#define XE_NP_NP2_DUAL_SD_CATALOG_H

#include "xe_np_np2_dual_sd_meta.h"
#include "xe_np_np2_grid16_meta.h"

#ifndef XE_NP_NP2_SD_CATALOG_ENABLE
#define XE_NP_NP2_SD_CATALOG_ENABLE 0U
#endif
#if XE_NP_NP2_SD_CATALOG_ENABLE!=0U && XE_NP_NP2_SD_CATALOG_ENABLE!=1U
#error "BLE catalog capability must be an explicit boolean"
#endif

/* Portable stopped-time catalog opt-in; no HAL/live-writer dependency. */
#ifndef XE_NP_NP2_SD_APPEND_ORDER_TEST
#define XE_NP_NP2_SD_APPEND_ORDER_TEST 0U
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST!=0U && XE_NP_NP2_SD_APPEND_ORDER_TEST!=1U
#error "Append catalog trial must be boolean"
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
#include "xe_np_np2_sd_append.h"
#endif

#define XE_NP_NP2_DUAL_SD_FORMAT_KEY 0x3850534EU
#define XE_NP_NP2_CATALOG_FULL 65536U
#define XE_NP_NP2_CATALOG_RECOVERY 131072U
#define XE_NP_NP2_CATALOG_RECOVERABLE 262144U
#define XE_NP_NP2_CATALOG_QUARANTINABLE 524288U
/* Wire bit22 belongs to the optional BLE catalog-command capability. */
#define XE_NP_NP2_CATALOG_DEGRADED 0x00800000U
/* Bit25 is the common firmware-identity BLE capability, not catalog state. */
#define XE_NP_NP2_CATALOG_REWIND_AVAILABLE 0x04000000U
#define XE_NP_NP2_CATALOG_REWIND_KEY 0x574F324EU /* N2OW: explicitly discard unknown tail */

#if XE_NP_NP2_SD_CATALOG_ENABLE
#define XE_NP_NP2_CATALOG_DELETE_KEY 0x4C44324EU /* N2DL */
#define XE_NP_NP2_CATALOG_LAST 0x00010000U
#define XE_NP_NP2_CATALOG_DELETE_ALLOWED 0x00020000U
#define XE_NP_NP2_CATALOG_METADATA_VALID 0x00040000U
#define XE_NP_NP2_CATALOG_INCOMPLETE 0x00080000U
typedef struct {
    uint32_t token,count,next,card_blocks,cid_crc,flags;
    uint32_t last_ordinal,last_start,last_end,last_cookie;
} XE_NP_Np2DualSdCatalogInfo;
typedef struct {
    uint32_t token,count,ordinal,start,end,cookie,session,sample_hz,probe_mask,flags;
} XE_NP_Np2DualSdCatalogEntry;
typedef struct {uint32_t token,count,ordinal,start,end,cookie;} XE_NP_Np2DualSdCatalogDelete;
uint32_t XE_NP_Np2DualSdCatalog_Reserved(void);
int XE_NP_Np2DualSdCatalog_Info(XE_NP_Np2DualSdCatalogInfo *out);
int XE_NP_Np2DualSdCatalog_Entry(uint32_t token,uint32_t count,uint32_t ordinal,
                                XE_NP_Np2DualSdCatalogEntry *out);
int XE_NP_Np2DualSdCatalog_CheckDelete(const XE_NP_Np2DualSdCatalogDelete *request);
/* Journal-only removal of the last COMPLETE entry. Incomplete/unknown entries
 * remain read-only; future recording may overwrite the explicitly removed tail. */
int XE_NP_Np2DualSdCatalog_DeleteLast(const XE_NP_Np2DualSdCatalogDelete *request,uint32_t *next);
#endif

/* All callbacks are stopped-time operations. The hardware adapter must reject
 * them while PSSI or SD IDMA owns a transfer. No payload path calls this API. */
typedef struct {
    void *user;
    int (*read_sector)(void *user,uint32_t lba,uint8_t out[512]);
    int (*write_sector)(void *user,uint32_t lba,const uint8_t in[512]);
    int (*stopped_command)(void *user,uint32_t argument);
    uint32_t card_blocks;
    uint32_t cid[4];
} XE_NP_Np2DualSdCatalogIo;

int XE_NP_Np2DualSdCatalog_Bind(const XE_NP_Np2DualSdCatalogIo *io);
/* Explicitly destroys the old catalog, not the card's payload sectors. */
int XE_NP_Np2DualSdCatalog_Format(uint32_t key,const uint8_t system_sector[512]);
/* Read-only mount. Full and recovery-required are separate from I/O failure. */
int XE_NP_Np2DualSdCatalog_Mount(uint32_t *next_start_lba);
/* Read-only best-effort mount. A validated tail may be staged for append.
 * Unknown allocation keeps RECOVERY; REWIND_AVAILABLE exposes a proposed
 * discard boundary, NOT a writable front. Reserve cannot bypass RECOVERY.
 * Only explicit Reserve/Rewind may publish their respective directory change. */
int XE_NP_Np2DualSdCatalog_MountAvailable(uint32_t *next_start_lba);
/* Destructive, stopped-only opt-in: truncate the catalog to the offered prefix.
 * Future recording may overwrite ALL data at/after expected_start_lba. Mount,
 * normal Start and Recover never imply this consent. Rechecks the offer first. */
int XE_NP_Np2DualSdCatalog_Rewind(uint32_t key,uint32_t expected_start_lba,
                                 uint32_t *next_start_lba);
uint32_t XE_NP_Np2DualSdCatalog_Status(void);
/* Explicit stopped-time repair: publish a validated terminal end, or protect
 * an intact RESERVED descriptor/footer by allocating its ENTIRE declared
 * extent. Quarantine does not claim a committed sample count or change the
 * incomplete footer. Invalid/unknown bounds are never guessed or erased. */
int XE_NP_Np2DualSdCatalog_Recover(uint32_t *next_start_lba);
/* Plan the next 8-MiB AU reservation. block_count is whole four-block RUs;
 * the reservation may contain extra unwritten tail capacity. */
int XE_NP_Np2DualSdCatalog_Plan(uint32_t sample_hz,uint32_t block_count,
                               uint32_t session_id,uint32_t config_crc,
                               XE_NP_Np2DualSdMeta *meta);
/* Explicit closed dual20/30 or triple15/20 profile; legacy Plan remains mask3. */
int XE_NP_Np2DualSdCatalog_PlanProfile(uint32_t probe_mask,uint32_t sample_hz,
                                      uint32_t block_count,uint32_t session_id,
                                      uint32_t config_crc,XE_NP_Np2DualSdMeta *meta);
/* Opt-in v12: exact requested whole-RU payload, reported AU (>=1024 sectors,
 * multiple1024), full touched-AU allocation plus the existing16K guard.
 * Zero is exactly Plan's existing v11 capacity/serialization semantics. */
int XE_NP_Np2DualSdCatalog_PlanAu(uint32_t sample_hz,uint32_t block_count,
                                 uint32_t session_id,uint32_t config_crc,
                                 uint32_t au_blocks,XE_NP_Np2DualSdMeta *meta);
int XE_NP_Np2DualSdCatalog_PlanAuProfile(uint32_t probe_mask,uint32_t sample_hz,
                                        uint32_t block_count,uint32_t session_id,
                                        uint32_t config_crc,uint32_t au_blocks,
                                        XE_NP_Np2DualSdMeta *meta);
/* Private v13: same exact requested payload/whole-AU reservation as v12,
 * but the AU is the card's legacy UHS unit and no VSC semantics are asserted. */
int XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(uint32_t probe_mask,uint32_t sample_hz,
                                             uint32_t block_count,uint32_t session_id,
                                             uint32_t config_crc,uint32_t au_blocks,
                                             XE_NP_Np2DualSdMeta *meta);
#if XE_NP_NP2_SD_GRID16_ENABLE
/* blocks=0 reserves the maximum complete groups on the current card. A
 * nonzero request is an exact whole-group NP record count. */
int XE_NP_Np2DualSdCatalog_PlanGrid16(uint32_t mask,uint32_t hz,uint32_t blocks,
    uint32_t session,uint32_t config_crc,uint32_t base,uint32_t au,XE_NP_Grid16Meta *meta);
struct XE_NP_Np2ClCarrierTag;
int XE_NP_Np2DualSdCatalog_ReserveGrid16(const XE_NP_Grid16Meta *meta,
    const uint8_t configuration[2048],const struct XE_NP_Np2ClCarrierTag *cl);
/* Caller supplies only card-confirmed whole-group counts. Failed recordings
 * retain the entire reservation regardless of their confirmed prefix. */
int XE_NP_Np2DualSdCatalog_FinishGrid16(const XE_NP_Grid16Footer *footer);
#endif
/* Seal footer/descriptor/config before publishing the CE64 directory entry.
 * Publish header end, not planned capacity; an unsealed footer blocks append
 * after reset. The planned write limit remains in descriptor and RAM only. */
int XE_NP_Np2DualSdCatalog_Reserve(const XE_NP_Np2DualSdMeta *meta,
                                  const uint8_t configuration[2048]);
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
/* Explicit new-format entry; ordinary Reserve never changes its format.
 * Caller-owned carrier must outlive this reservation through finalization. */
struct XE_NP_Np2ClCarrierTag;
int XE_NP_Np2DualSdCatalog_ReserveClosedLoop(const XE_NP_Np2DualSdMeta *,
    const uint8_t configuration[2048],uint32_t append,const struct XE_NP_Np2ClCarrierTag *);
#endif

/* One stopped-time footer checkpoint after the entire source/SD queue drains.
 * Retain the write count across reset during readback, without publishing the
 * directory, releasing the reservation or claiming COMPLETE/verified data. */
int XE_NP_Np2DualSdCatalog_CheckpointWritten(uint32_t committed_blocks);
/* Caller must have stopped PSSI and drained or aborted SD. Seal the footer
 * before publishing actual committed end, also for incomplete recordings. */
int XE_NP_Np2DualSdCatalog_Finish(uint32_t state,uint32_t error,uint32_t committed_blocks);
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
/* Explicit v14 reservation. Legacy footer APIs refuse this owner. Counts
 * describe dense physical storage; COMPLETE/VERI still require caller-proven
 * full unique readback/drain respectively, never just matching counters. */
int XE_NP_Np2DualSdCatalog_ReserveAppend(const XE_NP_Np2DualSdMeta *meta,
                                        const uint8_t configuration[2048]);
int XE_NP_Np2DualSdCatalog_CheckpointAppend(const XE_NP_Np2SdAppendCounts *counts);
int XE_NP_Np2DualSdCatalog_FinishAppend(uint32_t state,uint32_t error,
                                       const XE_NP_Np2SdAppendCounts *counts);
#endif
/* Optional UTC companion at reservation+5; stopped-time, readback verified. */
int XE_NP_Np2DualSdCatalog_Time(const uint8_t sector[512]);
#if NP_FINE_COUNTER64_ENABLE
int XE_NP_Np2DualSdCatalog_FineCounter64Time(const uint8_t utc2[512],const uint8_t anchor[64],
    const uint32_t uid[3],uint64_t token);
int XE_NP_Np2DualSdCatalog_RtcTime(const uint8_t utc2[512],const uint8_t anchor[64],
    const uint8_t rtc[128],const uint32_t uid[3],uint64_t token);
#endif


#endif
