#include "xe_np_np2_first_sync_gate.h"
#if defined(XE_NP_FIRST_SYNC_GATE_NATIVE_TEST)
uint32_t test_get_primask(void);void test_disable_irq(void);void test_set_primask(uint32_t);void test_dmb(void);
#define gate_primask() test_get_primask()
#define gate_disable_irq() test_disable_irq()
#define gate_restore_irq(key) test_set_primask(key)
#define gate_dmb() test_dmb()
#elif defined(__ARMCC_VERSION) || defined(__ARM_ARCH)
#include "main.h"
#define gate_primask() __get_PRIMASK()
#define gate_disable_irq() __disable_irq()
#define gate_restore_irq(key) __set_PRIMASK(key)
#define gate_dmb() __DMB()
#else
/* Native-only existing gate tests have no IRQ owner. */
#define gate_primask() 0U
#define gate_disable_irq() ((void)0)
#define gate_restore_irq(key) ((void)(key))
#define gate_dmb() ((void)0)
#endif
#if XE_NP_NP2_FIRST_SYNC_ENABLE
static int same(const NpFirstSyncBinding *a,const NpFirstSyncBinding *b)
{
    return a && b && a->session==b->session && a->generation==b->generation &&
        a->source_epoch==b->source_epoch && a->domain==b->domain &&
        a->counter_hz==b->counter_hz && a->profile_crc==b->profile_crc &&
        a->family==b->family && a->mask==b->mask && a->ap_hz==b->ap_hz;
}
static int point(const XE_NP_Np2FirstSyncGate *s,const XE_NP_Np2FirstSyncPoint *p)
{return p && s->binding.domain && p->domain==s->binding.domain && s->binding.counter_hz;}
static void exclusions(NpFirstSyncReceipt *r)
{
    uint32_t all=r->aux_mask!=0U;
    for(unsigned i=0U;i<4U;i++)if((r->aux_mask&(1U<<i)) && !(r->aux[i].flags&NP_FIRST_AUX_EXCLUDED))all=0U;
    r->flags=(r->flags&~NP_FIRST_AUX_GATED)|(all?NP_FIRST_AUX_GATED:0U);
}
static int aux_commit_open(const XE_NP_Np2FirstSyncGate *s,const NpFirstSyncBinding *b,uint32_t bit)
{
    return s && b && s->bound && s->live && !s->frozen && same(&s->binding,b) &&
        (s->receipt.aux_mask&bit) && (s->released&bit) && !(s->aux_seen&bit);
}
int XE_NP_Np2FirstSyncGate_Begin(XE_NP_Np2FirstSyncGate *s,const NpFirstSyncBinding *b,uint8_t aux,int mapped)
{
    if(!s || !b || s->bound || s->live || b->family!=2U || !b->session || !b->generation ||
       !b->source_epoch || !b->mask || (b->mask&~7U) || !np_first_profile(b->ap_hz) ||
       (aux&~15U) || ((!b->domain)!=(!b->counter_hz)) ||
       b->counter_hz>1000000000U)return 0;
    memset(s,0,sizeof(*s));s->binding=*b;s->bound=1U;
    NpFirstSyncReceipt *r=&s->receipt;
    r->flags=(2U<<8U)|NP_FIRST_FINAL|(b->profile_crc!=UINT32_MAX?NP_FIRST_PROFILE:0U)|
        (mapped?NP_FIRST_SOURCE_CLOCK:0U);
    r->session=b->session;r->generation=b->generation;r->source_epoch=b->source_epoch;
    r->domain=b->domain;r->source_hz=b->ap_hz*1600U;r->ap_hz=b->ap_hz;
    r->counter_hz=b->counter_hz;r->profile_crc=b->profile_crc;
    r->mask=(uint8_t)b->mask;r->reference=1U;r->aux_mask=aux;r->policy=(uint8_t)(aux!=0U);
    while(!(b->mask&(1U<<(r->reference-1U))))r->reference++;
    r->reference_tick=UINT64_MAX;r->discovery_ms=r->discovery_cycles=UINT32_MAX;
    for(unsigned i=0U;i<3U;i++)if(b->mask&(1U<<i)){
        r->probes[i].first_tick=UINT64_MAX;r->probes[i].counter=UINT32_MAX;
        r->probes[i].phase=UINT16_MAX;r->probes[i].period=1600U;r->probes[i].flags=NP_FIRST_PROBE_SELECTED;
    }
    for(unsigned i=0U;i<4U;i++)if(aux&(1U<<i)){
        NpFirstSyncAux *a=&r->aux[i];a->id=(uint8_t)(i+1U);a->flags=NP_FIRST_AUX_ENABLED;
        a->release_ms=a->release_cycles=a->first_ms=a->first_cycles=UINT32_MAX;
        a->counter=UINT64_MAX;a->offset_num=INT64_MIN;
    }
    return 1;
}
int XE_NP_Np2FirstSyncGate_Open(const XE_NP_Np2FirstSyncGate *s,const NpFirstSyncBinding *b)
{return s && s->bound && s->live && same(&s->binding,b);}
void XE_NP_Np2FirstSyncGate_Invalidate(XE_NP_Np2FirstSyncGate *s)
{if(s){s->bound=0U;s->live=0U;s->staged=0U;s->imu_ready=0U;}}
int XE_NP_Np2FirstSyncGate_Stage(XE_NP_Np2FirstSyncGate *s,const NpFirstSyncBinding *b,const uint8_t *block,uint32_t bytes,const XE_NP_Np2FirstSyncPoint *p,XE_NP_Np2FirstSyncRetained retained,void *user)
{
    XE_NP_Np2FirstSync proof;
    if(!s || !s->bound || s->attempted || !p)return 0;
    if(!same(&s->binding,b)){XE_NP_Np2FirstSyncGate_Invalidate(s);return 0;}
    s->attempted=1U;s->discovered_ms=p->ms;
    if(!block || bytes!=XE_NP_NP2_FIRST_SYNC_BLOCK_BYTES ||
       np_first_u64(block+24U)!=0U || np_first_u32(block+60U)!=b->ap_hz ||
       np_first_u32(block+80U)!=b->mask ||
       !XE_NP_Np2FirstSync_Prove(block,bytes,b->mask,&proof) ||
       (retained && !retained(user)) || !s->bound || !same(&s->binding,b))return 0;
    /* p may be refreshed by the post-scan owner callback. This is discovery,
     * not receiver arm or a physical conversion timestamp. */
    s->staged_proof=proof;s->staged_point=*p;s->discovered_ms=p->ms;
    s->staged=1U;return 1;
}
int XE_NP_Np2FirstSyncGate_Commit(XE_NP_Np2FirstSyncGate *s,const NpFirstSyncBinding *b,XE_NP_Np2FirstSyncRetained retained,void *user)
{
    uint8_t wire[NP_FIRST_SYNC_BYTES];
    if(!s || !s->bound || !s->staged || !same(&s->binding,b))return 0;
    s->staged=0U;
    if((retained && !retained(user)) || !s->bound || !same(&s->binding,b))return 0;
    const XE_NP_Np2FirstSync *proof=&s->staged_proof;
    const XE_NP_Np2FirstSyncPoint *p=&s->staged_point;
    NpFirstSyncReceipt *r=&s->receipt;
    r->flags|=NP_FIRST_ALL_PORTS;r->reference=(uint8_t)(proof->reference+1U);
    r->reference_tick=proof->first_tick[proof->reference];
    for(unsigned i=0U;i<3U;i++)if(b->mask&(1U<<i)){
        r->probes[i].first_tick=proof->first_tick[i];r->probes[i].phase=proof->phase[i];
        r->probes[i].flags=NP_FIRST_PROBE_SELECTED|NP_FIRST_PROBE_FRAMED|NP_FIRST_PROBE_PHASE|NP_FIRST_PROBE_CONTINUOUS;
    }
    if(point(s,p)){r->flags|=NP_FIRST_DISCOVERY;r->discovery_ms=p->ms;r->discovery_cycles=p->cycles;}
    if(!np_first_sync_pack(wire,r) || !np_first_sync_gate_match(wire,sizeof(wire),b))return 0;
    if(!s->bound)return 0; /* IRQ invalidation cannot be undone by late proof. */
    s->live=1U;return 1;
}
int XE_NP_Np2FirstSyncGate_Prove(XE_NP_Np2FirstSyncGate *s,const NpFirstSyncBinding *b,const uint8_t *block,uint32_t bytes,const XE_NP_Np2FirstSyncPoint *p)
{
    return XE_NP_Np2FirstSyncGate_Stage(s,b,block,bytes,p,NULL,NULL) &&
        XE_NP_Np2FirstSyncGate_Commit(s,b,NULL,NULL);
}
int XE_NP_Np2FirstSyncGate_Release(XE_NP_Np2FirstSyncGate *s,const NpFirstSyncBinding *b,uint32_t id,const XE_NP_Np2FirstSyncPoint *p)
{
    if(!XE_NP_Np2FirstSyncGate_Open(s,b) || s->frozen || id<1U || id>4U || !(s->receipt.aux_mask&(1U<<(id-1U))) || (s->released&(1U<<(id-1U))))return 0;
    NpFirstSyncAux *a=&s->receipt.aux[id-1U];
    if(point(s,p)){a->flags|=NP_FIRST_AUX_RELEASE;a->release_ms=p->ms;a->release_cycles=p->cycles;}
    s->released|=(uint8_t)(1U<<(id-1U));return 1;
}
int XE_NP_Np2FirstSyncGate_RecordAux(XE_NP_Np2FirstSyncGate *s,const NpFirstSyncBinding *b,const NpFirstSyncAux *a,uint32_t proof)
{
    uint8_t wire[NP_FIRST_SYNC_BYTES];NpFirstSyncReceipt r;uint32_t bit,key;
    if(!a || a->id<1U || a->id>4U || !XE_NP_Np2FirstSyncGate_Open(s,b) || s->frozen)return 0;
    bit=1U<<(a->id-1U);
    if(!(s->receipt.aux_mask&bit) || !(s->released&bit) || (s->aux_seen&bit) ||
       ((a->flags&NP_FIRST_AUX_EXCLUDED) && !(proof&NP2_FIRST_EXCLUSION_PROVEN)) ||
       ((a->flags&NP_FIRST_AUX_SAMPLE_LOCK) && !(proof&NP2_FIRST_SAMPLE_LOCK_PROVEN)))return 0;
    r=s->receipt;r.aux[a->id-1U]=*a;
    NpFirstSyncAux *dest=&r.aux[a->id-1U];const NpFirstSyncAux *prior=&s->receipt.aux[a->id-1U];
    dest->flags=(uint8_t)((dest->flags&~NP_FIRST_AUX_RELEASE)|NP_FIRST_AUX_ENABLED|(prior->flags&NP_FIRST_AUX_RELEASE));
    dest->release_ms=prior->release_ms;dest->release_cycles=prior->release_cycles;
    exclusions(&r);
    if(!np_first_sync_pack(wire,&r))return 0;
    /* Packing/CRC may be slow.  Commit only if the startup owner and this AUX
     * slot still match after an IRQ-driven Stop, invalidation, or rebind. */
    key=gate_primask();gate_disable_irq();
    if(!aux_commit_open(s,b,bit)){gate_restore_irq(key);return 0;}
    /* Do not restore a pre-pack receipt snapshot: another AUX may have
     * committed before this short critical section. */
    s->receipt.aux[a->id-1U]=r.aux[a->id-1U];exclusions(&s->receipt);
    s->aux_seen|=(uint8_t)bit;gate_dmb();gate_restore_irq(key);return 1;
}
void XE_NP_Np2FirstSyncGate_ImuBaseline(XE_NP_Np2FirstSyncGate *s,const uint32_t q[3],uint8_t groups)
{
    if(!s || !q || !s->bound || !s->live || !(s->released&1U))return;
    memcpy(s->imu_baseline,q,sizeof(s->imu_baseline));s->imu_needed=groups&7U;
    s->imu_flushed=s->imu_ready=0U;
}
int XE_NP_Np2FirstSyncGate_AllowImu(XE_NP_Np2FirstSyncGate *s,const uint32_t q[3],uint8_t valid)
{
    if(!s || !q || !s->bound || !s->live || !(s->released&1U) || !s->imu_needed)return 0;
    if(s->imu_ready==s->imu_needed)return 1;
    for(unsigned i=0U;i<3U;i++)if((s->imu_needed&(1U<<i)) && (valid&(1U<<i))){
        uint32_t delta=q[i]-s->imu_baseline[i];
        if(!delta || delta>0x7fffffffU)continue;
        s->imu_baseline[i]=q[i];
        if(s->imu_flushed&(1U<<i))s->imu_ready|=(uint8_t)(1U<<i);
        else s->imu_flushed|=(uint8_t)(1U<<i);
    }
    return s->imu_ready==s->imu_needed;
}
int XE_NP_Np2FirstSyncGate_Freeze(XE_NP_Np2FirstSyncGate *s,const NpFirstSyncBinding *b,uint32_t now,int stop)
{
    if(!s || !same(&s->binding,b) || !s->receipt.session)return 0;
    if(stop)XE_NP_Np2FirstSyncGate_Invalidate(s);
    if(s->frozen)return 1;
    if(!stop && (!s->attempted || ((s->aux_seen&s->receipt.aux_mask)!=s->receipt.aux_mask &&
       (uint32_t)(now-s->discovered_ms)<1000U)))return 0;
    if(!np_first_sync_pack(s->frozen_wire,&s->receipt))return 0;
    s->frozen=1U;return 1;
}
const uint8_t *XE_NP_Np2FirstSyncGate_Frozen(const XE_NP_Np2FirstSyncGate *s)
{return s && s->frozen?s->frozen_wire:NULL;}
int XE_NP_Np2FirstSyncGate_Pack(const XE_NP_Np2FirstSyncGate *s,uint8_t out[NP_FIRST_SYNC_BYTES])
{return s && out && s->receipt.session && np_first_sync_pack(out,&s->receipt);}
#endif
