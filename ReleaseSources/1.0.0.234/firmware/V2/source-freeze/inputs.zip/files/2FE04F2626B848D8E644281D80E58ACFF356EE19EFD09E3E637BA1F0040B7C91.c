#include "xe_np_np2_first_sync_runtime.h"
#if XE_NP_NP2_FIRST_SYNC_ENABLE
#include "xe_np_np2_first_sync_sd.h"
#include "xe_np_np2_capture_port.h"
#include "xe_np_sensors_port.h"
#include "xe_np_usb_aux.h"
#include "main.h"
#include "xe_np_np2_sd_fine_clock.h"
#if XE_NP_NP2_SD_GRID16_ENABLE && NP_FINE_COUNTER64_ENABLE && XE_NP_NP2_DUAL_SD_APP_ENABLE && XE_NP_BOARD_SENSOR_SERVICE_ENABLE
#define XE_NP_SD_GRID16_ACTIVE 1U
#include "xe_np_np2_grid16_runtime.h"
#include "xe_np_imu_grid_timer.h"
#include "np_imu_grid_wire.h"
#else
#define XE_NP_SD_GRID16_ACTIVE 0U
#endif
#if XE_NP_GRID_ENFORCED && !XE_NP_NP2_USB_GRID_EXPERIMENT
#error Enforced USB grid requires the USB grid runtime
#endif
#if XE_NP_NP2_USB_GRID_EXPERIMENT
#if defined(XE_NP_GRID_CLOCK_CHECK_TEST) && XE_NP_GRID_CLOCK_CHECK_TEST && !XE_NP_GRID_ENFORCED && \
    (!defined(XE_NP_GRID_READY_GATE_TEST) || !XE_NP_GRID_READY_GATE_TEST)
#error Grid clock checking requires the foreground readiness gate
#endif
#if !NP_FINE_COUNTER64_ENABLE || !XE_NP_RTC_START_ENABLE || !XE_NP_V2_AUX_ENABLE || !XE_NP_BOARD_SENSOR_SERVICE_ENABLE
#error USB grid experiment requires continuous64, RTC, AUX and sensor service
#endif
#include "xe_np_imu_grid_runtime.h"
#include "xe_np_imu_grid_timer.h"
#include "xe_np_imu_grid_provider.h"
#include "xe_np_imu_grid_diag.h"
#endif
#if NP_FINE_COUNTER64_ENABLE
#include "xe_np_np2_sd_fine_clock.h"
#include "xe_np_rtc_start.h"
#endif
/* One explicitly named CPU-only workspace; the software link comparison must
 * account for it without moving any fixed neural/capture/DMA reservation. */
typedef struct {
    XE_NP_Np2FirstSyncPort port;
    XE_NP_Np2FirstSyncSdContext sd;
    NpFirstSyncBinding binding;
    uint64_t token;
    uint32_t mode,nonce,session,mask,hz;
    uint8_t active,aux_mask;
#if NP_FINE_COUNTER64_ENABLE
    XE_NP_Np2SdFinePoint64 fine;
    uint8_t fine_anchor[64];
    uint32_t features;
    uint8_t prepared,clock_mode,fine_bound,fine_anchor_valid;
#endif
} NpFirstRuntime;
#if defined(_MSC_VER)
static NpFirstRuntime runtime;
#else
static NpFirstRuntime runtime __attribute__((section("NP_FIRST_CPU"),aligned(8)));
#endif
enum {FIRST_MODE_NONE=0U,FIRST_MODE_USB=1U,FIRST_MODE_SD=2U};
static void idle(void){}
static void (*service)(void)=idle;
static void freeze_pending(void);
#if XE_NP_NP2_USB_GRID_EXPERIMENT
/* USB-only optional state. All timer/queue work is foreground; NP capture
 * never waits for this service and failure only makes AUX incomplete. */
static struct {
    XE_NP_GridRuntime capture;
    XE_NP_GridProvider provider;
    volatile uint32_t requested,frozen,selected,stop_pending,unbind_pending;
    uint32_t started,attached,fault;
} usb_grid;
#if XE_NP_GRID_STARTUP_DIAG
XE_NP_GridStartupDiag xe_np_grid_startup_diag;
void XE_NP_Np2FirstSyncRuntime_GridDiagMark(uint32_t stage)
{
    uint32_t now,key,head,tail,dropped;
    if(stage>=XE_NP_GRID_DIAG_STAGE_COUNT || xe_np_grid_startup_diag.stage[stage].valid)return;
    /* A racy empty observation may delay the diagnostic until a later pass;
     * it must not mask NP interrupts on every idle deferral. */
    if((stage==XE_NP_GRID_DIAG_OPPORTUNITY_DEFERRED ||
        stage==XE_NP_GRID_DIAG_EP82_BUSY_WITH_QUEUED ||
        stage==XE_NP_GRID_DIAG_FIRSTSYNC_BLOCKED_WITH_QUEUED ||
        stage==XE_NP_GRID_DIAG_PROVIDER_POLLED) &&
       usb_grid.capture.queue.head==usb_grid.capture.queue.tail)return;
    now=HAL_GetTick();key=__get_PRIMASK();__disable_irq();
    head=usb_grid.capture.queue.head;tail=usb_grid.capture.queue.tail;
    dropped=usb_grid.capture.queue.dropped;__set_PRIMASK(key);
    /* Distinguish a real queued backlog from an idle producer deferral. */
    if((stage==XE_NP_GRID_DIAG_OPPORTUNITY_DEFERRED ||
        stage==XE_NP_GRID_DIAG_EP82_BUSY_WITH_QUEUED ||
        stage==XE_NP_GRID_DIAG_FIRSTSYNC_BLOCKED_WITH_QUEUED ||
        stage==XE_NP_GRID_DIAG_PROVIDER_POLLED) && head==tail)return;
    XE_NP_GridDiag_Mark(&xe_np_grid_startup_diag,stage,now,head,tail,dropped);
}
#endif
static void grid_finish(void)
{
    if(usb_grid.frozen && usb_grid.selected && !usb_grid.attached)usb_grid.fault=1U;
    if(usb_grid.started){
        if(usb_grid.attached)XE_NP_GridProvider_Finish(&usb_grid.provider,0,0U);
        else {XE_NP_GridRuntime_Stop(&usb_grid.capture,0,0U);usb_grid.fault=1U;}
        usb_grid.started=0U;
    }
}
static void grid_first(uint64_t ordinal)
{
    XE_NP_Np2FirstSyncGate *gate=&runtime.port.gate;NpFirstSyncAux a={0};
    if(!runtime.active || gate->frozen || (gate->aux_seen&1U) || ordinal==UINT64_MAX ||
       !XE_NP_Np2FirstSyncGate_Open(gate,&runtime.binding))return;
    a.id=1U;a.flags=NP_FIRST_AUX_ENABLED|NP_FIRST_AUX_COUNTER;a.counter_bits=64U;a.counter=ordinal;
    a.rate_num=1250U;a.rate_den=1U;a.release_ms=a.release_cycles=a.first_ms=a.first_cycles=UINT32_MAX;
    a.offset_num=INT64_MIN;
    if(XE_NP_Np2FirstSyncGate_RecordAux(gate,&runtime.binding,&a,0U))freeze_pending();
}
static int grid_next(void *unused,uint8_t *buffer,uint32_t capacity,uint32_t *type,
    uint32_t *bytes,uint64_t *source,uint32_t draining)
{
    int result;(void)unused;
    if(usb_grid.fault || !usb_grid.selected)return 2;
    if(!usb_grid.attached)return 0;
#if XE_NP_GRID_ENFORCED || (defined(XE_NP_GRID_CLOCK_CHECK_TEST) && XE_NP_GRID_CLOCK_CHECK_TEST)
    /* Only on an admitted foreground batch, after NP service. No per-slot
     * register scan. An observed clock fault invalidates grid time, not NP. */
    if(usb_grid.started){
        if(!XE_NP_GridTimer_Qualified() ||
           !XE_NP_Np2SdFineClock_BoundQualified64(usb_grid.capture.domain,
               usb_grid.capture.generation,usb_grid.capture.epoch)){
            /* A requested stop/reset can race the foreground read; do not
             * classify its expected invalidation as a new clock fault. */
            uint32_t key=__get_PRIMASK();__disable_irq();
            if(usb_grid.started && usb_grid.attached && runtime.active && !usb_grid.stop_pending){
                XE_NP_GridRuntime_ClockFault(&usb_grid.capture);
                XE_NP_GridProvider_Finish(&usb_grid.provider,0,0U);usb_grid.started=0U;
            }
            __set_PRIMASK(key);
        }
    }
#endif
    result=XE_NP_GridProvider_Next(&usb_grid.provider,buffer,capacity,type,bytes,source,draining);
    if(result==1 && *type==6U)grid_first(*source);
    return result;
}
static void grid_complete(void *unused,uint32_t type,uint32_t delivered)
{(void)unused;if(usb_grid.attached)XE_NP_GridProvider_Complete(&usb_grid.provider,type,delivered);}
int XE_NP_Np2FirstSyncRuntime_GridAvailable(void)
{
    uint32_t sw=RCC->CFGR1&RCC_CFGR1_SWS;
    return !usb_grid.frozen && !usb_grid.started && !usb_grid.stop_pending &&
        !(RCC->APB1ENR1&RCC_APB1ENR1_TIM3EN) && !(RCC->APB1RSTR1&RCC_APB1RSTR1_TIM3RST) &&
        !NVIC_GetEnableIRQ(TIM3_IRQn) && !NVIC_GetPendingIRQ(TIM3_IRQn) &&
        !(CoreDebug->DHCSR&CoreDebug_DHCSR_C_DEBUGEN_Msk) &&
        !(DBGMCU->APB1FZR1&DBGMCU_APB1FZR1_DBG_TIM3_STOP) &&
        !(SCB->SCR&(SCB_SCR_SLEEPDEEP_Msk|SCB_SCR_SLEEPONEXIT_Msk)) &&
        (RCC->CR&RCC_CR_HSERDY) && (sw==RCC_SYSCLKSOURCE_STATUS_HSE ||
        (sw==RCC_SYSCLKSOURCE_STATUS_PLLCLK && (RCC->CR&RCC_CR_PLL1RDY) &&
         (RCC->PLL1CFGR&RCC_PLL1CFGR_PLL1SRC)==RCC_PLLSOURCE_HSE));
}
int XE_NP_Np2FirstSyncRuntime_GridSelect(uint32_t selected)
{
    if(selected>1U || usb_grid.frozen || usb_grid.started || usb_grid.stop_pending)return 0;
    if(selected && !XE_NP_Np2FirstSyncRuntime_GridAvailable())return 0;
    if(XE_NP_UsbAux_BindGrid(selected?grid_next:NULL,selected?grid_complete:NULL,NULL)!=0)return 0;
    usb_grid.requested=selected;usb_grid.unbind_pending=0U;return 1;
}
void XE_NP_Np2FirstSyncRuntime_GridFreeze(void)
{usb_grid.selected=usb_grid.requested;usb_grid.frozen=1U;usb_grid.fault=0U;usb_grid.attached=0U;}
void XE_NP_Np2FirstSyncRuntime_GridReset(void)
{
    usb_grid.requested=0U;usb_grid.unbind_pending=1U;
    if(usb_grid.started || usb_grid.frozen)usb_grid.stop_pending=1U;
}
void XE_NP_Np2FirstSyncRuntime_GridService(uint32_t np_idle)
{
    if(usb_grid.stop_pending){grid_finish();usb_grid.stop_pending=0U;}
    if(usb_grid.unbind_pending){
        /* An EP0 SELECT can preempt foreground. Recheck and retire the old
         * binding atomically so deferred teardown cannot unbind a new owner. */
        uint32_t key=__get_PRIMASK();__disable_irq();
        if(usb_grid.unbind_pending && !XE_NP_UsbAux_IsBusy() &&
           XE_NP_UsbAux_BindGrid(NULL,NULL,NULL)==0)usb_grid.unbind_pending=0U;
        __set_PRIMASK(key);
    }
    if(np_idle && !XE_NP_UsbAux_IsBusy() && !usb_grid.started){usb_grid.frozen=0U;usb_grid.selected=0U;}
}
uint32_t XE_NP_Np2FirstSyncRuntime_GridSelected(void)
{return usb_grid.frozen?usb_grid.selected:usb_grid.requested;}
uint32_t XE_NP_Np2FirstSyncRuntime_GridFrozen(void){return usb_grid.frozen;}
#if XE_NP_GRID_ENFORCED || (defined(XE_NP_GRID_READY_GATE_TEST) && XE_NP_GRID_READY_GATE_TEST) || \
    (defined(XE_NP_GRID_FAIRNESS_TEST) && XE_NP_GRID_FAIRNESS_TEST)
/* Only skip a provably empty active provider; errors and pending payloads
 * must still reach Next so AUX can report them. Never gates stopped draining. */
int XE_NP_Np2FirstSyncRuntime_GridNeedsPoll(void)
{
    XE_NP_GridProvider *p=&usb_grid.provider;
    uint32_t queued;
    if(usb_grid.fault || !usb_grid.selected)return 1;
    if(!usb_grid.attached)return 0;
    if(!p->attached || p->incomplete)return 1;
    if(p->inflight || p->terminal_done)return 0;
    if(p->stopped || p->pending)return 1;
    queued=usb_grid.capture.queue.head-usb_grid.capture.queue.tail;
    if(queued>XE_NP_IMU_GRID_CAPACITY)return 1;
    return p->phase_done ? queued+p->has_held>=12U : (queued || p->has_held);
}
#endif
#if XE_NP_GRID_FAIRNESS_TEST
/* Foreground-only readiness; the timer IRQ may add slots, never remove them.
 * A stale lower count can defer service; it cannot manufacture a ready row. */
int XE_NP_Np2FirstSyncRuntime_GridFairReady(void)
{
    XE_NP_GridProvider *p=&usb_grid.provider;
    uint32_t queued;
    if(!usb_grid.started || !usb_grid.selected || !usb_grid.attached ||
       usb_grid.fault || usb_grid.stop_pending || usb_grid.unbind_pending ||
       !p->attached || p->stopped || p->incomplete || p->inflight || p->terminal_done)return 0;
    queued=usb_grid.capture.queue.head-usb_grid.capture.queue.tail;
    if(queued>XE_NP_IMU_GRID_CAPACITY)return 0;
    return p->phase_done ? queued+p->has_held>=12U : (queued || p->has_held);
}
int XE_NP_Np2FirstSyncRuntime_GridFairInputs(XE_NP_GridAdmission *s)
{
    XE_NP_GridProvider *p=&usb_grid.provider;
    if(!s || !XE_NP_Np2FirstSyncRuntime_GridFairReady())return 0;
    s->queue_head=usb_grid.capture.queue.head;s->queue_tail=usb_grid.capture.queue.tail;
    s->queue_capacity=XE_NP_IMU_GRID_CAPACITY;s->held=p->has_held;s->phase_done=p->phase_done;
    s->provider_ready=1U;s->provider_inflight=p->inflight;
    return (uint32_t)(s->queue_head-s->queue_tail)<=s->queue_capacity;
}
#endif

static void grid_start(void)
{
    if(!usb_grid.frozen || !usb_grid.selected)return;
    if(!XE_NP_UsbAux_IsRunning() || runtime.mode!=FIRST_MODE_USB || runtime.features!=15U || !runtime.fine_bound ||
       runtime.binding.counter_hz!=1000000U || !(runtime.aux_mask&1U)){
        usb_grid.fault=1U;return;
    }
    XE_NP_GridDiag_Reset(&xe_np_grid_startup_diag);
    XE_NP_GridRuntime_Init(&usb_grid.capture);XE_NP_GridProvider_Init(&usb_grid.provider);
    if(!XE_NP_GridRuntime_Prepare(&usb_grid.capture,runtime.binding.domain,
       runtime.binding.generation,runtime.binding.source_epoch,100U) ||
       !XE_NP_GridRuntime_Start(&usb_grid.capture,0U)){usb_grid.fault=1U;return;}
    usb_grid.started=1U;
#if XE_NP_GRID_STARTUP_DIAG
    XE_NP_Np2FirstSyncRuntime_GridDiagMark(XE_NP_GRID_DIAG_TIMER_START);
#endif
}
static void grid_attach(XE_NP_Np2FirstSyncGate *gate)
{
    uint8_t receipt[NP_FIRST_SYNC_BYTES];XE_NP_GridWireContext id;
    if(!usb_grid.started || !usb_grid.selected)return;
    id.uid[0]=HAL_GetUIDw0();id.uid[1]=HAL_GetUIDw1();id.uid[2]=HAL_GetUIDw2();
    id.session=runtime.binding.session;id.generation=runtime.binding.generation;
    id.epoch=runtime.binding.source_epoch;id.domain=runtime.binding.domain;id.token=runtime.token;
    if(!runtime.fine_anchor_valid || !np_first_sync_pack(receipt,&gate->receipt) ||
       !XE_NP_GridProvider_Attach(&usb_grid.provider,&usb_grid.capture,&id,receipt,sizeof(receipt),
            runtime.fine_anchor,sizeof(runtime.fine_anchor),0U,1U,XE_NP_GRID_ENFORCED)){
        grid_finish();usb_grid.fault=1U;return;
    }
    /* USB reset/NP fault may invalidate the gate while the foreground CRC
     * and binding checks run. Never publish the resulting stale provider. */
    uint32_t key=__get_PRIMASK();__disable_irq();
    if(!gate->bound || !gate->live || usb_grid.stop_pending){
        __set_PRIMASK(key);grid_finish();usb_grid.fault=1U;return;
    }
    usb_grid.attached=1U;__DMB();__set_PRIMASK(key);
#if XE_NP_GRID_STARTUP_DIAG
    XE_NP_Np2FirstSyncRuntime_GridDiagMark(XE_NP_GRID_DIAG_PROOF_ATTACH);
    XE_NP_Np2FirstSyncRuntime_GridDiagMark(XE_NP_GRID_DIAG_PRIME_BEGIN);
#endif
    /* Select a real post-source slot once at startup, independent of EP82.
     * The provider retains this exact slot for the subsequent phase/data. */
    uint64_t first;int primed=XE_NP_GridProvider_Prime(&usb_grid.provider,&first);
    /* A reset or stop may interrupt the bounded prime after attachment. Do
     * not leave its provider live after its source owner was invalidated. */
    key=__get_PRIMASK();__disable_irq();
    int still_owned=runtime.active && runtime.mode==FIRST_MODE_USB && !usb_grid.stop_pending &&
        runtime.token==id.token && runtime.binding.session==id.session &&
        runtime.binding.generation==id.generation && runtime.binding.source_epoch==id.epoch &&
        runtime.binding.domain==id.domain && XE_NP_Np2FirstSyncGate_Open(gate,&runtime.binding);
    __set_PRIMASK(key);
    if(primed<0 || !still_owned){grid_finish();usb_grid.fault=1U;}
    else if(primed>0)grid_first(first);
#if XE_NP_GRID_STARTUP_DIAG
    XE_NP_Np2FirstSyncRuntime_GridDiagMark(XE_NP_GRID_DIAG_PRIME_END);
#endif
}
#endif
#if XE_NP_SD_GRID16_ACTIVE
/* Dedicated CPU-owned workspace; target scatter/link must place and account
 * for this section explicitly. It is not an NP/DMA buffer. */
typedef struct {
    XE_NP_Grid16Runtime owner;volatile uint32_t stop_pending;uint32_t unavailable;
    uint64_t stopped_discarded_rows;uint32_t stopped_discarded_pending,retired;
} SdGrid16;
#if defined(_MSC_VER)
static SdGrid16 sd_grid16;
#else
static SdGrid16 sd_grid16 __attribute__((section("NP_GRID16_CPU"),aligned(8)));
#endif
static int sd_grid_qualified(void *context,const XE_NP_GridWireContext *id)
{
    XE_NP_Grid16Runtime *o=context;
    return o && id && runtime.active && runtime.mode==FIRST_MODE_SD && runtime.features==25U &&
        runtime.fine_bound && runtime.token==id->token && runtime.binding.session==id->session &&
        runtime.binding.generation==id->generation && runtime.binding.source_epoch==id->epoch &&
        runtime.binding.domain==id->domain &&
        XE_NP_Np2SdFineClock_BoundQualified64(id->domain,id->generation,id->epoch) &&
        (!o->started || XE_NP_GridTimer_Qualified());
}
static void sd_grid_stop(void)
{
    if(!sd_grid16.owner.started || sd_grid16.owner.stopped)return;
    if(__get_IPSR()){sd_grid16.stop_pending=1U;return;}
    if(!sd_grid16.owner.attached)sd_grid16.unavailable=1U;
    XE_NP_Grid16Runtime_Stop(&sd_grid16.owner);sd_grid16.stop_pending=0U;
}
static void sd_grid_start(void)
{
    XE_NP_GridWireContext id;
    sd_grid16.unavailable=1U;
    if(!XE_NP_Grid16Runtime_CanReuse(&sd_grid16.owner))return;
    XE_NP_Grid16Runtime_Init(&sd_grid16.owner);sd_grid16.stop_pending=0U;
    sd_grid16.stopped_discarded_rows=0U;sd_grid16.stopped_discarded_pending=0U;sd_grid16.retired=0U;
    if(runtime.mode!=FIRST_MODE_SD || runtime.features!=25U || !XE_NP_Np2FirstSyncSd_Grid16Start(runtime.nonce) || !runtime.fine_bound ||
       !runtime.fine_anchor_valid || runtime.binding.counter_hz!=1000000U || !(runtime.aux_mask&1U))return;
    id.uid[0]=HAL_GetUIDw0();id.uid[1]=HAL_GetUIDw1();id.uid[2]=HAL_GetUIDw2();
    id.session=runtime.binding.session;id.generation=runtime.binding.generation;
    id.epoch=runtime.binding.source_epoch;id.domain=runtime.binding.domain;id.token=runtime.token;
    if(XE_NP_Grid16Runtime_Start(&sd_grid16.owner,&id,sd_grid_qualified,&sd_grid16.owner,0U))
        sd_grid16.unavailable=0U;
}
static void sd_grid_first(uint64_t ordinal)
{
    XE_NP_Np2FirstSyncGate *gate=&runtime.port.gate;NpFirstSyncAux a={0};
    if(sd_grid16.unavailable || !runtime.active || gate->frozen || (gate->aux_seen&1U) ||
       ordinal==UINT64_MAX || !XE_NP_Np2FirstSyncGate_Open(gate,&runtime.binding))return;
    a.id=1U;a.flags=NP_FIRST_AUX_ENABLED|NP_FIRST_AUX_COUNTER;a.counter_bits=64U;a.counter=ordinal;
    a.rate_num=1250U;a.rate_den=1U;a.release_ms=a.release_cycles=a.first_ms=a.first_cycles=UINT32_MAX;
    a.offset_num=INT64_MIN;
    if(XE_NP_Np2FirstSyncGate_RecordAux(gate,&runtime.binding,&a,0U))freeze_pending();
}
static void sd_grid_attach(XE_NP_Np2FirstSyncGate *gate)
{
    uint8_t receipt[NP_FIRST_SYNC_BYTES];uint64_t first;uint32_t key;int valid,primed;
    XE_NP_Grid16Runtime *o=&sd_grid16.owner;
    if(sd_grid16.unavailable || !o->started || o->stopped)return;
    if(!runtime.fine_anchor_valid || !np_first_sync_pack(receipt,&gate->receipt) ||
       !XE_NP_Grid16Runtime_Attach(o,receipt,sizeof(receipt),runtime.fine_anchor,
                                  sizeof(runtime.fine_anchor),0U,1U,1U)){
        sd_grid16.unavailable=1U;sd_grid_stop();return;
    }
    key=__get_PRIMASK();__disable_irq();
    valid=runtime.active && runtime.mode==FIRST_MODE_SD && !sd_grid16.stop_pending &&
        runtime.token==o->identity.token && runtime.binding.session==o->identity.session &&
        runtime.binding.generation==o->identity.generation && runtime.binding.source_epoch==o->identity.epoch &&
        runtime.binding.domain==o->identity.domain && XE_NP_Np2FirstSyncGate_Open(gate,&runtime.binding);
    __set_PRIMASK(key);
    if(!valid){sd_grid16.unavailable=1U;sd_grid_stop();return;}
    primed=XE_NP_GridProvider_Prime(&o->provider,&first);
    key=__get_PRIMASK();__disable_irq();
    valid=runtime.active && runtime.mode==FIRST_MODE_SD && !sd_grid16.stop_pending &&
        runtime.token==o->identity.token && runtime.binding.session==o->identity.session &&
        runtime.binding.generation==o->identity.generation && runtime.binding.source_epoch==o->identity.epoch &&
        runtime.binding.domain==o->identity.domain && XE_NP_Np2FirstSyncGate_Open(gate,&runtime.binding);
    __set_PRIMASK(key);
    if(primed<0 || !valid){sd_grid16.unavailable=1U;sd_grid_stop();return;}
    if(primed>0)sd_grid_first(first);
}
static int sd_grid_next(uint8_t *body,uint32_t cap,uint32_t *type,uint32_t *bytes,uint64_t *source,uint32_t partial)
{
    if(sd_grid16.stop_pending)sd_grid_stop();
    if(sd_grid16.unavailable || !sd_grid16.owner.started)return 2;
    if(!sd_grid16.owner.attached)return sd_grid16.owner.stopped?2:0;
    int result=partial?XE_NP_Grid16Runtime_NextPartial(&sd_grid16.owner,body,cap,type,bytes,source):
        XE_NP_Grid16Runtime_Next(&sd_grid16.owner,body,cap,type,bytes,source);
    if(result==1 && *type==6U)sd_grid_first(*source);
    return result;
}
int XE_NP_Np2FirstSyncRuntime_SdGridNext(uint8_t *b,uint32_t c,uint32_t *t,uint32_t *n,uint64_t *s)
{return sd_grid_next(b,c,t,n,s,0U);}
int XE_NP_Np2FirstSyncRuntime_SdGridNextPartial(uint8_t *b,uint32_t c,uint32_t *t,uint32_t *n,uint64_t *s)
{return sd_grid_next(b,c,t,n,s,1U);}
void XE_NP_Np2FirstSyncRuntime_SdGridComplete(uint32_t type,uint32_t delivered)
{XE_NP_Grid16Runtime_Complete(&sd_grid16.owner,type,delivered);}
int XE_NP_Np2FirstSyncRuntime_SdGridPrepareStop(uint32_t *packets)
{
    XE_NP_Grid16Runtime *o=&sd_grid16.owner;XE_NP_GridProvider *p=&o->provider;
    uint32_t queued,tail,frames=0U,count=0U;uint64_t first=0U,last=0U,lower;
    if(!packets || __get_IPSR() || runtime.mode!=FIRST_MODE_SD)return 0;
    *packets=0U;sd_grid_stop();
    if(!o->started || !o->stopped || !o->attached || sd_grid16.unavailable ||
       sd_grid16.stop_pending || o->fault || p->incomplete || p->inflight ||
       XE_NP_GridTimer_Qualified())return 0;
    /* The timer is retired, so this bounded foreground scan has no producer.
     * Packet capacity is a12-slot ordinal span, not just12 observed rows. */
    tail=o->runtime.queue.tail;queued=o->runtime.queue.head-tail;
    if(queued>XE_NP_IMU_GRID_CAPACITY)return 0;
    lower=p->have_last?p->last_end:p->base_ordinal;
    if(p->pending){
        if(p->pending_type==5U){
            if(p->pending_end<=p->pending_source || p->pending_source<lower)return 0;
            frames=1U;lower=p->pending_end;
        }else if(p->pending_type==7U){
            if(queued || p->has_held)return 0;
        }else if(p->pending_type!=6U)return 0;
    }
    for(uint32_t i=0U;i<queued+(uint32_t)p->has_held;i++){
        uint64_t ordinal=p->has_held && !i?p->held.ordinal:
            o->runtime.queue.slots[(tail+i-(uint32_t)p->has_held)&(XE_NP_IMU_GRID_CAPACITY-1U)].ordinal;
        if(ordinal<lower || (count && ordinal<=last))return 0;
        if(!count || ordinal-first>=NP_IMU_GRID_MAX_SLOTS || count==NP_IMU_GRID_MAX_SLOTS){
            if(ordinal>UINT64_MAX-NP_IMU_GRID_MAX_SLOTS)return 0;
            first=ordinal;count=0U;frames++;
        }
        last=ordinal;count++;
    }
    *packets=frames;return 1;
}
int XE_NP_Np2FirstSyncRuntime_SdGridDiscardStopped(uint64_t *discarded_rows)
{
    XE_NP_Grid16Runtime *o=&sd_grid16.owner;XE_NP_GridProvider *p=&o->provider;
    uint32_t key,queued,pending;uint64_t rows;
    if(discarded_rows)*discarded_rows=0U;
    if(__get_IPSR() || !o->started || !o->stopped || !o->attached ||
       sd_grid16.stop_pending || XE_NP_GridTimer_Qualified() || p->inflight)return 0;
    key=__get_PRIMASK();__disable_irq();
    if(!o->started || !o->stopped || !o->attached || sd_grid16.stop_pending ||
       XE_NP_GridTimer_Qualified() || p->inflight){__set_PRIMASK(key);return 0;}
    queued=o->runtime.queue.head-o->runtime.queue.tail;
    if(queued>XE_NP_IMU_GRID_CAPACITY){__set_PRIMASK(key);return 0;}
    rows=(uint64_t)queued+(p->has_held?1U:0U);pending=p->pending?1U:0U;
    if(UINT64_MAX-sd_grid16.stopped_discarded_rows<rows){__set_PRIMASK(key);return 0;}
    sd_grid16.stopped_discarded_rows+=rows;
    if(pending && sd_grid16.stopped_discarded_pending!=UINT32_MAX)sd_grid16.stopped_discarded_pending++;
    o->runtime.queue.tail=o->runtime.queue.head;p->has_held=0U;p->pending=0U;p->incomplete=1U;
    o->attached=0U;sd_grid16.retired=1U;__DMB();__set_PRIMASK(key);
    if(discarded_rows)*discarded_rows=rows;return 1;
}
void XE_NP_Np2FirstSyncRuntime_SdGridStatus(XE_NP_Np2SdGridStatus *out)
{
    XE_NP_Grid16Runtime *o=&sd_grid16.owner;XE_NP_GridRuntimeStatus s={0};
    if(!out)return;memset(out,0,sizeof(*out));
    out->started=o->started;out->attached=o->attached;out->stopped=o->stopped;
    if(o->started)out->generation=o->identity.generation;
    out->fault=o->fault;out->retired=sd_grid16.retired;
    out->incomplete=!o->started || sd_grid16.unavailable || sd_grid16.stop_pending || o->fault || o->provider.incomplete || out->retired;
    out->discarded_prefix=o->provider.discarded_prefix;
    out->stopped_discarded_rows=sd_grid16.stopped_discarded_rows;
    out->stopped_discarded_pending=sd_grid16.stopped_discarded_pending;
    out->available=!out->incomplete && o->started && o->attached && !o->fault;
    if(o->started){XE_NP_GridRuntime_GetStatus(&o->runtime,&s);
        out->queue_dropped=s.queue_dropped;out->counter_faults=s.counter_faults;
        out->scheduler_faults=s.scheduler_faults;out->late_copies=s.late_copies;out->scheduler_missing=s.scheduler_missing;}
}
#elif XE_NP_NP2_SD_GRID16_ENABLE
int XE_NP_Np2FirstSyncRuntime_SdGridPrepareStop(uint32_t *packets)
{(void)packets;return 0;}
int XE_NP_Np2FirstSyncRuntime_SdGridNext(uint8_t *body,uint32_t cap,uint32_t *type,uint32_t *bytes,uint64_t *source)
{(void)body;(void)cap;(void)type;(void)bytes;(void)source;return 2;}
int XE_NP_Np2FirstSyncRuntime_SdGridNextPartial(uint8_t *b,uint32_t c,uint32_t *t,uint32_t *n,uint64_t *s)
{(void)b;(void)c;(void)t;(void)n;(void)s;return 2;}
void XE_NP_Np2FirstSyncRuntime_SdGridComplete(uint32_t type,uint32_t delivered){(void)type;(void)delivered;}
void XE_NP_Np2FirstSyncRuntime_SdGridStatus(XE_NP_Np2SdGridStatus *out)
{if(out){memset(out,0,sizeof(*out));out->incomplete=1U;}}
int XE_NP_Np2FirstSyncRuntime_SdGridDiscardStopped(uint64_t *discarded_rows)
{if(discarded_rows)*discarded_rows=0U;return 0;}
#endif
#if NP_FINE_COUNTER64_ENABLE
static uint32_t token_seed(void)
{uint32_t seed=(uint32_t)runtime.token^(uint32_t)(runtime.token>>32U);return seed?seed:1U;}
static int counter64_selected(void)
{return (runtime.mode==FIRST_MODE_SD && runtime.features==25U) ||
        (runtime.mode==FIRST_MODE_USB && (runtime.features==7U || runtime.features==15U));}
static void rtc_bind(void)
{
#if XE_NP_RTC_START_ENABLE
    NpRtcStartBinding b={0};const uint8_t *wire;
    const uint32_t uid[3]={HAL_GetUIDw0(),HAL_GetUIDw1(),HAL_GetUIDw2()};
    if(!runtime.fine_bound || !runtime.fine_anchor_valid)return;
    if(XE_NP_RtcStart_Frozen(runtime.token,runtime.fine.domain,runtime.binding.generation,
        runtime.binding.source_epoch,runtime.fine.counter_hz))return;
    wire=XE_NP_Np2FirstSyncGate_Frozen(&runtime.port.gate);
    if(!wire)return;
    b.receipt=wire;b.anchor=runtime.fine_anchor;memcpy(b.uid,uid,sizeof(uid));
    b.family=2U;b.session=runtime.mode==FIRST_MODE_SD?runtime.binding.session:0U;
    b.token=runtime.token;b.continuous64=1U;(void)XE_NP_RtcStart_Bind(&b);
#endif
}
#endif
static int owner(void *user,NpFirstSyncBinding *b,XE_NP_Np2FirstSyncPoint *p)
{
    XE_NP_AcquisitionAnchor a;(void)user;
    if(!runtime.active || !runtime.binding.generation || !XE_NP_Np2CapturePort_Armed() ||
       !XE_NP_Np2CapturePort_GetAnchor(&a) || (a.flags&0xFF0DU)!=0x020DU ||
       a.generation!=runtime.binding.generation || a.sample_hz!=runtime.hz ||
       a.source_hz!=runtime.hz*1600U)return 0;
    *b=runtime.binding;
    /* No continuously qualified DWT domain is inferred from a raw enable
     * counter. SourceClock remains clear; numeric source framing is useful. */
#if NP_FINE_COUNTER64_ENABLE
    if(runtime.fine_bound){
        XE_NP_Np2SdFinePoint64 point;
        if((a.flags&0xFF1FU)!=0x021FU || !XE_NP_Np2SdFineClock_Read64(&point) ||
           point.domain!=b->domain || point.counter_hz!=b->counter_hz ||
           point.generation!=b->generation || point.source_epoch!=b->source_epoch)return 0;
        p->domain=point.domain;p->ms=point.ms;p->cycles=(uint32_t)point.counter;return 1;
    }
#endif
    if(b->domain){
        XE_NP_Np2SdFinePoint point;
        if((a.flags&0xFF1FU)!=0x021FU || !XE_NP_Np2SdFineClock_Read(&point) ||
           point.domain!=b->domain || point.counter_hz!=b->counter_hz ||
           point.generation!=b->generation || point.source_epoch!=b->source_epoch)return 0;
        p->domain=point.domain;p->ms=point.ms;p->cycles=point.counter;return 1;
    }
    p->domain=0U;p->ms=HAL_GetTick();p->cycles=UINT32_MAX;return 1;
}
static void opened(void *user,XE_NP_Np2FirstSyncGate *gate,const NpFirstSyncBinding *b)
{
    XE_NP_Np2FirstSyncPoint p={0U,HAL_GetTick(),UINT32_MAX};(void)user;
    if(runtime.binding.domain){
        NpFirstSyncBinding actual;
        if(!owner(NULL,&actual,&p) || actual.session!=b->session || actual.generation!=b->generation ||
           actual.source_epoch!=b->source_epoch || actual.domain!=b->domain || actual.counter_hz!=b->counter_hz)return;
    }
    if(!XE_NP_Np2FirstSyncGate_Open(gate,b))return;
    for(uint32_t id=1U;id<=4U;id++)if(runtime.aux_mask&(1U<<(id-1U)))
        (void)XE_NP_Np2FirstSyncGate_Release(gate,b,id,&p);
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
    if((runtime.aux_mask&1U)
#if XE_NP_NP2_USB_GRID_EXPERIMENT
       /* In selected grid mode AUX owns the single sensor release below. */
       && !(runtime.mode==FIRST_MODE_USB && usb_grid.selected &&
            (XE_NP_UsbAux_FirstSyncMask()&1U))
#endif
       ){
#if NP_FINE_COUNTER64_ENABLE
        if(counter64_selected()){
            if(!runtime.fine_bound || !XE_NP_SensorsPort_FirstSyncRelease(gate)){
                XE_NP_SensorsPort_FirstSyncLegacy();
            }
        }else
#endif
        (void)XE_NP_SensorsPort_FirstSyncRelease(gate);
    }
#endif
#if XE_NP_V2_AUX_ENABLE
    if(runtime.mode==FIRST_MODE_USB)XE_NP_UsbAux_FirstSyncRelease(gate);
#endif
#if XE_NP_NP2_USB_GRID_EXPERIMENT
    if(runtime.mode==FIRST_MODE_USB)grid_attach(gate);
#endif
#if XE_NP_SD_GRID16_ACTIVE
    if(runtime.mode==FIRST_MODE_SD)sd_grid_attach(gate);
#endif
    service=freeze_pending;freeze_pending();
}
static void freeze_pending(void)
{
    if(!runtime.active){service=idle;return;}
    XE_NP_Np2FirstSyncGate *gate=&runtime.port.gate;
    if(!gate->receipt.session)return;
    if(XE_NP_Np2FirstSyncGate_Freeze(gate,&runtime.binding,HAL_GetTick(),!gate->bound)){
#if NP_FINE_COUNTER64_ENABLE
        rtc_bind();
#endif
        service=idle;
    }
}
static void runtime_legacy(void)
{
#if XE_NP_SD_GRID16_ACTIVE
    if(sd_grid16.owner.started && !sd_grid16.owner.stopped)sd_grid_stop();
#endif
#if XE_NP_NP2_USB_GRID_EXPERIMENT
    if(usb_grid.frozen && usb_grid.selected && !usb_grid.attached && runtime.mode==FIRST_MODE_USB)
        usb_grid.fault=1U;
    if(usb_grid.started){if(!__get_IPSR())grid_finish();else usb_grid.stop_pending=1U;}
#endif
#if NP_FINE_COUNTER64_ENABLE
    XE_NP_Np2SdFineDiagnosticEnd();
#endif
    XE_NP_Np2SdFineClock_Invalidate();
    XE_NP_Np2FirstSyncPort_Invalidate();service=idle;runtime.active=0U;runtime.mode=FIRST_MODE_NONE;
#if NP_FINE_COUNTER64_ENABLE
    XE_NP_RtcStart_Clear();
    runtime.prepared=runtime.clock_mode=runtime.fine_bound=runtime.fine_anchor_valid=0U;
    runtime.features=0U;memset(&runtime.fine,0,sizeof(runtime.fine));
#endif
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
    XE_NP_SensorsPort_FirstSyncLegacy();
#endif
#if XE_NP_V2_AUX_ENABLE
    XE_NP_UsbAux_FirstSyncLegacy();
#endif
}
void XE_NP_Np2FirstSyncRuntime_Init(void)
{
    XE_NP_Np2FirstSyncPort_Invalidate();memset(&runtime,0,sizeof(runtime));service=idle;
#if XE_NP_NP2_DUAL_SD_APP_ENABLE
    XE_NP_Np2FirstSyncSd_Bind(&runtime.sd);
#endif
    runtime_legacy();
}
void XE_NP_Np2FirstSyncRuntime_SdPrepare(uint32_t nonce,uint32_t session,uint32_t mask,uint32_t hz)
{
#if XE_NP_NP2_DUAL_SD_APP_ENABLE
    const XE_NP_Np2FirstSyncSdContext *r=XE_NP_Np2FirstSyncSd_Record();
    runtime_legacy();memset(&runtime.port,0,sizeof(runtime.port));memset(&runtime.binding,0,sizeof(runtime.binding));
    if(!r || r->retired || r->nonce!=nonce || !r->token || !session)return;
    runtime.mode=FIRST_MODE_SD;runtime.active=1U;runtime.nonce=nonce;runtime.token=r->token;
    runtime.session=session;runtime.mask=mask;runtime.hz=hz;
#if NP_FINE_COUNTER64_ENABLE
    runtime.features=XE_NP_Np2FirstSyncSd_CurrentContinuity()?25U:0U;
    XE_NP_Np2SdFineDiagnosticBegin(runtime.features?runtime.nonce:0U,runtime.features);
#endif
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE && XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE
    runtime.aux_mask=1U;
#else
    runtime.aux_mask=0U;
#endif
#else
    (void)nonce;(void)session;(void)mask;(void)hz;runtime_legacy();
#endif
}
int XE_NP_Np2FirstSyncRuntime_SdOpted(void)
{return runtime.active && runtime.mode==FIRST_MODE_SD;}
int XE_NP_Np2FirstSyncRuntime_SdClockBegin(void)
{return XE_NP_Np2FirstSyncRuntime_SdOpted() && runtime.nonce &&
    XE_NP_Np2SdFineClock_Start(runtime.nonce,0U,0U);}
static int legacy_fine_anchor(uint8_t out[64])
{
    XE_NP_AcquisitionAnchor a;
    if(!out || !XE_NP_Np2FirstSyncRuntime_SdOpted() || !runtime.binding.domain ||
       !XE_NP_Np2CapturePort_GetAnchor(&a) || (a.flags&0xFF1FU)!=0x021FU ||
       a.generation!=runtime.binding.generation || a.counter_hz!=runtime.binding.counter_hz ||
       a.source_hz!=runtime.hz*1600U || a.sample_hz!=runtime.hz)return 0;
    XE_NP_AcquisitionAnchor_Reply(&a,runtime.binding.domain,out);return 1;
}
#if !NP_FINE_COUNTER64_ENABLE
int XE_NP_Np2FirstSyncRuntime_SdFineAnchor(uint8_t out[64]){return legacy_fine_anchor(out);}
#endif
#if NP_FINE_COUNTER64_ENABLE
int XE_NP_Np2FirstSyncRuntime_ClockBegin(void)
{
    if(!runtime.active)return 0;
    XE_NP_Np2SdFineDiagnosticProgress(XE_NP_FINE_PROGRESS_CLOCK_BEGIN_CALLED);
    if(counter64_selected()){
        if(!XE_NP_Np2SdFineClock_Start64(token_seed(),0U,0U)){
            XE_NP_Np2SdFineDiagnosticFailure(XE_NP_FINE_DIAG_CLOCK_BEGIN,0U,0U,0U,NULL,NULL);
            XE_NP_Np2SdFineDiagnosticProgress(XE_NP_FINE_PROGRESS_CLOCK_BEGIN_FAIL);
            return 0;
        }
        runtime.clock_mode=2U;
        XE_NP_Np2SdFineDiagnosticProgress(XE_NP_FINE_PROGRESS_CLOCK_BEGIN_OK);
#if XE_NP_RTC_START_ENABLE
        if(runtime.mode==FIRST_MODE_SD || runtime.features==15U)(void)XE_NP_RtcStart_Observe(runtime.token);
#endif
        return 2;
    }
    if(runtime.mode!=FIRST_MODE_SD)return 0;
    if(XE_NP_Np2SdFineClock_Start(token_seed(),0U,0U)){runtime.clock_mode=1U;return 1;}
    return 0;
}
int XE_NP_Np2FirstSyncRuntime_FineBound(uint32_t generation,uint32_t source_epoch,
    const XE_NP_Np2SdFinePoint64 *before,const XE_NP_Np2SdFinePoint64 *after)
{
    XE_NP_Np2SdFinePoint64 point;
    XE_NP_Np2SdFineDiagnosticProgress(XE_NP_FINE_PROGRESS_FINE_BOUND_CALLED);
    if(!runtime.active || runtime.clock_mode!=2U || runtime.fine_bound ||
       !XE_NP_Np2SdFineClock_BindSource64(generation,source_epoch,before,after) ||
       !XE_NP_Np2SdFineClock_Read64(&point) || point.generation!=generation ||
       point.source_epoch!=source_epoch || point.counter_hz!=XE_NP_NP2_SD_FINE_HZ){
        XE_NP_Np2SdFineDiagnosticFailure(XE_NP_FINE_DIAG_RUNTIME_FINE_BOUND,0U,generation,source_epoch,before,after);
        XE_NP_Np2SdFineDiagnosticProgress(XE_NP_FINE_PROGRESS_FINE_BOUND_FAIL);
        return 0;
    }
    runtime.fine=point;runtime.fine_bound=1U;
    XE_NP_Np2SdFineDiagnosticProgress(XE_NP_FINE_PROGRESS_FINE_BOUND_OK);
    return 1;
}
int XE_NP_Np2FirstSyncRuntime_FineCounter64(void)
{return runtime.active && runtime.fine_bound && runtime.clock_mode==2U;}
int XE_NP_Np2FirstSyncRuntime_SdFineAnchor(uint8_t out[64])
{
    if(!runtime.fine_anchor_valid)return legacy_fine_anchor(out);
    if(!out)return 0;
    memcpy(out,runtime.fine_anchor,64U);return 1;
}
const uint8_t *XE_NP_Np2FirstSyncRuntime_RtcFrozen(void)
{
#if XE_NP_RTC_START_ENABLE
    if(!runtime.fine_bound)return NULL;
    return XE_NP_RtcStart_Frozen(runtime.token,runtime.fine.domain,runtime.binding.generation,
                                 runtime.binding.source_epoch,runtime.fine.counter_hz);
#else
    return NULL;
#endif
}
#endif
static int armed(void)
{
    XE_NP_AcquisitionAnchor a;
    if(!runtime.active || !XE_NP_Np2CapturePort_Armed() || !XE_NP_Np2CapturePort_GetAnchor(&a) ||
       (a.flags&0xFF0DU)!=0x020DU || !a.generation || a.sample_hz!=runtime.hz || a.source_hz!=runtime.hz*1600U)return 0;
    runtime.binding=(NpFirstSyncBinding){runtime.mode==FIRST_MODE_USB?a.generation:runtime.session,
        a.generation,a.generation,
#if NP_FINE_COUNTER64_ENABLE
        runtime.fine_bound?runtime.fine.domain:0U,
#else
        0U,
#endif
#if NP_FINE_COUNTER64_ENABLE
        runtime.fine_bound?runtime.fine.counter_hz:0U,
#else
        0U,
#endif
        UINT32_MAX,2U,runtime.mask,runtime.hz};
#if NP_FINE_COUNTER64_ENABLE
    if(runtime.fine_bound && ((a.flags&0xFF1FU)!=0x021FU ||
       runtime.fine.generation!=a.generation || runtime.fine.source_epoch!=a.generation ||
       runtime.fine.counter_hz!=a.counter_hz))return 0;
    if(runtime.fine_bound && !runtime.fine_anchor_valid){
        XE_NP_AcquisitionAnchor_Reply(&a,runtime.fine.domain,runtime.fine_anchor);runtime.fine_anchor_valid=1U;
    }
#endif
    if(!runtime.binding.domain){
        XE_NP_Np2SdFinePoint point;
        if((a.flags&0xFF1FU)==0x021FU && XE_NP_Np2SdFineClock_Read(&point) &&
           point.generation==a.generation && point.source_epoch==a.generation &&
           point.counter_hz==a.counter_hz){runtime.binding.domain=point.domain;runtime.binding.counter_hz=point.counter_hz;}
    }
#if XE_NP_NP2_DUAL_SD_APP_ENABLE
    if(runtime.mode==FIRST_MODE_SD && !XE_NP_Np2FirstSyncSd_Capture(runtime.nonce,runtime.session,
        a.generation,a.generation,UINT32_MAX))return 0;
#endif
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
    if(runtime.aux_mask&1U){
#if NP_FINE_COUNTER64_ENABLE
        if(counter64_selected() && !runtime.fine_bound){
            XE_NP_SensorsPort_FirstSyncLegacy();
        }else
#endif
        XE_NP_SensorsPort_FirstSyncWait();
    }
#endif
#if XE_NP_V2_AUX_ENABLE
    if(runtime.mode==FIRST_MODE_USB)XE_NP_UsbAux_FirstSyncWait();
#endif
    if(!XE_NP_Np2FirstSyncPort_Bind(&runtime.port,owner,opened,NULL,runtime.aux_mask,runtime.binding.domain!=0U))return 0;
#if XE_NP_NP2_USB_GRID_EXPERIMENT
    if(runtime.mode==FIRST_MODE_USB)grid_start();
#endif
#if XE_NP_SD_GRID16_ACTIVE
    if(runtime.mode==FIRST_MODE_SD)sd_grid_start();
#endif
    service=freeze_pending;return 1;
}
void XE_NP_Np2FirstSyncRuntime_SdArmed(void)
{if(XE_NP_Np2FirstSyncRuntime_SdOpted() && !armed())runtime_legacy();}
#if NP_FINE_COUNTER64_ENABLE
int XE_NP_Np2FirstSyncRuntime_UsbPrepare(uint64_t token,uint32_t mask,uint32_t hz,uint8_t aux,uint32_t features)
{
    runtime_legacy();memset(&runtime.port,0,sizeof(runtime.port));memset(&runtime.binding,0,sizeof(runtime.binding));
    if(!token)return 1;
    runtime.mode=FIRST_MODE_USB;runtime.active=1U;runtime.token=token;runtime.mask=mask;runtime.hz=hz;runtime.aux_mask=aux;
    if(features!=0U && features!=7U && features!=15U){runtime_legacy();return 0;}
    runtime.features=features;runtime.prepared=1U;
    XE_NP_Np2SdFineDiagnosticBegin(features?token_seed():0U,features);
    return 1;
}
#endif
int XE_NP_Np2FirstSyncRuntime_UsbArmed(uint64_t token,uint32_t mask,uint32_t hz,uint8_t aux)
{
#if NP_FINE_COUNTER64_ENABLE
    if(runtime.active && runtime.mode==FIRST_MODE_USB && runtime.prepared){
        if(runtime.token!=token || runtime.mask!=mask || runtime.hz!=hz || runtime.aux_mask!=aux)return 0;
        runtime.prepared=0U;if(armed())return 1;runtime_legacy();return 0;
    }
    if(!XE_NP_Np2FirstSyncRuntime_UsbPrepare(token,mask,hz,aux,0U))return 0;
    if(!token)return 1;
    if(armed())return 1;runtime_legacy();return 0;
#else
    runtime_legacy();memset(&runtime.port,0,sizeof(runtime.port));memset(&runtime.binding,0,sizeof(runtime.binding));
    if(!token)return 1;
    runtime.mode=FIRST_MODE_USB;runtime.active=1U;runtime.token=token;runtime.mask=mask;runtime.hz=hz;runtime.aux_mask=aux;
    if(armed())return 1;runtime_legacy();return 0;
#endif
}
void XE_NP_Np2FirstSyncRuntime_Stop(void)
{
#if XE_NP_SD_GRID16_ACTIVE
    if(runtime.mode==FIRST_MODE_SD)sd_grid_stop();
#endif
#if XE_NP_NP2_USB_GRID_EXPERIMENT
    /* Actual cutoff is not proven here; preserve unknown terminal instead. */
    if(!__get_IPSR())grid_finish();else usb_grid.stop_pending=1U;
#endif
#if NP_FINE_COUNTER64_ENABLE
    XE_NP_Np2SdFineDiagnosticEnd();
#endif
    if(!runtime.active || !runtime.binding.generation)return;
    if(!runtime.port.gate.receipt.session)
        (void)XE_NP_Np2FirstSyncGate_Begin(&runtime.port.gate,&runtime.binding,runtime.aux_mask,0);
    (void)XE_NP_Np2FirstSyncGate_Freeze(&runtime.port.gate,&runtime.binding,HAL_GetTick(),1);service=idle;
#if NP_FINE_COUNTER64_ENABLE
    rtc_bind();XE_NP_Np2SdFineClock_Invalidate();
#endif
}
void XE_NP_Np2FirstSyncRuntime_Service(void){
#if XE_NP_SD_GRID16_ACTIVE
    if(sd_grid16.stop_pending)sd_grid_stop();
#endif
    service();
}
void XE_NP_Np2FirstSyncRuntime_AuxAccepted(uint32_t id,uint64_t counter,uint8_t bits,uint32_t rn,uint32_t rd)
{
    XE_NP_Np2FirstSyncGate *gate=&runtime.port.gate;NpFirstSyncAux a={0};
#if XE_NP_SD_GRID16_ACTIVE
    if(runtime.mode==FIRST_MODE_SD && sd_grid16.owner.started && !sd_grid16.unavailable && id==1U)return;
#endif
#if XE_NP_NP2_USB_GRID_EXPERIMENT
    /* A selected grid owns IMU receipt ID1; legacy SNS stays otherwise intact. */
    if(runtime.mode==FIRST_MODE_USB && usb_grid.frozen && usb_grid.selected && id==1U)return;
#endif
    if(!runtime.active || gate->frozen || id<1U || id>4U || (gate->aux_seen&(1U<<(id-1U))) ||
       !XE_NP_Np2FirstSyncGate_Open(gate,&runtime.binding))return;
    a.id=(uint8_t)id;a.flags=NP_FIRST_AUX_ENABLED|NP_FIRST_AUX_COUNTER;a.counter_bits=bits;a.counter=counter;
    a.rate_num=rn;a.rate_den=rd;a.release_ms=a.release_cycles=a.first_ms=a.first_cycles=UINT32_MAX;a.offset_num=INT64_MIN;
    if(XE_NP_Np2FirstSyncGate_RecordAux(gate,&runtime.binding,&a,0U))freeze_pending();
}
const uint8_t *XE_NP_Np2FirstSyncRuntime_FrozenUsb(uint64_t token)
{
    return runtime.active && runtime.mode==FIRST_MODE_USB && token && token==runtime.token?
        XE_NP_Np2FirstSyncGate_Frozen(&runtime.port.gate):NULL;
}
void XE_NP_Np2FirstSyncRuntime_SdTime(uint8_t sector[512])
{
#if XE_NP_NP2_DUAL_SD_APP_ENABLE
    const XE_NP_Np2FirstSyncSdContext *r=XE_NP_Np2FirstSyncSd_Record();
    const uint8_t *wire=XE_NP_Np2FirstSyncGate_Frozen(&runtime.port.gate);
    const uint32_t uid[3]={HAL_GetUIDw0(),HAL_GetUIDw1(),HAL_GetUIDw2()};
    if(!sector || !XE_NP_Np2FirstSyncRuntime_SdOpted() || !r || !wire || r->token!=runtime.token || r->nonce!=runtime.nonce ||
       r->current.session!=runtime.binding.session || r->current.generation!=runtime.binding.generation ||
       r->current.source_epoch!=runtime.binding.source_epoch || np_first_u32(wire+16)!=runtime.binding.session ||
       np_first_u32(wire+20)!=runtime.binding.generation || np_first_u32(wire+24)!=runtime.binding.source_epoch)return;
    /* One existing foreground metadata write, never a neural/data-path write.
     * Failure preserves the old validated sector and cannot stop recording. */
    (void)np_first_sd_sector_bind(sector,sector,wire,2U,uid,runtime.token);
#else
    (void)sector;
#endif
}
#endif
