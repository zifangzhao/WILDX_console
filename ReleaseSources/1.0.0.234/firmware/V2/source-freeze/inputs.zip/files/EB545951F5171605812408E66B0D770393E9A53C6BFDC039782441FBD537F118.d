C:\Frank\Code\USB_PCconsole\_artifacts\closed_loop_20261102\V2\build-app\xe_np_np2_closed_loop_spi.o: \
  D:\Code\XE_NP_V2\Core\Src\xe_np_np2_closed_loop_spi.c \
  D:\Code\XE_NP_V2\Core\Inc\xe_np_np2_closed_loop_spi.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\stdint.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\string.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\limits.h \
  D:\Code\XE_NP_V2\Core\Inc\xe_np_np2_closed_loop_perf.h
