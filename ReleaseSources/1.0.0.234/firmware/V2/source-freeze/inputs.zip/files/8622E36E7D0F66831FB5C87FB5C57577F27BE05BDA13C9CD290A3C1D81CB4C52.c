#include "xe_np_legacy_fs.h"

#include "CE32_ADC.h"
#include "CE32_filesystem.h"
#include "CE32_HJ580.h"
#include "CE32_system.h"
#include "dataMGR.h"

#include <string.h>

typedef struct
{
    XE_NP_Runtime *runtime;
    dataMGR trigger_mgr;
    dataMGR *primary_mgr;
    dataMGR *secondary_mgr;
    uint8_t primary_consumer_armed;
    uint8_t secondary_consumer_armed;
    uint8_t initialized;
    uint8_t active;
} XE_NP_LegacyFsState;

static XE_NP_LegacyFsState xe_np_legacy_fs = {0};
volatile XE_NP_LegacyFsDiag xe_np_legacy_fs_diag = {
    XE_NP_LEGACY_FS_DIAG_MAGIC,
    XE_NP_LEGACY_FS_DIAG_VERSION,
    0U,
    XE_NP_LEGACY_FS_DIAG_STEP_IDLE,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
    0U,
};

#define XE_NP_LEGACY_FS_PRIMARY_STREAM_ID CE32_FILE_BUFFERID_EPHYS
#define XE_NP_LEGACY_FS_SECONDARY_STREAM_ID CE32_FILE_BUFFERID_CAMERA
#define XE_NP_LEGACY_FS_PORT_GPIOE 0x0U
#define XE_NP_LEGACY_FS_PORT_GPIOD 0x1U
#define XE_NP_LEGACY_FS_PORT_PSSI 0x8U
#define XE_NP_LEGACY_FS_PORT_NONE 0xFU

static void XE_NP_LegacyFs_RecordDiag(uint32_t step, const XE_NP_Runtime *runtime)
{
    xe_np_legacy_fs_diag.magic = XE_NP_LEGACY_FS_DIAG_MAGIC;
    xe_np_legacy_fs_diag.version = XE_NP_LEGACY_FS_DIAG_VERSION;
    xe_np_legacy_fs_diag.tick_ms = HAL_GetTick();
    xe_np_legacy_fs_diag.step = step;
    xe_np_legacy_fs_diag.runtime_flags = (runtime != NULL) ? runtime->flags : 0U;
    xe_np_legacy_fs_diag.capture_flags = (runtime != NULL) ? runtime->capture.flags : 0U;
    xe_np_legacy_fs_diag.ce32_error = CE32_SystemCompat_GetLegacyFsError();
    xe_np_legacy_fs_diag.fs_enabled = (uint32_t)fs.enabled;
    xe_np_legacy_fs_diag.fs_state = (uint32_t)fs.state;
    xe_np_legacy_fs_diag.fs_state_machine = (uint32_t)fs.stateMachine;
    xe_np_legacy_fs_diag.fs_fail_cnt = fs.fail_cnt;
    xe_np_legacy_fs_diag.file_addr = fs.file_addr;
    xe_np_legacy_fs_diag.event_addr = fs.event_addr;
    xe_np_legacy_fs_diag.log_addr = fs.log_addr;
    xe_np_legacy_fs_diag.status_bits =
        ((xe_np_legacy_fs.initialized != 0U) ? 0x01UL : 0UL) |
        ((xe_np_legacy_fs.active != 0U) ? 0x02UL : 0UL) |
        ((xe_np_legacy_fs.primary_consumer_armed != 0U) ? 0x04UL : 0UL) |
        ((xe_np_legacy_fs.secondary_consumer_armed != 0U) ? 0x08UL : 0UL);
}

static uint32_t XE_NP_LegacyFs_BuildRawLayoutTag(const XE_NP_Runtime *runtime, uint32_t gpioe_rate, uint32_t gpiod_rate)
{
    uint32_t primary_port = XE_NP_LEGACY_FS_PORT_NONE;
    uint32_t secondary_port = XE_NP_LEGACY_FS_PORT_NONE;
    uint32_t active_probe_mask = 0U;

    if(runtime != NULL)
    {
        active_probe_mask = (uint32_t)(runtime->active_np_probe_mask & XE_NP_CAPTURE_ALL_PROBES_MASK);
    }

    if(gpioe_rate != 0U)
    {
#if (XE_NP_BOARD_V2_PSSI_NP1_ENABLE != 0U)
        primary_port = XE_NP_LEGACY_FS_PORT_PSSI;
#else
        primary_port = XE_NP_LEGACY_FS_PORT_GPIOE;
#endif
        if(gpiod_rate != 0U)
        {
            secondary_port = XE_NP_LEGACY_FS_PORT_GPIOD;
        }
    }
    else if(gpiod_rate != 0U)
    {
        primary_port = XE_NP_LEGACY_FS_PORT_GPIOD;
    }

    /*
     * Persist a compact raw-layout tag in unassigned_32 for post-hoc tools:
     * 31:16 = 'NP', 15:8 = active probe mask, 7:4 = primary raw stream port,
     * 3:0 = secondary raw stream port (0xF when absent).
     */
    return 0x4E500000UL |
           ((active_probe_mask & 0xFFUL) << 8U) |
           ((primary_port & 0xFUL) << 4U) |
           (secondary_port & 0xFUL);
}

static int XE_NP_LegacyFs_BleMacValid(void)
{
    uint32_t mac_or = 0U;

    for(uint32_t i = 0U; i < sizeof(BLE_handle.DeviceMAC); ++i)
    {
        mac_or |= (uint8_t)BLE_handle.DeviceMAC[i];
    }

    return (mac_or != 0U) ? 1 : 0;
}

static void XE_NP_LegacyFs_ApplyLiveDeviceMetadata(XE_NP_Runtime *runtime)
{
    if(runtime == NULL)
    {
        return;
    }

    if(BLE_handle.DEV.hw_version != 0U)
    {
        runtime->sys_param.hw_version = BLE_handle.DEV.hw_version;
    }

    if(XE_NP_LegacyFs_BleMacValid() != 0)
    {
        memset(runtime->sys_param.MAC, 0, sizeof(runtime->sys_param.MAC));
        memcpy(
            runtime->sys_param.MAC,
            BLE_handle.DeviceMAC,
            sizeof(BLE_handle.DeviceMAC));
    }

    XE_NP_Runtime_StampRtcNow(runtime, &runtime->sys_param.date, &runtime->sys_param.time);
}

static int XE_NP_LegacyFs_RuntimeReady(const XE_NP_Runtime *runtime)
{
    if(runtime == NULL)
    {
        return 0;
    }

    if((runtime->flags & XE_NP_RUNTIME_FLAG_SD_PRESENT) == 0U)
    {
        return 0;
    }

    if(XE_NP_Runtime_HasValidNpMclk(runtime) == 0)
    {
        return 0;
    }

    if((runtime->flags & XE_NP_RUNTIME_FLAG_NP_GLOBAL_RESET_RELEASED) == 0U)
    {
        return 0;
    }

    /*
     * Allow the CE64-style recorder to arm immediately after capture DMA is
     * started, before NP_REC_NRST is released. That keeps the file/log path
     * ready before the first Neuropixels raw bytes can enter the ring.
     */
    if((runtime->flags &
        (XE_NP_RUNTIME_FLAG_NP_RECORD_RESET_RELEASED |
         XE_NP_RUNTIME_FLAG_NP_CAPTURE_DMA_ACTIVE)) == 0U)
    {
        return 0;
    }

    return 1;
}

static int XE_NP_LegacyFs_RawConsumersReady(const XE_NP_Runtime *runtime)
{
    if(runtime == NULL)
    {
        return 0;
    }

    /*
     * Keep the recorder/file path armed before REC_NRESET so the session can
     * open cleanly, but do not let the raw capture managers expose data to the
     * CE64 scheduler until the probe record reset has actually been released.
     * That drops pre-release bus-idle garbage without sacrificing the first
     * real post-reset Neuropixels frames.
     */
    if((runtime->flags & XE_NP_RUNTIME_FLAG_NP_RECORD_RESET_RELEASED) == 0U)
    {
        return 0;
    }

    return 1;
}

static void XE_NP_LegacyFs_UpdateRawConsumers(const XE_NP_Runtime *runtime)
{
    uint8_t consumers_ready;

    consumers_ready = (uint8_t)((XE_NP_LegacyFs_RuntimeReady(runtime) != 0) &&
                                (XE_NP_LegacyFs_RawConsumersReady(runtime) != 0));

    if(xe_np_legacy_fs.primary_mgr != NULL)
    {
        if(consumers_ready != 0U)
        {
            if(xe_np_legacy_fs.primary_consumer_armed == 0U)
            {
                dataMGR_ArmConsumer(xe_np_legacy_fs.primary_mgr, 0U);
                xe_np_legacy_fs.primary_consumer_armed = 1U;
            }
        }
        else if(xe_np_legacy_fs.primary_consumer_armed != 0U)
        {
            dataMGR_DisarmConsumer(xe_np_legacy_fs.primary_mgr, 0U);
            xe_np_legacy_fs.primary_consumer_armed = 0U;
        }
    }

    if(xe_np_legacy_fs.secondary_mgr != NULL)
    {
        if(consumers_ready != 0U)
        {
            if(xe_np_legacy_fs.secondary_consumer_armed == 0U)
            {
                dataMGR_ArmConsumer(xe_np_legacy_fs.secondary_mgr, 0U);
                xe_np_legacy_fs.secondary_consumer_armed = 1U;
            }
        }
        else if(xe_np_legacy_fs.secondary_consumer_armed != 0U)
        {
            dataMGR_DisarmConsumer(xe_np_legacy_fs.secondary_mgr, 0U);
            xe_np_legacy_fs.secondary_consumer_armed = 0U;
        }
    }
}

static uint32_t XE_NP_LegacyFs_SelectCaptureRate(const XE_NP_CapturePort *port)
{
    if((port == NULL) || (port->storage == NULL) || (port->raw_bytes_per_sec == 0U))
    {
        return 0U;
    }

    return port->raw_bytes_per_sec;
}

static uint32_t XE_NP_LegacyFs_SelectAdcRate(void)
{
    if((ADC_handle.hadc == NULL) || (ADC_handle.MGR.dataPtr == NULL) || (ADC_handle.fs == 0U))
    {
        return 0U;
    }

    return (uint32_t)ADC_handle.Nch * ADC_handle.fs * sizeof(uint16_t);
}

static void XE_NP_LegacyFs_SyncMetadata(const XE_NP_Runtime *runtime)
{
    CE32_systemParam *sys_param;
    uint32_t gpioe_rate;
    uint32_t gpiod_rate;
    uint32_t adc_rate;
    uint32_t misc_bytes_per_sec;

    if(runtime == NULL)
    {
        return;
    }

    sys_param = &xe_np_legacy_fs.runtime->sys_param;
    XE_NP_LegacyFs_ApplyLiveDeviceMetadata(xe_np_legacy_fs.runtime);

    /*
     * XE_NP logs Neuropixels as raw capture bytes, not as decoded Intan-style
     * channel banks. Keep the legacy CE64 file structure and its byte-rate-
     * preserving uint16 metadata, but identify V2's primary stream as PSSI in
     * the raw-layout tag.
     */
    gpioe_rate = XE_NP_LegacyFs_SelectCaptureRate(&runtime->capture.gpioe);
    gpiod_rate = XE_NP_LegacyFs_SelectCaptureRate(&runtime->capture.gpiod);
    adc_rate = XE_NP_LegacyFs_SelectAdcRate();
    misc_bytes_per_sec = (uint32_t)sys_param->Nch[3] *
                         sys_param->sampling_rate[3] * 2U;
    sys_param->unassigned_32 =
        XE_NP_LegacyFs_BuildRawLayoutTag(runtime, gpioe_rate, gpiod_rate);

    sys_param->Nch[XE_NP_LEGACY_FS_PRIMARY_STREAM_ID] = 0U;
    sys_param->sampling_rate[XE_NP_LEGACY_FS_PRIMARY_STREAM_ID] = 0U;
    sys_param->spd_rate[XE_NP_LEGACY_FS_PRIMARY_STREAM_ID] = 0U;
    sys_param->Nch[XE_NP_LEGACY_FS_SECONDARY_STREAM_ID] = 0U;
    sys_param->sampling_rate[XE_NP_LEGACY_FS_SECONDARY_STREAM_ID] = 0U;
    sys_param->spd_rate[XE_NP_LEGACY_FS_SECONDARY_STREAM_ID] = 0U;
    sys_param->Nch[CE32_FILE_BUFFERID_ADC] = 0U;
    sys_param->sampling_rate[CE32_FILE_BUFFERID_ADC] = 0U;
    sys_param->spd_rate[CE32_FILE_BUFFERID_ADC] = 0U;

    if(gpioe_rate != 0U)
    {
        sys_param->Nch[XE_NP_LEGACY_FS_PRIMARY_STREAM_ID] = 1U;
        sys_param->sampling_rate[XE_NP_LEGACY_FS_PRIMARY_STREAM_ID] = gpioe_rate / 2U;
        if(misc_bytes_per_sec != 0U)
        {
            sys_param->spd_rate[XE_NP_LEGACY_FS_PRIMARY_STREAM_ID] =
                (uint16_t)(gpioe_rate / misc_bytes_per_sec);
        }
    }
    else if(gpiod_rate != 0U)
    {
        sys_param->Nch[XE_NP_LEGACY_FS_PRIMARY_STREAM_ID] = 1U;
        sys_param->sampling_rate[XE_NP_LEGACY_FS_PRIMARY_STREAM_ID] = gpiod_rate / 2U;
        if(misc_bytes_per_sec != 0U)
        {
            sys_param->spd_rate[XE_NP_LEGACY_FS_PRIMARY_STREAM_ID] =
                (uint16_t)(gpiod_rate / misc_bytes_per_sec);
        }
    }

    if((gpioe_rate != 0U) && (gpiod_rate != 0U))
    {
        sys_param->Nch[XE_NP_LEGACY_FS_SECONDARY_STREAM_ID] = 1U;
        sys_param->sampling_rate[XE_NP_LEGACY_FS_SECONDARY_STREAM_ID] = gpiod_rate / 2U;
        if(misc_bytes_per_sec != 0U)
        {
            sys_param->spd_rate[XE_NP_LEGACY_FS_SECONDARY_STREAM_ID] =
                (uint16_t)(gpiod_rate / misc_bytes_per_sec);
        }
    }

    if(adc_rate != 0U)
    {
        sys_param->Nch[CE32_FILE_BUFFERID_ADC] = ADC_handle.Nch;
        sys_param->sampling_rate[CE32_FILE_BUFFERID_ADC] = ADC_handle.fs;
        if(misc_bytes_per_sec != 0U)
        {
            sys_param->spd_rate[CE32_FILE_BUFFERID_ADC] =
                (uint16_t)(adc_rate / misc_bytes_per_sec);
        }
    }
}

void XE_NP_LegacyFs_RefreshMetadata(void)
{
    XE_NP_Runtime *runtime = xe_np_legacy_fs.runtime;

    if(runtime == NULL)
    {
        return;
    }

    XE_NP_LegacyFs_SyncMetadata(runtime);
}

static void XE_NP_LegacyFs_UpdateTriggerMirror(void)
{
    if(xe_np_legacy_fs.primary_mgr == NULL)
    {
        return;
    }

    xe_np_legacy_fs.trigger_mgr.bufferUsed[0] =
        dataMGR_BytesAvailable(xe_np_legacy_fs.primary_mgr, 0U);
    xe_np_legacy_fs.trigger_mgr.outPTR[0] =
        xe_np_legacy_fs.primary_mgr->outPTR[0];
}

static int XE_NP_LegacyFs_Configure(XE_NP_Runtime *runtime)
{
    uint32_t gpioe_rate;
    uint32_t gpiod_rate;
    uint32_t adc_rate;
    int init_result;

    if(runtime == NULL)
    {
        return -1;
    }

    gpioe_rate = XE_NP_LegacyFs_SelectCaptureRate(&runtime->capture.gpioe);
    gpiod_rate = XE_NP_LegacyFs_SelectCaptureRate(&runtime->capture.gpiod);
    adc_rate = XE_NP_LegacyFs_SelectAdcRate();
    xe_np_legacy_fs_diag.gpioe_rate = gpioe_rate;
    xe_np_legacy_fs_diag.gpiod_rate = gpiod_rate;
    xe_np_legacy_fs_diag.adc_rate = adc_rate;
    XE_NP_LegacyFs_RecordDiag(XE_NP_LEGACY_FS_DIAG_STEP_CONFIG_ENTER, runtime);
    if((gpioe_rate == 0U) && (gpiod_rate == 0U))
    {
        XE_NP_LegacyFs_RecordDiag(XE_NP_LEGACY_FS_DIAG_STEP_CONFIG_NO_RATE, runtime);
        return -1;
    }

    memset(&xe_np_legacy_fs, 0, sizeof(xe_np_legacy_fs));
    xe_np_legacy_fs.runtime = runtime;
    XE_NP_LegacyFs_SyncMetadata(runtime);
    memset(&fs, 0, sizeof(fs));

    if((gpioe_rate != 0U) && (gpiod_rate != 0U))
    {
        xe_np_legacy_fs.primary_mgr = &runtime->capture.gpioe.raw_mgr;
        xe_np_legacy_fs.secondary_mgr = &runtime->capture.gpiod.raw_mgr;
        (void)CE32_File_FileStream_ConfigStream(
            &fs,
            XE_NP_LEGACY_FS_PRIMARY_STREAM_ID,
            xe_np_legacy_fs.primary_mgr,
            gpioe_rate);
        (void)CE32_File_FileStream_ConfigStream(
            &fs,
            XE_NP_LEGACY_FS_SECONDARY_STREAM_ID,
            xe_np_legacy_fs.secondary_mgr,
            gpiod_rate);
    }
    else
    {
        xe_np_legacy_fs.primary_mgr = (gpioe_rate != 0U) ?
            &runtime->capture.gpioe.raw_mgr :
            &runtime->capture.gpiod.raw_mgr;
        (void)CE32_File_FileStream_ConfigStream(
            &fs,
            XE_NP_LEGACY_FS_PRIMARY_STREAM_ID,
            xe_np_legacy_fs.primary_mgr,
            (gpioe_rate != 0U) ? gpioe_rate : gpiod_rate);
    }

    dataMGR_init(
        &xe_np_legacy_fs.trigger_mgr,
        (char *)xe_np_legacy_fs.primary_mgr->dataPtr,
        xe_np_legacy_fs.primary_mgr->dataSize);
    xe_np_legacy_fs.trigger_mgr.bufferUsed[0] = 0U;
    xe_np_legacy_fs.trigger_mgr.outPTR[0] = 0U;
    (void)CE32_File_FileStream_ConfigStream(
        &fs,
        CE32_FILE_BUFFERID_MISC,
        &xe_np_legacy_fs.trigger_mgr,
        0U);

    if(adc_rate != 0U)
    {
        dataMGR_ArmConsumer(&ADC_handle.MGR, 0U);
        (void)CE32_File_FileStream_ConfigStream(
            &fs,
            CE32_FILE_BUFFERID_ADC,
            &ADC_handle.MGR,
            adc_rate);
    }

    XE_NP_LegacyFs_RecordDiag(XE_NP_LEGACY_FS_DIAG_STEP_INIT_ENTER, runtime);
    init_result = CE32_File_FileStream_Init(
        &fs,
        NULL,
        &runtime->sys_param,
        &runtime->sys_log,
        &runtime->dsp_param[0],
        1);
    xe_np_legacy_fs_diag.init_result = (uint32_t)init_result;
    if(init_result != 0)
    {
        XE_NP_LegacyFs_RecordDiag(XE_NP_LEGACY_FS_DIAG_STEP_INIT_FAIL, runtime);
        return -1;
    }

    XE_NP_LegacyFs_SyncMetadata(runtime);
    fs.power_save = 0U;
    CE32_File_FileStream_PowerSave(&fs, 0);
    XE_NP_LegacyFs_UpdateRawConsumers(runtime);
    xe_np_legacy_fs.initialized = 1U;
    XE_NP_LegacyFs_RecordDiag(XE_NP_LEGACY_FS_DIAG_STEP_INIT_OK, runtime);
    return 0;
}

void XE_NP_LegacyFs_Init(XE_NP_Runtime *runtime)
{
    memset(&xe_np_legacy_fs, 0, sizeof(xe_np_legacy_fs));
    xe_np_legacy_fs.runtime = runtime;
}

void XE_NP_LegacyFs_Stop(void)
{
    if(xe_np_legacy_fs.active != 0U)
    {
        (void)CE32_File_FileStream_StopAndSave(&fs);
    }

    if(xe_np_legacy_fs.primary_mgr != NULL)
    {
        dataMGR_DisarmConsumer(xe_np_legacy_fs.primary_mgr, 0U);
    }
    if(xe_np_legacy_fs.secondary_mgr != NULL)
    {
        dataMGR_DisarmConsumer(xe_np_legacy_fs.secondary_mgr, 0U);
    }
    if(ADC_handle.MGR.dataPtr != NULL)
    {
        dataMGR_DisarmConsumer(&ADC_handle.MGR, 0U);
    }

    memset(&xe_np_legacy_fs, 0, sizeof(xe_np_legacy_fs));
    memset(&fs, 0, sizeof(fs));
}

void XE_NP_LegacyFs_Abort(void)
{
    XE_NP_LegacyFs_RecordDiag(XE_NP_LEGACY_FS_DIAG_STEP_ABORT, xe_np_legacy_fs.runtime);

    if(xe_np_legacy_fs.active != 0U)
    {
        if((fs.block_transfer != 0U) || (fs.data_transfering != 0U))
        {
            (void)HD32_SD_stopTrans();
        }

        fs.block_transfer = 0U;
        fs.data_transfering = 0U;
        fs.stop_pending = 0U;
        fs.stop_requested = 0U;
        (void)CE32_File_FileStream_PostStop(&fs);
    }

    if(xe_np_legacy_fs.primary_mgr != NULL)
    {
        dataMGR_DisarmConsumer(xe_np_legacy_fs.primary_mgr, 0U);
    }
    if(xe_np_legacy_fs.secondary_mgr != NULL)
    {
        dataMGR_DisarmConsumer(xe_np_legacy_fs.secondary_mgr, 0U);
    }
    if(ADC_handle.MGR.dataPtr != NULL)
    {
        dataMGR_DisarmConsumer(&ADC_handle.MGR, 0U);
    }

    memset(&xe_np_legacy_fs, 0, sizeof(xe_np_legacy_fs));
    memset(&fs, 0, sizeof(fs));
}

int XE_NP_LegacyFs_IsActive(void)
{
    return (xe_np_legacy_fs.active != 0U) ? 1 : 0;
}

void XE_NP_LegacyFs_OnSdError(void)
{
    if((xe_np_legacy_fs.active != 0U) && (fs.data_transfering != 0U))
    {
        fs.data_transfering = 0U;
        fs.evt_next = evt_transERR;
    }
    XE_NP_LegacyFs_RecordDiag(XE_NP_LEGACY_FS_DIAG_STEP_SD_ERROR, xe_np_legacy_fs.runtime);
}

void XE_NP_LegacyFs_Service(XE_NP_Runtime *runtime)
{
    if(runtime == NULL)
    {
        return;
    }

    if(XE_NP_LegacyFs_RuntimeReady(runtime) == 0)
    {
        XE_NP_LegacyFs_RecordDiag(XE_NP_LEGACY_FS_DIAG_STEP_RUNTIME_NOT_READY, runtime);
        if(xe_np_legacy_fs.active != 0U)
        {
            XE_NP_LegacyFs_Abort();
        }
        return;
    }

    if(xe_np_legacy_fs.initialized == 0U)
    {
        if(XE_NP_LegacyFs_Configure(runtime) != 0)
        {
            return;
        }
    }

    if(xe_np_legacy_fs.active == 0U)
    {
        int start_result;

        XE_NP_LegacyFs_SyncMetadata(runtime);
        XE_NP_LegacyFs_RecordDiag(XE_NP_LEGACY_FS_DIAG_STEP_START_ENTER, runtime);
        start_result = CE32_File_FileStream_Init_StartNewFile(&fs);
        xe_np_legacy_fs_diag.start_result = (uint32_t)start_result;
        if(start_result != 0)
        {
            XE_NP_LegacyFs_RecordDiag(XE_NP_LEGACY_FS_DIAG_STEP_START_FAIL, runtime);
            return;
        }
        xe_np_legacy_fs.active = 1U;
        XE_NP_LegacyFs_RecordDiag(XE_NP_LEGACY_FS_DIAG_STEP_START_OK, runtime);
    }

    HD32_SD_Service();
    if((xe_np_legacy_fs.active != 0U) && (fs.data_transfering != 0U) &&
       (SD_DMA_TX->NDTR == 0U))
    {
        /*
         * After the U5 SD shim only drops compat NDTR once the card is back in
         * TRANSFER state, promote the legacy completion edge immediately
         * instead of waiting for the old multi-pass guard in CheckTransfer().
         */
        CE32_File_FileStream_TransferCompleteCallback(&fs);
    }
    XE_NP_LegacyFs_UpdateRawConsumers(runtime);
    XE_NP_LegacyFs_UpdateTriggerMirror();
    (void)CE32_File_FileStream_exec(&fs);

    if(fs.enabled == 0U)
    {
        xe_np_legacy_fs.active = 0U;
        XE_NP_LegacyFs_RecordDiag(XE_NP_LEGACY_FS_DIAG_STEP_FS_DISABLED, runtime);
    }
}
