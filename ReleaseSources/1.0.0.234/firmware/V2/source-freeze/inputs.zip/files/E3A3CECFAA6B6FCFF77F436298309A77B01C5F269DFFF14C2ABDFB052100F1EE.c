#include "xe_np_np2_grid16_runtime.h"
#include <string.h>

void XE_NP_Grid16Runtime_Init(XE_NP_Grid16Runtime *o)
{if(o){memset(o,0,sizeof(*o));XE_NP_GridRuntime_Init(&o->runtime);XE_NP_GridProvider_Init(&o->provider);}}
static int qualified(const XE_NP_Grid16Runtime *o)
{return o->qualify && o->qualify(o->qualify_context,&o->identity)==1;}
static void fault(XE_NP_Grid16Runtime *o)
{
    if(!o || !o->started || o->stopped)return;
    o->fault=1U;XE_NP_GridRuntime_ClockFault(&o->runtime);
    if(o->attached)XE_NP_GridProvider_Finish(&o->provider,0,0U);
    else XE_NP_GridRuntime_Stop(&o->runtime,0,0U);
    o->stopped=1U;
}
int XE_NP_Grid16Runtime_Start(XE_NP_Grid16Runtime *o,const XE_NP_GridWireContext *id,
    XE_NP_Grid16Qualify q,void *context,uint64_t ordinal)
{
    if(!o || !id || !q || o->started || !id->domain || !id->generation || !id->epoch ||
       !id->session || !id->token || ordinal==UINT64_MAX)return 0;
    o->identity=*id;o->qualify=q;o->qualify_context=context;
    if(!qualified(o) || !XE_NP_GridRuntime_Prepare(&o->runtime,id->domain,id->generation,id->epoch,100U))return 0;
    if(!qualified(o)){XE_NP_GridRuntime_Stop(&o->runtime,0,0U);o->fault=1U;return 0;}
    if(!XE_NP_GridRuntime_Start(&o->runtime,ordinal)){o->fault=1U;return 0;}
    o->started=1U;return 1;
}
int XE_NP_Grid16Runtime_Attach(XE_NP_Grid16Runtime *o,const uint8_t *receipt,uint32_t n,
    const uint8_t *anchor,uint32_t an,uint64_t base,uint32_t continuous,uint32_t copy_bound)
{
    if(!o || !o->started || o->stopped || o->attached)return 0;
    if(!qualified(o)){fault(o);return 0;}
    if(!XE_NP_GridProvider_Attach(&o->provider,&o->runtime,&o->identity,
       receipt,n,anchor,an,base,continuous,copy_bound)){
        o->fault=1U;XE_NP_GridRuntime_Stop(&o->runtime,0,0U);o->stopped=1U;return 0;
    }
    o->attached=1U;return 1;
}
static int grid16_next(XE_NP_Grid16Runtime *o,uint8_t *body,uint32_t cap,
    uint32_t *type,uint32_t *bytes,uint64_t *source,uint32_t partial)
{
    if(!o || !o->attached)return -1;
    if(o->provider.inflight)return 0;
    if(!o->stopped && !qualified(o))fault(o);
    int result=XE_NP_GridProvider_Next(&o->provider,body,cap,type,bytes,source,o->stopped || partial);
    if(result<0 || result==2){
        o->fault=1U;
        if(!o->stopped){XE_NP_GridProvider_Finish(&o->provider,0,0U);o->stopped=1U;}
    }
    return result;
}
int XE_NP_Grid16Runtime_Next(XE_NP_Grid16Runtime *o,uint8_t *b,uint32_t cap,uint32_t *t,uint32_t *n,uint64_t *s)
{return grid16_next(o,b,cap,t,n,s,0U);}
int XE_NP_Grid16Runtime_NextPartial(XE_NP_Grid16Runtime *o,uint8_t *b,uint32_t cap,uint32_t *t,uint32_t *n,uint64_t *s)
{return grid16_next(o,b,cap,t,n,s,1U);}
void XE_NP_Grid16Runtime_Complete(XE_NP_Grid16Runtime *o,uint32_t type,uint32_t delivered)
{if(o && o->attached)XE_NP_GridProvider_Complete(&o->provider,type,delivered);}
void XE_NP_Grid16Runtime_Stop(XE_NP_Grid16Runtime *o)
{
    if(!o || !o->started || o->stopped)return;
    if(!qualified(o)){fault(o);return;}
    if(o->attached)XE_NP_GridProvider_Finish(&o->provider,0,0U);
    else XE_NP_GridRuntime_Stop(&o->runtime,0,0U);
    o->stopped=1U;
}
int XE_NP_Grid16Runtime_CanReuse(const XE_NP_Grid16Runtime *o)
{return o && (!o->started || (o->stopped && (!o->attached ||
    (o->provider.terminal_done && !o->provider.inflight && !o->provider.incomplete))));}
