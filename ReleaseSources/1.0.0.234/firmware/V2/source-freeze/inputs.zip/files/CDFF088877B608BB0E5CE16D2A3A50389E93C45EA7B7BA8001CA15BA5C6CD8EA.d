C:\Frank\Code\USB_PCconsole\_artifacts\closed_loop_20261102\V2\build-app\xe_np_np2_closed_loop_runtime.o: \
  D:\Code\XE_NP_V2\Core\Src\xe_np_np2_closed_loop_runtime.c \
  D:\Code\XE_NP_V2\Core\Inc\xe_np_np2_closed_loop_carrier.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\stdint.h \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Inc\np_cl_kernel.h \
  D:\Code\XE_NP_V2\Core\Inc\xe_np_np2_closed_loop_spi.h \
  D:\Code\XE_NP_V2\Core\Inc\xe_np_np2_closed_loop_perf.h
