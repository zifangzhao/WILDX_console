#ifndef XE_NP_NP2_CLOSED_LOOP_SD_H
#define XE_NP_NP2_CLOSED_LOOP_SD_H

#ifndef XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
#define XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE 0U
#endif
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE != 0U && XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE != 1U
#error "Closed-loop SD metadata opt-in must be 0 or 1"
#endif

#define XE_NP_NP2_CL_SD_VERSION 15U
#define XE_NP_NP2_CL_SD_FLAG 0x80U
#define XE_NP_NP2_CL_SD_MARKER 0x314D4C43U /* CLM1 */

#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
#include "xe_np_np2_sd_append.h"
#include "xe_np_np2_closed_loop_carrier.h"

/* Cold/stopped metadata only; decoding uses private 512-byte sector copies.
 * Linking this codec never opts legacy v11/v12/v13/v14 sessions into v15.
 * Descriptor132 binds the confirmed NPCC wire CRC (independent of config76);
 * 136 names the exact base codec, 140 is CLM1, and 144..507 remain zero.
 * Footer132/136 retain append counts only for base14; 140 is zero;
 * NPCLEND1 occupies144..207 and 208..507 remain zero. Both outer CRCs are
 * mandatory. AU128 and every legacy field/geometry/state rule are retained. */
int XE_NP_Np2ClSd_EncodeDescriptor(uint8_t out[512],
    const XE_NP_Np2DualSdMeta *meta,uint32_t base_version,uint32_t config_crc);
int XE_NP_Np2ClSd_DecodeDescriptor(const uint8_t in[512],
    XE_NP_Np2DualSdMeta *meta,uint32_t *base_version,uint32_t *config_crc);

/* Nonappend bases require equal physical/prefix/high-water counts.
 * A NULL/all-zero summary is an unfinalized checkpoint, accepted only when
 * explicitly allowed for initial RESERVED or FAILED/VERIFY_PENDING only.
 * Normal final footers require
 * a strict session/NPCC-CRC-bound NPCLEND1 summary. No input is modified. */
int XE_NP_Np2ClSd_EncodeFooter(uint8_t out[512],const uint8_t descriptor[512],
    uint32_t state,uint32_t error,const XE_NP_Np2SdAppendCounts *counts,
    const uint8_t summary[64],int allow_unfinalized);
int XE_NP_Np2ClSd_DecodeFooter(const uint8_t descriptor[512],const uint8_t footer[512],
    int allow_prefix_recovery,uint32_t *state,uint32_t *error,
    XE_NP_Np2SdAppendCounts *counts,XE_NP_Np2ClCarrierStatus *summary_status,
    int *drops_unknown);
/* Decode outputs change only on success. With an absent recovered summary,
 * status contains only its descriptor session/CRC binding (stopped=0);
 * drops_unknown=1. A present summary's delivery-unknown flag also propagates. */
#endif
#endif
