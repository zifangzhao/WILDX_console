#include "xe_np_np2_preview.h"
#include <string.h>
static uint32_t get(const uint8_t *b){uint32_t v;memcpy(&v,b,4);return v;}
static void put(uint8_t *b,uint32_t v){memcpy(b,&v,4);}
static uint32_t crc_bytes(const uint8_t *b,uint32_t bytes){uint32_t c=~0U;for(uint32_t n=0;n<bytes;n++){c^=b[n];for(unsigned k=0;k<8;k++)c=(c>>1)^((0U-(c&1U))&0xedb88320U);}return ~c;}
static uint32_t crc(const uint8_t *b){return crc_bytes(b,60U);}
#include "xe_np_np2_preview_multi.inc"
void XE_NP_Np2Preview_Drop(XE_NP_Np2Preview *p,uint32_t reason)
{
    if(p->kind==NP2_PREVIEW_FILTERED){np2_multi_drop(p,reason);return;}
    if(p->streaming){p->streaming=p->active=p->ready=p->queued=0;return;}
    p->active=0;p->ready=1;p->error=reason;p->total=p->used=p->offset=0;
}
int XE_NP_Np2Preview_Request(XE_NP_Np2Preview *p,const uint8_t *b,uint32_t session,uint32_t hz,int recording,uint32_t now)
{
    if(get(b)!=NP2_PREVIEW_MAGIC || get(b+4)!=1 || !get(b+12) || get(b+60)!=crc(b))return 0;
    uint32_t new_kind=get(b+8);
    if(new_kind>=NP2_PREVIEW_FILTERED && new_kind<=NP2_PREVIEW_CAPABILITY)
        return np2_multi_request(p,b,session,hz,recording,now);
    uint32_t kind=get(b+8),invalid=0;for(unsigned i=32;i<60;i++)invalid|=b[i];
    /* STOP/lease refresh only affect the matching subscription. No reply,
     * replay, re-arm on refresh, or retry backlog. Lease bounds disconnect. */
    if(kind==3 || kind==4){
        if(!invalid && p->streaming && get(b+12)==p->id && get(b+28)==p->session &&
           get(b+16)==p->probe && get(b+20)==p->channel && get(b+24)==p->phase){
            if(kind==3)XE_NP_Np2Preview_Drop(p,5);
            else if(recording && session==p->session)p->lease=now+2000U;
        }
        return 1;
    }
    /* Busy/rate-limited requests are dropped, not queued or replayed. */
    if(p->active || p->ready || (p->last_request && now-p->last_request<500))return 1;
    p->last_request=now;p->id=get(b+12);p->kind=get(b+8);p->probe=get(b+16);
    p->channel=get(b+20);p->phase=get(b+24);p->session=session;p->hz=hz;
    p->total=p->kind?3072:3200;p->used=p->offset=p->error=p->word_bytes=0;
    p->first=p->next=p->expected=0;
    if(invalid || (p->kind>2 && p->kind!=NP2_PREVIEW_SINGLE_CHANNEL) || p->probe<1 || p->probe>2 || p->channel>=384 || p->phase>=1600){XE_NP_Np2Preview_Drop(p,1);return 1;}
    if(!recording || !session || (hz!=15000 && hz!=20000 && hz!=30000
#if XE_NP_NP2_DUAL_SD_APP_ENABLE && XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
       && hz!=7500
#endif
       )){XE_NP_Np2Preview_Drop(p,2);return 1;}
    if(p->kind && get(b+28)!=session){XE_NP_Np2Preview_Drop(p,3);return 1;}
    p->last_valid=0;
    if(p->kind==2 || p->kind==NP2_PREVIEW_SINGLE_CHANNEL){
        p->streaming=1;p->stride=(hz/NP2_PREVIEW_HZ)*1600U;p->lease=now+2000U;
        p->write_slot=p->read_slot=p->queued=p->armed=p->dropped=p->bad_word=0;
        p->total=NP2_PREVIEW_FRAGMENT;
    }
    p->active=1;p->deadline=now+250;return 1;
}
static void stream_tap(XE_NP_Np2Preview *p,const uint8_t *raw,uint32_t bytes,uint64_t first,int pressure)
{
    const uint32_t single=p->kind==NP2_PREVIEW_SINGLE_CHANNEL;
    uint64_t end=first+bytes;
    if(!raw || !bytes || (p->expected && first!=p->expected)){
        /* Discard a partial packet, never concatenate across missing samples. */
        p->used=p->word_bytes=p->bad_word=0;p->armed=0;p->dropped++;p->expected=end;return;
    }
    p->expected=end;
    if(!p->armed){
        uint32_t c=p->channel%128,word=(1600-p->phase+(c%32)/2*100+4+((c/32)*2+(c&1))*12)%1600;
        p->next=first+(word+1600-(uint32_t)(first%1600))%1600;p->armed=1;
    }
    if(p->next>=end)return;
    if(p->queued==NP2_PREVIEW_STREAM_SLOTS){
        p->armed=0;p->dropped++;return; /* TX stalled: no waiting or overwrite. */
    }
    /* At 20/30k there is normally at most one 12-byte copy in a 16-KiB
     * retained source span. The loop also handles small split test spans. */
    while(p->next<end){
        uint8_t *slot=p->data+p->write_slot*NP2_PREVIEW_FRAGMENT;
        if(!p->used){
            p->slot_first[p->write_slot]=p->next;p->slot_mask[p->write_slot]=0;
            if(single){memset(slot,0,NP2_PREVIEW_FRAGMENT);put(slot,NP2_PREVIEW_HZ);put(slot+4,NP2_PREVIEW_SINGLE_ROWS);}
        }
        uint32_t n=12U-p->word_bytes;
        if(p->next+n>end)n=(uint32_t)(end-p->next);
        /* A validity bit preserves the nominal 500-Hz timeline when a sample
         * is skipped for recording pressure. No synthetic replacement value. */
        if(pressure)p->bad_word=1;
        else if(!p->bad_word){
            if(single){
                /* Keep one lane's 12 serial bits, NOT a decoded/filtered ADC
                 * sample. Subsample only; all decoding remains on the PC. */
                uint32_t at=16U+(p->used/12U)*2U,word=slot[at]|((uint32_t)slot[at+1U]<<8);
                uint32_t shift=(p->probe-1U)*3U+p->channel/128U;
                for(uint32_t i=0;i<n;i++)word|=((uint32_t)(raw[(uint32_t)(p->next-first)+i]>>shift)&1U)<<(p->word_bytes+i);
                slot[at]=(uint8_t)word;slot[at+1U]=(uint8_t)(word>>8);
            }else memcpy(slot+p->used,raw+(uint32_t)(p->next-first),n);
        }
        p->used+=n;p->word_bytes+=n;p->next+=n;
        if(p->word_bytes==12){
            if(!p->bad_word){
                uint32_t row=p->used/12U-1U;
                if(single){uint32_t at=8U+(row/32U)*4U;put(slot+at,get(slot+at)|(1U<<(row%32U)));}
                else p->slot_mask[p->write_slot]|=1U<<row;
            }
            else p->dropped++;
            p->word_bytes=p->bad_word=0;p->next+=p->stride-12U;
        }
        if(p->used==(single?NP2_PREVIEW_SINGLE_ROWS*12U:NP2_PREVIEW_FRAGMENT)){
            if(single?!(get(slot+8)|get(slot+12)):!p->slot_mask[p->write_slot]){p->used=0;continue;}
            p->last_slot=p->write_slot;p->last_valid=1;
            p->write_slot=(p->write_slot+1U)%NP2_PREVIEW_STREAM_SLOTS;
            p->used=0;p->queued++;p->ready=1;
            if(p->queued==NP2_PREVIEW_STREAM_SLOTS)return;
        }
    }
}
void XE_NP_Np2Preview_Tap(XE_NP_Np2Preview *p,const uint8_t *raw,uint32_t bytes,uint64_t first,int pressure)
{
    if(!p->active)return;
    if(p->kind==NP2_PREVIEW_FILTERED){np2_multi_tap(p,raw,bytes,first,pressure);return;}
    if(p->streaming){stream_tap(p,raw,bytes,first,pressure);return;}
    if(pressure || !raw || !bytes || (p->expected && first!=p->expected)){XE_NP_Np2Preview_Drop(p,4);return;}
    p->expected=first+bytes;
    if(!p->used && !p->word_bytes){
        if(!p->kind)p->first=first;
        else {
            uint32_t c=p->channel%128,word=(1600-p->phase+(c%32)/2*100+4+((c/32)*2+(c&1))*12)%1600;
            p->next=first+(word+1600-(uint32_t)(first%1600))%1600;
            p->first=p->next;
        }
    }
    if(!p->kind){
        uint32_t n=p->total-p->used;if(n>bytes)n=bytes;
        memcpy(p->data+p->used,raw,n);p->used+=n;
    }else while(p->used<p->total && p->next<p->expected){
        /* At most eleven 12-byte snippets per existing <=16-KiB owned span.
         * No buffer pin, wait, phase search, bit decode or additional IRQ. */
        uint32_t n=12-p->word_bytes;
        if(p->next+n>p->expected)n=(uint32_t)(p->expected-p->next);
        memcpy(p->data+p->used,raw+(uint32_t)(p->next-first),n);
        p->used+=n;p->word_bytes+=n;p->next+=n;
        if(p->word_bytes==12){p->word_bytes=0;p->next+=1588;}
    }
    if(p->used==p->total){p->active=0;p->ready=1;}
}
int XE_NP_Np2Preview_Fragment(XE_NP_Np2Preview *p,uint8_t *b)
{
    if(!p->ready)return 0;
    if(p->kind==NP2_PREVIEW_FILTERED || p->kind==NP2_PREVIEW_CAPABILITY)return np2_multi_fragment(p,b);
    if(p->streaming){
        uint64_t first=p->slot_first[p->read_slot];
        put(b,NP2_PREVIEW_MAGIC);put(b+4,p->id);put(b+8,p->session);put(b+12,p->hz);
        put(b+16,(uint32_t)first);put(b+20,(uint32_t)(first>>32));
        put(b+24,(NP2_PREVIEW_FRAGMENT<<16)|(p->kind==NP2_PREVIEW_SINGLE_CHANNEL?NP2_PREVIEW_SINGLE_ROWS:p->slot_mask[p->read_slot]));
        put(b+28,p->probe|((p->kind|NP2_PREVIEW_KIND_SIX_BIT_BYTES)<<8)|(p->channel<<16));
        if(p->kind==NP2_PREVIEW_SINGLE_CHANNEL)memcpy(b+32,p->data+p->read_slot*NP2_PREVIEW_FRAGMENT,NP2_PREVIEW_FRAGMENT);
        else for(uint32_t i=0U;i<NP2_PREVIEW_FRAGMENT;i++)b[32U+i]=(uint8_t)(p->data[p->read_slot*NP2_PREVIEW_FRAGMENT+i]&0x3fU);
        p->read_slot=(p->read_slot+1U)%NP2_PREVIEW_STREAM_SLOTS;
        p->queued--;p->ready=p->queued!=0;return 1;
    }
    put(b,NP2_PREVIEW_MAGIC);put(b+4,p->id);put(b+8,p->session);put(b+12,p->hz);
    put(b+16,(uint32_t)p->first);put(b+20,(uint32_t)(p->first>>32));
    put(b+24,p->offset|(p->total<<16));
    put(b+28,p->probe|((p->error?128U|p->error:p->kind|NP2_PREVIEW_KIND_SIX_BIT_BYTES)<<8)|(p->channel<<16));
    uint32_t n=p->total-p->offset;if(n>NP2_PREVIEW_FRAGMENT)n=NP2_PREVIEW_FRAGMENT;
    for(uint32_t i=0U;i<n;i++)b[32U+i]=(uint8_t)(p->data[p->offset+i]&0x3fU);
    memset(b+32+n,0,NP2_PREVIEW_FRAGMENT-n);
    p->offset+=n;if(p->offset==p->total)p->ready=0;
    return 1;
}
uint32_t XE_NP_Np2Preview_VerifyPacked(const XE_NP_Np2Preview *p,uint32_t session,
    const uint8_t *packed,uint64_t first,uint32_t ticks,uint32_t *mismatched)
{
    /* No capture/IRQ caller. Keep stale-session filtering here rather than
     * adding a session comparison to every retained DMA span. */
    if(!mismatched)return 0;
    *mismatched=0;
    if(!p || !packed || !session || p->session!=session || p->error ||
       p->probe<1U || p->probe>2U || (p->kind>2U && p->kind!=NP2_PREVIEW_SINGLE_CHANNEL) ||
       !ticks || ticks>UINT32_MAX/6U || first>UINT64_MAX-ticks)return 0;
    const uint8_t *data=p->data;
    uint64_t origin=p->first;
    uint32_t total=p->total,stride=1600U;
    if(p->kind==2U || p->kind==NP2_PREVIEW_SINGLE_CHANNEL){
        if(!p->last_valid || p->last_slot>=NP2_PREVIEW_STREAM_SLOTS || !p->stride)return 0;
        data+=p->last_slot*NP2_PREVIEW_FRAGMENT;
        origin=p->slot_first[p->last_slot];total=NP2_PREVIEW_FRAGMENT;stride=p->stride;
    }else if(p->used!=total || !total || total>NP2_PREVIEW_BYTES ||
             (p->kind && total%12U))return 0;
    const uint32_t single=p->kind==NP2_PREVIEW_SINGLE_CHANNEL;
    if(single)total=NP2_PREVIEW_SINGLE_ROWS*12U;
    uint64_t span=p->kind?(uint64_t)(total/12U-1U)*stride+12U:total;
    if(origin>UINT64_MAX-span || origin+span<=first || origin>=first+ticks)return 0;
    uint32_t checked=0,shift=(p->probe-1U)*3U;
    for(uint32_t i=0;i<total;i++){
        if(single){uint32_t row=i/12U;if(!(get(data+8U+(row/32U)*4U)&(1U<<(row%32U))))continue;}
        else if(p->kind==2U && !(p->slot_mask[p->last_slot]&(1U<<(i/12U))))continue;
        uint64_t tick=origin+(p->kind?(uint64_t)(i/12U)*stride+i%12U:i);
        if(tick<first || tick>=first+ticks)continue;
        uint32_t bit=(uint32_t)(tick-first)*6U,at=bit/8U,offset=bit&7U;
        uint32_t raw=packed[at]>>offset;
        if(offset>2U)raw|=(uint32_t)packed[at+1U]<<(8U-offset);
        checked++;
        if(single){
            uint32_t sample_at=16U+(i/12U)*2U,word=data[sample_at]|((uint32_t)data[sample_at+1U]<<8);
            if(((raw>>(shift+p->channel/128U))&1U)!=((word>>(i%12U))&1U))(*mismatched)++;
        }else if(((raw>>shift)&7U)!=((data[i]>>shift)&7U))(*mismatched)++;
    }
    return checked;
}
