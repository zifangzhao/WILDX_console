#ifndef XE_NP_NP2_D8_CALIBRATION_H
#define XE_NP_NP2_D8_CALIBRATION_H
#include <stdint.h>

#define XE_NP_NP2_D8_CALIBRATION_PERIOD 1600U
#define XE_NP_NP2_D8_CALIBRATION_INSPECT 4800U
#define XE_NP_NP2_D8_CALIBRATION_BYTES 800U
#ifndef XE_NP_NP2_D8_ROBUST_PSSI_SYNC
#define XE_NP_NP2_D8_ROBUST_PSSI_SYNC 0U
#endif
#ifndef XE_NP_NP2_D8_NEAR_ZERO_OFFSET
#define XE_NP_NP2_D8_NEAR_ZERO_OFFSET 0U
#endif

typedef struct {
    uint32_t pssi_phase,pssi_matches;
    uint32_t d8_offset,d8_matches;
    uint32_t pssi_best_score,pssi_runner_score;
    uint32_t d8_best_score,d8_runner_score;
} XE_NP_Np2D8Calibration;

static inline uint8_t XE_NP_Np2D8ExpectedSync(uint32_t position)
{
    static const uint8_t super_sync[12]={0xD3U,0x6AU,0x59U,0xC5U,0x3EU,0xA7U,
                                         0x1DU,0xE4U,0xB2U,0x4FU,0x78U,0x96U};
    uint32_t frame=position/100U,bit=position%100U;
    if(bit==0U)return frame==0U?7U:0U;
    if(bit==1U)return 0U;
    uint8_t wire=0U;
    for(uint32_t line=0U;line<3U;line++) {
        uint32_t at=frame*6U+line*2U+bit-2U;
        wire|=(uint8_t)(((super_sync[at/8U]>>(at&7U))&1U)<<line);
    }
    return wire;
}

#if XE_NP_NP2_D8_ROBUST_PSSI_SYNC
static inline uint32_t XE_NP_Np2PssiSyncScore(const uint8_t *samples,
    const uint8_t expected[16][4],uint32_t phase)
{
    uint32_t score=0U;
    for(uint32_t frame=0U;frame<16U;frame++){
        for(uint32_t sync_tick=0U;sync_tick<4U;sync_tick++){
            uint32_t position=frame*100U+sync_tick;
            uint32_t tick=position+XE_NP_NP2_D8_CALIBRATION_PERIOD-phase;
            if(tick>=XE_NP_NP2_D8_CALIBRATION_PERIOD)
                tick-=XE_NP_NP2_D8_CALIBRATION_PERIOD;
            uint8_t wanted=expected[frame][sync_tick]&3U;
            for(;tick<XE_NP_NP2_D8_CALIBRATION_INSPECT;
                tick+=XE_NP_NP2_D8_CALIBRATION_PERIOD)
                score+=((samples[tick]>>6U)&3U)==wanted;
        }
    }
    return score;
}

static inline uint32_t XE_NP_Np2D8SyncScore(const uint8_t *samples,
    const uint8_t expected[16][4],uint32_t phase,uint32_t offset)
{
    uint32_t score=0U;
    for(uint32_t frame=0U;frame<16U;frame++){
        for(uint32_t sync_tick=0U;sync_tick<4U;sync_tick++){
            uint32_t position=frame*100U+sync_tick;
            uint32_t tick=position+XE_NP_NP2_D8_CALIBRATION_PERIOD-phase;
            if(tick>=XE_NP_NP2_D8_CALIBRATION_PERIOD)
                tick-=XE_NP_NP2_D8_CALIBRATION_PERIOD;
            uint32_t wanted=(expected[frame][sync_tick]>>2U)&1U;
            for(;tick<XE_NP_NP2_D8_CALIBRATION_INSPECT;
                tick+=XE_NP_NP2_D8_CALIBRATION_PERIOD){
                uint32_t bit=offset+tick;
                score+=((samples[bit>>3U]>>(bit&7U))&1U)==wanted;
            }
        }
    }
    return score;
}
#endif

/* Strictly identify PSSI phase and SPI-D8 offset from the repeated SuperSync.
 * Enumerate only the 4 sync ticks in each 100-tick frame, not all 1600 sample
 * positions. Each unique signature must agree over all three inspected
 * periods. */
static inline int XE_NP_Np2D8Calibration_Find(const uint8_t *pssi_samples,
    const uint8_t *d8_samples,uint32_t d8_bytes,uint32_t ticks,
    XE_NP_Np2D8Calibration *result)
{
    if(result){result->pssi_phase=UINT32_MAX;result->pssi_matches=0U;
        result->d8_offset=UINT32_MAX;result->d8_matches=0U;
        result->pssi_best_score=result->pssi_runner_score=0U;
        result->d8_best_score=result->d8_runner_score=0U;}
    if(!pssi_samples || !d8_samples || !result || ticks<XE_NP_NP2_D8_CALIBRATION_INSPECT ||
       d8_bytes<XE_NP_NP2_D8_CALIBRATION_BYTES)return -1;

    uint8_t expected[16][4];
    for(uint32_t frame=0U;frame<16U;frame++)
        for(uint32_t sync_tick=0U;sync_tick<4U;sync_tick++)
            expected[frame][sync_tick]=XE_NP_Np2D8ExpectedSync(frame*100U+sync_tick);

#if XE_NP_NP2_D8_ROBUST_PSSI_SYNC
    /* The opt-in damaged-sync diagnostic must finish before another capture
     * event needs service. Screen only 8 PSSI and 16 D8 observations, then
     * fully score candidates within one screen match of the leader. */
    static uint8_t screen_score[XE_NP_NP2_D8_CALIBRATION_PERIOD];
    uint32_t phase_screen=0U;
    for(uint32_t candidate=0U;candidate<XE_NP_NP2_D8_CALIBRATION_PERIOD;candidate++){
        uint32_t score=0U;
        for(uint32_t frame=0U;frame<16U;frame+=2U){
            uint32_t position=frame*100U+2U;
            uint32_t tick=position+XE_NP_NP2_D8_CALIBRATION_PERIOD-candidate;
            if(tick>=XE_NP_NP2_D8_CALIBRATION_PERIOD)
                tick-=XE_NP_NP2_D8_CALIBRATION_PERIOD;
            score+=((pssi_samples[tick]>>6U)&3U)==(expected[frame][2U]&3U);
            if(score+(14U-frame)/2U<6U)break;
        }
        screen_score[candidate]=(uint8_t)score;
        if(score>phase_screen)phase_screen=score;
    }
    if(phase_screen<5U)return -1;
    uint32_t phase=UINT32_MAX,phase_best=0U,phase_runner=0U,phase_matches=0U;
    for(uint32_t candidate=0U;candidate<XE_NP_NP2_D8_CALIBRATION_PERIOD;candidate++){
        if(screen_score[candidate]+1U<phase_screen)continue;
        uint32_t score=XE_NP_Np2PssiSyncScore(pssi_samples,expected,candidate);
        if(score>phase_best){phase_runner=phase_best;phase_best=score;
            phase=candidate;phase_matches=1U;}
        else if(score==phase_best){phase_runner=score;phase_matches++;}
        else if(score>phase_runner)phase_runner=score;
    }
    result->pssi_best_score=phase_best;
    result->pssi_runner_score=phase_runner;
    if(phase_matches!=1U || phase_best<164U || phase_best<phase_runner+32U)return -1;
    result->pssi_phase=phase;result->pssi_matches=1U;

#if XE_NP_NP2_D8_NEAR_ZERO_OFFSET
    /* SPI2 DMA is armed immediately before PSSI on this board. The bounded
     * raw-phase experiment has observed offsets 0 and -1 bit. Test a small
     * symmetric neighborhood; reject, rather than scan for milliseconds in
     * capture service, if the hardware lands elsewhere. */
    static const uint16_t near_zero_offsets[5]={1598U,1599U,0U,1U,2U};
    uint32_t offset=UINT32_MAX,offset_best=0U,offset_runner=0U,offset_matches=0U;
    for(uint32_t i=0U;i<5U;i++){
        uint32_t candidate=near_zero_offsets[i];
        uint32_t score=XE_NP_Np2D8SyncScore(d8_samples,expected,phase,candidate);
        if(score>offset_best){offset_runner=offset_best;offset_best=score;
            offset=candidate;offset_matches=1U;}
        else if(score==offset_best){offset_runner=score;offset_matches++;}
        else if(score>offset_runner)offset_runner=score;
    }
#else
    uint16_t d8_screen_tick[16];
    for(uint32_t frame=0U;frame<16U;frame++){
        uint32_t position=frame*100U+2U;
        uint32_t tick=position+XE_NP_NP2_D8_CALIBRATION_PERIOD-phase;
        if(tick>=XE_NP_NP2_D8_CALIBRATION_PERIOD)
            tick-=XE_NP_NP2_D8_CALIBRATION_PERIOD;
        d8_screen_tick[frame]=(uint16_t)tick;
    }
    uint32_t offset_screen=0U;
    for(uint32_t candidate=0U;candidate<XE_NP_NP2_D8_CALIBRATION_PERIOD;candidate++){
        uint32_t score=0U;
        for(uint32_t frame=0U;frame<16U;frame++){
            uint32_t bit=candidate+d8_screen_tick[frame];
            score+=((d8_samples[bit>>3U]>>(bit&7U))&1U)==
                ((expected[frame][2U]>>2U)&1U);
        }
        screen_score[candidate]=(uint8_t)score;
        if(score>offset_screen)offset_screen=score;
    }
    if(offset_screen<12U)return -1;
    uint32_t offset=UINT32_MAX,offset_best=0U,offset_runner=0U,offset_matches=0U;
    for(uint32_t candidate=0U;candidate<XE_NP_NP2_D8_CALIBRATION_PERIOD;candidate++){
        if(screen_score[candidate]+1U<offset_screen)continue;
        uint32_t score=XE_NP_Np2D8SyncScore(d8_samples,expected,phase,candidate);
        if(score>offset_best){offset_runner=offset_best;offset_best=score;
            offset=candidate;offset_matches=1U;}
        else if(score==offset_best){offset_runner=score;offset_matches++;}
        else if(score>offset_runner)offset_runner=score;
    }
#endif
    result->d8_best_score=offset_best;
    result->d8_runner_score=offset_runner;
    if(offset_matches!=1U || offset_best<168U || offset_best<offset_runner+16U)return -1;
    result->d8_offset=offset;result->d8_matches=1U;
    return 0;
#else
    uint32_t phase=UINT32_MAX,phase_matches=0U;
    for(uint32_t candidate=0U;candidate<XE_NP_NP2_D8_CALIBRATION_PERIOD;candidate++) {
        int exact=1;
        for(uint32_t frame=0U;frame<16U && exact;frame++) {
            for(uint32_t sync_tick=0U;sync_tick<4U && exact;sync_tick++) {
                uint32_t position=frame*100U+sync_tick;
                uint8_t want=expected[frame][sync_tick]&3U;
                uint32_t first=position>=candidate?position-candidate:
                    position+XE_NP_NP2_D8_CALIBRATION_PERIOD-candidate;
                for(uint32_t tick=first;tick<XE_NP_NP2_D8_CALIBRATION_INSPECT;
                    tick+=XE_NP_NP2_D8_CALIBRATION_PERIOD) {
                    if(((pssi_samples[tick]>>6U)&3U)!=want){exact=0;break;}
                }
            }
        }
        if(exact){phase=candidate;phase_matches++;}
    }
    result->pssi_phase=phase;result->pssi_matches=phase_matches;
    if(phase_matches!=1U)return -1;

    uint32_t offset=UINT32_MAX,offset_matches=0U;
    for(uint32_t candidate=0U;candidate<XE_NP_NP2_D8_CALIBRATION_PERIOD;candidate++) {
        int exact=1;
        for(uint32_t frame=0U;frame<16U && exact;frame++) {
            for(uint32_t sync_tick=0U;sync_tick<4U && exact;sync_tick++) {
                uint32_t position=frame*100U+sync_tick;
                uint32_t want=(expected[frame][sync_tick]>>2U)&1U;
                uint32_t first=position>=phase?position-phase:
                    position+XE_NP_NP2_D8_CALIBRATION_PERIOD-phase;
                for(uint32_t tick=first;tick<XE_NP_NP2_D8_CALIBRATION_INSPECT;
                    tick+=XE_NP_NP2_D8_CALIBRATION_PERIOD) {
                    uint32_t bit=candidate+tick;
                    if(((d8_samples[bit>>3U]>>(bit&7U))&1U)!=want){exact=0;break;}
                }
            }
        }
        if(exact){offset=candidate;offset_matches++;}
    }
    result->d8_offset=offset;result->d8_matches=offset_matches;
    return offset_matches==1U?0:-1;
#endif
}
#endif
