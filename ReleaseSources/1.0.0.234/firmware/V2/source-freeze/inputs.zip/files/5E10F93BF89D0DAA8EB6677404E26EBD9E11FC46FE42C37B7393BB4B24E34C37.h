#ifndef XE_NP_EP81_FAULT_SNAPSHOT_H
#define XE_NP_EP81_FAULT_SNAPSHOT_H
#include <stdint.h>

/* Lab only. Reset once while USB is idle; capture once at failure before any
 * stop/abort. Caller supplies an owned immutable software view and a live PCD
 * pointer. Hardware registers may advance during the snapshot: they are not
 * atomic and cannot establish host receipt or physical sample loss. */
#ifndef XE_NP_EP81_FAULT_SNAPSHOT
#define XE_NP_EP81_FAULT_SNAPSHOT 0U
#endif
typedef struct {
    uint32_t error,tick_ms,configured,streaming,active,tx_busy,tx_started_ms;
    uint32_t filled,submitted,completed,partial,segment,expected_buffer;
} XE_NP_Ep81FaultSoft;
enum { XE_NP_EP81_SOFT_VALID=1U, XE_NP_EP81_HW_VALID=2U,
       XE_NP_EP81_NULL_SOFT=4U, XE_NP_EP81_NULL_PCD=8U,
       XE_NP_EP81_WRONG_INSTANCE=16U, XE_NP_EP81_CLOCK_OFF=32U,
       XE_NP_EP81_HW_NONATOMIC=64U };
#if XE_NP_EP81_FAULT_SNAPSHOT
#if defined(XE_NP_EP81_SNAPSHOT_FAKE)
#include "test_ep81_snapshot_fake.h"
#else
#include "xe_np_hal.h"
#endif
typedef struct {
    uint32_t attempted,flags,rcc_ahb2enr1;
    XE_NP_Ep81FaultSoft soft;
    uint32_t pcd_instance,pcd_dma_enable,pcd_state,pcd_error;
    uint32_t ep_xfer_buffer,ep_xfer_len,ep_xfer_count,ep_dma_addr,ep_maxpacket;
    uint32_t gintsts,gintmsk,gahbcfg,dsts,daint,daintmsk,diepmsk;
    uint32_t diepctl,diepint,dieptsiz,diepdma,dtxfsts;
} XE_NP_Ep81FaultSnapshot;
extern volatile XE_NP_Ep81FaultSnapshot xe_np_ep81_fault_snapshot;
void XE_NP_Ep81Fault_Reset(void);
void XE_NP_Ep81Fault_Capture(const XE_NP_Ep81FaultSoft *soft,const PCD_HandleTypeDef *pcd);
#else
#define XE_NP_Ep81Fault_Reset(...) ((void)0)
#define XE_NP_Ep81Fault_Capture(...) ((void)0)
#endif
#endif
