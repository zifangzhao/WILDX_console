#ifndef XE_NP_NP2_READ_ONLY_DIAG_H
#define XE_NP_NP2_READ_ONLY_DIAG_H

#include <stdint.h>

/* SWD-visible status for the deliberately limited NP2 bring-up image.  This
 * image proves only clock/power/reset sequencing and I2C register reads.  It
 * does not write shift chains, enable recording, arm PSSI/DMA, or access SD. */
#define XE_NP_NP2_READ_ONLY_DIAG_MAGIC   0x4E503252UL /* "NP2R" */
/* V3 always reads all connector IDs; detail registers use the first valid bus.
 * V2 could leave later connector IDs unqueried after an earlier match. */
#define XE_NP_NP2_READ_ONLY_DIAG_VERSION 3UL

enum {
    XE_NP_NP2_READ_DIAG_INIT = 1U,
    XE_NP_NP2_READ_DIAG_POWER_WAIT,
    XE_NP_NP2_READ_DIAG_CLOCK_WAIT,
    XE_NP_NP2_READ_DIAG_RESET_WAIT,
    XE_NP_NP2_READ_DIAG_READ_ID,
    XE_NP_NP2_READ_DIAG_READ_ID_I2C3,
    XE_NP_NP2_READ_DIAG_READ_ID_I2C4,
    XE_NP_NP2_READ_DIAG_READ_OP,
    XE_NP_NP2_READ_DIAG_READ_REC,
    XE_NP_NP2_READ_DIAG_READ_CAL,
    XE_NP_NP2_READ_DIAG_READ_STATUS,
    XE_NP_NP2_READ_DIAG_READY,
    XE_NP_NP2_READ_DIAG_FAILED = 0xFFU
};

enum {
    XE_NP_NP2_READ_DIAG_ERROR_NONE = 0U,
    XE_NP_NP2_READ_DIAG_ERROR_CLOCK = 1U,
    XE_NP_NP2_READ_DIAG_ERROR_HSLV = 2U,
    XE_NP_NP2_READ_DIAG_ERROR_I2C_INIT = 3U,
    XE_NP_NP2_READ_DIAG_ERROR_MCO = 4U,
    XE_NP_NP2_READ_DIAG_ERROR_I2C_READ = 5U,
    XE_NP_NP2_READ_DIAG_ERROR_PROBE_ID = 6U
};

typedef struct {
    uint32_t magic, version, state, error;
    uint32_t hclk_hz, sysclk_hz, expected_mco_hz, sample_hz;
    uint32_t flash_optr, rcc_cfgr1;
    uint32_t started_ms, state_since_ms, i2c_error, i2c_reads;
    uint32_t id, op, rec, cal, status;
    uint32_t probe_bus, id_i2c2, id_i2c3, id_i2c4;
    uint32_t i2c2_error, i2c3_error, i2c4_error;
} XE_NP_Np2ReadOnlyDiag;

extern volatile XE_NP_Np2ReadOnlyDiag xe_np_np2_read_only_diag;

void XE_NP_Np2ReadOnlyDiag_Init(void);
void XE_NP_Np2ReadOnlyDiag_Service(void);

#endif
