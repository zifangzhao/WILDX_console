#include "xe_np_np2_first_sync_port.h"
#include "xe_np_np2_usb_source.h"
#include "xe_np_np2_usb_wire.h"
#include "xe_np_usb_aux.h"

#include <string.h>

#if XE_NP_NP2_USB_SOURCE_ENABLE

#include "main.h"
#include "xe_np_board.h"
#include "xe_np_np2_capture_port.h"
#include "xe_np_np2_diag_config.h"
#include "xe_np_np2_config.h"
#include "xe_np_np2_preparation.h"
#include "xe_np_np2_producer.h"

#include <string.h>

#if XE_NP_NP2_SD_UNUSED_PROBE_POWERDOWN_TEST && \
    (XE_NP_NP2_SD_UNUSED_PROBE_POWERDOWN_TEST != 1U || \
     !XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
     XE_NP_V2_MEDIA_ENABLE)
#error "Unused-probe power trial requires the runtime-profile neural SD APP"
#endif

#if (XE_NP_NP2_SD_SINGLE7500_I2C_CLOCK_GATE_TEST!=0U && \
     XE_NP_NP2_SD_SINGLE7500_I2C_CLOCK_GATE_TEST!=1U) || \
    (XE_NP_NP2_SD_SINGLE7500_I2C_CLOCK_GATE_TEST && \
     (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
      !XE_NP_NP2_SD_UNUSED_PROBE_POWERDOWN_TEST || XE_NP_V2_MEDIA_ENABLE))
#error "Setup I2C clock trial requires runtime neural SD and unused-probe teardown"
#endif

#ifndef XE_NP_NP2_SD_SETTLE_SLEEP_TEST
#define XE_NP_NP2_SD_SETTLE_SLEEP_TEST 0U
#endif
#if (XE_NP_NP2_SD_SETTLE_SLEEP_TEST!=0U && XE_NP_NP2_SD_SETTLE_SLEEP_TEST!=1U) || \
    (XE_NP_NP2_SD_SETTLE_SLEEP_TEST && \
     (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
      XE_NP_V2_MEDIA_ENABLE))
#error "Settle sleep requires the runtime neural SD APP"
#endif

extern I2C_HandleTypeDef hi2c2,hi2c3,hi2c4;

enum {
    NP2_I2C = 0x20U, NP2_EEPROM = 0xA0U,
    R_OP = 0x00U, R_REC = 0x01U, R_CAL = 0x02U, R_STATUS = 0x09U,
    R_SYNC = 0x0AU, R_BASE_ODD = 0x16U, R_BASE_EVEN = 0x17U,
    R_SHANK0 = 0x1BU, R_LENGTH_HI = 0x1CU, R_LENGTH_LO = 0x1DU,
    R_ID = 0x1EU, R_SOFT_RESET = 0x1FU,
    REC_HELD = 0x88U, REC_RELEASED = 0xC8U,
    OP_RECORD = XE_NP_NP2_SD_DIGITAL_PATTERN_TEST ? 0x50U : 0x40U,
    CHAIN_COUNT = 6U, EEPROM_BYTES = 84U, EEPROM_CHUNK = 4U
};
enum {
    STEP_ID, STEP_EEPROM, STEP_HOLD, STEP_HOLD_READ, STEP_CAL, STEP_CAL_READ,
    STEP_RESET_FF, STEP_RESET_ZERO, STEP_RESET_OP, STEP_RESET_REC,
    STEP_LENGTH_LO, STEP_LENGTH_LO_READ, STEP_LENGTH_HI, STEP_LENGTH_HI_READ,
    STEP_CHAIN, STEP_STATUS, STEP_FINAL_HOLD, STEP_FINAL_HOLD_READ,
    STEP_FINAL_CAL, STEP_FINAL_CAL_READ, STEP_SYNC, STEP_SYNC_READ,
    STEP_OP, STEP_OP_READ, STEP_RELEASE, STEP_RELEASE_READ
};

static const uint8_t supersync[12] = {
    0xD3U,0x6AU,0x59U,0xC5U,0x3EU,0xA7U,0x1DU,0xE4U,0xB2U,0x4FU,0x78U,0x96U
};
#if XE_NP_NP2_LIVE_SD_DIRECT
/* Logical producer token only. Actual DMA destinations are the three-bank
 * record slots; no second PSSI ring is allocated or dereferenced here. */
#define ring ((uint8_t *)0x200D0000UL)
#define SOURCE_RING_BYTES XE_NP_NP2_RING_BYTES
#else
static uint8_t ring[XE_NP_NP2_RING_BYTES]
    __attribute__((aligned(32),section("NP_CAPTURE")));
#define SOURCE_RING_BYTES sizeof(ring)
#endif
static XE_NP_Np2ProducerIo producer_io;
static XE_NP_Np2UsbSourceStatus status;

typedef struct {
    volatile uint8_t i2c_active;
    uint8_t i2c_timed_out,step,complete,released,value[4];
    uint8_t eeprom[2][EEPROM_BYTES];
    uint32_t i2c_deadline_ms,eeprom_reads,chain,chain_pass,chain_index;
} XE_NP_Np2ProbeContext;

static struct {
    uint8_t initialized,started,i2c_ready,capture_bound,active_mask,release_mask;
    volatile uint8_t cancel_requested;
    XE_NP_Np2ProbeContext probe[3];
    uint8_t serial[3][8],model[3][8];
} source;

#if XE_NP_NP2_SD_UNUSED_PROBE_POWERDOWN_TEST
/* Private stopped/setup evidence, not a wire ABI or an acquisition service.
 * magic/version/requested/identified/verified/failed/operations/elapsed_ms. */
volatile uint32_t xe_np_np2_unused_power_diag[8];
#endif

static I2C_HandleTypeDef *probe_i2c(uint32_t probe)
{ return probe==0U ? &hi2c2 : probe==1U ? &hi2c3 : &hi2c4; }
static uint8_t probe_bit(uint32_t probe) {return (uint8_t)(1U<<probe);}

static int deadline_expired(uint32_t now,uint32_t deadline)
{ return deadline != 0U && (int32_t)(now-deadline) >= 0; }

static int configuring_state(uint32_t state)
{ return state >= XE_NP_NP2_USB_SOURCE_IDENTIFY && state <= XE_NP_NP2_USB_SOURCE_CONFIGURE; }

static void set_state(uint32_t state)
{
    status.state = state;
    status.state_since_ms = HAL_GetTick();
}

static void fail(uint32_t error)
{
    if(status.state == XE_NP_NP2_USB_SOURCE_FAILED || status.state == XE_NP_NP2_USB_SOURCE_STOPPED)
        return;
    if((status.flags&XE_NP_NP2_USB_SOURCE_FLAG_FAULT_CONTEXT)==0U)
        status.flags=(status.flags&~XE_NP_NP2_USB_SOURCE_FAULT_FIELDS)|
            XE_NP_NP2_USB_SOURCE_FLAG_FAULT_CONTEXT|(3U<<XE_NP_NP2_USB_SOURCE_FAULT_PROBE_SHIFT)|
            ((status.state&255U)<<XE_NP_NP2_USB_SOURCE_FAULT_STATE_SHIFT)|
            (255U<<XE_NP_NP2_USB_SOURCE_FAULT_STEP_SHIFT);
    status.error = error;
    XE_NP_Np2Config_Failed(source.active_mask);
    XE_NP_Np2UsbSource_Stop();
    status.state = XE_NP_NP2_USB_SOURCE_FAILED;
}

static uint32_t chain_bytes(uint32_t chain)
{ return chain < 2U ? XE_NP_NP2_BASE_BYTES : XE_NP_NP2_SHANK_BYTES; }

static uint8_t chain_register(uint32_t chain)
{
    if(chain == 0U) return R_BASE_EVEN;
    if(chain == 1U) return R_BASE_ODD;
    return (uint8_t)(R_SHANK0 - (chain - 2U));
}

static uint8_t chain_byte(uint32_t probe,uint32_t chain,uint32_t index)
{
    uint32_t physical=chain<2U?chain+4U:chain-2U;
    const uint8_t *image=XE_NP_Np2Config_Chain(probe,physical);
    return image?image[index]:XE_NP_Np2DiagChainByte(physical,index);
}

/* Wire programming is base-even/base-odd then shank 0..3. Export status in
 * the diagnostic helper's physical numbering: shanks 0..3, bases 4..5. */
static uint32_t physical_chain(uint32_t chain)
{ return chain < 2U ? chain+4U : chain-2U; }

/* Setup only. Any electrode OR reference switch makes a failed shank
 * unverified. Never silently rewrite the IMRO map or ignore transport errors. */
static int shank_unused(uint32_t probe,uint32_t chain)
{
    if(chain<2U || chain>=CHAIN_COUNT)return 0;
    for(uint32_t i=0U;i<XE_NP_NP2_SHANK_BYTES;i++)
        if(chain_byte(probe,chain,i)!=0U)return 0;
    return 1;
}

static int failed_chains_allow_recording(void)
{
    for(uint32_t p=0U;p<3U;p++)if(source.active_mask&probe_bit(p)){
        uint32_t failed=(status.chain_fail_mask>>(6U*p))&63U;
        if(failed&48U)return 0; /* Shared base/control failures remain fatal. */
    }
    return 1;
}

/* Returns 1 only after a completed operation, 0 while waiting/retrying and
 * -1 on a terminal HAL error. Each call submits at most one one-byte transfer. */
static int transfer(uint32_t probe,uint8_t address,uint8_t reg,uint8_t write,uint8_t value,uint32_t bytes)
{
    HAL_StatusTypeDef result;
    XE_NP_Np2ProbeContext *context=&source.probe[probe];
    I2C_HandleTypeDef *i2c=probe_i2c(probe);

    if(context->i2c_active != 0U) {
        if(HAL_I2C_GetError(i2c) != HAL_I2C_ERROR_NONE) {
            status.i2c_error = i2c->ErrorCode;
            context->i2c_active = 0U; context->i2c_deadline_ms=0U;
            return -1;
        }
        if(HAL_I2C_GetState(i2c) != HAL_I2C_STATE_READY) {
            if(deadline_expired(HAL_GetTick(),context->i2c_deadline_ms)) {
                context->i2c_timed_out=1U; context->i2c_active=0U; context->i2c_deadline_ms=0U;
                return -1;
            }
            return 0;
        }
        __DMB();
        if(HAL_I2C_GetError(i2c) != HAL_I2C_ERROR_NONE) {
            status.i2c_error = i2c->ErrorCode;
            context->i2c_active = 0U; context->i2c_deadline_ms=0U;
            return -1;
        }
        context->i2c_active = 0U; context->i2c_deadline_ms=0U;
        ++status.i2c_operations;
        return 1;
    }
    /* An IT completion can preempt immediately when the start bit is written.
     * Set ownership before the HAL call, under PRIMASK, so the IRQ cannot see
     * a request with i2c_active still clear. */
    if(context->i2c_deadline_ms != 0U && deadline_expired(HAL_GetTick(),context->i2c_deadline_ms)) {
        context->i2c_timed_out=1U; context->i2c_deadline_ms=0U;
        return -1;
    }
    context->value[0] = value;
    uint32_t key=__get_PRIMASK(); __disable_irq();
    context->i2c_active = 1U;
    if(context->i2c_deadline_ms == 0U) {
        context->i2c_timed_out=0U;
        context->i2c_deadline_ms=HAL_GetTick()+XE_NP_NP2_USB_SOURCE_I2C_TIMEOUT_MS;
    }
    result = write ? HAL_I2C_Mem_Write_IT(i2c,address,reg,I2C_MEMADD_SIZE_8BIT,context->value,bytes) :
                     HAL_I2C_Mem_Read_IT(i2c,address,reg,I2C_MEMADD_SIZE_8BIT,context->value,bytes);
    if(result == HAL_BUSY) { context->i2c_active=0U; __set_PRIMASK(key); return 0; }
    if(result != HAL_OK) {
        context->i2c_active=0U; context->i2c_deadline_ms=0U;
        status.i2c_error = i2c->ErrorCode ? i2c->ErrorCode : 0xFFFFFFFFUL;
        __set_PRIMASK(key);
        return -1;
    }
    __DMB(); __set_PRIMASK(key);
    return 0;
}

static int expect(uint32_t probe,uint8_t reg,uint8_t expected,uint8_t mask)
{
    int result = transfer(probe,NP2_I2C,reg,0U,0U,1U);
    if(result <= 0) return result;
    if((source.probe[probe].value[0] & mask) != (expected & mask)) return -1;
    return 1;
}

static int write_reg(uint32_t probe,uint8_t reg,uint8_t value)
{ return transfer(probe,NP2_I2C,reg,1U,value,1U); }

static int init_i2c_bus(I2C_HandleTypeDef *i2c,I2C_TypeDef *instance,
                        IRQn_Type event_irq,IRQn_Type error_irq)
{
    memset(i2c,0,sizeof(*i2c));i2c->Instance=instance;
    i2c->Init.Timing = XE_NP_BOARD_NP_I2C_TIMING;
    i2c->Init.OwnAddress1 = 0U;
    i2c->Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
    i2c->Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
    i2c->Init.OwnAddress2 = 0U;
    i2c->Init.OwnAddress2Masks = I2C_OA2_NOMASK;
    i2c->Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
    i2c->Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
    if(HAL_I2C_Init(i2c) != HAL_OK ||
       HAL_I2CEx_ConfigAnalogFilter(i2c,I2C_ANALOGFILTER_ENABLE) != HAL_OK ||
       HAL_I2CEx_ConfigDigitalFilter(i2c,0U) != HAL_OK) return -1;
    HAL_NVIC_SetPriority(event_irq,5U,0U);HAL_NVIC_SetPriority(error_irq,5U,0U);
    HAL_NVIC_ClearPendingIRQ(event_irq);HAL_NVIC_ClearPendingIRQ(error_irq);
    HAL_NVIC_EnableIRQ(event_irq);HAL_NVIC_EnableIRQ(error_irq);
    return 0;
}
static int init_i2c(void)
{
    if(source.active_mask&1U) {if(init_i2c_bus(&hi2c2,I2C2,I2C2_EV_IRQn,I2C2_ER_IRQn)!=0)return -1;source.i2c_ready|=1U;}
    if(source.active_mask&2U) {if(init_i2c_bus(&hi2c3,I2C3,I2C3_EV_IRQn,I2C3_ER_IRQn)!=0)return -1;source.i2c_ready|=2U;}
    if(source.active_mask&4U) {if(init_i2c_bus(&hi2c4,I2C4,I2C4_EV_IRQn,I2C4_ER_IRQn)!=0)return -1;source.i2c_ready|=4U;}
    return source.i2c_ready==source.active_mask?0:-1;
}

#if XE_NP_NP2_SD_UNUSED_PROBE_POWERDOWN_TEST
static void powerdown_unused_probes(void)
{
    volatile uint32_t *d=xe_np_np2_unused_power_diag;
    d[0]=0x4E325044U;d[1]=1U;d[2]=(~source.active_mask)&7U;
    d[3]=d[4]=d[5]=d[6]=d[7]=0U;
    if(!d[2])return;
    uint32_t began=HAL_GetTick();
    I2C_TypeDef *instances[3]={I2C2,I2C3,I2C4};
    IRQn_Type events[3]={I2C2_EV_IRQn,I2C3_EV_IRQn,I2C4_EV_IRQn};
    IRQn_Type errors[3]={I2C2_ER_IRQn,I2C3_ER_IRQn,I2C4_ER_IRQn};
    for(uint32_t p=0U;p<3U;p++)if(d[2]&probe_bit(p)) {
        I2C_HandleTypeDef *i2c=probe_i2c(p);
        /* Own even a failed optional init until ordinary quiesce_i2c().
         * No selected configuration transfer/capture has started yet. */
        source.i2c_ready|=probe_bit(p);
        if(init_i2c_bus(i2c,instances[p],events[p],errors[p])!=0) {
            d[5]|=probe_bit(p);continue;
        }
        uint8_t value=0U;d[6]++;
        if(HAL_I2C_Mem_Read(i2c,NP2_I2C,R_ID,I2C_MEMADD_SIZE_8BIT,&value,1U,
                XE_NP_NP2_USB_SOURCE_I2C_TIMEOUT_MS)!=HAL_OK ||
           (value&0x3FU)!=0x20U) {d[5]|=probe_bit(p);continue;}
        d[3]|=probe_bit(p);value=0x80U;d[6]++;
        /* NP2 guide V1.2 p38: OP_MODE P_DOWN=1, REC/CAL/DIG_TEST=0.
         * Digital control survives. Next shared NRST resets this to0.
         * Missing/failed unused probes never become a recording dependency. */
        if(HAL_I2C_Mem_Write(i2c,NP2_I2C,R_OP,I2C_MEMADD_SIZE_8BIT,&value,1U,
                XE_NP_NP2_USB_SOURCE_I2C_TIMEOUT_MS)!=HAL_OK) {
            d[5]|=probe_bit(p);continue;
        }
        value=0U;d[6]++;
        if(HAL_I2C_Mem_Read(i2c,NP2_I2C,R_OP,I2C_MEMADD_SIZE_8BIT,&value,1U,
                XE_NP_NP2_USB_SOURCE_I2C_TIMEOUT_MS)!=HAL_OK ||
           value!=0x80U) {d[5]|=probe_bit(p);continue;}
        d[4]|=probe_bit(p);
    }
    d[7]=HAL_GetTick()-began;
}
#endif

/* The selected probe I2C buses are owned only during source setup. Quiesce
 * them before the producer is bound, so PSSI/GPDMA owns the only enabled
 * capture vectors at handoff. */
static void quiesce_i2c(void)
{
    if(source.i2c_ready == 0U)return;
    I2C_HandleTypeDef *handles[3]={&hi2c2,&hi2c3,&hi2c4};
    I2C_TypeDef *instances[3]={I2C2,I2C3,I2C4};
    IRQn_Type events[3]={I2C2_EV_IRQn,I2C3_EV_IRQn,I2C4_EV_IRQn};
    IRQn_Type errors[3]={I2C2_ER_IRQn,I2C3_ER_IRQn,I2C4_ER_IRQn};
    for(uint32_t p=0U;p<3U;p++)if(source.i2c_ready&(1U<<p)) {
        HAL_NVIC_DisableIRQ(events[p]);HAL_NVIC_DisableIRQ(errors[p]);
        CLEAR_BIT(instances[p]->CR1,I2C_CR1_TXIE|I2C_CR1_RXIE|I2C_CR1_ADDRIE|I2C_CR1_NACKIE|
                  I2C_CR1_STOPIE|I2C_CR1_TCIE|I2C_CR1_ERRIE|I2C_CR1_PE);
        handles[p]->XferISR=NULL;handles[p]->State=HAL_I2C_STATE_RESET;
        source.probe[p].i2c_active=0U;source.probe[p].i2c_deadline_ms=0U;
        HAL_NVIC_ClearPendingIRQ(events[p]);HAL_NVIC_ClearPendingIRQ(errors[p]);
    }
    source.i2c_ready=0U; status.i2c_deadline_ms=0U;
}

#if XE_NP_NP2_SD_SINGLE7500_I2C_CLOCK_GATE_TEST
static uint32_t setup_i2c_clocks;
static void setup_i2c_clock_save(uint32_t enable)
{
    if(enable){
        /* All three buses were retired by quiesce_i2c(), including optional
         * unused-probe powerdown. Never gate a setup/capture owner in flight. */
        if(setup_i2c_clocks || source.i2c_ready || source.capture_bound ||
           source.active_mask!=1U || XE_NP_Board_GetNp2SampleRateHz()!=7500U)return;
        setup_i2c_clocks=8U|((RCC->APB1ENR1&RCC_APB1ENR1_I2C2EN)?1U:0U)|
            ((RCC->APB3ENR&RCC_APB3ENR_I2C3EN)?2U:0U)|
            ((RCC->APB1ENR2&RCC_APB1ENR2_I2C4EN)?4U:0U);
        CLEAR_BIT(RCC->APB1ENR1,RCC_APB1ENR1_I2C2EN);
        CLEAR_BIT(RCC->APB3ENR,RCC_APB3ENR_I2C3EN);
        CLEAR_BIT(RCC->APB1ENR2,RCC_APB1ENR2_I2C4EN);
    }else{
        if(!setup_i2c_clocks)return;
        MODIFY_REG(RCC->APB1ENR1,RCC_APB1ENR1_I2C2EN,
            (setup_i2c_clocks&1U)?RCC_APB1ENR1_I2C2EN:0U);
        MODIFY_REG(RCC->APB3ENR,RCC_APB3ENR_I2C3EN,
            (setup_i2c_clocks&2U)?RCC_APB3ENR_I2C3EN:0U);
        MODIFY_REG(RCC->APB1ENR2,RCC_APB1ENR2_I2C4EN,
            (setup_i2c_clocks&4U)?RCC_APB1ENR2_I2C4EN:0U);
        setup_i2c_clocks=0U;
    }
    __DSB();
}
#endif

static void prepare_idle_hardware(void)
{
    XE_NP_Board_StopNp2Mco();
    HAL_GPIO_WritePin(NP_NRST_GPIO_Port,NP_NRST_Pin,GPIO_PIN_RESET);
    HAL_GPIO_WritePin(VCC_EN_GPIO_Port,VCC_EN_Pin,GPIO_PIN_RESET);
    __HAL_RCC_GPDMA1_CLK_ENABLE(); __HAL_RCC_DCMI_PSSI_CLK_ENABLE();
    __HAL_RCC_GPDMA1_FORCE_RESET(); __HAL_RCC_DCMI_PSSI_FORCE_RESET(); __DSB();
    __HAL_RCC_GPDMA1_RELEASE_RESET(); __HAL_RCC_DCMI_PSSI_RELEASE_RESET(); __DSB();
    HAL_NVIC_DisableIRQ(GPDMA1_Channel12_IRQn); HAL_NVIC_DisableIRQ(DCMI_PSSI_IRQn);
    HAL_NVIC_ClearPendingIRQ(GPDMA1_Channel12_IRQn); HAL_NVIC_ClearPendingIRQ(DCMI_PSSI_IRQn);
}

static void reset_probe_contexts(void)
{
    for(uint32_t p=0U;p<3U;p++) {
        memset(&source.probe[p],0,sizeof(source.probe[p]));
        source.probe[p].step=STEP_ID;
    }
    source.release_mask=0U;
}

static uint32_t probe_i2c_error(const XE_NP_Np2ProbeContext *context,uint32_t fallback)
{ return context->i2c_timed_out ? XE_NP_NP2_USB_SOURCE_ERROR_I2C_TIMEOUT : fallback; }

static void publish_probe_progress(uint32_t probe)
{
    const XE_NP_Np2ProbeContext *context=&source.probe[probe];
    status.eeprom_reads=context->eeprom_reads;
    status.chain=context->chain;
    status.chain_pass=context->chain_pass;
    status.chain_index=context->chain_index;
}
static void fail_probe(uint32_t probe,uint32_t error)
{
    if(status.state==XE_NP_NP2_USB_SOURCE_FAILED || status.state==XE_NP_NP2_USB_SOURCE_STOPPED)return;
    if(probe<3U){
        publish_probe_progress(probe);
        status.flags=(status.flags&~XE_NP_NP2_USB_SOURCE_FAULT_FIELDS)|
            XE_NP_NP2_USB_SOURCE_FLAG_FAULT_CONTEXT|(probe<<XE_NP_NP2_USB_SOURCE_FAULT_PROBE_SHIFT)|
            ((status.state&255U)<<XE_NP_NP2_USB_SOURCE_FAULT_STATE_SHIFT)|
            ((uint32_t)source.probe[probe].step<<XE_NP_NP2_USB_SOURCE_FAULT_STEP_SHIFT);
    }
    fail(error);
}

static void publish_earliest_i2c_deadline(void)
{
    uint32_t deadline=0U;
    for(uint32_t p=0U;p<3U;p++)if(source.active_mask&probe_bit(p)) {
        uint32_t candidate=source.probe[p].i2c_deadline_ms;
        if(candidate!=0U && (deadline==0U || (int32_t)(candidate-deadline)<0)) deadline=candidate;
    }
    status.i2c_deadline_ms=deadline;
}

static int all_probes_configured(void)
{
    for(uint32_t p=0U;p<3U;p++)
        if((source.active_mask&probe_bit(p)) && source.probe[p].complete==0U)return 0;
    return 1;
}

static int all_probes_released(void)
{
    for(uint32_t p=0U;p<3U;p++)
        if((source.active_mask&probe_bit(p)) && source.probe[p].released==0U)return 0;
    return 1;
}

static void publish_configuration_state(void)
{
    uint32_t next=XE_NP_NP2_USB_SOURCE_CONFIGURE;
    for(uint32_t p=0U;p<3U;p++)if((source.active_mask&probe_bit(p)) && !source.probe[p].complete) {
        if(source.probe[p].step==STEP_ID) {next=XE_NP_NP2_USB_SOURCE_IDENTIFY;break;}
        if(source.probe[p].step==STEP_EEPROM) next=XE_NP_NP2_USB_SOURCE_EEPROM;
    }
    if(status.state!=next)set_state(next);
}

/* Advance one probe by at most one nonblocking I2C start/poll. Calling this
 * once for every active probe lets I2C2/I2C3/I2C4 remain in flight together. */
static uint32_t service_probe_configuration(uint32_t probe)
{
    XE_NP_Np2ProbeContext *context=&source.probe[probe];
    int result=0;

    if(context->complete)return XE_NP_NP2_USB_SOURCE_ERROR_NONE;
    switch(context->step) {
    case STEP_ID:
        result=expect(probe,R_ID,0x20U,0x3FU);
        if(result<0)return probe_i2c_error(context,XE_NP_NP2_USB_SOURCE_ERROR_ID);
        if(result==1) {status.id=context->value[0];context->step=STEP_EEPROM;}
        break;
    case STEP_EEPROM: {
        uint32_t pass=context->eeprom_reads/(EEPROM_BYTES/EEPROM_CHUNK);
        uint32_t offset=(context->eeprom_reads%(EEPROM_BYTES/EEPROM_CHUNK))*EEPROM_CHUNK;
        result=transfer(probe,NP2_EEPROM,(uint8_t)offset,0U,0U,EEPROM_CHUNK);
        if(result<0)return probe_i2c_error(context,XE_NP_NP2_USB_SOURCE_ERROR_I2C);
        if(result==0)break;
        memcpy(&context->eeprom[pass][offset],context->value,EEPROM_CHUNK);
        if(++context->eeprom_reads != 2U*(EEPROM_BYTES/EEPROM_CHUNK))break;
        if(memcmp(context->eeprom[0],context->eeprom[1],EEPROM_BYTES)==0)
            status.eeprom_match|=probe_bit(probe);
        memcpy(source.serial[probe],context->eeprom[0],8U);
        memcpy(source.model[probe],&context->eeprom[0][0x40U],8U);
        memcpy(status.serial,source.serial[probe],8U);
        memcpy(status.model,source.model[probe],8U);
        if(!XE_NP_Np2DiagIdentityKnown(context->eeprom[0],context->eeprom[1]) ||
           !XE_NP_Np2Diag_PartNumberIs(&context->eeprom[0][0x40U],"NP2013"))
            return XE_NP_NP2_USB_SOURCE_ERROR_IDENTITY;
        context->step=STEP_HOLD;
        break;
    }
    /* Method 2 proved the ordinary initial state is REC released. The hold is
     * restored only after the final soft reset, before sync/OP. */
    case STEP_HOLD: result=write_reg(probe,R_REC,REC_RELEASED); if(result==1)context->step=STEP_HOLD_READ; break;
    case STEP_HOLD_READ: result=expect(probe,R_REC,REC_RELEASED,0xFFU); if(result==1)context->step=STEP_CAL; break;
    case STEP_CAL: result=write_reg(probe,R_CAL,0U); if(result==1)context->step=STEP_CAL_READ; break;
    case STEP_CAL_READ: result=expect(probe,R_CAL,0U,0xFFU); if(result==1)context->step=STEP_RESET_FF; break;
    case STEP_RESET_FF: result=write_reg(probe,R_SOFT_RESET,0xFFU); if(result==1)context->step=STEP_RESET_ZERO; break;
    case STEP_RESET_ZERO: result=write_reg(probe,R_SOFT_RESET,0U); if(result==1)context->step=STEP_RESET_OP; break;
    case STEP_RESET_OP: result=expect(probe,R_OP,0U,0xFFU); if(result==1)context->step=STEP_RESET_REC; break;
    case STEP_RESET_REC: result=expect(probe,R_REC,REC_RELEASED,0xFFU); if(result==1)context->step=STEP_LENGTH_LO; break;
    case STEP_LENGTH_LO: result=write_reg(probe,R_LENGTH_LO,(uint8_t)chain_bytes(context->chain)); if(result==1)context->step=STEP_LENGTH_LO_READ; break;
    case STEP_LENGTH_LO_READ: result=expect(probe,R_LENGTH_LO,(uint8_t)chain_bytes(context->chain),0xFFU); if(result==1)context->step=STEP_LENGTH_HI; break;
    case STEP_LENGTH_HI: result=write_reg(probe,R_LENGTH_HI,0U); if(result==1)context->step=STEP_LENGTH_HI_READ; break;
    case STEP_LENGTH_HI_READ: result=expect(probe,R_LENGTH_HI,0U,0xFFU); if(result==1)context->step=STEP_CHAIN; break;
    case STEP_CHAIN:
        result=write_reg(probe,chain_register(context->chain),chain_byte(probe,context->chain,context->chain_index));
        if(result==1 && ++context->chain_index==chain_bytes(context->chain)) {
            context->chain_index=0U;
            if(++context->chain_pass==2U) {context->chain_pass=0U;context->step=STEP_STATUS;}
            else context->step=STEP_RESET_FF;
        }
        break;
    case STEP_STATUS:
        result=transfer(probe,NP2_I2C,R_STATUS,0U,0U,1U);
        if(result==1) {
            status.chain_status[physical_chain(context->chain)]=context->value[0];
            if((context->value[0]&0x80U)==0U) {
                status.chain_fail_mask|=1UL<<(physical_chain(context->chain)+6U*probe);
                if(!failed_chains_allow_recording())
                    return XE_NP_NP2_USB_SOURCE_ERROR_SHIFT;
                status.flags|=XE_NP_NP2_USB_SOURCE_FLAG_DEGRADED;
            }
            if(++context->chain==CHAIN_COUNT)context->step=STEP_FINAL_HOLD;
            else context->step=STEP_RESET_FF;
        }
        break;
    case STEP_FINAL_HOLD: result=write_reg(probe,R_REC,REC_HELD); if(result==1)context->step=STEP_FINAL_HOLD_READ; break;
    case STEP_FINAL_HOLD_READ: result=expect(probe,R_REC,REC_HELD,0xFFU); if(result==1)context->step=STEP_FINAL_CAL; break;
    case STEP_FINAL_CAL: result=write_reg(probe,R_CAL,0U); if(result==1)context->step=STEP_FINAL_CAL_READ; break;
    case STEP_FINAL_CAL_READ: result=expect(probe,R_CAL,0U,0xFFU); if(result==1)context->step=STEP_SYNC; break;
    case STEP_SYNC: result=write_reg(probe,(uint8_t)(R_SYNC+context->chain_index),supersync[context->chain_index]); if(result==1)context->step=STEP_SYNC_READ; break;
    case STEP_SYNC_READ:
        result=expect(probe,(uint8_t)(R_SYNC+context->chain_index),supersync[context->chain_index],0xFFU);
        if(result==1) {
            if(++context->chain_index==sizeof(supersync)) {context->chain_index=0U;context->step=STEP_OP;}
            else context->step=STEP_SYNC;
        }
        break;
    case STEP_OP: result=write_reg(probe,R_OP,OP_RECORD); if(result==1)context->step=STEP_OP_READ; break;
    case STEP_OP_READ:
        result=expect(probe,R_OP,OP_RECORD,0xFFU);
        if(result==1){
            uint32_t failed=(status.chain_fail_mask>>(6U*probe))&15U;
            uint32_t unverified=failed==15U;
            for(uint32_t shank=0U;shank<4U && !unverified;shank++)
                if((failed&(1U<<shank)) && !shank_unused(probe,shank+2U))unverified=1U;
            context->complete=1U;
            if(unverified)XE_NP_Np2Config_AppliedWithUnverifiedShanks(probe,failed);
            else XE_NP_Np2Config_AppliedWithShankFailures(probe,failed);
        }
        break;
    default: return XE_NP_NP2_USB_SOURCE_ERROR_ARGUMENT;
    }
    publish_probe_progress(probe);
    if(result<0)return probe_i2c_error(context,
        context->step==STEP_STATUS ? XE_NP_NP2_USB_SOURCE_ERROR_SHIFT : XE_NP_NP2_USB_SOURCE_ERROR_I2C);
    return XE_NP_NP2_USB_SOURCE_ERROR_NONE;
}

static uint32_t service_probe_release(uint32_t probe)
{
    XE_NP_Np2ProbeContext *context=&source.probe[probe];
    int result;
    if(context->released)return XE_NP_NP2_USB_SOURCE_ERROR_NONE;
    if(context->step==STEP_RELEASE) {
        result=write_reg(probe,R_REC,REC_RELEASED);
        if(result==1)context->step=STEP_RELEASE_READ;
    } else if(context->step==STEP_RELEASE_READ) {
        result=expect(probe,R_REC,REC_RELEASED,0xFFU);
        if(result==1) {
            status.rec=context->value[0];status.op=OP_RECORD;status.cal=0U;
            context->released=1U;source.release_mask|=probe_bit(probe);
        }
    } else return XE_NP_NP2_USB_SOURCE_ERROR_ARGUMENT;
    if(result<0)return probe_i2c_error(context,XE_NP_NP2_USB_SOURCE_ERROR_I2C);
    return XE_NP_NP2_USB_SOURCE_ERROR_NONE;
}

int XE_NP_Np2UsbSource_Init(void)
{
    /* Reinitialize only a successfully stopped source. Never clear a live
     * owner or sticky hardware fault to make a second session appear safe. */
    if(source.initialized != 0U &&
       (status.state!=XE_NP_NP2_USB_SOURCE_STOPPED || source.capture_bound ||
        XE_NP_Np2CapturePort_Armed()))return -1;
    XE_NP_Np2FirstSyncPort_Invalidate();
    memset(&source,0,sizeof(source));
    memset(&status,0,sizeof(status));
    status.magic = XE_NP_NP2_USB_SOURCE_MAGIC;
    status.version = XE_NP_NP2_USB_SOURCE_VERSION;
    status.state = XE_NP_NP2_USB_SOURCE_IDLE;
    status.ring_address = (uint32_t)(uintptr_t)ring;
    status.ring_bytes = SOURCE_RING_BYTES;
    source.active_mask=(uint8_t)(XE_NP_NP2_USB_V3_LIVE_PROBE_MASK&7U);
    source.initialized = 1U;
    return status.ring_address == 0x200D0000UL ? 0 : -1;
}

int XE_NP_Np2UsbSource_SelectProbeMask(uint32_t probe_mask)
{
    if(!source.initialized || source.started || status.state!=XE_NP_NP2_USB_SOURCE_IDLE ||
       !probe_mask || (probe_mask&~7U) || (probe_mask&~XE_NP_NP2_USB_V3_LIVE_PROBE_MASK))return -1;
    source.active_mask=(uint8_t)probe_mask;return 0;
}

int XE_NP_Np2UsbSource_Start(void)
{
    if(source.initialized == 0U || source.started != 0U || status.state != XE_NP_NP2_USB_SOURCE_IDLE ||
       !source.active_mask) return -1;
    reset_probe_contexts();
    XE_NP_Np2Config_BeginApply(source.active_mask);
    source.started = 1U;
    status.started_ms = HAL_GetTick();
    set_state(XE_NP_NP2_USB_SOURCE_PREPARE);
    return 0;
}

void XE_NP_Np2UsbSource_Stop(void)
{
    XE_NP_Np2FirstSyncPort_Invalidate();
    if(__get_IPSR() != 0U) { source.cancel_requested=1U; return; }
    if(source.capture_bound != 0U) XE_NP_Np2CapturePort_Stop();
#if XE_NP_NP2_SD_SINGLE7500_I2C_CLOCK_GATE_TEST
    setup_i2c_clock_save(0U);
#endif
    quiesce_i2c();
    source.capture_bound = 0U;
    status.config_deadline_ms=0U;
    HAL_GPIO_WritePin(NP_NRST_GPIO_Port,NP_NRST_Pin,GPIO_PIN_RESET);
    XE_NP_Board_StopNp2Mco();
    /* Capture is already stopped. Retain shared camera power until its
     * independent foreground owner retires the final transaction. */
    if(!XE_NP_UsbAux_HoldsVcc())
        HAL_GPIO_WritePin(VCC_EN_GPIO_Port,VCC_EN_Pin,GPIO_PIN_RESET);
    status.flags &= ~(XE_NP_NP2_USB_SOURCE_FLAG_READY|XE_NP_NP2_USB_SOURCE_FLAG_CAPTURE_BOUND);
    if(status.state != XE_NP_NP2_USB_SOURCE_FAILED) set_state(XE_NP_NP2_USB_SOURCE_STOPPED);
    XE_NP_Np2Preparation_SourceStopped();
}

int XE_NP_Np2UsbSource_IsReady(void)
{ return status.state == XE_NP_NP2_USB_SOURCE_READY ? 1 : 0; }
int XE_NP_Np2UsbSource_IsBusy(void)
{ return source.started != 0U && status.state != XE_NP_NP2_USB_SOURCE_READY &&
         status.state != XE_NP_NP2_USB_SOURCE_STOPPED && status.state != XE_NP_NP2_USB_SOURCE_FAILED; }
const XE_NP_Np2ProducerIo *XE_NP_Np2UsbSource_GetProducerIo(void)
{ return XE_NP_Np2UsbSource_IsReady() && source.capture_bound ? &producer_io : NULL; }
void XE_NP_Np2UsbSource_GetStatus(XE_NP_Np2UsbSourceStatus *out)
{ if(out != NULL) { uint32_t key=__get_PRIMASK();__disable_irq();*out=status;__set_PRIMASK(key); } }
int XE_NP_Np2UsbSource_GetProbeIdentity(uint32_t probe_index,uint8_t serial[8],uint8_t model[8])
{
    if(probe_index>=3U || !serial || !model || !(source.active_mask&(1U<<probe_index)) ||
       (status.flags&XE_NP_NP2_USB_SOURCE_FLAG_IDENTITY)==0U)return -1;
    memcpy(serial,source.serial[probe_index],8U);memcpy(model,source.model[probe_index],8U);return 0;
}
void XE_NP_Np2UsbSource_I2cEventIrq(uint32_t probe_index)
{
    if(probe_index<3U && (source.i2c_ready&probe_bit(probe_index)) &&
       source.probe[probe_index].i2c_active)
        HAL_I2C_EV_IRQHandler(probe_i2c(probe_index));
}
void XE_NP_Np2UsbSource_I2cErrorIrq(uint32_t probe_index)
{
    if(probe_index<3U && (source.i2c_ready&probe_bit(probe_index)) &&
       source.probe[probe_index].i2c_active)
        HAL_I2C_ER_IRQHandler(probe_i2c(probe_index));
}

#if XE_NP_NP2_SD_SETTLE_SLEEP_TEST
static void sleep_while_settling(void)
{
    /* No acquisition has armed. Keep MCO/rails and the full analog wait;
     * SysTick or UART wakes plain Sleep so Stop/rescue stays serviceable. */
    uint32_t key=__get_PRIMASK();
    if(key || __get_IPSR() || __get_BASEPRI() || __get_FAULTMASK() ||
       (SCB->SCR&(SCB_SCR_SLEEPDEEP_Msk|SCB_SCR_SLEEPONEXIT_Msk)) ||
       (SysTick->CTRL&(SysTick_CTRL_ENABLE_Msk|SysTick_CTRL_TICKINT_Msk))!=
           (SysTick_CTRL_ENABLE_Msk|SysTick_CTRL_TICKINT_Msk))return;
    __disable_irq();
    if(source.started && !source.cancel_requested && !source.capture_bound &&
       status.state==XE_NP_NP2_USB_SOURCE_SETTLING &&
       HAL_GetTick()-status.state_since_ms<XE_NP_NP2_ANALOG_SETTLE_MS &&
       !XE_NP_Np2CapturePort_Armed() && !source.probe[0].i2c_active &&
       !source.probe[1].i2c_active && !source.probe[2].i2c_active){
        __DSB();__WFI();__ISB();
    }
    __set_PRIMASK(key);
}
#endif

void XE_NP_Np2UsbSource_Service(void)
{
    uint32_t elapsed = HAL_GetTick() - status.state_since_ms;
    uint32_t error;

    if(source.cancel_requested != 0U) {
        source.cancel_requested=0U;
        if(source.started != 0U) fail(XE_NP_NP2_USB_SOURCE_ERROR_CANCELLED);
        return;
    }
    if(!source.started || status.state == XE_NP_NP2_USB_SOURCE_READY ||
       status.state == XE_NP_NP2_USB_SOURCE_STOPPED || status.state == XE_NP_NP2_USB_SOURCE_FAILED) return;
    if(configuring_state(status.state) && deadline_expired(HAL_GetTick(),status.config_deadline_ms)) {
        fail(XE_NP_NP2_USB_SOURCE_ERROR_CONFIG_TIMEOUT); return;
    }
    switch(status.state) {
    case XE_NP_NP2_USB_SOURCE_PREPARE:
        prepare_idle_hardware();
        status.hclk_hz=HAL_RCC_GetHCLKFreq(); status.sysclk_hz=HAL_RCC_GetSysClockFreq();
        if(status.hclk_hz != XE_NP_Board_GetRuntimeCoreClockHz() || status.sysclk_hz != XE_NP_Board_GetRuntimeCoreClockHz()) { fail(XE_NP_NP2_USB_SOURCE_ERROR_CLOCK); return; }
        if((FLASH->OPTR & FLASH_OPTR_IO_VDD_HSLV) == 0U) { fail(XE_NP_NP2_USB_SOURCE_ERROR_HSLV); return; }
        if(init_i2c() != 0) { fail(XE_NP_NP2_USB_SOURCE_ERROR_I2C_INIT); return; }
        set_state(XE_NP_NP2_USB_SOURCE_POWER_WAIT); return;
    case XE_NP_NP2_USB_SOURCE_POWER_WAIT:
        if(elapsed < 5U) return;
        HAL_GPIO_WritePin(VCC_EN_GPIO_Port,VCC_EN_Pin,GPIO_PIN_SET);
        set_state(XE_NP_NP2_USB_SOURCE_CLOCK_WAIT); return;
    case XE_NP_NP2_USB_SOURCE_CLOCK_WAIT:
        if(elapsed < 15U) return;
        if(XE_NP_Board_StartNp2Mco(15U) != 0) { fail(XE_NP_NP2_USB_SOURCE_ERROR_CLOCK); return; }
        status.rcc_cfgr1=RCC->CFGR1;
        if((status.rcc_cfgr1&(RCC_CFGR1_MCOSEL|RCC_CFGR1_MCOPRE)) != XE_NP_Board_GetRuntimeMcoRegisterBits()) { fail(XE_NP_NP2_USB_SOURCE_ERROR_CLOCK); return; }
        set_state(XE_NP_NP2_USB_SOURCE_RESET_WAIT); return;
    case XE_NP_NP2_USB_SOURCE_RESET_WAIT:
        if(elapsed < 1U) return;
        HAL_GPIO_WritePin(NP_NRST_GPIO_Port,NP_NRST_Pin,GPIO_PIN_SET);
#if XE_NP_NP2_SD_UNUSED_PROBE_POWERDOWN_TEST
        powerdown_unused_probes();
#endif
        status.config_deadline_ms=HAL_GetTick()+XE_NP_NP2_USB_SOURCE_CONFIG_TIMEOUT_MS;
        set_state(XE_NP_NP2_USB_SOURCE_IDENTIFY); return;
    case XE_NP_NP2_USB_SOURCE_IDENTIFY:
    case XE_NP_NP2_USB_SOURCE_EEPROM:
    case XE_NP_NP2_USB_SOURCE_CONFIGURE:
        for(uint32_t p=0U;p<3U;p++)if(source.active_mask&probe_bit(p)) {
            error=service_probe_configuration(p);
            if(error!=XE_NP_NP2_USB_SOURCE_ERROR_NONE) {fail_probe(p,error);return;}
        }
        publish_earliest_i2c_deadline();
        if(all_probes_configured()) {
            status.flags|=XE_NP_NP2_USB_SOURCE_FLAG_IDENTITY;
            if(status.chain_fail_mask==0U)status.flags|=XE_NP_NP2_USB_SOURCE_FLAG_CHAINS;
            status.config_deadline_ms=0U;set_state(XE_NP_NP2_USB_SOURCE_SETTLING);
        } else publish_configuration_state();
        return;
    case XE_NP_NP2_USB_SOURCE_SETTLING:
        if(elapsed < XE_NP_NP2_ANALOG_SETTLE_MS) {
#if XE_NP_NP2_SD_SETTLE_SLEEP_TEST
            sleep_while_settling();
#endif
            return;
        }
        source.release_mask=0U;
        for(uint32_t p=0U;p<3U;p++)if(source.active_mask&probe_bit(p)) {
            source.probe[p].step=STEP_RELEASE;
            source.probe[p].released=0U;
        }
        set_state(XE_NP_NP2_USB_SOURCE_RELEASE); return;
    case XE_NP_NP2_USB_SOURCE_RELEASE:
        for(uint32_t p=0U;p<3U;p++)if(source.active_mask&probe_bit(p)) {
            error=service_probe_release(p);
            if(error!=XE_NP_NP2_USB_SOURCE_ERROR_NONE) {fail_probe(p,error);return;}
        }
        publish_earliest_i2c_deadline();
        if(!all_probes_released())return;
        if(source.release_mask!=source.active_mask){fail(XE_NP_NP2_USB_SOURCE_ERROR_I2C);return;}
        /* No I2C operation remains once the final read completed. Do not
         * overlap an enabled configuration IRQ line with the capture handoff. */
        quiesce_i2c();
#if XE_NP_NP2_SD_SINGLE7500_I2C_CLOCK_GATE_TEST
        setup_i2c_clock_save(1U);
#endif
        if(!failed_chains_allow_recording() ||
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
           XE_NP_Np2CapturePort_BindProfile(ring,SOURCE_RING_BYTES,&producer_io,source.active_mask) != 0
#else
           XE_NP_Np2CapturePort_Bind(ring,SOURCE_RING_BYTES,&producer_io) != 0
#endif
          ) { fail(XE_NP_NP2_USB_SOURCE_ERROR_CAPTURE_BIND); return; }
        source.capture_bound=1U; status.flags|=XE_NP_NP2_USB_SOURCE_FLAG_READY|XE_NP_NP2_USB_SOURCE_FLAG_CAPTURE_BOUND;
        set_state(XE_NP_NP2_USB_SOURCE_READY); return;
    default: fail(XE_NP_NP2_USB_SOURCE_ERROR_ARGUMENT); return;
    }
}

#include "xe_np_np2_preparation.inc"

#else

int XE_NP_Np2UsbSource_Init(void) { return -1; }
int XE_NP_Np2UsbSource_SelectProbeMask(uint32_t probe_mask) { (void)probe_mask;return -1; }
int XE_NP_Np2UsbSource_Start(void) { return -1; }
void XE_NP_Np2UsbSource_Service(void) {}
int XE_NP_Np2UsbSource_IsReady(void) { return 0; }
int XE_NP_Np2UsbSource_IsBusy(void) { return 0; }
void XE_NP_Np2UsbSource_Stop(void) {}
const XE_NP_Np2ProducerIo *XE_NP_Np2UsbSource_GetProducerIo(void) { return NULL; }
void XE_NP_Np2UsbSource_GetStatus(XE_NP_Np2UsbSourceStatus *out) { if(out) memset(out,0,sizeof(*out)); }
int XE_NP_Np2UsbSource_GetProbeIdentity(uint32_t probe_index,uint8_t serial[8],uint8_t model[8])
{ (void)probe_index;(void)serial;(void)model;return -1; }
void XE_NP_Np2UsbSource_I2cEventIrq(uint32_t probe_index) { (void)probe_index; }
void XE_NP_Np2UsbSource_I2cErrorIrq(uint32_t probe_index) { (void)probe_index; }

#endif
