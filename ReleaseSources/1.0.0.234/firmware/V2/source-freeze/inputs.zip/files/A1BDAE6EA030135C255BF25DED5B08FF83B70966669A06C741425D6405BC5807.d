D:\Code\XE_NP_V2\_artifacts\v2_ble_cold_start_20261007_build\usb\usbd_msc_bot.o: \
  D:\Code\XE_NP_V2\Middlewares\ST\STM32_USB_Device_Library\Class\MSC\Src\usbd_msc_bot.c \
  D:\Code\XE_NP_V2\Middlewares\ST\STM32_USB_Device_Library\Class\MSC\Inc\usbd_msc_bot.h \
  D:\Code\XE_NP_V2\Middlewares\ST\STM32_USB_Device_Library\Core\Inc\usbd_core.h \
  D:\Code\XE_NP_V2\Core\Inc\usbd_conf.h \
  D:\Code\XE_NP_V2\Middlewares\ST\STM32_USB_Device_Library\Core\Inc\usbd_def.h \
  D:\Code\XE_NP_V2\Middlewares\ST\STM32_USB_Device_Library\Core\Inc\usbd_ioreq.h \
  D:\Code\XE_NP_V2\Middlewares\ST\STM32_USB_Device_Library\Core\Inc\usbd_ctlreq.h \
  D:\Code\XE_NP_V2\Middlewares\ST\STM32_USB_Device_Library\Class\MSC\Inc\usbd_msc.h \
  D:\Code\XE_NP_V2\Middlewares\ST\STM32_USB_Device_Library\Class\MSC\Inc\usbd_msc_scsi.h
