#include "xe_np_np2_ep81_headroom_diag.h"

#if XE_NP_NP2_EP81_HEADROOM_DIAG
#if defined(XE_NP_EP81_HEADROOM_DIAG_NATIVE_TEST)
void xe_np_ep81_diag_dmb(void);
#define EP81_DIAG_DMB() xe_np_ep81_diag_dmb()
#else
#include "main.h"
#define EP81_DIAG_DMB() __DMB()
#endif

volatile XE_NP_Ep81HeadroomDiag xe_np_ep81_headroom_diag;

static void ep81_store(volatile XE_NP_Ep81HeadroomRecord *slots,
                       volatile XE_NP_Ep81HeadroomRingState *state,uint32_t capacity,
                       uint32_t raw_tick,uint32_t block_index,uint16_t depth,
                       uint8_t owner_state,uint8_t flags)
{
    XE_NP_Ep81HeadroomRecord r;
    uint32_t ordinal=state->next_ordinal+1U,slot=state->next_slot;
    if(!ordinal)ordinal=1U;
    r.ordinal=0U;r.raw_tick=raw_tick;r.block_index=block_index;
    r.depth=depth;r.state=owner_state;r.flags=flags;
    slots[slot]=r;
    EP81_DIAG_DMB();
    slots[slot].ordinal=ordinal;
    state->next_ordinal=ordinal;
    slot++;if(slot==capacity)slot=0U;state->next_slot=slot;
    if(state->retained<capacity)state->retained++;
    else if(state->overwritten!=UINT32_MAX)state->overwritten++;
}

void XE_NP_Ep81HeadroomDiag_Reset(void)
{
    volatile XE_NP_Ep81HeadroomDiag *d=&xe_np_ep81_headroom_diag;
    /* Integration calls this only at idle; no global IRQ masking is needed. */
    for(uint32_t i=0U;i<sizeof(*d)/sizeof(uint32_t);i++)((volatile uint32_t *)d)[i]=0U;
    d->magic=XE_NP_EP81_HEADROOM_MAGIC;d->version=3U;d->tick_hz=1000U;
    EP81_DIAG_DMB();
}

void XE_NP_Ep81HeadroomDiag_Ep81Submit(uint32_t raw_tick,uint32_t block_index,
                                       uint16_t depth,uint8_t state,uint8_t flags)
{
    volatile XE_NP_Ep81HeadroomDiag *d=&xe_np_ep81_headroom_diag;
    ep81_store(d->submit,&d->submit_state,XE_NP_EP81_HEADROOM_SUBMIT_CAPACITY,
               raw_tick,block_index,depth,state,flags);
}

void XE_NP_Ep81HeadroomDiag_Ep81Complete(uint32_t raw_tick,uint32_t block_index,
                                         uint16_t depth,uint8_t state,uint8_t flags)
{
    volatile XE_NP_Ep81HeadroomDiag *d=&xe_np_ep81_headroom_diag;
    ep81_store(d->complete,&d->complete_state,XE_NP_EP81_HEADROOM_COMPLETE_CAPACITY,
               raw_tick,block_index,depth,state,flags);
}

void XE_NP_Ep81HeadroomDiag_ProducerSample(uint32_t raw_tick,uint32_t block_index,
                                           uint16_t backlog128,uint8_t state,uint8_t flags)
{
    volatile XE_NP_Ep81HeadroomDiag *d=&xe_np_ep81_headroom_diag;
    if(d->producer_sample_calls!=UINT32_MAX)d->producer_sample_calls++;
    ep81_store(d->producer,&d->producer_state,XE_NP_EP81_HEADROOM_PRODUCER_CAPACITY,
               raw_tick,block_index,backlog128,state,flags);
}

void XE_NP_Ep81HeadroomDiag_ProducerFault(uint32_t raw_tick,uint32_t block_index,
                                          uint16_t backlog128,uint8_t state,uint8_t flags)
{
    XE_NP_Ep81HeadroomRecord r;
    volatile XE_NP_Ep81HeadroomDiag *d=&xe_np_ep81_headroom_diag;
    ep81_store(d->producer,&d->producer_state,XE_NP_EP81_HEADROOM_PRODUCER_CAPACITY,
               raw_tick,block_index,backlog128,state,flags);
    if(d->first_fault.ordinal)return;
    r.ordinal=0U;r.raw_tick=raw_tick;r.block_index=block_index;
    r.depth=backlog128;r.state=state;r.flags=flags;
    d->first_fault=r;EP81_DIAG_DMB();d->first_fault.ordinal=d->producer_state.next_ordinal;
}
#endif
