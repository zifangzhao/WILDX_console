#ifndef XE_NP_NP2_PREVIEW_H
#define XE_NP_NP2_PREVIEW_H
#include <stdint.h>
#define NP2_PREVIEW_MAGIC 0x3256504eU
#define NP2_PREVIEW_BYTES 3200U
#define NP2_PREVIEW_FRAGMENT 192U
#define NP2_PREVIEW_STREAM_SLOTS 4U
#define NP2_PREVIEW_SINGLE_CHANNEL 5U
#define NP2_PREVIEW_FILTERED 6U
#define NP2_PREVIEW_FEEDBACK 7U
#define NP2_PREVIEW_CAPABILITY 8U
#define NP2_PREVIEW_FILTERED_ROWS 40U
#define NP2_PREVIEW_HISTORY_SLOTS 32U
#define NP2_PREVIEW_FILTER_ID 1U
#define NP2_PREVIEW_HZ 500U
#define NP2_PREVIEW_SINGLE_ROWS 64U
/* Legacy successful kinds0/1/2: each payload byte keeps P1/P2 low six bits.
 * Kind5 instead carries one lane's packed raw bits and explicit preview Hz.
 * Error0x80|reason replies remain unmarked. */
#define NP2_PREVIEW_KIND_SIX_BIT_BYTES 0x40U
/* ADC decoding and phase search belong to the PC. Rolling mode uses four
 * 16-sample packets within the existing raw allocation; no recorder RAM lost. */
/* Working state shares the legacy byte allocation only while kind6 owns it.
 * The anonymous union preserves every field offset and the retained wrapper ABI.
 * Replay packets occupy a separate CPU-only section, not acquisition RAM. */
typedef struct {
    uint32_t integrator[4],comb[4];
    int16_t fir[128];
    uint16_t descriptor,offset,word;
    uint8_t bits,shift;
} XE_NP_Np2PreviewFilterChannel;
typedef struct {
    XE_NP_Np2PreviewFilterChannel channel[2];
    uint64_t frame_base;
    uint32_t generated,sent,acked,next_send,replay;
    uint32_t intermediate_count,reciprocal,ignored_feedback,lost_native;
    uint16_t decimation,final_decimation,taps,delay,ring_at,cic_at,rows,count;
    uint8_t initialized,terminal_sent,previous_bytes,pressured;
    uint8_t previous[12];
} XE_NP_Np2PreviewFilterState;
#if defined(_MSC_VER)
#pragma warning(push)
#pragma warning(disable:4201) /* C11 anonymous union; retained byte-array ABI. */
#endif
typedef struct {
    union {
        uint8_t data[NP2_PREVIEW_BYTES];
        XE_NP_Np2PreviewFilterState filtered;
    };
    uint32_t id,session,hz,kind,probe,channel,phase,total,used,offset;
    uint32_t active,ready,error,deadline,last_request;
    uint64_t first,next,expected;
    uint32_t word_bytes;
    uint32_t streaming,stride,write_slot,read_slot,queued,armed;
    uint32_t lease,last_slot,last_valid,dropped;
    uint32_t bad_word,slot_mask[NP2_PREVIEW_STREAM_SLOTS];
    uint64_t slot_first[NP2_PREVIEW_STREAM_SLOTS];
} XE_NP_Np2Preview;
#if defined(_MSC_VER)
#pragma warning(pop)
#endif
int XE_NP_Np2Preview_Request(XE_NP_Np2Preview *,const uint8_t *,uint32_t session,uint32_t hz,int recording,uint32_t now);
void XE_NP_Np2Preview_Tap(XE_NP_Np2Preview *,const uint8_t *,uint32_t bytes,uint64_t first,int pressure);
void XE_NP_Np2Preview_Drop(XE_NP_Np2Preview *,uint32_t reason);
/* 224-byte fixed body, padded last fragment; mask only emitted payload bytes,
 * never retained raw data. No payload CRC/copy on IRQ. */
int XE_NP_Np2Preview_Fragment(XE_NP_Np2Preview *,uint8_t body[224]);
/* Stopped-only diagnostic. Source ticks restart each session: a retained
 * preview must never be compared against another recording's SD payload. */
uint32_t XE_NP_Np2Preview_VerifyPacked(const XE_NP_Np2Preview *,uint32_t session,
    const uint8_t *packed,uint64_t first,uint32_t ticks,uint32_t *mismatched);
#endif
