#ifndef XE_NP_RTC_H
#define XE_NP_RTC_H

#include <stdint.h>

/* Private, opt-in V2 RTC provider. It never uses the disabled HAL RTC stubs
 * and never changes backup-register contents. */
#ifndef XE_NP_RTC_ENABLE
#define XE_NP_RTC_ENABLE 0U
#endif

#define XE_NP_RTC_INPUT_HZ   750000U /* 24 MHz HSE / fixed RTC /32 */
#define XE_NP_RTC_PREDIV_A   74U
#define XE_NP_RTC_PREDIV_S   9999U
#define XE_NP_RTC_QUANTUM_US 100U

enum {
    XE_NP_RTC_STATUS_SOURCE_OK        = 0x00000001U,
    XE_NP_RTC_STATUS_CALENDAR_VALID   = 0x00000002U,
    XE_NP_RTC_STATUS_PC_CALIBRATED    = 0x00000004U,
    XE_NP_RTC_STATUS_WRITE_ADMITTED   = 0x00000008U,
    XE_NP_RTC_STATUS_TRANSACTION_BUSY = 0x00000010U,
    XE_NP_RTC_STATUS_DISCONTINUITY    = 0x00000020U,
    XE_NP_RTC_STATUS_CONFLICT         = 0x00000040U,
    XE_NP_RTC_STATUS_LOCAL_UNAVAILABLE= 0x00000080U,
    XE_NP_RTC_STATUS_SHIFT_PENDING    = 0x00000100U
};

/* UTC, 24-hour Gregorian convention. lower_us..upper_us is the actual
 * 100-us RTC quantum containing the sampled instant; it is not PC error. */
typedef struct {
    uint16_t year;
    uint8_t month,day,weekday,hour,minute,second;
    uint32_t lower_us,upper_us;
    uint32_t raw_ssr,raw_tr,raw_dr,prer,calr,bdcr;
    uint32_t status,calibration_generation;
} XE_NP_RtcSample;

/* Init may provision only an unselected source and only after explicit idle
 * admission. It never resets/migrates a pre-existing RTC configuration. */
int XE_NP_Rtc_Init(void);
uint32_t XE_NP_Rtc_Status(void);
/* Foreground-only RAM state; never polls RTC hardware or changes ownership. */
uint32_t XE_NP_Rtc_ShiftPending(void);
int XE_NP_Rtc_Read(XE_NP_RtcSample *out);

/* Foreground lifecycle only. Busy or unadmitted state closes every mutation.
 * Clearing busy never reopens writes; the caller must explicitly admit idle. */
void XE_NP_Rtc_AdmitIdle(uint32_t admitted);
void XE_NP_Rtc_SetTransactionBusy(uint32_t busy);
void XE_NP_Rtc_Invalidate(void);

/* Idle, read-only completion of an accepted fractional shift.  It never
 * writes or reopens admission; nonzero means the pending calibration became
 * readable. */
int XE_NP_Rtc_Service(void);

/* Pre-recording only. subsecond_us is rounded to the nearest representable
 * 100-us RTC quantum; year is 2000..2099 and weekday is RTC's 1..7 value. */
int XE_NP_Rtc_SetCalendarPhase(const XE_NP_RtcSample *utc,
                               uint32_t subsecond_us,
                               uint32_t calibration_generation);

#endif
