#include "xe_np_np2_producer.h"
#include "xe_np_np2_ep81_headroom_diag.h"
#if XE_NP_NP2_EP81_HEADROOM_DIAG && (XE_NP_IMAGE_ROLE != 2U)
#error "EP81 headroom diagnostics are USB-test-only"
#endif
#include <string.h>
#if defined(XE_NP_NP2_USB_GRID_EXPERIMENT) && XE_NP_NP2_USB_GRID_EXPERIMENT && \
    defined(XE_NP_GRID_STARTUP_DIAG) && XE_NP_GRID_STARTUP_DIAG
#include "xe_np_imu_grid_diag.h"
#endif

#if defined(XE_NP_NP2_LIVE_SD_COPY_COST_DIAG) && XE_NP_NP2_LIVE_SD_COPY_COST_DIAG
void XE_NP_Np2LiveSd_ProducerReceipt(const XE_NP_Np2Producer *p,uint32_t event);
#endif

#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
typedef struct {
    uint32_t ring_bytes,event_bytes,event_lead_max,unpublished_bound,retention_limit,
             stall_timeout_ms;
    uint8_t full_node_irq;
} XE_NP_Np2ProducerGeometry;

static int select_geometry(uint32_t bytes,uint8_t stride,XE_NP_Np2ProducerGeometry *g)
{
    if(bytes==XE_NP_NP2_RING_BYTES) {
        if(XE_NP_NP2_HALF_BYTES%stride)return -1;
        g->ring_bytes=XE_NP_NP2_RING_BYTES;
        g->event_bytes=XE_NP_NP2_EVENT_BYTES;
        g->event_lead_max=XE_NP_NP2_EVENT_LEAD_MAX;
        g->unpublished_bound=XE_NP_NP2_UNPUBLISHED_BOUND;
        g->retention_limit=XE_NP_NP2_RETENTION_LIMIT;
        g->stall_timeout_ms=XE_NP_NP2_STALL_TIMEOUT_MS;
        g->full_node_irq=XE_NP_NP2_FULL_NODE_IRQ;
        return 0;
    }
    if(bytes!=NP2_DIRECT_RING_TICKS || stride!=1U)return -1;
    g->ring_bytes=NP2_DIRECT_RING_TICKS;
    g->event_bytes=NP2_DIRECT_TICKS;
    g->event_lead_max=NP2_DIRECT_TICKS+XE_NP_NP2_EVENT_LATE_MARGIN_BYTES;
    g->unpublished_bound=61440U;
    g->retention_limit=NP2_DIRECT_RING_TICKS-NP2_DIRECT_TICKS;
    g->stall_timeout_ms=2U+((NP2_DIRECT_TICKS*1000U+XE_NP_NP2_SOURCE_BYTE_RATE_HZ-1U)/
                            XE_NP_NP2_SOURCE_BYTE_RATE_HZ);
    g->full_node_irq=1U;
    return 0;
}

#define PRODUCER_RING_BYTES(p) ((p)->ring_bytes)
#define PRODUCER_EVENT_BYTES(p) ((p)->event_bytes)
#define PRODUCER_EVENT_LEAD_MAX(p) ((p)->event_lead_max)
#define PRODUCER_UNPUBLISHED_BOUND(p) ((p)->unpublished_bound)
#define PRODUCER_RETENTION_LIMIT(p) ((p)->retention_limit)
#define PRODUCER_STALL_TIMEOUT_MS(p) ((p)->stall_timeout_ms)
#else
#define PRODUCER_RING_BYTES(p) XE_NP_NP2_RING_BYTES
#define PRODUCER_EVENT_BYTES(p) XE_NP_NP2_EVENT_BYTES
#define PRODUCER_EVENT_LEAD_MAX(p) XE_NP_NP2_EVENT_LEAD_MAX
#define PRODUCER_UNPUBLISHED_BOUND(p) XE_NP_NP2_UNPUBLISHED_BOUND
#define PRODUCER_RETENTION_LIMIT(p) XE_NP_NP2_RETENTION_LIMIT
#define PRODUCER_STALL_TIMEOUT_MS(p) XE_NP_NP2_STALL_TIMEOUT_MS
#endif

/* All state shared with IRQ is accessed under the port's critical section.
 * These sections contain only bounded register/state work, never cache/HAL
 * setup, payload copies, SD transactions, or waits. */
static int fault(XE_NP_Np2Producer *p,uint8_t code,const XE_NP_Np2DmaSnapshot *s)
{
    if(!p->error) {
#if defined(XE_NP_NP2_USB_GRID_EXPERIMENT) && XE_NP_NP2_USB_GRID_EXPERIMENT && \
    defined(XE_NP_GRID_STARTUP_DIAG) && XE_NP_GRID_STARTUP_DIAG
        /* Existing producer lock is held. Capture once before fault clears a
         * borrowed loan; no polling or extra work on successful snapshots. */
        volatile XE_NP_GridDiagProducerFault *d=&xe_np_grid_startup_diag.producer_fault;
        if(xe_np_grid_startup_diag.stage[XE_NP_GRID_DIAG_TIMER_START].valid && !d->valid){
            d->code=code;d->state=p->state;d->borrowed=p->borrowed;
            d->source_bytes_per_tick=p->source_bytes_per_tick;
            d->published_offset=p->published_offset;d->consumer_offset=p->consumer_offset;
            d->max_backlog=p->max_backlog;d->produced=p->produced;d->consumed=p->consumed;
            d->held_source_end=p->held.source_end;d->held_ticks=p->held.ticks;d->held_bytes=p->held.bytes;
            d->snapshot_valid=(s!=NULL);
            if(s){d->snapshot_ms=s->now_ms;d->snapshot_offset=s->offset;
                d->snapshot_events=s->events;d->snapshot_fault=s->fault;d->snapshot_active=s->active;}
            d->valid=1U;
        }
#endif
#if XE_NP_NP2_EP81_HEADROOM_DIAG
        if(code==XE_NP_NP2_PRODUCER_OVERWRITE){
            uint32_t retained=p->published_offset>=p->consumer_offset?
                p->published_offset-p->consumer_offset:
                p->published_offset+PRODUCER_RING_BYTES(p)-p->consumer_offset;
            uint32_t backlog=retained+PRODUCER_UNPUBLISHED_BOUND(p);
            uint32_t units=(backlog>>7U)+((backlog&127U)!=0U);
            uint8_t flags=XE_NP_EP81_HEADROOM_FLAG_UNKNOWN;
            if(units>UINT16_MAX){units=UINT16_MAX;flags|=XE_NP_EP81_HEADROOM_FLAG_SATURATED;}
            /* Producer has no verified NPUSB03 block index. Zero time means
             * unknown when the fault was not supplied a DMA snapshot. */
            XE_NP_Ep81HeadroomDiag_ProducerFault(s?s->now_ms:0U,UINT32_MAX,
                                                (uint16_t)units,code,flags);
        }
#endif
        uint8_t frozen=p->state==XE_NP_NP2_PRODUCER_FROZEN;
        p->error=code;if(s)p->last_fault=*s;
        p->state=XE_NP_NP2_PRODUCER_FAILED;
#if defined(XE_NP_NP2_LIVE_SD_COPY_COST_DIAG) && XE_NP_NP2_LIVE_SD_COPY_COST_DIAG
        XE_NP_Np2LiveSd_ProducerReceipt(p,2U);
#endif
        /* A frozen ring is already certified quiescent. Re-stopping it
         * would misreport intentionally disabled clocks as a new HW fault. */
        if(!frozen){
            XE_NP_Np2DmaSnapshot stopped={0};p->hw.stop(p->hw.user,&stopped);
            if(!s)p->last_fault=stopped;
        }
        p->borrowed=0;
    }
    return -1;
}
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
static int drain_overflow(XE_NP_Np2Producer *p)
{
    /* The first complete source block establishes framing/D8 calibration.
     * Startup failure must not turn into a fabricated nonzero origin. */
    if(!p->drain_ticks || p->consumed<p->drain_ticks)return -1;
    /* Rare overflow path only: drop to a whole logical block boundary. Keep
     * absolute source time and its physical ring position paired; all queued
     * SD/PSRAM owners remain untouched. A revoked CPU/DMA loan cannot publish. */
    uint64_t oldest=p->produced+PRODUCER_UNPUBLISHED_BOUND(p)-
        PRODUCER_RETENTION_LIMIT(p)+1U;
    uint64_t next=((oldest+p->drain_ticks-1U)/p->drain_ticks)*p->drain_ticks;
    if(next<=p->consumed || next>p->produced)return -1;
    p->dropped_ticks+=next-p->consumed;
    p->consumed=next;p->consumer_offset=(uint32_t)(next%PRODUCER_RING_BYTES(p));
    if(p->overflow_count!=UINT32_MAX)p->overflow_count++;
    if(p->borrowed){p->borrowed=0U;p->drain_revoked=1U;}
    return 0;
}
#endif
static int check(XE_NP_Np2Producer *p,const XE_NP_Np2DmaSnapshot *s)
{
    if(p->state!=XE_NP_NP2_PRODUCER_ACTIVE)return -1;
    if(s->fault || !s->active)return fault(p,XE_NP_NP2_PRODUCER_HW,s);
    if(s->events && s->events!=p->expected)return fault(p,XE_NP_NP2_PRODUCER_IRQ,s);
    /* Foreground DirectProgress also polls a stale IRQ boundary before
     * declaring a stall. If the expected TC is already latched, publish that
     * real boundary even when integer SysTick age has crossed the watchdog;
     * position/retention checks below still reject a late or coalesced TC. */
    if(!s->events && s->now_ms-p->last_irq_ms>=PRODUCER_STALL_TIMEOUT_MS(p))
        return fault(p,XE_NP_NP2_PRODUCER_STALL,s);
    /* PSSI's explicit byte-DMA mode advances CDAR once per 8-bit sample, so
     * an IRQ snapshot may be at any byte address. Legacy FIFO-word modes
     * retain the word-alignment check as an inexpensive descriptor guard. */
    if(s->offset>PRODUCER_RING_BYTES(p) ||
       ((XE_NP_NP2_CAPTURE_BYTE_DMA == 0U) && (s->offset&3U)))
        return fault(p,XE_NP_NP2_PRODUCER_POSITION,s);
    uint32_t offset=s->offset==PRODUCER_RING_BYTES(p)?0U:s->offset;
    uint32_t lead=offset>=p->published_offset?offset-p->published_offset:
                  offset+PRODUCER_RING_BYTES(p)-p->published_offset;
    /* The TC flag can remain latched while GPDMA continues into the next
     * repeated block. Allow the characterized bounded IRQ/snapshot latency;
     * publication still advances by exactly one complete record event. */
    if(lead>PRODUCER_EVENT_LEAD_MAX(p) ||
       (!s->events && lead>PRODUCER_EVENT_BYTES(p)) ||
       (s->events && lead+32U<PRODUCER_EVENT_BYTES(p)))
        return fault(p,XE_NP_NP2_PRODUCER_POSITION,s);
    /* The largest unpublished bound is expressed in raw bytes. Using that
     * constant in the practically unreachable 64-bit timeline-wrap guard is
     * conservative for both one- and two-byte source strides and avoids a
     * runtime divide in every DMA interrupt. */
    if(p->produced>UINT64_MAX-PRODUCER_UNPUBLISHED_BOUND(p))
        return fault(p,XE_NP_NP2_PRODUCER_POSITION,s);
    /* Published/consumer byte offsets wrap at the DMA ring boundary. The
     * retention guard faults with at least one whole node still free, so the
     * consumer can never be a full lap behind and this modular distance is
     * the exact queued-byte count. Keep absolute 64-bit ticks for the API,
     * but use 32-bit ring arithmetic in this per-IRQ guard. */
    uint32_t retained=p->published_offset>=p->consumer_offset?
        p->published_offset-p->consumer_offset:
        p->published_offset+PRODUCER_RING_BYTES(p)-p->consumer_offset;
    uint32_t backlog=retained+PRODUCER_UNPUBLISHED_BOUND(p);
    if(backlog>=PRODUCER_RETENTION_LIMIT(p)){
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
        if(!drain_overflow(p))return 0;
#endif
        return fault(p,XE_NP_NP2_PRODUCER_OVERWRITE,s);
    }
    if(backlog>p->max_backlog)p->max_backlog=(uint32_t)backlog;
    return 0;
}
static int snapshot(XE_NP_Np2Producer *p)
{
    /* Only a successful bounded hardware stop admits immutable draining.
     * Ordinary Stop remains terminal; stopped clocks cannot certify a live
     * snapshot, and a sticky fault must never become drainable. */
    if(p->state==XE_NP_NP2_PRODUCER_FROZEN && !p->error)return 0;
    XE_NP_Np2DmaSnapshot s={0};p->hw.snapshot(p->hw.user,&s);return check(p,&s);
}
static uint32_t ticks_from_bytes(const XE_NP_Np2Producer *p,uint32_t bytes)
{ return p->source_bytes_per_tick==2U?(bytes>>1U):bytes; }
static int post_ack_recheck(XE_NP_Np2Producer *p)
{
    if(!p->hw.irq_recheck)return snapshot(p);
    XE_NP_Np2DmaSnapshot quick={0};p->hw.irq_recheck(p->hw.user,&quick);
    if(!quick.fault && quick.active && (!quick.events || quick.events==p->expected))return 0;
    XE_NP_Np2DmaSnapshot detail={0};p->hw.snapshot(p->hw.user,&detail);
    int result=check(p,&detail);
    if(result)return result;
    /* Preserve a transient quick-read fault even if a later full snapshot no
     * longer sees it. Event flags asserted after W1C are never acknowledged
     * here; an expected next event remains pending for the normal IRQ entry. */
    quick.offset=detail.offset;
    return fault(p,(quick.fault || !quick.active)?XE_NP_NP2_PRODUCER_HW:
                 XE_NP_NP2_PRODUCER_IRQ,&quick);
}
static int arm(void *user,uint64_t *origin)
{
    XE_NP_Np2Producer *p=user;
    if(!origin || p->state!=XE_NP_NP2_PRODUCER_IDLE || !p->ring)return -1;
    uint32_t key=p->hw.lock(p->hw.user);
    p->state=XE_NP_NP2_PRODUCER_ACTIVE;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    p->expected=p->full_node_irq?XE_NP_NP2_EVENT_TC:XE_NP_NP2_EVENT_HT;
#else
    p->expected=XE_NP_NP2_FIRST_EVENT;
#endif
    p->last_irq_ms=p->hw.now_ms(p->hw.user);
    p->hw.unlock(p->hw.user,key);
    /* Setup is stopped-only and may take time; interrupts are not masked.
     * begin must not enable PSSI until the DMA and export are fully ready. */
    int result=p->hw.begin(p->hw.user,p->ring,PRODUCER_RING_BYTES(p));
    key=p->hw.lock(p->hw.user);
    p->last_irq_ms=p->hw.now_ms(p->hw.user);
    if(result || p->error)result=fault(p,XE_NP_NP2_PRODUCER_HW,NULL);
    else result=snapshot(p);
    if(!result)*origin=0;
    p->hw.unlock(p->hw.user,key);return result;
}
static int status(void *user,uint64_t *produced)
{
    if(!produced)return -1;
    XE_NP_Np2Producer *p=user;uint32_t key=p->hw.lock(p->hw.user);
    int result=snapshot(p);if(!result)*produced=p->produced;
    p->hw.unlock(p->hw.user,key);return result;
}
static int barrier(void *user,uint64_t *upper)
{
    if(!upper)return -1;
    XE_NP_Np2Producer *p=user;uint32_t key=p->hw.lock(p->hw.user);
    int result=snapshot(p);if(!result)*upper=p->produced+
        (p->state==XE_NP_NP2_PRODUCER_FROZEN?0U:
         ticks_from_bytes(p,PRODUCER_UNPUBLISHED_BOUND(p)));
    p->hw.unlock(p->hw.user,key);return result;
}
static int take(void *user,uint32_t maximum,XE_NP_Np2Span *span)
{
    XE_NP_Np2Producer *p=user;uint32_t key=p->hw.lock(p->hw.user);int result=-1;
    if(!span || !maximum || maximum>XE_NP_NP2_WIRE_MAX_SPAN || maximum%128U || p->borrowed)
        (void)fault(p,XE_NP_NP2_PRODUCER_ARGUMENT,NULL);
    else if(!snapshot(p)) {
        uint64_t available=p->produced-p->consumed;
        uint32_t count=available>maximum?maximum:(uint32_t)available;
        uint32_t contiguous=(PRODUCER_RING_BYTES(p)-p->consumer_offset)/p->source_bytes_per_tick;
        if(count>contiguous)count=contiguous;
        if(!count)result=0;
        else {
            p->held.data=p->ring+p->consumer_offset;p->held.ticks=count;
            p->held.bytes=count*p->source_bytes_per_tick;
            p->held.source_end=p->consumed+count;p->borrowed=1;
            *span=p->held;result=1;
#if defined(XE_NP_NP2_LIVE_SD_COPY_COST_DIAG) && XE_NP_NP2_LIVE_SD_COPY_COST_DIAG
            XE_NP_Np2LiveSd_ProducerReceipt(p,1U);
#endif
        }
    }
    p->hw.unlock(p->hw.user,key);return result;
}
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
/* Direct PSSI is a producer token, not a contiguous CPU-owned span.  The
 * later port owns certified retirement after publication; refusing here must
 * not fault or stop a healthy DMA producer. */
static int direct_take_refused(void *user,uint32_t maximum,XE_NP_Np2Span *span)
{
    (void)user;(void)maximum;(void)span;
    return -1;
}
#endif
static int retained(void *user,const XE_NP_Np2Span *span)
{
    XE_NP_Np2Producer *p=user;uint32_t key=p->hw.lock(p->hw.user);int result;
    if(!p->borrowed || !span || span->data!=p->held.data || span->ticks!=p->held.ticks ||
       span->bytes!=p->held.bytes ||
       span->source_end!=p->held.source_end){
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
        if(!p->error && p->drain_revoked && span &&
           span->data==p->held.data && span->ticks==p->held.ticks &&
           span->bytes==p->held.bytes && span->source_end==p->held.source_end){
            p->drain_revoked=0U;result=1;
        }
        else
#endif
            result=fault(p,XE_NP_NP2_PRODUCER_ARGUMENT,NULL);
    }else{
        result=snapshot(p);
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
        if(!result && !p->borrowed){p->drain_revoked=0U;result=1;} /* snapshot revoked this loan */
#endif
    }
    p->hw.unlock(p->hw.user,key);return result;
}
static void invalidate(void *user,const uint8_t *data,uint32_t count)
{
    XE_NP_Np2Producer *p=user;
    uint32_t failed=0U;
    p->invalidate_calls++;
    p->last_invalidate_address=(uint32_t)(uintptr_t)data;
    p->last_invalidate_count=count;
    if(!p->borrowed)failed|=1U;
    if(data!=p->held.data)failed|=2U;
    if(!count)failed|=4U;
    if(count>p->held.bytes)failed|=8U;
    if(!failed && p->hw.invalidate(p->hw.user,data,count))failed|=16U;
    if(failed) {
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
        if(failed==1U && !p->error && p->drain_revoked)return;
#endif
        p->invalidate_fail_mask=failed;
        uint32_t key=p->hw.lock(p->hw.user);(void)fault(p,XE_NP_NP2_PRODUCER_CACHE,NULL);
        p->hw.unlock(p->hw.user,key);
    }
}
static int release(void *user)
{
    XE_NP_Np2Producer *p=user;uint32_t key=p->hw.lock(p->hw.user);
    int result=-1;
    if(p->borrowed && !p->error) {
        p->consumed=p->held.source_end;p->consumer_offset+=p->held.bytes;
        if(p->consumer_offset==PRODUCER_RING_BYTES(p))p->consumer_offset=0;
        p->borrowed=0;result=0;
    }
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
    else if(!p->error && p->drain_revoked){p->drain_revoked=0U;result=1;} /* IRQ won the retained/release race */
#endif
    p->hw.unlock(p->hw.user,key);return result;
}
static uint32_t now_ms(void *user)
{ XE_NP_Np2Producer *p=user;return p->hw.now_ms(p->hw.user); }
static int stopped_status(void *user,uint64_t *produced)
{
    if(!produced)return -1;
    XE_NP_Np2Producer *p=user;uint32_t key=p->hw.lock(p->hw.user);
    int result=p->state==XE_NP_NP2_PRODUCER_STOPPED && !p->error?0:-1;
    if(!result)*produced=p->produced;
    p->hw.unlock(p->hw.user,key);return result;
}
static int disjoint(const void *a,uint32_t an,const void *b,uint32_t bn)
{
    uintptr_t x=(uintptr_t)a,y=(uintptr_t)b;
    return x<=UINTPTR_MAX-an && y<=UINTPTR_MAX-bn && (x+an<=y || y+bn<=x);
}
int XE_NP_Np2Producer_BindWithStride(XE_NP_Np2Producer *p,uint8_t *ring,
                         uint32_t bytes,uint8_t source_bytes_per_tick,
                         const XE_NP_Np2DmaIo *hw,XE_NP_Np2ProducerIo *io)
{
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    XE_NP_Np2ProducerGeometry geometry={0};
#endif
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(!p || p->state!=XE_NP_NP2_PRODUCER_IDLE || p->ring || !ring ||
       ((uintptr_t)ring&31U) ||
       (source_bytes_per_tick!=1U && source_bytes_per_tick!=2U) ||
       (uintptr_t)ring>UINTPTR_MAX-bytes || !hw || !io || !hw->lock || !hw->unlock ||
       !hw->begin || !hw->snapshot || !hw->ack || !hw->stop || !hw->invalidate || !hw->now_ms ||
       !disjoint(p,sizeof(*p),ring,bytes) || !disjoint(io,sizeof(*io),ring,bytes) ||
       !disjoint(io,sizeof(*io),p,sizeof(*p)) || !disjoint(io,sizeof(*io),hw,sizeof(*hw)))return -1;
    if(select_geometry(bytes,source_bytes_per_tick,&geometry))return -1;
#else
    if(!p || p->state!=XE_NP_NP2_PRODUCER_IDLE || p->ring || !ring ||
       ((uintptr_t)ring&31U) || bytes!=XE_NP_NP2_RING_BYTES ||
       (source_bytes_per_tick!=1U && source_bytes_per_tick!=2U) ||
       (XE_NP_NP2_HALF_BYTES%source_bytes_per_tick)!=0U ||
       (uintptr_t)ring>UINTPTR_MAX-bytes || !hw || !io || !hw->lock || !hw->unlock ||
       !hw->begin || !hw->snapshot || !hw->ack || !hw->stop || !hw->invalidate || !hw->now_ms ||
       !disjoint(p,sizeof(*p),ring,bytes) || !disjoint(io,sizeof(*io),ring,bytes) ||
       !disjoint(io,sizeof(*io),p,sizeof(*p)) || !disjoint(io,sizeof(*io),hw,sizeof(*hw)))return -1;
#endif
    p->hw=*hw;p->ring=ring;p->source_bytes_per_tick=source_bytes_per_tick;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    p->ring_bytes=geometry.ring_bytes;p->event_bytes=geometry.event_bytes;
    p->event_lead_max=geometry.event_lead_max;p->unpublished_bound=geometry.unpublished_bound;
    p->retention_limit=geometry.retention_limit;p->stall_timeout_ms=geometry.stall_timeout_ms;
    p->full_node_irq=geometry.full_node_irq;
#endif
    XE_NP_Np2ProducerIo result={p,arm,status,barrier,take,retained,invalidate,release,now_ms,stopped_status};
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(p->ring_bytes==NP2_DIRECT_RING_TICKS)result.take=direct_take_refused;
#endif
    *io=result;return 0;
}
int XE_NP_Np2Producer_Bind(XE_NP_Np2Producer *p,uint8_t *ring,uint32_t bytes,
                         const XE_NP_Np2DmaIo *hw,XE_NP_Np2ProducerIo *io)
{return XE_NP_Np2Producer_BindWithStride(p,ring,bytes,1U,hw,io);}
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
int XE_NP_Np2Producer_EnableDrain(XE_NP_Np2Producer *p,uint32_t ticks)
{
    if(!p || !p->ring || p->state!=XE_NP_NP2_PRODUCER_IDLE || p->error ||
       p->borrowed || p->source_bytes_per_tick!=1U || !ticks || ticks%128U ||
       ticks>PRODUCER_RETENTION_LIMIT(p)-PRODUCER_UNPUBLISHED_BOUND(p))return -1;
    p->drain_ticks=ticks;return 0;
}
#endif
/* Caller owns the producer lock. Stop latches real late hardware faults;
 * an expected, unpublished partial tail is not part of the stored extent. */
static int freeze(XE_NP_Np2Producer *p)
{
    XE_NP_Np2DmaSnapshot last={0};p->hw.stop(p->hw.user,&last);
    if(last.fault || last.active || (last.events && last.events!=p->expected)){
        p->error=XE_NP_NP2_PRODUCER_HW;p->last_fault=last;
        p->state=XE_NP_NP2_PRODUCER_FAILED;p->borrowed=0;return -1;
    }
    p->state=XE_NP_NP2_PRODUCER_FROZEN;return 0;
}
int XE_NP_Np2Producer_Freeze(XE_NP_Np2Producer *p)
{
    if(!p || !p->ring)return -1;
    uint32_t key=p->hw.lock(p->hw.user);int result=-1;
    if(p->state==XE_NP_NP2_PRODUCER_FROZEN && !p->error)result=0;
    else if(p->state==XE_NP_NP2_PRODUCER_ACTIVE && !snapshot(p))result=freeze(p);
    p->hw.unlock(p->hw.user,key);return result;
}
void XE_NP_Np2Producer_IrqUntil(XE_NP_Np2Producer *p,uint64_t limit)
{
    if(!p || !p->ring)return;
    uint32_t key=p->hw.lock(p->hw.user);
    XE_NP_Np2DmaSnapshot s={0};p->hw.snapshot(p->hw.user,&s);
    if(!check(p,&s) && s.events) {
        p->hw.ack(p->hw.user,s.events); /* clear ONLY the observed expected flag */
        p->produced+=ticks_from_bytes(p,PRODUCER_EVENT_BYTES(p));
        p->published_offset+=PRODUCER_EVENT_BYTES(p);
        if(p->published_offset==PRODUCER_RING_BYTES(p))p->published_offset=0;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
        if(!p->full_node_irq)
            p->expected^=XE_NP_NP2_EVENT_HT|XE_NP_NP2_EVENT_TC;
#elif !XE_NP_NP2_FULL_NODE_IRQ
        p->expected^=XE_NP_NP2_EVENT_HT|XE_NP_NP2_EVENT_TC;
#endif
        p->last_irq_ms=s.now_ms;p->irq_count++;
#if XE_NP_NP2_EP81_HEADROOM_DIAG
        if((p->irq_count&7U)==0U){
            uint32_t retained=p->published_offset>=p->consumer_offset?
                p->published_offset-p->consumer_offset:
                p->published_offset+PRODUCER_RING_BYTES(p)-p->consumer_offset;
            uint32_t backlog=retained+PRODUCER_UNPUBLISHED_BOUND(p);
            uint32_t units=(backlog>>7U)+((backlog&127U)!=0U);
            uint8_t flags=XE_NP_EP81_HEADROOM_FLAG_UNKNOWN;
            if(units>UINT16_MAX){units=UINT16_MAX;flags|=XE_NP_EP81_HEADROOM_FLAG_SATURATED;}
            XE_NP_Ep81HeadroomDiag_ProducerSample(s.now_ms,UINT32_MAX,
                                                 (uint16_t)units,p->state,flags);
        }
#endif
        /* Re-read after W1C/publication. A new opposite flag is left pending;
         * a fault/coalesced/duplicate event can never get erased by this IRQ. */
        if(!post_ack_recheck(p) && limit && p->produced>=limit){
            if(p->produced==limit)(void)freeze(p);
            else (void)fault(p,XE_NP_NP2_PRODUCER_POSITION,NULL);
        }
    }
    p->hw.unlock(p->hw.user,key);
}
void XE_NP_Np2Producer_Irq(XE_NP_Np2Producer *p)
{XE_NP_Np2Producer_IrqUntil(p,0U);}
void XE_NP_Np2Producer_Stop(XE_NP_Np2Producer *p)
{
    if(!p || !p->ring)return;
    uint32_t key=p->hw.lock(p->hw.user);
    if(p->state==XE_NP_NP2_PRODUCER_FROZEN && !p->error){
        p->state=XE_NP_NP2_PRODUCER_STOPPED;p->borrowed=0;
    }else if(p->state==XE_NP_NP2_PRODUCER_ACTIVE && !snapshot(p)) {
        if(!freeze(p))p->state=XE_NP_NP2_PRODUCER_STOPPED;
        p->borrowed=0;
    }
    p->hw.unlock(p->hw.user,key);
}
void XE_NP_Np2Producer_Abort(XE_NP_Np2Producer *p)
{
    if(!p || !p->ring)return;
    uint32_t key=p->hw.lock(p->hw.user);
    (void)fault(p,XE_NP_NP2_PRODUCER_HW,NULL);p->hw.unlock(p->hw.user,key);
}
