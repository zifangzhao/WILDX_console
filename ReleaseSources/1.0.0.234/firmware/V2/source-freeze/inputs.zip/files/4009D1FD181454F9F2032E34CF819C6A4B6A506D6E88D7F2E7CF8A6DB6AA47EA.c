#include "xe_np_nric.h"

#include <stddef.h>
#if XE_NP_NRIC_GPIO_I2C_ENABLE
#include "xe_np_nric_gpio.h"
#endif

#define XE_NP_NRIC_DIG_RESET_SETTLE_MS 10U

static void XE_NP_Nric_WaitBusFree(void)
{
#if (XE_NP_BOARD_V2_PSSI_NP1_ENABLE != 0U)
    /* Let internally pulled-up SDA settle after STOP before another START.
     * These foreground control transactions are not part of raw sampling. */
    HAL_Delay(1U);
#endif
}

#define XE_NP_NRIC_DIAG_STEP_NONE 0U
#define XE_NP_NRIC_DIAG_STEP_WRITE_OP_MODE_IDLE 1U
#define XE_NP_NRIC_DIAG_STEP_WRITE_CAL_MOD 2U
#define XE_NP_NRIC_DIAG_STEP_WRITE_REC_MOD_RESET 3U
#define XE_NP_NRIC_DIAG_STEP_WRITE_REC_MOD_BOOT 4U
#define XE_NP_NRIC_DIAG_STEP_PROGRAM_LENGTH_HI 5U
#define XE_NP_NRIC_DIAG_STEP_PROGRAM_LENGTH_LO 6U
#define XE_NP_NRIC_DIAG_STEP_PROGRAM_BURST_1 7U
#define XE_NP_NRIC_DIAG_STEP_PROGRAM_BURST_2 8U
#define XE_NP_NRIC_DIAG_STEP_PROGRAM_WAIT_READY 9U
#define XE_NP_NRIC_DIAG_STEP_WRITE_SYNC 10U
#define XE_NP_NRIC_DIAG_STEP_WRITE_REC_MOD_RUN 11U
#define XE_NP_NRIC_DIAG_STEP_WRITE_OP_MODE_RUN 12U
#define XE_NP_NRIC_DIAG_STEP_VERIFY_CAL_MOD 13U
#define XE_NP_NRIC_DIAG_STEP_VERIFY_SYNC 14U
#define XE_NP_NRIC_DIAG_STEP_VERIFY_REC_MOD 15U
#define XE_NP_NRIC_DIAG_STEP_VERIFY_OP_MODE 16U
#define XE_NP_NRIC_DIAG_STEP_READ_FINAL_STATUS 17U
#define XE_NP_NRIC_DIAG_STEP_FINAL_STATUS 18U

#define XE_NP_NRIC_SR_DIAG_PATTERN_DEFAULT 0U
#define XE_NP_NRIC_SR_DIAG_PATTERN_ZERO 1U
#define XE_NP_NRIC_SR_DIAG_PATTERN_ONE 2U
#define XE_NP_NRIC_SR_DIAG_PATTERN_AA55 3U
#define XE_NP_NRIC_SR_DIAG_PATTERN_01 4U
#define XE_NP_NRIC_SR_DIAG_PATTERN_02 5U
#define XE_NP_NRIC_SR_DIAG_PATTERN_04 6U
#define XE_NP_NRIC_SR_DIAG_PATTERN_08 7U
#define XE_NP_NRIC_SR_DIAG_PATTERN_10 8U
#define XE_NP_NRIC_SR_DIAG_PATTERN_20 9U
#define XE_NP_NRIC_SR_DIAG_PATTERN_40 10U
#define XE_NP_NRIC_SR_DIAG_PATTERN_80 11U
#define XE_NP_NRIC_SR_DIAG_PATTERN_03 12U
#define XE_NP_NRIC_SR_DIAG_PATTERN_07 13U
#define XE_NP_NRIC_SR_DIAG_PATTERN_0F 14U
#define XE_NP_NRIC_SR_DIAG_PATTERN_1F 15U
#define XE_NP_NRIC_SR_DIAG_PATTERN_3F 16U
#define XE_NP_NRIC_SR_DIAG_PATTERN_7F 17U
#define XE_NP_NRIC_SR_DIAG_PATTERN_FIRST_01 18U
#define XE_NP_NRIC_SR_DIAG_PATTERN_LAST_01 19U

#define XE_NP_NRIC_SR_DIAG_TINY_CHAIN_BYTES 1U
#define XE_NP_NRIC_SR_DIAG_SHORT_CHAIN_BYTES 32U
/*
 * The current direct-capture image still depends on bypassing chain2 (0x0D).
 * Leave this enabled until the real CA1 / SR_OUT_OK bring-up issue is fixed,
 * otherwise USB streaming never starts because probe initialization stalls.
 */
#ifndef XE_NP_NRIC_DIAG_SKIP_CHAIN2_PROGRAM
#define XE_NP_NRIC_DIAG_SKIP_CHAIN2_PROGRAM 1U
#endif

#define XE_NP_NRIC_SR_DIAG_FAIL_NONE 0U
#define XE_NP_NRIC_SR_DIAG_FAIL_WRITE_LENGTH_LO 1U
#define XE_NP_NRIC_SR_DIAG_FAIL_WRITE_LENGTH_HI 2U
#define XE_NP_NRIC_SR_DIAG_FAIL_WRITE_PASS_1 3U
#define XE_NP_NRIC_SR_DIAG_FAIL_WRITE_PASS_2 4U
#define XE_NP_NRIC_SR_DIAG_FAIL_WAIT_SR_OK 5U
#define XE_NP_NRIC_SR_DIAG_FAIL_READ_LENGTH_LO 6U
#define XE_NP_NRIC_SR_DIAG_FAIL_READ_LENGTH_HI 7U
#define XE_NP_NRIC_SR_DIAG_FAIL_READ_BURST 8U
#define XE_NP_NRIC_SR_DIAG_FAIL_PREP_RESET 9U
#define XE_NP_NRIC_SR_DIAG_FAIL_PREP_BOOT 10U

volatile XE_NP_NricDiag xe_np_nric_diag;
volatile XE_NP_NricSrReadbackDiag xe_np_nric_sr_diag;

static uint8_t xe_np_nric_sr_readback_buffer[XE_NP_NRIC_BASE_CHAIN_BYTES];
static uint8_t xe_np_nric_base_chain2_runtime[XE_NP_NRIC_BASE_CHAIN_BYTES];
static uint8_t xe_np_nric_base_chain3_runtime[XE_NP_NRIC_BASE_CHAIN_BYTES];
static uint8_t xe_np_nric_base_defaults_initialized = 0U;

static void XE_NP_Nric_UpdateDiag(
    I2C_HandleTypeDef *hi2c,
    uint8_t step,
    uint8_t reg_addr,
    HAL_StatusTypeDef hal_status,
    uint8_t status_reg,
    uint8_t read_value,
    uint8_t expected_value)
{
    xe_np_nric_diag.tick_ms = HAL_GetTick();
    xe_np_nric_diag.i2c_error_code = (hi2c != NULL) ? hi2c->ErrorCode : 0U;
    xe_np_nric_diag.i2c_isr =
        ((hi2c != NULL) && (hi2c->Instance != NULL)) ? hi2c->Instance->ISR : 0U;
    xe_np_nric_diag.step = step;
    xe_np_nric_diag.reg_addr = reg_addr;
    xe_np_nric_diag.hal_status = (uint8_t)hal_status;
    xe_np_nric_diag.status_reg = status_reg;
    xe_np_nric_diag.read_value = read_value;
    xe_np_nric_diag.expected_value = expected_value;
}

/*
 * These arrays are overwritten on first use by an Imec-API-derived default
 * generator. They remain statically allocated so the generated probe binding
 * and retained SR diagnostics can reference a stable buffer.
 */
static uint8_t xe_np_nric_base_chain2_default[XE_NP_NRIC_BASE_CHAIN_BYTES] = {
    0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U,
    0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U,
    0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U,
    0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U,
    0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x08U, 0x42U, 0x10U, 0x00U, 0x00U, 0x02U, 0x10U, 0x84U,
    0x00U, 0x00U, 0x00U, 0x84U, 0x21U, 0x00U, 0x00U, 0x00U, 0x21U, 0x08U, 0x40U, 0x00U, 0x00U, 0x08U, 0x42U, 0x10U,
    0x00U, 0x00U, 0x02U, 0x10U, 0x84U, 0x00U, 0x00U, 0x00U, 0x84U, 0x21U, 0x00U, 0x00U, 0x00U, 0x21U, 0x08U, 0x40U,
    0x00U, 0x00U
};

static uint8_t xe_np_nric_base_chain3_default[XE_NP_NRIC_BASE_CHAIN_BYTES] = {
    0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U,
    0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U,
    0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U,
    0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U,
    0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x92U, 0x49U, 0x24U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U,
    0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x20U, 0x08U, 0x42U, 0x10U, 0x00U, 0x00U, 0x02U, 0x10U, 0x84U,
    0x00U, 0x00U, 0x00U, 0x84U, 0x21U, 0x00U, 0x00U, 0x00U, 0x21U, 0x08U, 0x40U, 0x00U, 0x00U, 0x08U, 0x42U, 0x10U,
    0x00U, 0x00U, 0x02U, 0x10U, 0x84U, 0x00U, 0x00U, 0x00U, 0x84U, 0x21U, 0x00U, 0x00U, 0x00U, 0x21U, 0x08U, 0x40U,
    0x00U, 0x00U
};

static void XE_NP_Nric_SetBaseChainBit(uint8_t *chain, uint16_t bit_offset, uint8_t value)
{
    uint16_t byte_index;
    uint8_t mask;

    if((chain == NULL) || (bit_offset >= (XE_NP_NRIC_BASE_CHAIN_BYTES * 8U)))
    {
        return;
    }

    byte_index = (uint16_t)(bit_offset / 8U);
    mask = (uint8_t)(1U << (bit_offset & 0x07U));
    if(value != 0U)
    {
        chain[byte_index] |= mask;
    }
    else
    {
        chain[byte_index] &= (uint8_t)(~mask);
    }
}

static void XE_NP_Nric_EnsureDefaultBaseChainsInitialized(void)
{
    uint16_t index;
    uint16_t channel;
    uint8_t *target_chain;
    uint16_t ref_bit_offset;
    uint16_t gain_byte_index;

    if(xe_np_nric_base_defaults_initialized != 0U)
    {
        return;
    }

    for(index = 0U; index < XE_NP_NRIC_BASE_CHAIN_BYTES; ++index)
    {
        xe_np_nric_base_chain2_runtime[index] = 0U;
        xe_np_nric_base_chain3_runtime[index] = 0U;
    }

    for(channel = 0U; channel < 384U; ++channel)
    {
        if((channel & 1U) != 0U)
        {
            /*
             * NRIC SR chain2 (0x0D) carries the API's basecfg_even image,
             * which corresponds to 1-based even channels / 0-based odd index.
             */
            target_chain = xe_np_nric_base_chain2_runtime;
            ref_bit_offset = (uint16_t)((((uint16_t)383U - channel) / 2U) * 3U);
        }
        else
        {
            /*
             * NRIC SR chain3 (0x0C) carries the API's basecfg_odd image,
             * which corresponds to 1-based odd channels / 0-based even index.
             */
            target_chain = xe_np_nric_base_chain3_runtime;
            ref_bit_offset = (uint16_t)((((uint16_t)382U - channel) / 2U) * 3U);
        }

        /* EXT_REF is reference selector 0 in the official API. */
        XE_NP_Nric_SetBaseChainBit(target_chain, ref_bit_offset + 0U, 1U);

        /*
         * Gain bytes start at bit 576 / byte 72. The vendor API writes
         * value<7:0> = [FULL, STDB, LFP<2:0>, AP<2:0>].
         */
        gain_byte_index = (uint16_t)(72U + (channel / 2U));
        target_chain[gain_byte_index] = 0x04U;
    }

    xe_np_nric_base_defaults_initialized = 1U;
}

void XE_NP_Nric_GetDefaultBaseConfig(
    const uint8_t **chain2,
    uint16_t *chain2_bytes,
    const uint8_t **chain3,
    uint16_t *chain3_bytes)
{
    XE_NP_Nric_EnsureDefaultBaseChainsInitialized();

    if(chain2 != NULL)
    {
        *chain2 = xe_np_nric_base_chain2_runtime;
    }
    if(chain2_bytes != NULL)
    {
        *chain2_bytes = XE_NP_NRIC_BASE_CHAIN_BYTES;
    }
    if(chain3 != NULL)
    {
        *chain3 = xe_np_nric_base_chain3_runtime;
    }
    if(chain3_bytes != NULL)
    {
        *chain3_bytes = XE_NP_NRIC_BASE_CHAIN_BYTES;
    }
}

void XE_NP_NricConfig_InitDefaults(XE_NP_NricConfig *config)
{
    if(config == NULL)
    {
        return;
    }

#if XE_NP_NRIC_USE_SR_DEFAULT_STARTUP
    config->chain2 = NULL;
    config->chain2_bytes = 0U;
    config->chain3 = NULL;
    config->chain3_bytes = 0U;
#else
    XE_NP_Nric_GetDefaultBaseConfig(
        &config->chain2,
        &config->chain2_bytes,
        &config->chain3,
        &config->chain3_bytes);
#endif
    /*
     * Keep the generic NRIC default non-zero so low-level callers still
     * program a visible FIXED-word pattern unless they explicitly override it.
     */
    config->sync_value = XE_NP_NRIC_DEFAULT_SYNC_VALUE;
    config->op_mode_run = XE_NP_NRIC_OP_MODE_RECORD;
#if XE_NP_NRIC_DIAG_DIGITAL_TEST_STREAM
    config->op_mode_run |= XE_NP_NRIC_OP_MODE_DIGITAL_TEST;
#endif
    /*
     * Keep CAL_MOD at the documented recording default. GPO_0 is board-specific
     * and can be wired to a headstage oscillator control, so do not drive it
     * during normal direct-NRIC startup.
     */
    config->cal_mod = XE_NP_NRIC_STARTUP_CAL_MOD;
    config->rec_mod_boot = XE_NP_NRIC_REC_MOD_CH_NRESET |
                           XE_NP_NRIC_REC_MOD_DIG_NRESET;
    config->rec_mod_run = XE_NP_NRIC_REC_MOD_CH_NRESET |
                          XE_NP_NRIC_REC_MOD_DIG_NRESET;
#if XE_NP_NRIC_USE_PSB_HALF_RATE
    config->rec_mod_boot |= XE_NP_NRIC_REC_MOD_PSB_HALF_RATE;
    config->rec_mod_run |= XE_NP_NRIC_REC_MOD_PSB_HALF_RATE;
#endif
#if XE_NP_NRIC_USE_SR_DEFAULT_STARTUP
    config->rec_mod_boot |= XE_NP_NRIC_REC_MOD_SR_DEFAULT;
    config->rec_mod_run |= XE_NP_NRIC_REC_MOD_SR_DEFAULT;
#endif
}

static HAL_StatusTypeDef XE_NP_Nric_WriteRegisterBurst(
    I2C_HandleTypeDef *hi2c,
    uint8_t reg_addr,
    const uint8_t *data,
    uint16_t length)
{
    if((hi2c == NULL) || ((length > 0U) && (data == NULL)))
    {
        return HAL_ERROR;
    }

    XE_NP_Nric_WaitBusFree();
#if XE_NP_NRIC_GPIO_I2C_ENABLE
    if(hi2c->Instance == I2C4)
    {
        return XE_NP_Nric_GpioTransaction(hi2c, reg_addr, (uint8_t *)data, length, 0, 0);
    }
#endif
    return HAL_I2C_Mem_Write(
        hi2c,
        XE_NP_NRIC_I2C_ADDR,
        reg_addr,
        I2C_MEMADD_SIZE_8BIT,
        (uint8_t *)data,
        length,
        XE_NP_NRIC_I2C_TIMEOUT_MS);
}

static HAL_StatusTypeDef XE_NP_Nric_WriteRegisterTwiceWithDelay(
    I2C_HandleTypeDef *hi2c,
    uint8_t reg_addr,
    uint8_t value)
{
    HAL_StatusTypeDef hal_status;

    hal_status = XE_NP_Nric_WriteRegisterBurst(hi2c, reg_addr, &value, 1U);
    if(hal_status != HAL_OK)
    {
        return hal_status;
    }

    HAL_Delay(XE_NP_NRIC_DIG_RESET_SETTLE_MS);
    return XE_NP_Nric_WriteRegisterBurst(hi2c, reg_addr, &value, 1U);
}

static uint8_t XE_NP_Nric_ReverseBits8(uint8_t value)
{
    uint8_t result = 0U;
    uint8_t i;

    for(i = 0U; i < 8U; ++i)
    {
        result = (uint8_t)((result << 1U) | (value & 0x01U));
        value >>= 1U;
    }

    return result;
}

static HAL_StatusTypeDef XE_NP_Nric_WaitShiftRegisterReady(
    I2C_HandleTypeDef *hi2c,
    uint8_t status_before_program,
    uint8_t status_before_valid,
    uint8_t *status_out)
{
    uint32_t start_tick;
    uint8_t status = 0U;

    if(hi2c == NULL)
    {
        return HAL_ERROR;
    }

    start_tick = HAL_GetTick();
    do
    {
        if(XE_NP_Nric_ReadRegister(hi2c, XE_NP_NRIC_REG_STATUS, &status) != HAL_OK)
        {
            return HAL_ERROR;
        }

        if((status & XE_NP_NRIC_STATUS_SR_OUT_OK) != 0U)
        {
            /*
             * The Imec reference reads STATUS immediately after the second SR
             * write pass. Preserve that path so a short-lived SR_OUT_OK pulse
             * is not missed on the first chain, while still rejecting an
             * already-high stale bit when we know STATUS was high before the
             * programming attempt.
             */
            if((status_before_valid == 0U) ||
               ((status_before_program & XE_NP_NRIC_STATUS_SR_OUT_OK) == 0U) ||
               ((HAL_GetTick() - start_tick) != 0U))
            {
                if(status_out != NULL)
                {
                    *status_out = status;
                }
                return HAL_OK;
            }
        }
    } while((HAL_GetTick() - start_tick) < XE_NP_NRIC_SR_PROGRAM_TIMEOUT_MS);

    if(status_out != NULL)
    {
        *status_out = status;
    }
    return HAL_ERROR;
}

static HAL_StatusTypeDef XE_NP_Nric_VerifyRegister(
    I2C_HandleTypeDef *hi2c,
    uint8_t reg_addr,
    uint8_t expected_value,
    uint8_t step)
{
    uint8_t read_value = 0U;

    if(XE_NP_Nric_ReadRegister(hi2c, reg_addr, &read_value) != HAL_OK)
    {
        XE_NP_Nric_UpdateDiag(hi2c, step, reg_addr, HAL_ERROR, 0U, read_value, expected_value);
        return HAL_ERROR;
    }

    if(read_value != expected_value)
    {
        XE_NP_Nric_UpdateDiag(hi2c, step, reg_addr, HAL_ERROR, 0U, read_value, expected_value);
        return HAL_ERROR;
    }

    return HAL_OK;
}

HAL_StatusTypeDef XE_NP_Nric_ProgramShiftRegister(
    I2C_HandleTypeDef *hi2c,
    uint8_t reg_addr,
    const uint8_t *chain_data,
    uint16_t chain_length,
    uint8_t *status_out)
{
    uint8_t length_hi;
    uint8_t length_lo;
    uint8_t status_before_program = 0U;
    uint8_t status_before_valid = 0U;
    uint8_t tx_value;
    uint8_t pass;
    uint16_t i;

    if((hi2c == NULL) || ((chain_length > 0U) && (chain_data == NULL)))
    {
        return HAL_ERROR;
    }

    if(XE_NP_Nric_ReadRegister(hi2c, XE_NP_NRIC_REG_STATUS, &status_before_program) == HAL_OK)
    {
        status_before_valid = 1U;
    }

    length_hi = (uint8_t)((chain_length >> 8U) & 0xFFU);
    length_lo = (uint8_t)(chain_length & 0xFFU);

    for(pass = 0U; pass < 2U; ++pass)
    {
        if(XE_NP_Nric_WriteRegister(hi2c, XE_NP_NRIC_REG_SR_LENGTH1, length_lo) != HAL_OK)
        {
            XE_NP_Nric_UpdateDiag(
                hi2c, XE_NP_NRIC_DIAG_STEP_PROGRAM_LENGTH_LO, XE_NP_NRIC_REG_SR_LENGTH1,
                HAL_ERROR, pass, 0U, length_lo);
            return HAL_ERROR;
        }
        if(XE_NP_Nric_WriteRegister(hi2c, XE_NP_NRIC_REG_SR_LENGTH2, length_hi) != HAL_OK)
        {
            XE_NP_Nric_UpdateDiag(
                hi2c, XE_NP_NRIC_DIAG_STEP_PROGRAM_LENGTH_HI, XE_NP_NRIC_REG_SR_LENGTH2,
                HAL_ERROR, pass, 0U, length_hi);
            return HAL_ERROR;
        }
        for(i = 0U; i < chain_length; ++i)
        {
            tx_value = XE_NP_Nric_ReverseBits8(chain_data[i]);
            if(XE_NP_Nric_WriteRegister(hi2c, reg_addr, tx_value) != HAL_OK)
            {
                XE_NP_Nric_UpdateDiag(
                    hi2c,
                    (pass == 0U) ? XE_NP_NRIC_DIAG_STEP_PROGRAM_BURST_1 :
                                   XE_NP_NRIC_DIAG_STEP_PROGRAM_BURST_2,
                    reg_addr,
                    HAL_ERROR, pass, (uint8_t)i, tx_value);
                return HAL_ERROR;
            }
        }
    }

    if(XE_NP_Nric_WaitShiftRegisterReady(
           hi2c,
           status_before_program,
           status_before_valid,
           status_out) != HAL_OK)
    {
        XE_NP_Nric_UpdateDiag(
            hi2c, XE_NP_NRIC_DIAG_STEP_PROGRAM_WAIT_READY, reg_addr,
            HAL_ERROR, (status_out != NULL) ? *status_out : 0U, 0U,
            XE_NP_NRIC_STATUS_SR_OUT_OK);
        return HAL_ERROR;
    }

    return HAL_OK;
}

HAL_StatusTypeDef XE_NP_Nric_Ping(I2C_HandleTypeDef *hi2c)
{
    if(hi2c == NULL)
    {
        return HAL_ERROR;
    }

    XE_NP_Nric_WaitBusFree();
#if XE_NP_NRIC_GPIO_I2C_ENABLE
    if(hi2c->Instance == I2C4) { return XE_NP_Nric_GpioTransaction(hi2c, 0U, NULL, 0U, 0, 1); }
#endif
    return HAL_I2C_IsDeviceReady(
        hi2c,
        XE_NP_NRIC_I2C_ADDR,
        XE_NP_NRIC_I2C_READY_TRIALS,
        XE_NP_NRIC_I2C_TIMEOUT_MS);
}

HAL_StatusTypeDef XE_NP_Nric_ReadRegister(I2C_HandleTypeDef *hi2c, uint8_t reg_addr, uint8_t *value)
{
    if((hi2c == NULL) || (value == NULL))
    {
        return HAL_ERROR;
    }

    XE_NP_Nric_WaitBusFree();
#if XE_NP_NRIC_GPIO_I2C_ENABLE
    if(hi2c->Instance == I2C4) { return XE_NP_Nric_GpioTransaction(hi2c, reg_addr, value, 1U, 1, 0); }
#endif
    return HAL_I2C_Mem_Read(
        hi2c,
        XE_NP_NRIC_I2C_ADDR,
        reg_addr,
        I2C_MEMADD_SIZE_8BIT,
        value,
        1U,
        XE_NP_NRIC_I2C_TIMEOUT_MS);
}

HAL_StatusTypeDef XE_NP_Nric_WriteRegister(I2C_HandleTypeDef *hi2c, uint8_t reg_addr, uint8_t value)
{
    return XE_NP_Nric_WriteRegisterBurst(hi2c, reg_addr, &value, 1U);
}

static HAL_StatusTypeDef XE_NP_Nric_ReadRegisterBurst(
    I2C_HandleTypeDef *hi2c,
    uint8_t reg_addr,
    uint8_t *data,
    uint16_t length)
{
    if((hi2c == NULL) || ((length > 0U) && (data == NULL)))
    {
        return HAL_ERROR;
    }

    XE_NP_Nric_WaitBusFree();
#if XE_NP_NRIC_GPIO_I2C_ENABLE
    if(hi2c->Instance == I2C4) { return XE_NP_Nric_GpioTransaction(hi2c, reg_addr, data, length, 1, 0); }
#endif
    return HAL_I2C_Mem_Read(
        hi2c,
        XE_NP_NRIC_I2C_ADDR,
        reg_addr,
        I2C_MEMADD_SIZE_8BIT,
        data,
        length,
        XE_NP_NRIC_I2C_TIMEOUT_MS + (uint32_t)length * 12U);
}

static void XE_NP_Nric_ClearSrReadbackDiag(void)
{
    volatile uint8_t *diag_bytes = (volatile uint8_t *)&xe_np_nric_sr_diag;
    size_t i;

    for(i = 0U; i < sizeof(xe_np_nric_sr_diag); ++i)
    {
        diag_bytes[i] = 0U;
    }
}

static uint8_t XE_NP_Nric_SrDiagExpectedByte(
    uint8_t pattern_id,
    uint16_t byte_index,
    uint16_t chain_length,
    const uint8_t *default_chain)
{
    if(pattern_id == XE_NP_NRIC_SR_DIAG_PATTERN_ZERO)
    {
        return 0x00U;
    }
    if(pattern_id == XE_NP_NRIC_SR_DIAG_PATTERN_ONE)
    {
        return 0xFFU;
    }
    if(pattern_id == XE_NP_NRIC_SR_DIAG_PATTERN_AA55)
    {
        return ((byte_index & 1U) == 0U) ? 0xAAU : 0x55U;
    }
    if(pattern_id == XE_NP_NRIC_SR_DIAG_PATTERN_01)
    {
        return 0x01U;
    }
    if(pattern_id == XE_NP_NRIC_SR_DIAG_PATTERN_02)
    {
        return 0x02U;
    }
    if(pattern_id == XE_NP_NRIC_SR_DIAG_PATTERN_04)
    {
        return 0x04U;
    }
    if(pattern_id == XE_NP_NRIC_SR_DIAG_PATTERN_08)
    {
        return 0x08U;
    }
    if(pattern_id == XE_NP_NRIC_SR_DIAG_PATTERN_10)
    {
        return 0x10U;
    }
    if(pattern_id == XE_NP_NRIC_SR_DIAG_PATTERN_20)
    {
        return 0x20U;
    }
    if(pattern_id == XE_NP_NRIC_SR_DIAG_PATTERN_40)
    {
        return 0x40U;
    }
    if(pattern_id == XE_NP_NRIC_SR_DIAG_PATTERN_80)
    {
        return 0x80U;
    }
    if(pattern_id == XE_NP_NRIC_SR_DIAG_PATTERN_03)
    {
        return 0x03U;
    }
    if(pattern_id == XE_NP_NRIC_SR_DIAG_PATTERN_07)
    {
        return 0x07U;
    }
    if(pattern_id == XE_NP_NRIC_SR_DIAG_PATTERN_0F)
    {
        return 0x0FU;
    }
    if(pattern_id == XE_NP_NRIC_SR_DIAG_PATTERN_1F)
    {
        return 0x1FU;
    }
    if(pattern_id == XE_NP_NRIC_SR_DIAG_PATTERN_3F)
    {
        return 0x3FU;
    }
    if(pattern_id == XE_NP_NRIC_SR_DIAG_PATTERN_7F)
    {
        return 0x7FU;
    }
    if(pattern_id == XE_NP_NRIC_SR_DIAG_PATTERN_FIRST_01)
    {
        return (byte_index == 0U) ? 0x01U : 0x00U;
    }
    if(pattern_id == XE_NP_NRIC_SR_DIAG_PATTERN_LAST_01)
    {
        if(chain_length == 0U)
        {
            return 0x00U;
        }
        return (byte_index == (uint16_t)(chain_length - 1U)) ? 0x01U : 0x00U;
    }

    return (default_chain != NULL) ? default_chain[byte_index] : 0x00U;
}

static void XE_NP_Nric_SrDiagSetFailure(
    volatile XE_NP_NricSrReadbackResult *result,
    uint8_t fail_step,
    HAL_StatusTypeDef hal_status,
    uint16_t fail_index)
{
    if((result != NULL) && (result->fail_step == XE_NP_NRIC_SR_DIAG_FAIL_NONE))
    {
        result->fail_step = fail_step;
        result->hal_status = (uint8_t)hal_status;
        result->fail_index = fail_index;
    }
}

static void XE_NP_Nric_SetSrDiagLength(
    volatile XE_NP_NricSrReadbackResult *result,
    uint16_t chain_length)
{
    if(result == NULL)
    {
        return;
    }

    result->chain_length_lo = (uint8_t)(chain_length & 0xFFU);
    result->chain_length_hi = (uint8_t)(chain_length >> 8U);
}

static HAL_StatusTypeDef XE_NP_Nric_WriteSrLengthForDiag(
    I2C_HandleTypeDef *hi2c,
    uint16_t chain_length,
    volatile XE_NP_NricSrReadbackResult *result,
    uint8_t length_lo_fail_step,
    uint8_t length_hi_fail_step)
{
    HAL_StatusTypeDef hal_status;

    XE_NP_Nric_SetSrDiagLength(result, chain_length);

    hal_status = XE_NP_Nric_WriteRegister(
        hi2c, XE_NP_NRIC_REG_SR_LENGTH1, (uint8_t)(chain_length & 0xFFU));
    if(hal_status != HAL_OK)
    {
        XE_NP_Nric_SrDiagSetFailure(result, length_lo_fail_step, hal_status, 0U);
        return hal_status;
    }

    hal_status = XE_NP_Nric_WriteRegister(
        hi2c, XE_NP_NRIC_REG_SR_LENGTH2, (uint8_t)(chain_length >> 8U));
    if(hal_status != HAL_OK)
    {
        XE_NP_Nric_SrDiagSetFailure(result, length_hi_fail_step, hal_status, 0U);
        return hal_status;
    }

    return HAL_OK;
}

static void XE_NP_Nric_ReadSrLengthForDiag(
    I2C_HandleTypeDef *hi2c,
    volatile XE_NP_NricSrReadbackResult *result)
{
    uint8_t length1 = 0U;
    uint8_t length2 = 0U;

    if((hi2c == NULL) || (result == NULL))
    {
        return;
    }

    if((XE_NP_Nric_ReadRegister(hi2c, XE_NP_NRIC_REG_SR_LENGTH1, &length1) == HAL_OK) &&
       (XE_NP_Nric_ReadRegister(hi2c, XE_NP_NRIC_REG_SR_LENGTH2, &length2) == HAL_OK))
    {
        result->length1_readback = length1;
        result->length2_readback = length2;
        result->length_readback_valid = 1U;
    }
}

static HAL_StatusTypeDef XE_NP_Nric_WriteSrPatternPassForDiag(
    I2C_HandleTypeDef *hi2c,
    uint8_t reg_addr,
    uint8_t pattern_id,
    uint16_t chain_length,
    const uint8_t *default_chain,
    volatile XE_NP_NricSrReadbackResult *result,
    uint8_t fail_step)
{
    HAL_StatusTypeDef hal_status;
    uint16_t i;
    uint8_t tx_value;

    for(i = 0U; i < chain_length; ++i)
    {
        tx_value = XE_NP_Nric_ReverseBits8(
            XE_NP_Nric_SrDiagExpectedByte(pattern_id, i, chain_length, default_chain));
        hal_status = XE_NP_Nric_WriteRegister(hi2c, reg_addr, tx_value);
        if(hal_status != HAL_OK)
        {
            XE_NP_Nric_SrDiagSetFailure(result, fail_step, hal_status, i);
            return hal_status;
        }
    }

    return HAL_OK;
}

static HAL_StatusTypeDef XE_NP_Nric_PrepareSrTestForDiag(
    I2C_HandleTypeDef *hi2c,
    const XE_NP_NricConfig *config,
    volatile XE_NP_NricSrReadbackResult *result)
{
    HAL_StatusTypeDef hal_status;
    uint8_t rec_mod_programming;
    uint8_t rec_mod_reset_asserted;

    if((hi2c == NULL) || (config == NULL) || (result == NULL))
    {
        return HAL_ERROR;
    }

    rec_mod_programming = (uint8_t)(config->rec_mod_boot | XE_NP_NRIC_REC_MOD_PSB_HALF_RATE);
    rec_mod_reset_asserted = (uint8_t)(rec_mod_programming & ~XE_NP_NRIC_REC_MOD_DIG_NRESET);

    hal_status = XE_NP_Nric_WriteRegisterTwiceWithDelay(
        hi2c,
        XE_NP_NRIC_REG_REC_MOD,
        rec_mod_reset_asserted);
    if(hal_status != HAL_OK)
    {
        XE_NP_Nric_SrDiagSetFailure(
            result,
            XE_NP_NRIC_SR_DIAG_FAIL_PREP_RESET,
            hal_status,
            0xFFFFU);
        return hal_status;
    }

    hal_status = XE_NP_Nric_WriteRegisterTwiceWithDelay(
        hi2c,
        XE_NP_NRIC_REG_REC_MOD,
        rec_mod_programming);
    if(hal_status != HAL_OK)
    {
        XE_NP_Nric_SrDiagSetFailure(
            result,
            XE_NP_NRIC_SR_DIAG_FAIL_PREP_BOOT,
            hal_status,
            0xFFFFU);
        return hal_status;
    }

    return HAL_OK;
}

static void XE_NP_Nric_CompareSrReadbackForDiag(
    uint8_t pattern_id,
    uint16_t chain_length,
    const uint8_t *default_chain,
    volatile XE_NP_NricSrReadbackResult *result)
{
    uint16_t i;
    uint16_t mid_index;
    uint16_t last_index;
    uint8_t expected;
    uint8_t raw;
    uint8_t reversed;

    if((result == NULL) || (chain_length == 0U))
    {
        return;
    }

    result->first_raw_mismatch_index = 0xFFFFU;
    result->first_reversed_mismatch_index = 0xFFFFU;
    mid_index = (uint16_t)(chain_length / 2U);
    last_index = (uint16_t)(chain_length - 1U);

    for(i = 0U; i < chain_length; ++i)
    {
        expected = XE_NP_Nric_SrDiagExpectedByte(pattern_id, i, chain_length, default_chain);
        raw = xe_np_nric_sr_readback_buffer[i];
        reversed = XE_NP_Nric_ReverseBits8(raw);

        if(raw != expected)
        {
            ++result->raw_mismatch_count;
            if(result->first_raw_mismatch_index == 0xFFFFU)
            {
                result->first_raw_mismatch_index = i;
            }
        }
        if(reversed != expected)
        {
            ++result->reversed_mismatch_count;
            if(result->first_reversed_mismatch_index == 0xFFFFU)
            {
                result->first_reversed_mismatch_index = i;
            }
        }

        if(i == 0U)
        {
            result->sample0_expected = expected;
            result->sample0_raw = raw;
            result->sample0_reversed = reversed;
        }
        else if(i == mid_index)
        {
            result->sample_mid_expected = expected;
            result->sample_mid_raw = raw;
            result->sample_mid_reversed = reversed;
        }
        else if(i == last_index)
        {
            result->sample_last_expected = expected;
            result->sample_last_raw = raw;
            result->sample_last_reversed = reversed;
        }
    }
}

static void XE_NP_Nric_RunSrReadbackTestForDiag(
    I2C_HandleTypeDef *hi2c,
    uint8_t reg_addr,
    uint8_t pattern_id,
    uint16_t chain_length,
    const uint8_t *default_chain,
    volatile XE_NP_NricSrReadbackResult *result)
{
    HAL_StatusTypeDef hal_status;
    uint8_t status = 0U;
    uint8_t status_before_program = 0U;
    uint8_t status_before_valid = 0U;

    if(result == NULL)
    {
        return;
    }

    result->reg_addr = reg_addr;
    result->pattern_id = pattern_id;
    result->hal_status = (uint8_t)HAL_OK;
    result->fail_index = 0xFFFFU;
    XE_NP_Nric_SetSrDiagLength(result, chain_length);

    if(XE_NP_Nric_ReadRegister(hi2c, XE_NP_NRIC_REG_STATUS, &status_before_program) == HAL_OK)
    {
        result->status_before_program = status_before_program;
        status_before_valid = 1U;
    }

    if(XE_NP_Nric_WriteSrLengthForDiag(
            hi2c,
            chain_length,
            result,
            XE_NP_NRIC_SR_DIAG_FAIL_WRITE_LENGTH_LO,
            XE_NP_NRIC_SR_DIAG_FAIL_WRITE_LENGTH_HI) != HAL_OK)
    {
        return;
    }
    if(XE_NP_Nric_WriteSrPatternPassForDiag(
            hi2c,
            reg_addr,
            pattern_id,
            chain_length,
            default_chain,
            result,
            XE_NP_NRIC_SR_DIAG_FAIL_WRITE_PASS_1) != HAL_OK)
    {
        return;
    }
    if(XE_NP_Nric_WriteSrLengthForDiag(
            hi2c,
            chain_length,
            result,
            XE_NP_NRIC_SR_DIAG_FAIL_WRITE_LENGTH_LO,
            XE_NP_NRIC_SR_DIAG_FAIL_WRITE_LENGTH_HI) != HAL_OK)
    {
        return;
    }
    if(XE_NP_Nric_WriteSrPatternPassForDiag(
            hi2c,
            reg_addr,
            pattern_id,
            chain_length,
            default_chain,
            result,
            XE_NP_NRIC_SR_DIAG_FAIL_WRITE_PASS_2) != HAL_OK)
    {
        return;
    }

    if(XE_NP_Nric_ReadRegister(hi2c, XE_NP_NRIC_REG_STATUS, &status) == HAL_OK)
    {
        result->status_immediate = status;
    }

    if(XE_NP_Nric_WaitShiftRegisterReady(
           hi2c,
           status_before_program,
           status_before_valid,
           &status) != HAL_OK)
    {
        XE_NP_Nric_SrDiagSetFailure(
            result, XE_NP_NRIC_SR_DIAG_FAIL_WAIT_SR_OK, HAL_ERROR, 0xFFFFU);
    }
    result->status_reg = status;
    result->sr_ok = ((status & XE_NP_NRIC_STATUS_SR_OUT_OK) != 0U) ? 1U : 0U;

    if(XE_NP_Nric_WriteSrLengthForDiag(
            hi2c,
            chain_length,
            result,
            XE_NP_NRIC_SR_DIAG_FAIL_READ_LENGTH_LO,
            XE_NP_NRIC_SR_DIAG_FAIL_READ_LENGTH_HI) != HAL_OK)
    {
        return;
    }
    XE_NP_Nric_ReadSrLengthForDiag(hi2c, result);

    hal_status = XE_NP_Nric_ReadRegisterBurst(
        hi2c, reg_addr, xe_np_nric_sr_readback_buffer, chain_length);
    if(hal_status != HAL_OK)
    {
        XE_NP_Nric_SrDiagSetFailure(
            result, XE_NP_NRIC_SR_DIAG_FAIL_READ_BURST, hal_status, 0xFFFFU);
        return;
    }

    XE_NP_Nric_CompareSrReadbackForDiag(pattern_id, chain_length, default_chain, result);
}

static void XE_NP_Nric_RunSrReadbackDiagnostics(
    I2C_HandleTypeDef *hi2c,
    const XE_NP_NricConfig *config,
    uint8_t trigger_reg)
{
    /*
     * Keep one CA2/default control, then move a lone 0x01 across short CA1
     * chains. Because each byte is bit-reversed before programming, these
     * cases test whether only the first serial byte position of 0x0D can ever
     * propagate a high bit, and how long that first-position exception lasts
     * as the programmed chain grows.
     */
    static const uint8_t regs[XE_NP_NRIC_SR_READBACK_TEST_COUNT] = {
        XE_NP_NRIC_REG_SR_CHAIN3,
        XE_NP_NRIC_REG_SR_CHAIN2,
        XE_NP_NRIC_REG_SR_CHAIN2,
        XE_NP_NRIC_REG_SR_CHAIN2,
        XE_NP_NRIC_REG_SR_CHAIN2,
        XE_NP_NRIC_REG_SR_CHAIN2,
        XE_NP_NRIC_REG_SR_CHAIN2,
        XE_NP_NRIC_REG_SR_CHAIN2,
        XE_NP_NRIC_REG_SR_CHAIN2,
        XE_NP_NRIC_REG_SR_CHAIN2,
        XE_NP_NRIC_REG_SR_CHAIN2
    };
    static const uint8_t patterns[XE_NP_NRIC_SR_READBACK_TEST_COUNT] = {
        XE_NP_NRIC_SR_DIAG_PATTERN_DEFAULT,
        XE_NP_NRIC_SR_DIAG_PATTERN_FIRST_01,
        XE_NP_NRIC_SR_DIAG_PATTERN_FIRST_01,
        XE_NP_NRIC_SR_DIAG_PATTERN_FIRST_01,
        XE_NP_NRIC_SR_DIAG_PATTERN_FIRST_01,
        XE_NP_NRIC_SR_DIAG_PATTERN_LAST_01,
        XE_NP_NRIC_SR_DIAG_PATTERN_LAST_01,
        XE_NP_NRIC_SR_DIAG_PATTERN_LAST_01,
        XE_NP_NRIC_SR_DIAG_PATTERN_LAST_01,
        XE_NP_NRIC_SR_DIAG_PATTERN_FIRST_01,
        XE_NP_NRIC_SR_DIAG_PATTERN_DEFAULT
    };
    static const uint16_t chain_lengths[XE_NP_NRIC_SR_READBACK_TEST_COUNT] = {
        XE_NP_NRIC_BASE_CHAIN_BYTES,
        XE_NP_NRIC_SR_DIAG_TINY_CHAIN_BYTES,
        2U,
        4U,
        8U,
        2U,
        4U,
        8U,
        16U,
        16U,
        XE_NP_NRIC_BASE_CHAIN_BYTES
    };
    const uint8_t *default_chain;
    uint8_t reg_addr;
    uint8_t result_index = 0U;

    XE_NP_Nric_ClearSrReadbackDiag();
    XE_NP_Nric_EnsureDefaultBaseChainsInitialized();
    xe_np_nric_sr_diag.active = 1U;
    xe_np_nric_sr_diag.trigger_reg = trigger_reg;
    xe_np_nric_sr_diag.test_count = XE_NP_NRIC_SR_READBACK_TEST_COUNT;

    for(result_index = 0U; result_index < XE_NP_NRIC_SR_READBACK_TEST_COUNT; ++result_index)
    {
        reg_addr = regs[result_index];
        default_chain = NULL;
        if(config != NULL)
        {
            default_chain = (reg_addr == XE_NP_NRIC_REG_SR_CHAIN3) ?
                config->chain3 : config->chain2;
        }
        if(default_chain == NULL)
        {
            default_chain = (reg_addr == XE_NP_NRIC_REG_SR_CHAIN3) ?
                xe_np_nric_base_chain3_runtime : xe_np_nric_base_chain2_runtime;
        }

        if(config != NULL)
        {
            if(XE_NP_Nric_PrepareSrTestForDiag(
                   hi2c,
                   config,
                   &xe_np_nric_sr_diag.results[result_index]) != HAL_OK)
            {
                xe_np_nric_sr_diag.completed_count = (uint8_t)(result_index + 1U);
                continue;
            }
        }

        XE_NP_Nric_RunSrReadbackTestForDiag(
            hi2c,
            reg_addr,
            patterns[result_index],
            chain_lengths[result_index],
            default_chain,
            &xe_np_nric_sr_diag.results[result_index]);
        xe_np_nric_sr_diag.completed_count = (uint8_t)(result_index + 1U);
    }

    if(config != NULL)
    {
        (void)XE_NP_Nric_WriteRegister(
            hi2c,
            XE_NP_NRIC_REG_REC_MOD,
            (uint8_t)(config->rec_mod_boot &
                      ~(XE_NP_NRIC_REC_MOD_CH_NRESET | XE_NP_NRIC_REC_MOD_DIG_NRESET)));
    }

    xe_np_nric_sr_diag.tick_ms = HAL_GetTick();
    xe_np_nric_sr_diag.i2c_error_code = (hi2c != NULL) ? hi2c->ErrorCode : 0U;
    xe_np_nric_sr_diag.i2c_isr =
        ((hi2c != NULL) && (hi2c->Instance != NULL)) ? hi2c->Instance->ISR : 0U;
    xe_np_nric_sr_diag.active = 0U;
}

HAL_StatusTypeDef XE_NP_Nric_ApplyConfiguration(
    I2C_HandleTypeDef *hi2c,
    const XE_NP_NricConfig *config,
    uint8_t *status_out)
{
    uint8_t rec_mod_programming;
    uint8_t rec_mod_reset_asserted;
    uint8_t status = 0U;
    uint8_t explicit_sr_programming;

    /*
     * The direct NRIC1384 map exposes only the two channel/ADC analog-domain
     * SR chains: 0x0d (CA1) and 0x0c (CA2). The full probe PA/shank chain at
     * 0x0e is not present on this amplifier IC and must not be used here.
     */
    if((hi2c == NULL) || (config == NULL) ||
       ((config->chain2_bytes > 0U) &&
        ((config->chain2 == NULL) || (config->chain2_bytes != XE_NP_NRIC_BASE_CHAIN_BYTES))) ||
       ((config->chain3_bytes > 0U) &&
        ((config->chain3 == NULL) || (config->chain3_bytes != XE_NP_NRIC_BASE_CHAIN_BYTES))))
    {
        return HAL_ERROR;
    }
    explicit_sr_programming =
        ((config->chain2_bytes > 0U) || (config->chain3_bytes > 0U)) ? 1U : 0U;

#if XE_NP_NRIC_USE_SR_DEFAULT_STARTUP
    /* Match the independently read-back, hardware-default bring-up sequence.
     * This is an explicitly selected uncalibrated mode, never a substitute
     * for a failed custom configuration. No capture starts before readback. */
    {
        const uint8_t registers[] = {0x00U, 0x02U, 0x01U, 0x01U, 0x09U, 0x00U};
        const uint8_t values[] = {
            XE_NP_NRIC_OP_MODE_DIGITAL_TEST, config->cal_mod,
            (uint8_t)(config->rec_mod_run & ~XE_NP_NRIC_REC_MOD_DIG_NRESET),
            config->rec_mod_run, config->sync_value, config->op_mode_run};
        for(uint32_t i = 0U; i < sizeof(registers); ++i)
        {
            if(XE_NP_Nric_WriteRegister(hi2c, registers[i], values[i]) != HAL_OK)
            {
                XE_NP_Nric_UpdateDiag(hi2c, (uint8_t)(0x40U + i), registers[i],
                                     HAL_ERROR, 0U, 0U, values[i]);
                return HAL_ERROR;
            }
            if(i == 2U) { HAL_Delay(XE_NP_NRIC_DIG_RESET_SETTLE_MS); }
        }
        if((XE_NP_Nric_VerifyRegister(hi2c, XE_NP_NRIC_REG_OP_MODE, config->op_mode_run,
                                     XE_NP_NRIC_DIAG_STEP_VERIFY_OP_MODE) != HAL_OK) ||
           (XE_NP_Nric_VerifyRegister(hi2c, XE_NP_NRIC_REG_REC_MOD, config->rec_mod_run,
                                     XE_NP_NRIC_DIAG_STEP_VERIFY_REC_MOD) != HAL_OK) ||
           (XE_NP_Nric_VerifyRegister(hi2c, XE_NP_NRIC_REG_CAL_MOD, config->cal_mod,
                                     XE_NP_NRIC_DIAG_STEP_VERIFY_CAL_MOD) != HAL_OK) ||
           (XE_NP_Nric_VerifyRegister(hi2c, XE_NP_NRIC_REG_SYNC, config->sync_value,
                                     XE_NP_NRIC_DIAG_STEP_VERIFY_SYNC) != HAL_OK))
        {
            return HAL_ERROR;
        }
        if(XE_NP_Nric_ReadRegister(hi2c, XE_NP_NRIC_REG_STATUS, &status) != HAL_OK) { return HAL_ERROR; }
        if(status_out != NULL) { *status_out = status; }
        XE_NP_Nric_UpdateDiag(hi2c, 0U, XE_NP_NRIC_REG_STATUS, HAL_OK, status, status, 0U);
        return HAL_OK;
    }
#endif

    /* Configure V2 with recording disabled. Do not change the PSB clock
     * divider in the middle of this control sequence. */
    if(XE_NP_Nric_WriteRegister(hi2c, XE_NP_NRIC_REG_OP_MODE,
#if (XE_NP_BOARD_V2_PSSI_NP1_ENABLE != 0U)
                               (uint8_t)(config->op_mode_run & ~XE_NP_NRIC_OP_MODE_RECORD)
#else
                               config->op_mode_run
#endif
                               ) != HAL_OK)
    {
        XE_NP_Nric_UpdateDiag(
            hi2c, XE_NP_NRIC_DIAG_STEP_WRITE_OP_MODE_IDLE, XE_NP_NRIC_REG_OP_MODE,
            HAL_ERROR, 0U, 0U, config->op_mode_run);
        return HAL_ERROR;
    }
    if(XE_NP_Nric_WriteRegister(hi2c, XE_NP_NRIC_REG_CAL_MOD, config->cal_mod) != HAL_OK)
    {
        XE_NP_Nric_UpdateDiag(
            hi2c, XE_NP_NRIC_DIAG_STEP_WRITE_CAL_MOD, XE_NP_NRIC_REG_CAL_MOD,
            HAL_ERROR, 0U, 0U, config->cal_mod);
        return HAL_ERROR;
    }

    /*
     * Align the direct-NRIC startup pulse with the Imec reference API:
     * deassert DIG_NRESET only after a settled double-write, and keep PSB_F
     * high during configuration even if the final run mode will switch back.
     */
#if (XE_NP_BOARD_V2_PSSI_NP1_ENABLE != 0U)
    rec_mod_programming = config->rec_mod_boot;
#else
    rec_mod_programming = (uint8_t)(config->rec_mod_boot | XE_NP_NRIC_REC_MOD_PSB_HALF_RATE);
#endif
    rec_mod_reset_asserted = (uint8_t)(rec_mod_programming & ~XE_NP_NRIC_REC_MOD_DIG_NRESET);
    if(XE_NP_Nric_WriteRegisterTwiceWithDelay(
           hi2c,
           XE_NP_NRIC_REG_REC_MOD,
           rec_mod_reset_asserted) != HAL_OK)
    {
        XE_NP_Nric_UpdateDiag(
            hi2c, XE_NP_NRIC_DIAG_STEP_WRITE_REC_MOD_RESET, XE_NP_NRIC_REG_REC_MOD,
            HAL_ERROR, 0U, 0U, rec_mod_reset_asserted);
        return HAL_ERROR;
    }

    if(XE_NP_Nric_WriteRegisterTwiceWithDelay(
           hi2c,
           XE_NP_NRIC_REG_REC_MOD,
           rec_mod_programming) != HAL_OK)
    {
        XE_NP_Nric_UpdateDiag(
            hi2c, XE_NP_NRIC_DIAG_STEP_WRITE_REC_MOD_BOOT, XE_NP_NRIC_REG_REC_MOD,
            HAL_ERROR, 0U, 0U, rec_mod_programming);
        return HAL_ERROR;
    }

#if XE_NP_NRIC_DIAG_SKIP_CHAIN2_PROGRAM
    (void)status;
#else
    if((config->chain2_bytes > 0U) &&
       (XE_NP_Nric_ProgramShiftRegister(
            hi2c,
            XE_NP_NRIC_REG_SR_CHAIN2,
            config->chain2,
            config->chain2_bytes,
            &status) != HAL_OK))
    {
        XE_NP_Nric_RunSrReadbackDiagnostics(hi2c, config, XE_NP_NRIC_REG_SR_CHAIN2);
        return HAL_ERROR;
    }
#endif

    if((config->chain3_bytes > 0U) &&
       (XE_NP_Nric_ProgramShiftRegister(
            hi2c,
            XE_NP_NRIC_REG_SR_CHAIN3,
            config->chain3,
            config->chain3_bytes,
            &status) != HAL_OK))
    {
        XE_NP_Nric_RunSrReadbackDiagnostics(hi2c, config, XE_NP_NRIC_REG_SR_CHAIN3);
        return HAL_ERROR;
    }

    if(XE_NP_Nric_WriteRegister(hi2c, XE_NP_NRIC_REG_SYNC, config->sync_value) != HAL_OK)
    {
        XE_NP_Nric_UpdateDiag(
            hi2c, XE_NP_NRIC_DIAG_STEP_WRITE_SYNC, XE_NP_NRIC_REG_SYNC,
            HAL_ERROR, 0U, 0U, config->sync_value);
        return HAL_ERROR;
    }
    if(XE_NP_Nric_WriteRegister(hi2c, XE_NP_NRIC_REG_REC_MOD, config->rec_mod_run) != HAL_OK)
    {
        XE_NP_Nric_UpdateDiag(
            hi2c, XE_NP_NRIC_DIAG_STEP_WRITE_REC_MOD_RUN, XE_NP_NRIC_REG_REC_MOD,
            HAL_ERROR, 0U, 0U, config->rec_mod_run);
        return HAL_ERROR;
    }
    if(XE_NP_Nric_WriteRegister(hi2c, XE_NP_NRIC_REG_OP_MODE, config->op_mode_run) != HAL_OK)
    {
        XE_NP_Nric_UpdateDiag(
            hi2c, XE_NP_NRIC_DIAG_STEP_WRITE_OP_MODE_RUN, XE_NP_NRIC_REG_OP_MODE,
            HAL_ERROR, 0U, 0U, config->op_mode_run);
        return HAL_ERROR;
    }
    if((XE_NP_Nric_VerifyRegister(
            hi2c, XE_NP_NRIC_REG_CAL_MOD, config->cal_mod,
            XE_NP_NRIC_DIAG_STEP_VERIFY_CAL_MOD) != HAL_OK) ||
       (XE_NP_Nric_VerifyRegister(
            hi2c, XE_NP_NRIC_REG_SYNC, config->sync_value,
            XE_NP_NRIC_DIAG_STEP_VERIFY_SYNC) != HAL_OK) ||
       (XE_NP_Nric_VerifyRegister(
            hi2c, XE_NP_NRIC_REG_REC_MOD, config->rec_mod_run,
            XE_NP_NRIC_DIAG_STEP_VERIFY_REC_MOD) != HAL_OK) ||
       (XE_NP_Nric_VerifyRegister(
            hi2c, XE_NP_NRIC_REG_OP_MODE, config->op_mode_run,
            XE_NP_NRIC_DIAG_STEP_VERIFY_OP_MODE) != HAL_OK))
    {
        return HAL_ERROR;
    }
    if(XE_NP_Nric_ReadRegister(hi2c, XE_NP_NRIC_REG_STATUS, &status) != HAL_OK)
    {
        XE_NP_Nric_UpdateDiag(
            hi2c, XE_NP_NRIC_DIAG_STEP_READ_FINAL_STATUS, XE_NP_NRIC_REG_STATUS,
            HAL_ERROR, 0U, status, 0U);
        return HAL_ERROR;
    }

    if(status_out != NULL)
    {
        *status_out = status;
    }

    XE_NP_Nric_UpdateDiag(
        hi2c,
        ((explicit_sr_programming != 0U) &&
         ((status & XE_NP_NRIC_STATUS_SR_OUT_OK) == 0U)) ?
            XE_NP_NRIC_DIAG_STEP_FINAL_STATUS :
            XE_NP_NRIC_DIAG_STEP_NONE,
        XE_NP_NRIC_REG_STATUS,
        HAL_OK,
        status,
        status,
        (explicit_sr_programming != 0U) ? XE_NP_NRIC_STATUS_SR_OUT_OK : 0U);
    return HAL_OK;
}

HAL_StatusTypeDef XE_NP_Nric_ApplyBootConfiguration(
    I2C_HandleTypeDef *hi2c,
    uint8_t sync_value,
    uint8_t *status_out)
{
    XE_NP_NricConfig config;

    XE_NP_NricConfig_InitDefaults(&config);
    config.sync_value = sync_value;
    return XE_NP_Nric_ApplyConfiguration(hi2c, &config, status_out);
}
