#include "xe_np_np2_sd_fine_clock.h"
#include "xe_np_board.h"
#if XE_NP_NP2_FIRST_SYNC_ENABLE && (XE_NP_NP2_DUAL_SD_APP_ENABLE || NP_FINE_COUNTER64_ENABLE)
#include "xe_np_hal.h"
#include <string.h>
/* TIM5 has no native NP/ADC/camera owner. No pin, channel or DMA use.
 * Explicit continuous64 adds one update IRQ per 4294.967296 seconds.
 * RM0456 Rev4 55.4.28/Table566: timer runs in plain Sleep, stops in Stop.
 * The compiled APP admits only plain WFI; no STOP continuity is inferred. */
typedef struct {
    volatile uint32_t domain;
    uint32_t serial,owned,old_sleep,psc,generation,epoch;
    volatile uint32_t context;
    uint32_t hclk,cfgr1,cfgr2,pll,div,frac;
#if NP_FINE_COUNTER64_ENABLE
    volatile uint32_t high,wrap_sequence;
    uint32_t continuous,bound64;
#endif
} SdFineClock;
static SdFineClock clock_state;
#if NP_FINE_COUNTER64_ENABLE
volatile XE_NP_Np2SdFineDiagnostic xe_np_np2_sd_fine_diagnostic;
_Static_assert(sizeof(XE_NP_Np2SdFineDiagnostic)==56U*sizeof(uint32_t),
               "fine diagnostic ABI must remain 224 bytes");

static void diagnostic_point(volatile XE_NP_Np2SdFineDiagnostic *d,
    const XE_NP_Np2SdFinePoint64 *p,uint32_t after)
{
    if(!p)return;
    if(after){
        d->after_counter_lo=(uint32_t)p->counter;d->after_counter_hi=(uint32_t)(p->counter>>32);
        d->after_domain=p->domain;d->after_hz=p->counter_hz;
        d->after_generation=p->generation;d->after_epoch=p->source_epoch;
    }else{
        d->before_counter_lo=(uint32_t)p->counter;d->before_counter_hi=(uint32_t)(p->counter>>32);
        d->before_domain=p->domain;d->before_hz=p->counter_hz;
        d->before_generation=p->generation;d->before_epoch=p->source_epoch;
    }
}
void XE_NP_Np2SdFineDiagnosticBegin(uint32_t nonce,uint32_t features)
{
    volatile unsigned char *bytes=(volatile unsigned char *)&xe_np_np2_sd_fine_diagnostic;
    for(uint32_t i=0U;i<sizeof(xe_np_np2_sd_fine_diagnostic);i++)bytes[i]=0U;
    __DMB();
    if(!features)return;
    xe_np_np2_sd_fine_diagnostic.nonce=nonce;
    xe_np_np2_sd_fine_diagnostic.features=features;
    xe_np_np2_sd_fine_diagnostic.window_open=1U;
    xe_np_np2_sd_fine_diagnostic.progress=XE_NP_FINE_PROGRESS_BEGIN_OPEN;
    __DMB();
}
void XE_NP_Np2SdFineDiagnosticEnd(void)
{
    if(!xe_np_np2_sd_fine_diagnostic.window_open)return;
    xe_np_np2_sd_fine_diagnostic.progress|=XE_NP_FINE_PROGRESS_END;
    __DMB();xe_np_np2_sd_fine_diagnostic.window_open=0U;
}
void XE_NP_Np2SdFineDiagnosticProgress(uint32_t flags)
{
    if(xe_np_np2_sd_fine_diagnostic.window_open)
        xe_np_np2_sd_fine_diagnostic.progress|=flags;
}
void XE_NP_Np2SdFineDiagnosticFailure(uint32_t stage,uint32_t detail,
    uint32_t generation,uint32_t epoch,const XE_NP_Np2SdFinePoint64 *before,
    const XE_NP_Np2SdFinePoint64 *after)
{
    volatile XE_NP_Np2SdFineDiagnostic *d=&xe_np_np2_sd_fine_diagnostic;
    if(!d->window_open || d->stage)return;
    d->detail=detail;d->generation=generation;d->epoch=epoch;
    diagnostic_point(d,before,0U);diagnostic_point(d,after,1U);
    d->dhcsr=CoreDebug->DHCSR;d->dbg_tim5_freeze=DBGMCU->APB1FZR1;d->scr=SCB->SCR;
    d->rcc_cr=RCC->CR;d->rcc_cfgr1=RCC->CFGR1;d->rcc_cfgr2=RCC->CFGR2;
    d->rcc_pll1cfgr=RCC->PLL1CFGR;d->rcc_pll1divr=RCC->PLL1DIVR;d->rcc_pll1fracr=RCC->PLL1FRACR;
    d->rcc_apb1enr1=RCC->APB1ENR1;d->rcc_apb1smenr1=RCC->APB1SMENR1;d->rcc_apb1rstr1=RCC->APB1RSTR1;
    d->tim5_cr1=TIM5->CR1;d->tim5_cr2=TIM5->CR2;d->tim5_smcr=TIM5->SMCR;d->tim5_dier=TIM5->DIER;
    d->tim5_psc=TIM5->PSC;d->tim5_arr=TIM5->ARR;d->tim5_cnt=TIM5->CNT;d->tim5_sr=TIM5->SR;
    d->nvic_enabled=NVIC_GetEnableIRQ(TIM5_IRQn);d->nvic_pending=NVIC_GetPendingIRQ(TIM5_IRQn);
    d->nvic_priority=NVIC_GetPriority(TIM5_IRQn);
    d->saved_owned=clock_state.owned;d->saved_continuous=clock_state.continuous;
    d->saved_bound=clock_state.bound64;d->saved_domain=clock_state.domain;
    d->saved_generation=clock_state.generation;d->saved_epoch=clock_state.epoch;
    d->saved_hclk=clock_state.hclk;d->saved_cfgr1=clock_state.cfgr1;d->saved_cfgr2=clock_state.cfgr2;
    d->saved_pll1cfgr=clock_state.pll;d->saved_pll1divr=clock_state.div;d->saved_pll1fracr=clock_state.frac;
    d->saved_context=clock_state.context;
    __DMB();d->stage=stage;__DMB();
}
const volatile XE_NP_Np2SdFineDiagnostic *XE_NP_Np2SdFineDiagnosticGet(void)
{return &xe_np_np2_sd_fine_diagnostic;}
#define DIAGNOSTIC_FAILURE(stage,detail,generation,epoch,before,after) \
    XE_NP_Np2SdFineDiagnosticFailure((stage),(detail),(generation),(epoch),(before),(after))
#else
#define DIAGNOSTIC_FAILURE(stage,detail,generation,epoch,before,after) ((void)0)
#endif
#ifndef XE_NP_SD_FINE_COUNTER
#define XE_NP_SD_FINE_COUNTER() (TIM5->CNT)
#endif
#if NP_FINE_COUNTER64_ENABLE
/* Actual V2 NP DMA/PSSI is priority1; dedicated sensor I2C is7. The rare
 * wrap leaf runs at2, below capture and above sensor completion reads. */
#define FINE_WRAP_PRIORITY 2U
static void irq_idle(void){}
static void (*wrap_irq)(void)=irq_idle;
static void irq_update(void)
{
    if(!(TIM5->SR&TIM_SR_UIF))return;
    clock_state.wrap_sequence++;__DMB();
    if(clock_state.high==UINT32_MAX){
        clock_state.domain=0U;TIM5->DIER=0U;wrap_irq=irq_idle;
    }else clock_state.high++;
    TIM5->SR=~TIM_SR_UIF;__DSB();
    clock_state.wrap_sequence++;
}
void TIM5_IRQHandler(void){wrap_irq();}
#endif
#define FINE_CFGR1_MASK (RCC_CFGR1_SW|RCC_CFGR1_SWS)
#define FINE_CFGR2_MASK (RCC_CFGR2_HPRE|RCC_CFGR2_PPRE1)
static int root_allowed(void)
{
    uint32_t sw=RCC->CFGR1&RCC_CFGR1_SWS;
    return !(CoreDebug->DHCSR&CoreDebug_DHCSR_C_DEBUGEN_Msk) &&
        !(DBGMCU->APB1FZR1&DBGMCU_APB1FZR1_DBG_TIM5_STOP) &&
        !(SCB->SCR&(SCB_SCR_SLEEPDEEP_Msk|SCB_SCR_SLEEPONEXIT_Msk)) &&
        (RCC->CR&RCC_CR_HSERDY) &&
        (sw==RCC_SYSCLKSOURCE_STATUS_HSE ||
         (sw==RCC_SYSCLKSOURCE_STATUS_PLLCLK &&
          (RCC->CR&RCC_CR_PLL1RDY) &&
          (RCC->PLL1CFGR&RCC_PLL1CFGR_PLL1SRC)==RCC_PLLSOURCE_HSE));
}
static int qualified(void)
{
    return clock_state.domain && clock_state.owned && root_allowed() &&
        (RCC->APB1ENR1&RCC_APB1ENR1_TIM5EN) &&
        (RCC->APB1SMENR1&RCC_APB1SMENR1_TIM5SMEN) &&
        !(RCC->APB1RSTR1&RCC_APB1RSTR1_TIM5RST) &&
        (RCC->CFGR1&FINE_CFGR1_MASK)==clock_state.cfgr1 &&
        (RCC->CFGR2&FINE_CFGR2_MASK)==clock_state.cfgr2 &&
        RCC->PLL1CFGR==clock_state.pll && RCC->PLL1DIVR==clock_state.div &&
        RCC->PLL1FRACR==clock_state.frac && SystemCoreClock==clock_state.hclk &&
        TIM5->CR1==TIM_CR1_CEN && !TIM5->CR2 && !TIM5->SMCR &&
#if NP_FINE_COUNTER64_ENABLE
        TIM5->DIER==(clock_state.continuous?TIM_DIER_UIE:0U) &&
        (!clock_state.continuous || (NVIC_GetEnableIRQ(TIM5_IRQn) &&
                                    NVIC_GetPriority(TIM5_IRQn)==FINE_WRAP_PRIORITY)) &&
#else
        !TIM5->DIER &&
#endif
        !TIM5->CCER && !TIM5->CCMR1 && !TIM5->CCMR2 &&
        TIM5->PSC==clock_state.psc && TIM5->ARR==UINT32_MAX;
}
void XE_NP_Np2SdFineClock_Invalidate(void)
{
    clock_state.domain=0U;__DMB();
#if NP_FINE_COUNTER64_ENABLE
    wrap_irq=irq_idle;clock_state.bound64=0U;__DMB();
    if(clock_state.owned && clock_state.continuous){
        TIM5->DIER=0U;HAL_NVIC_DisableIRQ(TIM5_IRQn);
        HAL_NVIC_ClearPendingIRQ(TIM5_IRQn);
    }
#endif
    if(clock_state.owned){
        TIM5->CR1=0U;TIM5->DIER=0U;
        RCC->APB1SMENR1=(RCC->APB1SMENR1&~RCC_APB1SMENR1_TIM5SMEN)|clock_state.old_sleep;
        RCC->APB1ENR1&=~RCC_APB1ENR1_TIM5EN;__DSB();
        clock_state.owned=0U;
    }
}
static int start(uint32_t seed,uint32_t generation,uint32_t source_epoch
#if NP_FINE_COUNTER64_ENABLE
                 ,uint32_t continuous,uint32_t diagnostic_stage
#endif
                 )
{
    uint32_t hz,domain;
    if(!seed || (!!generation!=!!source_epoch)){
#if NP_FINE_COUNTER64_ENABLE
        DIAGNOSTIC_FAILURE(diagnostic_stage,XE_NP_FINE_DIAG_DETAIL_ARGUMENT,generation,source_epoch,0,0);
#endif
        return 0;
    }
    if(!root_allowed()){
#if NP_FINE_COUNTER64_ENABLE
        DIAGNOSTIC_FAILURE(diagnostic_stage,XE_NP_FINE_DIAG_DETAIL_ROOT,generation,source_epoch,0,0);
#endif
        XE_NP_Np2SdFineClock_Invalidate();return 0;
    }
    /* A caller must relinquish before reclocking. Do not silently repair an
     * unqualified interval, nor claim an already enabled foreign timer. */
    if(clock_state.owned && (!qualified()
#if NP_FINE_COUNTER64_ENABLE
        || clock_state.continuous!=continuous
#endif
        )){
#if NP_FINE_COUNTER64_ENABLE
        DIAGNOSTIC_FAILURE(diagnostic_stage,XE_NP_FINE_DIAG_DETAIL_OWNED,generation,source_epoch,0,0);
#endif
        XE_NP_Np2SdFineClock_Invalidate();return 0;
    }
    if(!clock_state.owned){
#if NP_FINE_COUNTER64_ENABLE
        if(continuous && (NVIC_GetEnableIRQ(TIM5_IRQn) || NVIC_GetPendingIRQ(TIM5_IRQn))){
            DIAGNOSTIC_FAILURE(diagnostic_stage,XE_NP_FINE_DIAG_DETAIL_FOREIGN_NVIC,generation,source_epoch,0,0);return 0;
        }
#endif
        if((RCC->APB1ENR1&RCC_APB1ENR1_TIM5EN) ||
           (RCC->APB1RSTR1&RCC_APB1RSTR1_TIM5RST)){
#if NP_FINE_COUNTER64_ENABLE
            DIAGNOSTIC_FAILURE(diagnostic_stage,XE_NP_FINE_DIAG_DETAIL_FOREIGN_TIMER,generation,source_epoch,0,0);
#endif
            return 0;
        }
        hz=HAL_RCC_GetPCLK1Freq();
        if((RCC->CFGR2&RCC_CFGR2_PPRE1)>=RCC_CFGR2_PPRE1_2){
            if(hz>UINT32_MAX/2U){
#if NP_FINE_COUNTER64_ENABLE
                DIAGNOSTIC_FAILURE(diagnostic_stage,XE_NP_FINE_DIAG_DETAIL_APB_CLOCK,generation,source_epoch,0,0);
#endif
                return 0;
            }hz*=2U;
        }
        if(!hz || hz%XE_NP_NP2_SD_FINE_HZ ||
           hz/XE_NP_NP2_SD_FINE_HZ>65536U){
#if NP_FINE_COUNTER64_ENABLE
            DIAGNOSTIC_FAILURE(diagnostic_stage,XE_NP_FINE_DIAG_DETAIL_APB_CLOCK,generation,source_epoch,0,0);
#endif
            return 0;
        }
        clock_state.old_sleep=RCC->APB1SMENR1&RCC_APB1SMENR1_TIM5SMEN;
        clock_state.psc=hz/XE_NP_NP2_SD_FINE_HZ-1U;
        clock_state.hclk=SystemCoreClock;
        clock_state.cfgr1=RCC->CFGR1&FINE_CFGR1_MASK;
        clock_state.cfgr2=RCC->CFGR2&FINE_CFGR2_MASK;
        clock_state.pll=RCC->PLL1CFGR;clock_state.div=RCC->PLL1DIVR;
        clock_state.frac=RCC->PLL1FRACR;
        RCC->APB1ENR1|=RCC_APB1ENR1_TIM5EN;
        (void)RCC->APB1ENR1;
        RCC->APB1SMENR1|=RCC_APB1SMENR1_TIM5SMEN;
        TIM5->CR1=0U;TIM5->CR2=0U;TIM5->SMCR=0U;TIM5->DIER=0U;
        TIM5->CCER=0U;TIM5->CCMR1=0U;TIM5->CCMR2=0U;
        TIM5->PSC=clock_state.psc;TIM5->ARR=UINT32_MAX;
        TIM5->EGR=TIM_EGR_UG;TIM5->SR=0U;TIM5->CNT=0U;
#if NP_FINE_COUNTER64_ENABLE
        clock_state.continuous=continuous;clock_state.bound64=0U;
        clock_state.high=0U;clock_state.wrap_sequence=0U;
        if(continuous){
            HAL_NVIC_DisableIRQ(TIM5_IRQn);HAL_NVIC_ClearPendingIRQ(TIM5_IRQn);
            HAL_NVIC_SetPriority(TIM5_IRQn,FINE_WRAP_PRIORITY,0U);
            wrap_irq=irq_update;TIM5->DIER=TIM_DIER_UIE;
        }
#endif
        TIM5->CR1=TIM_CR1_CEN;__DSB();clock_state.owned=1U;
#if NP_FINE_COUNTER64_ENABLE
        if(continuous)HAL_NVIC_EnableIRQ(TIM5_IRQn);
#endif
    }
    /* Seed is the explicit native record's negotiated nonce, not a timer
     * fraction. Capture binding is published separately after actual arm. */
    clock_state.domain=0U;__DMB();
#if NP_FINE_COUNTER64_ENABLE
    clock_state.bound64=0U;
#endif
    clock_state.context++;__DMB();
    clock_state.generation=generation;clock_state.epoch=source_epoch;
    __DMB();clock_state.context++;
    if(++clock_state.serial==0U)clock_state.serial=1U;
    domain=seed^(clock_state.serial*0x9e3779b9U)^HAL_GetUIDw0();
    if(!domain)domain=clock_state.serial;
    __DMB();clock_state.domain=domain;
    if(!qualified()){
#if NP_FINE_COUNTER64_ENABLE
        DIAGNOSTIC_FAILURE(diagnostic_stage,XE_NP_FINE_DIAG_DETAIL_QUALIFICATION,generation,source_epoch,0,0);
#endif
        XE_NP_Np2SdFineClock_Invalidate();return 0;
    }
    return 1;
}
int XE_NP_Np2SdFineClock_Start(uint32_t seed,uint32_t generation,uint32_t source_epoch)
{
    return start(seed,generation,source_epoch
#if NP_FINE_COUNTER64_ENABLE
                 ,0U,XE_NP_FINE_DIAG_NONE
#endif
                 );
}
#if NP_FINE_COUNTER64_ENABLE
int XE_NP_Np2SdFineClock_Start64(uint32_t seed,uint32_t generation,uint32_t source_epoch)
{
    int ok;
    XE_NP_Np2SdFineDiagnosticProgress(XE_NP_FINE_PROGRESS_START64_CALLED);
    ok=start(seed,generation,source_epoch,1U,XE_NP_FINE_DIAG_CLOCK_BEGIN);
    XE_NP_Np2SdFineDiagnosticProgress(ok?XE_NP_FINE_PROGRESS_START64_OK:
                                          XE_NP_FINE_PROGRESS_START64_FAIL);
    return ok;
}
#endif
int XE_NP_Np2SdFineClock_BindSource(uint32_t generation,uint32_t source_epoch)
{
    if(!generation || !source_epoch){
#if NP_FINE_COUNTER64_ENABLE
        DIAGNOSTIC_FAILURE(XE_NP_FINE_DIAG_RUNTIME_FINE_BOUND,XE_NP_FINE_DIAG_DETAIL_BIND_ARGUMENT,generation,source_epoch,0,0);
#endif
        return 0;
    }
#if NP_FINE_COUNTER64_ENABLE
    if(clock_state.continuous && !clock_state.bound64){
        DIAGNOSTIC_FAILURE(XE_NP_FINE_DIAG_RUNTIME_FINE_BOUND,XE_NP_FINE_DIAG_DETAIL_BIND_QUALIFICATION,generation,source_epoch,0,0);
        return 0;
    }
#endif
    if(!qualified()){
#if NP_FINE_COUNTER64_ENABLE
        DIAGNOSTIC_FAILURE(XE_NP_FINE_DIAG_RUNTIME_FINE_BOUND,XE_NP_FINE_DIAG_DETAIL_BIND_QUALIFICATION,generation,source_epoch,0,0);
#endif
        XE_NP_Np2SdFineClock_Invalidate();return 0;
    }
    clock_state.context++;__DMB();
    clock_state.generation=generation;clock_state.epoch=source_epoch;
    __DMB();clock_state.context++;return 1;
}
int XE_NP_Np2SdFineClock_ReadIrq(uint32_t tick,XE_NP_Np2SdFinePoint *out)
{
    uint32_t domain=clock_state.domain,context=clock_state.context;
    if(!out || !domain || (context&1U))return 0;
    out->domain=domain;out->counter_hz=XE_NP_NP2_SD_FINE_HZ;
    out->ms=tick;out->counter=XE_NP_SD_FINE_COUNTER();
    out->generation=clock_state.generation;out->source_epoch=clock_state.epoch;
    __DMB();return domain==clock_state.domain && context==clock_state.context;
}
int XE_NP_Np2SdFineClock_Read(XE_NP_Np2SdFinePoint *out)
{
    uint32_t before,after;
    if(!out)return 0;
    memset(out,0,sizeof(*out));
    if(!qualified()){XE_NP_Np2SdFineClock_Invalidate();return 0;}
    /* At most three attempts for a coherent coarse/counter observation.
     * No fraction is synthesized from HAL ms. Wrap selection is host work. */
    for(unsigned tries=0U;tries<3U;tries++){
        before=HAL_GetTick();
        if(!XE_NP_Np2SdFineClock_ReadIrq(before,out))break;
        after=HAL_GetTick();
        if(before==after && qualified())return 1;
    }
    XE_NP_Np2SdFineClock_Invalidate();memset(out,0,sizeof(*out));return 0;
}
#if NP_FINE_COUNTER64_ENABLE
#ifndef XE_NP_SD_FINE_READ64_HOOK
#define XE_NP_SD_FINE_READ64_HOOK() ((void)0)
#endif
static int read64(uint32_t tick,XE_NP_Np2SdFinePoint64 *out)
{
    if(!out || !clock_state.continuous)return 0;
    for(unsigned tries=0U;tries<2U;tries++){
        uint32_t domain=clock_state.domain,context=clock_state.context;
        uint32_t seq=clock_state.wrap_sequence,high=clock_state.high,low;
        if(!domain || (context&1U) || (seq&1U))continue;
        low=XE_NP_SD_FINE_COUNTER();
        XE_NP_SD_FINE_READ64_HOOK();__DMB();
        if((TIM5->SR&TIM_SR_UIF) || seq!=clock_state.wrap_sequence ||
           context!=clock_state.context || domain!=clock_state.domain)continue;
        out->counter=((uint64_t)high<<32)|low;
        out->domain=domain;out->counter_hz=XE_NP_NP2_SD_FINE_HZ;out->ms=tick;
        out->generation=clock_state.generation;out->source_epoch=clock_state.epoch;
        __DMB();
        if(context==clock_state.context && domain==clock_state.domain)return 1;
    }
    return 0;
}
int XE_NP_Np2SdFineClock_BindSource64(uint32_t generation,uint32_t source_epoch,
    const XE_NP_Np2SdFinePoint64 *before,const XE_NP_Np2SdFinePoint64 *after)
{
    XE_NP_Np2SdFineDiagnosticProgress(XE_NP_FINE_PROGRESS_FINE_BOUND_CALLED);
    if(!generation || !source_epoch || !before || !after || !clock_state.continuous ||
       clock_state.bound64 || before->counter>>32 || after->counter<before->counter ||
       after->counter-before->counter>100U ||
       (uint32_t)(after->counter-before->counter)!=(uint32_t)after->counter-(uint32_t)before->counter ||
       before->domain!=clock_state.domain || after->domain!=before->domain ||
       before->counter_hz!=XE_NP_NP2_SD_FINE_HZ || after->counter_hz!=before->counter_hz ||
       before->generation!=clock_state.generation || after->generation!=before->generation ||
       before->source_epoch!=clock_state.epoch || after->source_epoch!=before->source_epoch){
        DIAGNOSTIC_FAILURE(XE_NP_FINE_DIAG_RUNTIME_FINE_BOUND,XE_NP_FINE_DIAG_DETAIL_BIND_ARGUMENT,
                           generation,source_epoch,before,after);
        XE_NP_Np2SdFineDiagnosticProgress(XE_NP_FINE_PROGRESS_FINE_BOUND_FAIL);
        return 0;
    }
    if(!qualified()){
        DIAGNOSTIC_FAILURE(XE_NP_FINE_DIAG_RUNTIME_FINE_BOUND,XE_NP_FINE_DIAG_DETAIL_BIND_QUALIFICATION,
                           generation,source_epoch,before,after);
        XE_NP_Np2SdFineDiagnosticProgress(XE_NP_FINE_PROGRESS_FINE_BOUND_FAIL);
        return 0;
    }
    /* Independent capture owner supplies actual before/after data observations;
     * no timer read or query can manufacture a first-source proof. */
    clock_state.bound64=1U;
    if(XE_NP_Np2SdFineClock_BindSource(generation,source_epoch)){
        XE_NP_Np2SdFineDiagnosticProgress(XE_NP_FINE_PROGRESS_FINE_BOUND_OK);return 1;
    }
    DIAGNOSTIC_FAILURE(XE_NP_FINE_DIAG_RUNTIME_FINE_BOUND,XE_NP_FINE_DIAG_DETAIL_BIND_QUALIFICATION,
                       generation,source_epoch,before,after);
    XE_NP_Np2SdFineDiagnosticProgress(XE_NP_FINE_PROGRESS_FINE_BOUND_FAIL);
    clock_state.bound64=0U;return 0;
}
int XE_NP_Np2SdFineClock_BoundQualified64(uint32_t domain,uint32_t generation,uint32_t epoch)
{
    uint32_t context=clock_state.context;
    if(!domain || !generation || !epoch || (context&1U) || !clock_state.bound64 ||
       clock_state.domain!=domain || clock_state.generation!=generation || clock_state.epoch!=epoch ||
       !qualified())return 0;
    __DMB();return context==clock_state.context && clock_state.bound64 &&
        clock_state.domain==domain && clock_state.generation==generation && clock_state.epoch==epoch;
}
int XE_NP_Np2SdFineClock_Read64Irq(uint32_t tick,XE_NP_Np2SdFinePoint64 *out)
{
    return clock_state.bound64 && clock_state.generation && clock_state.epoch && read64(tick,out);
}
int XE_NP_Np2SdFineClock_ReadOwned64(XE_NP_Np2SdFinePoint64 *out)
{
    if(!out)return 0;
    memset(out,0,sizeof(*out));
    if(!qualified()){
        DIAGNOSTIC_FAILURE(XE_NP_FINE_DIAG_READ_OWNED,XE_NP_FINE_DIAG_DETAIL_READ_QUALIFICATION,
                           clock_state.generation,clock_state.epoch,0,0);
        XE_NP_Np2SdFineClock_Invalidate();return 0;
    }
    if(read64(HAL_GetTick(),out) && qualified())return 1;
    memset(out,0,sizeof(*out));return 0;
}
int XE_NP_Np2SdFineClock_Read64(XE_NP_Np2SdFinePoint64 *out)
{
    if(!out)return 0;
    memset(out,0,sizeof(*out));
    return clock_state.bound64 && clock_state.generation && clock_state.epoch &&
        XE_NP_Np2SdFineClock_ReadOwned64(out);
}
#endif
#endif
