#include "CE32_Sync.h"

#include <math.h>
#include <stddef.h>
#include <string.h>

CE32_DelayEstimate delay_estimate;

static uint32_t CE32_RTC_TimeToMsOfDay(const RTC_TimeTypeDef *time)
{
    uint32_t second_fraction;
    uint32_t sub_elapsed;
    uint32_t ms_fraction;

    if(time == NULL)
    {
        return 0U;
    }

    second_fraction = time->SecondFraction;
    if(second_fraction == 0U)
    {
        second_fraction = SUBSEC_PRECISION;
    }

    if(time->SubSeconds > second_fraction)
    {
        sub_elapsed = 0U;
    }
    else
    {
        sub_elapsed = second_fraction - time->SubSeconds;
    }

    ms_fraction = (sub_elapsed * 1000U) / (second_fraction + 1U);

    return ((uint32_t)time->Hours * 3600000U) +
           ((uint32_t)time->Minutes * 60000U) +
           ((uint32_t)time->Seconds * 1000U) +
           ms_fraction;
}

static void CE32_RTC_TimeFromMsOfDay(RTC_TimeTypeDef *time, uint32_t ms_of_day)
{
    uint32_t ms_in_second;

    if(time == NULL)
    {
        return;
    }

    ms_of_day %= 86400000U;
    time->Hours = (uint8_t)(ms_of_day / 3600000U);
    time->Minutes = (uint8_t)((ms_of_day / 60000U) % 60U);
    time->Seconds = (uint8_t)((ms_of_day / 1000U) % 60U);
    time->TimeFormat = 0U;
    time->SecondFraction = SUBSEC_PRECISION;
    ms_in_second = ms_of_day % 1000U;
    time->SubSeconds = SUBSEC_PRECISION - ((ms_in_second * (SUBSEC_PRECISION + 1U)) / 1000U);
    time->DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
    time->StoreOperation = RTC_STOREOPERATION_RESET;
}

int CE32_Sync_Sort(float *ptr, uint32_t len)
{
    uint32_t i;
    uint32_t j;

    if(ptr == NULL)
    {
        return -1;
    }

    for(i = 0U; i + 1U < len; ++i)
    {
        for(j = 0U; j + 1U < len - i; ++j)
        {
            if(ptr[j] > ptr[j + 1U])
            {
                float temp = ptr[j];
                ptr[j] = ptr[j + 1U];
                ptr[j + 1U] = temp;
            }
        }
    }

    return 0;
}

void CE32_Time2Sync(const RTC_TimeTypeDef *time, CE32_SyncTypeDef *sync)
{
    if((time == NULL) || (sync == NULL))
    {
        return;
    }

    sync->Seconds = ((uint32_t)time->Minutes * 60U) + (uint32_t)time->Seconds;
    sync->SubSeconds = SUBSEC_PRECISION - time->SubSeconds;
}

float CE32_Sync_TimeDiff(const CE32_SyncTypeDef *sync, const CE32_SyncTypeDef *sync1)
{
    float t0;
    float t1;
    float result;

    if((sync == NULL) || (sync1 == NULL))
    {
        return 0.0f;
    }

    t0 = (float)sync->Seconds + ((float)sync->SubSeconds / (float)(SUBSEC_PRECISION + 1U));
    t1 = (float)sync1->Seconds + ((float)sync1->SubSeconds / (float)(SUBSEC_PRECISION + 1U));
    result = t0 - t1;

    if(result > 1800.0f)
    {
        result -= 3600.0f;
    }
    else if(result < -1800.0f)
    {
        result += 3600.0f;
    }

    return result;
}

void CE32_Sync_DelayEstimate_init(CE32_DelayEstimate *estimate)
{
    if(estimate == NULL)
    {
        return;
    }

    memset(estimate, 0, sizeof(*estimate));
    estimate->state = CE32_DELAYESTIMATE_STATE_PEND;
}

uint16_t CE32_Sync_DelayEstimate_inputdata(CE32_DelayEstimate *estimate, float time_diff)
{
    float temp;
    uint32_t trim;
    uint32_t start;
    uint32_t end;
    uint32_t count;
    uint32_t i;

    if(estimate == NULL)
    {
        return CE32_DELAYESTIMATE_STATE_ABORT;
    }

    switch(estimate->state)
    {
    case CE32_DELAYESTIMATE_STATE_PEND:
        break;

    case CE32_DELAYESTIMATE_STATE_BASELINE:
        estimate->rtc_diff[0][estimate->count] = time_diff;
        estimate->temp_mean[0] += time_diff / (float)CE32_DELAYESTIMATE_SAMPLES;
        estimate->count++;
        if(estimate->count >= CE32_DELAYESTIMATE_SAMPLES)
        {
            estimate->state = CE32_DELAYESTIMATE_STATE_CAL;
        }
        break;

    case CE32_DELAYESTIMATE_STATE_CAL:
        for(i = 0U; i < CE32_DELAYESTIMATE_SAMPLES; ++i)
        {
            estimate->std[0] += (float)pow((double)(estimate->rtc_diff[0][i] - estimate->temp_mean[0]), 2.0);
        }

        estimate->std[0] = (float)sqrt((double)(estimate->std[0] / (float)CE32_DELAYESTIMATE_SAMPLES));
        (void)CE32_Sync_Sort(&estimate->rtc_diff[0][0], CE32_DELAYESTIMATE_SAMPLES);

        trim = CE32_DELAYESTIMATE_SAMPLES / 4U;
        start = trim;
        end = CE32_DELAYESTIMATE_SAMPLES - trim;
        if(end <= start)
        {
            start = 0U;
            end = CE32_DELAYESTIMATE_SAMPLES;
        }

        temp = 0.0f;
        count = 0U;
        for(i = start; i < end; ++i)
        {
            temp += estimate->rtc_diff[0][i];
            count++;
        }
        if(count > 0U)
        {
            temp /= (float)count;
        }

        estimate->mean_corrected[0] = temp;
        estimate->median[0] = estimate->rtc_diff[0][CE32_DELAYESTIMATE_SAMPLES / 2U - 1U];
        estimate->t_diff = estimate->mean_corrected[0];
        estimate->proc_delay = 0.0f;
        estimate->state = CE32_DELAYESTIMATE_STATE_FINISH;
        break;

    case CE32_DELAYESTIMATE_STATE_FINISH:
    case CE32_DELAYESTIMATE_STATE_ABORT:
    default:
        break;
    }

    return estimate->state;
}

HAL_StatusTypeDef CE32_RTC_SetTimeCompat(RTC_HandleTypeDef *hrtc, RTC_TimeTypeDef *time, uint32_t format)
{
    if((hrtc == NULL) || (time == NULL))
    {
        return HAL_ERROR;
    }

    if(time->SecondFraction == 0U)
    {
        time->SecondFraction = SUBSEC_PRECISION;
    }

    if(time->SubSeconds > time->SecondFraction)
    {
        time->SubSeconds = time->SecondFraction;
    }

    return HAL_RTC_SetTime(hrtc, time, format);
}

HAL_StatusTypeDef CE32_RTC_AdjustTime(RTC_HandleTypeDef *hrtc, float time_adjustment)
{
    RTC_TimeTypeDef time;
    RTC_DateTypeDef date_sink;
    int64_t delta_ms;
    int64_t next_ms;
    uint32_t current_ms;

    if(hrtc == NULL)
    {
        return HAL_ERROR;
    }

    if(HAL_RTC_GetTime(hrtc, &time, RTC_FORMAT_BIN) != HAL_OK)
    {
        return HAL_ERROR;
    }
    (void)HAL_RTC_GetDate(hrtc, &date_sink, RTC_FORMAT_BIN);

    current_ms = CE32_RTC_TimeToMsOfDay(&time);
    delta_ms = (int64_t)lround((double)time_adjustment * 1000.0);
    next_ms = (int64_t)current_ms + delta_ms;

    while(next_ms < 0)
    {
        next_ms += 86400000LL;
    }
    next_ms %= 86400000LL;

    CE32_RTC_TimeFromMsOfDay(&time, (uint32_t)next_ms);
    return CE32_RTC_SetTimeCompat(hrtc, &time, RTC_FORMAT_BIN);
}
