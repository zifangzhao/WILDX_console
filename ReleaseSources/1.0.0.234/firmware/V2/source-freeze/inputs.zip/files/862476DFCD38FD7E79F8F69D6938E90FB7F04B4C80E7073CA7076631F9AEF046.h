#ifndef XE_NP_IMU_GRID_SCHEDULE_H
#define XE_NP_IMU_GRID_SCHEDULE_H
#include <stdint.h>

/* Standalone arithmetic prototype, not a timer driver or serialized format.
 * The caller supplies a qualified monotonic 64-bit HSE-derived 1 MHz count,
 * correctly extended through hardware-counter wraps. No per-slot time is stored.
 * The phase and initial ordinal are established separately from the validated
 * recording origin; this helper does not prove that relationship. */
#define XE_NP_GRID_PERIOD_US 800U
/* Reject long service gaps instead of silently aliasing a 32-bit delta. */
#define XE_NP_GRID_MAX_UNSERVICED_US UINT32_MAX

typedef enum {
    XE_NP_GRID_INVALID=-1, XE_NP_GRID_WAIT=0,
    XE_NP_GRID_SAMPLE=1, XE_NP_GRID_MISSED=2
} XE_NP_GridEvent;

typedef struct {
    uint64_t next_due_us,next_ordinal,last_now_us,missed;
    uint32_t max_lateness_us;
    uint8_t active,has_now;
} XE_NP_GridSchedule;

typedef struct {
    uint64_t ordinal,skipped;
    uint32_t lateness_us;
} XE_NP_GridDecision;

/* max_lateness_us must be less than one 800 us period. */
int XE_NP_GridSchedule_Init(XE_NP_GridSchedule *s,uint64_t first_due_us,
    uint64_t first_ordinal,uint32_t max_lateness_us);
/* SAMPLE permits an immediate cached copy labelled with the scheduled slot,
 * with phase uncertainty at least max_lateness plus copy/preemption latency.
 * MISSED returns no sample. skipped counts all newly missed slots, including
 * the current one when the IRQ is too late. WAIT produces no decision. */
XE_NP_GridEvent XE_NP_GridSchedule_Service(XE_NP_GridSchedule *s,
    uint64_t now_us,XE_NP_GridDecision *decision);
/* Stop counts all unobserved slots with due <= stop_us as missing. Returns the
 * first ordinal beyond that inclusive boundary, even if no later sample was
 * queued. This is not a claim that the queue delivered every accepted slot. */
int XE_NP_GridSchedule_Stop(XE_NP_GridSchedule *s,uint64_t stop_us,
    uint64_t *final_exclusive_ordinal,uint64_t *newly_missed);
#endif
