#include "xe_np_rtc_start.h"

#if XE_NP_RTC_START_ENABLE && NP_FINE_COUNTER64_ENABLE
#include "xe_np_np2_sd_fine_clock.h"
#include "xe_np_rtc.h"
#include "xe_np_rtc_online.h"
#include <string.h>

typedef struct {
    XE_NP_Np2SdFinePoint64 before,after,final;
    XE_NP_RtcSample rtc;
    uint8_t raw[NP_RTC_START_BYTES];
    uint64_t token,utc_lower,utc_upper;
    uint32_t status,valid,bound,pc_uncertainty;
} XE_NP_RtcStartCache;
static XE_NP_RtcStartCache rtc_start;

static void rtc_start_reset(uint32_t status)
{ memset(&rtc_start,0,sizeof(rtc_start));rtc_start.status=status; }
static int rtc_start_same(const XE_NP_Np2SdFinePoint64 *a,const XE_NP_Np2SdFinePoint64 *b)
{ return a->domain && a->domain==b->domain && a->counter_hz && a->counter_hz==b->counter_hz &&
         a->generation==b->generation && a->source_epoch==b->source_epoch; }
static int rtc_start_span(const XE_NP_Np2SdFinePoint64 *a,const XE_NP_Np2SdFinePoint64 *b)
{
    uint64_t max;
    if(b->counter<a->counter || !a->counter_hz)return 0;
    max=((uint64_t)a->counter_hz*50U+999999U)/1000000U;
    return b->counter-a->counter<=max;
}
void XE_NP_RtcStart_Clear(void){rtc_start_reset(NP_RTC_START_INVALID);}
uint32_t XE_NP_RtcStart_Status(void){return rtc_start.status;}
int XE_NP_RtcStart_Observe(uint64_t token)
{
    uint64_t utc;int rtc_ok;
    XE_NP_RtcStart_Clear();rtc_start.token=token;
    if(!token || !XE_NP_Np2SdFineClock_ReadOwned64(&rtc_start.before)){
        rtc_start.status=NP_RTC_START_COUNTER;return 0;
    }
    rtc_ok=XE_NP_Rtc_Read(&rtc_start.rtc);
    if(!XE_NP_Np2SdFineClock_ReadOwned64(&rtc_start.after)){
        rtc_start.status=NP_RTC_START_COUNTER;return 0;
    }
    rtc_start.pc_uncertainty=(rtc_start.rtc.status&XE_NP_RTC_STATUS_PC_CALIBRATED)?
        XE_NP_RtcOnline_DeclaredUncertainty():0U;
    if(!rtc_ok){rtc_start.status=rtc_start.rtc.calr?NP_RTC_START_CONFIG:NP_RTC_START_CALENDAR;return 0;}
    rtc_start.status=NP_RTC_START_FLAGS;
    if(!rtc_start_same(&rtc_start.before,&rtc_start.after) || !rtc_start_span(&rtc_start.before,&rtc_start.after) ||
       (rtc_start.rtc.status&(XE_NP_RTC_STATUS_LOCAL_UNAVAILABLE|XE_NP_RTC_STATUS_SHIFT_PENDING)) ||
       !(rtc_start.rtc.status&XE_NP_RTC_STATUS_CALENDAR_VALID) ||
       !XE_NP_RtcOnline_Utc(&rtc_start.rtc,&utc) || utc<NP_RTC_START_MIN_US || utc>NP_RTC_START_END_US-100U)return 0;
    rtc_start.utc_lower=utc;rtc_start.utc_upper=utc+100U;rtc_start.valid=1U;rtc_start.status=NP_RTC_START_OK;return 1;
}
int XE_NP_RtcStart_Bind(const NpRtcStartBinding *binding)
{
    NpRtcStartStamp stamp;
    const uint8_t *r;
    if(!binding || !np_rtc_start_binding_valid(binding) || binding->token!=rtc_start.token ||
       !XE_NP_Np2SdFineClock_Read64(&rtc_start.final)){
        XE_NP_RtcStart_Clear();return 0;
    }
    r=binding->receipt;
    if(rtc_start.final.domain!=np_first_u32(r+28U) || rtc_start.final.generation!=np_first_u32(r+20U) ||
       rtc_start.final.source_epoch!=np_first_u32(r+24U) || rtc_start.final.counter_hz!=np_first_u32(r+40U)){
        XE_NP_RtcStart_Clear();return 0;
    }
    if(rtc_start.valid && (rtc_start.before.domain!=rtc_start.final.domain ||
       rtc_start.before.counter_hz!=rtc_start.final.counter_hz ||
       rtc_start.after.counter>rtc_start.final.counter)){
        rtc_start.valid=0U;rtc_start.status=NP_RTC_START_COUNTER;
    }
    memset(&stamp,0,sizeof(stamp));
    stamp.domain=rtc_start.final.domain;stamp.fine_hz=rtc_start.final.counter_hz;
    stamp.generation=rtc_start.final.generation;stamp.source_epoch=rtc_start.final.source_epoch;
    stamp.token=binding->token;stamp.psca=(rtc_start.rtc.prer>>16U)&127U;
    stamp.pscs=rtc_start.rtc.prer&32767U;stamp.input_hz=XE_NP_RTC_INPUT_HZ;
    stamp.ssr=rtc_start.rtc.raw_ssr;stamp.calr=rtc_start.rtc.calr;
    if(rtc_start.valid){
        stamp.flags=NP_RTC_START_REQUIRED;stamp.utc_lower_us=rtc_start.utc_lower;stamp.utc_upper_us=rtc_start.utc_upper;
        stamp.before64=rtc_start.before.counter;stamp.after64=rtc_start.after.counter;
        if(rtc_start.rtc.status&XE_NP_RTC_STATUS_PC_CALIBRATED){
            stamp.flags|=NP_RTC_START_PC_CALIBRATED;stamp.cal_generation=rtc_start.rtc.calibration_generation;
            stamp.pc_uncertainty_us=rtc_start.pc_uncertainty;
        }
    }
    if(!np_rtc_start_pack(rtc_start.raw,&stamp,binding)){XE_NP_RtcStart_Clear();return 0;}
    rtc_start.bound=1U;return 1;
}
const uint8_t *XE_NP_RtcStart_Frozen(uint64_t token,uint32_t domain,
    uint32_t generation,uint32_t source_epoch,uint32_t hz)
{
    if(!rtc_start.bound || token!=rtc_start.token || domain!=rtc_start.final.domain ||
       generation!=rtc_start.final.generation || source_epoch!=rtc_start.final.source_epoch ||
       hz!=rtc_start.final.counter_hz)return NULL;
    return rtc_start.raw;
}
#else
void XE_NP_RtcStart_Clear(void){}
int XE_NP_RtcStart_Observe(uint64_t token){(void)token;return 0;}
int XE_NP_RtcStart_Bind(const NpRtcStartBinding *binding){(void)binding;return 0;}
uint32_t XE_NP_RtcStart_Status(void){return NP_RTC_START_INVALID;}
const uint8_t *XE_NP_RtcStart_Frozen(uint64_t token,uint32_t domain,uint32_t generation,uint32_t source_epoch,uint32_t hz)
{(void)token;(void)domain;(void)generation;(void)source_epoch;(void)hz;return NULL;}
#endif
