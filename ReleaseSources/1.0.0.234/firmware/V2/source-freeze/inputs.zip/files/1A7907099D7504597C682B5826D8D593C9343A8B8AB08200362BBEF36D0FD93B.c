#include "BASE_string.h"

int BASE_Int16toDecimal(short num, char *str, unsigned short *len)
{
    unsigned char temp[5] = "";
    int sgn = (num >= 0) ? 1 : -1;
    int valid_digit = 0;

    num = (short)(num * sgn);
    for(int i = 0; i < 5; ++i)
    {
        temp[i] = (unsigned char)(num % 10);
        num = (short)(num / 10);
        if(num == 0)
        {
            valid_digit = i;
            break;
        }
    }

    *len = 0;
    if(sgn < 0)
    {
        str[(*len)++] = '-';
    }

    for(int i = 0; i <= valid_digit; ++i)
    {
        str[(*len)++] = (char)temp[valid_digit - i];
    }
    str[*len + 1U] = 0;
    return 0;
}

int BASE_Uint16toDecimal(unsigned short num, char *str, unsigned short *len)
{
    unsigned char temp[5] = "";
    int valid_digit = 0;

    for(int i = 0; i < 5; ++i)
    {
        temp[i] = (unsigned char)(num % 10U);
        num = (unsigned short)(num / 10U);
        if(num == 0U)
        {
            valid_digit = i;
            break;
        }
    }

    for(int i = 0; i <= valid_digit; ++i)
    {
        str[i] = (char)temp[valid_digit - i];
    }
    (void)len;
    return 0;
}

int BASE_Int16toChar(short num, char *str, unsigned short *len)
{
    unsigned char temp[5] = "";
    int sgn = (num >= 0) ? 1 : -1;
    int valid_digit = 0;

    num = (short)(num * sgn);
    for(int i = 0; i < 5; ++i)
    {
        temp[i] = (unsigned char)(num % 10);
        num = (short)(num / 10);
        if(num == 0)
        {
            valid_digit = i;
            break;
        }
    }

    *len = 0;
    if(sgn < 0)
    {
        str[(*len)++] = '-';
    }

    for(int i = 0; i <= valid_digit; ++i)
    {
        str[(*len)++] = (char)('0' + temp[valid_digit - i]);
    }
    str[*len + 1U] = 0;
    return 0;
}

int BASE_Uint16toChar(unsigned short num, char *str, unsigned short *len)
{
    unsigned char temp[5] = "";
    int valid_digit = 0;

    for(int i = 0; i < 5; ++i)
    {
        temp[i] = (unsigned char)(num % 10U);
        num = (unsigned short)(num / 10U);
        if(num == 0U)
        {
            valid_digit = i;
            break;
        }
    }

    for(int i = 0; i <= valid_digit; ++i)
    {
        str[i] = (char)('0' + temp[valid_digit - i]);
    }
    str[valid_digit + 1] = '\0';
    *len = (unsigned short)(valid_digit + 1);
    return 0;
}

int BASE_Uint16toChar_Decimal(unsigned short num, short place, char *str, unsigned short *len)
{
    unsigned char temp[8] = "";
    int valid_digit = 0;
    int loc = 0;

    for(int i = 0; i < 8; ++i)
    {
        temp[i] = (unsigned char)(num % 10U);
        num = (unsigned short)(num / 10U);
        if(num == 0U)
        {
            valid_digit = i;
            break;
        }
    }

    for(int i = 0; i <= valid_digit; ++i)
    {
        str[loc++] = (char)('0' + temp[valid_digit - i]);
        if((valid_digit - i - place) == 0)
        {
            str[loc++] = '.';
        }
    }

    if(valid_digit == 0)
    {
        str[loc++] = '.';
        str[loc++] = '0';
    }

    str[loc++] = '\0';
    *len = (unsigned short)loc;
    return 0;
}

int BASE_Uint32toChar(unsigned long num, char *str, unsigned short *len)
{
    unsigned char temp[10] = "";
    int valid_digit = 0;

    for(int i = 0; i < 10; ++i)
    {
        temp[i] = (unsigned char)(num % 10UL);
        num /= 10UL;
        if(num == 0UL)
        {
            valid_digit = i;
            break;
        }
    }

    for(int i = 0; i <= valid_digit; ++i)
    {
        str[i] = (char)('0' + temp[valid_digit - i]);
    }
    str[valid_digit + 1] = '\0';
    *len = (unsigned short)(valid_digit + 1);
    return 0;
}

int BASE_Uint32toCharN(unsigned long num, char *str, unsigned short len)
{
    unsigned char temp[10] = "";
    int valid_digit = (int)len - 1;

    for(unsigned short i = 0; i < len; ++i)
    {
        temp[i] = (unsigned char)(num % 10UL);
        num /= 10UL;
    }

    for(int i = 0; i <= valid_digit; ++i)
    {
        str[i] = (char)('0' + temp[valid_digit - i]);
    }
    str[valid_digit + 1] = '\0';
    return 0;
}

int BASE_HextoChar(unsigned char x, char *str, unsigned short *len)
{
    unsigned char temp[2] = "";

    temp[0] = (unsigned char)((x & 0xf0U) >> 4);
    temp[1] = (unsigned char)(x & 0x0fU);
    for(int i = 0; i < 2; ++i)
    {
        str[i] = (char)(temp[i] < 10U ? (temp[i] + '0') : (temp[i] + 'A' - 10U));
    }
    *len = 2U;
    return 0;
}

int BASE_SwapEndian(unsigned char *x, int len, int unitBytes)
{
    if((unitBytes <= 0) || ((len % unitBytes) != 0))
    {
        return -1;
    }

    for(int i = 0; i < len; i += unitBytes)
    {
        int swapcnt = unitBytes / 2;
        for(int j = 0; j < swapcnt; ++j)
        {
            unsigned char temp = x[i + j];
            x[i + j] = x[i + unitBytes - 1 - j];
            x[i + unitBytes - 1 - j] = temp;
        }
    }
    return 0;
}

unsigned short BASE_reverseBits(unsigned short num)
{
    unsigned short rev = 0U;

    for(int i = 0; i < 16; ++i)
    {
        rev = (unsigned short)((rev << 1U) | (num & 1U));
        num = (unsigned short)(num >> 1U);
    }
    return rev;
}
