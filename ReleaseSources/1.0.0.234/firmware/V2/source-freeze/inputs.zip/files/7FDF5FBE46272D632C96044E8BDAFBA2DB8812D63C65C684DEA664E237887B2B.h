/* Experimental ownership core for separating the NP2 acquisition ring from
 * SDMMC IDMA buffers. Selected only by an opt-in live-HIL build. The 4+9 split
 * reuses the existing 13-RU SRAM allocation; PSRAM is a bounded overflow FIFO.
 * All calls are foreground operations except seal(), which may follow a
 * published acquisition boundary. No function copies payload bytes. */
#ifndef XE_NP_NP2_STAGE_QUEUE_H
#define XE_NP_NP2_STAGE_QUEUE_H
#include <stdint.h>
#include <string.h>

#define XE_NP2_STAGE_ACQ_RUS 4U
#define XE_NP2_STAGE_STORE_RUS 9U
#define XE_NP2_STAGE_RU_BYTES 186368U
#define XE_NP2_STAGE_SPILL_RUS (8388608U/XE_NP2_STAGE_RU_BYTES)
#ifndef XE_NP2_STAGE_RESTORE_IDLE_ONLY
#define XE_NP2_STAGE_RESTORE_IDLE_ONLY 0U
#endif
#ifndef XE_NP2_STAGE_DIRECT_PSRAM_IDMA
#define XE_NP2_STAGE_DIRECT_PSRAM_IDMA 0U
#endif
#define XE_NP2_STAGE_SD_NODE_BYTES (127U*512U)
#ifndef XE_NP2_STAGE_MAX_SD_UNITS
#define XE_NP2_STAGE_MAX_SD_UNITS 7U
#endif
#if XE_NP2_STAGE_MAX_SD_UNITS != 7U && XE_NP2_STAGE_MAX_SD_UNITS != 8U
#error "Staged SD batch must be seven or eight RUs"
#endif
#define XE_NP2_STAGE_NODES_PER_RU 3U
#define XE_NP2_STAGE_MAX_SD_NODES (XE_NP2_STAGE_MAX_SD_UNITS*XE_NP2_STAGE_NODES_PER_RU)
#if defined(XE_NP_NP2_STAGED_CAPTURE) && XE_NP_NP2_STAGED_CAPTURE
#include "xe_np_np2_direct_layout.h"
_Static_assert(NP2_DIRECT_SLOTS==XE_NP2_STAGE_ACQ_RUS*4U &&
               XE_NP2_STAGE_RU_BYTES==NP2_DIRECT_SLOT_BYTES*4U,
               "Staged queue must match the four-RU PSSI/SPI DMA geometry");
#endif
_Static_assert((XE_NP2_STAGE_RU_BYTES+XE_NP2_STAGE_SD_NODE_BYTES-1U)/
               XE_NP2_STAGE_SD_NODE_BYTES==XE_NP2_STAGE_NODES_PER_RU,
               "Each staged RU must fit exactly three IDMA nodes");
/* Against np2_direct_sd_13ru.sct: bank0 is acquisition; bank1, bank2 and
 * the four-slot extension remain immutable SD/restore destinations. */
static inline uint32_t XE_Np2Stage_SourcePhysicalRu(uint32_t sequence)
{ return sequence%XE_NP2_STAGE_ACQ_RUS; }
static inline uint32_t XE_Np2Stage_StorePhysicalRu(uint32_t slot)
{ return XE_NP2_STAGE_ACQ_RUS+slot; }

enum { XE_NP2_STAGE_FREE=0, XE_NP2_STAGE_READY=1,
       XE_NP2_STAGE_COPY=2, XE_NP2_STAGE_IDMA=3 };
enum { XE_NP2_STAGE_COPY_NONE=0, XE_NP2_STAGE_TO_SRAM=1,
       XE_NP2_STAGE_TO_PSRAM=2, XE_NP2_STAGE_FROM_PSRAM=3 };

typedef struct {
    uint32_t produced, handed, committed;
    uint32_t spill_head, spill_tail, spill_count;
    uint32_t spill_sequence[XE_NP2_STAGE_SPILL_RUS];
    uint32_t store_sequence[XE_NP2_STAGE_STORE_RUS];
    uint8_t source_state[XE_NP2_STAGE_ACQ_RUS];
    uint8_t store_state[XE_NP2_STAGE_STORE_RUS];
    uint8_t copy_kind, copy_source, copy_destination;
    uint32_t copy_sequence;
    uint8_t sd_active, sd_count, sd_retired;
    uint8_t sd_slots[XE_NP2_STAGE_MAX_SD_UNITS];
} XE_Np2StageQueue;

typedef struct { uint32_t address,bytes; } XE_Np2StageSdSegment;

static inline uint32_t XE_Np2Stage_CopyChunkBytes(uint32_t offset)
{
    if(offset>=XE_NP2_STAGE_RU_BYTES)return 0U;
    uint32_t remaining=XE_NP2_STAGE_RU_BYTES-offset;
    return remaining>XE_NP2_STAGE_SD_NODE_BYTES?
        XE_NP2_STAGE_SD_NODE_BYTES:remaining;
}

static inline void XE_Np2Stage_Init(XE_Np2StageQueue *q)
{ memset(q,0,sizeof(*q)); }

/* The physical PSSI/SPI destination for sequence n is n mod 4. Reserve one
 * complete RU for the producer/D8 lookahead while GPDMA owns older units.
 * Capture must check this before arming/reusing a slot, not after overwrite. */
static inline int XE_Np2Stage_CanCapture(const XE_Np2StageQueue *q)
{ return q->produced-q->handed<XE_NP2_STAGE_ACQ_RUS-1U &&
         q->source_state[q->produced%XE_NP2_STAGE_ACQ_RUS]==XE_NP2_STAGE_FREE; }
static inline int XE_Np2Stage_Seal(XE_Np2StageQueue *q)
{
    uint32_t slot=q->produced%XE_NP2_STAGE_ACQ_RUS;
    if(!XE_Np2Stage_CanCapture(q))return -1;
    q->source_state[slot]=XE_NP2_STAGE_READY;
    q->produced++;
    return 0;
}
static inline int XE_Np2Stage_FreeStore(const XE_Np2StageQueue *q)
{
    for(uint32_t i=0;i<XE_NP2_STAGE_STORE_RUS;i++)
        if(q->store_state[i]==XE_NP2_STAGE_FREE)return (int)i;
    return -1;
}
static inline int XE_Np2Stage_ReadyStore(const XE_Np2StageQueue *q,uint32_t sequence)
{
    for(uint32_t i=0;i<XE_NP2_STAGE_STORE_RUS;i++)
        if(q->store_state[i]==XE_NP2_STAGE_READY && q->store_sequence[i]==sequence)
            return (int)i;
    return -1;
}

/* Returns copy kind and physical source/destination indices in q. Preserve
 * one free SRAM slot for the oldest spilled unit. Newer source RUs may use
 * OTHER free slots while PSRAM is nonempty; forcing every newer RU through
 * PSRAM would require two slow copies per RU. Restore the ordered PSRAM head
 * first when capture has at most one waiting RU; otherwise source handoff
 * wins to protect the four-RU acquisition ring. The opt-in idle-only policy
 * instead restores only when no capture RU waits, except when a full spill
 * FIFO makes restoration necessary to free a spill slot. Either policy can
 * lose to an unlucky card tail; neither is a losslessness guarantee. */
static inline int XE_Np2Stage_BeginCopyPriority(XE_Np2StageQueue *q,
                                                int feeder_urgent)
{
    if(q->copy_kind!=XE_NP2_STAGE_COPY_NONE)return -1;
    int free_slot=XE_Np2Stage_FreeStore(q);
    uint32_t source_pending=q->produced-q->handed;
    int restore_first=q->spill_count && free_slot>=0 &&
#if XE_NP2_STAGE_DIRECT_PSRAM_IDMA
        0;
    (void)feeder_urgent;
#elif XE_NP2_STAGE_RESTORE_IDLE_ONLY
        (source_pending==0U || q->spill_count==XE_NP2_STAGE_SPILL_RUS ||
         (feeder_urgent && source_pending<=1U));
#else
        (source_pending<=1U || q->spill_count==XE_NP2_STAGE_SPILL_RUS);
    (void)feeder_urgent;
#endif
    if(source_pending && !restore_first){
        uint32_t seq=q->handed,source=seq%XE_NP2_STAGE_ACQ_RUS;
        if(q->source_state[source]!=XE_NP2_STAGE_READY)return -1;
        int destination=free_slot;
        if(q->spill_count && destination>=0 && !XE_NP2_STAGE_DIRECT_PSRAM_IDMA){
            uint32_t free_count=0U;
            for(uint32_t i=0;i<XE_NP2_STAGE_STORE_RUS;i++)
                free_count+=(q->store_state[i]==XE_NP2_STAGE_FREE);
            if(free_count<=1U)destination=-1;
        }
        if(destination<0){
            if(q->spill_count>=XE_NP2_STAGE_SPILL_RUS)return 0;
            q->copy_kind=XE_NP2_STAGE_TO_PSRAM;
            q->copy_destination=(uint8_t)q->spill_head;
        }else{
            q->copy_kind=XE_NP2_STAGE_TO_SRAM;
            q->copy_destination=(uint8_t)destination;
            q->store_state[destination]=XE_NP2_STAGE_COPY;
            q->store_sequence[destination]=seq;
        }
        q->copy_sequence=seq;q->copy_source=(uint8_t)source;
        q->source_state[source]=XE_NP2_STAGE_COPY;
        return q->copy_kind;
    }
    if(!q->spill_count || free_slot<0 || XE_NP2_STAGE_DIRECT_PSRAM_IDMA)return 0;
    q->copy_kind=XE_NP2_STAGE_FROM_PSRAM;
    q->copy_sequence=q->spill_sequence[q->spill_tail];
    q->copy_source=(uint8_t)q->spill_tail;
    q->copy_destination=(uint8_t)free_slot;
    q->store_state[free_slot]=XE_NP2_STAGE_COPY;
    q->store_sequence[free_slot]=q->copy_sequence;
    return q->copy_kind;
}
static inline int XE_Np2Stage_BeginCopy(XE_Np2StageQueue *q)
{ return XE_Np2Stage_BeginCopyPriority(q,0); }
static inline int XE_Np2Stage_CompleteCopy(XE_Np2StageQueue *q)
{
    uint32_t kind=q->copy_kind;
    if(kind==XE_NP2_STAGE_COPY_NONE)return -1;
    if(kind==XE_NP2_STAGE_TO_SRAM || kind==XE_NP2_STAGE_TO_PSRAM){
        if(q->copy_sequence!=q->handed ||
           q->source_state[q->copy_source]!=XE_NP2_STAGE_COPY)return -1;
        if(kind==XE_NP2_STAGE_TO_SRAM){
            if(q->store_state[q->copy_destination]!=XE_NP2_STAGE_COPY)return -1;
            q->store_state[q->copy_destination]=XE_NP2_STAGE_READY;
        }else{
            if(q->spill_count>=XE_NP2_STAGE_SPILL_RUS ||
               q->copy_destination!=q->spill_head)return -1;
            q->spill_sequence[q->spill_head]=q->copy_sequence;
            q->spill_head=(q->spill_head+1U)%XE_NP2_STAGE_SPILL_RUS;
            q->spill_count++;
        }
        q->source_state[q->copy_source]=XE_NP2_STAGE_FREE;
        q->handed++;
    }else if(kind==XE_NP2_STAGE_FROM_PSRAM){
        if(!q->spill_count || q->copy_source!=q->spill_tail ||
           q->spill_sequence[q->spill_tail]!=q->copy_sequence ||
           q->store_state[q->copy_destination]!=XE_NP2_STAGE_COPY)return -1;
        q->store_state[q->copy_destination]=XE_NP2_STAGE_READY;
        q->spill_tail=(q->spill_tail+1U)%XE_NP2_STAGE_SPILL_RUS;
        q->spill_count--;
    }else return -1;
    q->copy_kind=XE_NP2_STAGE_COPY_NONE;
    return 0;
}

/* One CMD25 at a time. The caller constructs IDMA nodes from sd_slots[];
 * these physical SRAM slots need not be adjacent or follow sequence modulo9. */
static inline int XE_Np2Stage_BeginSd(XE_Np2StageQueue *q,uint32_t max_units,
                                       uint32_t min_units)
{
    if(q->sd_active || !max_units || max_units>XE_NP2_STAGE_MAX_SD_UNITS || !min_units ||
       min_units>max_units)return -1;
    uint32_t units=0U;
    for(;units<max_units;units++){
        int slot=XE_Np2Stage_ReadyStore(q,q->committed+units);
        if(slot<0)break;
        q->sd_slots[units]=(uint8_t)slot;
    }
    if(units<min_units)return 0;
    for(uint32_t i=0;i<units;i++)q->store_state[q->sd_slots[i]]=XE_NP2_STAGE_IDMA;
    q->sd_count=(uint8_t)units;q->sd_retired=0U;q->sd_active=1U;
    return (int)units;
}
/* Convert the ordered CMD25 claim to raw SDMMC IDMA node addresses. The
 * caller supplies the linker-attested RU base addresses, indexed 0..12.
 * Never coalesce across an RU here: three 127-sector-or-smaller nodes per
 * unit make descriptor completion/retirement boundaries unambiguous. */
static inline int XE_Np2Stage_SdSegments(const XE_Np2StageQueue *q,
    const uint32_t physical_ru_base[13],XE_Np2StageSdSegment *out,uint32_t capacity)
{
    if(!q->sd_active || !physical_ru_base || !out ||
       capacity<XE_NP2_STAGE_MAX_SD_NODES)return -1;
    uint32_t count=0U;
    for(uint32_t unit=0U;unit<q->sd_count;unit++){
        uint32_t slot=q->sd_slots[unit];
        if(slot>=XE_NP2_STAGE_STORE_RUS ||
           q->store_state[slot]!=XE_NP2_STAGE_IDMA ||
           q->store_sequence[slot]!=q->committed+unit)return -1;
        uint32_t base=physical_ru_base[XE_Np2Stage_StorePhysicalRu(slot)];
        if((base&31U) || base+XE_NP2_STAGE_RU_BYTES<base)return -1;
        uint32_t offset=0U;
        while(offset<XE_NP2_STAGE_RU_BYTES){
            uint32_t bytes=XE_NP2_STAGE_RU_BYTES-offset;
            if(bytes>XE_NP2_STAGE_SD_NODE_BYTES)bytes=XE_NP2_STAGE_SD_NODE_BYTES;
            if((bytes&511U) || count>=capacity)return -1;
            out[count].address=base+offset;
            out[count].bytes=bytes;
            count++;offset+=bytes;
        }
    }
    return (int)count;
}
static inline int XE_Np2Stage_RetireIdma(XE_Np2StageQueue *q)
{
    if(!q->sd_active || q->sd_retired>=q->sd_count)return -1;
    uint32_t slot=q->sd_slots[q->sd_retired];
    if(q->store_state[slot]!=XE_NP2_STAGE_IDMA ||
       q->store_sequence[slot]!=q->committed+q->sd_retired)return -1;
    q->store_state[slot]=XE_NP2_STAGE_FREE;
    q->sd_retired++;
    return 0;
}
static inline int XE_Np2Stage_CommitSd(XE_Np2StageQueue *q)
{
    if(!q->sd_active || q->sd_retired!=q->sd_count)return -1;
    q->committed+=q->sd_count;
    q->sd_active=q->sd_count=q->sd_retired=0U;
    return 0;
}
#endif
