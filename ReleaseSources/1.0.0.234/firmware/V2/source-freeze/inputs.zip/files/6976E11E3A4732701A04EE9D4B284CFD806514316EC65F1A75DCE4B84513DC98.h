/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32u5xx_it.h
  * @brief   This file contains the headers of the interrupt handlers.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __STM32U5xx_IT_H
#define __STM32U5xx_IT_H

#ifdef __cplusplus
extern "C" {
#endif

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void NMI_Handler(void);
void HardFault_Handler(void);
void MemManage_Handler(void);
void BusFault_Handler(void);
void UsageFault_Handler(void);
void SVC_Handler(void);
void DebugMon_Handler(void);
void PendSV_Handler(void);
void SysTick_Handler(void);
/* USER CODE BEGIN EFP */
void I2C5_EV_IRQHandler(void);
void I2C5_ER_IRQHandler(void);
void I2C6_EV_IRQHandler(void);
void I2C6_ER_IRQHandler(void);
void USART2_IRQHandler(void);
void SDMMC1_IRQHandler(void);
void GPDMA1_Channel11_IRQHandler(void);
void GPDMA1_Channel10_IRQHandler(void);
void LPDMA1_Channel0_IRQHandler(void);
void GPDMA1_Channel12_IRQHandler(void);
void DCMI_PSSI_IRQHandler(void);
void GPDMA1_Channel13_IRQHandler(void);
void GPDMA1_Channel14_IRQHandler(void);
void GPDMA1_Channel9_IRQHandler(void);
void SPI1_IRQHandler(void);

/* USER CODE END EFP */

#ifdef __cplusplus
}
#endif

#endif /* __STM32U5xx_IT_H */
