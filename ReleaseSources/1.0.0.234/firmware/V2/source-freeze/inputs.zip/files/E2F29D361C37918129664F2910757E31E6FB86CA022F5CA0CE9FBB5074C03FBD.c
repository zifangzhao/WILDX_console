#include "xe_np_imu_grid_queue.h"
#include <string.h>

/* Cortex-M33 is single-core: the IRQ producer and foreground consumer each
 * own one index. DMB publishes slots before head and retirement before tail.
 * The x86 native test uses a compiler barrier; x86 orders ordinary stores. */
#if defined(_MSC_VER)
#include <intrin.h>
#define GRID_BARRIER() _ReadWriteBarrier()
#elif defined(__arm__) || defined(__thumb__)
#define GRID_BARRIER() __asm volatile("dmb ish" ::: "memory")
#else
#define GRID_BARRIER() __atomic_thread_fence(__ATOMIC_SEQ_CST)
#endif

void XE_NP_ImuGridQueue_Reset(XE_NP_ImuGridQueue *q)
{
    /* Never reset while the producer IRQ or foreground consumer is active. */
    memset(q,0,sizeof(*q));
}

int XE_NP_ImuGridQueue_Push(XE_NP_ImuGridQueue *q,uint64_t ordinal,
    const int32_t accel[3],const int32_t gyro[3],const int32_t mag[3],
    uint32_t ag_sequence,uint32_t mag_sequence,uint32_t valid,uint32_t error)
{
    uint32_t head=q->head,tail=q->tail;
    uint32_t flags=valid&(XE_NP_IMU_GRID_AG_VALID|XE_NP_IMU_GRID_MAG_VALID);
    XE_NP_ImuGridSlot *slot;
    GRID_BARRIER();
    if((flags&XE_NP_IMU_GRID_AG_VALID) && (q->last_valid&XE_NP_IMU_GRID_AG_VALID) &&
       ag_sequence==q->last_ag_sequence)flags|=XE_NP_IMU_GRID_AG_REPEAT;
    if((flags&XE_NP_IMU_GRID_MAG_VALID) && (q->last_valid&XE_NP_IMU_GRID_MAG_VALID) &&
       mag_sequence==q->last_mag_sequence)flags|=XE_NP_IMU_GRID_MAG_REPEAT;
    q->last_ag_sequence=ag_sequence;q->last_mag_sequence=mag_sequence;
    q->last_valid=valid&(XE_NP_IMU_GRID_AG_VALID|XE_NP_IMU_GRID_MAG_VALID);
    if(error)flags|=XE_NP_IMU_GRID_ERROR;
    if((uint32_t)(head-tail)>=XE_NP_IMU_GRID_CAPACITY){
        if(q->dropped!=UINT32_MAX)q->dropped++;
        return 0;
    }
    slot=&q->slots[head&(XE_NP_IMU_GRID_CAPACITY-1U)];
    slot->ordinal=ordinal;
    for(uint32_t i=0U;i<3U;i++){
        slot->values[i]=accel[i];slot->values[i+3U]=gyro[i];slot->values[i+6U]=mag[i];
    }
    slot->flags=flags;GRID_BARRIER();q->head=head+1U;
    return 1;
}

int XE_NP_ImuGridQueue_Pop(XE_NP_ImuGridQueue *q,XE_NP_ImuGridSlot *out)
{
    uint32_t tail=q->tail,head=q->head;
    GRID_BARRIER();
    if(tail==head)return 0;
    *out=q->slots[tail&(XE_NP_IMU_GRID_CAPACITY-1U)];
    GRID_BARRIER();q->tail=tail+1U;
    return 1;
}
