#include "xe_np_imu_grid_timer.h"
#if defined(XE_NP_GRID_TIMER_FAKE)
#include "imu_grid_tim3_fake.h"
#else
#include "xe_np_hal.h"
#endif

/* PSSI/GPDMA capture=1; SD=6. Keep the optional grid below both. */
#define GRID_PRIORITY 7U
#define GRID_HZ 1250U
#define CLOCK1_MASK (RCC_CFGR1_SW|RCC_CFGR1_SWS)
#define CLOCK2_MASK (RCC_CFGR2_HPRE|RCC_CFGR2_PPRE1)

typedef struct {
    XE_NP_GridTimerCallback callback;
    void *context;
    uint32_t old_sleep,old_priority,cfgr1,cfgr2,pll,div,frac,hclk,psc,arr;
    uint8_t owned,started;
} GridTimer;
static GridTimer timer;

static int root_allowed(void)
{
    uint32_t sw=RCC->CFGR1&RCC_CFGR1_SWS;
    return !(CoreDebug->DHCSR&CoreDebug_DHCSR_C_DEBUGEN_Msk) &&
        !(DBGMCU->APB1FZR1&DBGMCU_APB1FZR1_DBG_TIM3_STOP) &&
        !(SCB->SCR&(SCB_SCR_SLEEPDEEP_Msk|SCB_SCR_SLEEPONEXIT_Msk)) &&
        (RCC->CR&RCC_CR_HSERDY) &&
        (sw==RCC_SYSCLKSOURCE_STATUS_HSE ||
        (sw==RCC_SYSCLKSOURCE_STATUS_PLLCLK && (RCC->CR&RCC_CR_PLL1RDY) &&
         (RCC->PLL1CFGR&RCC_PLL1CFGR_PLL1SRC)==RCC_PLLSOURCE_HSE));
}
static int clock_same(void)
{
    return root_allowed() && (RCC->CFGR1&CLOCK1_MASK)==timer.cfgr1 &&
        (RCC->CFGR2&CLOCK2_MASK)==timer.cfgr2 && RCC->PLL1CFGR==timer.pll &&
        RCC->PLL1DIVR==timer.div && RCC->PLL1FRACR==timer.frac &&
        SystemCoreClock==timer.hclk;
}
/* Even with the clock gated, a previous claimant might leave configuration
 * behind. Refuse a dirty timer; don't reset or overwrite foreign state. */
static int reset_state(void)
{
    return !TIM3->CR1 && !TIM3->CR2 && !TIM3->SMCR && !TIM3->DIER &&
        !TIM3->SR && !TIM3->CCMR1 && !TIM3->CCMR2 && !TIM3->CCER &&
        !TIM3->CNT && !TIM3->PSC && TIM3->ARR==UINT32_MAX && !TIM3->TISEL &&
        !TIM3->AF1 && !TIM3->OR1 && !TIM3->DCR;
}
int XE_NP_GridTimer_Prepare(XE_NP_GridTimerCallback callback,void *context)
{
    uint32_t hz,ticks,divisor=0U,key,cfgr1,cfgr2,pll,div,frac,hclk;
    if(!callback || timer.owned || __get_IPSR() || !root_allowed())return 0;
    cfgr1=RCC->CFGR1&CLOCK1_MASK;cfgr2=RCC->CFGR2&CLOCK2_MASK;
    pll=RCC->PLL1CFGR;div=RCC->PLL1DIVR;frac=RCC->PLL1FRACR;hclk=SystemCoreClock;
    hz=HAL_RCC_GetPCLK1Freq();
    if((cfgr2&RCC_CFGR2_PPRE1)>=RCC_CFGR2_PPRE1_2){
        if(hz>UINT32_MAX/2U)return 0;hz*=2U;
    }
    if(!hz || hz%GRID_HZ)return 0;
    ticks=hz/GRID_HZ;
    /* 16-bit PSC/ARR; calculate once at admission, never inside IRQ. */
    for(uint32_t i=1U;i<=65536U;i++)if(ticks%i==0U && ticks/i<=65536U){divisor=i;break;}
    if(!divisor)return 0;
    key=__get_PRIMASK();__disable_irq();
    if(timer.owned || !root_allowed() || (RCC->CFGR1&CLOCK1_MASK)!=cfgr1 ||
       (RCC->CFGR2&CLOCK2_MASK)!=cfgr2 || RCC->PLL1CFGR!=pll || RCC->PLL1DIVR!=div ||
       RCC->PLL1FRACR!=frac || SystemCoreClock!=hclk ||
       (RCC->APB1ENR1&RCC_APB1ENR1_TIM3EN) || (RCC->APB1RSTR1&RCC_APB1RSTR1_TIM3RST) ||
       NVIC_GetEnableIRQ(TIM3_IRQn) || NVIC_GetPendingIRQ(TIM3_IRQn)){
        __set_PRIMASK(key);return 0;
    }
    RCC->APB1ENR1|=RCC_APB1ENR1_TIM3EN;(void)RCC->APB1ENR1;__DSB();
    if(!reset_state()){
        RCC->APB1ENR1&=~RCC_APB1ENR1_TIM3EN;__DSB();__set_PRIMASK(key);return 0;
    }
    timer.old_sleep=RCC->APB1SMENR1&RCC_APB1SMENR1_TIM3SMEN;
    timer.old_priority=NVIC_GetPriority(TIM3_IRQn);
    timer.cfgr1=cfgr1;timer.cfgr2=cfgr2;timer.pll=pll;timer.div=div;timer.frac=frac;timer.hclk=hclk;
    timer.psc=divisor-1U;timer.arr=ticks/divisor-1U;
    timer.callback=callback;timer.context=context;timer.owned=1U;timer.started=0U;
    RCC->APB1SMENR1|=RCC_APB1SMENR1_TIM3SMEN;
    TIM3->CR1=0U;TIM3->DIER=0U;TIM3->PSC=timer.psc;TIM3->ARR=timer.arr;
    TIM3->EGR=TIM_EGR_UG;TIM3->SR=0U;TIM3->CNT=0U;
    NVIC_SetPriority(TIM3_IRQn,GRID_PRIORITY);__DSB();__set_PRIMASK(key);return 1;
}
int XE_NP_GridTimer_Qualified(void)
{
    return timer.owned && clock_same() &&
        (RCC->APB1ENR1&RCC_APB1ENR1_TIM3EN) &&
        (RCC->APB1SMENR1&RCC_APB1SMENR1_TIM3SMEN) &&
        !(RCC->APB1RSTR1&RCC_APB1RSTR1_TIM3RST) &&
        TIM3->CR1==(timer.started?TIM_CR1_CEN:0U) &&
        TIM3->DIER==(timer.started?TIM_DIER_UIE:0U) && !TIM3->CR2 && !TIM3->SMCR &&
        !TIM3->CCER && !TIM3->CCMR1 && !TIM3->CCMR2 &&
        TIM3->PSC==timer.psc && TIM3->ARR==timer.arr &&
        NVIC_GetPriority(TIM3_IRQn)==GRID_PRIORITY &&
        NVIC_GetEnableIRQ(TIM3_IRQn)==timer.started;
}
int XE_NP_GridTimer_Start(void)
{
    uint32_t key;
    if(__get_IPSR())return 0;
    key=__get_PRIMASK();__disable_irq();
    if(timer.started || !XE_NP_GridTimer_Qualified() || NVIC_GetPendingIRQ(TIM3_IRQn)){
        __set_PRIMASK(key);return 0;
    }
    TIM3->SR=0U;TIM3->CNT=0U;TIM3->DIER=TIM_DIER_UIE;
    timer.started=1U;__DMB();NVIC_EnableIRQ(TIM3_IRQn);TIM3->CR1=TIM_CR1_CEN;
    __DSB();__set_PRIMASK(key);return 1;
}
int XE_NP_GridTimer_SwitchCurrentCallback(XE_NP_GridTimerCallback callback,void *context)
{
    if(!callback || !timer.owned || !timer.started || timer.context!=context ||
       __get_IPSR()!=(uint32_t)(TIM3_IRQn+16U))return 0;
    timer.callback=callback;__DMB();return 1;
}
/* The single update flag can coalesce periods; the callback must use the
 * independently qualified monotonic counter/scheduler to detect gaps. */
void TIM3_IRQHandler(void)
{
    if(timer.owned && timer.started && (TIM3->SR&TIM_SR_UIF)){
        TIM3->SR=~TIM_SR_UIF;__DSB();timer.callback(timer.context);
    }
}
void XE_NP_GridTimer_Release(void)
{
    uint32_t key;
    if(__get_IPSR())return;
    key=__get_PRIMASK();__disable_irq();
    if(timer.owned){
        TIM3->DIER=0U;TIM3->CR1=0U;NVIC_DisableIRQ(TIM3_IRQn);
        NVIC_ClearPendingIRQ(TIM3_IRQn);timer.started=0U;__DMB();
        TIM3->PSC=0U;TIM3->ARR=UINT32_MAX;TIM3->CNT=0U;TIM3->EGR=TIM_EGR_UG;TIM3->SR=0U;
        NVIC_SetPriority(TIM3_IRQn,timer.old_priority);
        RCC->APB1SMENR1=(RCC->APB1SMENR1&~RCC_APB1SMENR1_TIM3SMEN)|timer.old_sleep;
        RCC->APB1ENR1&=~RCC_APB1ENR1_TIM3EN;__DSB();
        timer.owned=0U;timer.callback=0;timer.context=0;
    }
    __set_PRIMASK(key);
}
