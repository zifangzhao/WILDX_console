#ifndef XE_NP_NP2_DIAG_CONFIG_H
#define XE_NP_NP2_DIAG_CONFIG_H

/* Pure, read-only-safe diagnostic profile construction. This is intentionally
 * independent of I2C, capture, and acquisition state: it describes only the
 * known four-shank NP2 image used to prove configuration serialization. */
#include <stdint.h>

#define XE_NP_NP2_DIAG_SHANKS 4U
#define XE_NP_NP2_DIAG_CHANNELS 384U
#define XE_NP_NP2_DIAG_SHANK_BYTES 161U
#define XE_NP_NP2_DIAG_BASE_BYTES 96U
#define XE_NP_NP2_DIAG_EEPROM_STRING_BYTES 20U
#define XE_NP_NP2_DIAG_EEPROM_SNAPSHOT_BYTES 84U

enum {
    XE_NP_NP2_DIAG_CHAIN_SHANK0 = 0,
    XE_NP_NP2_DIAG_CHAIN_SHANK1 = 1,
    XE_NP_NP2_DIAG_CHAIN_SHANK2 = 2,
    XE_NP_NP2_DIAG_CHAIN_SHANK3 = 3,
    XE_NP_NP2_DIAG_CHAIN_BASE_EVEN = 4,
    XE_NP_NP2_DIAG_CHAIN_BASE_ODD = 5
};

/* Open Ephys' GenerateShankBits mapping for the normal 1,280-electrode NP2
 * shank: odd electrodes count down from 642; even count up from 645. The
 * endpoint assertions pin the guide's numbering before byte serialization. */
#define XE_NP_NP2_DIAG_ODD_BIT(electrode) (642U-((uint32_t)(electrode)/2U))
#define XE_NP_NP2_DIAG_EVEN_BIT(electrode) (645U+((uint32_t)(electrode)/2U))
_Static_assert(XE_NP_NP2_DIAG_EVEN_BIT(0U)==645U,"NP2 guide even endpoint");
_Static_assert(XE_NP_NP2_DIAG_ODD_BIT(1U)==642U,"NP2 guide odd endpoint");
_Static_assert(XE_NP_NP2_DIAG_EVEN_BIT(382U)==836U,"NP2 guide even limit");
_Static_assert(XE_NP_NP2_DIAG_ODD_BIT(383U)==451U,"NP2 guide odd limit");

static inline uint32_t XE_NP_Np2Diag_ElectrodeBit(uint32_t electrode)
{
    return (electrode&1U) ? XE_NP_NP2_DIAG_ODD_BIT(electrode) : XE_NP_NP2_DIAG_EVEN_BIT(electrode);
}

/* The wire image is MSB-first within each byte. Only shank 0 electrodes
 * 0..383 are enabled; all other shanks, tip references and external-reference
 * switches remain zero. GND reference/all channels active is represented by
 * the known 0x11 base image for both parity chains. */
static inline uint8_t XE_NP_Np2DiagChainByte(uint32_t physical_chain,uint32_t index)
{
    if(physical_chain==XE_NP_NP2_DIAG_CHAIN_BASE_EVEN || physical_chain==XE_NP_NP2_DIAG_CHAIN_BASE_ODD)
        return index<XE_NP_NP2_DIAG_BASE_BYTES ? 0x11U : 0U;
    if(physical_chain!=XE_NP_NP2_DIAG_CHAIN_SHANK0 || index>=XE_NP_NP2_DIAG_SHANK_BYTES)return 0U;
    uint8_t value=0U;
    for(uint32_t electrode=0U;electrode<XE_NP_NP2_DIAG_CHANNELS;electrode++) {
        uint32_t bit=XE_NP_Np2Diag_ElectrodeBit(electrode);
        if(bit/8U==index)value|=(uint8_t)(1U<<(7U-(bit&7U)));
    }
    return value;
}

static inline int XE_NP_Np2Diag_SerialValid(const uint8_t serial_le[8])
{
    if(!serial_le)return 0;
    uint8_t any_nonzero=0U,any_not_ff=0U;
    for(uint32_t i=0U;i<8U;i++) { any_nonzero|=serial_le[i];any_not_ff|=(uint8_t)(serial_le[i]^0xFFU); }
    return any_nonzero!=0U && any_not_ff!=0U;
}

/* EEPROM string fields may contain factory data after their NUL/FF terminator.
 * Require only a printable, nonempty terminated prefix; never require the
 * unused tail to be all zero or all FF. */
static inline int XE_NP_Np2Diag_EepromStringValid(const uint8_t field[XE_NP_NP2_DIAG_EEPROM_STRING_BYTES])
{
    if(!field)return 0;
    for(uint32_t i=0U;i<XE_NP_NP2_DIAG_EEPROM_STRING_BYTES;i++) {
        if(field[i]==0U || field[i]==0xFFU)return i!=0U;
        if(field[i]<0x20U || field[i]>0x7EU)return 0;
    }
    return 0;
}

static inline int XE_NP_Np2Diag_PartNumberIs(const uint8_t field[XE_NP_NP2_DIAG_EEPROM_STRING_BYTES],const char part[7])
{
    if(!field || !part)return 0;
    for(uint32_t i=0U;i<6U;i++)if(field[i]!=(uint8_t)part[i])return 0;
    return field[6]==0U || field[6]==0xFFU;
}

/* This is an identity gate, not an EEPROM writer: both independently read
 * snapshots must be byte-identical, have a plausible serial and printable
 * terminated fields, and identify a supported standard four-shank probe. */
static inline int XE_NP_Np2DiagIdentityKnown(const uint8_t first[XE_NP_NP2_DIAG_EEPROM_SNAPSHOT_BYTES],
                                              const uint8_t second[XE_NP_NP2_DIAG_EEPROM_SNAPSHOT_BYTES])
{
    if(!first || !second)return 0;
    for(uint32_t i=0U;i<XE_NP_NP2_DIAG_EEPROM_SNAPSHOT_BYTES;i++)if(first[i]!=second[i])return 0;
    if(!XE_NP_Np2Diag_SerialValid(&first[0x00U]) ||
       !XE_NP_Np2Diag_EepromStringValid(&first[0x20U]) ||
       !XE_NP_Np2Diag_EepromStringValid(&first[0x40U]))return 0;
    return XE_NP_Np2Diag_PartNumberIs(&first[0x40U],"NP2013") ||
           XE_NP_Np2Diag_PartNumberIs(&first[0x40U],"NP2014");
}

#endif
