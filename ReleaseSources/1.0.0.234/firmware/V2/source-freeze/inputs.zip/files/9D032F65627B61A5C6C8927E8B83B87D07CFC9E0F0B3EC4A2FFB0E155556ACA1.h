#ifndef XE_NP_IMU_GRID_RUNTIME_H
#define XE_NP_IMU_GRID_RUNTIME_H
#include "xe_np_imu_grid_queue.h"
#include "imu_grid_schedule.h"
#include <stdint.h>

/* Inactive prototype; no transport, NP capture, timer activation, or format
 * integration is implied. One owner initializes/controls it in foreground;
 * the timer IRQ is the sole producer and one foreground reader is consumer.
 * Never initialize/reuse while timer or a previous consumer is active. */
typedef struct {
    uint32_t state,counter_faults,scheduler_faults,late_copies,accepted;
    uint32_t queue_dropped,terminal_known;
    uint64_t scheduler_missing,terminal_exclusive,start_before,start_after;
} XE_NP_GridRuntimeStatus;
/* The first successfully queued grid copy only.  before/after are the real
 * 1 MHz copy bracket, not an ADC conversion or NP STARTBYTE timestamp. */
typedef struct {
    uint64_t ordinal,before,after;
    uint32_t domain,generation,epoch;
    volatile uint32_t valid;
} XE_NP_GridRuntimeFirstAccepted;
typedef struct {
    XE_NP_ImuGridQueue queue;
    XE_NP_GridSchedule schedule;
    volatile uint32_t state,counter_faults,scheduler_faults,late_copies,accepted;
    uint32_t domain,generation,epoch,max_lateness;
    uint64_t terminal_exclusive,start_before,start_after;
    uint32_t terminal_known;
    XE_NP_GridRuntimeFirstAccepted first_accepted;
} XE_NP_GridRuntime;
void XE_NP_GridRuntime_Init(XE_NP_GridRuntime *r);
/* The caller must hold an already bound 1 MHz HSE clock, qualify it at the
 * lifecycle boundary, prevent reclocking and preserve the same domain until
 * Stop. A grid ordinal is only relative until an owner proves its NP phase. */
int XE_NP_GridRuntime_Prepare(XE_NP_GridRuntime *r,uint32_t domain,
    uint32_t generation,uint32_t epoch,uint32_t max_lateness_us);
int XE_NP_GridRuntime_Start(XE_NP_GridRuntime *r,uint64_t first_ordinal);
/* cutoff_valid only when the owner has an independently proven inclusive
 * terminal cutoff on the same counter/domain; otherwise terminal is unknown.
 * A queued sample dropped by the ring is separate from scheduler_missing. */
void XE_NP_GridRuntime_Stop(XE_NP_GridRuntime *r,int cutoff_valid,uint64_t cutoff_us);
/* Foreground observed a clock/timer ownership failure. Stop accepting grid
 * rows immediately; the caller finishes/drains the provider separately. */
void XE_NP_GridRuntime_ClockFault(XE_NP_GridRuntime *r);
int XE_NP_GridRuntime_Pop(XE_NP_GridRuntime *r,XE_NP_ImuGridSlot *out);
void XE_NP_GridRuntime_GetStatus(XE_NP_GridRuntime *r,XE_NP_GridRuntimeStatus *out);
/* Foreground-only atomic snapshot.  A zero return means no successful queue
 * publication occurred for this prepared run. */
int XE_NP_GridRuntime_GetFirstAccepted(XE_NP_GridRuntime *r,
    XE_NP_GridRuntimeFirstAccepted *out);
#endif
