#ifndef XE_NP_NP2_EP81_HEADROOM_DIAG_H
#define XE_NP_NP2_EP81_HEADROOM_DIAG_H

#include <stdint.h>

/* Default-off lab trace.  Callers supply existing observations; this module
 * never reads a clock, DMA, producer, or USB register. */
#ifndef XE_NP_NP2_EP81_HEADROOM_DIAG
#define XE_NP_NP2_EP81_HEADROOM_DIAG 0U
#endif

enum {
    XE_NP_EP81_HEADROOM_MAGIC=0x31384448U, /* HD81 */
    XE_NP_EP81_HEADROOM_SUBMIT_CAPACITY=128U,
    XE_NP_EP81_HEADROOM_COMPLETE_CAPACITY=128U,
    XE_NP_EP81_HEADROOM_PRODUCER_CAPACITY=32U,
    XE_NP_EP81_HEADROOM_FLAG_UNKNOWN=1U,
    XE_NP_EP81_HEADROOM_FLAG_SATURATED=2U,
    XE_NP_EP81_HEADROOM_FLAG_SEGMENT_FIRST=4U,
    XE_NP_EP81_HEADROOM_FLAG_SEGMENT_SECOND=8U,
    XE_NP_EP81_HEADROOM_FLAG_BLOCK_INDEX_ROLLOVER=16U,
    XE_NP_EP81_HEADROOM_FLAG_BLOCK_INDEX_EPOCH_UNKNOWN=32U
};

/* ordinal is committed last. raw_tick is caller-supplied HAL_GetTick() ms:
 * device-relative ordering only, never RTC/NP/IMU phase. block_index is
 * zero-based and is the sole host correlation key. `depth` is USB blocks in
 * submit/complete rings and conservative ceil(bytes/128) producer backlog in
 * the current 8-bit geometry; UNKNOWN/SATURATED make either explicit. */
typedef struct {
    uint32_t ordinal;
    uint32_t raw_tick;
    uint32_t block_index;
    uint16_t depth;
    uint8_t state;
    uint8_t flags;
} XE_NP_Ep81HeadroomRecord;

/* retained reaches capacity once and survives ordinal wrap.  `overwritten`
 * therefore counts replacement records monotonically (until saturation).
 * ROLLOVER/EPOCH_UNKNOWN state that the 32-bit block index alone is not a
 * full 64-bit identity. SEGMENT_FIRST/SECOND tag a split USB transfer. */
typedef struct {
    uint32_t next_ordinal;
    uint32_t next_slot; /* physical cursor; independent of ordinal rollover */
    uint32_t retained,overwritten;
} XE_NP_Ep81HeadroomRingState;

typedef struct {
    uint32_t magic,version;
    uint32_t tick_hz; /* 1000 for HAL_GetTick milliseconds */
    uint32_t producer_sample_calls;
    XE_NP_Ep81HeadroomRingState submit_state,complete_state,producer_state;
    XE_NP_Ep81HeadroomRecord submit[XE_NP_EP81_HEADROOM_SUBMIT_CAPACITY];
    XE_NP_Ep81HeadroomRecord complete[XE_NP_EP81_HEADROOM_COMPLETE_CAPACITY];
    XE_NP_Ep81HeadroomRecord producer[XE_NP_EP81_HEADROOM_PRODUCER_CAPACITY];
    XE_NP_Ep81HeadroomRecord first_fault;
} XE_NP_Ep81HeadroomDiag;

#if XE_NP_NP2_EP81_HEADROOM_DIAG
extern volatile XE_NP_Ep81HeadroomDiag xe_np_ep81_headroom_diag;
/* Reset only while producer and EP81 ownership are idle.  Each Record API has
 * one writer context: producer capture, EP81 submit, or EP81 completion.
 * Writers do payload, DMB, ordinal; readers inspect stopped ownership only. */
void XE_NP_Ep81HeadroomDiag_Reset(void);
void XE_NP_Ep81HeadroomDiag_Ep81Submit(uint32_t raw_tick,uint32_t block_index,
                                       uint16_t depth,uint8_t state,uint8_t flags);
void XE_NP_Ep81HeadroomDiag_Ep81Complete(uint32_t raw_tick,uint32_t block_index,
                                         uint16_t depth,uint8_t state,uint8_t flags);
/* Caller samples once per eight producer IRQs; this function never scans. */
void XE_NP_Ep81HeadroomDiag_ProducerSample(uint32_t raw_tick,uint32_t block_index,
                                           uint16_t backlog128,uint8_t state,uint8_t flags);
void XE_NP_Ep81HeadroomDiag_ProducerFault(uint32_t raw_tick,uint32_t block_index,
                                          uint16_t backlog128,uint8_t state,uint8_t flags);
#else
#define XE_NP_Ep81HeadroomDiag_Reset() do {} while(0)
#define XE_NP_Ep81HeadroomDiag_Ep81Submit(...) do {} while(0)
#define XE_NP_Ep81HeadroomDiag_Ep81Complete(...) do {} while(0)
#define XE_NP_Ep81HeadroomDiag_ProducerSample(...) do {} while(0)
#define XE_NP_Ep81HeadroomDiag_ProducerFault(...) do {} while(0)
#endif

#endif
