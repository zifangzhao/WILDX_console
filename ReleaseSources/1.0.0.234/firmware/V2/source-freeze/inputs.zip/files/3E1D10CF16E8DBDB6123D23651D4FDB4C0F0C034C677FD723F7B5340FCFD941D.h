#ifndef XE_NP_NP2_RECORD_H
#define XE_NP_NP2_RECORD_H
#include "xe_np_np2_acquisition.h"
#if (XE_NP_NP2_SINGLE_LANE_3BIT != 0U)
#define XE_NP_NP2_RECORD_VERSION 10U
#define XE_NP_NP2_RECORD_STORED_BITS 3U
#define XE_NP_NP2_RECORD_CODEC 4U
#define XE_NP_NP2_RECORD_FLAGS 56U /* no payload CRC, host sync check, no header CRC */
#define XE_NP_NP2_RECORD_APPLICATION_CRC 0U
#else
#define XE_NP_NP2_RECORD_VERSION 8U
#define XE_NP_NP2_RECORD_STORED_BITS 6U
#define XE_NP_NP2_RECORD_CODEC 2U
#define XE_NP_NP2_RECORD_FLAGS 0U
#define XE_NP_NP2_RECORD_APPLICATION_CRC 1U
#endif
#define XE_NP_NP2_RECORD_CHUNK 65536U
#define XE_NP_NP2_RECORD_PAYLOAD XE_NP_NP2_CHUNK_PACKED_BYTES
#define XE_NP_NP2_RECORD_TICKS XE_NP_NP2_CHUNK_INPUT_TICKS
#define XE_NP_NP2_RECORD_RU 524288U
#define XE_NP_NP2_RECORD_MAX_RUS 3U
/* Six-wire 64 KiB source spans produce 48 KiB; the single-lane build
 * produces 24 KiB. Keep the generic sink contract wide enough for both. */
#define XE_NP_NP2_RECORD_CRC_MAX_BYTES 49152U
_Static_assert(XE_NP_NP2_RECORD_PAYLOAD==XE_NP_NP2_CHUNK_PACKED_BYTES,"NP2 packed payload geometry changed");
_Static_assert(XE_NP_NP2_RECORD_TICKS==XE_NP_NP2_CHUNK_INPUT_TICKS,"NP2 source geometry changed");
_Static_assert(XE_NP_NP2_RECORD_RU==8U*XE_NP_NP2_RECORD_CHUNK,"NP2 requires whole 8-chunk RUs");
enum {XE_NP_NP2_REC_EMPTY=0,XE_NP_NP2_REC_CONFIG,XE_NP_NP2_REC_RUNNING,
      XE_NP_NP2_REC_DRAINING,XE_NP_NP2_REC_FINALIZE,XE_NP_NP2_REC_COMPLETE,XE_NP_NP2_REC_FAILED};
enum {XE_NP_NP2_REC_ARGUMENT=1,XE_NP_NP2_REC_SOURCE,XE_NP_NP2_REC_SINK,
      XE_NP_NP2_REC_TIMEOUT,XE_NP_NP2_REC_CHECKSUM,XE_NP_NP2_REC_CANCELLED};
enum {XE_NP_NP2_RU_FREE=0,XE_NP_NP2_RU_FILLING,XE_NP_NP2_RU_READY,XE_NP_NP2_RU_INFLIGHT};
typedef struct {
    void *user;
    /* Nonblocking: zero means accepted, negative means terminal failure.
     * Buffer remains immutable until poll returns 1. SD: DMA AND card-ready;
     * USB: every byte handed off without reuse. Neither proves media durability. */
    int (*submit)(void *,const uint8_t *,uint32_t bytes,uint32_t first_sequence);
    int (*poll)(void *); /* 0 busy, 1 completed, negative failure; never replay */
    void (*abort)(void *); /* synchronous cancellation; releases DMA/USB ownership */
    /* Legacy-v8 incremental reflected IEEE CRC32, same as
     * zlib.crc32(data,previous),
     * initial previous=0. Called only on newly packed immutable private bytes,
     * <=49152 bytes/call. Must return 0 on success. A target may use exclusive
     * hardware CRC; software tests do not qualify its live cost/implementation.
     * The v10 performance profile leaves this NULL and relies on SDMMC's native
     * command/data CRC plus host sequence/source/SuperSync validation. */
    int (*crc32)(void *,uint32_t previous,const uint8_t *,uint32_t,uint32_t *result);
    uint32_t (*now_ms)(void *);
    /* Nonblocking raw-status check: zero healthy, negative terminal fault.
     * Checked before confirming config and each RUNNING/DRAINING service,
     * including when no RU is in flight. No card commands or busy waits. */
    int (*healthy)(void *);
    /* Optional free-running core-cycle counter.  It is diagnostics only and
     * must not be used for deadlines or correctness decisions. */
    uint32_t (*cycles)(void *);
} XE_NP_Np2RecordIo;
typedef struct {
    uint8_t *data;
    uint32_t state,first_sequence,chunks,fill,crc;
    uint64_t source_start,source_end;
} XE_NP_Np2RecordRu;
typedef struct {
    XE_NP_Np2Acquisition *acquisition;
    XE_NP_Np2RecordIo io;
    XE_NP_Np2RecordRu ru[XE_NP_NP2_RECORD_MAX_RUS];
    uint8_t descriptor[512],footer[512];
    uint32_t start_lba,end_lba,header_sectors,next_sequence,committed_chunks;
    uint32_t write_since_ms,max_write_ms,max_pack_ms,max_pack_cycles,write_timeout_ms;
    uint64_t first_source,packed_end,committed_end;
    /* writer and filler cache the only INFLIGHT/FILLING RU.  They are never
     * advisory: every use rechecks the corresponding RU state.  This keeps
     * the high-frequency recording service from scanning three RUs before
     * every 48 MHz source-span pack. */
    uint8_t state,error,stop_requested,source_stopped,writer,filler,finalize_ready,ru_count;
} XE_NP_Np2Record;
/* CONFIG_READY acquisition, fresh record, exclusive 32-byte-aligned 512KiB RUs.
 * SD: reserved start>=8192, 8192-aligned; end whole 16384-sector AU.
 * USB: start/end zero. No card accesses here and no implied reservation.
 * Caller persists/transfers descriptor and config before ConfirmConfig. */
int XE_NP_Np2Record_Begin(XE_NP_Np2Record *,XE_NP_Np2Acquisition *,const XE_NP_Np2RecordIo *,
                         uint8_t *ru0,uint8_t *ru1,uint32_t start_lba,uint32_t end_lba,uint32_t timeout_ms);
/* SD-only extended buffering. The additional RU absorbs bounded card-control
 * busy tails; it does not change the 512 KiB Video Speed Class write unit. */
int XE_NP_Np2Record_Begin3(XE_NP_Np2Record *,XE_NP_Np2Acquisition *,const XE_NP_Np2RecordIo *,
                          uint8_t *ru0,uint8_t *ru1,uint8_t *ru2,
                          uint32_t start_lba,uint32_t end_lba,uint32_t timeout_ms);
int XE_NP_Np2Record_ConfirmConfig(XE_NP_Np2Record *,uint32_t session_id,uint32_t config_crc);
/* One bounded pack, one completion poll, at most one new submit per call.
 * Caller owns Service; no interrupt may reenter it or modify its state. */
void XE_NP_Np2Record_Service(XE_NP_Np2Record *);
void XE_NP_Np2Record_Stop(XE_NP_Np2Record *); /* finish current whole RU, then drain */
void XE_NP_Np2Record_Abort(XE_NP_Np2Record *);
void XE_NP_Np2Record_SinkFailed(XE_NP_Np2Record *); /* including failed footer/directory persistence */
/* Caller persists/verifies footer only after finalize_ready and source stop.
 * Successful COMPLETE requires actual sink finalization, then the legacy CRC
 * value for v8 or an explicitly zero application-CRC field for v10. FAILED
 * evidence may be saved, but cannot be confirmed complete. */
int XE_NP_Np2Record_ConfirmFinalized(XE_NP_Np2Record *,uint32_t footer_crc);
#endif
