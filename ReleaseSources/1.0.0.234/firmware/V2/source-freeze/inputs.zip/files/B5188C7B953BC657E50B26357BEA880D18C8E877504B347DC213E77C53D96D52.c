#include "CE32_system.h"
#include "CE32_UART_INTERCOM.h"
#include "dataMGR.h"
#include "xe_np_legacy_fs.h"
#include "xe_np_sensors_port.h"

#include <string.h>

#define CE32_LOG_UPDATE_PERIOD_MS 10000U

static uint32_t CE32_LegacyFs_MapError(uint16_t error_ID)
{
    switch(error_ID)
    {
        case CE32_FILE_ERROR_ADDR:
        case CE32_FILE_ERROR_CARDFULL:
            return CE32_ERRORID_SD_CARDFULL;

        case CE32_FILE_ERROR_NOCARD:
            return CE32_ERRORID_SD_NOTPRESENT;

        case CE32_FILE_ERROR_FORMATERR:
            return CE32_ERRORID_SD_FORMATERR;

        case CE32_FILE_ERROR_WRITE:
        case CE32_FILE_ERROR_READ:
        case CE32_FILE_ERROR_CARDBUSY:
        case CE32_FILE_ERROR_TRANSERR:
        case CE32_FILE_ERROR_OVR:
        default:
            return CE32_ERRORID_SD_ERR;
    }
}

volatile uint8_t ce32_log_update_pending = 0U;
uint8_t ACC_buf_raw[20] = {0};
uint16_t ACC_value[10] = {0};
uint8_t ACC_buf[8] = {0};
static uint16_t ce32_adc_buf[256] = {0};
static uint32_t ce32_next_log_update_tick = 0U;
static volatile uint16_t ce32_legacy_fs_error_id = 0U;

void CE32_INTERCOM_TX_EnqueueCmd_Act(CE32_INTERCOM_Handle *handle_IC)
{
    (void)CE32_INTERCOM_TX_Start_DMA(handle_IC);
}

void CE32_INTERCOM_TX_restart(CE32_INTERCOM_Handle *handle_IC)
{
    CE32_INTERCOM_UART_TX_DMA_Init(handle_IC);
    (void)CE32_INTERCOM_TX_Start_DMA(handle_IC);
}

void CE32_File_FileStream_InitAct(void)
{
    XE_NP_LegacyFs_RefreshMetadata();
}

void CE32_File_FileStream_PreLoadAct(void)
{
    XE_NP_LegacyFs_RefreshMetadata();
}

void CE32_File_FileStream_PostLoadAct(void)
{
    XE_NP_LegacyFs_RefreshMetadata();
}

void CE32_File_FileStream_RecInitAct(void)
{
    XE_NP_LegacyFs_RefreshMetadata();
    ce32_legacy_fs_error_id = 0U;
    ce32_log_update_pending = 0U;
    ce32_next_log_update_tick = HAL_GetTick() + CE32_LOG_UPDATE_PERIOD_MS;
}

void CE32_File_FileStream_PreStartAct(void)
{
    XE_NP_LegacyFs_RefreshMetadata();
}

void CE32_File_FileStream_StartAct(void)
{
    XE_NP_LegacyFs_RefreshMetadata();
    ce32_legacy_fs_error_id = 0U;
    if(fs.sysParam != NULL)
    {
        fs.sysParam->system_status |= MGR_SYS_RECORDING;
    }

    if(ADC_handle.fs > 0U)
    {
        (void)CE32_ADC_StartDMA(&ADC_handle);
    }

    ce32_log_update_pending = 0U;
    ce32_next_log_update_tick = HAL_GetTick() + CE32_LOG_UPDATE_PERIOD_MS;
}

void CE32_File_FileStream_StopAct(void)
{
    if(ADC_handle.hadc != NULL)
    {
        (void)CE32_ADC_Stop(&ADC_handle);
    }

    if(fs.sysParam != NULL)
    {
        fs.sysParam->system_status &= ~(MGR_SYS_RECORDING | MGR_SYS_PREVIEW);
    }

    ce32_log_update_pending = 0U;
    ce32_next_log_update_tick = HAL_GetTick() + CE32_LOG_UPDATE_PERIOD_MS;
}

void CE32_File_FileStream_ErrorAct(uint16_t error_ID)
{
    ce32_legacy_fs_error_id = error_ID;
    if(fs.sysParam != NULL)
    {
        CE32_ReportError(fs.sysParam, CE32_LegacyFs_MapError(error_ID));
    }
}

void HAL_I2C_MemRxCpltCallback(I2C_HandleTypeDef *hi2c)
{
    if(XE_NP_SensorsPort_Complete(hi2c,0U))return;
    if((ACC_handle.hi2c != NULL) && (hi2c == ACC_handle.hi2c))
    {
        memcpy(ACC_value, ACC_buf_raw, sizeof(ACC_buf_raw));
        CE32_IMU_BMX160_RX_IT_Callback(&ACC_handle);
        CE32_SWI_TRIG(CE32_SWI_IRQ_IMU);
    }
}

void HAL_I2C_MemTxCpltCallback(I2C_HandleTypeDef *hi2c)
{
    (void)XE_NP_SensorsPort_Complete(hi2c,0U);
}

__weak void CE32_SWI_TRIG(int IRQn)
{
    (void)IRQn;
}

void CE32_IMU_PreInitAct(void)
{
    if(ACC_handle.hi2c == NULL)
    {
        return;
    }

    (void)HAL_I2C_DeInit(ACC_handle.hi2c);
    (void)HAL_I2C_Init(ACC_handle.hi2c);
}

void CE32_SystemCompat_InitLegacyAdc(ADC_HandleTypeDef *hadc, uint32_t sample_rate_hz)
{
    if(hadc == NULL)
    {
        return;
    }

    (void)CE32_ADC_Init(
        &ADC_handle,
        hadc,
        NULL,
        NULL,
        sample_rate_hz,
        1U,
        (uint8_t *)ce32_adc_buf,
        (uint16_t)sizeof(ce32_adc_buf));
}

void CE32_SystemCompat_Service(void)
{
    uint32_t now_tick = HAL_GetTick();

    XE_NP_LegacyFs_RefreshMetadata();

    if((XE_NP_LegacyFs_IsActive() == 0) || (fs.enabled == 0U))
    {
        ce32_log_update_pending = 0U;
        ce32_next_log_update_tick = now_tick + CE32_LOG_UPDATE_PERIOD_MS;
        return;
    }

    if(ce32_next_log_update_tick == 0U)
    {
        ce32_next_log_update_tick = now_tick + CE32_LOG_UPDATE_PERIOD_MS;
    }

    if((int32_t)(now_tick - ce32_next_log_update_tick) >= 0)
    {
        ce32_log_update_pending = 1U;
        do
        {
            ce32_next_log_update_tick += CE32_LOG_UPDATE_PERIOD_MS;
        } while((int32_t)(now_tick - ce32_next_log_update_tick) >= 0);
    }
}

uint16_t CE32_SystemCompat_GetLegacyFsError(void)
{
    return ce32_legacy_fs_error_id;
}

void CE32_SystemCompat_ClearLegacyFsError(void)
{
    ce32_legacy_fs_error_id = 0U;
}
