#ifndef XE_NP_NP2_GRID16_RUNTIME_H
#define XE_NP_NP2_GRID16_RUNTIME_H
#include "xe_np_imu_grid_provider.h"

/* Caller supplies a bounded foreground check of the current HSE-derived
 * 1 MHz clock and the complete given context. This is an endpoint check,
 * not proof of uninterrupted clock continuity between checks. */
typedef int (*XE_NP_Grid16Qualify)(void *context,const XE_NP_GridWireContext *identity);
typedef struct {
    XE_NP_GridRuntime runtime;
    XE_NP_GridProvider provider;
    XE_NP_GridWireContext identity;
    XE_NP_Grid16Qualify qualify;
    void *qualify_context;
    uint8_t started,attached,stopped,fault;
} XE_NP_Grid16Runtime;

/* One foreground owner, allocated outside stack/capture buffers. Init only
 * a fresh object, never while the timer or claimed provider record is owned. */
void XE_NP_Grid16Runtime_Init(XE_NP_Grid16Runtime *owner);
int XE_NP_Grid16Runtime_Start(XE_NP_Grid16Runtime *owner,const XE_NP_GridWireContext *identity,
    XE_NP_Grid16Qualify qualify,void *qualify_context,uint64_t first_ordinal);
/* receipt/anchor are real already-validated NP-first evidence. Continuous
 * clock and copy-bound flags are independent caller-proven assertions; an
 * endpoint check alone is not continuous-clock proof. */
int XE_NP_Grid16Runtime_Attach(XE_NP_Grid16Runtime *owner,const uint8_t *receipt,uint32_t receipt_bytes,
    const uint8_t *anchor,uint32_t anchor_bytes,uint64_t base_ordinal,
    uint32_t continuous_clock_qualified,uint32_t copy_bound_qualified);
/* Caller invokes Next only for an admitted batch. 1 claims immutable data,
 * 0 means unavailable, 2 means incomplete, -1 invalid/fault. Complete is
 * mandatory once per claim, including failed delivery; no blind replay. */
int XE_NP_Grid16Runtime_Next(XE_NP_Grid16Runtime *owner,uint8_t *body,uint32_t capacity,
    uint32_t *type,uint32_t *bytes,uint64_t *source);
/* Foreground SD tail hint: flush available partial rows; do not stop timer or emit END. */
int XE_NP_Grid16Runtime_NextPartial(XE_NP_Grid16Runtime *owner,uint8_t *body,uint32_t capacity,
    uint32_t *type,uint32_t *bytes,uint64_t *source);
void XE_NP_Grid16Runtime_Complete(XE_NP_Grid16Runtime *owner,uint32_t type,uint32_t delivered);
/* Foreground only before source-clock invalidation; no cutoff is inferred.
 * Draining proceeds after stop without reading a now-retired clock. */
void XE_NP_Grid16Runtime_Stop(XE_NP_Grid16Runtime *owner);
/* True only after timer retirement and terminal delivery (or failed attach
 * with no provider claim). Incomplete/aborted ownership stays pinned. */
int XE_NP_Grid16Runtime_CanReuse(const XE_NP_Grid16Runtime *owner);
#endif
