#ifndef XE_NP_SD_WRITE_TRACE_H
#define XE_NP_SD_WRITE_TRACE_H
#include <stdint.h>
#ifndef XE_NP_SD_WRITE_TRACE_ENABLE
#define XE_NP_SD_WRITE_TRACE_ENABLE 0U
#endif
#ifndef XE_NP_SD_FAILURE_TRACE_ENABLE
#define XE_NP_SD_FAILURE_TRACE_ENABLE 0U
#endif
#if (XE_NP_SD_FAILURE_TRACE_ENABLE!=0U && XE_NP_SD_FAILURE_TRACE_ENABLE!=1U) || \
    (XE_NP_SD_FAILURE_TRACE_ENABLE && \
     (!defined(STM32U595xx) || XE_NP_IMAGE_ROLE!=1U || \
      !XE_NP_NP2_LIVE_SD_ENABLE || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
      !XE_NP_NP2_LIVE_SD_OVERFLOW_FAULT_DIAG || XE_NP_SD_WRITE_TRACE_ENABLE || \
      XE_NP_NP2_LIVE_SD_FAULT_SD_PINS_TEST))
#error "Failure-only SD trace requires the U595 APP's existing overflow fault storage"
#endif
/* Private 64-byte SWD diagnostic ABI. Captured BEFORE IRQ cleanup changes
 * DCOUNT, response, flags or DMA ownership. CYCCNT deltas wrap naturally. */
typedef struct {
    uint32_t sequence,block,bytes,start_cycles,command_cycles,irq_cycles;
    uint32_t status,dcount,idmactrl,response,dctrl,command,mask,command_error;
    uint32_t irq_seen,clock;
} XE_NP_SdWriteTrace;

#if XE_NP_SD_FAILURE_TRACE_ENABLE
/* Private SDFT v1 overlays 29 words of the existing 56-word fault receipt.
 * Kind1=data IRQ,2=command response timeout,3=command CRC,4=software timeout.
 * First failure wins, including a pre-existing source-fault receipt. Normal
 * IRQ/command completion never calls this helper. STA supplies FIFO flags:
 * never read the payload FIFO or chase an IDMA-supplied address here. */
extern volatile uint32_t xe_np_np2_overflow_fault_diag[56];
/* Spare words41..44 retain the last pre-CMD13 STA/CMD/PLL-ready witness until
 * first failure. Words45..49/55 tag the failure-time RCC snapshot. Old frozen
 * HAL DATA receipts have no CLK1 tag; never interpret their spare words as RCC.
 * No payload command, buffer, deadline or interrupt policy changes here. */
static __attribute__((noinline,unused)) void XE_NP_SdCaptureCommandStart(SDMMC_TypeDef *s)
{
    volatile uint32_t *d=xe_np_np2_overflow_fault_diag;
    if(s!=SDMMC1 || d[2])return;
    d[42]=s->STA;d[43]=s->CMD;d[44]=RCC->CR;
    __DMB();d[41]=0x50524331U; /* PRC1; caller is pre-CMD13 only. */
}
static __attribute__((noinline,unused)) void XE_NP_SdCaptureFailure(
    SDMMC_TypeDef *s,uint32_t kind,uint32_t flags)
{
    volatile uint32_t *d=xe_np_np2_overflow_fault_diag;
    if(s!=SDMMC1 || d[2])return;
    d[0]=0x53444654U;d[1]=1U;d[3]=kind;d[4]=flags;d[5]=DWT->CYCCNT;
    d[6]=s->STA;d[7]=s->CMD;d[8]=s->ARG;d[9]=s->RESPCMD;d[10]=s->RESP1;
    d[11]=s->DCOUNT;d[12]=s->DLEN;d[13]=s->DCTRL;d[14]=s->CLKCR;
    d[15]=s->POWER;d[16]=s->DTIMER;d[17]=s->ACKTIME;d[18]=s->IDMACTRL;
    d[19]=s->IDMABSIZE;d[20]=s->IDMABASER;d[21]=s->IDMALAR;d[22]=s->IDMABAR;
    d[23]=s->MASK;d[24]=GPIOC->IDR;d[25]=GPIOD->IDR;d[26]=GPIOB->IDR;
    d[27]=__get_PRIMASK();d[28]=__get_BASEPRI();
    d[45]=RCC->CR;d[46]=RCC->PLL2CFGR;d[47]=RCC->PLL2DIVR;
    d[48]=RCC->CCIPR2;d[49]=RCC->AHB2ENR1;d[55]=0x434C4B31U; /* CLK1. */
    __DMB();d[2]=1U;
}
#endif
#endif
