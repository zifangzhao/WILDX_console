#include "xe_np_np2_grid16_idma.h"
#include <string.h>

static uint32_t grid16_owner_mask(const XE_NP_Np2Grid16IdmaPlan *plan)
{return (1U<<plan->owner_count)-1U;}

int XE_NP_Np2Grid16Idma_Build(uint32_t first_lba,uint32_t group_count,uint32_t aux_sectors,
                               XE_NP_Np2Grid16IdmaPlan *out)
{
    uint32_t group_sectors,node=0U,lba=first_lba;
    if(!out || !group_count || group_count>XE_NP_NP2_GRID16_GROUPS ||
       !aux_sectors || aux_sectors>XE_NP_NP2_GRID16_MAX_AUX_SECTORS)return -1;
    group_sectors=XE_NP_NP2_GRID16_NN_SECTORS+aux_sectors;
    if(group_sectors<XE_NP_NP2_GRID16_NN_SECTORS ||
       first_lba>UINT32_MAX-group_count*group_sectors)return -1;
    memset(out,0,sizeof(*out));
    out->first_lba=first_lba;out->aux_sectors=aux_sectors;
    out->owner_count=(uint8_t)group_count;
    for(uint32_t owner=0U;owner<group_count;owner++){
        static const uint32_t nn_sectors[XE_NP_NP2_GRID16_NN_NODES]={127U,127U,110U};
        uint32_t source=0U;
        for(uint32_t i=0U;i<XE_NP_NP2_GRID16_NN_NODES;i++){
            XE_NP_Np2Grid16IdmaNode *n=&out->node[node++];
            n->lba=lba;n->source_offset=source;n->bytes=nn_sectors[i]*512U;
            n->owner=(uint8_t)owner;n->kind=XE_NP_NP2_GRID16_KIND_NN;
            lba+=nn_sectors[i];source+=n->bytes;
        }
        XE_NP_Np2Grid16IdmaNode *aux=&out->node[node++];
        aux->lba=lba;aux->source_offset=0U;
        aux->bytes=aux_sectors*512U;aux->owner=(uint8_t)owner;
        aux->kind=XE_NP_NP2_GRID16_KIND_AUX;lba+=aux_sectors;
    }
    out->node_count=(uint8_t)node;out->total_sectors=lba-first_lba;
    out->total_bytes=out->total_sectors*512U;out->end_lba=lba;
    return node==group_count*4U && out->owner_count<=XE_NP_NP2_GRID16_MAX_OWNERS?0:-1;
}

void XE_NP_Np2Grid16Idma_Begin(const XE_NP_Np2Grid16IdmaPlan *plan,
                               XE_NP_Np2Grid16IdmaState *out)
{
    (void)plan;
    if(out)memset(out,0,sizeof(*out));
}

int XE_NP_Np2Grid16Idma_Btc(const XE_NP_Np2Grid16IdmaPlan *plan,
                             XE_NP_Np2Grid16IdmaState *state,uint32_t node_index,
                             uint32_t *retired_owner)
{
    uint32_t owner,last;
    if(retired_owner)*retired_owner=UINT32_MAX;
    if(!plan || !state || state->ready_committed || node_index!=state->next_btc_node ||
       node_index>=plan->node_count)return -1;
    owner=plan->node[node_index].owner;
    if(owner>=plan->owner_count)return -1;
    state->next_btc_node++;
    last=(owner+1U)*4U-1U;
    if(node_index==last){
        state->source_retired_mask|=(uint8_t)(1U<<owner);
        if(retired_owner)*retired_owner=owner;
        return 1;
    }
    return 0;
}

int XE_NP_Np2Grid16Idma_CommitReady(const XE_NP_Np2Grid16IdmaPlan *plan,
                                     XE_NP_Np2Grid16IdmaState *state)
{
    if(!plan || !state || state->ready_committed || state->next_btc_node!=plan->node_count ||
    state->source_retired_mask!=grid16_owner_mask(plan))return -1;
    state->committed_mask=(uint8_t)grid16_owner_mask(plan);
    state->committed_end_lba=plan->end_lba;state->ready_committed=1U;
    return 0;
}
