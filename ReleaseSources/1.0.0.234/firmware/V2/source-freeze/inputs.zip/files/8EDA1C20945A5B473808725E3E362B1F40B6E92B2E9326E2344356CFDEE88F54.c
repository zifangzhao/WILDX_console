/* Deliberately not the NP1 application. The resident V2 transport service
 * retains its diagnostic ABI, but every legacy acquisition entry is closed.
 * Link this INSTEAD OF xe_np_app.c; NP2 owns a distinct source/wire protocol. */
#include "xe_np_app.h"
#include <string.h>
const XE_NP_Runtime *XE_NP_App_GetRuntime(void){return 0;}
void XE_NP_App_GetBleNameDiag(XE_NP_AppBleNameDiag *p){memset(p,0,sizeof(*p));}
void XE_NP_App_GetBleControlDiag(XE_NP_AppBleControlDiag *p){memset(p,0,sizeof(*p));}
int XE_NP_App_BleVendorFrame(const uint8_t *p,uint32_t n){(void)p;(void)n;return -1;}
XE_NP_CapturePort *XE_NP_App_GetCapturePortForUsb(uint8_t p){(void)p;return 0;}
int XE_NP_App_StartUsbCapture(uint8_t p){(void)p;return -1;}
void XE_NP_App_StopUsbCapture(void){}
int XE_NP_App_SetRuntimeMcoDivider(uint32_t d){(void)d;return -1;}
int XE_NP_App_IsUsbCaptureReady(uint8_t p){(void)p;return 0;}
int XE_NP_App_EnableUsbWindowExport(uint8_t p){(void)p;return -1;}
void XE_NP_App_DisableUsbWindowExport(void){}
int XE_NP_App_DequeueUsbCaptureWindowLimited(uint8_t p,XE_NP_AppUsbCaptureWindow *w,uint32_t n)
{(void)p;(void)w;(void)n;return -1;}
int XE_NP_App_DequeueUsbCaptureWindowForDma(uint8_t p,XE_NP_AppUsbCaptureWindow *w,uint32_t n)
{(void)p;(void)w;(void)n;return -1;}
int XE_NP_App_IsUsbInterleavedCapture(void){return 0;}
int XE_NP_App_IsUsbQuadInterleavedCapture(void){return 0;}
int XE_NP_App_IsUsbQuadInterleavedCaptureConfigured(void){return 0;}
uint32_t XE_NP_App_GetUsbRecordingFault(uint8_t p){(void)p;return 0;}
int XE_NP_App_CheckUsbCaptureWindow(uint8_t p,const XE_NP_AppUsbCaptureWindow *w){(void)p;(void)w;return -1;}
uint32_t XE_NP_App_CopyUsbInterleavedLanePayload(uint8_t *p,uint32_t n,uint8_t *l){(void)p;(void)n;(void)l;return 0;}
uint32_t XE_NP_App_CopyUsbQuadInterleavedLanePayload(uint8_t *p,uint32_t n,uint8_t *l){(void)p;(void)n;(void)l;return 0;}
int XE_NP_App_BeginUsbQuadDmaBatch(uint32_t n,XE_NP_AppUsbQuadDmaBatch *b){(void)n;(void)b;return -1;}
int XE_NP_App_CommitUsbQuadDmaBatch(const XE_NP_AppUsbQuadDmaBatch *b){(void)b;return -1;}
void XE_NP_App_CancelUsbQuadDmaBatch(void){}
int XE_NP_App_BeginUsbInterleavedDmaBatch(uint32_t n,uint32_t m,XE_NP_AppUsbInterleavedDmaBatch *b){(void)n;(void)m;(void)b;return -1;}
int XE_NP_App_CommitUsbInterleavedDmaBatch(const XE_NP_AppUsbInterleavedDmaBatch *b){(void)b;return -1;}
void XE_NP_App_CancelUsbInterleavedDmaBatch(void){}
uint32_t XE_NP_App_GetUsbInterleavedExportDebug(void){return 0;}
void XE_NP_App_ReleaseUsbActiveWindow(uint8_t p){(void)p;}
uint32_t XE_NP_App_GetUsbWindowPendingBytes(uint8_t p){(void)p;return 0;}
void XE_NP_App_GetUsbExportDiag(uint8_t p,XE_NP_AppUsbExportDiag *d){(void)p;memset(d,0,sizeof(*d));}
void XE_NP_App_GpioeDmaIrqHandler(void){}
void XE_NP_App_PssiIrqHandler(void){}
void XE_NP_App_GpiodDmaIrqHandler(void){}
void XE_NP_App_SpiTapDmaIrqHandler(void){}
void XE_NP_App_Spi1IrqHandler(void){}
void XE_NP_App_SdStageDmaIrqHandler(void){}
void XE_NP_App_SdLinkedListNodeComplete(SD_HandleTypeDef *h){(void)h;}
int XE_NP_App_IsRawSdSinkActive(void){return 0;}
