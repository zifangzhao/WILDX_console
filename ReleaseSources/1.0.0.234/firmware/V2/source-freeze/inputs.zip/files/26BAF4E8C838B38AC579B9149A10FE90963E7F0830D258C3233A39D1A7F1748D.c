#include "xe_np_np2_sd_fine_clock.h"
#include "xe_np_np2_first_sync_runtime.h"
#if XE_NP_NP2_FIRST_SYNC_ENABLE
#include "xe_np_np2_first_sync_sd.h"
#include "xe_np_np2_capture_port.h"
#include "xe_np_sensors_port.h"
#include "xe_np_usb_aux.h"
#include "main.h"
/* One explicitly named CPU-only workspace; the software link comparison must
 * account for it without moving any fixed neural/capture/DMA reservation. */
typedef struct {
    XE_NP_Np2FirstSyncPort port;
    XE_NP_Np2FirstSyncSdContext sd;
    NpFirstSyncBinding binding;
    uint64_t token;
    uint32_t mode,nonce,session,mask,hz;
    uint8_t active,aux_mask;
} NpFirstRuntime;
#if defined(_MSC_VER)
static NpFirstRuntime runtime;
#else
static NpFirstRuntime runtime __attribute__((section("NP_FIRST_CPU"),aligned(8)));
#endif
enum {FIRST_MODE_NONE=0U,FIRST_MODE_USB=1U,FIRST_MODE_SD=2U};
static void idle(void){}
static void (*service)(void)=idle;
static void freeze_pending(void);
static int owner(void *user,NpFirstSyncBinding *b,XE_NP_Np2FirstSyncPoint *p)
{
    XE_NP_AcquisitionAnchor a;(void)user;
    if(!runtime.active || !runtime.binding.generation || !XE_NP_Np2CapturePort_Armed() ||
       !XE_NP_Np2CapturePort_GetAnchor(&a) || (a.flags&0xFF0DU)!=0x020DU ||
       a.generation!=runtime.binding.generation || a.sample_hz!=runtime.hz ||
       a.source_hz!=runtime.hz*1600U)return 0;
    *b=runtime.binding;
    if(runtime.binding.domain){
        XE_NP_Np2SdFinePoint point;
        if((a.flags&0xFF1FU)!=0x021FU || !XE_NP_Np2SdFineClock_Read(&point) ||
           point.domain!=runtime.binding.domain || point.counter_hz!=runtime.binding.counter_hz ||
           point.generation!=a.generation || point.source_epoch!=runtime.binding.source_epoch)return 0;
        p->domain=point.domain;p->ms=point.ms;p->cycles=point.counter;return 1;
    }
    p->domain=0U;p->ms=HAL_GetTick();p->cycles=UINT32_MAX;return 1;
}
static void opened(void *user,XE_NP_Np2FirstSyncGate *gate,const NpFirstSyncBinding *b)
{
    XE_NP_Np2FirstSyncPoint p={0U,HAL_GetTick(),UINT32_MAX};(void)user;
    if(!XE_NP_Np2FirstSyncGate_Open(gate,b))return;
    for(uint32_t id=1U;id<=4U;id++)if(runtime.aux_mask&(1U<<(id-1U)))
        (void)XE_NP_Np2FirstSyncGate_Release(gate,b,id,&p);
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
    if(runtime.aux_mask&1U)XE_NP_SensorsPort_FirstSyncRelease(gate);
#endif
#if XE_NP_V2_AUX_ENABLE
    if(runtime.mode==FIRST_MODE_USB)XE_NP_UsbAux_FirstSyncRelease(gate);
#endif
    service=freeze_pending;freeze_pending();
}
static void freeze_pending(void)
{
    if(!runtime.active){service=idle;return;}
    XE_NP_Np2FirstSyncGate *gate=&runtime.port.gate;
    if(!gate->receipt.session)return;
    if(XE_NP_Np2FirstSyncGate_Freeze(gate,&runtime.binding,HAL_GetTick(),!gate->bound))service=idle;
}
static void runtime_legacy(void)
{
    XE_NP_Np2SdFineClock_Invalidate();
    XE_NP_Np2FirstSyncPort_Invalidate();service=idle;runtime.active=0U;runtime.mode=FIRST_MODE_NONE;
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
    XE_NP_SensorsPort_FirstSyncLegacy();
#endif
#if XE_NP_V2_AUX_ENABLE
    XE_NP_UsbAux_FirstSyncLegacy();
#endif
}
void XE_NP_Np2FirstSyncRuntime_Init(void)
{
    XE_NP_Np2FirstSyncPort_Invalidate();memset(&runtime,0,sizeof(runtime));service=idle;
#if XE_NP_NP2_DUAL_SD_APP_ENABLE
    XE_NP_Np2FirstSyncSd_Bind(&runtime.sd);
#endif
    runtime_legacy();
}
void XE_NP_Np2FirstSyncRuntime_SdPrepare(uint32_t nonce,uint32_t session,uint32_t mask,uint32_t hz)
{
#if XE_NP_NP2_DUAL_SD_APP_ENABLE
    const XE_NP_Np2FirstSyncSdContext *r=XE_NP_Np2FirstSyncSd_Record();
    runtime_legacy();memset(&runtime.port,0,sizeof(runtime.port));memset(&runtime.binding,0,sizeof(runtime.binding));
    if(!r || r->retired || r->nonce!=nonce || !r->token || !session)return;
    runtime.mode=FIRST_MODE_SD;runtime.active=1U;runtime.nonce=nonce;runtime.token=r->token;
    runtime.session=session;runtime.mask=mask;runtime.hz=hz;
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE && XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE
    runtime.aux_mask=1U;
#else
    runtime.aux_mask=0U;
#endif
#else
    (void)nonce;(void)session;(void)mask;(void)hz;runtime_legacy();
#endif
}
int XE_NP_Np2FirstSyncRuntime_SdOpted(void)
{return runtime.active && runtime.mode==FIRST_MODE_SD;}
static int armed(void)
{
    XE_NP_AcquisitionAnchor a;
    if(!runtime.active || !XE_NP_Np2CapturePort_Armed() || !XE_NP_Np2CapturePort_GetAnchor(&a) ||
       (a.flags&0xFF0DU)!=0x020DU || !a.generation || a.sample_hz!=runtime.hz || a.source_hz!=runtime.hz*1600U)return 0;
    runtime.binding=(NpFirstSyncBinding){runtime.mode==FIRST_MODE_USB?a.generation:runtime.session,
        a.generation,a.generation,0U,0U,UINT32_MAX,2U,runtime.mask,runtime.hz};
    XE_NP_Np2SdFinePoint point;
    if((a.flags&0xFF1FU)==0x021FU && XE_NP_Np2SdFineClock_Read(&point) &&
       point.generation==a.generation && point.source_epoch==a.generation &&
       point.counter_hz==a.counter_hz){
        runtime.binding.domain=point.domain;runtime.binding.counter_hz=point.counter_hz;
    }
#if XE_NP_NP2_DUAL_SD_APP_ENABLE
    if(runtime.mode==FIRST_MODE_SD && !XE_NP_Np2FirstSyncSd_Capture(runtime.nonce,runtime.session,
        a.generation,a.generation,UINT32_MAX))return 0;
#endif
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
    if(runtime.aux_mask&1U)XE_NP_SensorsPort_FirstSyncWait();
#endif
#if XE_NP_V2_AUX_ENABLE
    if(runtime.mode==FIRST_MODE_USB)XE_NP_UsbAux_FirstSyncWait();
#endif
    if(!XE_NP_Np2FirstSyncPort_Bind(&runtime.port,owner,opened,NULL,runtime.aux_mask,runtime.binding.domain!=0U))return 0;
    service=freeze_pending;return 1;
}
void XE_NP_Np2FirstSyncRuntime_SdArmed(void)
{if(XE_NP_Np2FirstSyncRuntime_SdOpted() && !armed())runtime_legacy();}
int XE_NP_Np2FirstSyncRuntime_UsbArmed(uint64_t token,uint32_t mask,uint32_t hz,uint8_t aux)
{
    runtime_legacy();memset(&runtime.port,0,sizeof(runtime.port));memset(&runtime.binding,0,sizeof(runtime.binding));
    if(!token)return 1; /* Explicit legacy path never inherits a prior gate. */
    runtime.mode=FIRST_MODE_USB;runtime.active=1U;runtime.token=token;runtime.mask=mask;runtime.hz=hz;runtime.aux_mask=aux;
    if(armed())return 1;runtime_legacy();return 0;
}
void XE_NP_Np2FirstSyncRuntime_Stop(void)
{
    if(!runtime.active || !runtime.binding.generation)return;
    if(!runtime.port.gate.receipt.session)
        (void)XE_NP_Np2FirstSyncGate_Begin(&runtime.port.gate,&runtime.binding,runtime.aux_mask,0);
    (void)XE_NP_Np2FirstSyncGate_Freeze(&runtime.port.gate,&runtime.binding,HAL_GetTick(),1);service=idle;
}
void XE_NP_Np2FirstSyncRuntime_Service(void){service();}
void XE_NP_Np2FirstSyncRuntime_AuxAccepted(uint32_t id,uint64_t counter,uint8_t bits,uint32_t rn,uint32_t rd)
{
    XE_NP_Np2FirstSyncGate *gate=&runtime.port.gate;NpFirstSyncAux a={0};
    if(!runtime.active || gate->frozen || id<1U || id>4U || (gate->aux_seen&(1U<<(id-1U))) ||
       !XE_NP_Np2FirstSyncGate_Open(gate,&runtime.binding))return;
    a.id=(uint8_t)id;a.flags=NP_FIRST_AUX_ENABLED|NP_FIRST_AUX_COUNTER;a.counter_bits=bits;a.counter=counter;
    a.rate_num=rn;a.rate_den=rd;a.release_ms=a.release_cycles=a.first_ms=a.first_cycles=UINT32_MAX;a.offset_num=INT64_MIN;
    if(XE_NP_Np2FirstSyncGate_RecordAux(gate,&runtime.binding,&a,0U))freeze_pending();
}
const uint8_t *XE_NP_Np2FirstSyncRuntime_FrozenUsb(uint64_t token)
{
    return runtime.active && runtime.mode==FIRST_MODE_USB && token && token==runtime.token?
        XE_NP_Np2FirstSyncGate_Frozen(&runtime.port.gate):NULL;
}
void XE_NP_Np2FirstSyncRuntime_SdTime(uint8_t sector[512])
{
#if XE_NP_NP2_DUAL_SD_APP_ENABLE
    const XE_NP_Np2FirstSyncSdContext *r=XE_NP_Np2FirstSyncSd_Record();
    const uint8_t *wire=XE_NP_Np2FirstSyncGate_Frozen(&runtime.port.gate);
    const uint32_t uid[3]={HAL_GetUIDw0(),HAL_GetUIDw1(),HAL_GetUIDw2()};
    if(!sector || !XE_NP_Np2FirstSyncRuntime_SdOpted() || !r || !wire || r->token!=runtime.token || r->nonce!=runtime.nonce ||
       r->current.session!=runtime.binding.session || r->current.generation!=runtime.binding.generation ||
       r->current.source_epoch!=runtime.binding.source_epoch || np_first_u32(wire+16)!=runtime.binding.session ||
       np_first_u32(wire+20)!=runtime.binding.generation || np_first_u32(wire+24)!=runtime.binding.source_epoch)return;
    /* One existing foreground metadata write, never a neural/data-path write.
     * Failure preserves the old validated sector and cannot stop recording. */
    (void)np_first_sd_sector_bind(sector,sector,wire,2U,uid,runtime.token);
#else
    (void)sector;
#endif
}
#endif

#if XE_NP_NP2_FIRST_SYNC_ENABLE
int XE_NP_Np2FirstSyncRuntime_SdClockBegin(void)
{
    return XE_NP_Np2FirstSyncRuntime_SdOpted() && runtime.nonce &&
        XE_NP_Np2SdFineClock_Start(runtime.nonce,0U,0U);
}
int XE_NP_Np2FirstSyncRuntime_SdFineAnchor(uint8_t out[64])
{
    XE_NP_AcquisitionAnchor a;
    if(!out || !XE_NP_Np2FirstSyncRuntime_SdOpted() || !runtime.binding.domain ||
       !XE_NP_Np2CapturePort_GetAnchor(&a) || (a.flags&0xFF1FU)!=0x021FU ||
       a.generation!=runtime.binding.generation || a.counter_hz!=runtime.binding.counter_hz ||
       a.source_hz!=runtime.hz*1600U || a.sample_hz!=runtime.hz)return 0;
    XE_NP_AcquisitionAnchor_Reply(&a,runtime.binding.domain,out);return 1;
}
#endif
