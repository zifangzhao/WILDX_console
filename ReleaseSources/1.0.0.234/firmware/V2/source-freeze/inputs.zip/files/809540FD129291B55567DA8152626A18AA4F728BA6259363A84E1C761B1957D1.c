#include "xe_np_np2_first_sync_sd.h"
#if XE_NP_NP2_FIRST_SYNC_ENABLE
#include "xe_np_hal.h"
#include "xe_np_np2_sd_control.h"
#include <string.h>

static XE_NP_Np2FirstSyncSdContext *bound;

static void uid(uint32_t out[3])
{out[0]=HAL_GetUIDw0();out[1]=HAL_GetUIDw1();out[2]=HAL_GetUIDw2();}
static int request(const uint8_t in[64],uint32_t actual[3])
{uid(actual);return np_first_u32(in)==NP_FIRST_SD_REQUEST && np_first_sd_request_valid(in,64U,2U,actual);}
static void pack(uint8_t out[64],const uint8_t in[64],uint32_t result,uint32_t supported,
                 uint32_t features,uint32_t session,uint32_t generation,uint32_t epoch,uint32_t profile)
{
    NpFirstSdReply r={result,supported,features,session,generation,epoch,profile};
    (void)np_first_sd_reply_pack(out,in,2U,&r);
}
static void failure(uint8_t out[64],const uint8_t in[64],uint32_t result)
{pack(out,in,result,0U,0U,0U,0U,0U,UINT32_MAX);}

void XE_NP_Np2FirstSyncSd_Bind(XE_NP_Np2FirstSyncSdContext *context)
{bound=context;}

const NpFirstSdReply *XE_NP_Np2FirstSyncSd_Current(void)
{return bound && bound->current_valid?&bound->current:NULL;}
const XE_NP_Np2FirstSyncSdContext *XE_NP_Np2FirstSyncSd_Record(void)
{return bound && bound->current_valid?bound:NULL;}

void XE_NP_Np2FirstSyncSd_AcceptedLegacyStart(uint32_t nonce)
{
    if(!bound || !nonce)return;
    if(bound->bridge_active && bound->nonce==nonce)return;
    /* Preserve historical ACK bytes for a harmless exact duplicate, but never
     * let an ordinary legacy Start attach to the prior NPSD record. */
    bound->current_valid=0U;bound->token=0U;bound->nonce=0U;
    memset(&bound->current,0,sizeof(bound->current));
}

void XE_NP_Np2FirstSyncSd_CancelStart(uint32_t nonce)
{
    if(bound && bound->current_valid && !bound->current.session && bound->nonce==nonce){
        bound->current_valid=0U;bound->token=0U;bound->nonce=0U;
        memset(&bound->current,0,sizeof(bound->current));
    }
}

void XE_NP_Np2FirstSyncSd_AcceptedLegacyStop(uint32_t nonce)
{
    if(bound && bound->current_valid && (int32_t)(nonce-bound->nonce)>0){
        if(bound->current.session){bound->retired=1U;return;}
        bound->current_valid=0U;bound->token=0U;bound->nonce=0U;
        memset(&bound->current,0,sizeof(bound->current));
    }
}

int XE_NP_Np2FirstSyncSd_Capture(uint32_t nonce,uint32_t session,uint32_t generation,
                                  uint32_t source_epoch,uint32_t profile_crc)
{
    if(!bound || !bound->current_valid || bound->retired || bound->nonce!=nonce || !session || !generation || !source_epoch)return 0;
    bound->current.session=session;bound->current.generation=generation;
    bound->current.source_epoch=source_epoch;bound->current.profile_crc=profile_crc;
    return 1;
}

int XE_NP_Np2FirstSyncSd_Exchange(const uint8_t in[64],uint8_t out[64])
{
    uint32_t actual[3],op,id,legacy[16],error,pending_before;
    if(!in || !out || np_first_u32(in)!=NP_FIRST_SD_REQUEST)return 0;
    memset(out,0,64U);uid(actual);
    if(!np_first_sd_request_valid(in,64U,2U,actual)){return 1;}
    op=np_first_u16(in+6);id=np_first_u32(in+8);
    if(op==NP_FIRST_SD_CAPS){
        if(!bound)failure(out,in,NP_FIRST_SD_UNSUPPORTED);
        else pack(out,in,NP_FIRST_SD_OK,NP_FIRST_SD_FEATURE_SYNC|NP_FIRST_SD_FEATURE_SCHEDULED|NP_FIRST_SD_FEATURE_FINE_CLOCK,
                  0U,0U,0U,0U,UINT32_MAX);
        return 1;
    }
    if(!bound){failure(out,in,NP_FIRST_SD_UNSUPPORTED);return 1;}
    if(op==NP_FIRST_SD_STATUS){
        if(!bound->current_valid || bound->token!=np_first_u64(in+24))failure(out,in,NP_FIRST_SD_NOT_FOUND);
        else pack(out,in,NP_FIRST_SD_OK,NP_FIRST_SD_FEATURE_SYNC|NP_FIRST_SD_FEATURE_SCHEDULED|NP_FIRST_SD_FEATURE_FINE_CLOCK,
                  NP_FIRST_SD_FEATURE_SYNC,bound->current.session,bound->current.generation,
                  bound->current.source_epoch,bound->current.profile_crc);
        return 1;
    }
    if(np_first_sd_cached_duplicate(in,bound->accepted,2U,actual)){memcpy(out,bound->ack,64U);return 1;}
    if(!np_first_sd_fresh_start(in,64U,2U,actual,bound->token) ||
       (bound->history_valid && np_first_u32(bound->accepted+8)==id)){failure(out,in,NP_FIRST_SD_INVALID);return 1;}
    if(!np_first_sd_unwrap((uint8_t *)legacy,in,2U,actual)){failure(out,in,NP_FIRST_SD_INVALID);return 1;}
    /* A cached legacy reply with this ID is not evidence that this wrapper
     * admitted a new record.  It may still describe an older pending START. */
    pending_before=XE_NP_Np2SdControl_PendingStart();
    bound->bridge_active=1U;error=XE_NP_Np2SdControl_Exchange((const uint8_t *)legacy,out)?NP_FIRST_SD_ERROR:np_first_u32(out+16);
    bound->bridge_active=0U;
    if(error || pending_before==id || XE_NP_Np2SdControl_PendingStart()!=id){failure(out,in,error==2U?NP_FIRST_SD_BUSY:NP_FIRST_SD_ERROR);return 1;}
    bound->token=np_first_u64(in+24);bound->nonce=id;bound->current_valid=1U;bound->retired=0U;
    bound->current=(NpFirstSdReply){NP_FIRST_SD_OK,NP_FIRST_SD_FEATURE_SYNC|NP_FIRST_SD_FEATURE_SCHEDULED|NP_FIRST_SD_FEATURE_FINE_CLOCK,
        NP_FIRST_SD_FEATURE_SYNC,0U,0U,0U,UINT32_MAX};
    memcpy(bound->accepted,in,64U);pack(bound->ack,in,NP_FIRST_SD_OK,
        NP_FIRST_SD_FEATURE_SYNC|NP_FIRST_SD_FEATURE_SCHEDULED|NP_FIRST_SD_FEATURE_FINE_CLOCK,NP_FIRST_SD_FEATURE_SYNC,0U,0U,0U,UINT32_MAX);
    bound->history_valid=1U;memcpy(out,bound->ack,64U);return 1;
}
#endif
