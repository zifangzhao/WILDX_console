#ifndef XE_NP_IMU_GRID_QUEUE_H
#define XE_NP_IMU_GRID_QUEUE_H
#include <stdint.h>

/* Private SPSC handoff only; this is not an on-disk or USB wire format.
 * One producer (the eventual slot IRQ) and one foreground consumer. Reset
 * only when both are quiescent. The caller supplies a real slot ordinal and
 * an immutable snapshot for the entire Push call. Never synthesize a slot. */
#ifndef XE_NP_IMU_GRID_CAPACITY
#define XE_NP_IMU_GRID_CAPACITY 128U
#endif
#if XE_NP_IMU_GRID_CAPACITY < 2U || (XE_NP_IMU_GRID_CAPACITY & (XE_NP_IMU_GRID_CAPACITY-1U)) || XE_NP_IMU_GRID_CAPACITY > 0x80000000UL
#error "Grid queue capacity must be a power of two in the unambiguous SPSC range"
#endif
#define XE_NP_IMU_GRID_AG_VALID 0x01U
#define XE_NP_IMU_GRID_MAG_VALID 0x02U
#define XE_NP_IMU_GRID_AG_REPEAT 0x04U
#define XE_NP_IMU_GRID_MAG_REPEAT 0x08U
#define XE_NP_IMU_GRID_ERROR 0x10U

typedef struct {
    uint64_t ordinal;
    int32_t values[9]; /* accel micro-g, gyro milli-dps, mag nano-tesla */
    uint32_t flags;
} XE_NP_ImuGridSlot;

typedef struct {
    XE_NP_ImuGridSlot slots[XE_NP_IMU_GRID_CAPACITY];
    volatile uint32_t head,tail;
    volatile uint32_t dropped;
    uint32_t last_ag_sequence,last_mag_sequence,last_valid;
} XE_NP_ImuGridQueue;

void XE_NP_ImuGridQueue_Reset(XE_NP_ImuGridQueue *queue);
/* Push takes only cached values. No I2C, timing read, allocation or retry.
 * Both sequences are from the same coherent published snapshot. Valid uses
 * only AG_VALID/MAG_VALID; error is nonzero for an IMU communication error.
 * The ordinal is independent of queue occupancy and phase representation. */
int XE_NP_ImuGridQueue_Push(XE_NP_ImuGridQueue *queue,uint64_t ordinal,
    const int32_t accel[3],const int32_t gyro[3],const int32_t mag[3],
    uint32_t ag_sequence,uint32_t mag_sequence,uint32_t valid,uint32_t error);
int XE_NP_ImuGridQueue_Pop(XE_NP_ImuGridQueue *queue,XE_NP_ImuGridSlot *out);
#endif
