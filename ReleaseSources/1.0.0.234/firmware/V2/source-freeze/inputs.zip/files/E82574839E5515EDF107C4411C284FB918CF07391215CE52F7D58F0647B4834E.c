#include "dataMGR.h"

#include <string.h>

void CE32_ReportError(CE32_systemParam *sysParam, unsigned long error_code)
{
    if(sysParam == NULL)
    {
        return;
    }

    sysParam->error_code |= (uint32_t)error_code;
}

void dataMGR_init(dataMGR *mgr, char *dataPtr, unsigned long dataSize)
{
    uint32_t i;

    if(mgr == NULL)
    {
        return;
    }

    mgr->dataPtr = dataPtr;
    mgr->dataSize = dataSize;
    mgr->ptr_mask = (dataSize > 0U) ? (dataSize - 1U) : 0U;
    mgr->inPTR = 0U;
    mgr->DMA_RX_NDTR = NULL;
    mgr->DMA_TX_NDTR = NULL;
    mgr->logState = 0U;
    mgr->sysState = 0U;
    mgr->activeOutMask = (1UL << CE32_OUTPTR_COUNT) - 1UL;

    for(i = 0U; i < CE32_OUTPTR_COUNT; ++i)
    {
        mgr->outPTR[i] = 0U;
        mgr->bufferUsed[i] = 0U;
        mgr->bufferMAX[i] = 0U;
    }
}

void dataMGR_init_DMA(dataMGR *mgr, char *dataPtr, unsigned long dataSize, __IO uint32_t *dma_rx_ndtr, __IO uint32_t *dma_tx_ndtr)
{
    dataMGR_init(mgr, dataPtr, dataSize);
    if(mgr == NULL)
    {
        return;
    }

    mgr->DMA_RX_NDTR = dma_rx_ndtr;
    mgr->DMA_TX_NDTR = dma_tx_ndtr;
}

void dataMGR_init_515B(dataMGR *mgr, char *dataPtr, unsigned long dataSize)
{
    unsigned long count;
    unsigned long size;
    unsigned long i;

    if(mgr == NULL)
    {
        return;
    }

    count = dataSize / 515U;
    size = 515U * count;
    dataMGR_init(mgr, dataPtr, size);
    mgr->inPTR = 1U;

    for(i = 0U; i < count; ++i)
    {
        mgr->dataPtr[i * 515U] = (char)0xFC;
    }
}

void dataMGR_IncNrec(CE32_systemLog *sysLog)
{
    if((sysLog != NULL) && (sysLog->Nrec < CE32_SYSTEM_LOG_CAPACITY))
    {
        sysLog->Nrec++;
    }
}

void syslog_init(CE32_systemLog *sysLog, unsigned int *filePTR)
{
    if((sysLog == NULL) || (filePTR == NULL))
    {
        return;
    }

    while((sysLog->Nrec > 1U) && (sysLog->log[sysLog->Nrec - 1U] < (LOG_ADDR + 1U)))
    {
        sysLog->Nrec--;
    }

    dataMGR_IncNrec(sysLog);
    if(sysLog->Nrec == 1U)
    {
        *filePTR = DATA_ADDR;
    }
    else
    {
        *filePTR = sysLog->log[sysLog->Nrec - 2U];
        if(*filePTR < (LOG_ADDR + 1U))
        {
            sysLog->Nrec = 1U;
            *filePTR = DATA_ADDR;
        }
    }
}

uint32_t largestPowerOf2(uint32_t n)
{
    if(n == 0U)
    {
        return 0U;
    }

    n |= (n >> 1U);
    n |= (n >> 2U);
    n |= (n >> 4U);
    n |= (n >> 8U);
    n |= (n >> 16U);
    return (n + 1U) >> 1U;
}
