#ifndef XE_NP_NP2_GRID16_IDMA_H
#define XE_NP_NP2_GRID16_IDMA_H

#include <stdint.h>

/* Pure SD16 planning: one to four immutable NN groups, each followed by one
 * bounded auxiliary sector span. The live writer supplies independent NN/AUX
 * DMA bases and owns cache maintenance, RU state, CMD25, and CMD13. */
enum {
    XE_NP_NP2_GRID16_GROUPS=4U,
    XE_NP_NP2_GRID16_NN_BYTES=186368U,
    XE_NP_NP2_GRID16_NN_SECTORS=364U,
    XE_NP_NP2_GRID16_NN_NODES=3U,
    XE_NP_NP2_GRID16_MAX_AUX_SECTORS=5U,
    XE_NP_NP2_GRID16_MAX_NODES=16U,
    XE_NP_NP2_GRID16_MAX_OWNERS=6U,
    XE_NP_NP2_GRID16_KIND_NN=1U,
    XE_NP_NP2_GRID16_KIND_AUX=2U
};

typedef struct {
    uint32_t lba;
    uint32_t source_offset;
    uint32_t bytes;
    uint8_t owner;
    uint8_t kind;
} XE_NP_Np2Grid16IdmaNode;

typedef struct {
    uint32_t first_lba;
    uint32_t end_lba; /* exclusive physical/card boundary */
    uint32_t aux_sectors;
    uint32_t total_sectors;
    uint32_t total_bytes;
    uint8_t owner_count;
    uint8_t node_count;
    XE_NP_Np2Grid16IdmaNode node[XE_NP_NP2_GRID16_MAX_NODES];
} XE_NP_Np2Grid16IdmaPlan;

typedef struct {
    uint8_t next_btc_node;
    uint8_t source_retired_mask;
    uint8_t committed_mask;
    uint8_t ready_committed;
    uint32_t committed_end_lba;
} XE_NP_Np2Grid16IdmaState;

/* Builds a contiguous physical LBA plan for an available prefix. aux_sectors
 * is per group and intentionally one node (the frozen K range is 1..5).
 * NN and AUX offsets are relative to separately owned source bases; node.kind
 * selects that base, so this helper never implies a concatenating copy. */
int XE_NP_Np2Grid16Idma_Build(uint32_t first_lba,uint32_t group_count,uint32_t aux_sectors,
                               XE_NP_Np2Grid16IdmaPlan *out);
void XE_NP_Np2Grid16Idma_Begin(const XE_NP_Np2Grid16IdmaPlan *plan,
                               XE_NP_Np2Grid16IdmaState *out);
/* Call in actual BTC/node retirement order. Returns nonzero only for the
 * owner whose complete NN+aux source is no longer read by IDMA. */
int XE_NP_Np2Grid16Idma_Btc(const XE_NP_Np2Grid16IdmaPlan *plan,
                             XE_NP_Np2Grid16IdmaState *state,uint32_t node_index,
                             uint32_t *retired_owner);
/* Call only after the enclosing CMD25 has a successful card-ready/CMD13
 * result. It commits the physical prefix; BTC alone never commits media. */
int XE_NP_Np2Grid16Idma_CommitReady(const XE_NP_Np2Grid16IdmaPlan *plan,
                                     XE_NP_Np2Grid16IdmaState *state);

#endif
