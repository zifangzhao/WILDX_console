#ifndef XE_NP_NP2_CLOSED_LOOP_CAPTURE_PROOF_H
#define XE_NP_NP2_CLOSED_LOOP_CAPTURE_PROOF_H
#ifndef XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
#define XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE 0U
#endif
#if XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
#include "xe_np_np2_closed_loop_carrier.h"
/* Oct20 copied-APP capture proof only. 1=current proof, 0=not proved,
 * including a NULL output. A failed query clears a non-NULL receipt, never
 * the NP producer.
 * Flags0x205 mean this capture's internal root/source/PSSI tick coordinates:
 * fresh zero counters + successful cold arm + unique initial SPI calibration
 * + the first retained source0 span. They do NOT add legacy GetAnchor, UTC,
 * wall-clock mapping or DWT-cycle validity. core_hz is a checked cold
 * SystemCoreClock snapshot. Session/timing fields remain zero for the caller
 * to bind to its actual SD owner. No SPI/PSSI configuration or payload work.
 * Getter is foreground-only, before the first closed-loop publication.
 * Epochs never wrap/reuse: exhaustion disables CL until a fresh boot. */
int XE_NP_Np2ClCaptureProof_Get(XE_NP_Np2ClStartupReceipt *out);
#endif
#endif
