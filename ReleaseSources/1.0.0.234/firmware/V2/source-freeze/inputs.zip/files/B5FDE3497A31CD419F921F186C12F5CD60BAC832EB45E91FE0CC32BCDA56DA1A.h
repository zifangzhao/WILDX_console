#ifndef XE_NP_NP2_FIRST_SYNC_GATE_H
#define XE_NP_NP2_FIRST_SYNC_GATE_H
#include <stdint.h>
#ifndef XE_NP_NP2_FIRST_SYNC_ENABLE
#define XE_NP_NP2_FIRST_SYNC_ENABLE 0U
#endif
#if XE_NP_NP2_FIRST_SYNC_ENABLE
#include "np_first_sync_wire.h"
#include "xe_np_np2_first_sync.h"
/* Startup/first-observation state only. The owner invalidates the cached live
 * gate on Stop/rearm/source loss; the capture receipt survives for its footer. */
typedef struct {uint32_t domain,ms,cycles;} XE_NP_Np2FirstSyncPoint;
typedef int (*XE_NP_Np2FirstSyncRetained)(void *);

typedef struct XE_NP_Np2FirstSyncGate {
    NpFirstSyncReceipt receipt;
    NpFirstSyncBinding binding;
    uint32_t imu_baseline[3],discovered_ms;
    uint8_t frozen_wire[NP_FIRST_SYNC_BYTES];
    XE_NP_Np2FirstSync staged_proof;
    XE_NP_Np2FirstSyncPoint staged_point;
    volatile uint8_t bound,live;
    uint8_t attempted,staged,released,aux_seen,imu_needed,imu_flushed,imu_ready,frozen;
} XE_NP_Np2FirstSyncGate;
enum {NP2_FIRST_EXCLUSION_PROVEN=1U,NP2_FIRST_SAMPLE_LOCK_PROVEN=2U};
/* Zero-initialized context; final generation/profile must come from its actual
 * admitted capture owner, never PREPARED, host arrival, or an arm-time guess. */
int XE_NP_Np2FirstSyncGate_Begin(XE_NP_Np2FirstSyncGate *,const NpFirstSyncBinding *,uint8_t aux_mask,int source_mapping);
/* Scan an accepted private view once, then publish proof only after the
 * owner's normal block commit. Retention runs after scanning and at commit;
 * it must not copy/prepare/release the neural source a second time. */
int XE_NP_Np2FirstSyncGate_Stage(XE_NP_Np2FirstSyncGate *,const NpFirstSyncBinding *,const uint8_t *,uint32_t,const XE_NP_Np2FirstSyncPoint *,XE_NP_Np2FirstSyncRetained,void *);
int XE_NP_Np2FirstSyncGate_Commit(XE_NP_Np2FirstSyncGate *,const NpFirstSyncBinding *,XE_NP_Np2FirstSyncRetained,void *);
int XE_NP_Np2FirstSyncGate_Prove(XE_NP_Np2FirstSyncGate *,const NpFirstSyncBinding *,const uint8_t *,uint32_t,const XE_NP_Np2FirstSyncPoint *);
int XE_NP_Np2FirstSyncGate_Open(const XE_NP_Np2FirstSyncGate *,const NpFirstSyncBinding *);
void XE_NP_Np2FirstSyncGate_Invalidate(XE_NP_Np2FirstSyncGate *);
int XE_NP_Np2FirstSyncGate_Release(XE_NP_Np2FirstSyncGate *,const NpFirstSyncBinding *,uint32_t id,const XE_NP_Np2FirstSyncPoint *);
/* A producer must attest exclusion/common phase separately. Foreground points
 * or a positive offset alone never grant physical sample0-lock. Once per AUX. */
int XE_NP_Np2FirstSyncGate_RecordAux(XE_NP_Np2FirstSyncGate *,const NpFirstSyncBinding *,const NpFirstSyncAux *,uint32_t producer_proof);
/* Logical archival freshness only: flush the first new observation after the
 * release baseline, then await another advancing observation for each needed
 * group. This does not establish independent sensor conversion phase/offset. */
void XE_NP_Np2FirstSyncGate_ImuBaseline(XE_NP_Np2FirstSyncGate *,const uint32_t sequence[3],uint8_t valid_groups);
int XE_NP_Np2FirstSyncGate_AllowImu(XE_NP_Np2FirstSyncGate *,const uint32_t sequence[3],uint8_t valid_groups);
/* Nonblocking metadata-only deadline: freeze once when every enabled AUX has
 * its first accepted record,1000ms after discovery, or immediately on Stop.
 * Live archival need not stop when metadata freezes; late metadata is unknown. */
int XE_NP_Np2FirstSyncGate_Freeze(XE_NP_Np2FirstSyncGate *,const NpFirstSyncBinding *,uint32_t now_ms,int stop);
const uint8_t *XE_NP_Np2FirstSyncGate_Frozen(const XE_NP_Np2FirstSyncGate *);
/* Stop/footer or an explicitly frozen transport only; never serialize per
 * recording block. Pending/unknown evidence remains explicit on the wire. */
int XE_NP_Np2FirstSyncGate_Pack(const XE_NP_Np2FirstSyncGate *,uint8_t out[NP_FIRST_SYNC_BYTES]);
#endif
#endif