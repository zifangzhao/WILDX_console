#include "xe_np_np2_closed_loop_carrier.h"
#if XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE && XE_NP_NP2_CLOSED_LOOP_WORKSPACE_ENABLE
#if defined(_MSC_VER)
__declspec(align(8)) XE_NP_Np2ClWorkspace xe_np_np2_closed_loop_workspace;
#else
XE_NP_Np2ClWorkspace xe_np_np2_closed_loop_workspace __attribute__((section("NP_CL_CPU"),aligned(8)));
#endif
void XE_NP_Np2ClRuntime_Ensure(void){XE_NP_Np2ClCarrier_PortBind(&xe_np_np2_closed_loop_workspace);}
#endif
