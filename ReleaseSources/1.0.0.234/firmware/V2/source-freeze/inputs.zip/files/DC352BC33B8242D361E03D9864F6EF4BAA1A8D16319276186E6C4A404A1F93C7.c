#include "xe_np_msc_bot.h"

uint8_t MSCInEpAdd = 0x81U;
uint8_t MSCOutEpAdd = 0x01U;
static XE_NP_MscBot *owner;
static int8_t inquiry[36] = {0,0x80,2,2,31,0,0,0,
    'W','I','L','D','X',' ',' ',' ', 'N','P','1',' ','S','D',' ','S','T','O','R','A','G','E',' ',' ',
    '0','0','0','1'};
static int8_t init(uint8_t lun) { return lun == 0U ? 0 : -1; }
static int8_t ready(uint8_t lun) { return lun == 0U && owner->bot.scsi_medium_state != SCSI_MEDIUM_EJECTED && owner->ops->ready(owner->context) ? 0 : -1; }
static int8_t capacity(uint8_t lun, uint32_t *n, uint16_t *size)
{
    if(ready(lun) != 0) { return -1; }
    *n = owner->ops->capacity(owner->context); *size = 512U;
    return *n != 0U ? 0 : -1;
}
static int8_t protected(uint8_t lun) { return lun != 0U || owner->ops->write_protected(owner->context) ? 1 : 0; }
static int range(uint32_t lba, uint32_t n)
{
    uint32_t count = owner->ops->capacity(owner->context);
    return ready(0) == 0 && lba <= count && n <= count-lba;
}
static int8_t read_blocks(uint8_t lun, uint8_t *dst, uint32_t lba, uint16_t n)
{
    return lun == 0U && range(lba,n) && owner->ops->read(owner->context,dst,lba,n) == 0 ? 0 : -1;
}
static int8_t write_blocks(uint8_t lun, uint8_t *src, uint32_t lba, uint16_t n)
{
    return !protected(lun) && range(lba,n) && owner->ops->write(owner->context,src,lba,n) == 0 ? 0 : -1;
}
static int8_t max_lun(void) { return 0; }
static USBD_StorageTypeDef storage = {init,capacity,ready,protected,read_blocks,write_blocks,max_lun,inquiry};

static void invalid_transfer(XE_NP_MscBot *m)
{
    m->errors++; m->reset_required = 1U; m->reset_seen = 0U; m->clear_mask = 0U;
    m->mode_pending = 0U; m->bot.bot_status = USBD_BOT_STATUS_ERROR;
    m->ops->stall(m->context,0x81); m->ops->stall(m->context,0x01);
}
void XE_NP_MscBot_Init(XE_NP_MscBot *m, const XE_NP_MscOps *ops, void *context)
{
    memset(m,0,sizeof(*m)); m->ops = ops; m->context = context;
    m->device.pClassDataCmsit[0] = &m->bot; m->device.pUserData[0] = &storage;
    m->device.pData = m; m->device.dev_speed = USBD_SPEED_HIGH; owner = m;
}
void XE_NP_MscBot_Configure(XE_NP_MscBot *m)
{
    owner = m; m->configured = 1U; m->reset_required = m->reset_seen = m->clear_mask = 0U;
    m->mode_pending = m->halt_mask = 0U; m->bot.max_lun = 0U;
    MSC_BOT_Init(&m->device);
}
void XE_NP_MscBot_Receive(XE_NP_MscBot *m, uint32_t bytes)
{
    owner = m;
    if(!m->configured || m->reset_required) { return; }
    if(!m->rx_armed || bytes != m->rx_expected || bytes > sizeof(m->rx_scratch) || !m->rx_destination) {
        invalid_transfer(m); return;
    }
    m->rx_armed=0U;
    memcpy(m->rx_destination,m->rx_scratch,bytes);
    m->rx_received = bytes;
    if(m->bot.bot_state == USBD_BOT_IDLE) { m->commands++; }
    MSC_BOT_DataOut(&m->device,1);
    if(m->bot.bot_status == USBD_BOT_STATUS_ERROR) { invalid_transfer(m); }
}
void XE_NP_MscBot_TransmitDone(XE_NP_MscBot *m)
{
    owner = m;
    if(!m->configured || m->reset_required || !m->tx_pending) { return; }
    m->tx_pending=0U;
    if(m->tx_is_csw && m->mode_pending) {
        m->mode_pending = 0U; m->ops->mode_ack(m->context);
    }
    if(m->tx_is_csw && m->rx_deferred) {
        m->rx_deferred=0U;
        m->rx_armed=m->ops->receive(m->context,m->rx_scratch,m->rx_expected)==0;
    }
    MSC_BOT_DataIn(&m->device,1);
}
void XE_NP_MscBot_ClassReset(XE_NP_MscBot *m)
{
    owner = m; m->mode_pending = 0U;
    m->tx_pending=m->rx_deferred=m->rx_armed=0U;
    m->reset_required = 1U; m->reset_seen = 1U; m->clear_mask = 0U;
    m->ops->flush(m->context,0x81); m->ops->flush(m->context,0x01);
    /* BOT reset recovery requires CLEAR_FEATURE on both bulk endpoints. */
}
void XE_NP_MscBot_ClearHalt(XE_NP_MscBot *m, uint8_t ep)
{
    owner = m;
    if(ep != 0x81 && ep != 0x01) { return; }
    if(m->reset_required) {
        if(!m->reset_seen) { m->ops->stall(m->context,ep); return; }
        m->ops->clear_stall(m->context,ep);
        m->clear_mask |= ep == 0x81 ? 1U : 2U;
        if(m->clear_mask == 3U) {
            uint8_t medium=m->bot.scsi_medium_state;
            XE_NP_MscBot_Configure(m);m->bot.scsi_medium_state=medium;
        }
    } else {
        uint8_t bit=ep==0x81?1U:2U, was_halted=m->halt_mask&bit;
        m->halt_mask&=(uint8_t)~bit;
        m->ops->clear_stall(m->context,ep);
        if(was_halted)MSC_BOT_CplClrFeature(&m->device,ep);
    }
}

USBD_StatusTypeDef USBD_LL_Transmit(USBD_HandleTypeDef *d, uint8_t ep, uint8_t *data, uint32_t n)
{
    XE_NP_MscBot *m = d->pData; (void)ep;
    if(m->tx_pending) { invalid_transfer(m); return USBD_FAIL; }
    m->tx_is_csw = n == USBD_BOT_CSW_LENGTH && data == (uint8_t *)&m->bot.csw;
    m->tx_pending=1U;
    if(m->ops->transmit(m->context,data,n) != 0) { m->tx_pending=0U;return USBD_FAIL; }
    return USBD_OK;
}
USBD_StatusTypeDef USBD_LL_PrepareReceive(USBD_HandleTypeDef *d, uint8_t ep, uint8_t *dst, uint32_t n)
{
    XE_NP_MscBot *m = d->pData; (void)ep;
    if(n > sizeof(m->rx_scratch)) { invalid_transfer(m); return USBD_FAIL; }
    m->rx_destination = dst; m->rx_expected = n;
    if(m->tx_pending && m->tx_is_csw) { m->rx_deferred=1U;return USBD_OK; }
    m->rx_armed=m->ops->receive(m->context,m->rx_scratch,n)==0;
    return m->rx_armed ? USBD_OK : USBD_FAIL;
}
uint32_t USBD_LL_GetRxDataSize(USBD_HandleTypeDef *d, uint8_t ep) { (void)ep; return ((XE_NP_MscBot *)d->pData)->rx_received; }
USBD_StatusTypeDef USBD_LL_StallEP(USBD_HandleTypeDef *d,uint8_t ep) { XE_NP_MscBot *m=d->pData; m->halt_mask|=ep==0x81?1U:2U;m->ops->stall(m->context,ep); return USBD_OK; }
USBD_StatusTypeDef USBD_LL_ClearStallEP(USBD_HandleTypeDef *d,uint8_t ep) { XE_NP_MscBot *m=d->pData; m->ops->clear_stall(m->context,ep); return USBD_OK; }
USBD_StatusTypeDef USBD_LL_FlushEP(USBD_HandleTypeDef *d,uint8_t ep) { XE_NP_MscBot *m=d->pData; m->ops->flush(m->context,ep); return USBD_OK; }

int8_t XE_NP_MscScsiExtension(USBD_HandleTypeDef *d,uint8_t lun,uint8_t *cmd)
{
    XE_NP_MscBot *m=d->pData; uint32_t bytes=64U;
    if(lun != 0U) { return -1; }
    m->bot.bot_data_length=0U;
    if(cmd[0] == 0x35 || cmd[0] == 0x91) {
        if(m->bot.cbw.dDataLength == 0U && m->ops->sync(m->context) == 0) { return 0; }
    } else if(cmd[0] == 0xC0 && memcmp(&cmd[2],"XENP",4) == 0) {
        for(uint32_t i=6;i<16;i++) { if(cmd[i] != 0U) { goto fail; } }
        if(cmd[1] == 0U) {
            if(m->bot.cbw.bmFlags != 0x80 || m->bot.cbw.dDataLength != 64U) { goto fail; }
            if(m->ops->control(m->context,0,m->bot.bot_data,&bytes) == 0 && bytes <= 64U) {
                m->bot.bot_data_length=bytes; return 0;
            }
        } else if(m->bot.cbw.dDataLength == 0U && m->bot.cbw.bmFlags == 0U &&
                  m->bot.scsi_medium_state != SCSI_MEDIUM_LOCKED &&
                  (!m->ops->ready(m->context) || m->bot.scsi_medium_state == SCSI_MEDIUM_EJECTED)) {
            if(m->ops->control(m->context,cmd[1],NULL,&bytes) == 0) { m->mode_pending=1U; return 0; }
        }
    }
fail:
    if(m->bot.cbw.dDataLength == 0U) { m->bot.bot_state = USBD_BOT_NO_DATA; }
    SCSI_SenseCode(d,lun,ILLEGAL_REQUEST,INVALID_FIELD_IN_COMMAND); return -1;
}
