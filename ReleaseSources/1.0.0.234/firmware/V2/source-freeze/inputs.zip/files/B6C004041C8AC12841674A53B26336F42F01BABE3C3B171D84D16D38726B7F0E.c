#include "xe_np_np2_first_sync_port.h"
#include "xe_np_np2_config.h"
#include "xe_np_np2_preparation.h"
#include <string.h>

#define N2C_TIMEOUT_MS 10000U
static struct {
    uint8_t pending[N2C_BYTES],active[3][N2C_BYTES];
    uint8_t valid[3],port_state[3],verification[3],port;
    uint32_t port_crc[3],owner,transaction,received,expected_crc,last_ms,state;
    uint32_t last_owner,last_id,last_crc,last_port;
#if XE_NP_NP2_PREPARATION_ENABLE
    uint32_t revision;
#endif
} config __attribute__((aligned(4),section("NP_CAPTURE")));

static uint32_t get32(const uint8_t *p)
{return p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static void put32(uint8_t *p,uint32_t v)
{for(unsigned i=0;i<4;i++)p[i]=(uint8_t)(v>>(8U*i));}
uint32_t XE_NP_Np2Config_Crc(const uint8_t *p,uint32_t n)
{
    uint32_t c=~0U;
    while(n--){c^=*p++;for(unsigned b=0;b<8;b++)c=(c>>1)^((0U-(c&1U))&0xedb88320U);}
    return ~c;
}
static void clear_transfer(void)
{config.owner=0U;config.transaction=0U;config.received=0U;}
void XE_NP_Np2Config_Disconnected(uint32_t owner)
{
    XE_NP_Np2Preparation_Invalidate(NP2_PREP_OWNER);
    if(config.owner==owner){clear_transfer();config.state=N2C_NONE;}
}

static uint32_t validate(const uint8_t *p,uint32_t port)
{
    if(memcmp(p,"N2B1",4)||p[5]!=port||p[6]||p[7])return N2C_INVALID;
    if(p[4]!=4U)return N2C_UNSUPPORTED;
    uint8_t identity=0U;for(unsigned i=8;i<40;i++)identity|=p[i];
    if(!identity)return N2C_INVALID;
    /* Only active channels with one reference are admitted. The PC compiler
     * validates site-to-channel routing against the NP2013 vendor catalog. */
    for(unsigned i=40U+4U*161U;i<N2C_BYTES;i++){
        uint32_t lo=p[i]&15U,hi=p[i]>>4;
        if((lo!=1U && lo!=2U && lo!=4U)||(hi!=1U && hi!=2U && hi!=4U))return N2C_INVALID;
    }
    return N2C_OK;
}

void XE_NP_Np2Config_Exchange(uint32_t owner,const uint8_t q[N2C_FRAME],uint32_t now,
                            uint32_t busy,uint32_t mask,const uint32_t uid[3],uint8_t r[N2C_FRAME])
{
    uint32_t error=N2C_OK,op=q[5],port=q[6],id=get32(q+8),off=get32(q+12),n=get32(q+16);
    if(config.owner && now-config.last_ms>N2C_TIMEOUT_MS){clear_transfer();config.state=N2C_NONE;}
    if(memcmp(q,"NPC2",4)||q[4]!=2U||port>2U||q[7]||get32(q+56)||
       get32(q+60)!=XE_NP_Np2Config_Crc(q,60)||
       (owner!=N2C_USB && owner!=N2C_BLE)){error=N2C_BAD_FRAME;goto done;}
    if(op==N2C_STATUS || op==N2C_CAPS)goto done;
    if(op>N2C_CAPS){error=N2C_UNSUPPORTED;goto done;}
    if(busy || XE_NP_Np2Preparation_ConfigBusy()){error=N2C_BUSY;goto done;}
    if(!(mask&(1U<<port))){error=N2C_UNSUPPORTED;goto done;}
    if(!id){error=N2C_INVALID;goto done;}
    if(op==N2C_BEGIN){
        if(n!=N2C_BYTES || off){error=N2C_RANGE;goto done;}
        if(config.owner){
            if(config.owner==owner && config.transaction==id && config.port==port &&
               config.expected_crc==get32(q+20)){config.last_ms=now;goto done;}
            error=N2C_OWNER;goto done;
        }
        XE_NP_Np2FirstSyncPort_Invalidate();
        XE_NP_Np2Preparation_Invalidate(NP2_PREP_CONFIG);
        config.owner=owner;config.transaction=id;config.port=(uint8_t)port;
        config.received=0;config.expected_crc=get32(q+20);config.last_ms=now;
        config.state=N2C_RECEIVING;goto done;
    }
    /* Exact committed retry is harmless; never acknowledge an obsolete map
     * after a newer transaction replaced that port's stable image. */
    if(op==N2C_COMMIT && !config.owner && config.last_owner==owner && config.last_id==id &&
       config.last_port==port && config.last_crc==get32(q+20) && config.valid[port] &&
       config.port_crc[port]==config.last_crc)goto done;
    if(config.owner!=owner || config.transaction!=id || config.port!=port){error=N2C_OWNER;goto done;}
    config.last_ms=now;
    if(op==N2C_ABORT){clear_transfer();config.state=N2C_NONE;goto done;}
    if(op==N2C_WRITE){
        if(!n || n>N2C_CHUNK || off>N2C_BYTES || n>N2C_BYTES-off){error=N2C_RANGE;goto done;}
        if(off<config.received){
            if(n<=config.received-off && !memcmp(config.pending+off,q+24,n))goto done;
            error=N2C_ORDER;goto done;
        }
        if(off!=config.received){error=N2C_ORDER;goto done;}
        memcpy(config.pending+off,q+24,n);config.received+=n;goto done;
    }
    if(op==N2C_COMMIT){
        if(config.received!=N2C_BYTES){error=N2C_ORDER;goto done;}
        if(get32(q+20)!=config.expected_crc ||
           XE_NP_Np2Config_Crc(config.pending,N2C_BYTES)!=config.expected_crc){error=N2C_CRC;goto done;}
        error=validate(config.pending,port);if(error)goto done;
        XE_NP_Np2FirstSyncPort_Invalidate();
        XE_NP_Np2Preparation_Invalidate(NP2_PREP_CONFIG);
#if XE_NP_NP2_PREPARATION_ENABLE
        if(++config.revision==0U)config.revision=1U;
#endif
        memcpy(config.active[port],config.pending,N2C_BYTES);
        config.valid[port]=1U;config.port_state[port]=N2C_STAGED;config.verification[port]=0U;
        config.port_crc[port]=config.expected_crc;
        config.last_owner=owner;config.last_id=id;config.last_port=port;config.last_crc=config.expected_crc;
        clear_transfer();config.state=N2C_STAGED;
    }
done:
    memset(r,0,N2C_FRAME);memcpy(r,"NPR2",4);r[4]=2U;r[5]=(uint8_t)op;r[6]=(uint8_t)error;
    r[7]=(uint8_t)config.state;put32(r+8,id);put32(r+12,config.received);put32(r+16,N2C_BYTES);
    if(!error && op==N2C_CAPS){
        put32(r+24,mask);put32(r+28,4U);
        if(uid)for(unsigned i=0;i<3;i++)put32(r+32+4U*i,uid[i]);
    }else if(port<3U){
        r[20]=config.port_state[port];r[21]=config.verification[port];r[22]=(uint8_t)port;
        if(config.valid[port]){r[23]=config.active[port][4];put32(r+24,config.port_crc[port]);
            memcpy(r+28,config.active[port]+8,32);}
    }
    put32(r+60,XE_NP_Np2Config_Crc(r,60));
}
const uint8_t *XE_NP_Np2Config_Chain(uint32_t port,uint32_t chain)
{
    if(port>=3U || chain>=6U || !config.valid[port])return 0;
    return config.active[port]+40U+(chain<4U?chain*161U:4U*161U+(chain-4U)*96U);
}
const uint8_t *XE_NP_Np2Config_Selection(uint32_t port)
{return port<3U && config.valid[port]?config.active[port]:0;}
void XE_NP_Np2Config_BeginApply(uint32_t mask)
{
    for(unsigned p=0;p<3;p++)if((mask&(1U<<p)) && config.valid[p]){
        config.port_state[p]=N2C_STAGED;config.verification[p]=0U;
    }
}
void XE_NP_Np2Config_Applied(uint32_t port)
{XE_NP_Np2Config_AppliedWithShankFailures(port,0U);}
void XE_NP_Np2Config_AppliedWithShankFailures(uint32_t port,uint32_t failed_shanks)
{
    if(port<3U && config.valid[port]){
        if((failed_shanks&~15U) || failed_shanks==15U){
            config.port_state[port]=N2C_FAILED;config.verification[port]=0U;return;
        }
        config.port_state[port]=N2C_APPLIED;
        config.verification[port]=(uint8_t)(failed_shanks ?
            N2C_VERIFY_SELECTED_CHAIN_CONTROL|(failed_shanks<<N2C_VERIFY_FAILED_SHANK_SHIFT) :
            N2C_VERIFY_CHAIN_CONTROL);
    }
}
void XE_NP_Np2Config_AppliedWithUnverifiedShanks(uint32_t port,uint32_t failed_shanks)
{
    if(port<3U && config.valid[port]){
        if(!failed_shanks || (failed_shanks&~15U)){
            config.port_state[port]=N2C_FAILED;config.verification[port]=0U;return;
        }
        config.port_state[port]=N2C_APPLIED;
        config.verification[port]=(uint8_t)(N2C_VERIFY_UNVERIFIED_SHANKS|
            (failed_shanks<<N2C_VERIFY_FAILED_SHANK_SHIFT));
    }
}
void XE_NP_Np2Config_Failed(uint32_t mask)
{
    for(unsigned p=0;p<3;p++)if((mask&(1U<<p)) && config.valid[p]){
        config.port_state[p]=N2C_FAILED;config.verification[p]=0U;
    }
}

#if XE_NP_NP2_PREPARATION_ENABLE
uint32_t XE_NP_Np2Config_Revision(void){return config.revision;}
uint32_t XE_NP_Np2Config_Receiving(void){return config.owner!=0U;}
uint32_t XE_NP_Np2Config_Fingerprint(uint32_t mask,uint32_t hz)
{
    uint32_t words[7]={mask,hz,config.revision,0U,0U,0U,0U};
    for(uint32_t p=0U;p<3U;p++)if(mask&(1U<<p)){
        words[3U+p]=config.valid[p]?config.port_crc[p]:0U;
        if(config.valid[p])words[6]|=1U<<p;
    }
    return XE_NP_Np2Config_Crc((const uint8_t *)words,sizeof(words));
}
#endif