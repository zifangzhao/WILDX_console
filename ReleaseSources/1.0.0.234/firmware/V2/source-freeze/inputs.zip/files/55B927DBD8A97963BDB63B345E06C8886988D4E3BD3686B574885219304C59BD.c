#include "xe_np_board.h"
#include "xe_np_media_profile.h"
#include "xe_np_media_camera.h"

#if XE_NP_V2_MEDIA_ENABLE || XE_NP_V2_AUX_ENABLE
#include <string.h>
#include "../../Firmware/V1/Core/Inc/np_camera_exposure.h"

/* Reuse the maintained NanEye synchronizer, linked raster DMA and immutable
 * slot publication. Only board admission/cadence belongs in this adapter.
 * np_sd_ru1 is an actual caller-owned arena, not V1's fixed download memory. */
static const uint32_t np_mode_mask = 0U;
static uint8_t *np_sd_ru1;
static uint32_t NP_CameraReadPrescaler(uint32_t safe);
#define HAL_SPI_RxCpltCallback XE_NP_MediaCamera_HalRxComplete
#define HAL_SPI_ErrorCallback XE_NP_MediaCamera_HalError
/* V2 program11 owns its cold/resumed settling below. New V1-only Prime
 * warmups must not silently change this already validated capture profile. */
#define USB512_CAMERA_POST_PRIME_WARMUP_FRAMES 0U
#if XE_NP_V2_AUX_ENABLE
#define USB512_CAMERA_FRAME_BASE np_sd_ru1
#endif
#include "../../Firmware/V1/Core/Src/np_usb_camera_driver.inc"
#if XE_NP_V2_AUX_ENABLE
#undef USB512_CAMERA_FRAME_BASE
#endif
#undef USB512_CAMERA_POST_PRIME_WARMUP_FRAMES
#undef HAL_SPI_RxCpltCallback
#undef HAL_SPI_ErrorCallback

static DMA_HandleTypeDef media_camera_dma;
static SPI_HandleTypeDef *media_camera_spi;
static NpCameraCadence media_camera_cadence;
static uint8_t media_camera_armed;
static int media_camera_error;
static uint8_t media_rows,media_gain=3U,media_auto=1U;
static NpCameraExposure media_exposure;
#if XE_NP_NP2_FIRST_SYNC_ENABLE
static struct {uint32_t arm_generation,used_generation,drop_through;uint8_t active;} media_camera_first_sync;
static uint32_t media_camera_dwt(uint32_t *valid)
{
#if defined(DWT) && defined(DWT_CTRL_CYCCNTENA_Msk)
    if(DWT->CTRL&DWT_CTRL_CYCCNTENA_Msk){*valid=1U;return DWT->CYCCNT;}
#endif
    *valid=0U;return 0U;
}
static uint8_t media_camera_first_sync_allowed(uint32_t id)
{
    uint32_t first=media_camera_first_sync.drop_through+1U;
    return id!=0U && (int32_t)(id-first)>=0;
}
static void media_camera_first_sync_filter(void)
{
    uint32_t key;uint8_t slot,mask,accepted=0U;
    if(!media_camera_first_sync.active)return;
    key=__get_PRIMASK();__disable_irq();mask=usb512_camera_state.ready_mask;
    for(slot=0U;slot<USB512_CAMERA_BUFFER_COUNT;slot++)if(mask&(1U<<slot)){
        if(!media_camera_first_sync_allowed(usb512_camera_state.slot_id[slot]))
            mask&=(uint8_t)~(1U<<slot);
        else accepted=1U;
    }
    usb512_camera_state.ready_mask=mask;
    if(usb512_camera_state.tx_slot<USB512_CAMERA_BUFFER_COUNT &&
       !(mask&(1U<<usb512_camera_state.tx_slot)))usb512_camera_state.tx_slot=USB512_CAMERA_SLOT_NONE;
    usb512_camera_state.frame_ready=mask!=0U;
    /* Once a post-boundary completed raster is visible, all older ownership
     * was retired.  Stop scanning hot publication paths for this Arm. */
    if(accepted)media_camera_first_sync.active=0U;
    __set_PRIMASK(key);
}
#endif
#if XE_NP_V2_AUX_ENABLE
static uint32_t media_camera_hz=XE_NP_MEDIA_CAMERA_HZ,media_camera_kernel;
static int media_camera_arena_fits(uintptr_t arena,uint32_t bytes)
{
    return !(arena&31U) && arena>=0x20220000UL && arena<0x20270000UL &&
        bytes>=2U*160000U && bytes<=0x20270000UL-arena;
}
static int media_camera_rate_valid(uint32_t kernel,uint32_t hz,uint32_t safe)
{
    return (kernel==96000000U || kernel==128000000U || kernel==150000000U ||
        kernel==192000000U) && safe<=1U && hz && hz<=np_camera_max_hz(kernel,safe);
}
static int media_camera_clock_valid(uint32_t kernel)
{
    return HAL_RCC_GetSysClockFreq()==kernel &&
        __HAL_RCC_GET_SYSCLK_SOURCE()==RCC_SYSCLKSOURCE_STATUS_PLLCLK &&
        (RCC->PLL1CFGR&RCC_PLL1CFGR_PLL1SRC)==RCC_PLLSOURCE_HSE;
}
static int media_camera_prepare_admitted(SPI_HandleTypeDef *spi,uint8_t *arena,
    uint32_t bytes,uint32_t hz,uint32_t safe,uint32_t legacy)
{
    uint32_t kernel=HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SPI1);
    return !media_camera_spi && spi && spi->Instance==SPI1 &&
        HAL_SPI_GetState(spi)==HAL_SPI_STATE_RESET &&
        media_camera_arena_fits((uintptr_t)arena,bytes) &&
        media_camera_rate_valid(kernel,hz,safe) && media_camera_clock_valid(kernel) &&
        (!legacy || (kernel==XE_NP_MEDIA_CORE_HZ && hz==XE_NP_MEDIA_CAMERA_HZ && !safe)) &&
        !(PSSI->CR&PSSI_CR_ENABLE) && !(TIM8->CR1&TIM_CR1_CEN) &&
        !(GPDMA1_Channel15->CCR&DMA_CCR_EN);
}
#endif

static uint32_t NP_CameraReadPrescaler(uint32_t safe)
{
    uint32_t divider = np_camera_divider(
        HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SPI1), safe);
    uint32_t field = 0U;
    while(divider > 2U) { divider /= 2U; field++; }
    return field << SPI_CFG1_MBR_Pos;
}

#if XE_NP_V2_AUX_ENABLE
static int media_camera_prepare(SPI_HandleTypeDef *spi,uint8_t *arena,
    uint32_t arena_bytes,uint32_t hz,uint32_t safe_profile,uint32_t legacy)
#else
int XE_NP_MediaCamera_Prepare(SPI_HandleTypeDef *spi, uint8_t *arena,
                              uint32_t arena_bytes)
#endif
{
    GPIO_InitTypeDef gpio = {0};
    uint32_t rails_were_off;

    /* Fail before changing any pad, rail, handle or shared clock. SPI1 must
     * be explicitly retired, not aborted out from under another source. */
#if XE_NP_V2_AUX_ENABLE
    if(!media_camera_prepare_admitted(spi,arena,arena_bytes,hz,safe_profile,legacy))return -1;
    const uint32_t kernel=HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SPI1);
#else
    if(media_camera_spi || !spi || spi->Instance != SPI1 ||
       HAL_SPI_GetState(spi) != HAL_SPI_STATE_RESET ||
       !XE_NP_MediaCameraArenaFits((uintptr_t)arena, arena_bytes) ||
       HAL_RCC_GetSysClockFreq() != XE_NP_MEDIA_CORE_HZ ||
       __HAL_RCC_GET_SYSCLK_SOURCE() != RCC_SYSCLKSOURCE_STATUS_PLLCLK ||
       (RCC->PLL1CFGR & RCC_PLL1CFGR_PLL1SRC) != RCC_PLLSOURCE_HSE ||
       (PSSI->CR & PSSI_CR_ENABLE) || (TIM8->CR1 & TIM_CR1_CEN) ||
       (GPDMA1_Channel15->CCR & DMA_CCR_EN)) return -1;
#endif

    media_camera_error = 0;
    np_sd_ru1 = arena;
    media_camera_spi = spi;
    __HAL_RCC_GPIOG_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();
    __HAL_RCC_GPIOF_CLK_ENABLE();
    __HAL_RCC_GPDMA1_CLK_ENABLE();
    rails_were_off = HAL_GPIO_ReadPin(VCC_EN_GPIO_Port, VCC_EN_Pin) != GPIO_PIN_SET ||
                    HAL_GPIO_ReadPin(VEE_EN_GPIO_Port, VEE_EN_Pin) != GPIO_PIN_SET;
    /* These enables are shared with probe/SD rails. Never cycle them here. */
    HAL_GPIO_WritePin(VCC_EN_GPIO_Port, VCC_EN_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(VEE_EN_GPIO_Port, VEE_EN_Pin, GPIO_PIN_SET);
    gpio.Mode = GPIO_MODE_OUTPUT_PP;
    gpio.Pull = GPIO_NOPULL;
    gpio.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    gpio.Pin = VCC_EN_Pin;
    HAL_GPIO_Init(VCC_EN_GPIO_Port, &gpio);
    gpio.Pin = VEE_EN_Pin;
    HAL_GPIO_Init(VEE_EN_GPIO_Port, &gpio);
    if(rails_were_off) HAL_Delay(100U);

    memset(&spi->Init, 0, sizeof(spi->Init));
    spi->Init.Mode = SPI_MODE_MASTER;
    spi->Init.Direction = SPI_DIRECTION_2LINES;
    spi->Init.DataSize = SPI_DATASIZE_8BIT;
    spi->Init.CLKPolarity = SPI_POLARITY_LOW;
    spi->Init.CLKPhase = SPI_PHASE_1EDGE;
    spi->Init.NSS = SPI_NSS_SOFT;
    spi->Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_4;
    spi->Init.FirstBit = SPI_FIRSTBIT_MSB;
    spi->Init.TIMode = SPI_TIMODE_DISABLE;
    spi->Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
    spi->Init.CRCPolynomial = 0x7U;
    spi->Init.NSSPMode = SPI_NSS_PULSE_DISABLE;
    spi->Init.NSSPolarity = SPI_NSS_POLARITY_LOW;
    spi->Init.FifoThreshold = SPI_FIFO_THRESHOLD_01DATA;
    spi->Init.MasterSSIdleness = SPI_MASTER_SS_IDLENESS_00CYCLE;
    spi->Init.MasterInterDataIdleness = SPI_MASTER_INTERDATA_IDLENESS_00CYCLE;
    spi->Init.MasterReceiverAutoSusp = SPI_MASTER_RX_AUTOSUSP_DISABLE;
    spi->Init.MasterKeepIOState = SPI_MASTER_KEEP_IO_STATE_DISABLE;
    spi->Init.IOSwap = SPI_IO_SWAP_DISABLE;
    spi->Init.ReadyMasterManagement = SPI_RDY_MASTER_MANAGEMENT_INTERNALLY;
    spi->Init.ReadyPolarity = SPI_RDY_POLARITY_HIGH;
    if(HAL_SPI_Init(spi) != HAL_OK ||
#if XE_NP_V2_AUX_ENABLE
       HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SPI1)!=kernel || !media_camera_clock_valid(kernel) ||
       !media_camera_rate_valid(kernel,hz,safe_profile))
#else
       HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SPI1) != XE_NP_MEDIA_CORE_HZ ||
       np_camera_max_hz(XE_NP_MEDIA_CORE_HZ, 0U) < XE_NP_MEDIA_CAMERA_HZ)
#endif
    {
        media_camera_error = -2;
        return -2;
    }
    /* CAM_CS is PG5, separate from the software NSS peripheral setting. */
    HAL_GPIO_WritePin(GPIOG, GPIO_PIN_5, GPIO_PIN_SET);
    gpio.Pin = GPIO_PIN_5;
    HAL_GPIO_Init(GPIOG, &gpio);
    HAL_GPIO_WritePin(GPIOG, GPIO_PIN_5, GPIO_PIN_RESET);

    memset(&media_camera_dma, 0, sizeof(media_camera_dma));
    media_camera_dma.Instance = GPDMA1_Channel15;
    media_camera_dma.Init.Request = GPDMA1_REQUEST_SPI1_RX;
    media_camera_dma.Init.BlkHWRequest = DMA_BREQ_SINGLE_BURST;
    media_camera_dma.Init.Direction = DMA_PERIPH_TO_MEMORY;
    media_camera_dma.Init.SrcInc = DMA_SINC_FIXED;
    media_camera_dma.Init.DestInc = DMA_DINC_INCREMENTED;
    media_camera_dma.Init.SrcDataWidth = DMA_SRC_DATAWIDTH_BYTE;
    media_camera_dma.Init.DestDataWidth = DMA_DEST_DATAWIDTH_BYTE;
    media_camera_dma.Init.Priority = DMA_LOW_PRIORITY_HIGH_WEIGHT;
    media_camera_dma.Init.SrcBurstLength = 1U;
    media_camera_dma.Init.DestBurstLength = 1U;
    media_camera_dma.Init.TransferAllocatedPort = DMA_SRC_ALLOCATED_PORT0 | DMA_DEST_ALLOCATED_PORT1;
    media_camera_dma.Init.TransferEventMode = DMA_TCEM_BLOCK_TRANSFER;
    media_camera_dma.Init.Mode = DMA_NORMAL;
    if(HAL_DMA_Init(&media_camera_dma) != HAL_OK ||
       HAL_DMA_ConfigChannelAttributes(&media_camera_dma, DMA_CHANNEL_NPRIV) != HAL_OK)
    {
        media_camera_error = -3;
        return -3;
    }
    __HAL_LINKDMA(spi, hdmarx, media_camera_dma);
    /* ADC cadence publication wins over camera completion; no NP source. */
    HAL_NVIC_SetPriority(GPDMA1_Channel15_IRQn, 4U, 0U);
    HAL_NVIC_EnableIRQ(GPDMA1_Channel15_IRQn);
    HAL_NVIC_SetPriority(SPI1_IRQn, 5U, 0U);
    HAL_NVIC_EnableIRQ(SPI1_IRQn);
    if(USB512_Camera_Init(spi) != HAL_OK ||
       USB512_Camera_SetProfile(
#if XE_NP_V2_AUX_ENABLE
           (uint8_t)safe_profile
#else
           USB512_CAMERA_PROFILE_NORMAL_50HZ
#endif
           ) != HAL_OK ||
       USB512_Camera_SetExposure(media_rows,media_gain) != HAL_OK ||
       USB512_Camera_Prime() != HAL_OK)
    {
        USB512_Camera_StopCapture();
        media_camera_error = -4;
        return -4;
    }
    np_camera_exposure_reset(&media_exposure,media_rows,media_gain,media_auto);
#if XE_NP_V2_AUX_ENABLE
    media_camera_hz=hz;media_camera_kernel=kernel;
#endif
    return 0;
}

#if XE_NP_V2_AUX_ENABLE
int XE_NP_MediaCamera_Prepare(SPI_HandleTypeDef *spi,uint8_t *arena,uint32_t bytes)
{return media_camera_prepare(spi,arena,bytes,XE_NP_MEDIA_CAMERA_HZ,0U,1U);}
int XE_NP_MediaCamera_PrepareRate(SPI_HandleTypeDef *spi,uint8_t *arena,
    uint32_t bytes,uint32_t hz,uint32_t safe_profile)
{return media_camera_prepare(spi,arena,bytes,hz,safe_profile,0U);}
uint32_t XE_NP_MediaCamera_MaxRate(uint32_t safe_profile)
{
    uint32_t kernel=HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SPI1);
    return media_camera_rate_valid(kernel,1U,safe_profile) && media_camera_clock_valid(kernel)?
        np_camera_max_hz(kernel,safe_profile):0U;
}
int XE_NP_MediaCamera_SetRate(uint32_t hz,uint32_t safe_profile)
{
    if(!media_camera_spi || media_camera_error || media_camera_armed ||
       !USB512_Camera_IsReady() || USB512_Camera_IsBusy() || USB512_Camera_IsFrameReady() ||
       usb512_camera_state.capture_dma_restore_pending ||
       HAL_SPI_GetState(media_camera_spi)!=HAL_SPI_STATE_READY ||
       (PSSI->CR&PSSI_CR_ENABLE) || (TIM8->CR1&TIM_CR1_CEN) ||
       (GPDMA1_Channel15->CCR&DMA_CCR_EN) ||
       HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SPI1)!=media_camera_kernel ||
       !media_camera_clock_valid(media_camera_kernel) ||
       !media_camera_rate_valid(media_camera_kernel,hz,safe_profile))return -1;
    if(USB512_Camera_SetProfile((uint8_t)safe_profile)!=HAL_OK)return -1;
    media_camera_hz=hz;
    return 0;
}
void XE_NP_MediaCamera_Retire(void)
{
    media_camera_armed=0U;
    if(media_camera_spi)USB512_Camera_RequestRetire();
}
int XE_NP_MediaCamera_IsRetired(void)
{
    if(!media_camera_spi)return 1;
    USB512_Camera_ServiceRetire();
    return !usb512_camera_state.retire_pending &&
        !usb512_camera_state.capture_dma_linked && !usb512_camera_state.capture_dma_restore_pending &&
        !(GPDMA1_Channel15->CCR&DMA_CCR_EN) &&
        HAL_SPI_GetState(media_camera_spi)==HAL_SPI_STATE_READY;
}
#endif

int XE_NP_MediaCamera_Settle(void)
{
#if XE_NP_V2_AUX_ENABLE
    if(HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SPI1)!=media_camera_kernel ||
       !media_camera_clock_valid(media_camera_kernel))return -1;
#endif
    if(!media_camera_spi || media_camera_error || media_camera_armed ||
       !USB512_Camera_IsReady() || USB512_Camera_IsBusy() ||
       USB512_Camera_IsFrameReady()) return -1;
    /* STOP can retire an in-flight linked raster asynchronously. Finish only
     * that foreground DMA handoff before private warmup; never rearm cadence. */
    const uint32_t retire_started=HAL_GetTick();
    while(usb512_camera_state.capture_dma_restore_pending) {
        USB512_Camera_Service();
        if(usb512_camera_state.phase==USB512_CAMERA_PHASE_ERROR ||
           HAL_GetTick()-retire_started>=100U)return -1;
    }
    const uint32_t baseline=usb512_camera_state.frame_count;
    /* A resumed stream or staged register pair can leave its first raster
     * at the configuration phase. Retire two private rasters immediately
     * before Arm, after stopped SD I/O. No source ID/tick or ADC is started,
     * and steady-state capture keeps the canonical synchronizer unchanged. */
    for(unsigned warmup=0U;warmup<2U;warmup++) {
        usb512_camera_state.warmup_frames=1U;
        if(USB512_Camera_StartFrame()!=HAL_OK) return -1;
        const uint32_t started=HAL_GetTick();
        while(usb512_camera_state.busy || usb512_camera_state.capture_dma_restore_pending) {
            USB512_Camera_Service();
            if(usb512_camera_state.phase==USB512_CAMERA_PHASE_ERROR) return -1;
            if(HAL_GetTick()-started>=100U) {
                XE_NP_MediaCamera_StopCapture();
                return -1;
            }
        }
        if(usb512_camera_state.warmup_frames || usb512_camera_state.ready_mask ||
           usb512_camera_state.frame_count!=baseline) return -1;
    }
    return 0;
}

int XE_NP_MediaCamera_Arm(uint32_t start_ms)
{
#if XE_NP_V2_AUX_ENABLE
    if(HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SPI1)!=media_camera_kernel ||
       !media_camera_clock_valid(media_camera_kernel))return -1;
#endif
    if(!media_camera_spi || media_camera_error || media_camera_armed ||
       !USB512_Camera_IsReady() || USB512_Camera_IsBusy() ||
       USB512_Camera_IsFrameReady()) return -1;
#if XE_NP_NP2_FIRST_SYNC_ENABLE
    if(media_camera_first_sync.arm_generation==UINT32_MAX)return -1;
    media_camera_first_sync.arm_generation++;media_camera_first_sync.active=0U;
#endif
    media_camera_cadence = (NpCameraCadence){start_ms, 0U, 0U};
    media_camera_armed = 1U;
    return 0;
}

uint32_t XE_NP_MediaCamera_FirstSyncGeneration(void)
{
#if XE_NP_NP2_FIRST_SYNC_ENABLE
    return media_camera_armed?media_camera_first_sync.arm_generation:0U;
#else
    return 0U;
#endif
}

int XE_NP_MediaCamera_FirstSyncBegin(uint32_t generation,XE_NP_MediaCameraFirstSync *out)
{
#if XE_NP_NP2_FIRST_SYNC_ENABLE
    uint32_t key,before_valid,after_valid,before,after;uint8_t ready,slot,inflight;
    if(out)memset(out,0,sizeof(*out));
    if(!out || !generation || !media_camera_spi || media_camera_error || !media_camera_armed ||
       generation!=media_camera_first_sync.arm_generation ||
       media_camera_first_sync.used_generation==generation || media_camera_first_sync.active)return -1;
    before=HAL_GetTick();out->before_hal_ms=before;out->before_dwt_cycles=media_camera_dwt(&before_valid);
    key=__get_PRIMASK();__disable_irq();ready=usb512_camera_state.ready_mask;
    if((ready&~((1U<<USB512_CAMERA_BUFFER_COUNT)-1U)) ||
       (usb512_camera_state.tx_slot<USB512_CAMERA_BUFFER_COUNT && !(ready&(1U<<usb512_camera_state.tx_slot))) ||
       (usb512_camera_state.busy && usb512_camera_state.capture_slot>=USB512_CAMERA_BUFFER_COUNT) ||
       (!usb512_camera_state.busy && usb512_camera_state.capture_slot!=USB512_CAMERA_SLOT_NONE) ||
       (!usb512_camera_state.busy && usb512_camera_state.publish_pending) ||
       usb512_camera_state.capture_dma_restore_pending || usb512_camera_state.frame_count>=UINT32_MAX-1U){
        __set_PRIMASK(key);return -1;
    }
    for(slot=0U;slot<USB512_CAMERA_BUFFER_COUNT;slot++)if((ready&(1U<<slot)) && !usb512_camera_state.slot_id[slot]){
        __set_PRIMASK(key);return -1;
    }
    inflight=(uint8_t)(usb512_camera_state.busy||usb512_camera_state.publish_pending);
    out->generation=generation;out->arm_generation=media_camera_first_sync.arm_generation;
    out->before_frame_count=usb512_camera_state.frame_count;
    media_camera_first_sync.used_generation=generation;
    media_camera_first_sync.drop_through=usb512_camera_state.frame_count+(inflight?1U:0U);
    media_camera_first_sync.active=1U;
    usb512_camera_state.ready_mask=0U;usb512_camera_state.tx_slot=USB512_CAMERA_SLOT_NONE;
    usb512_camera_state.frame_ready=0U;
    out->first_allowed_counter=out->min_frame_id=media_camera_first_sync.drop_through+1U;
    out->flags=XE_NP_MEDIA_CAMERA_FIRST_SYNC_VALID|(ready?XE_NP_MEDIA_CAMERA_FIRST_SYNC_DROPPED_READY:0U)|
        (inflight?XE_NP_MEDIA_CAMERA_FIRST_SYNC_INFLIGHT_SKIPPED:0U);
    out->after_frame_count=usb512_camera_state.frame_count;__set_PRIMASK(key);
    after=HAL_GetTick();out->after_hal_ms=after;out->after_dwt_cycles=media_camera_dwt(&after_valid);
    out->flags|=(before_valid&&after_valid)?XE_NP_MEDIA_CAMERA_FIRST_SYNC_DWT_VALID:XE_NP_MEDIA_CAMERA_FIRST_SYNC_CYCLES_UNKNOWN;
    return 0;
#else
    (void)generation;if(out)memset(out,0,sizeof(*out));return -1;
#endif
}

void XE_NP_MediaCamera_Service(uint32_t now_ms)
{
    if(!media_camera_spi) return;
    USB512_Camera_Service();
#if XE_NP_NP2_FIRST_SYNC_ENABLE
    media_camera_first_sync_filter();
#endif
    if(USB512_Camera_GetPhase() == USB512_CAMERA_PHASE_ERROR)
    {
        if(!media_camera_error) {
            media_camera_error = -5;
            USB512_Camera_StopCapture();
        }
        media_camera_armed = 0U;
        return;
    }
    if(media_camera_armed && (int32_t)(now_ms - media_camera_cadence.next_ms) >= 0)
    {
        HAL_StatusTypeDef status = USB512_Camera_IsBusy() ? HAL_BUSY : USB512_Camera_StartFrame();
        if(status == HAL_BUSY) media_camera_cadence.missed++;
        else if(status != HAL_OK) {
            media_camera_error = -6;
            media_camera_armed = 0U;
            USB512_Camera_StopCapture();
        }
        np_camera_advance(&media_camera_cadence,
#if XE_NP_V2_AUX_ENABLE
            media_camera_hz,
#else
            XE_NP_MEDIA_CAMERA_HZ,
#endif
            now_ms);
    }
}

int XE_NP_MediaCamera_FinishCapture(void)
{
#if XE_NP_V2_AUX_ENABLE
    if(PSSI->CR&PSSI_CR_ENABLE){XE_NP_MediaCamera_Retire();return -1;}
#endif
    if(!media_camera_spi || media_camera_error)return -1;
    media_camera_armed=0U;
    const uint32_t started=HAL_GetTick();
    /* Explicit logger transitions finish the current raster, not its serial
     * word halfway through. Ordinary BLE requests never call this helper. */
    do {
        USB512_Camera_Service();
        if(USB512_Camera_GetPhase()==USB512_CAMERA_PHASE_ERROR)return -1;
        if(!USB512_Camera_IsBusy() && !usb512_camera_state.capture_dma_restore_pending) {
            XE_NP_MediaCamera_StopCapture();return 0;
        }
    } while(HAL_GetTick()-started<100U);
    media_camera_error=-7;
    XE_NP_MediaCamera_StopCapture();return -1;
}

void XE_NP_MediaCamera_StopCapture(void)
{
#if XE_NP_NP2_FIRST_SYNC_ENABLE
    media_camera_first_sync.active=0U;
#endif
#if XE_NP_V2_AUX_ENABLE
    XE_NP_MediaCamera_Retire();
    if(!(PSSI->CR&PSSI_CR_ENABLE))(void)XE_NP_MediaCamera_IsRetired();
#else
    media_camera_armed = 0U;
    if(media_camera_spi) {
        /* Publish an already completed raster before retiring a partial one.
         * Never run the adapter cadence here: STOP must not start a frame. */
        USB512_Camera_Service();
        const uint32_t prior_dma_error=media_camera_dma.ErrorCode;
        USB512_Camera_StopCapture();
        /* HAL_SPI_Abort also asks a completed RX DMA to abort, producing its
         * software NO_XFER code. Clear only this proven STOP artifact; retain
         * every pre-existing DMA/SPI/source fault and any failed retirement. */
        if(!prior_dma_error && media_camera_dma.ErrorCode==HAL_DMA_ERROR_NO_XFER &&
           !media_camera_error && USB512_Camera_GetPhase()!=USB512_CAMERA_PHASE_ERROR &&
           !(GPDMA1_Channel15->CCR&DMA_CCR_EN) &&
           HAL_SPI_GetState(media_camera_spi)==HAL_SPI_STATE_READY)
            media_camera_dma.ErrorCode=HAL_DMA_ERROR_NONE;
    }
#endif
}

int XE_NP_MediaCamera_Release(void)
{
    if(!media_camera_spi) return 0;
    XE_NP_MediaCamera_StopCapture();
#if XE_NP_V2_AUX_ENABLE
    if((PSSI->CR&PSSI_CR_ENABLE) || !XE_NP_MediaCamera_IsRetired())return -1;
#endif
    if(GPDMA1_Channel15->CCR & DMA_CCR_EN) return -1;
    USB512_Camera_Stop();
    HAL_NVIC_DisableIRQ(GPDMA1_Channel15_IRQn);
    HAL_NVIC_DisableIRQ(SPI1_IRQn);
    if(HAL_SPI_DeInit(media_camera_spi) != HAL_OK) return -1;
    if(media_camera_dma.Instance && HAL_DMA_DeInit(&media_camera_dma) != HAL_OK) return -1;
    HAL_GPIO_WritePin(GPIOG, GPIO_PIN_5, GPIO_PIN_SET);
    HAL_GPIO_DeInit(GPIOG, GPIO_PIN_5);
    media_camera_spi->hdmarx = NULL;
    media_camera_spi = NULL;
    np_sd_ru1 = NULL;
#if XE_NP_V2_AUX_ENABLE
    media_camera_kernel=0U;
#endif
    return 0;
}

const uint8_t *XE_NP_MediaCamera_GetFrame(uint32_t *id, uint32_t *tick)
{
#if XE_NP_NP2_FIRST_SYNC_ENABLE
    media_camera_first_sync_filter();
#endif
    const uint8_t *frame = media_camera_spi ? USB512_Camera_GetFrame() : NULL;
    if(id) *id = frame ? NP_CameraFrameId() : 0U;
    if(tick) *tick = frame ? NP_CameraFrameTick() : 0U;
    return frame;
}
void XE_NP_MediaCamera_ConsumeFrame(void) { if(media_camera_spi) USB512_Camera_ConsumeFrame(); }
uint32_t XE_NP_MediaCamera_MissedCadences(void) { return media_camera_cadence.missed; }
int XE_NP_MediaCamera_Error(void) { return media_camera_error; }
uint32_t XE_NP_MediaCamera_CompletedFrames(void) { return USB512_Camera_GetFrameCount(); }
uint32_t XE_NP_MediaCamera_ConfigurationFlags(void) {
    return (usb512_camera_state.initialized?1U:0U) |
           (usb512_camera_state.exposure_update_pending?2U:0U);
}
int XE_NP_MediaCamera_SetExposure(uint8_t rows,uint8_t gain,uint8_t automatic)
{
    if(gain>3U || automatic>1U) return -1;
    if(media_camera_spi && USB512_Camera_SetExposure(rows,gain)!=HAL_OK) return -1;
    media_rows=rows;media_gain=gain;media_auto=automatic;
    np_camera_exposure_reset(&media_exposure,rows,gain,automatic);
    return 0;
}
void XE_NP_MediaCamera_ObserveFrame(const uint8_t *frame,uint32_t id,uint32_t tick)
{
    if(np_camera_exposure_observe(&media_exposure,frame,
         XE_NP_MEDIA_CAMERA_FRAME_BYTES,id,tick)>0)
        (void)USB512_Camera_SetExposure(media_exposure.rows,media_exposure.gain);
}
void XE_NP_MediaCamera_Snapshot(NpMediaMetadata *out)
{
    out->camera_source_completed=USB512_Camera_GetFrameCount();
    out->camera_fault=(uint32_t)media_camera_error;
    out->camera_cadence_misses=media_camera_cadence.missed;
    out->camera_spi_sr=media_camera_spi?SPI1->SR:0U;
    out->camera_spi_error=media_camera_spi?media_camera_spi->ErrorCode:0U;
    out->camera_dma_error=media_camera_dma.ErrorCode;
    out->seed_reg0=(USB512_CAMERA_REG0_DEFAULT & ~0xFF30U) |
                   ((uint32_t)media_rows<<8U) | ((uint32_t)media_gain<<4U);
    out->effective_reg0=media_camera_spi?usb512_camera_state.reg0:out->seed_reg0;
    out->reg1=USB512_CAMERA_REG1_DEFAULT;
    out->auto_enabled=media_auto;
    out->mean=media_exposure.mean;
    out->camera_last_id=media_exposure.frame_id;
    out->camera_last_tick=media_exposure.frame_tick;
}
void XE_NP_MediaCamera_DmaIrq(void) { if(media_camera_spi) HAL_DMA_IRQHandler(&media_camera_dma); }
void XE_NP_MediaCamera_SpiIrq(void) { if(media_camera_spi) HAL_SPI_IRQHandler(media_camera_spi); }
#endif
