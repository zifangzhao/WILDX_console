#ifndef XE_NP_NP2_FIRST_SYNC_RUNTIME_H
#define XE_NP_NP2_FIRST_SYNC_RUNTIME_H
#include <stddef.h>
#include "xe_np_np2_first_sync_port.h"
#include "xe_np_imu_grid_control_wire.h"
#ifndef NP_FINE_COUNTER64_ENABLE
#define NP_FINE_COUNTER64_ENABLE 0U
#endif
#ifndef XE_NP_NP2_USB_GRID_EXPERIMENT
#define XE_NP_NP2_USB_GRID_EXPERIMENT 0U
#endif
#ifndef XE_NP_NP2_SD_GRID16_ENABLE
#define XE_NP_NP2_SD_GRID16_ENABLE 0U
#endif
#if XE_NP_NP2_SD_GRID16_ENABLE
/* Foreground metadata only. `available` does not certify interval
 * continuity or analog phase and does not gate draining. `incomplete` is
 * never an NP stop request. */
typedef struct {
    uint32_t available,started,attached,stopped,fault,incomplete;
    uint32_t queue_dropped,counter_faults,scheduler_faults,late_copies,generation;
    uint32_t stopped_discarded_pending,retired;
    uint64_t scheduler_missing,discarded_prefix,stopped_discarded_rows;
} XE_NP_Np2SdGridStatus;
#if XE_NP_NP2_FIRST_SYNC_ENABLE
int XE_NP_Np2FirstSyncRuntime_SdGridNext(uint8_t *body,uint32_t capacity,
    uint32_t *type,uint32_t *bytes,uint64_t *source);
int XE_NP_Np2FirstSyncRuntime_SdGridNextPartial(uint8_t *body,uint32_t capacity,
    uint32_t *type,uint32_t *bytes,uint64_t *source);
void XE_NP_Np2FirstSyncRuntime_SdGridComplete(uint32_t type,uint32_t delivered);
void XE_NP_Np2FirstSyncRuntime_SdGridStatus(XE_NP_Np2SdGridStatus *out);
/* Manual Stop preparation: stop only the grid timer/provider, preserving NP
 * and its fine-clock/gate. Count remaining actual12-slot packets once stopped. */
int XE_NP_Np2FirstSyncRuntime_SdGridPrepareStop(uint32_t *pending_packets);
/* Foreground-only after the app sealed and released its final Grid16 stage.
 * Queued/held rows are exact; a pending provider record stays unknown. */
int XE_NP_Np2FirstSyncRuntime_SdGridDiscardStopped(uint64_t *discarded_rows);
#else
#define XE_NP_Np2FirstSyncRuntime_SdGridNext(body,capacity,type,bytes,source) 2
#define XE_NP_Np2FirstSyncRuntime_SdGridNextPartial(body,capacity,type,bytes,source) 2
#define XE_NP_Np2FirstSyncRuntime_SdGridComplete(type,delivered) ((void)0)
#define XE_NP_Np2FirstSyncRuntime_SdGridStatus(out) ((void)0)
#define XE_NP_Np2FirstSyncRuntime_SdGridPrepareStop(pending_packets) 0
#define XE_NP_Np2FirstSyncRuntime_SdGridDiscardStopped(discarded_rows) 0
#endif
#endif
#if XE_NP_NP2_FIRST_SYNC_ENABLE
#if NP_FINE_COUNTER64_ENABLE
#include "xe_np_np2_sd_fine_clock.h"
#endif
/* Owner runtime: initialized while stopped, never from an IRQ. It owns only
 * CPU metadata; fixed NN/DMA rings are never repurposed. Optional protocol
 * defaults off for each legacy/new recording until explicit admission. */
void XE_NP_Np2FirstSyncRuntime_Init(void);
void XE_NP_Np2FirstSyncRuntime_SdPrepare(uint32_t nonce,uint32_t session,uint32_t mask,uint32_t hz);
void XE_NP_Np2FirstSyncRuntime_SdArmed(void);
int XE_NP_Np2FirstSyncRuntime_SdOpted(void);
int XE_NP_Np2FirstSyncRuntime_SdClockBegin(void);
int XE_NP_Np2FirstSyncRuntime_SdFineAnchor(uint8_t out[64]);
#if NP_FINE_COUNTER64_ENABLE
/* Starts the negotiated fine clock after final clocks settle and before the
 * capture owner takes its root.  2=continuous64 selected, 1=legacy32, 0=no
 * optional clock.  It never makes a source/root claim. */
int XE_NP_Np2FirstSyncRuntime_ClockBegin(void);
/* The capture owner supplies the one actual first-DMA-word bracket. */
int XE_NP_Np2FirstSyncRuntime_FineBound(uint32_t generation,uint32_t source_epoch,
    const XE_NP_Np2SdFinePoint64 *before,const XE_NP_Np2SdFinePoint64 *after);
int XE_NP_Np2FirstSyncRuntime_FineCounter64(void);
const uint8_t *XE_NP_Np2FirstSyncRuntime_RtcFrozen(void);
#endif
/* USB first-sync v2/3 prepares before final arm; Armed consumes only this
 * exact tuple.  Feature 7/15 selects continuous64; legacy callers remain
 * valid through UsbArmed's fallback. */
int XE_NP_Np2FirstSyncRuntime_UsbPrepare(uint64_t token,uint32_t mask,uint32_t hz,
    uint8_t aux_mask,uint32_t features);
/* Called only AFTER the actual final receiver arm. USB has no catalog ID;
 * session is actual nonzero final anchor generation, UID/token separately bound. */
int XE_NP_Np2FirstSyncRuntime_UsbArmed(uint64_t token,uint32_t mask,uint32_t hz,uint8_t aux_mask);
/* Foreground metadata only, no source/sensor setup or I/O. Stop freezes once;
 * the normal source owner independently closes live permission from IRQ. */
void XE_NP_Np2FirstSyncRuntime_Stop(void);
void XE_NP_Np2FirstSyncRuntime_Service(void);
#if XE_NP_NP2_USB_GRID_EXPERIMENT
/* USB-only experimental selection. Control callbacks mutate only small state;
 * producer setup/teardown is foreground and never gates NP recording. */
int XE_NP_Np2FirstSyncRuntime_GridAvailable(void);
int XE_NP_Np2FirstSyncRuntime_GridSelect(uint32_t selected);
void XE_NP_Np2FirstSyncRuntime_GridFreeze(void);
void XE_NP_Np2FirstSyncRuntime_GridReset(void);
void XE_NP_Np2FirstSyncRuntime_GridService(uint32_t np_idle);
uint32_t XE_NP_Np2FirstSyncRuntime_GridSelected(void);
uint32_t XE_NP_Np2FirstSyncRuntime_GridFrozen(void);
#if XE_NP_GRID_ENFORCED || (defined(XE_NP_GRID_READY_GATE_TEST) && XE_NP_GRID_READY_GATE_TEST) || \
    (defined(XE_NP_GRID_FAIRNESS_TEST) && XE_NP_GRID_FAIRNESS_TEST)
/* 0 only when the active provider cannot yet return or report anything. */
int XE_NP_Np2FirstSyncRuntime_GridNeedsPoll(void);
#endif
#if defined(XE_NP_GRID_FAIRNESS_TEST) && XE_NP_GRID_FAIRNESS_TEST
#include "xe_np_imu_grid_admission.h"
int XE_NP_Np2FirstSyncRuntime_GridFairReady(void);
int XE_NP_Np2FirstSyncRuntime_GridFairInputs(XE_NP_GridAdmission *s);
#endif
#endif
/* Actual optional archive admission only. Counter/rate remain native; no
 * physical timestamp/offset/sample-lock is fabricated by this helper. */
void XE_NP_Np2FirstSyncRuntime_AuxAccepted(uint32_t id,uint64_t counter,uint8_t counter_bits,uint32_t rate_num,uint32_t rate_den);
/* Frozen exact receipt for this USB token only; NULL means pending/unknown.
 * No reserialization or mutable page cache is returned. */
const uint8_t *XE_NP_Np2FirstSyncRuntime_FrozenUsb(uint64_t token);
/* Existing stopped finalization buffer only; failed optional binding leaves
 * the valid legacy UTC2 bytes intact and cannot fail neural recording. */
void XE_NP_Np2FirstSyncRuntime_SdTime(uint8_t sector[512]);
#if !NP_FINE_COUNTER64_ENABLE
#define XE_NP_Np2FirstSyncRuntime_ClockBegin() 0
#define XE_NP_Np2FirstSyncRuntime_UsbPrepare(token,mask,hz,aux_mask,features) 0
#endif
#else
#define XE_NP_Np2FirstSyncRuntime_Init() ((void)0)
#define XE_NP_Np2FirstSyncRuntime_SdPrepare(nonce,session,mask,hz) ((void)0)
#define XE_NP_Np2FirstSyncRuntime_SdArmed() ((void)0)
#define XE_NP_Np2FirstSyncRuntime_SdOpted() 0
#define XE_NP_Np2FirstSyncRuntime_SdClockBegin() 0
#define XE_NP_Np2FirstSyncRuntime_ClockBegin() 0
#define XE_NP_Np2FirstSyncRuntime_FineBound(generation,source_epoch,before,after) 0
#define XE_NP_Np2FirstSyncRuntime_FineCounter64() 0
#define XE_NP_Np2FirstSyncRuntime_SdFineAnchor(out) 0
#define XE_NP_Np2FirstSyncRuntime_RtcFrozen() NULL
#define XE_NP_Np2FirstSyncRuntime_UsbPrepare(token,mask,hz,aux_mask,features) 0
#define XE_NP_Np2FirstSyncRuntime_Stop() ((void)0)
#define XE_NP_Np2FirstSyncRuntime_Service() ((void)0)
#define XE_NP_Np2FirstSyncRuntime_SdTime(sector) ((void)0)
#endif
#endif
