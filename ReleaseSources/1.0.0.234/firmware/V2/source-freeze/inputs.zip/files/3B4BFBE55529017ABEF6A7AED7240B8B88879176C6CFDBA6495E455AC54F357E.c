#include "xe_np_np2_sd_fine_clock.h"
#include "xe_np_np2_first_sync_runtime.h"
#include "xe_np_np2_first_sync_sd.h"
#include "xe_np_np2_first_word.h"
#include "xe_np_np2_first_sync_port.h"
#include "xe_np_np2_capture_port.h"
#include "xe_np_np2_dma_events.h"
#if XE_NP_NP2_CAPTURE_PORT_ENABLE
#include "main.h"
#include "xe_np_np2_d8_copy.h"
#include "xe_np_np2_d8_calibration.h"
#include <string.h>
#if XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
#include "xe_np_np2_closed_loop_capture_proof.h"
static void cl_capture_clear(void);
static void cl_capture_calibrated(int,uint32_t,uint32_t,uint32_t);
#endif
#if !XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || (XE_NP_BOARD_NP2_CAPTURE_PROFILE_COUNT != 1U)
#error "NP2 capture port requires exactly one explicit NP2 capture clock profile"
#endif
extern DCACHE_HandleTypeDef hdcache1;
static XE_NP_Np2Producer producer;
static uint64_t stop_ticks;
static DMA_HandleTypeDef dma;
static DMA_QListTypeDef queue;
static volatile uint32_t setup_stage;
static XE_NP_AcquisitionAnchor acquisition_anchor;
static XE_NP_CycleClockState cycle_clock;
#define NP2_PORT_DIRECT_PSSI \
    (XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST)
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
static volatile uint32_t runtime_direct_prepared,runtime_direct_retired_rus;
static volatile uint32_t runtime_direct_published_low,runtime_direct_capture_active;
static volatile uint32_t runtime_spi_total,runtime_spi_offset;
#define direct_prepared runtime_direct_prepared
#define direct_retired_rus runtime_direct_retired_rus
#define direct_published_low runtime_direct_published_low
#define direct_capture_active runtime_direct_capture_active
#endif
volatile XE_NP_Np2Spi2D8Diag xe_np_np2_spi2_d8_diag;
#ifndef XE_NP_NP2_SPI2_D8_DIAG_CPHA
#define XE_NP_NP2_SPI2_D8_DIAG_CPHA SPI_PHASE_1EDGE
#endif
#ifndef XE_NP_NP2_SPI2_D8_SECOND_EDGE_TEST
#define XE_NP_NP2_SPI2_D8_SECOND_EDGE_TEST 0U
#endif
#if XE_NP_NP2_SPI2_D8_SECOND_EDGE_TEST && !XE_NP_NP2_LIVE_SD_DIRECT
#error "Alternate D8 receive phase is restricted to the direct SD diagnostic"
#endif
#define NP2_SPI2_CAPTURE_PHASE (XE_NP_NP2_SPI2_D8_SECOND_EDGE_TEST ? SPI_PHASE_2EDGE : SPI_PHASE_1EDGE)
#ifndef XE_NP_NP2_STARTUP_PREROLL_TEST
#define XE_NP_NP2_STARTUP_PREROLL_TEST 0U
#endif
#if XE_NP_NP2_STARTUP_PREROLL_TEST && !XE_NP_NP2_LIVE_SD_DIRECT
#error "DMA pre-roll requires the direct SD diagnostic"
#endif
#if XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE && XE_NP_NP2_SPI2_D8_DIAG_ENABLE
#error "SPI2 D8 production capture and bounded diagnostic are mutually exclusive"
#endif
#if (XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE != 0U) && (XE_NP_NP2_CAPTURE_16BIT_PSSI != 0U)
#error "SPI2 D8 production capture requires eight-bit PSSI ingress"
#endif
#if XE_NP_NP2_SD_RAW_INGRESS_RU_TEST && \
    (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES)
#error "Raw-ingress RU trial is restricted to the copied runtime SD APP"
#endif
#ifndef XE_NP_NP2_SD_UNUSED_PSSI_ANALOG_TEST
#define XE_NP_NP2_SD_UNUSED_PSSI_ANALOG_TEST 0U
#endif
#if (XE_NP_NP2_SD_UNUSED_PSSI_ANALOG_TEST!=0U && XE_NP_NP2_SD_UNUSED_PSSI_ANALOG_TEST!=1U) || \
    (XE_NP_NP2_SD_UNUSED_PSSI_ANALOG_TEST && \
     (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
      !XE_NP_NP2_SD_UNUSED_PROBE_POWERDOWN_TEST || XE_NP_NP2_LIVE_SD_DIRECT || \
      XE_NP_NP2_STAGED_CAPTURE || XE_NP_V2_MEDIA_ENABLE || XE_NP_V2_AUX_ENABLE || \
      XE_NP_NP2_SD_RAW_INGRESS_RU_TEST))
#error "Unused PSSI input trial requires the original copied neural SD APP with unused probes asleep"
#endif
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
#if !XE_NP_NP2_LIVE_SD_ENABLE || XE_NP_NP2_LIVE_SD_DIRECT || \
    !XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE || XE_NP_NP2_SPI2_D8_DIAG_ENABLE || \
    XE_NP_NP2_CAPTURE_16BIT_PSSI || XE_NP_NP2_CAPTURE_BYTE_DMA || \
    !XE_NP_CAPTURE_SRAM3_MPU_NONCACHEABLE || \
    XE_NP_NP2_RING_BYTES!=(XE_NP_NP2_SD_RAW_INGRESS_RU_TEST?552960U:737280U) || \
    XE_NP_NP2_NODE_BYTES!=61440U || XE_NP_NP2_FULL_NODE_IRQ || \
    XE_NP_NP2_IRQ_REPEAT_BLOCKS!=1U || \
    XE_NP_NP2_SOURCE_BYTE_RATE_HZ!=(XE_NP_NP2_DUAL_SD_APP_ENABLE?12000000UL:24000000UL)
#error "Runtime copied capture requires the common PSSI8/HT ring, D8 capacity and minimum source-rate stall bound"
#endif
static uint8_t capture_profile_d8;
static uint32_t capture_profile_sample_hz;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
static uint8_t capture_profile_direct;
#endif
#if XE_NP_NP2_SD_UNUSED_PSSI_ANALOG_TEST
static uint32_t capture_profile_mask;
#endif
#endif
#if (XE_NP_NP2_SPI2_D8_DIAG_ENABLE != 0U)
uint8_t xe_np_np2_spi2_d8_samples[XE_NP_NP2_SPI2_D8_DIAG_BYTES]
    __attribute__((aligned(32),section("NP_CAPTURE")));
#endif
#if (XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE != 0U)
#if XE_NP_NP2_LIVE_SD_DIRECT
#if !XE_NP_NP2_LIVE_SD_ENABLE || !XE_NP_CAPTURE_SRAM3_MPU_NONCACHEABLE || \
    XE_NP_NP2_NODE_BYTES != NP2_DIRECT_TICKS || XE_NP_NP2_RING_BYTES != NP2_DIRECT_RING_TICKS
#error "Direct DMA capture requires the exclusive live SD layout and exact logical ring geometry"
#endif
#define spi2_d8_ring (XE_NP_Np2DirectBlock(0U)+512U+NP2_DIRECT_TICKS)
#define SPI2_D8_NODE_BYTES NP2_DIRECT_D8_BYTES
#define SPI2_D8_NODE_COUNT NP2_DIRECT_SLOTS
#define SPI2_D8_CHECK_BYTES SPI2_D8_NODE_BYTES
#define NP2_DIRECT_RU_TICKS (4U*NP2_DIRECT_TICKS)
#define NP2_DIRECT_RU_COUNT (NP2_DIRECT_RING_TICKS/NP2_DIRECT_RU_TICKS)
_Static_assert(NP2_DIRECT_RING_TICKS%NP2_DIRECT_RU_TICKS==0U,
               "direct SD retirement units must tile the producer ring");
static uint32_t spi2_direct_total;
static uint32_t spi2_direct_offset;
static volatile uint32_t direct_prepared,direct_retired_rus;
static volatile uint32_t direct_published_low;
static volatile uint32_t direct_capture_active;
#else
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
/* Physical RU4 is an exclusive stopped-selected overlay. The gap after the
 * PSSI ring contains BLE/config state, so it is NOT available to D8. The
 * writer removes RU4 from its logical map for mask7; no extra capture BSS. */
#define spi2_d8_ring ((uint8_t *)0x2018C800UL)
#else
static uint8_t spi2_d8_ring[XE_NP_NP2_SPI2_D8_RING_BYTES]
    __attribute__((aligned(32),section("NP_CAPTURE")));
#endif
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
#define NP2_DIRECT_RU_TICKS (4U*NP2_DIRECT_TICKS)
#define NP2_DIRECT_RU_COUNT (NP2_DIRECT_RING_TICKS/NP2_DIRECT_RU_TICKS)
_Static_assert(NP2_DIRECT_RU_COUNT==NP2_RUNTIME_DIRECT_CAPTURE_RUS,
               "runtime direct PSSI must retain exactly eight capture RUs");
#endif
#define SPI2_D8_NODE_BYTES (XE_NP_NP2_SPI2_D8_RING_BYTES/2U)
#define SPI2_D8_NODE_COUNT 2U
#define SPI2_D8_CHECK_BYTES XE_NP_NP2_SPI2_D8_RING_BYTES
#endif
static __attribute__((aligned(128),section("NP2_DMA_DESCRIPTORS")))
    DMA_NodeTypeDef spi2_d8_nodes[SPI2_D8_NODE_COUNT+XE_NP_NP2_STARTUP_PREROLL_TEST];
static DMA_QListTypeDef spi2_d8_queue;
_Static_assert(SPI2_D8_NODE_BYTES<=65535U,"SPI2 D8 node exceeds GPDMA block size");
static uint32_t spi2_d8_offset_bits=UINT32_MAX;
#endif
#if (XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE != 0U) || (XE_NP_NP2_SPI2_D8_DIAG_ENABLE != 0U)
static SPI_HandleTypeDef spi2_d8;
static DMA_HandleTypeDef spi2_d8_dma;
#endif
static struct {uint32_t cfgr1,cfgr2,pllcfgr,plldivr,pllfracr,ready_mask;uint8_t valid;} clock_guard;
#if (XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE != 0U) || (XE_NP_NP2_SPI2_D8_DIAG_ENABLE != 0U)
static int spi2_d8_begin(void);
static void spi2_d8_stop(void);
static int spi2_d8_clock(void)
{
    /* PA8/MCO drives the shared PB13/PD9 clock net. SPI2 only samples it;
     * select a bounded HSE-derived kernel, not a second SCK generator. */
    uint32_t sys_hz=HAL_RCC_GetSysClockFreq();
    uint32_t kernel_hz=sys_hz<=160000000U?sys_hz:HAL_RCC_GetPCLK1Freq();
    uint32_t bit_hz=XE_NP_Board_GetRuntimeExpectedMcoHz();
    xe_np_np2_spi2_d8_diag.kernel_hz=kernel_hz;
    xe_np_np2_spi2_d8_diag.bit_hz=bit_hz;
    if(!bit_hz || bit_hz>kernel_hz/2U || kernel_hz>160000000U)return -1;
    __HAL_RCC_SPI2_CONFIG(sys_hz<=160000000U?RCC_SPI2CLKSOURCE_SYSCLK:RCC_SPI2CLKSOURCE_PCLK1);
    __HAL_RCC_SPI2_CLK_ENABLE();
    __HAL_RCC_SPI2_FORCE_RESET();__HAL_RCC_SPI2_RELEASE_RESET();
    return 0;
}
#endif
#if (XE_NP_CAPTURE_SRAM3_MPU_NONCACHEABLE != 0U)
static int in_noncacheable_capture_arena(const uint8_t *data,uint32_t bytes)
{
    /* Matches XE_NP_CAPTURE_SRAM3_* and the dedicated image scatter file.
     * Keep this port independent of the larger legacy capture header so its
     * standalone HAL model continues to exercise the production DMA adapter. */
    uintptr_t start=(uintptr_t)data,end=start+(uintptr_t)bytes;
#if XE_NP_NP2_LIVE_SD_DIRECT
    (void)start;(void)end;
    return XE_NP_Np2DirectContains(data,bytes);
#else
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
    return data && end>=start &&
        ((start>=0x200D0000UL && end<=0x200D0000UL+XE_NP_NP2_RING_BYTES) ||
         (start>=0x2018C800UL && end<=0x201A3000UL));
#else
    return data && end>=start && start>=0x200D0000UL && end<=0x201A0000UL;
#endif
#endif
}
#endif
/* Legacy queues fit an aligned 1 KiB window; direct-record capture uses
 * 48 nodes in 4 KiB. The scatter/map gate keeps both lanes' descriptors
 * within GPDMA's 64 KiB link window. */
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
#define NP2_DMA_NODE_COUNT NP2_DIRECT_SLOTS
#define NP2_COPIED_NODE_COUNT \
    (XE_NP_NP2_RING_BYTES/(XE_NP_NP2_NODE_BYTES*XE_NP_NP2_IRQ_REPEAT_BLOCKS))
#define NP2_CAPTURE_NODE_COUNT (capture_profile_direct?NP2_DIRECT_SLOTS:NP2_COPIED_NODE_COUNT)
#define NP2_CAPTURE_NODE_BYTES (capture_profile_direct?NP2_DIRECT_TICKS:XE_NP_NP2_NODE_BYTES)
#define NP2_CAPTURE_RING_BYTES (capture_profile_direct?NP2_DIRECT_RING_TICKS:XE_NP_NP2_RING_BYTES)
#else
#define NP2_DMA_NODE_COUNT \
    (XE_NP_NP2_RING_BYTES/(XE_NP_NP2_NODE_BYTES*XE_NP_NP2_IRQ_REPEAT_BLOCKS))
#define NP2_CAPTURE_NODE_COUNT NP2_DMA_NODE_COUNT
#define NP2_CAPTURE_NODE_BYTES XE_NP_NP2_NODE_BYTES
#define NP2_CAPTURE_RING_BYTES XE_NP_NP2_RING_BYTES
#endif
#if XE_NP_NP2_LIVE_SD_DIRECT && (XE_NP_NP2_IRQ_REPEAT_BLOCKS > 1U)
#define NP2_DMA_BLOCK_DEST_GAP_BYTES (NP2_DIRECT_SLOT_BYTES-NP2_DIRECT_TICKS)
_Static_assert(XE_NP_NP2_IRQ_REPEAT_BLOCKS==4U,
               "direct repeated-block DMA must map one complete four-block RU");
_Static_assert(NP2_DMA_BLOCK_DEST_GAP_BYTES<=65535U,
               "direct repeated-block destination gap exceeds GPDMA range");
#else
#define NP2_DMA_BLOCK_DEST_GAP_BYTES 0U
#endif
#if XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
#define NP2_DESCRIPTOR_ALIGN 4096U
#else
#define NP2_DESCRIPTOR_ALIGN 1024U
#endif
static __attribute__((aligned(NP2_DESCRIPTOR_ALIGN),section("NP2_DMA_DESCRIPTORS"))) DMA_NodeTypeDef nodes[NP2_DMA_NODE_COUNT+XE_NP_NP2_STARTUP_PREROLL_TEST];
_Static_assert(sizeof(nodes)<=NP2_DESCRIPTOR_ALIGN,"GPDMA descriptors must fit one aligned link window");
#define DMA_ERROR_FLAGS (DMA_FLAG_DTE|DMA_FLAG_ULE|DMA_FLAG_USE|DMA_FLAG_TO)
#define DMA_LIVE_FAULTS (DMA_ERROR_FLAGS|DMA_FLAG_SUSP)
#define PORT_STOP_FAULT 0x80000000U
/* The documented NP2 sampling edge is rising. Permit the other edge only in
 * the isolated bring-up image or an explicitly bounded direct-SD experiment;
 * normal USB/live recording profiles cannot silently select it. */
#ifndef XE_NP_NP2_DIAG_FALLING_EDGE
#define XE_NP_NP2_DIAG_FALLING_EDGE 0U
#endif
#if XE_NP_NP2_DIAG_FALLING_EDGE && !XE_NP_NP2_PSSI_TEST_DIAG_ENABLE && \
    !(XE_NP_NP2_LIVE_SD_ENABLE && XE_NP_NP2_LIVE_SD_DIRECT)
#error "Alternate NP2 edge is restricted to isolated or bounded direct-SD diagnostics"
#endif
#ifndef XE_NP_NP2_DIAG_CLOCK_STOP_BEFORE_SUSP
#define XE_NP_NP2_DIAG_CLOCK_STOP_BEFORE_SUSP 0U
#endif
#ifndef XE_NP_NP2_USB_SOURCE_ENABLE
#define XE_NP_NP2_USB_SOURCE_ENABLE 0U
#endif
#ifndef XE_NP_NP2_CAPTURE_BYTE_DMA
#define XE_NP_NP2_CAPTURE_BYTE_DMA 0U
#endif
#ifndef XE_NP_NP2_CAPTURE_16BIT_PSSI
#define XE_NP_NP2_CAPTURE_16BIT_PSSI 0U
#endif
#if XE_NP_NP2_CAPTURE_16BIT_PSSI && XE_NP_NP2_CAPTURE_BYTE_DMA
#error "16-bit extended PSSI cannot use the single-lane byte-DMA source"
#endif
#ifndef XE_NP_NP2_CAPTURE_PORT0_TEST
#define XE_NP_NP2_CAPTURE_PORT0_TEST 0U
#endif
#if (XE_NP_NP2_CAPTURE_PORT0_TEST != 0U) && (XE_NP_NP2_CAPTURE_PORT0_TEST != 1U)
#error "NP2 capture port-allocation test accepts only 0 or 1"
#endif
#if XE_NP_NP2_CAPTURE_PORT0_TEST && \
    (!XE_NP_NP2_LIVE_SD_ENABLE || !XE_NP_NP2_LIVE_SD_VSC_TEST || \
     !XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST || !XE_NP_NP2_LIVE_SD_SPILL_HOLD_TEST || \
     XE_NP_NP2_CAPTURE_BYTE_DMA || XE_NP_NP2_CAPTURE_16BIT_PSSI)
#error "NP2 capture port0 test requires held direct-PSRAM live-VSC word-wide eight-bit PSSI"
#endif
#define NP2_DMA_DEST_PORT (XE_NP_NP2_CAPTURE_PORT0_TEST ? \
                           DMA_DEST_ALLOCATED_PORT0 : DMA_DEST_ALLOCATED_PORT1)
#define NP2_DMA_LINK_PORT (XE_NP_NP2_CAPTURE_PORT0_TEST ? \
                           DMA_LINK_ALLOCATED_PORT0 : DMA_LINK_ALLOCATED_PORT1)
#ifndef XE_NP_NP2_CAPTURE_DEST_BURST_TEST
#define XE_NP_NP2_CAPTURE_DEST_BURST_TEST 4U
#endif
#if XE_NP_NP2_CAPTURE_DEST_BURST_TEST != 1U && XE_NP_NP2_CAPTURE_DEST_BURST_TEST != 4U
#error "NP2 capture destination-burst test accepts only1 or4"
#endif
#if XE_NP_NP2_CAPTURE_DEST_BURST_TEST == 1U && \
    (XE_NP_NP2_CAPTURE_BYTE_DMA || XE_NP_NP2_CAPTURE_16BIT_PSSI)
#error "NP2 destination-burst test requires word-wide eight-bit PSSI"
#endif
#if XE_NP_NP2_DIAG_CLOCK_STOP_BEFORE_SUSP && !XE_NP_NP2_PSSI_TEST_DIAG_ENABLE && !XE_NP_NP2_USB_SOURCE_ENABLE
#error "NP2 source-clock stop experiment requires the isolated diagnostic or USB source"
#endif
#define NP2_CLOCK_STOP_BEFORE_SUSP \
    ((XE_NP_NP2_DIAG_CLOCK_STOP_BEFORE_SUSP != 0U) || (XE_NP_NP2_USB_SOURCE_ENABLE != 0U))
#define NP2_PSSI_CKPOL (XE_NP_NP2_DIAG_FALLING_EDGE ? 0U : PSSI_CR_CKPOL)
#define NP2_PSSI_WIDTH (XE_NP_NP2_CAPTURE_16BIT_PSSI ? PSSI_CR_EDM : 0U)
#define PSSI_RUNNING (PSSI_CR_DMAEN|NP2_PSSI_CKPOL|NP2_PSSI_WIDTH|PSSI_CR_ENABLE)
#define CLOCK_READY_PLL (RCC_CR_HSEON|RCC_CR_HSERDY|RCC_CR_PLL1ON|RCC_CR_PLL1RDY)
#if (XE_NP_NP2_CAPTURE_BYTE_DMA != 0U)
/* The dedicated single-lane image uses PSSI's byte request/data path.  Its
 * consumer and ring positions are one byte per PDCK tick; this avoids
 * materializing a 32-bit word per tick when only D[5:3] is connected. */
#define NP2_DMA_SOURCE_WIDTH DMA_SRC_DATAWIDTH_BYTE
#define NP2_DMA_DEST_WIDTH DMA_DEST_DATAWIDTH_BYTE
#define NP2_DMA_DEST_BURST 1U
#elif (XE_NP_NP2_CAPTURE_16BIT_PSSI != 0U)
/* Extended PSSI still raises its DMA request at the documented four-byte FIFO
 * granule.  A word read therefore drains two adjacent 16-bit input ticks;
 * memory is little-endian and the triple codec reads them back as consecutive
 * uint16_t values.  A half-word DMA transaction leaves half the FIFO pending
 * and overflows at the 32 MHz source rate. */
#define NP2_DMA_SOURCE_WIDTH DMA_SRC_DATAWIDTH_WORD
#define NP2_DMA_DEST_WIDTH DMA_DEST_DATAWIDTH_WORD
#define NP2_DMA_DEST_BURST 4U
#else
/* Eight-bit PSSI still presents a four-byte receive FIFO word to GPDMA. A
 * word-wide peripheral read drains four adjacent byte samples into four
 * consecutive ring bytes; this is one stored byte per tick, not 32-bit
 * materialization. Byte DMA cannot drain the FIFO at 32/48 MHz. */
#define NP2_DMA_SOURCE_WIDTH DMA_SRC_DATAWIDTH_WORD
#define NP2_DMA_DEST_WIDTH DMA_DEST_DATAWIDTH_WORD
#define NP2_DMA_DEST_BURST XE_NP_NP2_CAPTURE_DEST_BURST_TEST
#endif

static uint32_t lock(void *unused)
{ (void)unused;uint32_t key=__get_PRIMASK();__disable_irq();__DMB();return key; }
static void unlock(void *unused,uint32_t key)
{ (void)unused;__DMB();__set_PRIMASK(key); }
static uint32_t now(void *unused) { (void)unused;return HAL_GetTick(); }
static int clock_ok(void)
{
    uint32_t sample_hz=XE_NP_Board_GetNp2SampleRateHz();
    uint32_t mco_hz=XE_NP_Board_GetRuntimeExpectedMcoHz();
    uint32_t mco_bits=XE_NP_Board_GetRuntimeMcoRegisterBits();
    uint32_t mco_source=mco_bits&RCC_CFGR1_MCOSEL;
    uint32_t hclk_hz=HAL_RCC_GetHCLKFreq();
    /* DS13633 Table114: receive PDCK/HCLK <=0.4. PDCK follows this MCO.
     * Check only before arm; power profiles must not exceed the input ratio. */
    return hclk_hz==XE_NP_Board_GetRuntimeCoreClockHz() &&
        HAL_RCC_GetSysClockFreq()==XE_NP_Board_GetRuntimeCoreClockHz() &&
        (sample_hz==15000U || sample_hz==20000U || sample_hz==30000U
#if XE_NP_NP2_DUAL_SD_APP_ENABLE && XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
         || sample_hz==7500U
#endif
        ) && mco_hz==sample_hz*1600U &&
        (uint64_t)mco_hz*5U<=(uint64_t)hclk_hz*2U &&
        (mco_source==RCC_MCO1SOURCE_PLL1CLK || mco_source==RCC_MCO1SOURCE_HSE) &&
        (RCC->PLL1CFGR&(RCC_PLL1CFGR_PLL1SRC|RCC_PLL1CFGR_PLL1REN))==(RCC_PLLSOURCE_HSE|RCC_PLL1CFGR_PLL1REN) &&
        (RCC->CFGR1&(RCC_CFGR1_MCOSEL|RCC_CFGR1_MCOPRE))==mco_bits;
}
static int clock_unchanged(void)
{
    /* HAL_RCC_GetSysClockFreq uses floating-point PLL arithmetic. Validate
     * once before arm, then compare its complete input registers in the hot
     * path. This still detects PLL/fractional/HCLK/MCO/source changes and loss
     * of ready flags, without floating point or division inside DMA IRQs. */
    return clock_guard.valid && RCC->CFGR1==clock_guard.cfgr1 && RCC->CFGR2==clock_guard.cfgr2 &&
        RCC->PLL1CFGR==clock_guard.pllcfgr && RCC->PLL1DIVR==clock_guard.plldivr &&
        RCC->PLL1FRACR==clock_guard.pllfracr &&
        (RCC->CR&clock_guard.ready_mask)==clock_guard.ready_mask;
}
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
/* Called only with the short producer lock held.  C9 remains the independent
 * copied lane in the runtime-direct profile, so its serial position must be
 * refreshed immediately before and after foreground D8 materialization. */
static int runtime_direct_d8_progress_locked(void)
{
    uintptr_t base=(uintptr_t)spi2_d8_ring,dar=GPDMA1_Channel9->CDAR;
    if(dar<base || dar>base+XE_NP_NP2_SPI2_D8_RING_BYTES)return -1;
    uint32_t position=(uint32_t)(dar-base);
    if(position==XE_NP_NP2_SPI2_D8_RING_BYTES)position=0U;
    uint32_t previous=runtime_spi_offset;
    uint32_t delta=position>=previous?position-previous:
        position+XE_NP_NP2_SPI2_D8_RING_BYTES-previous;
    runtime_spi_total+=delta*8U;runtime_spi_offset=position;
    return 0;
}

/* 0 means the serial lane has not reached this source start yet; -1 is an
 * overwritten source range.  Keep those distinct so foreground can wait for
 * C9 without converting an ordinary lead into a producer failure. */
static int runtime_direct_d8_retention_locked(uint32_t start)
{
    if(!XE_NP_Np2Producer_LowCounterReached(runtime_spi_total,start))return 0;
    return runtime_spi_total-start<XE_NP_NP2_SPI2_D8_RING_BYTES*8U?1:-1;
}
#endif
static void snapshot(void *unused,XE_NP_Np2DmaSnapshot *s)
{
    (void)unused;
    uint32_t before=GPDMA1_Channel12->CSR;
    uint32_t dar=GPDMA1_Channel12->CDAR;
    uint32_t after=GPDMA1_Channel12->CSR;
    uint32_t flags=before|after;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    s->offset=capture_profile_direct?XE_NP_Np2DirectOffset(dar,0U):dar-0x200D0000U;
#elif XE_NP_NP2_LIVE_SD_DIRECT
    s->offset=XE_NP_Np2DirectOffset(dar,0U);
#else
    s->offset=dar-0x200D0000U;
#endif
    /* Direct SD leaves HTIE off; the shared policy ignores sticky HT until
     * full-node TC and is also used by final-stop diagnostics below. */
    s->events=XE_NP_Np2DmaEventsFromFlags(flags,DMA_FLAG_HT,DMA_FLAG_TC);
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(capture_profile_direct)s->events&=XE_NP_NP2_EVENT_TC;
#endif
    /* A completed suspension while live was not requested by us, so it is a
     * fault here. stop() handles its own requested suspension separately. */
    s->fault=(flags&DMA_LIVE_FAULTS)|(PSSI->RIS&PSSI_RIS_OVR_RIS);
#if (XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE != 0U) && !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
    if(!(GPDMA1_Channel9->CCR&DMA_CCR_EN) || (GPDMA1_Channel9->CSR&DMA_ERROR_FLAGS) ||
       !(SPI2->CR1&SPI_CR1_SPE) || !(SPI2->CFG1&SPI_CFG1_RXDMAEN) ||
       (SPI2->SR&SPI_FLAG_OVR) || xe_np_np2_spi2_d8_diag.error)s->fault|=0x40000000U;
#endif
    if(!clock_unchanged() || PSSI->CR!=PSSI_RUNNING || !(NP_NRST_GPIO_Port->ODR&NP_NRST_Pin) ||
       !(VCC_EN_GPIO_Port->ODR&VCC_EN_Pin))s->fault|=0x80000000U;
    s->active=(GPDMA1_Channel12->CCR&DMA_CCR_EN)?1U:0U;s->now_ms=HAL_GetTick();
}
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
/* Bind selects this callback only for triple. Dual IRQs retain the original
 * PSSI-only snapshot without a runtime SPI-health branch or MMIO reads. */
static void snapshot_d8(void *unused,XE_NP_Np2DmaSnapshot *s)
{
    snapshot(unused,s);
    if(!(GPDMA1_Channel9->CCR&DMA_CCR_EN) || (GPDMA1_Channel9->CSR&DMA_ERROR_FLAGS) ||
       !(SPI2->CR1&SPI_CR1_SPE) || !(SPI2->CFG1&SPI_CFG1_RXDMAEN) ||
       (SPI2->SR&SPI_FLAG_OVR) || xe_np_np2_spi2_d8_diag.error)s->fault|=0x40000000U;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(capture_profile_direct && !s->fault) {
        if(runtime_direct_d8_progress_locked()!=0)s->fault|=0x40000000U;
    }
#endif
}
#endif
static void irq_recheck(void *unused,XE_NP_Np2DmaSnapshot *s)
{
    (void)unused;
    uint32_t before=GPDMA1_Channel12->CSR;
    uint32_t after=GPDMA1_Channel12->CSR;
    uint32_t flags=before|after;
    s->events=XE_NP_Np2DmaEventsFromFlags(flags,DMA_FLAG_HT,DMA_FLAG_TC);
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(capture_profile_direct)s->events&=XE_NP_NP2_EVENT_TC;
#endif
    s->fault=(flags&DMA_LIVE_FAULTS)|(PSSI->RIS&PSSI_RIS_OVR_RIS);
    /* The full pre-ack snapshot just checked the independent SPI2-D8 lane.
     * Its DMA error and SPI overrun flags are sticky until explicitly cleared,
     * so rereading six SPI/channel state registers here adds no race coverage.
     * Keep this post-W1C pass narrow: only catch a new PSSI/GPDMA12 event or
     * fault that arrived around acknowledgement/publication. */
    s->active=(GPDMA1_Channel12->CCR&DMA_CCR_EN)?1U:0U;
}
static void ack(void *unused,uint32_t event)
{
    (void)unused;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(capture_profile_direct && event==XE_NP_NP2_EVENT_TC){
        GPDMA1_Channel12->CFCR=DMA_FLAG_HT|DMA_FLAG_TC;__DSB();return;
    }
    GPDMA1_Channel12->CFCR=XE_NP_Np2DmaAckFlags(event,DMA_FLAG_HT,DMA_FLAG_TC);__DSB();return;
#elif XE_NP_NP2_FULL_NODE_IRQ
    GPDMA1_Channel12->CFCR=XE_NP_Np2DmaAckFlags(event,DMA_FLAG_HT,DMA_FLAG_TC);__DSB();return;
#else
    GPDMA1_Channel12->CFCR=XE_NP_Np2DmaAckFlags(event,DMA_FLAG_HT,DMA_FLAG_TC);
    __DSB();
#endif
}
static void latch_stop_status(XE_NP_Np2DmaSnapshot *last)
{
    uint32_t flags=GPDMA1_Channel12->CSR;
    last->fault|=(flags&DMA_ERROR_FLAGS)|(PSSI->RIS&PSSI_RIS_OVR_RIS);
    last->events|=XE_NP_Np2DmaEventsFromFlags(flags,DMA_FLAG_HT,DMA_FLAG_TC);
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(capture_profile_direct)last->events&=XE_NP_NP2_EVENT_TC;
#endif
}
static void stop(void *unused,XE_NP_Np2DmaSnapshot *last)
{
    XE_NP_Np2FirstSyncPort_Invalidate();
#if XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
    cl_capture_clear();
#endif
    (void)unused;
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
    producer.hw.snapshot(NULL,last);
#else
    snapshot(NULL,last);
#endif
    /* Quiesce under PRIMASK: retain status before RESET clears DMA evidence.
     * Previously committed spans are immutable; no in-flight tail is exported.
     * Do not free/reuse ring/descriptors until a fresh boot. The register
     * polls below are bounded and do not depend on HAL/SysTick while PRIMASK
     * is held. GPDMA RESET is only valid once the channel is suspended or
     * already disabled. */
    HAL_NVIC_DisableIRQ(GPDMA1_Channel12_IRQn);HAL_NVIC_DisableIRQ(DCMI_PSSI_IRQn);
    PSSI->IER=0U;
    /* Keep the peripheral request path and the source clock alive until GPDMA
     * acknowledges suspension.  Removing PSSI ENABLE/DMAEN (or stopping MCO)
     * first can strand an already asserted peripheral request and raises DTE.
     * The final partial DMA span is intentionally discarded by the producer. */
    int settled=!(GPDMA1_Channel12->CCR&DMA_CCR_EN);
    if(!settled) {
        SET_BIT(GPDMA1_Channel12->CCR,DMA_CCR_SUSP);__DSB();
        for(uint32_t i=0;i<1024U && !(GPDMA1_Channel12->CSR&DMA_FLAG_SUSP) &&
            (GPDMA1_Channel12->CCR&DMA_CCR_EN);i++)__NOP();
        settled=(GPDMA1_Channel12->CSR&DMA_FLAG_SUSP) || !(GPDMA1_Channel12->CCR&DMA_CCR_EN);
    }
    /* Capture any final real DMA/PSSI fault and event before RESET clears
     * status. SUSP is expected only after the request above and is therefore
     * deliberately excluded from this post-quiesce diagnostic. */
    latch_stop_status(last);
    if(settled) {
        /* SUSPF means no transfer is in flight, so request and source-clock
         * gates may now be removed without manufacturing a terminal DTE. */
        CLEAR_BIT(PSSI->CR,PSSI_CR_ENABLE|PSSI_CR_DMAEN);
#if NP2_CLOCK_STOP_BEFORE_SUSP
        MODIFY_REG(RCC->CFGR1,RCC_CFGR1_MCOSEL|RCC_CFGR1_MCOPRE,
                   RCC_MCO1SOURCE_NOCLOCK|RCC_MCODIV_1);
#endif
#if (XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE != 0U) || (XE_NP_NP2_SPI2_D8_DIAG_ENABLE != 0U)
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
        if(capture_profile_d8){
#endif
        spi2_d8_stop();
#if (XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE != 0U)
        if(xe_np_np2_spi2_d8_diag.error)last->fault|=0x40000000U;
#endif
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
        }
#endif
#endif
        HAL_GPIO_WritePin(NP_NRST_GPIO_Port,NP_NRST_Pin,GPIO_PIN_RESET);
        __DSB();
#if NP2_CLOCK_STOP_BEFORE_SUSP
        if((RCC->CFGR1&(RCC_CFGR1_MCOSEL|RCC_CFGR1_MCOPRE))!=
           (RCC_MCO1SOURCE_NOCLOCK|RCC_MCODIV_1))last->fault|=PORT_STOP_FAULT;
#endif
        latch_stop_status(last);
        SET_BIT(GPDMA1_Channel12->CCR,DMA_CCR_RESET);__DSB();
        for(uint32_t i=0;i<1024U && (GPDMA1_Channel12->CCR&DMA_CCR_EN);i++)__NOP();
    }
    /* RESET normally clears status. Read again nonetheless: a late peripheral
     * or DMA fault must not disappear between the pre-reset observation and
     * the disabled-channel check. */
    latch_stop_status(last);
    if(GPDMA1_Channel12->CCR&DMA_CCR_EN)last->fault|=PORT_STOP_FAULT;
    /* If suspension timed out, retain PSSI, DMAEN, source clock, and NRST.
     * That is intentionally fail-closed: the still-live DMA owns the ring and
     * no caller may certify or reuse it until a fresh boot. */
    if(!settled)last->fault|=PORT_STOP_FAULT;
    __DSB();latch_stop_status(last);
    HAL_NVIC_ClearPendingIRQ(GPDMA1_Channel12_IRQn);HAL_NVIC_ClearPendingIRQ(DCMI_PSSI_IRQn);
    /* RESET requests cancellation asynchronously. Keep active set if hardware
     * hasn't actually stopped yet, so stopped_status cannot certify a stop. */
    last->active=(GPDMA1_Channel12->CCR&DMA_CCR_EN)?1U:0U;
}
static int invalidate(void *unused,const uint8_t *data,uint32_t bytes)
{
    (void)unused;
#if (XE_NP_CAPTURE_SRAM3_MPU_NONCACHEABLE != 0U)
    /* The dedicated recorder maps the complete PSSI producer arena as
     * non-cacheable before any peripheral is initialized.  A cache command
     * can otherwise contend with the preceding clean or invalidate and make
     * a healthy producer look terminally faulty.  Keep the address guard:
     * this callback is allowed to waive maintenance only for the DMA ring,
     * never for arbitrary application memory. */
    if(!in_noncacheable_capture_arena(data,bytes))return -1;
    __DMB();
    return 0;
#else
    return HAL_DCACHE_InvalidateByAddr(&hdcache1,(const uint32_t*)data,(bytes+31U)&~31U)==HAL_OK?0:-1;
#endif
}
static void unexpected_callback(DMA_HandleTypeDef *handle)
{
    (void)handle;
    /* Only our ordered IRQ handler may publish progress. This callback exists
     * so HAL enables HT interrupts; it is never a second accounting path. */
    XE_NP_Np2Producer_Abort(&producer);
#if XE_NP_NP2_LIVE_SD_DIRECT
    direct_capture_active=0U;__DMB();
#endif
}
#if (XE_NP_NP2_SPI2_D8_DIAG_ENABLE != 0U)
enum { SPI2_D8_DIAG_CONFIGURED=1U, SPI2_D8_DIAG_CAPTURING=2U,
       SPI2_D8_DIAG_STOPPED=3U, SPI2_D8_DIAG_COMPLETE=4U,
       SPI2_D8_DIAG_FAILED=255U };

static void spi2_d8_latch(uint32_t state)
{
    uint32_t remaining=GPDMA1_Channel9->CBR1&DMA_CBR1_BNDT;
    xe_np_np2_spi2_d8_diag.state=state;
    xe_np_np2_spi2_d8_diag.dma_csr=GPDMA1_Channel9->CSR;
    xe_np_np2_spi2_d8_diag.dma_remaining=remaining;
    xe_np_np2_spi2_d8_diag.bytes_captured=
        remaining<=XE_NP_NP2_SPI2_D8_DIAG_BYTES?
        XE_NP_NP2_SPI2_D8_DIAG_BYTES-remaining:0U;
    xe_np_np2_spi2_d8_diag.spi_sr=SPI2->SR;
    xe_np_np2_spi2_d8_diag.spi_cr1=SPI2->CR1;
    xe_np_np2_spi2_d8_diag.spi_cfg1=SPI2->CFG1;
    xe_np_np2_spi2_d8_diag.spi_cfg2=SPI2->CFG2;
}

static int spi2_d8_begin(void)
{
    memset((void *)&xe_np_np2_spi2_d8_diag,0,sizeof(xe_np_np2_spi2_d8_diag));
    xe_np_np2_spi2_d8_diag.magic=XE_NP_NP2_SPI2_D8_DIAG_MAGIC;
    xe_np_np2_spi2_d8_diag.version=1U;
    xe_np_np2_spi2_d8_diag.buffer_address=(uint32_t)(uintptr_t)xe_np_np2_spi2_d8_samples;
    xe_np_np2_spi2_d8_diag.buffer_capacity=XE_NP_NP2_SPI2_D8_DIAG_BYTES;
    xe_np_np2_spi2_d8_diag.cpol=SPI_POLARITY_LOW;
    xe_np_np2_spi2_d8_diag.cpha=XE_NP_NP2_SPI2_D8_DIAG_CPHA;
    xe_np_np2_spi2_d8_diag.first_bit=SPI_FIRSTBIT_LSB;
    xe_np_np2_spi2_d8_diag.calibrated_offset_bits=UINT32_MAX;
    if((GPDMA1_Channel9->CCR&DMA_CCR_EN) || (SPI2->CR1&SPI_CR1_SPE)) {
        xe_np_np2_spi2_d8_diag.error=1U;spi2_d8_latch(SPI2_D8_DIAG_FAILED);return -1;
    }

    if(spi2_d8_clock()!=0) {
        xe_np_np2_spi2_d8_diag.error=2U;spi2_d8_latch(SPI2_D8_DIAG_FAILED);return -1;
    }

    spi2_d8.Instance=SPI2;
    spi2_d8.Init.Mode=SPI_MODE_SLAVE;
    spi2_d8.Init.Direction=SPI_DIRECTION_2LINES_RXONLY;
    spi2_d8.Init.DataSize=SPI_DATASIZE_8BIT;
    spi2_d8.Init.CLKPolarity=SPI_POLARITY_LOW;
    spi2_d8.Init.CLKPhase=XE_NP_NP2_SPI2_D8_DIAG_CPHA;
    spi2_d8.Init.NSS=SPI_NSS_SOFT;
    spi2_d8.Init.BaudRatePrescaler=SPI_BAUDRATEPRESCALER_2;
    spi2_d8.Init.FirstBit=SPI_FIRSTBIT_LSB;
    spi2_d8.Init.TIMode=SPI_TIMODE_DISABLE;
    spi2_d8.Init.CRCCalculation=SPI_CRCCALCULATION_DISABLE;
    spi2_d8.Init.CRCPolynomial=7U;
    spi2_d8.Init.NSSPMode=SPI_NSS_PULSE_DISABLE;
    spi2_d8.Init.NSSPolarity=SPI_NSS_POLARITY_LOW;
    spi2_d8.Init.FifoThreshold=SPI_FIFO_THRESHOLD_01DATA;
    spi2_d8.Init.MasterSSIdleness=SPI_MASTER_SS_IDLENESS_00CYCLE;
    spi2_d8.Init.MasterInterDataIdleness=SPI_MASTER_INTERDATA_IDLENESS_00CYCLE;
    spi2_d8.Init.MasterReceiverAutoSusp=SPI_MASTER_RX_AUTOSUSP_DISABLE;
    spi2_d8.Init.MasterKeepIOState=SPI_MASTER_KEEP_IO_STATE_DISABLE;
    spi2_d8.Init.IOSwap=SPI_IO_SWAP_DISABLE;
    spi2_d8.Init.ReadyMasterManagement=SPI_RDY_MASTER_MANAGEMENT_INTERNALLY;
    spi2_d8.Init.ReadyPolarity=SPI_RDY_POLARITY_HIGH;
    if(HAL_SPI_Init(&spi2_d8)!=HAL_OK) {
        xe_np_np2_spi2_d8_diag.error=3U;spi2_d8_latch(SPI2_D8_DIAG_FAILED);return -1;
    }
    CLEAR_BIT(SPI2->CR1,SPI_CR1_SSI); /* Software NSS active, MOSI is input. */

    spi2_d8_dma.Instance=GPDMA1_Channel9;
    spi2_d8_dma.Init.Request=GPDMA1_REQUEST_SPI2_RX;
    spi2_d8_dma.Init.BlkHWRequest=DMA_BREQ_SINGLE_BURST;
    spi2_d8_dma.Init.Direction=DMA_PERIPH_TO_MEMORY;
    spi2_d8_dma.Init.SrcInc=DMA_SINC_FIXED;
    spi2_d8_dma.Init.DestInc=DMA_DINC_INCREMENTED;
    spi2_d8_dma.Init.SrcDataWidth=DMA_SRC_DATAWIDTH_BYTE;
    spi2_d8_dma.Init.DestDataWidth=DMA_DEST_DATAWIDTH_BYTE;
    spi2_d8_dma.Init.Priority=DMA_HIGH_PRIORITY;
    spi2_d8_dma.Init.SrcBurstLength=1U;
    spi2_d8_dma.Init.DestBurstLength=1U;
    spi2_d8_dma.Init.TransferAllocatedPort=DMA_SRC_ALLOCATED_PORT0|DMA_DEST_ALLOCATED_PORT1;
    spi2_d8_dma.Init.TransferEventMode=DMA_TCEM_BLOCK_TRANSFER;
    spi2_d8_dma.Init.Mode=DMA_NORMAL;
    if(HAL_DMA_Init(&spi2_d8_dma)!=HAL_OK) {
        xe_np_np2_spi2_d8_diag.error=4U;spi2_d8_latch(SPI2_D8_DIAG_FAILED);return -1;
    }
    __HAL_LINKDMA(&spi2_d8,hdmarx,spi2_d8_dma);
    HAL_NVIC_DisableIRQ(GPDMA1_Channel9_IRQn);
    HAL_NVIC_ClearPendingIRQ(GPDMA1_Channel9_IRQn);
    spi2_d8_latch(SPI2_D8_DIAG_CONFIGURED);
    if(HAL_SPI_Receive_DMA(&spi2_d8,xe_np_np2_spi2_d8_samples,
                          (uint16_t)XE_NP_NP2_SPI2_D8_DIAG_BYTES)!=HAL_OK) {
        xe_np_np2_spi2_d8_diag.error=5U;spi2_d8_latch(SPI2_D8_DIAG_FAILED);return -1;
    }
    spi2_d8_latch(SPI2_D8_DIAG_CAPTURING);
    return 0;
}

static void spi2_d8_stop(void)
{
    uint32_t state=(GPDMA1_Channel9->CSR&DMA_FLAG_TC)?SPI2_D8_DIAG_COMPLETE:SPI2_D8_DIAG_STOPPED;
    spi2_d8_latch(state);
    CLEAR_BIT(SPI2->CFG1,SPI_CFG1_RXDMAEN);
    CLEAR_BIT(SPI2->IER,SPI_IT_OVR|SPI_IT_FRE|SPI_IT_MODF);
    if(GPDMA1_Channel9->CCR&DMA_CCR_EN) {
        SET_BIT(GPDMA1_Channel9->CCR,DMA_CCR_SUSP);__DSB();
        for(uint32_t i=0;i<1024U && !(GPDMA1_Channel9->CSR&DMA_FLAG_SUSP) &&
            (GPDMA1_Channel9->CCR&DMA_CCR_EN);i++)__NOP();
    }
    spi2_d8_latch(state);
    CLEAR_BIT(SPI2->CR1,SPI_CR1_SPE);
    if((GPDMA1_Channel9->CSR&DMA_ERROR_FLAGS) || (SPI2->SR&SPI_FLAG_OVR))
        xe_np_np2_spi2_d8_diag.error|=XE_NP_NP2_SPI2_D8_ERR_STOP;
}
#endif
#if (XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE != 0U)
enum { SPI2_D8_STREAM_CONFIGURED=1U, SPI2_D8_STREAM_CAPTURING=2U,
       SPI2_D8_STREAM_STOPPED=3U, SPI2_D8_STREAM_FAILED=255U };

static void spi2_d8_latch(uint32_t state)
{
    uint32_t dar=GPDMA1_Channel9->CDAR;
    xe_np_np2_spi2_d8_diag.state=state;
    xe_np_np2_spi2_d8_diag.dma_csr=GPDMA1_Channel9->CSR;
    xe_np_np2_spi2_d8_diag.dma_remaining=GPDMA1_Channel9->CBR1&DMA_CBR1_BNDT;
#if XE_NP_NP2_LIVE_SD_DIRECT
    uint32_t offset=XE_NP_Np2DirectOffset(dar,1U);
    xe_np_np2_spi2_d8_diag.bytes_captured=offset==UINT32_MAX?0U:offset/8U;
#else
    xe_np_np2_spi2_d8_diag.bytes_captured=
        dar>=(uint32_t)(uintptr_t)spi2_d8_ring &&
        dar<=(uint32_t)(uintptr_t)(spi2_d8_ring+XE_NP_NP2_SPI2_D8_RING_BYTES)?
        dar-(uint32_t)(uintptr_t)spi2_d8_ring:0U;
#endif
    xe_np_np2_spi2_d8_diag.spi_sr=SPI2->SR;
    xe_np_np2_spi2_d8_diag.spi_cr1=SPI2->CR1;
    xe_np_np2_spi2_d8_diag.spi_cfg1=SPI2->CFG1;
    xe_np_np2_spi2_d8_diag.spi_cfg2=SPI2->CFG2;
}

static int spi2_d8_begin(void)
{
    DMA_NodeConfTypeDef c={0};
    memset((void *)&xe_np_np2_spi2_d8_diag,0,sizeof(xe_np_np2_spi2_d8_diag));
    xe_np_np2_spi2_d8_diag.magic=XE_NP_NP2_SPI2_D8_DIAG_MAGIC;
    xe_np_np2_spi2_d8_diag.version=2U;
    xe_np_np2_spi2_d8_diag.calibrated_offset_bits=UINT32_MAX;
    spi2_d8_offset_bits=UINT32_MAX;
#if XE_NP_NP2_LIVE_SD_DIRECT
    spi2_direct_total=0U;spi2_direct_offset=direct_prepared=0U;
#endif
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(capture_profile_direct)runtime_spi_total=runtime_spi_offset=0U;
#endif
    xe_np_np2_spi2_d8_diag.buffer_address=(uint32_t)(uintptr_t)spi2_d8_ring;
    xe_np_np2_spi2_d8_diag.buffer_capacity=XE_NP_NP2_SPI2_D8_RING_BYTES;
    xe_np_np2_spi2_d8_diag.cpol=SPI_POLARITY_LOW;
    xe_np_np2_spi2_d8_diag.cpha=NP2_SPI2_CAPTURE_PHASE;
    xe_np_np2_spi2_d8_diag.first_bit=SPI_FIRSTBIT_LSB;
    if((GPDMA1_Channel9->CCR&DMA_CCR_EN) || (SPI2->CR1&SPI_CR1_SPE) ||
       !in_noncacheable_capture_arena(spi2_d8_ring,SPI2_D8_CHECK_BYTES)) {
        xe_np_np2_spi2_d8_diag.error=1U;spi2_d8_latch(SPI2_D8_STREAM_FAILED);return -1;
    }
    /* Hardware stop retires C9 without HAL callbacks, so the old circular
     * queue can still say BUSY. Rebuild only after the owner guard above;
     * never reset a live list or add bookkeeping to capture interrupts. */
    memset(&spi2_d8_dma,0,sizeof(spi2_d8_dma));
    memset(&spi2_d8_queue,0,sizeof(spi2_d8_queue));
    memset(spi2_d8_nodes,0,sizeof(spi2_d8_nodes));
    if(spi2_d8_clock()!=0) {
        xe_np_np2_spi2_d8_diag.error=2U;spi2_d8_latch(SPI2_D8_STREAM_FAILED);return -1;
    }
    spi2_d8.Instance=SPI2;
    spi2_d8.Init.Mode=SPI_MODE_SLAVE;spi2_d8.Init.Direction=SPI_DIRECTION_2LINES_RXONLY;
    spi2_d8.Init.DataSize=SPI_DATASIZE_8BIT;spi2_d8.Init.CLKPolarity=SPI_POLARITY_LOW;
    spi2_d8.Init.CLKPhase=NP2_SPI2_CAPTURE_PHASE;spi2_d8.Init.NSS=SPI_NSS_SOFT;
    spi2_d8.Init.BaudRatePrescaler=SPI_BAUDRATEPRESCALER_2;spi2_d8.Init.FirstBit=SPI_FIRSTBIT_LSB;
    spi2_d8.Init.TIMode=SPI_TIMODE_DISABLE;spi2_d8.Init.CRCCalculation=SPI_CRCCALCULATION_DISABLE;
    spi2_d8.Init.CRCPolynomial=7U;spi2_d8.Init.NSSPMode=SPI_NSS_PULSE_DISABLE;
    spi2_d8.Init.NSSPolarity=SPI_NSS_POLARITY_LOW;spi2_d8.Init.FifoThreshold=SPI_FIFO_THRESHOLD_01DATA;
#if XE_NP_NP2_DIRECT_SPI_FIFO_WORD_DMA
#if !XE_NP_NP2_LIVE_SD_DIRECT && \
    !(XE_NP_NP2_DUAL_SD_APP_ENABLE && XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES)
#error "SPI FIFO word-access experiment requires direct or runtime SD capture"
#endif
    _Static_assert(SPI2_D8_NODE_BYTES%4U==0U,"SPI FIFO word nodes must contain whole words");
    _Static_assert(XE_NP_NP2_SPI2_D8_RING_BYTES%4U==0U,"SPI FIFO word ring must contain whole words");
    spi2_d8.Init.FifoThreshold=SPI_FIFO_THRESHOLD_04DATA;
#endif
    spi2_d8.Init.MasterSSIdleness=SPI_MASTER_SS_IDLENESS_00CYCLE;
    spi2_d8.Init.MasterInterDataIdleness=SPI_MASTER_INTERDATA_IDLENESS_00CYCLE;
    spi2_d8.Init.MasterReceiverAutoSusp=SPI_MASTER_RX_AUTOSUSP_DISABLE;
    spi2_d8.Init.MasterKeepIOState=SPI_MASTER_KEEP_IO_STATE_DISABLE;
    spi2_d8.Init.IOSwap=SPI_IO_SWAP_DISABLE;
    spi2_d8.Init.ReadyMasterManagement=SPI_RDY_MASTER_MANAGEMENT_INTERNALLY;
    spi2_d8.Init.ReadyPolarity=SPI_RDY_POLARITY_HIGH;
    if(HAL_SPI_Init(&spi2_d8)!=HAL_OK) {
        xe_np_np2_spi2_d8_diag.error=3U;spi2_d8_latch(SPI2_D8_STREAM_FAILED);return -1;
    }
    CLEAR_BIT(SPI2->CR1,SPI_CR1_SSI); /* Software NSS active, MOSI is input. */
    spi2_d8_dma.Instance=GPDMA1_Channel9;
    spi2_d8_dma.InitLinkedList.Priority=DMA_HIGH_PRIORITY;
    spi2_d8_dma.InitLinkedList.LinkStepMode=DMA_LSM_FULL_EXECUTION;
    spi2_d8_dma.InitLinkedList.LinkAllocatedPort=DMA_LINK_ALLOCATED_PORT1;
    spi2_d8_dma.InitLinkedList.TransferEventMode=DMA_TCEM_LAST_LL_ITEM_TRANSFER;
    spi2_d8_dma.InitLinkedList.LinkedListMode=DMA_LINKEDLIST_CIRCULAR;
    if(HAL_DMAEx_List_Init(&spi2_d8_dma)!=HAL_OK ||
       HAL_DMAEx_List_ResetQ(&spi2_d8_queue)!=HAL_OK) {
        xe_np_np2_spi2_d8_diag.error=4U;spi2_d8_latch(SPI2_D8_STREAM_FAILED);return -1;
    }
    c.NodeType=DMA_GPDMA_LINEAR_NODE;c.Init.Request=GPDMA1_REQUEST_SPI2_RX;
    c.Init.BlkHWRequest=DMA_BREQ_SINGLE_BURST;c.Init.Direction=DMA_PERIPH_TO_MEMORY;
    c.Init.SrcInc=DMA_SINC_FIXED;c.Init.DestInc=DMA_DINC_INCREMENTED;
    c.Init.SrcDataWidth=DMA_SRC_DATAWIDTH_BYTE;c.Init.DestDataWidth=DMA_DEST_DATAWIDTH_BYTE;
    c.Init.Priority=DMA_HIGH_PRIORITY;c.Init.SrcBurstLength=1U;c.Init.DestBurstLength=1U;
    c.Init.TransferAllocatedPort=DMA_SRC_ALLOCATED_PORT0|DMA_DEST_ALLOCATED_PORT1;
    c.Init.TransferEventMode=DMA_TCEM_BLOCK_TRANSFER;c.Init.Mode=DMA_NORMAL;
    c.DataHandlingConfig.DataExchange=DMA_EXCHANGE_NONE;
    c.DataHandlingConfig.DataAlignment=DMA_DATA_RIGHTALIGN_ZEROPADDED;
    c.TriggerConfig.TriggerMode=DMA_TRIGM_SINGLE_BURST_TRANSFER;
    c.TriggerConfig.TriggerPolarity=DMA_TRIG_POLARITY_MASKED;
    c.SrcAddress=(uint32_t)(uintptr_t)&SPI2->RXDR;c.DataSize=SPI2_D8_NODE_BYTES;
#if XE_NP_NP2_DIRECT_SPI_WORD_DMA
#if !XE_NP_NP2_LIVE_SD_DIRECT
#error "SPI word-DMA experiment requires the direct-record layout"
#endif
    /* Channel 9 has an 8-byte FIFO: four peripheral byte requests pack into
     * one aligned RAM word. Node byte counts, chronological LSB order and
     * destination addresses are unchanged. No CPU re-packing is involved. */
    c.Init.DestDataWidth=DMA_DEST_DATAWIDTH_WORD;
    c.DataHandlingConfig.DataAlignment=DMA_DATA_PACK;
#endif
#if XE_NP_NP2_DIRECT_SPI_FIFO_WORD_DMA
    /* Match a four-byte FIFO packet with one 32-bit peripheral read. This
     * removes three of four APB reads, not just three of four RAM writes.
     * Copied-ring node lengths/addresses and byte chronology stay unchanged. */
    c.Init.SrcDataWidth=DMA_SRC_DATAWIDTH_WORD;
    c.Init.DestDataWidth=DMA_DEST_DATAWIDTH_WORD;
    c.DataHandlingConfig.DataAlignment=DMA_DATA_RIGHTALIGN_ZEROPADDED;
#endif
    c.RepeatBlockConfig.RepeatCount=1U;
    for(uint32_t i=0;i<SPI2_D8_NODE_COUNT;i++) {
#if XE_NP_NP2_LIVE_SD_DIRECT
        c.DstAddress=(uint32_t)(uintptr_t)(XE_NP_Np2DirectBlock(i)+512U+NP2_DIRECT_TICKS);
#else
        c.DstAddress=(uint32_t)(uintptr_t)(spi2_d8_ring+i*SPI2_D8_NODE_BYTES);
#endif
        if(HAL_DMAEx_List_BuildNode(&c,&spi2_d8_nodes[i])!=HAL_OK ||
           HAL_DMAEx_List_InsertNode_Tail(&spi2_d8_queue,&spi2_d8_nodes[i])!=HAL_OK) {
            xe_np_np2_spi2_d8_diag.error=5U;spi2_d8_latch(SPI2_D8_STREAM_FAILED);return -1;
        }
    }
#if XE_NP_NP2_STARTUP_PREROLL_TEST
    /* One-shot prefix goes into an unused future header. It is not linked
     * into the circular body and is never part of the recording origin. */
    c.DstAddress=(uint32_t)(uintptr_t)(XE_NP_Np2DirectBlock(1U)+128U);
    c.DataSize=64U;c.Init.TransferEventMode=DMA_TCEM_LAST_LL_ITEM_TRANSFER;
    if(HAL_DMAEx_List_BuildNode(&c,&spi2_d8_nodes[SPI2_D8_NODE_COUNT])!=HAL_OK ||
       HAL_DMAEx_List_InsertNode_Head(&spi2_d8_queue,&spi2_d8_nodes[SPI2_D8_NODE_COUNT])!=HAL_OK){
        xe_np_np2_spi2_d8_diag.error=6U;return -1;
    }
#endif
#if XE_NP_NP2_STARTUP_PREROLL_TEST
    if(HAL_DMAEx_List_SetCircularModeConfig(&spi2_d8_queue,&spi2_d8_nodes[0])!=HAL_OK ||
#else
    if(HAL_DMAEx_List_SetCircularMode(&spi2_d8_queue)!=HAL_OK ||
#endif
       HAL_DMAEx_List_LinkQ(&spi2_d8_dma,&spi2_d8_queue)!=HAL_OK ||
       HAL_DCACHE_CleanByAddr(&hdcache1,(const uint32_t*)spi2_d8_nodes,
          ((uint32_t)sizeof(spi2_d8_nodes)+31U)&~31U)!=HAL_OK) {
        xe_np_np2_spi2_d8_diag.error=6U;spi2_d8_latch(SPI2_D8_STREAM_FAILED);return -1;
    }
    GPDMA1_Channel9->CDAR=(uint32_t)(uintptr_t)spi2_d8_ring;
#if XE_NP_NP2_STARTUP_PREROLL_TEST
    GPDMA1_Channel9->CDAR=(uint32_t)(uintptr_t)(XE_NP_Np2DirectBlock(1U)+128U);
#endif
    GPDMA1_Channel9->CFCR=DMA_FLAG_HT|DMA_FLAG_TC|DMA_LIVE_FAULTS;
    HAL_NVIC_DisableIRQ(GPDMA1_Channel9_IRQn);HAL_NVIC_ClearPendingIRQ(GPDMA1_Channel9_IRQn);
    spi2_d8_latch(SPI2_D8_STREAM_CONFIGURED);
    if(HAL_DMAEx_List_Start(&spi2_d8_dma)!=HAL_OK) {
        xe_np_np2_spi2_d8_diag.error=7U;spi2_d8_latch(SPI2_D8_STREAM_FAILED);return -1;
    }
    MODIFY_REG(SPI2->CR2,SPI_CR2_TSIZE,0U);
    SET_BIT(SPI2->CFG1,SPI_CFG1_RXDMAEN);CLEAR_BIT(SPI2->IER,SPI_IT_OVR|SPI_IT_FRE|SPI_IT_MODF);
    /* Arm DMA only. Enable this passive receiver beside PSSI after all cold
     * setup; no CSTART or clock output is needed in slave receive mode. */
    spi2_d8_latch(SPI2_D8_STREAM_CONFIGURED);
    return 0;
}

static void spi2_d8_stop(void)
{
    /* Keep the live SPI request path until C9 is suspended. Reset only a
     * quiescent channel: suspension alone leaves EN set on USB/non-runtime
     * profiles too, so it does not retire the D8 ring's DMA owner. */
    int settled=!(GPDMA1_Channel9->CCR&DMA_CCR_EN);
    if(!settled){
        SET_BIT(GPDMA1_Channel9->CCR,DMA_CCR_SUSP);__DSB();
        for(uint32_t i=0U;i<1024U && !(GPDMA1_Channel9->CSR&DMA_FLAG_SUSP) &&
            (GPDMA1_Channel9->CCR&DMA_CCR_EN);i++)__NOP();
        settled=(GPDMA1_Channel9->CSR&DMA_FLAG_SUSP) || !(GPDMA1_Channel9->CCR&DMA_CCR_EN);
    }
    spi2_d8_latch(SPI2_D8_STREAM_STOPPED);
    if((GPDMA1_Channel9->CSR&DMA_ERROR_FLAGS) || (SPI2->SR&SPI_FLAG_OVR))
        xe_np_np2_spi2_d8_diag.error|=XE_NP_NP2_SPI2_D8_ERR_STOP;
    if(settled){
        CLEAR_BIT(SPI2->CFG1,SPI_CFG1_RXDMAEN);CLEAR_BIT(SPI2->CR1,SPI_CR1_SPE);
        SET_BIT(GPDMA1_Channel9->CCR,DMA_CCR_RESET);__DSB();
        for(uint32_t i=0U;i<1024U && (GPDMA1_Channel9->CCR&DMA_CCR_EN);i++)__NOP();
    }
    if(!settled || (GPDMA1_Channel9->CCR&DMA_CCR_EN) ||
       (GPDMA1_Channel9->CSR&DMA_ERROR_FLAGS) || (SPI2->SR&SPI_FLAG_OVR))
        xe_np_np2_spi2_d8_diag.error|=XE_NP_NP2_SPI2_D8_ERR_STOP;
}

static int spi2_d8_calibrate(const uint8_t *pssi,uint64_t source_start,uint32_t ticks)
{
    XE_NP_Np2D8Calibration calibration;
    if(source_start!=0U)return -1;
    int result=XE_NP_Np2D8Calibration_Find(pssi,spi2_d8_ring,
        SPI2_D8_CHECK_BYTES,ticks,&calibration);
    xe_np_np2_spi2_d8_diag.calibrated_phase=calibration.pssi_phase;
    xe_np_np2_spi2_d8_diag.calibration_matches=calibration.d8_matches;
#if XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
    cl_capture_calibrated(result,calibration.pssi_matches,calibration.d8_matches,calibration.pssi_phase);
#endif
    if(calibration.pssi_matches!=1U){
        xe_np_np2_spi2_d8_diag.error|=XE_NP_NP2_SPI2_D8_ERR_PSSI_SYNC;return -1;
    }
    if(result!=0 || calibration.d8_matches!=1U){
        xe_np_np2_spi2_d8_diag.error|=XE_NP_NP2_SPI2_D8_ERR_D8_SYNC;return -1;
    }
    spi2_d8_offset_bits=calibration.d8_offset;
    __DMB();xe_np_np2_spi2_d8_diag.calibrated_offset_bits=calibration.d8_offset;
    return 0;
}

int XE_NP_Np2CapturePort_CopyD8(const uint8_t *pssi,uint64_t source_start,uint32_t ticks,
                               uint8_t *destination,uint32_t capacity)
{
#if XE_NP_NP2_LIVE_SD_DIRECT
    (void)pssi;(void)source_start;(void)ticks;(void)destination;(void)capacity;
    return -1; /* not a contiguous copy-ring backend */
#else
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
    if(!capture_profile_d8)return -1;
#endif
    if(!pssi || !destination || !ticks || (ticks&7U) || capacity<ticks/8U ||
       xe_np_np2_spi2_d8_diag.state!=SPI2_D8_STREAM_CAPTURING ||
       xe_np_np2_spi2_d8_diag.error || !(GPDMA1_Channel9->CCR&DMA_CCR_EN) ||
       (GPDMA1_Channel9->CSR&DMA_ERROR_FLAGS) || !(SPI2->CR1&SPI_CR1_SPE) ||
       !(SPI2->CFG1&SPI_CFG1_RXDMAEN) || (SPI2->SR&SPI_FLAG_OVR))return -1;
    if(spi2_d8_offset_bits==UINT32_MAX && spi2_d8_calibrate(pssi,source_start,ticks)!=0) {
        xe_np_np2_spi2_d8_diag.error|=XE_NP_NP2_SPI2_D8_ERR_ALIGNMENT;return -1;
    }
    /* 737280=2^14*45 and 2^24 ==1 (mod45). Fold all64 bits before the
     * 32-bit remainder; retain unsigned addition wrap and long-run phase. */
    _Static_assert(XE_NP_NP2_SPI2_D8_RING_BYTES==92160U,"Copied D8 modulo geometry changed");
    uint64_t position=source_start+spi2_d8_offset_bits;
    uint32_t folded=((uint32_t)(position>>14U)&0xFFFFFFU)+(uint32_t)(position>>38U);
    uint32_t bit=((folded%45U)<<14U)|((uint32_t)position&0x3FFFU);
#if XE_NP_NP2_SPI2_D8_WORD_COPY
    XE_NP_Np2D8Copy(destination,spi2_d8_ring,XE_NP_NP2_SPI2_D8_RING_BYTES,bit,ticks/8U);
#else
    uint32_t index=bit>>3U,shift=bit&7U;
    for(uint32_t i=0;i<ticks/8U;i++) {
        uint32_t next=index+1U==XE_NP_NP2_SPI2_D8_RING_BYTES?0U:index+1U;
        uint16_t pair=(uint16_t)spi2_d8_ring[index]|((uint16_t)spi2_d8_ring[next]<<8U);
        destination[i]=(uint8_t)(pair>>shift);
        index=next;
    }
#endif
    __DMB();
    if((GPDMA1_Channel9->CSR&DMA_ERROR_FLAGS) || (SPI2->SR&SPI_FLAG_OVR))return -1;
    return 0;
#endif
}
#if NP2_PORT_DIRECT_PSSI
int XE_NP_Np2CapturePort_DirectReady(uint32_t end_tick_low)
{
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(!capture_profile_direct)return 0;
#endif
    uint32_t published=direct_published_low;
    if(!XE_NP_Np2Producer_LowCounterReached(published,end_tick_low))return 0;
    /* The IRQ publishes this low word only after the matching PSSI DMA event;
     * order following reads of the non-cacheable sample plane after it. */
    __DMB();return 1;
}

int XE_NP_Np2CapturePort_DirectProgress(uint64_t *published)
{
    if(!published)return -1;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(!capture_profile_direct)return -1;
#endif
    uint32_t key=lock(NULL);
    uint32_t stale=HAL_GetTick()-producer.last_irq_ms;
    uint32_t flags=GPDMA1_Channel12->CSR;
    uint32_t events=XE_NP_Np2DmaEventsFromFlags(flags,DMA_FLAG_HT,DMA_FLAG_TC);
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(capture_profile_direct)events&=XE_NP_NP2_EVENT_TC;
#endif
    /* The foreground already polls this path once per SysTick. Recover a
     * latched completion/fault immediately if its NVIC dispatch was delayed;
     * do not wait for the multi-millisecond watchdog and let another DMA
     * boundary coalesce. This is one register read per poll, not per sample. */
    if(events || (flags&DMA_LIVE_FAULTS) || (PSSI->RIS&PSSI_RIS_OVR_RIS) ||
        stale>=
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
        (capture_profile_direct?producer.stall_timeout_ms:XE_NP_NP2_STALL_TIMEOUT_MS)
#else
        XE_NP_NP2_STALL_TIMEOUT_MS
#endif
       ){
        XE_NP_Np2Producer_Irq(&producer);
        __DMB();direct_published_low=(uint32_t)producer.produced;
    }
    int active=!producer.error && producer.state==XE_NP_NP2_PRODUCER_ACTIVE;
    __DMB();direct_capture_active=(uint32_t)active;
    *published=producer.produced;
    unlock(NULL,key);
    /* IRQs validate hardware/retention at each published PSSI boundary. The
     * repeated-block experiment publishes once per RU, so its watchdog allows
     * that longer DMA interval plus margin. Do not repeatedly reread
     * RCC/GPIO/SPI/DMA in the waiting loop; a missing IRQ still faults. */
    return active?0:-1;
}

#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
static int runtime_direct_retained_locked(uint32_t end_tick_low)
{
    if(!producer.ring || producer.ring_bytes!=NP2_DIRECT_RING_TICKS ||
       producer.consumer_offset>=producer.ring_bytes ||
       producer.published_offset>=producer.ring_bytes ||
       !XE_NP_Np2Producer_LowCounterReached((uint32_t)producer.produced,end_tick_low))return 0;
    uint32_t retained=producer.published_offset>=producer.consumer_offset?
        producer.published_offset-producer.consumer_offset:
        producer.published_offset+producer.ring_bytes-producer.consumer_offset;
    return retained+producer.unpublished_bound<producer.retention_limit;
}
#endif

int XE_NP_Np2CapturePort_DirectPrepare(uint32_t sequence)
{
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(!capture_profile_direct)return -1;
    uint32_t end=(sequence+1U)*NP2_DIRECT_TICKS;
    uint32_t start=sequence*NP2_DIRECT_TICKS;
    uint64_t absolute_start=(uint64_t)sequence*NP2_DIRECT_TICKS;
    uint32_t key=lock(NULL);
    int d8=runtime_direct_d8_progress_locked()==0?
        runtime_direct_d8_retention_locked(start):-1;
    int valid=sequence==direct_prepared && direct_capture_active && !producer.error &&
        producer.state==XE_NP_NP2_PRODUCER_ACTIVE &&
        runtime_direct_retained_locked(end) && d8>=0;
    uint32_t lookahead=spi2_d8_offset_bits==UINT32_MAX?1600U:spi2_d8_offset_bits;
    int ready=valid && d8>0 &&
        XE_NP_Np2Producer_LowCounterReached(runtime_spi_total,end+lookahead+64U);
    unlock(NULL,key);
    if(!valid || (GPDMA1_Channel12->CSR&DMA_LIVE_FAULTS) ||
       (PSSI->RIS&PSSI_RIS_OVR_RIS) || xe_np_np2_spi2_d8_diag.error ||
       (GPDMA1_Channel9->CSR&DMA_ERROR_FLAGS) || (SPI2->SR&SPI_FLAG_OVR))return -1;
    if(!ready)return 0;
    uint8_t *block=XE_NP_Np2DirectBlock(sequence%NP2_DIRECT_SLOTS);
    if(XE_NP_Np2CapturePort_CopyD8(block+512U,absolute_start,
                                   NP2_DIRECT_TICKS,block+512U+NP2_DIRECT_TICKS,
                                   NP2_DIRECT_D8_BYTES))return -1;
    key=lock(NULL);
    d8=runtime_direct_d8_progress_locked()==0?runtime_direct_d8_retention_locked(start):-1;
    valid=sequence==direct_prepared && direct_capture_active && !producer.error &&
        producer.state==XE_NP_NP2_PRODUCER_ACTIVE &&
        runtime_direct_retained_locked(end) && d8>0;
    if(valid)direct_prepared++;
    unlock(NULL,key);
    return valid?1:-1;
#else
    /* Producer state changes only at serialized control/IRQ boundaries.
     * The 32-bit gate is refreshed there, avoiding a PRIMASK round-trip for
     * every ready stream block. IRQ-owned sticky hardware faults below still
     * close the gate immediately if an event fails. */
    int active=direct_capture_active!=0U;
    /* The TC snapshot that published this DMA group already verifies channel
     * enables, PSSI/SPI configuration, clock and probe-power/reset state.
     * Keep only sticky faults that may arrive between that snapshot and this
     * record's D8 handoff; repeating all enable/config GPIO reads per record
     * adds foreground bus traffic without extending the event-level guard. */
    if(sequence!=direct_prepared || !active ||
       (GPDMA1_Channel12->CSR&DMA_LIVE_FAULTS) ||
       (PSSI->RIS&PSSI_RIS_OVR_RIS) ||
       xe_np_np2_spi2_d8_diag.error ||
       (GPDMA1_Channel9->CSR&DMA_ERROR_FLAGS) || (SPI2->SR&SPI_FLAG_OVR))return -1;
    uint32_t position=XE_NP_Np2DirectD8Offset(GPDMA1_Channel9->CDAR);
    if(position==UINT32_MAX)return -1;
    uint32_t delta=position>=spi2_direct_offset?position-spi2_direct_offset:
                   position+NP2_DIRECT_RING_TICKS-spi2_direct_offset;
    spi2_direct_total+=delta;spi2_direct_offset=position;
    /* The caller's lock-free PSSI ready gate has already proved the matching
     * producer boundary. Keep D8 progress 32-bit: ring distance is statically
     * below the modular half-range, including phase lookahead. */
    uint32_t end=(sequence+1U)*NP2_DIRECT_TICKS;
    uint32_t lookahead=spi2_d8_offset_bits==UINT32_MAX?1600U:spi2_d8_offset_bits;
    if(!XE_NP_Np2Producer_LowCounterReached(spi2_direct_total,end+lookahead+64U))return 0;
    uint8_t *block=XE_NP_Np2DirectBlock(sequence%NP2_DIRECT_SLOTS);
    if(spi2_d8_offset_bits==UINT32_MAX && spi2_d8_calibrate(block+512U,0U,NP2_DIRECT_TICKS))return -1;
    uint8_t *next=XE_NP_Np2DirectBlock((sequence+1U)%NP2_DIRECT_SLOTS);
#if XE_NP_NP2_DIRECT_D8_RAW_PHASE
    XE_NP_Np2DirectD8PrepareRawPhase(block,
        next+512U+NP2_DIRECT_TICKS,spi2_d8_offset_bits);
#else
    XE_NP_Np2DirectShiftD8(block+512U+NP2_DIRECT_TICKS,next+512U+NP2_DIRECT_TICKS,spi2_d8_offset_bits);
#endif
    __DMB();
    if((GPDMA1_Channel9->CSR&DMA_ERROR_FLAGS) || (SPI2->SR&SPI_FLAG_OVR))return -1;
    direct_prepared++;return 1;
#endif
}
#if XE_NP_NP2_FIRST_SYNC_ENABLE
int XE_NP_Np2CapturePort_FirstSyncRetained(uint32_t sequence)
{
    XE_NP_Np2DmaSnapshot view={0};
    uint64_t first=(uint64_t)sequence*NP2_DIRECT_TICKS,end=first+NP2_DIRECT_TICKS;
    uint32_t key=lock(NULL);
    /* The same read-only hardware view is used by the existing producer.
     * Do not acknowledge DMA, advance a cursor, copy D8 or fault neural data
     * merely because optional startup evidence is no longer available. */
    producer.hw.snapshot(producer.hw.user,&view);
    int valid=direct_capture_active && producer.state==XE_NP_NP2_PRODUCER_ACTIVE &&
        !producer.error && view.active && !view.fault && sequence<direct_prepared &&
        producer.produced>=end &&
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
        capture_profile_direct && producer.produced-first+producer.unpublished_bound<producer.retention_limit &&
        view.now_ms-producer.last_irq_ms<producer.stall_timeout_ms &&
#else
        producer.produced-first+XE_NP_NP2_UNPUBLISHED_BOUND<XE_NP_NP2_RETENTION_LIMIT &&
        view.now_ms-producer.last_irq_ms<XE_NP_NP2_STALL_TIMEOUT_MS &&
#endif
        !(GPDMA1_Channel12->CSR&DMA_LIVE_FAULTS) && !(PSSI->RIS&PSSI_RIS_OVR_RIS) &&
        !xe_np_np2_spi2_d8_diag.error && !(GPDMA1_Channel9->CSR&DMA_ERROR_FLAGS) &&
        !(SPI2->SR&SPI_FLAG_OVR);
    unlock(NULL,key);return valid;
}
#endif
int XE_NP_Np2CapturePort_DirectRetireRUs(uint32_t end_ru)
{
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(!capture_profile_direct)return -1;
#endif
    uint32_t previous=direct_retired_rus;
    uint32_t units=end_ru-previous;
    if(!units || units>=NP2_DIRECT_RU_COUNT-1U)return -1;

    /* The caller supplies monotonically completed RUs from the validated SD
     * descriptor chain. Keep readiness validation in 32-bit modular tick
     * space; producer lead is bounded by the direct ring (< 2^31 ticks). */
    uint32_t end_tick_low=end_ru*NP2_DIRECT_RU_TICKS;
    uint32_t prepared_tick_low=direct_prepared*NP2_DIRECT_TICKS;
    if(!XE_NP_Np2Producer_LowCounterReached(direct_published_low,end_tick_low) ||
       !XE_NP_Np2Producer_LowCounterReached(prepared_tick_low,end_tick_low))return -1;

    uint32_t tick_advance=units*NP2_DIRECT_RU_TICKS;
    uint32_t next_offset=producer.consumer_offset+tick_advance;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(next_offset>=producer.ring_bytes)next_offset-=producer.ring_bytes;
#else
    if(next_offset>=NP2_DIRECT_RING_TICKS)next_offset-=NP2_DIRECT_RING_TICKS;
#endif

    /* Keep only the producer-shared commit in the global critical section.
     * In particular, do not mask the highest-priority PSSI/DMA IRQs while
     * doing 64-bit timeline arithmetic or modulo operations. */
    uint32_t key=lock(NULL);
    int valid=!producer.error &&
        (producer.state==XE_NP_NP2_PRODUCER_ACTIVE ||
          producer.state==XE_NP_NP2_PRODUCER_STOPPED
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
          || producer.state==XE_NP_NP2_PRODUCER_FROZEN
#endif
         ) && !producer.borrowed;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    valid=valid && producer.ring_bytes==NP2_DIRECT_RING_TICKS &&
        producer.produced>=producer.consumed &&
        producer.produced-producer.consumed<producer.ring_bytes;
#endif
    if(valid){
        producer.consumer_offset=next_offset;
        direct_retired_rus=end_ru;
    }
    unlock(NULL,key);
    if(!valid)return -1;

    /* The DMA IRQ consumes only the atomic 32-bit ring offset. Maintain the
     * absolute counter afterward for diagnostics/readback qualification. */
    producer.consumed+=tick_advance;
    return 0;
}
#endif
#endif
static void pins(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();__HAL_RCC_GPIOB_CLK_ENABLE();__HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();__HAL_RCC_GPIOE_CLK_ENABLE();
    GPIO_InitTypeDef g={0};g.Mode=GPIO_MODE_AF_PP;g.Pull=GPIO_NOPULL;g.Speed=GPIO_SPEED_FREQ_VERY_HIGH;
    g.Pin=NP1_D0_Pin;g.Alternate=GPIO_AF10_PSSI;HAL_GPIO_Init(NP1_D0_GPIO_Port,&g);
    g.Pin=NP1_D1_Pin;g.Alternate=GPIO_AF5_PSSI;HAL_GPIO_Init(NP1_D1_GPIO_Port,&g);
    g.Pin=NP1_D2_Pin|NP1_D3_Pin|NP1_D4_Pin|NP1_D6_Pin;g.Alternate=GPIO_AF10_PSSI;HAL_GPIO_Init(GPIOE,&g);
    g.Pin=NP1_D5_Pin|NP1_SYNC_Pin;HAL_GPIO_Init(GPIOB,&g);
#if (XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE != 0U) || (XE_NP_NP2_SPI2_D8_DIAG_ENABLE != 0U)
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
    if(capture_profile_d8){
#endif
    /* Slave RX-only makes PC3/MOSI and PB13/SCK passive inputs. PA8/MCO is
     * the sole driver of the clock shared with PD9/PSSI_PDCK. */
    g.Pin=NP2_SPI2_D8_Pin;g.Alternate=GPIO_AF5_SPI2;HAL_GPIO_Init(NP2_SPI2_D8_GPIO_Port,&g);
    g.Pin=NP2_SPI2_SCK_Pin;g.Alternate=GPIO_AF5_SPI2;HAL_GPIO_Init(NP2_SPI2_SCK_GPIO_Port,&g);
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
    }
#endif
#endif
    g.Pin=NP1_PSSI_PDCK_Pin;g.Alternate=NP1_PSSI_PDCK_AF;HAL_GPIO_Init(NP1_PSSI_PDCK_GPIO_Port,&g);
#if XE_NP_NP2_SD_UNUSED_PSSI_ANALOG_TEST
    if(capture_profile_mask==1U && capture_profile_sample_hz==7500U){
        /* The runtime mask1 codec consumes only PSSI[2:0]. Disable the five
         * unused input stages before arm, never while a DMA owner is active.
         * Ordinary initialization above restores all lanes on every session.
         * PB9 is D7, not the PD9/PA6 sampling clock despite its legacy name. */
        g.Mode=GPIO_MODE_ANALOG;g.Pull=GPIO_NOPULL;
        g.Pin=NP1_D3_Pin|NP1_D4_Pin|NP1_D6_Pin;HAL_GPIO_Init(GPIOE,&g);
        g.Pin=NP1_D5_Pin|NP1_SYNC_Pin;HAL_GPIO_Init(GPIOB,&g);
    }
#endif
}
#if XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
#include "xe_np_np2_closed_loop_capture_proof.inc"
#endif
static int begin(void *unused,uint8_t *ring,uint32_t bytes)
{
    (void)unused;
#if XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
    cl_capture_proof.flags=0U;
#endif
    /* Invalidate before any fallible setup; never report the previous run as
     * this attempt. No clock reads or anchor work are added to DMA service. */
    acquisition_anchor.flags=0U;
#if NP_FINE_COUNTER64_ENABLE && XE_NP_NP2_FIRST_SYNC_ENABLE
    XE_NP_Np2SdFinePoint64 np_before64={0},np_after64={0};
    uint32_t np_counter64_mode=0U,np_before64_valid=0U,np_descriptor_ready=0U,np_descriptor_link=0U;
    uint32_t np_descriptor_base=(uint32_t)(uintptr_t)ring;
#endif
#if XE_NP_NP2_STARTUP_PREROLL_TEST
    /* Headers are initialized before arm. Preserve them across the one-shot
     * scratch prefix; normal recording still updates only its hot fields. */
    uint8_t preroll_header0[512],preroll_header1[64];
    memcpy(preroll_header0,XE_NP_Np2DirectBlock(0U),sizeof(preroll_header0));
    memcpy(preroll_header1,XE_NP_Np2DirectBlock(1U)+128U,sizeof(preroll_header1));
#endif
#if XE_NP_NP2_LIVE_SD_DIRECT
    direct_published_low=0U;direct_capture_active=0U;
    direct_prepared=direct_retired_rus=0U;
#endif
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(capture_profile_direct){
        direct_published_low=0U;direct_capture_active=0U;
        direct_prepared=direct_retired_rus=0U;
        runtime_spi_total=runtime_spi_offset=0U;
    }
#endif
    setup_stage=0x100U;
    dma.Instance=GPDMA1_Channel12; /* stop hook remains safe on setup failure */
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
    if(XE_NP_Board_GetNp2SampleRateHz()!=capture_profile_sample_hz){setup_stage=0x10DU;return -1;}
#endif
    if(producer.error || producer.state!=XE_NP_NP2_PRODUCER_ACTIVE || !clock_ok() ||
        (uintptr_t)ring!=0x200D0000U || bytes!=NP2_CAPTURE_RING_BYTES ||
       (GPDMA1_Channel12->CCR&DMA_CCR_EN) || (PSSI->CR&PSSI_CR_ENABLE) ||
       !(NP_NRST_GPIO_Port->ODR&NP_NRST_Pin) || !(VCC_EN_GPIO_Port->ODR&VCC_EN_Pin)) {setup_stage=0x101U;return -1;}
    clock_guard.cfgr1=RCC->CFGR1;clock_guard.cfgr2=RCC->CFGR2;clock_guard.pllcfgr=RCC->PLL1CFGR;
    clock_guard.plldivr=RCC->PLL1DIVR;clock_guard.pllfracr=RCC->PLL1FRACR;clock_guard.valid=1;
    clock_guard.ready_mask=CLOCK_READY_PLL;
    if(!clock_unchanged()){setup_stage=0x102U;return -1;}
    pins();__HAL_RCC_GPDMA1_CLK_ENABLE();__HAL_RCC_DCMI_PSSI_CLK_ENABLE();
    __HAL_RCC_DCMI_PSSI_FORCE_RESET();__HAL_RCC_DCMI_PSSI_RELEASE_RESET();
    PSSI->CR=PSSI_CR_DMAEN|NP2_PSSI_CKPOL|NP2_PSSI_WIDTH;PSSI->ICR=PSSI_ICR_OVR_ISC;
#if (XE_NP_CAPTURE_SRAM3_MPU_NONCACHEABLE != 0U)
    /* No prior CPU ownership is possible for an MPU non-cacheable producer
     * ring.  Do not issue a DCACHE command immediately before arming PSSI. */
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(!capture_profile_direct && !in_noncacheable_capture_arena(ring,bytes)){setup_stage=0x103U;return -1;}
#elif !NP2_PORT_DIRECT_PSSI
    if(!in_noncacheable_capture_arena(ring,bytes)){setup_stage=0x103U;return -1;}
#endif
    __DMB();
#else
    if(HAL_DCACHE_CleanInvalidByAddr(&hdcache1,(const uint32_t*)ring,bytes)!=HAL_OK){setup_stage=0x103U;return -1;}
#endif
    dma.InitLinkedList.Priority=DMA_HIGH_PRIORITY;dma.InitLinkedList.LinkStepMode=DMA_LSM_FULL_EXECUTION;
    dma.InitLinkedList.LinkAllocatedPort=NP2_DMA_LINK_PORT;
    dma.InitLinkedList.TransferEventMode=XE_NP_NP2_IRQ_REPEAT_BLOCKS>1U?
        DMA_TCEM_REPEATED_BLOCK_TRANSFER:DMA_TCEM_BLOCK_TRANSFER;
    dma.InitLinkedList.LinkedListMode=DMA_LINKEDLIST_CIRCULAR;
    if(HAL_DMAEx_List_Init(&dma)!=HAL_OK){setup_stage=0x104U;return -1;}
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    dma.XferHalfCpltCallback=capture_profile_direct?NULL:unexpected_callback;
#elif XE_NP_NP2_FULL_NODE_IRQ
    /* HAL enables HTIE when this callback is non-null. Direct SD publishes
     * only complete record nodes; TC still interrupts and faults stay enabled. */
    dma.XferHalfCpltCallback=NULL;
#else
    dma.XferHalfCpltCallback=unexpected_callback;
#endif
    DMA_NodeConfTypeDef c={0};
    c.NodeType=XE_NP_NP2_IRQ_REPEAT_BLOCKS>1U?
        DMA_GPDMA_2D_NODE:DMA_GPDMA_LINEAR_NODE;
    c.Init.Request=GPDMA1_REQUEST_DCMI_PSSI;c.Init.BlkHWRequest=DMA_BREQ_SINGLE_BURST;
    c.Init.Direction=DMA_PERIPH_TO_MEMORY;c.Init.SrcInc=DMA_SINC_FIXED;c.Init.DestInc=DMA_DINC_INCREMENTED;
    c.Init.SrcDataWidth=NP2_DMA_SOURCE_WIDTH;c.Init.DestDataWidth=NP2_DMA_DEST_WIDTH;
    c.Init.Priority=DMA_HIGH_PRIORITY;c.Init.SrcBurstLength=1U;c.Init.DestBurstLength=NP2_DMA_DEST_BURST;
    c.Init.TransferAllocatedPort=DMA_SRC_ALLOCATED_PORT0|NP2_DMA_DEST_PORT;
    c.Init.TransferEventMode=XE_NP_NP2_IRQ_REPEAT_BLOCKS>1U?
        DMA_TCEM_REPEATED_BLOCK_TRANSFER:DMA_TCEM_BLOCK_TRANSFER;
    c.Init.Mode=DMA_NORMAL;
    c.DataHandlingConfig.DataExchange=DMA_EXCHANGE_NONE;c.DataHandlingConfig.DataAlignment=DMA_DATA_RIGHTALIGN_ZEROPADDED;
    c.TriggerConfig.TriggerMode=DMA_TRIGM_SINGLE_BURST_TRANSFER;c.TriggerConfig.TriggerPolarity=DMA_TRIG_POLARITY_MASKED;
    c.SrcAddress=(uint32_t)(uintptr_t)&PSSI->DR;c.DataSize=NP2_CAPTURE_NODE_BYTES;
    c.RepeatBlockConfig.RepeatCount=XE_NP_NP2_IRQ_REPEAT_BLOCKS;
    c.RepeatBlockConfig.SrcAddrOffset=0;c.RepeatBlockConfig.DestAddrOffset=0;
    c.RepeatBlockConfig.BlkSrcAddrOffset=0;
    c.RepeatBlockConfig.BlkDestAddrOffset=(int32_t)NP2_DMA_BLOCK_DEST_GAP_BYTES;
    for(uint32_t i=0;i<NP2_CAPTURE_NODE_COUNT;i++) {
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
        c.DstAddress=(uint32_t)(uintptr_t)(capture_profile_direct?
            XE_NP_Np2DirectBlock(i*XE_NP_NP2_IRQ_REPEAT_BLOCKS)+512U:
            ring+i*NP2_CAPTURE_NODE_BYTES*XE_NP_NP2_IRQ_REPEAT_BLOCKS);
#elif XE_NP_NP2_LIVE_SD_DIRECT
        c.DstAddress=(uint32_t)(uintptr_t)(XE_NP_Np2DirectBlock(
            i*XE_NP_NP2_IRQ_REPEAT_BLOCKS)+512U);
#else
        c.DstAddress=(uint32_t)(uintptr_t)(ring+
            i*NP2_CAPTURE_NODE_BYTES*XE_NP_NP2_IRQ_REPEAT_BLOCKS);
#endif
        if(HAL_DMAEx_List_BuildNode(&c,&nodes[i])!=HAL_OK){setup_stage=0x105U;return -1;}
        MODIFY_REG(nodes[i].LinkRegisters[0],DMA_CTR1_SDW_LOG2|DMA_CTR1_DDW_LOG2,
                   NP2_DMA_SOURCE_WIDTH|NP2_DMA_DEST_WIDTH);
        if(HAL_DMAEx_List_InsertNode_Tail(&queue,&nodes[i])!=HAL_OK){setup_stage=0x106U;return -1;}
    }
#if XE_NP_NP2_STARTUP_PREROLL_TEST
    /* Retain the queue's 2D node type; HAL forbids mixed node layouts. */
    c.DstAddress=(uint32_t)(uintptr_t)XE_NP_Np2DirectBlock(0U);
    c.DataSize=512U;c.RepeatBlockConfig.RepeatCount=1U;c.RepeatBlockConfig.BlkDestAddrOffset=0;
    c.Init.TransferEventMode=DMA_TCEM_LAST_LL_ITEM_TRANSFER;
    if(HAL_DMAEx_List_BuildNode(&c,&nodes[NP2_DMA_NODE_COUNT])!=HAL_OK ||
       HAL_DMAEx_List_InsertNode_Head(&queue,&nodes[NP2_DMA_NODE_COUNT])!=HAL_OK){setup_stage=0x107U;return -1;}
#endif
#if XE_NP_NP2_STARTUP_PREROLL_TEST
    if(HAL_DMAEx_List_SetCircularModeConfig(&queue,&nodes[0])!=HAL_OK){setup_stage=0x107U;return -1;}
#else
    if(HAL_DMAEx_List_SetCircularMode(&queue)!=HAL_OK){setup_stage=0x107U;return -1;}
#endif
    if(HAL_DMAEx_List_LinkQ(&dma,&queue)!=HAL_OK){setup_stage=0x108U;return -1;}
    if(HAL_DCACHE_CleanByAddr(&hdcache1,(const uint32_t*)nodes,((uint32_t)sizeof(nodes)+31U)&~31U)!=HAL_OK){setup_stage=0x109U;return -1;}
    /* First linked-list fetch may still be in progress at the first snapshot.
     * Seed the same DAR at idle; actual descriptor reload uses that same base. */
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    GPDMA1_Channel12->CDAR=(uint32_t)(uintptr_t)(capture_profile_direct?
        XE_NP_Np2DirectBlock(0U)+512U:ring);
#elif XE_NP_NP2_LIVE_SD_DIRECT
    GPDMA1_Channel12->CDAR=(uint32_t)(uintptr_t)(XE_NP_Np2DirectBlock(0U)+512U);
#if XE_NP_NP2_STARTUP_PREROLL_TEST
    GPDMA1_Channel12->CDAR=(uint32_t)(uintptr_t)XE_NP_Np2DirectBlock(0U);
#endif
#else
    GPDMA1_Channel12->CDAR=(uint32_t)(uintptr_t)ring;
#endif
    GPDMA1_Channel12->CFCR=DMA_FLAG_HT|DMA_FLAG_TC|DMA_LIVE_FAULTS;
    HAL_NVIC_SetPriority(GPDMA1_Channel12_IRQn,1U,0U);HAL_NVIC_SetPriority(DCMI_PSSI_IRQn,1U,0U);
    HAL_NVIC_ClearPendingIRQ(GPDMA1_Channel12_IRQn);HAL_NVIC_ClearPendingIRQ(DCMI_PSSI_IRQn);
    PSSI->IER=PSSI_IER_OVR_IE;
    if(HAL_DMAEx_List_Start_IT(&dma)!=HAL_OK){setup_stage=0x10AU;return -1;}
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(capture_profile_direct){
        /* Runtime direct publishes only complete 40,960-tick nodes. */
        CLEAR_BIT(GPDMA1_Channel12->CCR,DMA_CCR_HTIE);__DSB();
    }
#elif XE_NP_NP2_FULL_NODE_IRQ
    /* HTIE is normally left clear by the null callback above. Force it off
     * explicitly in case prior DMA-handle state carried it across setup. */
    CLEAR_BIT(GPDMA1_Channel12->CCR,DMA_CCR_HTIE);__DSB();
#endif
#if (XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE != 0U) || (XE_NP_NP2_SPI2_D8_DIAG_ENABLE != 0U)
    /* Prepare the passive serial sampler after arming the PSSI DMA, but
     * defer SPE until both receivers reach the final enable sequence below.
     * Exact calibration still measures, rather than assumes, the lane offset. */
    if(
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
       capture_profile_d8 &&
#endif
       spi2_d8_begin()!=0){setup_stage=0x10CU;return -1;}
#endif
    acquisition_anchor.counter_hz=XE_NP_Board_GetRuntimeCoreClockHz();
    acquisition_anchor.source_hz=XE_NP_Board_GetRuntimeExpectedMcoHz();
    acquisition_anchor.sample_hz=XE_NP_Board_GetNp2SampleRateHz();
    acquisition_anchor.origin_lo=XE_NP_NP2_STARTUP_PREROLL_TEST?512U:0U;
    acquisition_anchor.origin_hi=0U;
    if(++acquisition_anchor.generation==0U)acquisition_anchor.generation=1U;
    uint32_t anchor_flags=NP_ANCHOR_V2_PSSI_TICK|NP_ANCHOR_SOFTWARE;
    if((CoreDebug->DEMCR&CoreDebug_DEMCR_TRCENA_Msk) &&
       (DWT->CTRL&DWT_CTRL_CYCCNTENA_Msk))anchor_flags|=NP_ANCHOR_CYCLES_VALID;
    /* DMA descriptor-fetch errors can occur before PSSI starts. Keep the
     * owned NVIC lines disabled until the enable-last sequence is complete;
     * otherwise an early fault ISR could stop DMA and this code re-enable it. */
#if NP_FINE_COUNTER64_ENABLE && XE_NP_NP2_FIRST_SYNC_ENABLE
    np_counter64_mode=XE_NP_Np2FirstSyncRuntime_ClockBegin();
#if !XE_NP_NP2_STARTUP_PREROLL_TEST && !XE_NP_NP2_CAPTURE_16BIT_PSSI && !XE_NP_NP2_CAPTURE_BYTE_DMA
    if(np_counter64_mode==2U && !__get_PRIMASK() && !__get_BASEPRI() && !__get_IPSR()){
        uint32_t began=TIM5->CNT;
        for(uint32_t tries=512U;tries;tries--){
            if(np2_first_word_initial(np_descriptor_base,XE_NP_NP2_NODE_BYTES,
                GPDMA1_Channel12->CDAR,GPDMA1_Channel12->CBR1&DMA_CBR1_BNDT)){
                np_descriptor_link=GPDMA1_Channel12->CLLR;np_descriptor_ready=1U;break;
            }
            if((GPDMA1_Channel12->CSR&DMA_LIVE_FAULTS) || (uint32_t)(TIM5->CNT-began)>=50U)break;
        }
    }
#endif
#endif
    uint32_t key=lock(NULL);
    if(producer.error || (GPDMA1_Channel12->CSR&DMA_LIVE_FAULTS) || !clock_unchanged()) {
        setup_stage=0x10BU;unlock(NULL,key);return -1;
    }
    /* Start the production D8 sampler adjacent to PSSI. Exact calibration
     * remains mandatory; DirectPrepare keeps its lossless correction if the
     * measured offset is nonzero. A zero offset makes that correction a no-op
     * and avoids touching the D8 plane in the 20/30-kHz hot path. */
#if (XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE != 0U)
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
    if(capture_profile_d8)
#endif
    __HAL_SPI_ENABLE(&spi2_d8);
#endif
    /* WILD's prepare-first/start-last model: only these four timestamp reads
     * surround the final receiver gate. No wait, IRQ, payload or clock change.
     * The first accepted PDCK follows this gate; decoder frame phase is added
     * by the PC. A DWT wrap is valid unsigned subtraction, not an RTC epoch. */
    XE_NP_CycleClock_Anchor(&cycle_clock,acquisition_anchor.generation,
        acquisition_anchor.counter_hz,(anchor_flags&NP_ANCHOR_CYCLES_VALID) &&
        !(CoreDebug->DHCSR&CoreDebug_DHCSR_C_DEBUGEN_Msk));
    acquisition_anchor.before_ms=HAL_GetTick();
    acquisition_anchor.before_cycles=DWT->CYCCNT;
#if NP_FINE_COUNTER64_ENABLE && XE_NP_NP2_FIRST_SYNC_ENABLE
    if(np_counter64_mode==2U && XE_NP_Np2SdFineClock_ReadOwned64(&np_before64) &&
       !(np_before64.counter>>32U))np_before64_valid=1U;
#endif
    SET_BIT(PSSI->CR,PSSI_CR_ENABLE);__DSB();
    acquisition_anchor.after_cycles=DWT->CYCCNT;
    acquisition_anchor.after_ms=HAL_GetTick();
    acquisition_anchor.flags=anchor_flags|NP_ANCHOR_ROOT_VALID;
#if NP_FINE_COUNTER64_ENABLE && XE_NP_NP2_FIRST_SYNC_ENABLE
    if(np_counter64_mode==2U)acquisition_anchor.flags&=~NP_ANCHOR_CYCLES_VALID;
#endif
#if XE_NP_NP2_STARTUP_PREROLL_TEST
    /* Both lanes discard exactly 512 ticks once. Wait only at startup until
     * DAR reaches the normal payload. No prefix node event is published, and
     * every subsequent circular pass contains only ordinary recording nodes. */
    uint32_t attempts=20000U;
    uint32_t pssi_offset=UINT32_MAX,spi_offset=UINT32_MAX;
    while(attempts--){
        pssi_offset=XE_NP_Np2DirectOffset(GPDMA1_Channel12->CDAR,0U);
        spi_offset=XE_NP_Np2DirectOffset(GPDMA1_Channel9->CDAR,1U);
        if(pssi_offset>=64U && pssi_offset<NP2_DIRECT_TICKS &&
           spi_offset>=64U && spi_offset<NP2_DIRECT_TICKS)break;
        if((GPDMA1_Channel12->CSR&DMA_LIVE_FAULTS) ||
           (GPDMA1_Channel9->CSR&DMA_LIVE_FAULTS))break;
    }
    if(pssi_offset<64U || pssi_offset>=NP2_DIRECT_TICKS ||
       spi_offset<64U || spi_offset>=NP2_DIRECT_TICKS){
        setup_stage=0x111U;unlock(NULL,key);return -1;
    }
    memcpy(XE_NP_Np2DirectBlock(0U),preroll_header0,sizeof(preroll_header0));
    memcpy(XE_NP_Np2DirectBlock(1U)+128U,preroll_header1,sizeof(preroll_header1));
    __DSB();
#endif
    acquisition_anchor.flags|=NP_ANCHOR_SOURCE_VALID;
#if (XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE != 0U)
    spi2_d8_latch(SPI2_D8_STREAM_CAPTURING);
#endif
#if XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
    cl_capture_arm();
#endif
    HAL_NVIC_EnableIRQ(GPDMA1_Channel12_IRQn);HAL_NVIC_EnableIRQ(DCMI_PSSI_IRQn);
    setup_stage=0x110U;unlock(NULL,key);
#if NP_FINE_COUNTER64_ENABLE && XE_NP_NP2_FIRST_SYNC_ENABLE
    if(np_counter64_mode==2U && np_descriptor_ready && np_before64_valid &&
       !__get_PRIMASK() && !__get_BASEPRI() && !__get_IPSR()){
        for(uint32_t tries=512U;tries;tries--){
            uint32_t remaining=GPDMA1_Channel12->CBR1&DMA_CBR1_BNDT;
            uint32_t address=GPDMA1_Channel12->CDAR,link=GPDMA1_Channel12->CLLR;
            uint32_t faults=(GPDMA1_Channel12->CSR&(DMA_LIVE_FAULTS|DMA_FLAG_TC|DMA_FLAG_HT))|
                (PSSI->RIS&PSSI_RIS_OVR_RIS);
            if((uint32_t)(TIM5->CNT-(uint32_t)np_before64.counter)>=50U)break;
            if(np2_first_word_seen(np_descriptor_base,XE_NP_NP2_NODE_BYTES,np_descriptor_link,
                                   address,remaining,link,faults)){
                if(XE_NP_Np2SdFineClock_ReadOwned64(&np_after64) &&
                   np_after64.domain==np_before64.domain && np_after64.counter>=np_before64.counter &&
                   np_after64.counter-np_before64.counter<100U && !producer.error && clock_unchanged() &&
                   (PSSI->CR&PSSI_CR_ENABLE) && !(PSSI->RIS&PSSI_RIS_OVR_RIS) &&
                   XE_NP_Np2FirstSyncRuntime_FineBound(acquisition_anchor.generation,
                       acquisition_anchor.generation,&np_before64,&np_after64)){
                    key=lock(NULL);
                    acquisition_anchor.before_ms=np_before64.ms;acquisition_anchor.after_ms=np_after64.ms;
                    acquisition_anchor.before_cycles=(uint32_t)np_before64.counter;
                    acquisition_anchor.after_cycles=(uint32_t)np_after64.counter;
                    acquisition_anchor.counter_hz=XE_NP_NP2_SD_FINE_HZ;
                    acquisition_anchor.flags|=NP_ANCHOR_CYCLES_VALID|NP_ANCHOR_FIRST_SOURCE_VALID;
                    unlock(NULL,key);
                }
                break;
            }
            if(faults)break;
        }
    }
#endif
#if NP_FINE_COUNTER64_ENABLE && XE_NP_NP2_FIRST_SYNC_ENABLE
    if(np_counter64_mode==2U && !(acquisition_anchor.flags&NP_ANCHOR_FIRST_SOURCE_VALID)){
        uint32_t stage=!np_descriptor_ready?XE_NP_FINE_DIAG_CAPTURE_DESCRIPTOR:
            !np_before64_valid?XE_NP_FINE_DIAG_CAPTURE_BEFORE:
            !np_after64.domain?XE_NP_FINE_DIAG_CAPTURE_FIRST_WORD:XE_NP_FINE_DIAG_CAPTURE_AFTER;
        uint32_t detail=(np_descriptor_ready?1U:0U)|(np_before64_valid?2U:0U)|
            (__get_PRIMASK()?8U:0U)|(__get_BASEPRI()?16U:0U)|(__get_IPSR()?32U:0U);
        XE_NP_Np2SdFineDiagnosticFailure(stage,detail,acquisition_anchor.generation,
            acquisition_anchor.generation,&np_before64,&np_after64);
    }
    XE_NP_Np2SdFineDiagnosticEnd();
#endif
    return 0;
}
int XE_NP_Np2CapturePort_GetAnchor(XE_NP_AcquisitionAnchor *out)
{
    uint32_t key=lock(NULL);
    *out=acquisition_anchor;
    unlock(NULL,key);
    return (out->flags&NP_ANCHOR_ROOT_VALID)!=0U;
}
void XE_NP_Np2CapturePort_CycleClockInit(void)
{
    memset(&cycle_clock,0,sizeof(cycle_clock));
    CoreDebug->DEMCR|=CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CTRL|=DWT_CTRL_CYCCNTENA_Msk; /* Preserve any existing counter epoch. */
    __DSB();
}
void XE_NP_Np2CapturePort_CycleClockInvalidate(void)
{
    uint32_t key=lock(NULL);XE_NP_CycleClock_Invalidate(&cycle_clock);unlock(NULL,key);
}
void XE_NP_Np2CapturePort_GetCycleClock(uint32_t id,uint32_t continuous,
                                     XE_NP_CycleClockSnapshot *out)
{
    uint32_t key=lock(NULL);
    uint32_t enabled=(CoreDebug->DEMCR&CoreDebug_DEMCR_TRCENA_Msk) &&
        (DWT->CTRL&DWT_CTRL_CYCCNTENA_Msk) &&
        !(CoreDebug->DHCSR&CoreDebug_DHCSR_C_DEBUGEN_Msk);
    uint32_t hz=HAL_RCC_GetHCLKFreq();
    uint32_t valid=(acquisition_anchor.flags&7U)==7U && acquisition_anchor.counter_hz==hz;
    out->flags=NP_ANCHOR_V2_PSSI_TICK|XE_NP_CycleClock_Observe(&cycle_clock,id,hz,
        enabled,continuous,acquisition_anchor.generation,valid);
    out->token=cycle_clock.token;out->generation=acquisition_anchor.generation;
    out->hz=hz;out->anchor_token=cycle_clock.anchor_token;
    out->ms_before=HAL_GetTick();out->cycles_before=DWT->CYCCNT;
    out->cycles_after=DWT->CYCCNT;out->ms_after=HAL_GetTick();
    unlock(NULL,key);
}
#if XE_NP_NP2_LIVE_SD_DIRECT
static int direct_no_take(void *user,uint32_t ticks,XE_NP_Np2Span *span)
{ (void)user;(void)ticks;(void)span;return -1; }
#endif
static int bind(uint8_t *ring,uint32_t bytes,XE_NP_Np2ProducerIo *io)
{
    setup_stage=0x001U;
#if XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
    cl_capture_clear();
#endif
    /* Preserve the admission reason for SWD diagnostics.  These values are
     * stopped-only telemetry, never a reason to relax exclusive ownership of
     * the PSSI/GPDMA vectors. */
    if((uintptr_t)ring!=0x200D0000U){setup_stage=0x201U;return -1;}
    if(GPDMA1_Channel12->CCR&DMA_CCR_EN){setup_stage=0x202U;return -1;}
    if(PSSI->CR&PSSI_CR_ENABLE){setup_stage=0x203U;return -1;}
    if(NVIC_GetEnableIRQ(GPDMA1_Channel12_IRQn)){setup_stage=0x204U;return -1;}
    if(NVIC_GetEnableIRQ(DCMI_PSSI_IRQn)){setup_stage=0x205U;return -1;}
    if(NVIC_GetPendingIRQ(GPDMA1_Channel12_IRQn)){setup_stage=0x206U;return -1;}
    if(NVIC_GetPendingIRQ(DCMI_PSSI_IRQn)){setup_stage=0x207U;return -1;}
    if(producer.ring){
        if(producer.error || producer.borrowed ||
           (producer.state!=XE_NP_NP2_PRODUCER_STOPPED && producer.state!=XE_NP_NP2_PRODUCER_IDLE) ||
           producer.produced!=producer.consumed){setup_stage=0x208U;return -1;}
        memset(&producer,0,sizeof(producer));
    }
    acquisition_anchor.flags=0U;cycle_clock.anchor_token=0U;
    /* A stopped session leaves the HAL circular-list bookkeeping populated.
     * Rebuilding onto that list would link the same nodes twice. Ownership
     * checks above precede this stopped-only reset; no capture IRQ work added. */
    memset(&dma,0,sizeof(dma));memset(&queue,0,sizeof(queue));
    memset(nodes,0,sizeof(nodes));
    XE_NP_Np2DmaIo hw={NULL,lock,unlock,begin,snapshot,ack,stop,invalidate,now,irq_recheck};
    if(XE_NP_Np2Producer_BindWithStride(&producer,ring,bytes,
       XE_NP_NP2_CAPTURE_16BIT_PSSI?2U:1U,&hw,io)!=0){setup_stage=0x003U;return -1;}
    stop_ticks=0U;
#if XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
    cl_capture_wrap(io);
#endif
#if XE_NP_NP2_LIVE_SD_DIRECT
    /* ring is a logical address token, never a contiguous sample pointer. */
    io->take=direct_no_take;
#endif
    setup_stage=0x010U;return 0;
}
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
static int capture_profile_valid(const uint8_t *ring,uint32_t bytes,uint32_t mask,uint32_t sample_hz)
{
    uintptr_t base=(uintptr_t)ring,end=base+(uintptr_t)bytes;
    return base==0x200D0000UL && bytes==XE_NP_NP2_RING_BYTES &&
        end==0x200D0000UL+XE_NP_NP2_RING_BYTES &&
        end<=(uintptr_t)spi2_d8_ring && (uintptr_t)spi2_d8_ring==0x2018C800UL &&
        (uintptr_t)spi2_d8_ring+XE_NP_NP2_SPI2_D8_RING_BYTES==0x201A3000UL &&
        (mask==1U || mask==3U || mask==7U) &&
        (sample_hz==15000U || sample_hz==20000U || sample_hz==30000U
#if XE_NP_NP2_DUAL_SD_APP_ENABLE && XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
         || sample_hz==7500U
#endif
        );
}
int XE_NP_Np2CapturePort_BindProfile(uint8_t *ring,uint32_t bytes,
                                    XE_NP_Np2ProducerIo *io,uint32_t probe_mask)
{
#if XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
    cl_capture_clear();
#endif
    uint32_t sample_hz=XE_NP_Board_GetNp2SampleRateHz();
    if(!io || !capture_profile_valid(ring,bytes,probe_mask,sample_hz)){
        setup_stage=0x209U;return -1;
    }
    if((GPDMA1_Channel9->CCR&DMA_CCR_EN) || (SPI2->CR1&SPI_CR1_SPE) ||
       NVIC_GetEnableIRQ(GPDMA1_Channel9_IRQn) || NVIC_GetPendingIRQ(GPDMA1_Channel9_IRQn)){
        setup_stage=0x20AU;return -1;
    }
    if(producer.ring && producer.state==XE_NP_NP2_PRODUCER_IDLE &&
       (capture_profile_d8!=(probe_mask==7U) || capture_profile_sample_hz!=sample_hz
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
         || capture_profile_direct!=XE_NP_Np2RuntimeDirectPssiProfile(probe_mask,sample_hz)
#endif
#if XE_NP_NP2_SD_UNUSED_PSSI_ANALOG_TEST
        || capture_profile_mask!=probe_mask
#endif
       )){
        setup_stage=0x20BU;return -1;
    }
    if(bind(ring,XE_NP_Np2RuntimeDirectPssiProfile(probe_mask,sample_hz)?
            NP2_DIRECT_RING_TICKS:bytes,io)!=0)return -1;
    capture_profile_d8=(uint8_t)(probe_mask==7U);capture_profile_sample_hz=sample_hz;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    capture_profile_direct=(uint8_t)XE_NP_Np2RuntimeDirectPssiProfile(probe_mask,sample_hz);
#endif
#if XE_NP_NP2_SD_UNUSED_PSSI_ANALOG_TEST
    capture_profile_mask=probe_mask;
#endif
    producer.hw.snapshot=capture_profile_d8?snapshot_d8:snapshot;
    return 0;
}
int XE_NP_Np2CapturePort_RetireStoppedTail(uint64_t recorded_ticks)
{
    uint32_t key=lock(NULL);int result=-1;
    if(recorded_ticks &&
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
       (capture_profile_d8 || producer.drain_ticks) &&
#else
       capture_profile_d8 &&
#endif
       producer.ring &&
       producer.state==XE_NP_NP2_PRODUCER_STOPPED && !producer.error && !producer.borrowed &&
       producer.source_bytes_per_tick==1U &&
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
       (producer.drain_ticks?producer.consumed>=recorded_ticks:producer.consumed==recorded_ticks) &&
       producer.consumed<=producer.produced &&
#else
       producer.consumed==recorded_ticks &&
#endif
       producer.produced>=recorded_ticks &&
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
       /* Discarded trailing input is no longer retained in the raw ring. */
       producer.produced-producer.consumed<
#else
       producer.produced-recorded_ticks<
#endif
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
        producer.ring_bytes && producer.consumer_offset<producer.ring_bytes &&
#else
        XE_NP_NP2_RING_BYTES && producer.consumer_offset<XE_NP_NP2_RING_BYTES &&
#endif
       !(GPDMA1_Channel9->CCR&DMA_CCR_EN) && !(GPDMA1_Channel12->CCR&DMA_CCR_EN) &&
       !(SPI2->CR1&SPI_CR1_SPE) && !(PSSI->CR&PSSI_CR_ENABLE) &&
       !NVIC_GetEnableIRQ(GPDMA1_Channel9_IRQn) && !NVIC_GetPendingIRQ(GPDMA1_Channel9_IRQn) &&
       !NVIC_GetEnableIRQ(GPDMA1_Channel12_IRQn) && !NVIC_GetPendingIRQ(GPDMA1_Channel12_IRQn) &&
       !NVIC_GetEnableIRQ(DCMI_PSSI_IRQn) && !NVIC_GetPendingIRQ(DCMI_PSSI_IRQn)){
        /* Old footer/snapshots retain both counts. Only the next initialization
         * acknowledges samples beyond that already verified recording extent. */
        uint32_t offset=producer.consumer_offset+(uint32_t)(producer.produced-producer.consumed);
         if(offset>=
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
            producer.ring_bytes)offset-=producer.ring_bytes;
#else
            XE_NP_NP2_RING_BYTES)offset-=XE_NP_NP2_RING_BYTES;
#endif
        producer.consumer_offset=offset;producer.consumed=producer.produced;result=0;
    }
    unlock(NULL,key);return result;
}
#endif
int XE_NP_Np2CapturePort_Bind(uint8_t *ring,uint32_t bytes,XE_NP_Np2ProducerIo *io)
{
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
    return XE_NP_Np2CapturePort_BindProfile(ring,bytes,io,XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE?7U:3U);
#else
    return bind(ring,bytes,io);
#endif
}
int XE_NP_Np2CapturePort_SetStopTicks(uint64_t ticks)
{
    uint32_t key=lock(NULL);int result=-1;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(!producer.ring || !producer.source_bytes_per_tick){unlock(NULL,key);return -1;}
#endif
    uint32_t event_ticks=
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
        producer.event_bytes/producer.source_bytes_per_tick;
#else
        XE_NP_NP2_EVENT_BYTES/(XE_NP_NP2_CAPTURE_16BIT_PSSI?2U:1U);
#endif
    if(producer.ring && !producer.error && ticks && ticks%event_ticks==0U &&
       ticks>=producer.produced &&
       (producer.state==XE_NP_NP2_PRODUCER_IDLE ||
        producer.state==XE_NP_NP2_PRODUCER_ACTIVE ||
        (producer.state==XE_NP_NP2_PRODUCER_FROZEN && ticks==producer.produced))){
        result=0;
        if(producer.state==XE_NP_NP2_PRODUCER_ACTIVE && ticks==producer.produced)
            result=XE_NP_Np2Producer_Freeze(&producer);
        if(!result)stop_ticks=ticks;
    }
    unlock(NULL,key);return result;
}
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
int XE_NP_Np2CapturePort_EnableDrain(uint32_t ticks)
{
    uint32_t key=lock(NULL);
    int result=XE_NP_Np2Producer_EnableDrain(&producer,ticks);
    unlock(NULL,key);return result;
}
#endif
void XE_NP_Np2CapturePort_Stop(void)
{
#if XE_NP_NP2_LIVE_SD_DIRECT
    direct_capture_active=0U;__DMB();
#elif XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(capture_profile_direct){direct_capture_active=0U;__DMB();}
#endif
    XE_NP_Np2Producer_Stop(&producer);
#if XE_NP_NP2_LIVE_SD_DIRECT
    direct_capture_active=0U;__DMB();
#elif XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(capture_profile_direct){direct_capture_active=0U;__DMB();}
#endif
    /* Control can fail while still configuring, before DMA was ever armed.
     * Its safety hook must nevertheless hold BOTH probes in shared reset. */
    HAL_GPIO_WritePin(NP_NRST_GPIO_Port,NP_NRST_Pin,GPIO_PIN_RESET);
}
int XE_NP_Np2CapturePort_Armed(void)
{
    uint32_t key=lock(NULL);
    int active=producer.state==XE_NP_NP2_PRODUCER_ACTIVE && !producer.error;
#if XE_NP_NP2_LIVE_SD_DIRECT
    __DMB();direct_capture_active=(uint32_t)active;
#elif XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(capture_profile_direct){__DMB();direct_capture_active=(uint32_t)active;}
#endif
    unlock(NULL,key);return active;
}
#if XE_NP_IMAGE_ROLE==1U && XE_NP_NP2_CLOSED_LOOP_SPI_ENABLE
int XE_NP_Np2CapturePort_OptionalHeadroom(uint32_t reserve_ticks)
{
    uint32_t key=lock(NULL),allowed=0U;
    if(!producer.error && producer.ring){
        if(producer.state==XE_NP_NP2_PRODUCER_STOPPED)allowed=1U;
        else if(producer.state==XE_NP_NP2_PRODUCER_ACTIVE){
            uint32_t bytes_per_tick=producer.source_bytes_per_tick;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
            uint32_t ring_bytes=producer.ring_bytes;
            uint32_t retention_bytes=producer.retention_limit;
            uint32_t unpublished_bytes=producer.unpublished_bound;
#else
            uint32_t ring_bytes=XE_NP_NP2_RING_BYTES;
            uint32_t retention_bytes=XE_NP_NP2_RETENTION_LIMIT;
            uint32_t unpublished_bytes=XE_NP_NP2_UNPUBLISHED_BOUND;
#endif
            /* The P3 D8 path is byte-wide. Reject other strides rather than
             * divide cold geometry in this repeated admission boundary. */
            if(bytes_per_tick==1U){
                uint32_t ring=ring_bytes;
                uint32_t retention=retention_bytes;
                uint32_t unpublished=unpublished_bytes;
                if(ring && ring<0x80000000U && retention<ring && unpublished<retention &&
                   reserve_ticks<retention-unpublished){
                    uint32_t backlog=(uint32_t)producer.produced-(uint32_t)producer.consumed;
                    allowed=backlog<ring && backlog<retention-unpublished-reserve_ticks;
                }
            }
        }
    }
    unlock(NULL,key);return (int)allowed;
}
#endif
void XE_NP_Np2CapturePort_DmaIrq(void)
{
    XE_NP_Np2Producer_IrqUntil(&producer,stop_ticks);
#if XE_NP_NP2_LIVE_SD_DIRECT
    __DMB();direct_published_low=(uint32_t)producer.produced;
    direct_capture_active=(uint32_t)(producer.state==XE_NP_NP2_PRODUCER_ACTIVE && !producer.error);
#elif XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(capture_profile_direct){
        __DMB();direct_published_low=(uint32_t)producer.produced;
        direct_capture_active=(uint32_t)(producer.state==XE_NP_NP2_PRODUCER_ACTIVE && !producer.error);
    }
#endif
}
void XE_NP_Np2CapturePort_PssiIrq(void)
{
    XE_NP_Np2Producer_IrqUntil(&producer,stop_ticks);
#if XE_NP_NP2_LIVE_SD_DIRECT
    __DMB();direct_published_low=(uint32_t)producer.produced;
    direct_capture_active=(uint32_t)(producer.state==XE_NP_NP2_PRODUCER_ACTIVE && !producer.error);
#elif XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(capture_profile_direct){
        __DMB();direct_published_low=(uint32_t)producer.produced;
        direct_capture_active=(uint32_t)(producer.state==XE_NP_NP2_PRODUCER_ACTIVE && !producer.error);
    }
#endif
}
uint32_t XE_NP_Np2CapturePort_LastSetupStage(void) { return setup_stage; }
void XE_NP_Np2CapturePort_Diagnostics(XE_NP_Np2Producer *out)
{ if(out) {uint32_t key=lock(NULL);*out=producer;unlock(NULL,key);} }
#endif
