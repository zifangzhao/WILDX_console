#include "xe_np_np2_grid16_sector.h"
#include <string.h>

int XE_NP_Grid16Sector_Wrap(uint8_t out[512],uint32_t generation,uint64_t preceding,
                            const uint8_t *frame,size_t bytes)
{
    if(!out || !generation || preceding==UINT64_MAX || (preceding&3U)!=3U ||
       bytes>480U || (bytes && (!frame || bytes<48U ||
       np_imu_grid_overlap(out,512U,frame,bytes) ||
       np_imu_grid_u32(frame)!=NP_IMU_GRID_MAGIC || frame[4]!=1U || frame[5]!=1U ||
       np_imu_grid_u16(frame+6U)!=48U || np_imu_grid_u32(frame+40U)!=generation ||
       np_imu_grid_u32(frame+32U)!=bytes-48U)))return 0;
    memset(out,0,512U);memcpy(out,"NPGRID02",8U);
    np_imu_grid_put32(out+8U,1U);np_imu_grid_put32(out+12U,generation);
    np_imu_grid_put64(out+16U,preceding);np_imu_grid_put16(out+24U,(uint16_t)bytes);
    np_imu_grid_put32(out+28U,np_imu_grid_crc(out,28U));
    if(bytes)memcpy(out+32U,frame,bytes);
    return 1;
}

int XE_NP_Grid16Sector_Read(const uint8_t in[512],uint32_t generation,
                            uint64_t preceding,NpImuGridView *view)
{
    NpImuGridView v;size_t bytes;
    if(!in || !generation || preceding==UINT64_MAX || (preceding&3U)!=3U ||
       (view && np_imu_grid_overlap(in,512U,view,sizeof(*view))))return -1;
    if(view)memset(view,0,sizeof(*view));
    if(memcmp(in,"NPGRID02",8U) || np_imu_grid_u32(in+8U)!=1U ||
       np_imu_grid_u32(in+12U)!=generation || np_imu_grid_u64(in+16U)!=preceding ||
       np_imu_grid_u16(in+26U) || np_imu_grid_u32(in+28U)!=np_imu_grid_crc(in,28U))return -1;
    bytes=np_imu_grid_u16(in+24U);if(bytes>480U)return -1;
    for(size_t i=32U+bytes;i<512U;i++)if(in[i])return -1;
    if(!bytes)return 0;
    if(!np_imu_grid_read(in+32U,bytes,&v) || v.header.capture_generation!=generation)return -1;
    if(view)*view=v;return 1;
}
