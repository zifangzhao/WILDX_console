#ifndef XE_NP_IMU_GRID_PROVIDER_H
#define XE_NP_IMU_GRID_PROVIDER_H
#include "xe_np_imu_grid_runtime.h"
#include "xe_np_imu_grid_control_wire.h"
#include "xe_np_imu_grid_phase_bound.h"
#include <stdint.h>

/* One foreground owner, one runtime and one AUX request in flight. This is an
 * inactive provider; it never changes NP, USB, SD or TIM5 lifecycle. */
typedef struct {
    XE_NP_GridRuntime *runtime;
    XE_NP_GridWireContext identity;
    XE_NP_GridPhaseInput phase;
    XE_NP_ImuGridSlot held;
    uint64_t base_ordinal,pending_source,pending_end,last_end,discarded_prefix;
    uint32_t pending_type,pending_bytes,have_last;
    uint8_t body[480];
    uint8_t attached,stopped,has_held,phase_done,pending,inflight,terminal_done,incomplete;
} XE_NP_GridProvider;
/* Zero-initialize this object before the first Attach. Never reinitialize it
 * while a session or its unconfirmed transport payload is owned. */
void XE_NP_GridProvider_Init(XE_NP_GridProvider *p);
/* Caller independently matches UID/token and validates current live context.
 * receipt/anchor are the existing final NPSTART and source-root evidence.
 * copy_bound_qualified is 1 only when actually enforced for the session. */
int XE_NP_GridProvider_Attach(XE_NP_GridProvider *p,XE_NP_GridRuntime *r,
    const XE_NP_GridWireContext *identity,const uint8_t *receipt,uint32_t receipt_bytes,
    const uint8_t *anchor,uint32_t anchor_bytes,uint64_t base_ordinal,
    uint32_t continuous_clock_qualified,uint32_t copy_bound_qualified);
/* Call after actual NP cutoff is determined, before its source clock is torn
 * down. Unknown/unproven cutoff is explicitly passed as cutoff_valid=0. */
void XE_NP_GridProvider_Finish(XE_NP_GridProvider *p,int cutoff_valid,uint64_t cutoff_us);
/* Foreground-only before transport: examine at most 12 queued slots. Return 1
 * with an actual held post-source ordinal, 0 if none, -1 on invalid state or
 * unqualified data. Never serializes or changes an outstanding transfer.
 * Output is unchanged on 0/-1; unsuccessful proof marks provider incomplete. */
int XE_NP_GridProvider_Prime(XE_NP_GridProvider *p,uint64_t *ordinal);
/* Bind as AUX Next/Complete; both are bounded foreground-only callbacks. */
int XE_NP_GridProvider_Next(void *context,uint8_t *staging,uint32_t capacity,
    uint32_t *type,uint32_t *bytes,uint64_t *source,uint32_t draining);
void XE_NP_GridProvider_Complete(void *context,uint32_t type,uint32_t delivered);
/* A failed AUX-only transfer is unconfirmed, not proof the host lost a row. */
int XE_NP_GridProvider_Incomplete(const XE_NP_GridProvider *p);
#endif
