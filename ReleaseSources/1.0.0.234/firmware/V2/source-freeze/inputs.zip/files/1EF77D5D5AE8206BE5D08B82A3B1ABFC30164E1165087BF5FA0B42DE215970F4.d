D:\Code\XE_NP_V2\_artifacts\v2_ble_cold_start_20261007_build\usb\xe_np_bme_compensation.o: \
  D:\Code\XE_NP_V2\Core\Src\xe_np_bme_compensation.c \
  D:\Code\XE_NP_V2\Core\Src\..\..\Middlewares\Bosch\BME280_SensorAPI\bme280.c \
  D:\Code\XE_NP_V2\Core\Src\..\..\Middlewares\Bosch\BME280_SensorAPI\bme280.h \
  D:\Code\XE_NP_V2\Core\Src\..\..\Middlewares\Bosch\BME280_SensorAPI\bme280_defs.h
