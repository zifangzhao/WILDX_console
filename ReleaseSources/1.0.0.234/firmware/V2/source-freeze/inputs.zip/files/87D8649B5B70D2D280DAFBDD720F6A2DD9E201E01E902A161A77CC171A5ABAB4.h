#ifndef XE_NP_NP2_FIRST_SYNC_PORT_H
#define XE_NP_NP2_FIRST_SYNC_PORT_H
#include "xe_np_np2_first_sync_gate.h"
#if XE_NP_NP2_FIRST_SYNC_ENABLE
/* A provider reads actual final-generation ownership, never a cached GUI or
 * preparation receipt. Startup only; no endpoint/HAL setup is performed here. */
typedef int (*XE_NP_Np2FirstSyncOwner)(void *,NpFirstSyncBinding *,XE_NP_Np2FirstSyncPoint *);
typedef int (*XE_NP_Np2FirstSyncViewRetained)(const uint8_t *,uint32_t,void *);
typedef void (*XE_NP_Np2FirstSyncOpened)(void *,XE_NP_Np2FirstSyncGate *,const NpFirstSyncBinding *);
typedef struct {
    XE_NP_Np2FirstSyncGate gate;
    XE_NP_Np2FirstSyncOwner owner;
    XE_NP_Np2FirstSyncOpened opened;
    void *user;
    const uint8_t *private_block;
    XE_NP_Np2FirstSyncViewRetained retained;
    void *retained_user;
    NpFirstSyncBinding observed;
    XE_NP_Np2FirstSyncPoint discovery;
    uint8_t aux_mask,source_mapping,pending;
} XE_NP_Np2FirstSyncPort;
/* Caller owns storage for the whole recording/footer lifetime. No large
 * ordinary-RAM context is instantiated by this module. Bind before capture;
 * a new Bind may replace a stopped context only after its footer is owned. */
int XE_NP_Np2FirstSyncPort_Bind(XE_NP_Np2FirstSyncPort *,XE_NP_Np2FirstSyncOwner,XE_NP_Np2FirstSyncOpened,void *,uint8_t aux_mask,int source_mapping);
void XE_NP_Np2FirstSyncPort_Private(const uint8_t *,uint32_t,XE_NP_Np2FirstSyncViewRetained,void *);
void XE_NP_Np2FirstSyncPort_Commit(const uint8_t *);
/* IRQ-safe permission invalidation: no clocks, HAL, receipt packing or I/O.
 * Frozen/historical evidence survives for the foreground footer owner. */
void XE_NP_Np2FirstSyncPort_Invalidate(void);
XE_NP_Np2FirstSyncGate *XE_NP_Np2FirstSyncPort_Gate(void);
#else
#define XE_NP_Np2FirstSyncPort_Private(block,bytes,retained,user) ((void)0)
#define XE_NP_Np2FirstSyncPort_Commit(block) ((void)0)
#define XE_NP_Np2FirstSyncPort_Invalidate() ((void)0)
#endif
#endif
