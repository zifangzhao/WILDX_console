#include "CE32_HJ580.h"

#include <stdio.h>
#include <string.h>

CE32_HJ580_Handle BLE_handle;

#define XE_NP_HJ185_DIAG_MAGIC 0x484A3138UL
#define XE_NP_HJ185_DIAG_VERSION 7UL
#define XE_NP_HJ185_PROBE_FLAG_REPLY 0x00000001UL
#define XE_NP_HJ185_PROBE_FLAG_VALID_PREFIX 0x00000002UL
#define XE_NP_HJ185_PROBE_FLAG_VALUE_PARSED 0x00000004UL
#define XE_NP_HJ185_PROBE_FLAG_ERROR_TOKEN 0x00000008UL
#define XE_NP_HJ185_PROBE_FLAG_TIMEOUT 0x00000010UL
#define XE_NP_HJ185_PROBE_FLAG_CMD_RD_SOFT_VERSION 0x00000100UL
#define XE_NP_HJ185_PROBE_FLAG_CMD_RD_TO_APP 0x00000200UL
#define XE_NP_HJ185_PROBE_FLAG_CMD_RD_APP_CONFIG 0x00000400UL
#define XE_NP_HJ185_PROBE_FLAG_CMD_RD_NAME 0x00000800UL

typedef struct
{
    uint32_t magic;
    uint32_t version;
    uint32_t stage;
    uint32_t result;
    uint32_t last_status;
    uint32_t last_state;
    uint32_t last_gpio_state;
    uint32_t last_reply_len;
    uint32_t wake_pin_state;
    uint32_t mode_pin_state;
    uint32_t uart_isr;
    uint32_t uart_cr1;
    uint32_t uart_brr;
    uint32_t uart_error_flags;
    uint32_t uart_error_count;
    uint32_t rx_byte_count;
    uint32_t rx_frame_count;
    uint32_t stream_rx_irq_count;
    uint32_t stream_raw_byte_count;
    uint32_t stream_raw_last_len;
    uint32_t stream_raw_last_byte;
    uint32_t stream_cmd_rx_count;
    uint32_t stream_cmd_tx_launch_count;
    uint32_t stream_last_rx_len;
    uint32_t stream_last_tx_launch_len;
    uint32_t stream_last_rx_cmd;
    uint32_t stream_last_tx_launch_cmd;
    uint32_t tx_byte_count;
    uint32_t last_rx_byte;
    uint8_t stream_raw_last_data[16];
    uint8_t stream_last_rx_data[16];
    uint8_t stream_last_tx_launch_data[16];
    char last_command[32];
    char last_reply[96];
    uint32_t host_baud;
    uint32_t host_parity;
    uint32_t host_stop_bit;
    uint32_t probe_config_count;
    uint32_t probe_exchange_count;
    uint32_t probe_best_score;
    uint32_t probe_best_flags;
    uint32_t probe_best_baud;
    uint32_t probe_best_parity;
    uint32_t probe_best_stop_bit;
    uint32_t probe_best_status;
    uint32_t probe_best_reply_len;
    char probe_best_command[32];
    char probe_best_reply[96];
} XE_NP_HJ185_Diag;

volatile XE_NP_HJ185_Diag xe_np_hj185_diag;
static uint8_t ce32_hj185_config_to_app = 0U;
static uint8_t ce32_hj185_vendor_boot_name_applied = 0U;

#define HJ185_DEFAULT_BAUD 115200UL
#define HJ185_CMD_TIMEOUT_MS 250U
#define HJ185_STARTUP_SETTLE_MS 100U
#define HJ185_RESET_SETTLE_MS 500U
#define HJ185_CONFIG_SETTLE_MS 2U
#define HJ185_VENDOR_BOOT_NAME_DELAY_MS 20U
#define HJ185_VENDOR_BOOT_NAME_REPEAT_COUNT 3U
#define HJ185_NAME_WRITE_RETRY_COUNT 3U
#define HJ185_UART_RECOVERY_SETTLE_MS 2U
#define HJ185_RESET_VERIFY_RETRY_COUNT 5U
#define HJ185_EXPECT_WAKEUP_HIGH 0U
#define HJ185_EXPECT_TO_APP 0U
#define HJ185_RECOVERY_BAUD_CANDIDATE_COUNT 10U
#define HJ185_UART_ERROR_ISR_MASK \
    (USART_ISR_PE | USART_ISR_FE | USART_ISR_NE | USART_ISR_ORE)

static size_t CE32_HJ185_StrnLen(const char *text, size_t max_len);
static void CE32_HJ185_ArmPassiveConfigListener(CE32_HJ580_Handle *handle, uint32_t stage);
static void CE32_HJ185_DiagCopyBytes(
    uint8_t *dst,
    uint32_t dst_size,
    const uint8_t *src,
    uint32_t src_len);
static int CE32_HJ185_TryHostUartConfig(
    CE32_HJ580_Handle *handle,
    uint32_t baud,
    uint8_t parity,
    uint8_t stop_bit,
    uint8_t config_to_app);

static uint32_t CE32_HJ185_DiagMapParity(const UART_HandleTypeDef *huart)
{
    if(huart == NULL)
    {
        return 0U;
    }

    switch(huart->Init.Parity)
    {
        case UART_PARITY_EVEN:
            return HJ580_PARITY_EVEN;
        case UART_PARITY_ODD:
            return HJ580_PARITY_ODD;
        case UART_PARITY_NONE:
        default:
            return HJ580_PARITY_NA;
    }
}

static uint32_t CE32_HJ185_DiagMapStopBits(const UART_HandleTypeDef *huart)
{
    if(huart == NULL)
    {
        return 0U;
    }

    switch(huart->Init.StopBits)
    {
        case UART_STOPBITS_2:
            return HJ580_STOPBIT_2;
        case UART_STOPBITS_1:
        default:
            return HJ580_STOPBIT_1;
    }
}

static void CE32_HJ185_DiagCopyString(char *dst, size_t dst_size, const char *src)
{
    size_t copy_len = 0U;

    if((dst == NULL) || (dst_size == 0U))
    {
        return;
    }

    memset(dst, 0, dst_size);
    if(src == NULL)
    {
        return;
    }

    copy_len = CE32_HJ185_StrnLen(src, dst_size - 1U);
    memcpy(dst, src, copy_len);
}

static void CE32_HJ185_DiagCopyBytes(
    uint8_t *dst,
    uint32_t dst_size,
    const uint8_t *src,
    uint32_t src_len)
{
    uint32_t copy_len = src_len;

    if((dst == NULL) || (dst_size == 0U))
    {
        return;
    }

    memset(dst, 0, dst_size);
    if(src == NULL)
    {
        return;
    }

    if(copy_len > dst_size)
    {
        copy_len = dst_size;
    }
    memcpy(dst, src, copy_len);
}

static int CE32_HJ185_ReadConfigReply(
    CE32_HJ580_Handle *handle,
    char *reply,
    uint32_t reply_size)
{
    uint8_t *data_ptr = NULL;
    uint32_t cmd_len = 0U;
    uint32_t copy_len;

    if((handle == NULL) || (reply == NULL) || (reply_size == 0U))
    {
        return -1;
    }

    if(CE32_HJ580_COMMAND_DequeueCmd(&handle->Config_CMD_RX, &data_ptr, &cmd_len) != 0)
    {
        reply[0] = '\0';
        return -1;
    }

    copy_len = cmd_len;
    if(copy_len >= reply_size)
    {
        copy_len = reply_size - 1U;
    }
    memcpy(reply, data_ptr, copy_len);
    reply[copy_len] = '\0';
    return 0;
}

static void CE32_HJ185_DiagReset(void)
{
    memset((void *)&xe_np_hj185_diag, 0, sizeof(xe_np_hj185_diag));
    xe_np_hj185_diag.magic = XE_NP_HJ185_DIAG_MAGIC;
    xe_np_hj185_diag.version = XE_NP_HJ185_DIAG_VERSION;
}

static void CE32_HJ185_DiagSetStage(uint32_t stage)
{
    xe_np_hj185_diag.stage = stage;
}

static void CE32_HJ185_DiagCaptureState(CE32_HJ580_Handle *handle)
{
    xe_np_hj185_diag.last_state = (handle != NULL) ? handle->state : 0U;
    xe_np_hj185_diag.last_gpio_state =
        (HAL_GPIO_ReadPin(HJ_STATE_GPIO_Port, HJ_STATE_Pin) == GPIO_PIN_SET) ? 1U : 0U;
    xe_np_hj185_diag.wake_pin_state =
        (HAL_GPIO_ReadPin(HJ_WAKE_GPIO_Port, HJ_WAKE_Pin) == GPIO_PIN_SET) ? 1U : 0U;
    xe_np_hj185_diag.mode_pin_state =
        (HAL_GPIO_ReadPin(HJ_MODE_GPIO_Port, HJ_MODE_Pin) == GPIO_PIN_SET) ? 1U : 0U;
}

static void CE32_HJ185_DiagCaptureUart(CE32_HJ580_Handle *handle)
{
    UART_HandleTypeDef *huart = NULL;

    if(handle != NULL)
    {
        huart = handle->COMM.huart;
    }

    if((huart == NULL) || (huart->Instance == NULL))
    {
        xe_np_hj185_diag.uart_isr = 0U;
        xe_np_hj185_diag.uart_cr1 = 0U;
        xe_np_hj185_diag.uart_brr = 0U;
        return;
    }

    xe_np_hj185_diag.uart_isr = huart->Instance->ISR;
    xe_np_hj185_diag.uart_cr1 = huart->Instance->CR1;
    xe_np_hj185_diag.uart_brr = huart->Instance->BRR;
    xe_np_hj185_diag.host_baud = huart->Init.BaudRate;
    xe_np_hj185_diag.host_parity = CE32_HJ185_DiagMapParity(huart);
    xe_np_hj185_diag.host_stop_bit = CE32_HJ185_DiagMapStopBits(huart);
}

static void CE32_HJ185_ClearUartErrors(UART_HandleTypeDef *huart)
{
    uint32_t isr;
    uint32_t icr = 0U;
    uint32_t error_flags;

    if((huart == NULL) || (huart->Instance == NULL))
    {
        return;
    }

    isr = huart->Instance->ISR;
    error_flags = isr & HJ185_UART_ERROR_ISR_MASK;
    if(error_flags == 0U)
    {
        return;
    }

    if((error_flags & USART_ISR_PE) != 0U)
    {
        icr |= USART_ICR_PECF;
    }
    if((error_flags & USART_ISR_FE) != 0U)
    {
        icr |= USART_ICR_FECF;
    }
    if((error_flags & USART_ISR_NE) != 0U)
    {
        icr |= USART_ICR_NECF;
    }
    if((error_flags & USART_ISR_ORE) != 0U)
    {
        icr |= USART_ICR_ORECF;
    }

    if((isr & CE32_UART_ISR_RXNE) != 0U)
    {
        (void)huart->Instance->RDR;
    }
    huart->Instance->ICR = icr;
    xe_np_hj185_diag.uart_error_flags |= error_flags;
    xe_np_hj185_diag.uart_error_count++;
}

static void CE32_HJ185_DiagCaptureExchange(
    CE32_HJ580_Handle *handle,
    const char *command,
    const char *reply,
    int status)
{
    size_t command_len = 0U;
    size_t reply_len = 0U;

    xe_np_hj185_diag.last_status = (uint32_t)status;
    CE32_HJ185_DiagCaptureState(handle);
    CE32_HJ185_DiagCaptureUart(handle);

    if(command != NULL)
    {
        command_len = CE32_HJ185_StrnLen(command, sizeof(xe_np_hj185_diag.last_command) - 1U);
    }
    if(reply != NULL)
    {
        reply_len = CE32_HJ185_StrnLen(reply, sizeof(xe_np_hj185_diag.last_reply) - 1U);
    }

    CE32_HJ185_DiagCopyString((char *)xe_np_hj185_diag.last_command, sizeof(xe_np_hj185_diag.last_command), command);
    CE32_HJ185_DiagCopyString((char *)xe_np_hj185_diag.last_reply, sizeof(xe_np_hj185_diag.last_reply), reply);

    xe_np_hj185_diag.last_reply_len = (uint32_t)reply_len;
}

static void CE32_HJ185_DiagCapturePassiveFrame(const char *reply, uint32_t reply_len)
{
    if(reply == NULL)
    {
        return;
    }

    xe_np_hj185_diag.last_status = 1U;
    xe_np_hj185_diag.last_reply_len = reply_len;
    CE32_HJ185_DiagCopyString(
        (char *)xe_np_hj185_diag.last_reply,
        sizeof(xe_np_hj185_diag.last_reply),
        reply);
}

static size_t CE32_HJ185_StrnLen(const char *text, size_t max_len)
{
    size_t len = 0U;

    if(text == NULL)
    {
        return 0U;
    }

    while((len < max_len) && (text[len] != '\0'))
    {
        ++len;
    }

    return len;
}

static int CE32_HJ185_CommandMatches(const char *reply, const char *prefix)
{
    size_t prefix_len;

    if((reply == NULL) || (prefix == NULL))
    {
        return 0;
    }

    prefix_len = strlen(prefix);
    return (strncmp(reply, prefix, prefix_len) == 0) ? 1 : 0;
}

static const uint32_t ce32_hj185_recovery_bauds[HJ185_RECOVERY_BAUD_CANDIDATE_COUNT] =
{
    115200UL,
    19200UL,
    57600UL,
    38400UL,
    9600UL,
    230400UL,
    460800UL,
    921600UL,
    4800UL,
    2400UL
};

static int CE32_HJ185_ParseReplyBitValue(
    const char *reply,
    const char *prefix,
    uint8_t *value)
{
    size_t prefix_len;

    if((reply == NULL) || (prefix == NULL) || (value == NULL))
    {
        return -1;
    }

    prefix_len = strlen(prefix);
    if(strncmp(reply, prefix, prefix_len) != 0)
    {
        return -1;
    }

    if(reply[prefix_len] == '0')
    {
        *value = 0U;
        return 0;
    }
    if(reply[prefix_len] == '1')
    {
        *value = 1U;
        return 0;
    }

    return -1;
}

static uint32_t CE32_HJ185_ProbeCommandFlags(const char *command)
{
    if(command == NULL)
    {
        return 0U;
    }
    if(strcmp(command, "<RD_SOFT_VERSION>") == 0)
    {
        return XE_NP_HJ185_PROBE_FLAG_CMD_RD_SOFT_VERSION;
    }
    if(strcmp(command, "<RD_TO_APP>") == 0)
    {
        return XE_NP_HJ185_PROBE_FLAG_CMD_RD_TO_APP;
    }
    if(strcmp(command, "<RD_APP_CONFIG>") == 0)
    {
        return XE_NP_HJ185_PROBE_FLAG_CMD_RD_APP_CONFIG;
    }
    if(strcmp(command, "<RD_NAME>") == 0)
    {
        return XE_NP_HJ185_PROBE_FLAG_CMD_RD_NAME;
    }

    return 0U;
}

static uint32_t CE32_HJ185_ClassifyProbeReply(const char *command, const char *reply, int status)
{
    uint32_t flags = CE32_HJ185_ProbeCommandFlags(command);
    uint8_t bit_value = 0U;

    if((status != 0) || (reply == NULL) || (reply[0] == '\0'))
    {
        return flags | XE_NP_HJ185_PROBE_FLAG_TIMEOUT;
    }

    flags |= XE_NP_HJ185_PROBE_FLAG_REPLY;
    if(strncmp(reply, "<!", 2U) == 0)
    {
        flags |= XE_NP_HJ185_PROBE_FLAG_ERROR_TOKEN;
    }

    if((flags & XE_NP_HJ185_PROBE_FLAG_CMD_RD_SOFT_VERSION) != 0U)
    {
        if(CE32_HJ185_CommandMatches(reply, "<rd_soft_version=") != 0)
        {
            flags |= XE_NP_HJ185_PROBE_FLAG_VALID_PREFIX | XE_NP_HJ185_PROBE_FLAG_VALUE_PARSED;
        }
        return flags;
    }

    if((flags & XE_NP_HJ185_PROBE_FLAG_CMD_RD_TO_APP) != 0U)
    {
        if(CE32_HJ185_ParseReplyBitValue(reply, "<rd_to_app=", &bit_value) == 0)
        {
            flags |= XE_NP_HJ185_PROBE_FLAG_VALID_PREFIX | XE_NP_HJ185_PROBE_FLAG_VALUE_PARSED;
        }
        return flags;
    }

    if((flags & XE_NP_HJ185_PROBE_FLAG_CMD_RD_APP_CONFIG) != 0U)
    {
        if(CE32_HJ185_ParseReplyBitValue(reply, "<rd_app_config=", &bit_value) == 0)
        {
            flags |= XE_NP_HJ185_PROBE_FLAG_VALID_PREFIX | XE_NP_HJ185_PROBE_FLAG_VALUE_PARSED;
        }
        return flags;
    }

    if((flags & XE_NP_HJ185_PROBE_FLAG_CMD_RD_NAME) != 0U)
    {
        if(CE32_HJ185_CommandMatches(reply, "<rd_name=") != 0)
        {
            flags |= XE_NP_HJ185_PROBE_FLAG_VALID_PREFIX | XE_NP_HJ185_PROBE_FLAG_VALUE_PARSED;
        }
    }

    return flags;
}

static uint32_t CE32_HJ185_ProbeScore(uint32_t flags)
{
    if((flags & XE_NP_HJ185_PROBE_FLAG_VALUE_PARSED) != 0U)
    {
        return 5U;
    }
    if((flags & XE_NP_HJ185_PROBE_FLAG_VALID_PREFIX) != 0U)
    {
        return 4U;
    }
    if((flags & XE_NP_HJ185_PROBE_FLAG_ERROR_TOKEN) != 0U)
    {
        return 3U;
    }
    if((flags & XE_NP_HJ185_PROBE_FLAG_REPLY) != 0U)
    {
        return 2U;
    }

    return 1U;
}

static void CE32_HJ185_DiagNoteProbeAttempt(
    CE32_HJ580_Handle *handle,
    const char *command,
    const char *reply,
    int status)
{
    uint32_t flags;
    uint32_t score;
    uint32_t reply_len = 0U;

    CE32_HJ185_DiagCaptureUart(handle);
    xe_np_hj185_diag.probe_exchange_count++;

    flags = CE32_HJ185_ClassifyProbeReply(command, reply, status);
    score = CE32_HJ185_ProbeScore(flags);
    if(reply != NULL)
    {
        reply_len = (uint32_t)CE32_HJ185_StrnLen(reply, sizeof(xe_np_hj185_diag.probe_best_reply) - 1U);
    }

    if((score < xe_np_hj185_diag.probe_best_score) ||
       ((score == xe_np_hj185_diag.probe_best_score) &&
        (reply_len <= xe_np_hj185_diag.probe_best_reply_len)))
    {
        return;
    }

    xe_np_hj185_diag.probe_best_score = score;
    xe_np_hj185_diag.probe_best_flags = flags;
    xe_np_hj185_diag.probe_best_baud = xe_np_hj185_diag.host_baud;
    xe_np_hj185_diag.probe_best_parity = xe_np_hj185_diag.host_parity;
    xe_np_hj185_diag.probe_best_stop_bit = xe_np_hj185_diag.host_stop_bit;
    xe_np_hj185_diag.probe_best_status = (uint32_t)status;
    xe_np_hj185_diag.probe_best_reply_len = reply_len;
    CE32_HJ185_DiagCopyString(
        (char *)xe_np_hj185_diag.probe_best_command,
        sizeof(xe_np_hj185_diag.probe_best_command),
        command);
    CE32_HJ185_DiagCopyString(
        (char *)xe_np_hj185_diag.probe_best_reply,
        sizeof(xe_np_hj185_diag.probe_best_reply),
        reply);
}

static int CE32_HJ185_ParseReplyUInt(
    const char *reply,
    const char *prefix,
    uint32_t *value)
{
    size_t prefix_len;
    unsigned long parsed = 0UL;

    if((reply == NULL) || (prefix == NULL) || (value == NULL))
    {
        return -1;
    }

    prefix_len = strlen(prefix);
    if(strncmp(reply, prefix, prefix_len) != 0)
    {
        return -1;
    }

    if(sscanf(reply + prefix_len, "%lu", &parsed) != 1)
    {
        return -1;
    }

    *value = (uint32_t)parsed;
    return 0;
}

static int CE32_HJ185_ParseHexNibble(char ch, uint8_t *value)
{
    if(value == NULL)
    {
        return -1;
    }

    if((ch >= '0') && (ch <= '9'))
    {
        *value = (uint8_t)(ch - '0');
        return 0;
    }
    if((ch >= 'A') && (ch <= 'F'))
    {
        *value = (uint8_t)(10 + (ch - 'A'));
        return 0;
    }
    if((ch >= 'a') && (ch <= 'f'))
    {
        *value = (uint8_t)(10 + (ch - 'a'));
        return 0;
    }

    return -1;
}

static void CE32_HJ185_FlushUartRx(UART_HandleTypeDef *huart)
{
    if((huart == NULL) || (huart->Instance == NULL))
    {
        return;
    }

    while((huart->Instance->ISR & CE32_UART_ISR_RXNE) != 0U)
    {
        (void)huart->Instance->RDR;
    }
    CE32_HJ185_ClearUartErrors(huart);
}

static int CE32_HJ185_MapHostParity(
    uint8_t parity,
    uint32_t *hal_word_length,
    uint32_t *hal_parity)
{
    if((hal_word_length == NULL) || (hal_parity == NULL))
    {
        return -1;
    }

    switch(parity)
    {
        case HJ580_PARITY_NA:
            *hal_word_length = UART_WORDLENGTH_8B;
            *hal_parity = UART_PARITY_NONE;
            return 0;
        case HJ580_PARITY_ODD:
            *hal_word_length = UART_WORDLENGTH_9B;
            *hal_parity = UART_PARITY_ODD;
            return 0;
        case HJ580_PARITY_EVEN:
            *hal_word_length = UART_WORDLENGTH_9B;
            *hal_parity = UART_PARITY_EVEN;
            return 0;
        default:
            return -1;
    }
}

static int CE32_HJ185_ReconfigureHostUart(
    CE32_HJ580_Handle *handle,
    uint32_t baud,
    uint8_t parity,
    uint8_t stop_bit)
{
    UART_HandleTypeDef *huart;
    uint32_t hal_word_length = 0U;
    uint32_t hal_parity = 0U;
    uint32_t hal_stop_bits = 0U;

    if(handle == NULL)
    {
        return -1;
    }

    huart = handle->COMM.huart;
    if((huart == NULL) || (huart->Instance == NULL))
    {
        return -1;
    }

    if(CE32_HJ185_MapHostParity(parity, &hal_word_length, &hal_parity) != 0)
    {
        return -1;
    }

    switch(stop_bit)
    {
        case HJ580_STOPBIT_1:
            hal_stop_bits = UART_STOPBITS_1;
            break;
        case HJ580_STOPBIT_2:
            hal_stop_bits = UART_STOPBITS_2;
            break;
        default:
            return -1;
    }

    (void)CE32_INTERCOM_TX_Stop_All((CE32_INTERCOM_Handle *)handle);
    CE32_HJ580_COMMAND_DiscardAll(&handle->Config_CMD_RX);
    CE32_HJ580_COMMAND_DiscardAll(&handle->Config_CMD_TX);
    (void)HAL_UART_Abort(huart);
    if(HAL_UART_DeInit(huart) != HAL_OK)
    {
        return -1;
    }

    huart->Init.BaudRate = baud;
    huart->Init.WordLength = hal_word_length;
    huart->Init.StopBits = hal_stop_bits;
    huart->Init.Parity = hal_parity;
    huart->Init.Mode = UART_MODE_TX_RX;
    huart->Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart->Init.OverSampling = UART_OVERSAMPLING_16;
    huart->Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
    huart->Init.ClockPrescaler = UART_PRESCALER_DIV1;
    huart->AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
    if(HAL_UART_Init(huart) != HAL_OK)
    {
        return -1;
    }
    if(HAL_UARTEx_SetTxFifoThreshold(huart, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
    {
        return -1;
    }
    if(HAL_UARTEx_SetRxFifoThreshold(huart, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
    {
        return -1;
    }
    if(HAL_UARTEx_DisableFifoMode(huart) != HAL_OK)
    {
        return -1;
    }

    handle->COMM.UART = huart->Instance;
    CE32_HJ185_FlushUartRx(huart);
    INTERCOM_UART_ENABLE((CE32_INTERCOM_Handle *)handle);
    INTERCOM_UART_RXIT_ENABLE((CE32_INTERCOM_Handle *)handle);
    CE32_HJ185_DiagCaptureUart(handle);
    return 0;
}

static int CE32_HJ185_ParseMacString(const char *ascii, uint8_t *mac_out)
{
    uint8_t high;
    uint8_t low;

    if((ascii == NULL) || (mac_out == NULL))
    {
        return -1;
    }

    for(uint8_t byte_index = 0U; byte_index < 6U; ++byte_index)
    {
        if((CE32_HJ185_ParseHexNibble(ascii[byte_index * 2U], &high) != 0) ||
           (CE32_HJ185_ParseHexNibble(ascii[byte_index * 2U + 1U], &low) != 0))
        {
            return -1;
        }
        mac_out[byte_index] = (uint8_t)((high << 4U) | low);
    }

    return 0;
}

static void CE32_HJ185_FormatMacString(const uint8_t *mac, char *ascii, uint32_t ascii_size)
{
    static const char hex_lut[] = "0123456789ABCDEF";

    if((mac == NULL) || (ascii == NULL) || (ascii_size < 13U))
    {
        return;
    }

    for(uint8_t byte_index = 0U; byte_index < 6U; ++byte_index)
    {
        ascii[byte_index * 2U] = hex_lut[(mac[byte_index] >> 4U) & 0x0FU];
        ascii[byte_index * 2U + 1U] = hex_lut[mac[byte_index] & 0x0FU];
    }
    ascii[12] = '\0';
}

static void CE32_HJ185_SelectUartRxEnabled(void)
{
    HAL_GPIO_WritePin(HJ_WAKE_GPIO_Port, HJ_WAKE_Pin, GPIO_PIN_RESET);
}

static void CE32_HJ185_SelectUartRxPinHigh(void)
{
    HAL_GPIO_WritePin(HJ_WAKE_GPIO_Port, HJ_WAKE_Pin, GPIO_PIN_SET);
}

static void CE32_HJ185_SetConfigPath(uint8_t to_app)
{
    ce32_hj185_config_to_app = (to_app != 0U) ? 1U : 0U;
}

static void CE32_HJ185_SelectBleDataPath(void)
{
    HAL_GPIO_WritePin(HJ_MODE_GPIO_Port, HJ_MODE_Pin, GPIO_PIN_RESET);
}

static void CE32_HJ185_SelectAppPath(void)
{
    /*
     * On this board HJ_MODE is wired to HJ185 P0.18. The HJ185 docs expose
     * that latch as TO_APP, where x=0 keeps UART on the BLE transparent path
     * and x=1 diverts UART traffic to the module APP path. Runtime BLE data
     * stays on the transparent path, but the config handshake now probes both
     * mux states before concluding the command parser is unreachable.
     */
    HAL_GPIO_WritePin(
        HJ_MODE_GPIO_Port,
        HJ_MODE_Pin,
        (ce32_hj185_config_to_app != 0U) ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

static void CE32_HJ185_EnterDirectCommandSession(CE32_HJ580_Handle *handle)
{
    if((handle == NULL) || (handle->COMM.huart == NULL))
    {
        return;
    }

    CE32_HJ185_SelectBleDataPath();
    (void)CE32_INTERCOM_TX_Stop_All((CE32_INTERCOM_Handle *)handle);
    CE32_HJ185_FlushUartRx(handle->COMM.huart);
    handle->state &= (uint16_t)(~(HJ580_STATE_ERROR | HJ580_STATE_WAITRESP | HJ580_STATE_CMD_RESP_PEND));
    handle->state |= HJ580_STATE_CONFIG;
    HAL_Delay(HJ185_UART_RECOVERY_SETTLE_MS);
}

static void CE32_HJ185_ExitDirectCommandSession(CE32_HJ580_Handle *handle)
{
    if(handle == NULL)
    {
        return;
    }

    handle->state &= (uint16_t)(~(HJ580_STATE_CONFIG | HJ580_STATE_WAITRESP | HJ580_STATE_CMD_RESP_PEND));
    CE32_INTERCOM_UART_TX_DMA_Init((CE32_INTERCOM_Handle *)handle);
}

static int CE32_HJ185_FindCommandPath(
    CE32_HJ580_Handle *handle,
    uint8_t *wakeup_pin_high)
{
    static const uint8_t wake_candidates[2] = {0U, 1U};
    static const uint8_t path_candidates[2] = {0U, 1U};
    static const uint8_t parity_candidates[2] = {HJ580_PARITY_NA, HJ580_PARITY_EVEN};

    if((handle == NULL) || (wakeup_pin_high == NULL))
    {
        return -1;
    }

    /* Try the factory UART setting on all routed wake/path combinations first.
     * This keeps the normal boot fast while still recovering a saved TO_APP or
     * WAKEUP_HIGH configuration from an earlier image. */
    for(uint32_t wake_index = 0U; wake_index < 2U; ++wake_index)
    {
        if(wake_candidates[wake_index] == 0U)
        {
            CE32_HJ185_SelectUartRxEnabled();
        }
        else
        {
            CE32_HJ185_SelectUartRxPinHigh();
        }

        for(uint32_t path_index = 0U; path_index < 2U; ++path_index)
        {
            if(CE32_HJ185_TryHostUartConfig(
                   handle,
                   HJ185_DEFAULT_BAUD,
                   HJ580_PARITY_NA,
                   HJ580_STOPBIT_1,
                   path_candidates[path_index]) == 0)
            {
                *wakeup_pin_high = wake_candidates[wake_index];
                return 0;
            }
        }
    }

    /* A field unit may have retained a non-default baud/parity. Scan every
     * documented recovery baud only after the four fast-path attempts fail. */
    for(uint32_t wake_index = 0U; wake_index < 2U; ++wake_index)
    {
        if(wake_candidates[wake_index] == 0U)
        {
            CE32_HJ185_SelectUartRxEnabled();
        }
        else
        {
            CE32_HJ185_SelectUartRxPinHigh();
        }

        for(uint32_t path_index = 0U; path_index < 2U; ++path_index)
        {
            for(uint32_t baud_index = 0U;
                baud_index < HJ185_RECOVERY_BAUD_CANDIDATE_COUNT;
                ++baud_index)
            {
                uint32_t baud = ce32_hj185_recovery_bauds[baud_index];

                for(uint32_t parity_index = 0U; parity_index < 2U; ++parity_index)
                {
                    uint8_t parity = parity_candidates[parity_index];

                    if((baud == HJ185_DEFAULT_BAUD) && (parity == HJ580_PARITY_NA))
                    {
                        continue;
                    }
                    if(CE32_HJ185_TryHostUartConfig(
                           handle,
                           baud,
                           parity,
                           HJ580_STOPBIT_1,
                           path_candidates[path_index]) == 0)
                    {
                        *wakeup_pin_high = wake_candidates[wake_index];
                        return 0;
                    }
                }
            }
        }
    }

    CE32_HJ185_SelectUartRxEnabled();
    CE32_HJ185_SetConfigPath(0U);
    CE32_HJ185_SelectAppPath();
    (void)CE32_HJ185_ReconfigureHostUart(
        handle,
        HJ185_DEFAULT_BAUD,
        HJ580_PARITY_NA,
        HJ580_STOPBIT_1);
    return -1;
}

static void CE32_HJ185_InitOptionalPins(void)
{
    /*
     * USB384_NP routes the HJ185 UART, P0.01 wake, P0.04 state, and P0.18
     * UART-path select. P0.16 APP-config is not routed, P0.20/SIMPAIR is tied
     * low, and P0.21/nRESET is tied to the 1V8 rail rather than MCU GPIO, so
     * keep the bring-up logic focused on the routed control lines.
     */
}

static void CE32_HJ185_ResetPulse(void)
{
    HAL_Delay(HJ185_STARTUP_SETTLE_MS);
}

static void CE32_HJ185_RefreshConnectedState(CE32_HJ580_Handle *handle)
{
    if(handle == NULL)
    {
        return;
    }

    if(HAL_GPIO_ReadPin(HJ_STATE_GPIO_Port, HJ_STATE_Pin) == GPIO_PIN_SET)
    {
        handle->state |= HJ580_STATE_CONNECTED;
    }
    else if((handle->state & HJ580_STATE_MASTER) == 0U)
    {
        handle->state &= (uint16_t)(~HJ580_STATE_CONNECTED);
    }
}

static int CE32_HJ185_SendCommand(
    CE32_HJ580_Handle *handle,
    const char *command,
    char *reply,
    uint32_t reply_size)
{
    int status = -1;

    if((handle == NULL) || (command == NULL))
    {
        CE32_HJ185_DiagCaptureExchange(handle, command, NULL, -1);
        return -1;
    }

    CE32_HJ580_COMMAND_DiscardAll(&handle->Config_CMD_RX);
    if(CE32_HJ580_COMMAND_EnqueueCmd_MEMCopy(
           &handle->Config_CMD_TX,
           (unsigned char *)command,
           (int)strlen(command)) != 0)
    {
        CE32_HJ185_DiagCaptureExchange(handle, command, NULL, -2);
        return -1;
    }

    CE32_HJ580_TX_Start(handle);
    if(HJ_WaitCmdResp(handle) != 0)
    {
        CE32_HJ185_DiagCaptureExchange(handle, command, NULL, -3);
        return -1;
    }

    if((reply != NULL) && (reply_size != 0U))
    {
        status = CE32_HJ185_ReadConfigReply(handle, reply, reply_size);
        CE32_HJ185_DiagCaptureExchange(handle, command, (status == 0) ? reply : NULL, status);
        return status;
    }

    status = CE32_HJ580_COMMAND_DequeueCmd(&handle->Config_CMD_RX, NULL, NULL);
    CE32_HJ185_DiagCaptureExchange(handle, command, NULL, status);
    return status;
}

__attribute__((unused)) static void CE32_HJ185_BlindSendCommand(
    CE32_HJ580_Handle *handle,
    const char *command)
{
    size_t command_len;

    if((handle == NULL) || (handle->COMM.huart == NULL) || (handle->COMM.huart->Instance == NULL) ||
       (command == NULL))
    {
        return;
    }

    command_len = strlen(command);
    if(command_len == 0U)
    {
        return;
    }

    CE32_HJ185_FlushUartRx(handle->COMM.huart);
    (void)HAL_UART_Transmit(
        handle->COMM.huart,
        (uint8_t *)command,
        (uint16_t)command_len,
        HJ185_CMD_TIMEOUT_MS);
    xe_np_hj185_diag.tx_byte_count += (uint32_t)command_len;
    HAL_Delay(20U);
}

static void CE32_HJ185_BlindSendCommandVariants(
    CE32_HJ580_Handle *handle,
    const char *uppercase_command,
    const char *lowercase_command)
{
    if((handle == NULL) || (uppercase_command == NULL))
    {
        return;
    }

    CE32_HJ185_BlindSendCommand(handle, uppercase_command);
    if((lowercase_command != NULL) && (strcmp(uppercase_command, lowercase_command) != 0))
    {
        CE32_HJ185_BlindSendCommand(handle, lowercase_command);
    }
}

static void CE32_HJ185_VendorBootBlindApplyName(CE32_HJ580_Handle *handle)
{
    char command_upper[96];
    char command_lower[96];
    uint32_t restore_baud;
    uint8_t restore_parity;
    uint8_t restore_stop_bit;
    size_t name_len;

    if((handle == NULL) || (handle->COMM.huart == NULL))
    {
        return;
    }

    name_len = CE32_HJ185_StrnLen(handle->DeviceName, sizeof(handle->DeviceName));
    if(name_len == 0U)
    {
        return;
    }
    if(name_len > 29U)
    {
        name_len = 29U;
        handle->DeviceName[name_len] = '\0';
    }

    restore_baud = (handle->baud != 0U) ? handle->baud : HJ185_DEFAULT_BAUD;
    restore_parity = handle->parity;
    restore_stop_bit = (handle->stop_bit != 0U) ? handle->stop_bit : HJ580_STOPBIT_1;
    snprintf(command_upper, sizeof(command_upper), "<ST_NAME=%s>", handle->DeviceName);
    snprintf(command_lower, sizeof(command_lower), "<st_name=%s>", handle->DeviceName);

    CE32_HJ185_SetConfigPath(0U);
    CE32_HJ185_SelectUartRxEnabled();
    CE32_HJ185_SelectBleDataPath();
    (void)CE32_HJ185_ReconfigureHostUart(handle, restore_baud, restore_parity, restore_stop_bit);
    HAL_Delay(HJ185_VENDOR_BOOT_NAME_DELAY_MS);
    CE32_HJ185_BlindSendCommandVariants(handle, "<ST_ADV_ONOFF=0>", "<st_adv_onoff=0>");
    HAL_Delay(HJ185_VENDOR_BOOT_NAME_DELAY_MS);
    for(uint32_t attempt = 0U; attempt < HJ185_VENDOR_BOOT_NAME_REPEAT_COUNT; ++attempt)
    {
        CE32_HJ185_BlindSendCommandVariants(handle, command_upper, command_lower);
        HAL_Delay(HJ185_VENDOR_BOOT_NAME_DELAY_MS);
    }
    CE32_HJ185_BlindSendCommandVariants(handle, "<ST_ADV_ONOFF=1>", "<st_adv_onoff=1>");
    CE32_HJ185_DiagCaptureState(handle);
    CE32_HJ185_DiagCaptureUart(handle);
    ce32_hj185_vendor_boot_name_applied = 1U;

    (void)CE32_HJ185_ReconfigureHostUart(handle, restore_baud, restore_parity, restore_stop_bit);
    handle->baud = restore_baud;
    handle->parity = restore_parity;
    handle->stop_bit = restore_stop_bit;
}

void CE32_HJ185_BootBlindApplyNameEarly(UART_HandleTypeDef *huart, const char *device_name)
{
    size_t name_len;

    if((huart == NULL) || (device_name == NULL) || (ce32_hj185_vendor_boot_name_applied != 0U))
    {
        return;
    }

    name_len = CE32_HJ185_StrnLen(device_name, sizeof(BLE_handle.DeviceName) - 1U);
    if(name_len == 0U)
    {
        return;
    }

    CE32_HJ580_COMMAND_Init(&BLE_handle.Config_CMD_RX);
    CE32_HJ580_COMMAND_Init(&BLE_handle.Config_CMD_TX);
    BLE_handle.COMM.huart = huart;
    BLE_handle.COMM.UART = huart->Instance;
    BLE_handle.baud = HJ185_DEFAULT_BAUD;
    BLE_handle.parity = HJ580_PARITY_NA;
    BLE_handle.stop_bit = HJ580_STOPBIT_1;
    memcpy(BLE_handle.DeviceName, device_name, name_len);
    BLE_handle.DeviceName[name_len] = '\0';

    CE32_HJ185_VendorBootBlindApplyName(&BLE_handle);
}

static void CE32_HJ185_BlindApplyName(CE32_HJ580_Handle *handle)
{
    char command_upper[96];
    char command_lower[96];
    uint32_t restore_baud;
    uint8_t restore_parity;
    uint8_t restore_stop_bit;
    size_t name_len;

    if(handle == NULL)
    {
        return;
    }

    name_len = CE32_HJ185_StrnLen(handle->DeviceName, sizeof(handle->DeviceName));
    if(name_len == 0U)
    {
        return;
    }
    if(name_len > 29U)
    {
        name_len = 29U;
        handle->DeviceName[name_len] = '\0';
    }

    restore_baud = (handle->baud != 0U) ? handle->baud : HJ185_DEFAULT_BAUD;
    restore_parity = handle->parity;
    restore_stop_bit = (handle->stop_bit != 0U) ? handle->stop_bit : HJ580_STOPBIT_1;
    snprintf(command_upper, sizeof(command_upper), "<ST_NAME=%s>", handle->DeviceName);
    snprintf(command_lower, sizeof(command_lower), "<st_name=%s>", handle->DeviceName);
    CE32_HJ185_SetConfigPath(0U);
    (void)CE32_HJ185_ReconfigureHostUart(handle, restore_baud, restore_parity, restore_stop_bit);
    HAL_Delay(20U);
    HJ580_EnterConfigMode(handle);
    HAL_Delay(20U);
    CE32_HJ185_BlindSendCommandVariants(handle, "<ST_ADV_ONOFF=0>", "<st_adv_onoff=0>");
    HAL_Delay(100U);
    for(uint32_t attempt = 0U; attempt < 3U; ++attempt)
    {
        CE32_HJ185_BlindSendCommandVariants(handle, command_upper, command_lower);
        HAL_Delay(100U);
    }
    CE32_HJ185_BlindSendCommandVariants(handle, "<ST_ADV_ONOFF=1>", "<st_adv_onoff=1>");
    HJ580_ExitConfigMode(handle);
    HAL_Delay(200U);

    (void)CE32_HJ185_ReconfigureHostUart(handle, restore_baud, restore_parity, restore_stop_bit);
    handle->baud = restore_baud;
    handle->parity = restore_parity;
    handle->stop_bit = restore_stop_bit;
    CE32_HJ185_SetConfigPath(0U);
    CE32_HJ185_SelectBleDataPath();
    HAL_Delay(20U);
    if((handle->COMM.huart != NULL) && (handle->COMM.huart->Instance != NULL))
    {
        INTERCOM_UART_ENABLE((CE32_INTERCOM_Handle *)handle);
        INTERCOM_UART_RXIT_ENABLE((CE32_INTERCOM_Handle *)handle);
    }
}

static int CE32_HJ185_QueryVersion(CE32_HJ580_Handle *handle)
{
    char reply[64];
    unsigned int major = 0U;
    unsigned int minor = 0U;
    unsigned int patch = 0U;

    if(CE32_HJ185_SendCommand(handle, "<RD_SOFT_VERSION>", reply, sizeof(reply)) != 0)
    {
        return -1;
    }
    if(CE32_HJ185_CommandMatches(reply, "<rd_soft_version=") == 0)
    {
        return -1;
    }

    if(sscanf(reply, "<rd_soft_version=v%u.%u.%u>", &major, &minor, &patch) >= 2)
    {
        handle->DEV.version = (uint16_t)((major * 100U) + (minor % 100U));
        handle->DEV.hw_version = (uint8_t)(major & 0xFFU);
        return 0;
    }
    if(sscanf(reply, "<rd_soft_version=v%u.%u>", &major, &minor) == 2)
    {
        handle->DEV.version = (uint16_t)((major * 100U) + (minor % 100U));
        handle->DEV.hw_version = (uint8_t)(major & 0xFFU);
        return 0;
    }

    return -1;
}

static int CE32_HJ185_ResetBle(CE32_HJ580_Handle *handle)
{
    char reply[64];

    if(CE32_HJ185_SendCommand(handle, "<ST_RESET_BLE>", reply, sizeof(reply)) != 0)
    {
        return -1;
    }

    return (CE32_HJ185_CommandMatches(reply, "<st_reset_ble=ok>") != 0) ? 0 : -1;
}

static int CE32_HJ185_TryResetBeforeConfigure(CE32_HJ580_Handle *handle)
{
    if((handle == NULL) || (handle->COMM.huart == NULL))
    {
        return -1;
    }

    if(CE32_HJ185_ResetBle(handle) != 0)
    {
        return -1;
    }

    HJ580_ExitConfigMode(handle);
    HAL_Delay(HJ185_RESET_SETTLE_MS);
    HJ580_EnterConfigMode(handle);
    handle->state &= (uint16_t)(~(HJ580_STATE_ERROR | HJ580_STATE_WAITRESP | HJ580_STATE_CMD_RESP_PEND));
    HAL_Delay(HJ185_UART_RECOVERY_SETTLE_MS);
    return CE32_HJ_HandShake(handle);
}

static int CE32_HJ185_QueryLocalMac(CE32_HJ580_Handle *handle)
{
    char reply[64];
    const char *payload;

    if(CE32_HJ185_SendCommand(handle, "<RD_BLE_MAC>", reply, sizeof(reply)) != 0)
    {
        return -1;
    }
    if(CE32_HJ185_CommandMatches(reply, "<rd_ble_mac=") == 0)
    {
        return -1;
    }

    payload = reply + strlen("<rd_ble_mac=");
    if(CE32_HJ185_ParseMacString(payload, handle->DEV.MAC) != 0)
    {
        return -1;
    }
    memcpy(handle->DeviceMAC, handle->DEV.MAC, sizeof(handle->DeviceMAC));
    return 0;
}

static void CE32_HJ185_RunProbeCommand(CE32_HJ580_Handle *handle, const char *command)
{
    char reply[96];
    int status;

    if((handle == NULL) || (command == NULL))
    {
        return;
    }

    handle->state &= (uint16_t)(~(HJ580_STATE_ERROR | HJ580_STATE_WAITRESP | HJ580_STATE_CMD_RESP_PEND));
    memset(reply, 0, sizeof(reply));
    status = CE32_HJ185_SendCommand(handle, command, reply, sizeof(reply));
    CE32_HJ185_DiagNoteProbeAttempt(handle, command, (status == 0) ? reply : NULL, status);
}

static void CE32_HJ185_RunExtendedUartProbe(CE32_HJ580_Handle *handle)
{
    CE32_HJ185_RunProbeCommand(handle, "<RD_SOFT_VERSION>");
    CE32_HJ185_RunProbeCommand(handle, "<RD_TO_APP>");
    CE32_HJ185_RunProbeCommand(handle, "<RD_APP_CONFIG>");
    CE32_HJ185_RunProbeCommand(handle, "<RD_NAME>");
}

static void CE32_HJ185_ArmPassiveConfigListener(CE32_HJ580_Handle *handle, uint32_t stage)
{
    if((handle == NULL) || (handle->COMM.UART == NULL))
    {
        return;
    }

    CE32_HJ185_DiagSetStage(stage);
    handle->state &= (uint16_t)(~(HJ580_STATE_ERROR | HJ580_STATE_WAITRESP | HJ580_STATE_CMD_RESP_PEND));
    CE32_HJ580_COMMAND_DiscardAll(&handle->Config_CMD_RX);
    CE32_HJ580_COMMAND_DiscardAll(&handle->Config_CMD_TX);
    HJ580_EnterConfigMode(handle);
    INTERCOM_UART_ENABLE((CE32_INTERCOM_Handle *)handle);
    INTERCOM_UART_RXIT_ENABLE((CE32_INTERCOM_Handle *)handle);
    CE32_HJ185_DiagCaptureState(handle);
    CE32_HJ185_DiagCaptureUart(handle);
}

static int CE32_HJ185_QueryName(CE32_HJ580_Handle *handle)
{
    char reply[80];
    const char *prefix = "<rd_name=";
    const char *payload;
    size_t payload_len;

    if(CE32_HJ185_SendCommand(handle, "<RD_NAME>", reply, sizeof(reply)) != 0)
    {
        return -1;
    }
    if(CE32_HJ185_CommandMatches(reply, prefix) == 0)
    {
        return -1;
    }

    payload = reply + strlen(prefix);
    payload_len = strcspn(payload, ">");
    if(payload_len >= sizeof(handle->DeviceName))
    {
        payload_len = sizeof(handle->DeviceName) - 1U;
    }
    memcpy(handle->DeviceName, payload, payload_len);
    handle->DeviceName[payload_len] = '\0';
    return 0;
}

static int CE32_HJ185_QueryWakeupHigh(CE32_HJ580_Handle *handle, uint8_t *value)
{
    char reply[64];

    if((handle == NULL) || (value == NULL))
    {
        return -1;
    }

    if(CE32_HJ185_SendCommand(handle, "<RD_WAKEUP_HIGH>", reply, sizeof(reply)) != 0)
    {
        return -1;
    }

    return CE32_HJ185_ParseReplyBitValue(reply, "<rd_wakeup_high=", value);
}

static int CE32_HJ185_QueryBaud(CE32_HJ580_Handle *handle, uint32_t *baud)
{
    char reply[64];

    if((handle == NULL) || (baud == NULL))
    {
        return -1;
    }

    if(CE32_HJ185_SendCommand(handle, "<RD_BAUD>", reply, sizeof(reply)) != 0)
    {
        return -1;
    }

    return CE32_HJ185_ParseReplyUInt(reply, "<rd_baud=", baud);
}

static int CE32_HJ185_SetBaud(CE32_HJ580_Handle *handle, uint32_t baud)
{
    char command[32];
    char reply[64];

    if(handle == NULL)
    {
        return -1;
    }

    snprintf(command, sizeof(command), "<ST_BAUD=%lu>", (unsigned long)baud);
    if(CE32_HJ185_SendCommand(handle, command, reply, sizeof(reply)) != 0)
    {
        return -1;
    }

    return (CE32_HJ185_CommandMatches(reply, "<st_baud=ok>") != 0) ? 0 : -1;
}

static int CE32_HJ185_QueryUartEven(CE32_HJ580_Handle *handle, uint8_t *value)
{
    char reply[64];

    if((handle == NULL) || (value == NULL))
    {
        return -1;
    }

    if(CE32_HJ185_SendCommand(handle, "<RD_UART_EVEN>", reply, sizeof(reply)) != 0)
    {
        return -1;
    }

    return CE32_HJ185_ParseReplyBitValue(reply, "<rd_uart_even=", value);
}

static int CE32_HJ185_SetUartEven(CE32_HJ580_Handle *handle, uint8_t value)
{
    char command[32];
    char reply[64];

    if(handle == NULL)
    {
        return -1;
    }

    snprintf(command, sizeof(command), "<ST_UART_EVEN=%u>", (unsigned int)(value & 0x01U));
    if(CE32_HJ185_SendCommand(handle, command, reply, sizeof(reply)) != 0)
    {
        return -1;
    }

    return (CE32_HJ185_CommandMatches(reply, "<st_uart_even=ok>") != 0) ? 0 : -1;
}

static int CE32_HJ185_SetWakeupHigh(CE32_HJ580_Handle *handle, uint8_t value)
{
    char command[32];
    char reply[64];

    if(handle == NULL)
    {
        return -1;
    }

    snprintf(command, sizeof(command), "<ST_WAKEUP_HIGH=%u>", (unsigned int)(value & 0x01U));
    if(CE32_HJ185_SendCommand(handle, command, reply, sizeof(reply)) != 0)
    {
        return -1;
    }

    return (CE32_HJ185_CommandMatches(reply, "<st_wakeup_high=ok>") != 0) ? 0 : -1;
}

static int CE32_HJ185_EnsureWakeupHigh(CE32_HJ580_Handle *handle, uint8_t expected_value)
{
    uint8_t current_value = 0U;

    if((handle == NULL) || ((expected_value & 0x01U) != expected_value))
    {
        return -1;
    }

    if(CE32_HJ185_QueryWakeupHigh(handle, &current_value) != 0)
    {
        return -1;
    }
    if(current_value == expected_value)
    {
        return 0;
    }

    if(CE32_HJ185_SetWakeupHigh(handle, expected_value) != 0)
    {
        return -1;
    }

    if(CE32_HJ185_QueryWakeupHigh(handle, &current_value) != 0)
    {
        return -1;
    }

    return (current_value == expected_value) ? 0 : -1;
}

static int CE32_HJ185_ForceWakeupLowActive(CE32_HJ580_Handle *handle, uint8_t command_path_uses_high_pin)
{
    uint8_t current_value = 0U;

    if(handle == NULL)
    {
        return -1;
    }

    if(command_path_uses_high_pin == 0U)
    {
        return CE32_HJ185_EnsureWakeupHigh(handle, HJ185_EXPECT_WAKEUP_HIGH);
    }

    /*
     * If the module currently treats P0.01 as high-active then switching to
     * low-active can immediately mute the reply path. Send the write while the
     * high level is still valid, then pull the pin low and verify by query.
     */
    CE32_HJ185_BlindSendCommand(handle, "<ST_WAKEUP_HIGH=0>");
    CE32_HJ185_SelectUartRxEnabled();
    HAL_Delay(HJ185_UART_RECOVERY_SETTLE_MS);

    if(CE32_HJ185_QueryWakeupHigh(handle, &current_value) != 0)
    {
        return -1;
    }

    return (current_value == HJ185_EXPECT_WAKEUP_HIGH) ? 0 : -1;
}

static int CE32_HJ185_QueryToApp(CE32_HJ580_Handle *handle, uint8_t *value)
{
    char reply[64];

    if((handle == NULL) || (value == NULL))
    {
        return -1;
    }

    if(CE32_HJ185_SendCommand(handle, "<RD_TO_APP>", reply, sizeof(reply)) != 0)
    {
        return -1;
    }

    return CE32_HJ185_ParseReplyBitValue(reply, "<rd_to_app=", value);
}

static int CE32_HJ185_SetToApp(CE32_HJ580_Handle *handle, uint8_t value)
{
    char command[24];
    char reply[64];

    if(handle == NULL)
    {
        return -1;
    }

    snprintf(command, sizeof(command), "<ST_TO_APP=%u>", (unsigned int)(value & 0x01U));
    if(CE32_HJ185_SendCommand(handle, command, reply, sizeof(reply)) != 0)
    {
        return -1;
    }

    return (CE32_HJ185_CommandMatches(reply, "<st_to_app=ok>") != 0) ? 0 : -1;
}

static int CE32_HJ185_EnsureToApp(CE32_HJ580_Handle *handle, uint8_t expected_value)
{
    uint8_t current_value = 0U;

    if((handle == NULL) || ((expected_value & 0x01U) != expected_value))
    {
        return -1;
    }

    if(CE32_HJ185_QueryToApp(handle, &current_value) != 0)
    {
        return -1;
    }
    if(current_value == expected_value)
    {
        return 0;
    }

    if(CE32_HJ185_SetToApp(handle, expected_value) != 0)
    {
        return -1;
    }

    if(CE32_HJ185_QueryToApp(handle, &current_value) != 0)
    {
        return -1;
    }

    return (current_value == expected_value) ? 0 : -1;
}

static int CE32_HJ185_QueryAdvOnOff(CE32_HJ580_Handle *handle, uint8_t *value)
{
    char reply[64];

    if((handle == NULL) || (value == NULL))
    {
        return -1;
    }

    if(CE32_HJ185_SendCommand(handle, "<RD_ADV_ONOFF>", reply, sizeof(reply)) != 0)
    {
        return -1;
    }

    return CE32_HJ185_ParseReplyBitValue(reply, "<rd_adv_onoff=", value);
}

static int CE32_HJ185_SetAdvOnOff(CE32_HJ580_Handle *handle, uint8_t value)
{
    char command[32];
    char reply[64];

    if(handle == NULL)
    {
        return -1;
    }

    snprintf(command, sizeof(command), "<ST_ADV_ONOFF=%u>", (unsigned int)(value & 0x01U));
    if(CE32_HJ185_SendCommand(handle, command, reply, sizeof(reply)) != 0)
    {
        return -1;
    }

    return (CE32_HJ185_CommandMatches(reply, "<st_adv_onoff=ok>") != 0) ? 0 : -1;
}

static int CE32_HJ185_EnsureAdvOnOff(CE32_HJ580_Handle *handle, uint8_t expected_value)
{
    uint8_t current_value = 0U;

    if((handle == NULL) || ((expected_value & 0x01U) != expected_value))
    {
        return -1;
    }

    if(CE32_HJ185_QueryAdvOnOff(handle, &current_value) != 0)
    {
        return -1;
    }
    if(current_value == expected_value)
    {
        return 0;
    }

    if(CE32_HJ185_SetAdvOnOff(handle, expected_value) != 0)
    {
        return -1;
    }

    if(CE32_HJ185_QueryAdvOnOff(handle, &current_value) != 0)
    {
        return -1;
    }

    return (current_value == expected_value) ? 0 : -1;
}

static int CE32_HJ185_NormalizeHostAndModuleUart(
    CE32_HJ580_Handle *handle,
    uint32_t desired_baud,
    uint8_t desired_parity,
    uint8_t desired_stop_bit)
{
    uint32_t current_baud = 0U;
    uint8_t current_even = 0U;
    uint8_t desired_even = 0U;

    if((handle == NULL) || (desired_baud == 0U))
    {
        return -1;
    }
    if(desired_stop_bit != HJ580_STOPBIT_1)
    {
        return -1;
    }

    switch(desired_parity)
    {
        case HJ580_PARITY_NA:
            desired_even = 0U;
            break;
        case HJ580_PARITY_EVEN:
            desired_even = 1U;
            break;
        default:
            return -1;
    }

    if(CE32_HJ185_QueryUartEven(handle, &current_even) != 0)
    {
        return -1;
    }
    if(current_even != desired_even)
    {
        if(CE32_HJ185_SetUartEven(handle, desired_even) != 0)
        {
            return -1;
        }
        if(CE32_HJ185_ReconfigureHostUart(handle, handle->baud, desired_parity, desired_stop_bit) != 0)
        {
            return -1;
        }
        if(CE32_HJ_HandShake(handle) != 0)
        {
            return -1;
        }
    }

    if(CE32_HJ185_QueryBaud(handle, &current_baud) != 0)
    {
        return -1;
    }
    if(current_baud != desired_baud)
    {
        if(CE32_HJ185_SetBaud(handle, desired_baud) != 0)
        {
            return -1;
        }
        if(CE32_HJ185_ReconfigureHostUart(handle, desired_baud, desired_parity, desired_stop_bit) != 0)
        {
            return -1;
        }
        if(CE32_HJ_HandShake(handle) != 0)
        {
            return -1;
        }
    }

    handle->baud = desired_baud;
    handle->parity = desired_parity;
    handle->stop_bit = desired_stop_bit;
    return 0;
}

static int CE32_HJ185_SetName(CE32_HJ580_Handle *handle)
{
    char command[96];
    char reply[64];
    size_t name_len;

    if(handle == NULL)
    {
        return -1;
    }

    name_len = CE32_HJ185_StrnLen(handle->DeviceName, sizeof(handle->DeviceName));
    if(name_len == 0U)
    {
        return 0;
    }

    if(name_len > 29U)
    {
        name_len = 29U;
        handle->DeviceName[name_len] = '\0';
    }

    snprintf(command, sizeof(command), "<ST_NAME=%s>", handle->DeviceName);
    if(CE32_HJ185_SendCommand(handle, command, reply, sizeof(reply)) != 0)
    {
        return -1;
    }

    return (CE32_HJ185_CommandMatches(reply, "<st_name=ok>") != 0) ? 0 : -1;
}

int CE32_HJ185_ConfigureNameMinimal(CE32_HJ580_Handle *handle, const char *device_name)
{
    char desired_name[sizeof(BLE_handle.DeviceName)];
    uint8_t command_path_uses_high_pin = 0U;
    size_t name_len;
    uint32_t name_attempt = 0U;
    uint32_t verify_attempt = 0U;

    if((handle == NULL) || (device_name == NULL) || (handle->COMM.huart == NULL))
    {
        return -1;
    }

    name_len = CE32_HJ185_StrnLen(device_name, sizeof(desired_name) - 1U);
    if(name_len == 0U)
    {
        return -1;
    }
    if(name_len > 29U)
    {
        name_len = 29U;
    }

    memset(desired_name, 0, sizeof(desired_name));
    memcpy(desired_name, device_name, name_len);
    memcpy(handle->DeviceName, desired_name, name_len + 1U);

    CE32_HJ185_DiagReset();
    CE32_HJ185_DiagSetStage(20U);
    CE32_HJ185_DiagCaptureState(handle);
    CE32_HJ185_DiagCaptureUart(handle);
    CE32_HJ185_InitOptionalPins();
    CE32_HJ185_SelectBleDataPath();
    CE32_HJ185_SelectUartRxEnabled();
    if(CE32_HJ185_ReconfigureHostUart(handle, HJ185_DEFAULT_BAUD, HJ580_PARITY_NA, HJ580_STOPBIT_1) != 0)
    {
        xe_np_hj185_diag.result = xe_np_hj185_diag.stage;
        goto fail;
    }
    CE32_HJ185_EnterDirectCommandSession(handle);
    HAL_Delay(HJ185_STARTUP_SETTLE_MS);

    CE32_HJ185_DiagSetStage(21U);
    if(CE32_HJ185_FindCommandPath(handle, &command_path_uses_high_pin) != 0)
    {
        xe_np_hj185_diag.result = xe_np_hj185_diag.stage;
        goto fail;
    }

    CE32_HJ185_DiagSetStage(23U);
    if(CE32_HJ185_NormalizeHostAndModuleUart(handle, HJ185_DEFAULT_BAUD, HJ580_PARITY_NA, HJ580_STOPBIT_1) != 0)
    {
        xe_np_hj185_diag.result = xe_np_hj185_diag.stage;
        goto fail;
    }

    CE32_HJ185_DiagSetStage(24U);
    if(CE32_HJ185_ForceWakeupLowActive(handle, command_path_uses_high_pin) != 0)
    {
        xe_np_hj185_diag.result = xe_np_hj185_diag.stage;
        goto fail;
    }

    for(name_attempt = 0U; name_attempt < HJ185_NAME_WRITE_RETRY_COUNT; ++name_attempt)
    {
        CE32_HJ185_DiagSetStage(25U);
        memcpy(handle->DeviceName, desired_name, name_len + 1U);
        if(CE32_HJ185_SetName(handle) == 0)
        {
            CE32_HJ185_DiagSetStage(26U);
            if((CE32_HJ185_QueryName(handle) == 0) &&
               (strcmp(handle->DeviceName, desired_name) == 0))
            {
                break;
            }
            xe_np_hj185_diag.result = 26U;
        }
        else
        {
            xe_np_hj185_diag.result = 25U;
        }
        HAL_Delay(HJ185_VENDOR_BOOT_NAME_DELAY_MS);
    }
    if(name_attempt >= HJ185_NAME_WRITE_RETRY_COUNT)
    {
        goto fail;
    }

    CE32_HJ185_DiagSetStage(27U);
    if(CE32_HJ185_ResetBle(handle) != 0)
    {
        xe_np_hj185_diag.result = xe_np_hj185_diag.stage;
        goto fail;
    }
    HAL_Delay(HJ185_RESET_SETTLE_MS + 300U);

    /* Reset can re-apply the module's saved WAKEUP_HIGH, TO_APP, baud, and
     * parity settings. Rediscover the command path before trusting RD_NAME. */
    CE32_HJ185_DiagSetStage(28U);
    CE32_HJ185_EnterDirectCommandSession(handle);
    if(CE32_HJ185_FindCommandPath(handle, &command_path_uses_high_pin) != 0)
    {
        xe_np_hj185_diag.result = xe_np_hj185_diag.stage;
        goto fail;
    }

    for(verify_attempt = 0U; verify_attempt < HJ185_RESET_VERIFY_RETRY_COUNT; ++verify_attempt)
    {
        if(CE32_HJ185_QueryName(handle) == 0)
        {
            break;
        }
        HAL_Delay(150U);
    }
    if(verify_attempt >= HJ185_RESET_VERIFY_RETRY_COUNT)
    {
        xe_np_hj185_diag.result = xe_np_hj185_diag.stage;
        goto fail;
    }

    if(strcmp(handle->DeviceName, desired_name) != 0)
    {
        xe_np_hj185_diag.result = xe_np_hj185_diag.stage;
        goto fail;
    }

    CE32_HJ185_DiagSetStage(29U);
    if(CE32_HJ185_EnsureAdvOnOff(handle, 1U) != 0)
    {
        xe_np_hj185_diag.result = xe_np_hj185_diag.stage;
        goto fail;
    }

    xe_np_hj185_diag.result = 0U;
    CE32_HJ185_DiagSetStage(30U);
    CE32_HJ185_ExitDirectCommandSession(handle);
    CE32_HJ580_Start(handle);
    return 0;

fail:
    CE32_HJ185_DiagSetStage(31U);
    CE32_HJ185_ExitDirectCommandSession(handle);
    CE32_HJ580_Start(handle);
    return -1;
}

static int CE32_HJ185_QueryLink(
    CE32_HJ580_Handle *handle,
    const char *command,
    const char *prefix,
    uint8_t *mac_out)
{
    char reply[96];
    const char *payload;

    if((handle == NULL) || (command == NULL) || (prefix == NULL) || (mac_out == NULL))
    {
        return -1;
    }

    if(CE32_HJ185_SendCommand(handle, command, reply, sizeof(reply)) != 0)
    {
        return -1;
    }
    if(CE32_HJ185_CommandMatches(reply, prefix) == 0)
    {
        return -1;
    }

    payload = reply + strlen(prefix);
    if(CE32_HJ185_ParseMacString(payload, mac_out) != 0)
    {
        return -1;
    }

    handle->state |= HJ580_STATE_CONNECTED;
    return 0;
}

int CE32_HJ580_COMMAND_Init(CE32_command_cfg *handle)
{
    memset(handle, 0, sizeof(*handle));
    handle->free_buffer = HJ_CFG_CMD_BUFSIZE;
    return 0;
}

int CE32_HJ580_COMMAND_Enqueue_Allocate(CE32_command_cfg *handle, int cmd_len, uint8_t **ptr)
{
    uint16_t start_ptr = (uint16_t)handle->cmd_ptr_in;
    uint16_t byte_till_end = HJ_CFG_CMD_BUFSIZE - start_ptr;
    uint16_t padding = 0U;

    if((handle == NULL) || (ptr == NULL))
    {
        return -1;
    }
    if((cmd_len <= 0) || (cmd_len > HJ_CFG_CMD_BUFSIZE) || (handle->cmd_pending >= HJ_CFG_CMD_SEQ))
    {
        return -1;
    }

    if((uint16_t)cmd_len >= byte_till_end)
    {
        padding = byte_till_end;
        start_ptr = 0U;
    }
    if(handle->free_buffer < (uint16_t)(cmd_len + padding))
    {
        return -1;
    }

    handle->stream_in.addr = &handle->buffer[start_ptr];
    handle->stream_in.len = (uint16_t)cmd_len;
    handle->stream_in.idx = 0U;
    handle->stream_in.logging = 1U;
    handle->cmd_pad[handle->cmd_idx_in] = padding;
    *ptr = (uint8_t *)handle->stream_in.addr;
    return 0;
}

int CE32_HJ580_COMMAND_EnqueueCmd_buffered(CE32_command_cfg *handle)
{
    uint16_t start_ptr;
    uint16_t pad;
    uint32_t idx;

    if((handle == NULL) || (handle->stream_in.logging == 0U) || (handle->cmd_pending >= HJ_CFG_CMD_SEQ))
    {
        return -1;
    }

    idx = handle->cmd_idx_in;
    start_ptr = (uint16_t)(handle->stream_in.addr - handle->buffer);
    pad = handle->cmd_pad[idx];
    if(handle->free_buffer < (uint16_t)(handle->stream_in.len + pad))
    {
        return -1;
    }

    handle->cmd_buf[idx] = (uint8_t *)handle->stream_in.addr;
    handle->cmd_len[idx] = handle->stream_in.len;
    handle->free_buffer -= (uint16_t)(handle->stream_in.len + pad);
    handle->cmd_ptr_in = CMD_ADD_CHK(start_ptr, handle->stream_in.len, HJ_CFG_CMD_BUFSIZE);
    handle->cmd_idx_in = CMD_ADD_CHK(handle->cmd_idx_in, 1U, HJ_CFG_CMD_SEQ);
    handle->cmd_pending++;
    handle->IN_OK++;
    handle->stream_in.logging = 0U;
    handle->stream_in.len = 0U;
    handle->stream_in.idx = 0U;
    return 0;
}

int CE32_HJ580_COMMAND_EnqueueCmd_MEMCopy(CE32_command_cfg *handle, unsigned char *data, int cmd_len)
{
    uint8_t *ptr;

    if((handle == NULL) || (data == NULL))
    {
        return -1;
    }

    if(CE32_HJ580_COMMAND_Enqueue_Allocate(handle, cmd_len, &ptr) != 0)
    {
        return -1;
    }

    memcpy(ptr, data, (size_t)cmd_len);
    return CE32_HJ580_COMMAND_EnqueueCmd_buffered(handle);
}

int CE32_HJ580_COMMAND_Enqueue_Byte(CE32_command_cfg *handle, unsigned char data)
{
    if(handle == NULL)
    {
        return -1;
    }

    if(handle->stream_in.idx >= handle->stream_in.len)
    {
        handle->stream_in.idx++;
        return -1;
    }

    handle->stream_in.addr[handle->stream_in.idx++] = data;
    return 0;
}

int CE32_HJ580_COMMAND_Enqueue_BytesLeft(CE32_command_cfg *handle)
{
    return (handle != NULL) ? (int)(handle->stream_in.len - handle->stream_in.idx) : -1;
}

int CE32_HJ580_COMMAND_Enqueue_Byte_Abort(CE32_command_cfg *handle)
{
    if(handle == NULL)
    {
        return -1;
    }

    handle->stream_in.logging = 0U;
    handle->stream_in.len = 0U;
    handle->stream_in.idx = 0U;
    handle->IN_Fail++;
    return 0;
}

int CE32_HJ580_COMMAND_DequeueCmd(CE32_command_cfg *handle, uint8_t **data_ptr, uint32_t *cmd_len)
{
    uint32_t idx;
    uint32_t out_len;
    uint16_t pad;

    if((handle == NULL) || (handle->cmd_pending == 0U))
    {
        return -1;
    }

    idx = handle->cmd_idx_out;
    out_len = handle->cmd_len[idx];
    pad = handle->cmd_pad[idx];

    if(data_ptr != NULL)
    {
        *data_ptr = (uint8_t *)handle->cmd_buf[idx];
    }
    if(cmd_len != NULL)
    {
        *cmd_len = out_len;
    }

    handle->cmd_idx_out = CMD_ADD_CHK(handle->cmd_idx_out, 1U, HJ_CFG_CMD_SEQ);
    handle->cmd_pending--;
    handle->free_buffer += (uint16_t)out_len;
    handle->free_buffer += pad;
    handle->cmd_pad[idx] = 0U;
    return 0;
}

int CE32_HJ580_COMMAND_Dequeue_Byte(CE32_command_cfg *handle, uint8_t *data)
{
    uint32_t cmd_len;
    uint8_t *ptr;

    if((handle == NULL) || (data == NULL) || (handle->cmd_pending == 0U))
    {
        return -1;
    }

    if(handle->stream_out.logging == 0U)
    {
        if(CE32_HJ580_COMMAND_GetCmdPointer(handle, &ptr, &cmd_len) != 0)
        {
            return -1;
        }
        handle->stream_out.addr = ptr;
        handle->stream_out.len = cmd_len;
        handle->stream_out.idx = 0U;
        handle->stream_out.logging = 1U;
    }

    if(handle->stream_out.idx >= handle->stream_out.len)
    {
        return -1;
    }

    *data = handle->stream_out.addr[handle->stream_out.idx++];
    if(handle->stream_out.idx >= handle->stream_out.len)
    {
        handle->stream_out.logging = 0U;
        handle->stream_out.idx = 0U;
        CE32_HJ580_COMMAND_DequeueCmd(handle, NULL, NULL);
    }

    return 0;
}

int CE32_HJ580_COMMAND_GetPendingCounts(CE32_command_cfg *handle)
{
    return (handle != NULL) ? (int)handle->cmd_pending : -1;
}

int CE32_HJ580_COMMAND_GetCmdPointer(CE32_command_cfg *handle, uint8_t **data_ptr, uint32_t *cmd_len)
{
    if((handle == NULL) || (data_ptr == NULL) || (cmd_len == NULL) || (handle->cmd_pending == 0U))
    {
        return -1;
    }

    *data_ptr = (uint8_t *)handle->cmd_buf[handle->cmd_idx_out];
    *cmd_len = handle->cmd_len[handle->cmd_idx_out];
    return 0;
}

int CE32_HJ580_COMMAND_DiscardAll(CE32_command_cfg *handle)
{
    if(handle == NULL)
    {
        return -1;
    }

    while(CE32_HJ580_COMMAND_DequeueCmd(handle, NULL, NULL) == 0)
    {
    }

    handle->stream_out.logging = 0U;
    handle->stream_out.len = 0U;
    handle->stream_out.idx = 0U;
    return 0;
}

int HJ_WaitCmdResp(CE32_HJ580_Handle *handle)
{
    uint32_t start_tick;

    if(handle == NULL)
    {
        return -1;
    }

    handle->state |= HJ580_STATE_WAITRESP;
    start_tick = HAL_GetTick();

    while(handle->Config_CMD_TX.cmd_pending > 0U)
    {
        CE32_HJ185_ClearUartErrors(handle->COMM.huart);
        if((HAL_GetTick() - start_tick) > HJ185_CMD_TIMEOUT_MS)
        {
            CE32_HJ185_DiagCaptureUart(handle);
            handle->state |= HJ580_STATE_ERROR;
            handle->state &= (uint16_t)(~HJ580_STATE_WAITRESP);
            return 1;
        }
    }

    while(handle->Config_CMD_RX.cmd_pending == 0U)
    {
        CE32_HJ185_ClearUartErrors(handle->COMM.huart);
        if((HAL_GetTick() - start_tick) > HJ185_CMD_TIMEOUT_MS)
        {
            CE32_HJ185_DiagCaptureUart(handle);
            handle->state |= HJ580_STATE_ERROR;
            handle->state &= (uint16_t)(~HJ580_STATE_WAITRESP);
            return 1;
        }
    }

    CE32_HJ185_DiagCaptureUart(handle);
    handle->state &= (uint16_t)(~(HJ580_STATE_WAITRESP | HJ580_STATE_CMD_RESP_PEND));
    return 0;
}

static int CE32_HJ185_TryHostUartConfig(
    CE32_HJ580_Handle *handle,
    uint32_t baud,
    uint8_t parity,
    uint8_t stop_bit,
    uint8_t config_to_app)
{
    if(handle == NULL)
    {
        return -1;
    }

    CE32_HJ185_SetConfigPath(config_to_app);
    CE32_HJ185_SelectAppPath();
    HAL_Delay(HJ185_CONFIG_SETTLE_MS);
    handle->state &= (uint16_t)(~(HJ580_STATE_ERROR | HJ580_STATE_WAITRESP | HJ580_STATE_CMD_RESP_PEND));
    if(CE32_HJ185_ReconfigureHostUart(handle, baud, parity, stop_bit) != 0)
    {
        return -1;
    }
    HAL_Delay(HJ185_UART_RECOVERY_SETTLE_MS);
    xe_np_hj185_diag.probe_config_count++;
    if(CE32_HJ_HandShake(handle) != 0)
    {
        return -1;
    }

    handle->state &= (uint16_t)(~HJ580_STATE_ERROR);
    handle->baud = baud;
    handle->parity = parity;
    handle->stop_bit = stop_bit;
    return 0;
}

static int CE32_HJ_Init_device(CE32_HJ580_Handle *handle)
{
    uint32_t requested_baud;
    uint8_t requested_parity;
    uint8_t requested_stop_bit;
    static const uint8_t path_candidates[2] = {0U, 1U};

    if((handle == NULL) || (handle->COMM.huart == NULL))
    {
        return -1;
    }

    requested_baud = (handle->baud != 0U) ? handle->baud : HJ185_DEFAULT_BAUD;
    requested_parity = handle->parity;
    requested_stop_bit = (handle->stop_bit != 0U) ? handle->stop_bit : HJ580_STOPBIT_1;

    for(uint32_t path_index = 0U; path_index < 2U; ++path_index)
    {
        uint8_t attempted_default = 0U;
        uint8_t config_to_app = path_candidates[path_index];

        if(CE32_HJ185_TryHostUartConfig(
               handle,
               requested_baud,
               requested_parity,
               requested_stop_bit,
               config_to_app) == 0)
        {
            return 0;
        }
        attempted_default = 1U;

        for(uint32_t baud_index = 0U; baud_index < HJ185_RECOVERY_BAUD_CANDIDATE_COUNT; ++baud_index)
        {
            uint32_t baud = ce32_hj185_recovery_bauds[baud_index];
            uint8_t parity_candidates[2] = {HJ580_PARITY_NA, HJ580_PARITY_EVEN};

            for(uint32_t parity_index = 0U; parity_index < 2U; ++parity_index)
            {
                uint8_t parity = parity_candidates[parity_index];

                if((attempted_default != 0U) &&
                   (baud == requested_baud) &&
                   (parity == requested_parity))
                {
                    continue;
                }

                if(CE32_HJ185_TryHostUartConfig(
                       handle,
                       baud,
                       parity,
                       requested_stop_bit,
                       config_to_app) == 0)
                {
                    return 0;
                }
            }
        }
    }

    CE32_HJ185_SetConfigPath(0U);
    CE32_HJ185_SelectAppPath();
    (void)CE32_HJ185_ReconfigureHostUart(handle, requested_baud, requested_parity, requested_stop_bit);
    handle->baud = requested_baud;
    handle->parity = requested_parity;
    handle->stop_bit = requested_stop_bit;
    return -1;
}

void CE32_UART_Init_unconfigState(UART_HandleTypeDef *huart)
{
    (void)huart;
}

void CE32_UART_Init_configedState(UART_HandleTypeDef *huart)
{
    (void)huart;
}

int CE32_HJ_Init_Slave(CE32_HJ580_Handle *handle)
{
    if(handle == NULL)
    {
        return -1;
    }

    handle->state &= (uint16_t)(~HJ580_STATE_MASTER);
    if(CE32_HJ_Setting(
           handle,
           (char *)handle->COMM.CMD_RX.buffer,
           (uint16_t)sizeof(handle->COMM.CMD_RX.buffer),
           (char *)handle->COMM.CMD_TX.buffer,
           (uint16_t)sizeof(handle->COMM.CMD_TX.buffer)) != 0)
    {
        return 1;
    }

    handle->state |= HJ580_STATE_TXON;
    CE32_HJ_Upload_State(handle);
    return 0;
}

int CE32_HJ_Init_Master(CE32_HJ580_Handle *handle)
{
    if(handle == NULL)
    {
        return -1;
    }

    handle->state |= HJ580_STATE_MASTER;
    if(CE32_HJ_Setting(
           handle,
           (char *)handle->COMM.CMD_RX.buffer,
           (uint16_t)sizeof(handle->COMM.CMD_RX.buffer),
           (char *)handle->COMM.CMD_TX.buffer,
           (uint16_t)sizeof(handle->COMM.CMD_TX.buffer)) != 0)
    {
        return 1;
    }

    handle->state |= HJ580_STATE_TXON;
    CE32_HJ_Upload_State(handle);
    return 0;
}

int CE32_HJ_Setting(CE32_HJ580_Handle *handle, char *RX_buf, uint16_t RX_size, char *TX_buf, uint16_t TX_size)
{
    uint32_t desired_baud;
    uint8_t desired_parity;
    uint8_t desired_stop_bit;

    if((handle == NULL) || (handle->COMM.huart == NULL))
    {
        return -1;
    }

    CE32_HJ185_DiagReset();
    CE32_HJ185_DiagCaptureState(handle);
    desired_baud = (handle->baud != 0U) ? handle->baud : HJ185_DEFAULT_BAUD;
    desired_parity = handle->parity;
    desired_stop_bit = (handle->stop_bit != 0U) ? handle->stop_bit : HJ580_STOPBIT_1;

    dataMGR_init(&handle->RX_MGR, RX_buf, RX_size);
    dataMGR_init(&handle->TX_MGR, TX_buf, TX_size);

    /*
     * USB384_NP routes HJ185 P0.01, P0.04, P0.18, TX, and RX. It does not
     * route P0.16 APP-config enable, P0.20/SIMPAIR is tied low, and P0.21
     * reset is tied to the 1V8 rail instead of MCU GPIO. HJ185 still accepts
     * its serial command set directly over UART, so keep the port model close
     * to CE64 and avoid assuming any firmware-controlled pairing/reset path
     * that the board cannot physically drive.
     */
    CE32_HJ185_InitOptionalPins();
    CE32_HJ185_ResetPulse();
    if(ce32_hj185_vendor_boot_name_applied == 0U)
    {
        CE32_HJ185_VendorBootBlindApplyName(handle);
    }
    HJ580_EnterConfigMode(handle);
    CE32_HJ185_DiagSetStage(1U);
    if(CE32_HJ185_TryResetBeforeConfigure(handle) == 0)
    {
        CE32_HJ185_DiagCaptureState(handle);
        CE32_HJ185_DiagCaptureUart(handle);
    }

    CE32_HJ185_DiagSetStage(2U);
    if(CE32_HJ_Init_device(handle) != 0)
    {
        uint32_t probe_baud;
        uint8_t probe_parity;
        uint8_t probe_stop_bit;

        probe_baud = desired_baud;
        probe_parity = desired_parity;
        probe_stop_bit = desired_stop_bit;
        if((xe_np_hj185_diag.probe_best_score >= 2U) &&
           (xe_np_hj185_diag.probe_best_baud != 0U))
        {
            probe_baud = xe_np_hj185_diag.probe_best_baud;
            probe_parity = (uint8_t)xe_np_hj185_diag.probe_best_parity;
            probe_stop_bit = (uint8_t)xe_np_hj185_diag.probe_best_stop_bit;
        }

        handle->state &= (uint16_t)(~(HJ580_STATE_ERROR | HJ580_STATE_WAITRESP | HJ580_STATE_CMD_RESP_PEND));
        CE32_HJ185_DiagSetStage(11U);
        if(CE32_HJ185_ReconfigureHostUart(handle, probe_baud, probe_parity, probe_stop_bit) == 0)
        {
            HAL_Delay(HJ185_UART_RECOVERY_SETTLE_MS);
        }
        CE32_HJ185_RunExtendedUartProbe(handle);
        CE32_HJ185_BlindApplyName(handle);
        CE32_HJ185_SetConfigPath(0U);
        HJ580_ExitConfigMode(handle);
        CE32_HJ580_Start(handle);
        CE32_HJ185_DiagSetStage(12U);
        CE32_HJ185_DiagCaptureState(handle);
        CE32_HJ185_DiagCaptureUart(handle);
        xe_np_hj185_diag.result = 1U;
        return -1;
    }
    CE32_HJ185_DiagSetStage(3U);
    if(CE32_HJ185_NormalizeHostAndModuleUart(handle, desired_baud, desired_parity, desired_stop_bit) != 0)
    {
        xe_np_hj185_diag.result = 2U;
        HJ580_ExitConfigMode(handle);
        return -1;
    }

    CE32_HJ185_DiagSetStage(4U);
    if(CE32_HJ185_QueryVersion(handle) != 0)
    {
        xe_np_hj185_diag.result = 4U;
        HJ580_ExitConfigMode(handle);
        return 1;
    }
    CE32_HJ185_DiagSetStage(5U);
    if(CE32_HJ185_QueryLocalMac(handle) != 0)
    {
        xe_np_hj185_diag.result = 5U;
        HJ580_ExitConfigMode(handle);
        return 1;
    }

    CE32_HJ185_DiagSetStage(6U);
    if((handle->DeviceName[0] != '\0') && (CE32_HJ185_SetName(handle) != 0))
    {
        xe_np_hj185_diag.result = 6U;
        HJ580_ExitConfigMode(handle);
        return 1;
    }

    /*
     * Do not trust previously-saved HJ185 transport mux state. USB384_NP
     * drives P0.01 low for wake/RX enable and expects UART traffic to stay on
     * the BLE transparent path rather than the APP-side mux.
     */
    CE32_HJ185_DiagSetStage(7U);
    if(CE32_HJ185_EnsureWakeupHigh(handle, HJ185_EXPECT_WAKEUP_HIGH) != 0)
    {
        xe_np_hj185_diag.result = 7U;
        HJ580_ExitConfigMode(handle);
        return 1;
    }
    CE32_HJ185_DiagSetStage(8U);
    if(CE32_HJ185_EnsureToApp(handle, HJ185_EXPECT_TO_APP) != 0)
    {
        xe_np_hj185_diag.result = 8U;
        HJ580_ExitConfigMode(handle);
        return 1;
    }
    CE32_HJ185_DiagSetStage(9U);
    if(CE32_HJ185_EnsureAdvOnOff(handle, 1U) != 0)
    {
        xe_np_hj185_diag.result = 9U;
        HJ580_ExitConfigMode(handle);
        return 1;
    }

    CE32_HJ185_DiagSetStage(10U);
    (void)CE32_HJ185_QueryName(handle);
    xe_np_hj185_diag.result = 0U;
    HJ580_ExitConfigMode(handle);
    return 0;
}

void CE32_HJ_RXISR(CE32_HJ580_Handle *handle)
{
    if(handle == NULL)
    {
        return;
    }

    if((handle->state & HJ580_STATE_CONFIG) != 0U)
    {
        (void)CE32_HJ580_RX_CONFIG_ISR(handle);
    }
    else
    {
        (void)CE32_HJ580_RX_ISR(handle);
    }
}

void HJ_UartSend(UART_HandleTypeDef *huart, char *buf)
{
    if((huart == NULL) || (buf == NULL))
    {
        return;
    }

    (void)HAL_UART_Transmit(huart, (uint8_t *)buf, (uint16_t)strlen(buf), HJ185_CMD_TIMEOUT_MS);
}

void HJ_UartSend_LimLen(UART_HandleTypeDef *huart, char *buf, int maxLen)
{
    if((huart == NULL) || (buf == NULL) || (maxLen <= 0))
    {
        return;
    }

    (void)HAL_UART_Transmit(
        huart,
        (uint8_t *)buf,
        (uint16_t)CE32_HJ185_StrnLen(buf, (size_t)maxLen),
        HJ185_CMD_TIMEOUT_MS);
}

void CE32_UART_TRANSMIT_PREV_DMA(uint8_t *data, uint16_t size, int16_t sig1, int32_t sig2, uint16_t *sig3)
{
    (void)data;
    (void)size;
    (void)sig1;
    (void)sig2;
    (void)sig3;
}

void CE32_UART_TRANSMIT_IT(UART_HandleTypeDef *huart, uint8_t *data, uint16_t size, int16_t sig1, int32_t sig2, uint16_t *sig3)
{
    (void)sig1;
    (void)sig2;
    (void)sig3;

    if((huart == NULL) || (data == NULL) || (size == 0U))
    {
        return;
    }

    (void)HAL_UART_Transmit_IT(huart, data, size);
}

void CE32_UART_TRANSMIT_VAR_HEADER_DMA(uint8_t *header, uint16_t sizeHeader, uint8_t *data, uint16_t size)
{
    (void)header;
    (void)sizeHeader;
    (void)data;
    (void)size;
}

int CE32_HJ_TX_EnqueueCmd_DMA(CE32_INTERCOM_Handle *handle, unsigned char *data, int cmd_len)
{
    return CE32_INTERCOM_TX_EnqueueCmd(handle, data, cmd_len);
}

void HJ_BlockTransmit(char *buf, uint32_t size)
{
    if((BLE_handle.COMM.huart == NULL) || (buf == NULL) || (size == 0U))
    {
        return;
    }

    (void)HAL_UART_Transmit(BLE_handle.COMM.huart, (uint8_t *)buf, (uint16_t)size, HJ185_CMD_TIMEOUT_MS);
}

int CE32_HJ_HandShake(CE32_HJ580_Handle *handle)
{
    char reply[64];
    int status;

    memset(reply, 0, sizeof(reply));
    status = CE32_HJ185_SendCommand(handle, "<RD_SOFT_VERSION>", reply, sizeof(reply));
    CE32_HJ185_DiagNoteProbeAttempt(handle, "<RD_SOFT_VERSION>", (status == 0) ? reply : NULL, status);
    if(status != 0)
    {
        return -1;
    }

    return (CE32_HJ185_CommandMatches(reply, "<rd_soft_version=") != 0) ? 0 : -1;
}

int CE32_HJ_READPEERINFO(CE32_HJ580_Handle *handle)
{
    int resp;

    if(handle == NULL)
    {
        return -1;
    }

    HJ580_EnterConfigMode(handle);
    if((handle->state & HJ580_STATE_MASTER) != 0U)
    {
        resp = CE32_HJ185_QueryLink(
            handle,
            "<RD_CENTER_LINK>",
            "<rd_center_link=",
            (uint8_t *)handle->PeerMAC);
    }
    else
    {
        resp = CE32_HJ185_QueryLink(
            handle,
            "<RD_CLIENT_LINK>",
            "<rd_client_link=",
            (uint8_t *)handle->PeerMAC);
    }
    HJ580_ExitConfigMode(handle);
    return resp;
}

int CE32_HJ_READRSSI(CE32_HJ580_Handle *handle)
{
    (void)handle;
    return -1;
}

int CE32_HJ_BondMAC(CE32_HJ580_Handle *handle)
{
    char mac_ascii[13];
    char command[48];
    char reply[64];
    const uint8_t *bond_mac;

    if(handle == NULL)
    {
        return -1;
    }

    bond_mac = (handle->BondMAC[0] != '\0') ? (const uint8_t *)handle->BondMAC :
                                              (const uint8_t *)handle->PeerMAC;
    CE32_HJ185_FormatMacString(bond_mac, mac_ascii, sizeof(mac_ascii));
    if(mac_ascii[0] == '\0')
    {
        return -1;
    }

    snprintf(command, sizeof(command), "<ST_BOND_CLIENT_MAC=%s>", mac_ascii);
    HJ580_EnterConfigMode(handle);
    if(CE32_HJ185_SendCommand(handle, command, reply, sizeof(reply)) != 0)
    {
        HJ580_ExitConfigMode(handle);
        return -1;
    }
    HJ580_ExitConfigMode(handle);

    if((CE32_HJ185_CommandMatches(reply, "<st_bond_client_mac=") != 0) &&
       (strstr(reply, "error") == NULL))
    {
        handle->state |= HJ580_STATE_BONDED;
        return 0;
    }

    return -1;
}

int CE32_HJ_DisbondMAC(CE32_HJ580_Handle *handle)
{
    char reply[64];

    if(handle == NULL)
    {
        return -1;
    }

    HJ580_EnterConfigMode(handle);
    if(CE32_HJ185_SendCommand(handle, "<ST_BOND_CLIENT_MAC=0>", reply, sizeof(reply)) != 0)
    {
        HJ580_ExitConfigMode(handle);
        return -1;
    }
    HJ580_ExitConfigMode(handle);

    if((CE32_HJ185_CommandMatches(reply, "<st_bond_client_mac=ok>") != 0) ||
       (CE32_HJ185_CommandMatches(reply, "<st_bond_client_mac=") != 0))
    {
        handle->state &= (uint16_t)(~HJ580_STATE_BONDED);
        memset(handle->BondMAC, 0, sizeof(handle->BondMAC));
        return 0;
    }

    return -1;
}

int CE32_HJ_SetAdvData(CE32_HJ580_Handle *handle, char *data, uint8_t data_len)
{
    char hex_payload[sizeof(handle->ADVdata) * 2U + 1U];
    char command[128];
    char reply[64];
    uint8_t max_bytes;

    if((handle == NULL) || (data == NULL))
    {
        return -1;
    }

    max_bytes = (uint8_t)(sizeof(handle->ADVdata) / 2U);
    if(data_len > max_bytes)
    {
        return -1;
    }

    for(uint8_t index = 0U; index < data_len; ++index)
    {
        snprintf(&hex_payload[index * 2U], sizeof(hex_payload) - (index * 2U), "%02X", (uint8_t)data[index]);
    }
    hex_payload[data_len * 2U] = '\0';
    snprintf(command, sizeof(command), "<ST_ADV_DATA=%s>", hex_payload);

    HJ580_EnterConfigMode(handle);
    if(CE32_HJ185_SendCommand(handle, command, reply, sizeof(reply)) != 0)
    {
        HJ580_ExitConfigMode(handle);
        return -1;
    }
    HJ580_ExitConfigMode(handle);

    if(CE32_HJ185_CommandMatches(reply, "<st_adv_data=ok>") != 0)
    {
        memset(handle->ADVdata, 0, sizeof(handle->ADVdata));
        memcpy(handle->ADVdata, data, data_len);
        return 0;
    }

    return -1;
}

void CE32_HJ_Upload_State(CE32_HJ580_Handle *handle)
{
    if(handle == NULL)
    {
        return;
    }

    CE32_HJ185_RefreshConnectedState(handle);
    handle->DEV.state = 0U;
    if((handle->state & HJ580_STATE_CONNECTED) != 0U)
    {
        handle->DEV.state |= CE32_STATE_CONNECTED;
    }
}

void CE32_HJ185_DiagNoteStreamRxIrq(void)
{
    xe_np_hj185_diag.stream_rx_irq_count++;
}

void CE32_HJ185_DiagNoteStreamRawByte(uint8_t data)
{
    uint32_t data_len = xe_np_hj185_diag.stream_raw_last_len;

    xe_np_hj185_diag.stream_raw_byte_count++;
    xe_np_hj185_diag.stream_raw_last_byte = (uint32_t)data;

    if(data_len < sizeof(xe_np_hj185_diag.stream_raw_last_data))
    {
        xe_np_hj185_diag.stream_raw_last_data[data_len] = data;
        xe_np_hj185_diag.stream_raw_last_len = data_len + 1U;
        return;
    }

    memmove(
        (void *)&xe_np_hj185_diag.stream_raw_last_data[0],
        (const void *)&xe_np_hj185_diag.stream_raw_last_data[1],
        sizeof(xe_np_hj185_diag.stream_raw_last_data) - 1U);
    xe_np_hj185_diag.stream_raw_last_data[sizeof(xe_np_hj185_diag.stream_raw_last_data) - 1U] = data;
}

void CE32_HJ185_DiagNoteStreamCmdRx(const uint8_t *data, uint32_t data_len)
{
    xe_np_hj185_diag.stream_cmd_rx_count++;
    xe_np_hj185_diag.stream_last_rx_len = data_len;
    xe_np_hj185_diag.stream_last_rx_cmd =
        ((data != NULL) && (data_len != 0U)) ? (uint32_t)data[0] : 0U;
    CE32_HJ185_DiagCopyBytes(
        (uint8_t *)xe_np_hj185_diag.stream_last_rx_data,
        sizeof(xe_np_hj185_diag.stream_last_rx_data),
        data,
        data_len);
}

void CE32_HJ185_DiagNoteStreamCmdTxLaunch(const uint8_t *data, uint32_t data_len)
{
    xe_np_hj185_diag.stream_cmd_tx_launch_count++;
    xe_np_hj185_diag.stream_last_tx_launch_len = data_len;
    xe_np_hj185_diag.stream_last_tx_launch_cmd =
        ((data != NULL) && (data_len != 0U)) ? (uint32_t)data[0] : 0U;
    CE32_HJ185_DiagCopyBytes(
        (uint8_t *)xe_np_hj185_diag.stream_last_tx_launch_data,
        sizeof(xe_np_hj185_diag.stream_last_tx_launch_data),
        data,
        data_len);
}

void CE32_INTERCOM_TX_Launch_Act(CE32_INTERCOM_Handle *handle_IC, const uint8_t *data, uint32_t data_len)
{
    if(handle_IC == (CE32_INTERCOM_Handle *)&BLE_handle)
    {
        CE32_HJ185_DiagNoteStreamCmdTxLaunch(data, data_len);
    }
}

void CE32_INTERCOM_RX_Byte_Act(CE32_INTERCOM_Handle *handle_IC, uint8_t data)
{
    if(handle_IC == (CE32_INTERCOM_Handle *)&BLE_handle)
    {
        CE32_HJ185_DiagNoteStreamRawByte(data);
    }
}

void CE32_INTERCOM_RX_FrameComplete_Act(
    CE32_INTERCOM_Handle *handle_IC,
    const uint8_t *data,
    uint32_t data_len)
{
    uint8_t reply[1];

    if(handle_IC != (CE32_INTERCOM_Handle *)&BLE_handle)
    {
        return;
    }

    CE32_HJ185_DiagNoteStreamCmdRx(data, data_len);
    if((data == NULL) || (data_len != 1U))
    {
        return;
    }

    if((data[0] != 0x45U) && (data[0] != 0x80U))
    {
        return;
    }

    reply[0] = data[0];
    (void)CE32_INTERCOM_TX_EnqueueCmd(handle_IC, reply, sizeof(reply));
}

int CE32_HJ580_RX_CONFIG_ISR(CE32_HJ580_Handle *handle_BLE)
{
    CE32_command_cfg *handle;

    if((handle_BLE == NULL) || (handle_BLE->COMM.UART == NULL))
    {
        return -1;
    }

    handle = &handle_BLE->Config_CMD_RX;
    CE32_HJ185_ClearUartErrors(handle_BLE->COMM.huart);

    while(INTERCOM_CHECK_RXNE(&handle_BLE->COMM))
    {
        uint8_t data_temp = CE32_UART_RX_READ(handle_BLE->COMM.UART);

        xe_np_hj185_diag.rx_byte_count++;
        xe_np_hj185_diag.last_rx_byte = data_temp;

        if(handle->stream_in.logging == 0U)
        {
            if(data_temp != '<')
            {
                continue;
            }
            if(CE32_HJ580_COMMAND_Enqueue_Allocate(handle, HJ_CFG_CMD_MAXSIZE, (uint8_t **)&handle->stream_in.addr) != 0)
            {
                continue;
            }
            handle->stream_in.logging = 1U;
            handle->stream_in.len = HJ_CFG_CMD_MAXSIZE;
            handle->stream_in.idx = 0U;
        }

        if(CE32_HJ580_COMMAND_Enqueue_Byte(handle, data_temp) != 0)
        {
            CE32_HJ580_COMMAND_Enqueue_Byte_Abort(handle);
            continue;
        }

        if(data_temp == '>')
        {
            uint8_t passive_frame[HJ_CFG_CMD_MAXSIZE];
            uint8_t *passive_ptr = NULL;
            uint32_t passive_len = 0U;

            handle->stream_in.len = handle->stream_in.idx;
            if(CE32_HJ580_COMMAND_EnqueueCmd_buffered(handle) == 0)
            {
                xe_np_hj185_diag.rx_frame_count++;
                if((handle_BLE->state & HJ580_STATE_WAITRESP) != 0U)
                {
                    handle_BLE->state |= HJ580_STATE_CMD_RESP_PEND;
                }
                else if(CE32_HJ580_COMMAND_DequeueCmd(handle, &passive_ptr, &passive_len) == 0)
                {
                    if(passive_len >= sizeof(passive_frame))
                    {
                        passive_len = sizeof(passive_frame) - 1U;
                    }
                    memcpy(passive_frame, (const void *)passive_ptr, passive_len);
                    passive_frame[passive_len] = '\0';
                    CE32_HJ185_DiagCapturePassiveFrame((const char *)passive_frame, passive_len);
                }
            }
            CE32_HJ580_COMMAND_Enqueue_Byte_Abort(handle);
        }
    }

    return 0;
}

int CE32_HJ580_RX_ISR(CE32_HJ580_Handle *handle_BLE)
{
    return CE32_INTERCOM_RX_ISR((CE32_INTERCOM_Handle *)handle_BLE);
}

int CE32_HJ580_RX_ISR_SWI(CE32_HJ580_Handle *handle)
{
    return CE32_INTERCOM_RX_ISR_SWI((CE32_INTERCOM_Handle *)handle);
}

int CE32_HJ580_RX_ProcBuffer(CE32_HJ580_Handle *handle)
{
    return CE32_INTERCOM_RX_ProcBuffer((CE32_INTERCOM_Handle *)handle);
}

int CE32_HJ580_RX_PREV_ISR(CE32_HJ580_Handle *handle_BLE)
{
    return CE32_INTERCOM_RX_ISR((CE32_INTERCOM_Handle *)handle_BLE);
}

int CE32_HJ580_TX_CONFIG_ISR(CE32_HJ580_Handle *handleBLE)
{
    uint8_t data;

    if((handleBLE == NULL) || (handleBLE->COMM.UART == NULL))
    {
        return -1;
    }

    while(INTERCOM_CHECK_TXE(&handleBLE->COMM))
    {
        if(CE32_HJ580_COMMAND_Dequeue_Byte(&handleBLE->Config_CMD_TX, &data) != 0)
        {
            INTERCOM_UART_TXEIE_DISABLE(&handleBLE->COMM);
            return 0;
        }
        INTERCOM_TX_SEND(&handleBLE->COMM, data);
        xe_np_hj185_diag.tx_byte_count++;
    }

    return 0;
}

void HJ580_EnterConfigMode(CE32_HJ580_Handle *handle)
{
    if(handle == NULL)
    {
        return;
    }

    CE32_HJ185_SelectUartRxEnabled();
    CE32_HJ185_SelectAppPath();
    (void)CE32_INTERCOM_TX_Stop_All((CE32_INTERCOM_Handle *)handle);
    CE32_HJ185_FlushUartRx(handle->COMM.huart);
    handle->state |= HJ580_STATE_CONFIG;
    HAL_Delay(HJ185_CONFIG_SETTLE_MS);
}

void HJ580_ExitConfigMode(CE32_HJ580_Handle *handle)
{
    if(handle == NULL)
    {
        return;
    }

    handle->state &= (uint16_t)(~(HJ580_STATE_CONFIG | HJ580_STATE_WAITRESP | HJ580_STATE_CMD_RESP_PEND));
    CE32_HJ185_SelectBleDataPath();
    CE32_INTERCOM_UART_TX_DMA_Init((CE32_INTERCOM_Handle *)handle);
}

void CE32_HJ580_TX_Start(CE32_HJ580_Handle *handle)
{
    if((handle == NULL) || (handle->COMM.UART == NULL))
    {
        return;
    }

    handle->COMM.UART->CR1 |= USART_CR1_TXEIE_TXFNFIE;
    (void)CE32_HJ580_TX_CONFIG_ISR(handle);
}

void CE32_HJ580_TX_Start_DMA(CE32_HJ580_Handle *handle)
{
    if(handle == NULL)
    {
        return;
    }

    (void)CE32_INTERCOM_TX_Start_DMA((CE32_INTERCOM_Handle *)handle);
}

int CE32_HJ580_TX_Stop_DMA(CE32_HJ580_Handle *handle)
{
    if(handle == NULL)
    {
        return -1;
    }

    return CE32_INTERCOM_TX_Stop_DMA((CE32_INTERCOM_Handle *)handle);
}

void CE32_HJ580_Start(CE32_HJ580_Handle *handle)
{
    if((handle == NULL) || (handle->COMM.UART == NULL))
    {
        return;
    }

    if(xe_np_hj185_diag.magic != XE_NP_HJ185_DIAG_MAGIC)
    {
        CE32_HJ185_DiagReset();
    }
    CE32_HJ185_DiagCaptureState(handle);
    CE32_HJ185_DiagCaptureUart(handle);

    CE32_HJ185_SelectUartRxEnabled();
    CE32_HJ185_SelectBleDataPath();
    CE32_INTERCOM_UART_TX_DMA_Init((CE32_INTERCOM_Handle *)handle);
    INTERCOM_UART_ENABLE((CE32_INTERCOM_Handle *)handle);
    INTERCOM_UART_RXIT_ENABLE((CE32_INTERCOM_Handle *)handle);
}

void CE32_HJ580_RX_dataCached_Act(CE32_HJ580_Handle *handle_IC)
{
    (void)handle_IC;
}

__weak void CE32_HJ_CMD_RECEIVED_ACT(CE32_HJ580_Handle *handle)
{
    (void)handle;
}
