#ifndef XE_NP_NP2_FIRST_WORD_H
#define XE_NP_NP2_FIRST_WORD_H
#include <stdint.h>
/* Startup only. RM0456 42.5.1: disabling PSSI flushes FIFO. CBR1 BNDT
 * decreases on source transfers (17.8); CDAR advances at destination.
 * A fresh first-node decrease+advance bounds first accepted PDCK without a
 * FIFO latency guess or a foreground-discovery timestamp. */
static inline int np2_first_word_initial(uint32_t base,uint32_t bytes,
                                        uint32_t address,uint32_t remaining)
{
    return base && bytes>=4096U && bytes<=65532U && !(base&3U) && !(bytes&3U) &&
        base<=UINT32_MAX-bytes && address==base && remaining==bytes;
}
static inline int np2_first_word_seen(uint32_t base,uint32_t bytes,uint32_t link,
    uint32_t address,uint32_t remaining,uint32_t observed_link,uint32_t faults)
{
    return !faults && link==observed_link && remaining && remaining<bytes &&
        address>base && address<base+bytes && !(address&3U);
}
#endif
