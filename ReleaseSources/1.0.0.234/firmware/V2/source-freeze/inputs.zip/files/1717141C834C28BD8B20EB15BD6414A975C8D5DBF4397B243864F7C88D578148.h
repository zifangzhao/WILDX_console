#ifndef XE_NP_SENSORS_PORT_H
#define XE_NP_SENSORS_PORT_H
#include "stm32u5xx_hal.h"
#include "xe_np_sensors.h"
#ifndef XE_NP_NP2_FIRST_SYNC_ENABLE
#define XE_NP_NP2_FIRST_SYNC_ENABLE 0U
#endif
#if XE_NP_NP2_FIRST_SYNC_ENABLE
#include "xe_np_np2_first_sync_gate.h"
#else
typedef struct XE_NP_Np2FirstSyncGate XE_NP_Np2FirstSyncGate;
#endif
#ifndef XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE
#define XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE 0U
#endif
void XE_NP_SensorsPort_Init(I2C_HandleTypeDef *imu,I2C_HandleTypeDef *environment);
void XE_NP_SensorsPort_Service(uint8_t recording_active);
/* Stopped profile changes/diagnostics only; no waits in the clock boundary. */
void XE_NP_SensorsPort_Pause(void);
void XE_NP_SensorsPort_Resume(void);
int XE_NP_SensorsPort_Complete(I2C_HandleTypeDef *,uint32_t error);
const XE_NP_SensorSnapshot *XE_NP_SensorsPort_GetSnapshot(void);
/* Archival-only first-sync filter. Normal live snapshots stay unmodified. */
void XE_NP_SensorsPort_FirstSyncWait(void);
int XE_NP_SensorsPort_FirstSyncRelease(XE_NP_Np2FirstSyncGate *gate);
void XE_NP_SensorsPort_FirstSyncLegacy(void);
/* Copies the current archival view: zero while waiting, otherwise one filtered
 * or legacy snapshot. The caller owns the 140-byte destination. */
int XE_NP_SensorsPort_CopyArchive(XE_NP_SensorSnapshot *out);
/* Optional 116-byte SNS2 view. Bytes0..111 are the SNS1 prefix retagged
 * SNS2/v2; bytes112..115 are its IEEE CRC32. I/O/timeouts/missed are N/A. */
const uint8_t *XE_NP_SensorsPort_GetSdPacket(uint32_t *publication_id);
/* SWD-visible copy: atomic index into two foreground-published buffers. */
extern XE_NP_SensorSnapshot xe_np_sensor_snapshot[2];
extern volatile uint32_t xe_np_sensor_snapshot_index;
#endif
