"""Bounded read-only provenance/source freeze for checked V2 APP680 and USB1D.

No build, preprocessor, hardware, canonical edits or firmware payload copying.
"""
import collections
import hashlib
import json
from pathlib import Path
import re
import shutil

BASE = Path('C:/Frank/Code/XE_NP/_artifacts/v2_sd_recording_fix_20261104')
OLD = Path('C:/Frank/Code/XE_NP/_artifacts/closed_loop_qualification_20261104/V2')
ROOT = Path('D:/Code/XE_NP_V2')
HERE = Path(__file__).resolve().parent
EXT = {'.c','.h','.inc','.s','.asm','.sct','.ld','.cpp','.hpp'}
RECEIPTS = [BASE/'build-app-metadata/receipt.json', BASE/'build-app/receipt.json',
 Path('C:/Frank/Code/USB_PCconsole/_artifacts/closed_loop_20261102/V2/build-app/receipt.json'),
 OLD/'build-usb/receipt.json']

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def normalize(path):
    return str(Path(str(path))).replace('\\','/').lower()

def text_path(value):
    return isinstance(value,str) and len(value)>3 and Path(value).suffix.lower() in EXT

def main():
    store=HERE/'files';store.mkdir(exist_ok=True)
    records={};pins=[];deps=[];objects=[];commands=[];include_dirs=set();evidence=[]
    receipts={};unresolved=[];dependency_files=[]
    def keep(path, category, expected=None, logical=None):
        path=Path(path)
        if not path.is_file(): return None
        size=path.stat().st_size
        if size>12*1024*1024: raise ValueError('Oversize source/evidence: '+str(path))
        actual=digest(path);key=actual+path.suffix.lower()
        dest=store/key
        if not dest.exists():shutil.copyfile(path,dest)
        entry=records.setdefault(key,{'sha256':actual,'bytes':size,'stored':str(dest.relative_to(HERE)),
                                     'origins':[],'claims':[]})
        if str(path) not in entry['origins']:entry['origins'].append(str(path))
        claim={'category':category}
        if expected:claim['expected_sha256']=expected;claim['matches_expected']=actual==expected
        if logical:claim['logical_path']=str(logical)
        if claim not in entry['claims']:entry['claims'].append(claim)
        return key
    def inspect_json(path):
        path=Path(path)
        if normalize(path) in receipts or not path.is_file() or path.stat().st_size>8*1024*1024:return
        try:data=json.loads(path.read_text(encoding='utf-8-sig'))
        except (ValueError,UnicodeError):return
        receipts[normalize(path)]=data;keep(path,'build-receipt');evidence.append(str(path))
        def visit(value,trail=''):
            if isinstance(value,dict):
                if isinstance(value.get('command'),list) and re.fullmatch('[0-9a-fA-F]{64}',str(value.get('source_sha256',''))):
                    sources=[a for a in value['command'] if text_path(a) and Path(a).suffix.lower() in {'.c','.s','.cpp'}]
                    if len(sources)==1:pins.append({'path':str(Path(sources[0])),
                        'sha256':value['source_sha256'].upper(),'receipt':str(path),'field':trail+'/source_sha256'})
                for k,v in value.items():
                    if text_path(k) and isinstance(v,str) and re.fullmatch('[0-9a-fA-F]{64}',v):
                        pins.append({'path':str(Path(k)),'sha256':v.upper(),'receipt':str(path),'field':trail+'/'+k})
                    visit(v,trail+'/'+k)
            elif isinstance(value,list):
                if value and all(isinstance(x,str) for x in value) and any(x.endswith(('.c','.s','.cpp')) for x in value):
                    commands.append({'receipt':str(path),'field':trail,'command':value})
                    for i,a in enumerate(value):
                        if a in ('-I','-iquote','-isystem') and i+1<len(value):include_dirs.add(str(Path(value[i+1])))
                        elif a.startswith('-I') and len(a)>2:include_dirs.add(str(Path(a[2:])))
                        if text_path(a):deps.append((Path(a),'compiler-input:'+str(path)))
                for i,v in enumerate(value):visit(v,trail+'/'+str(i))
        visit(data)
    for r in RECEIPTS:inspect_json(r)
    app=json.loads(RECEIPTS[0].read_text());usb=json.loads(RECEIPTS[3].read_text())
    for family,r in [('APP680A1685',app),('USB1D86BC8B',usb)]:
        for p,h in r['retained_objects'].items():objects.append({'family':family,'path':p,'sha256':h})
        cs=r.get('compiler_commands',{})
        if not cs:cs={k:v['command'] for k,v in r.get('compile',{}).items()}
        for k,c in cs.items():
            if '-o' in c:
                expected=r.get('compile',{}).get(k,{}).get('object_sha256')
                objects.append({'family':family,'path':c[c.index('-o')+1],
                    'sha256':expected or digest(Path(c[c.index('-o')+1])),
                    'rebuilt':True,'recorded_object_hash_available':bool(expected)})
    directories={Path(o['path']).parent for o in objects}
    # Read only provenance files adjacent to these exact effective objects.
    names={'receipt.json','incremental-build.json','build-inputs.json','build_receipt.json',
           'build-profile.json','build.json','plan.json','input-manifest.json'}
    for directory in sorted(directories,key=str):
        for name in names:inspect_json(directory/name)
        for name in ('receipt.json','incremental-build.json','build-inputs.json'):
            inspect_json(directory.parent/name)
    # Exact adjacent .d is preferred; alternative same-stem .dep also retained.
    for obj in objects:
        p=Path(obj['path']);obj['object_matches_receipt']=p.is_file() and digest(p)==obj['sha256']
        d=p.with_suffix('.d')
        if not d.is_file():
            obj['dependency_file']=None;continue
        obj['dependency_file']=str(d);keep(d,'dependency-file');dependency_files.append(str(d))
        body=d.read_text(errors='replace').replace('\\\n',' ')
        # ARM .d emits one path per continuation; spaces can be make-escaped.
        body=re.sub(r'^.*?\.o:\s*','',body,count=1,flags=re.S)
        for line in body.splitlines():
            for item in re.findall(r'(?:[A-Za-z]:[\\/]|\.\.?[\\/])(?:\\ |[^\s])+',line):
                item=item.replace('\\ ',' ')
                dep=Path(item)
                if not dep.is_absolute():
                    roots=[ROOT/'MDK-ARM',p.parent,ROOT]
                    dep=next((x/dep for x in roots if (x/dep).is_file()),p.parent/dep)
                if dep.suffix.lower() in EXT:deps.append((dep,'dependency:'+str(d)))
    # Explicit bounded source/header allowlist fills sources absent from old .d.
    allow=[ROOT/'Core/Inc',ROOT/'Core/Src',ROOT/'Shared/Timing',
           ROOT/'Drivers/STM32U5xx_HAL_Driver/Inc',ROOT/'Drivers/STM32U5xx_HAL_Driver/Src',
           ROOT/'Drivers/CMSIS/Include',ROOT/'Drivers/CMSIS/Device/ST/STM32U5xx/Include',
           ROOT/'Middlewares/Bosch/BME280_SensorAPI',ROOT/'Middlewares/Bosch/BMM150_SensorAPI',
           Path('D:/Code/WILDX_console/WILDX_console/Neuropixels/ClosedLoop'),
           Path('C:/Frank/Code/XE_NP/Firmware/V1/Core/Inc'),
           BASE/'integration/checked/Core/Inc',BASE/'integration/Core/Src',
           BASE/'integration/canonical-source/preimages/Core/Inc',BASE/'integration/canonical-source/preimages/Core/Src',
           BASE/'Core/Src',BASE/'metadata-fix/Core/Src',OLD/'Core/Inc',OLD/'Core/Src']
    allow+=sorted((Path(x) for x in include_dirs if Path(x).is_dir()),key=str)
    candidates=collections.defaultdict(list)
    for directory in dict.fromkeys(allow):
        if not directory.is_dir():continue
        for p in directory.iterdir():
            if p.is_file() and p.suffix.lower() in EXT:candidates[p.name.lower()].append(p)
    for p,_ in deps:candidates[p.name.lower()].append(p)
    for pin in pins:candidates[Path(pin['path']).name.lower()].append(Path(pin['path']))
    pinned_paths=collections.defaultdict(set)
    for pin in pins:
        p=Path(pin['path']);expected=pin['sha256'];pinned_paths[normalize(p)].add(expected)
        found=None
        for q in dict.fromkeys([p,*candidates[p.name.lower()]]):
            if q.is_file() and digest(q)==expected:found=q;break
        if found:
            pin['stored']=keep(found,'receipt-pinned-exact',expected,p)
            pin['resolved_from']=str(found);pin['status']='exact-match'
        else:
            pin['status']='unresolved-preimage';unresolved.append(pin.copy())
            if p.is_file():keep(p,'current-differs-from-checked-preimage',expected,p)
    # Dependency-only files are useful, but not labeled checked original bytes.
    for p,origin in deps:
        if not p.is_file():
            unresolved.append({'path':str(p),'status':'missing-dependency','origin':origin});continue
        if not pinned_paths.get(normalize(p)):keep(p,'dependency-snapshot-no-recorded-preimage',logical=p)
    # Source lookups for inherited objects without .d stay explicitly unproven.
    for obj in objects:
        if obj.get('dependency_file'):continue
        stem=Path(obj['path']).stem.lower()
        hits=candidates.get(stem+'.c',[])+candidates.get(stem+'.s',[])
        obj['source_lookup_snapshots']=[]
        for p in dict.fromkeys(hits):
            if p.is_file():obj['source_lookup_snapshots'].append(keep(p,'same-stem-source-snapshot-not-proven',logical=p))
        obj['source_closure_status']='no-adjacent-dependency-file; inherited object source closure not proven'
    total=sum(x['bytes'] for x in records.values())
    if total>50*1024*1024:raise ValueError('Source freeze exceeded50MiB')
    target_receipts={normalize(RECEIPTS[0]),normalize(RECEIPTS[1]),normalize(RECEIPTS[3])}
    target_pins=[p for p in pins if normalize(p['receipt']) in target_receipts]
    result={'images':{'APP':'680A1685','USB':'1D86BC8B'},'files':list(records.values()),
       'pins':pins,'objects':objects,'compiler_commands':commands,'receipt_paths':evidence,
       'dependency_files':sorted(set(dependency_files)),'unresolved':unresolved,
       'bytes':total,'counts':{'files':len(records),'pins':len(pins),
         'exact_pins':sum(p['status']=='exact-match' for p in pins),
         'unresolved_pins':sum(p['status']!='exact-match' for p in pins),
         'current_component_pins':len(target_pins),
         'current_component_pins_exact':sum(p['status']=='exact-match' for p in target_pins),
         'objects':len(objects),'objects_with_adjacent_d':sum(bool(o.get('dependency_file')) for o in objects)},
       'limits':['Inherited object hashes do not prove source/header equivalence.',
         'Dependency-only snapshots have no recorded original hash and are not relabeled as checked bytes.',
         'No firmware archives, neural captures, toolchain binaries, builds or device access included.',
         'No full source rebuild or equivalence claim is made; unresolved preimages are listed.']}
    (HERE/'manifest.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'bytes':total,'counts':result['counts'],'manifest_sha256':digest(HERE/'manifest.json')},indent=2))

if __name__=='__main__':main()
