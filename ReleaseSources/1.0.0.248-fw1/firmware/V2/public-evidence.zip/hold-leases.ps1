$ErrorActionPreference='Stop'
$taskDir=Join-Path $PSScriptRoot 'owner';New-Item -ItemType Directory -Force $taskDir|Out-Null
if(Test-Path (Join-Path $taskDir 'release.flag')){throw 'Fresh lease workspace required'}
$taskGlobal=[Threading.Mutex]::new($false,'Local\WILDX_NP_TIMING_HIL')
$taskUid=[Threading.Mutex]::new($false,'Local\WILDX_NP_TIMING_HIL_001A0004434250062039314E')
$taskG=$false;$taskU=$false
$taskLease=@{status='waiting';global_status='waiting';scope='GLOBAL+UID';uid='001A0004434250062039314E';pid=$PID;task='v2_power_efficiency_20261106/V2';started_utc=[DateTime]::UtcNow.ToString('o')}
function Save-Lease {$taskLease|ConvertTo-Json|Set-Content (Join-Path $taskDir 'lease.json') -Encoding utf8}
try {
 Save-Lease;Write-Output 'Waiting for actual GLOBAL release; no hardware access'
 $taskDeadline=[DateTime]::UtcNow.AddMinutes(10)
 while(!$taskG -and [DateTime]::UtcNow -lt $taskDeadline){
  try{$taskG=$taskGlobal.WaitOne(250)}catch [Threading.AbandonedMutexException]{$taskG=$true;$taskLease.abandoned_global=$true}
 }
 if(!$taskG){throw 'GLOBAL remains held; no hardware operation authorized'}
 try{$taskU=$taskUid.WaitOne(0)}catch [Threading.AbandonedMutexException]{$taskU=$true;$taskLease.abandoned_uid=$true}
 if(!$taskU){throw 'Exact V2 UID owner busy; no hardware operation authorized'}
 $taskLease.status='active';$taskLease.global_status='held';$taskLease.acquired_utc=[DateTime]::UtcNow.ToString('o');Save-Lease
 Write-Output ('GLOBAL + exact V2 UID acquired PID='+$PID)
 while(!(Test-Path (Join-Path $taskDir 'release.flag'))){Start-Sleep -Milliseconds 250}
}finally{
 if($taskU){$taskUid.ReleaseMutex()};if($taskG){$taskGlobal.ReleaseMutex()}
 $taskLease.status='closed';$taskLease.global_status='released';$taskLease.closed_utc=[DateTime]::UtcNow.ToString('o');Save-Lease
 $taskUid.Dispose();$taskGlobal.Dispose();Write-Output 'V2 hardware leases released'
}
