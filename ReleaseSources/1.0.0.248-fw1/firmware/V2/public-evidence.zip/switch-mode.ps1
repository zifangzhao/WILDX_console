param([Parameter(Mandatory=$true)][ValidateSet('Download','Stream','Sd')][string]$Mode,[Parameter(Mandatory=$true)][string]$ReceiptName)
$ErrorActionPreference='Stop'
$lease=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'owner/lease.json') -Raw | ConvertFrom-Json
if($lease.status -ne 'active' -or $lease.global_status -ne 'held' -or $lease.uid -ne '001A0004434250062039314E'){throw 'Exclusive V2 lease required'}
if($ReceiptName -notmatch '^[a-zA-Z0-9_-]+$'){throw 'Simple receipt name required'}
$receipt=Join-Path $PSScriptRoot "preflight/$ReceiptName.json";if(Test-Path -LiteralPath $receipt){throw 'Fresh transition receipt required'}
$exe='C:/Frank/Code/USB_PCconsole/_artifacts/sd_usb_test_host/enabled248-bleready/WILDX_console.exe'
if((Get-FileHash -LiteralPath $exe).Hash -ne '364BE7FF77B45C4B959FB72FE9CB657E8F04CEDBCF4C21E3F8F2AC22890DAF30'){throw 'Host pin mismatch'}
$a=[Reflection.Assembly]::LoadFrom($exe);$f=[Reflection.BindingFlags]'Public,NonPublic,Static,Instance';$t=$a.GetType('USB512_interface.NpV2UsbDevice',$true)
$path='\\?\usb#vid_1209&pid_b386#001a0004434250062039314e#{8f5a4a7b-0aa6-4f8e-a14f-a2f7b3c6aa4e}'
function V($o,$n){return $o.GetType().GetField($n,$f).GetValue($o)}
$events=[Collections.Generic.List[object]]::new()
function Save{$events.ToArray() | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $receipt}
function ToMode([string]$name,[int]$code){
 $d=$t.GetMethod('Open',$f).Invoke($null,@($path))
 try{
  $s=$t.GetMethod('GetServiceStatus',$f).Invoke($d,@())
  if((V $s 'Busy') -ne 0 -or (V $s 'Target') -ne 0){throw 'Device busy; no mode command'}
  if((V $s 'Mode') -eq $code){return}
  $events.Add([ordered]@{utc=[DateTime]::UtcNow.ToString('o');uid=$lease.uid;from_mode=(V $s 'Mode');to_mode=$code;attempted=$true;confirmed=$false});Save
  $t.GetMethod('Request'+$name+'Mode',$f).Invoke($d,@()) | Out-Null
 }finally{$d.Dispose()}
 if($code -eq 1){return}
 $watch=[Diagnostics.Stopwatch]::StartNew()
 do{Start-Sleep -Milliseconds 300;try{
  $d=$t.GetMethod('Open',$f).Invoke($null,@($path));try{$s=$t.GetMethod('GetServiceStatus',$f).Invoke($d,@());if((V $s 'Mode') -eq $code -and (V $s 'Busy') -eq 0 -and (V $s 'Target') -eq 0){$events[$events.Count-1].confirmed=$true;Save;return}}finally{$d.Dispose()}
 }catch{}}while($watch.Elapsed.TotalSeconds -lt 30)
 throw 'Mode return unconfirmed; command not replayed'
}
if($Mode -eq 'Download'){ToMode 'Download' 3}elseif($Mode -eq 'Stream'){ToMode 'Stream' 2}else{ToMode 'Stream' 2;ToMode 'Sd' 1}
"Normal production $Mode request complete; SD APP needs separate BLE UID/status verification."
