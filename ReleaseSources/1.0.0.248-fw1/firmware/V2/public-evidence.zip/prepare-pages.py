"""Reversible APP candidate/unchanged USB80 pages from fresh exact restore backup."""
from pathlib import Path
import json,hashlib,struct,zlib
T=Path(__file__).resolve().parent;O=T/'deployment';O.mkdir(exist_ok=False)
F=Path(r'C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105');U=F/'build-usb-r3'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest().upper()
old=(T/'original/full.bin').read_bytes();back=load(T/'original/receipt.json');assert len(old)==0x400000 and sha(old)==back['full_sha256']
assert (T/'original/uid.bin').read_bytes().hex()=='04001a00065042434e313920'
new=bytearray(old);pages=[];components={}
for role,d,base,sealbase,original in [('app',F/'build-app',0x20000,0x1e000,'7F238587'),('usb',U,0x180000,0x17e000,'74FC7104')]:
 r=load(d/'receipt.json');body=(d/'application.bin').read_bytes();seal=(d/'application.manifest.bin').read_bytes()
 assert sha(body)==r['body_sha256'] and f'{zlib.crc32(body):08X}'==r['crc32']
 assert len(seal)==128 and zlib.crc32(seal[:124])==struct.unpack_from('<I',seal,124)[0] and struct.unpack_from('<I',seal,32)[0]==zlib.crc32(body)
 os=old[sealbase:sealbase+128];n=struct.unpack_from('<I',os,28)[0];crc=struct.unpack_from('<I',os,32)[0]
 assert zlib.crc32(os[:124])==struct.unpack_from('<I',os,124)[0] and zlib.crc32(old[base:base+n])==crc and f'{crc:08X}'==original
 components[role]=dict(original_crc32=original,candidate_crc32=r['crc32'],body_sha256=sha(body),manifest_sha256=sha(seal))
 for name,start,end,payload in [(role+'-body',base,(base+len(body)+8191)//8192*8192,body),(role+'-manifest',sealbase,sealbase+8192,seal)]:
  b=bytearray(old[start:end]);b[:len(payload)]=payload;new[start:end]=b
  (O/(name+'-new.bin')).write_bytes(b);(O/(name+'-old.bin')).write_bytes(old[start:end])
  pages.append(dict(name=name,address=0x08000000+start,bytes=end-start,new_sha256=sha(b),old_sha256=sha(old[start:end])))
(O/'expected-full.bin').write_bytes(new)
receipt=dict(uid=back['uid'],original_full_sha256=sha(old),candidate_full_sha256=sha(new),install_preimage_sha256=sha(old),options_sha256=back['options_sha256'],components=components,pages=pages,status='PAGE_IMAGES_PREPARED_NO_FLASH')
(O/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
