from pathlib import Path
import sys,json,hashlib,zipfile,importlib.util,struct,zlib
N=Path(r'C:/Frank/Code/XE_NP/_artifacts/v2_power_efficiency_20261106');R=Path(r'D:/Code/XE_NP_V2');O=N/'release';O.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper();load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert load(N/'owner/lease.json')['status']=='closed';assert load(N/'candidate-quality.json')['status']=='PASS_FULL_PRODUCTION_EXPORT_WITH_TIMING_LIMITS';assert load(N/'native-check.json')['exit_code']==0
sys.path.insert(0,str(R/'Tools'));import package_xe_np_firmware as pkg;pkg.LOADER_ABI_VERSION=4
sp=importlib.util.spec_from_file_location('direct_merge',r'C:/Frank/Code/XE_NP/Tools/V1Capture/UnifiedUsb/merge_verified_hex.py');merge=importlib.util.module_from_spec(sp);sp.loader.exec_module(merge)
roles={};mem={}
for role,crc in [('app','C88F3B27'),('usb','E581FE41')]:
 b=N/('build-'+role);r=load(b/'receipt.json');body=(b/'application.bin').read_bytes();manifest=(b/'application.manifest.bin').read_bytes();assert f'{zlib.crc32(body):08X}'==r['crc32']==crc and sha(b/'application.bin')==r['body_sha256'];m=pkg.sealed_slot_memory(body,manifest);hexfile=b/('V2_'+role.upper()+crc+'.hex');assert pkg.read_intel_hex(hexfile)==m
 target=O/hexfile.name;target.write_bytes(hexfile.read_bytes());assert b'\r' not in target.read_bytes();mem[role]=m;roles[role]=dict(crc32=crc,body_bytes=len(body),body_sha256=sha(b/'application.bin'),manifest_sha256=sha(b/'application.manifest.bin'),hex_file=target.name,hex_sha256=sha(target))
 if role=='app':(O/('V2_APP'+crc+'.xenp')).write_bytes(manifest+body)
boot=R/'LATEST_FIRMWARE/V2_NP2/V2_recovery_only_6408DBB8_20261012.hex';assert sha(boot)=='C376D5716A7C1F54330351D0F62E1B375BD868F32C0D6C26A3434AF9DFEDBCEA';bootmem=pkg.read_intel_hex(boot);assert not (bootmem.keys()&mem['usb'].keys());(O/boot.name).write_bytes(boot.read_bytes())
fused=merge.merge({**bootmem,**mem['usb']},mem['app']);f=O/'V2_FUSED_BOOT_USBE581FE41_APPC88F3B27.hex';pkg.write_intel_hex(f,fused);f.write_bytes(f.read_bytes().replace(b'\r\n',b'\n'));assert pkg.read_intel_hex(f)==fused and not any(0x0801c000<=a<0x0801e000 for a in fused)
files={}
for role in ('app','usb'):
 for ext in ('receipt.json','application.lnp','application.sct','application.map','link.log'):
  p=N/('build-'+role)/ext;files['build-'+role+'/'+ext]=p
 for p in (N/('build-'+role)).glob('*.o'):files['build-'+role+'/'+p.name]=p
 for p in (N/('build-'+role)).glob('*.compile.json'):files['build-'+role+'/'+p.name]=p
for rel in ['Core/Src/xe_np_sensors.c','Core/Inc/xe_np_image_role.h','usb/Core/Src/xe_np_usb_sd_test_job.c','native-check.json','usb-pair-delta.json']:
 files[rel]=N/rel
files['Tools/Power/test_sd_idle_sensor_cadence.py']=R/'Tools/Power/test_sd_idle_sensor_cadence.py'
with zipfile.ZipFile(O/'source-freeze.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for rel,p in sorted(files.items()):z.write(p,rel)
small=set()
for pattern in ('*.json','*.py','*.cs','*.ps1','*.tcl','*.csv','*.log'):small.update(N.glob(pattern))
for folder in ('candidate-record','candidate-export','candidate-cleanup','compact','preflight'):
 small.update(p for p in (N/folder).rglob('*') if p.is_file())
for folder in ('original','deployment','variant-B1','variant-A2','variant-B2','owner'):
 small.update((N/folder).glob('*.json'));small.update((N/folder).glob('*.log'))
small.add(N/'preserved-originals/fingerprint.json');small.add(N/'preserved-originals/catalog.json');small.add(N/'debug-restored.txt')
assert all(p.stat().st_size<8*1024*1024 and p.resolve().is_relative_to(N.resolve()) for p in small)
with zipfile.ZipFile(O/'closure.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(small):z.write(p,p.relative_to(N).as_posix())
a=dict(status='VALIDATED_BOUNDED_IDLE_POWER_IMPROVEMENT',family='V2',firmware=roles,recovery_crc32='6408DBB8',fused=dict(file=f.name,bytes=f.stat().st_size,sha256=sha(f)),runtime=dict(version='1.0.0.248',host_sha256='364BE7FF77B45C4B959FB72FE9CB657E8F04CEDBCF4C21E3F8F2AC22890DAF30',sdk_sha256='EBC98EEB84FDE42DEE06B713F1F6246B30B3527732075D9F84C6DF57BCA69EFB'),idle_comparison=load(N/'idle-comparison.json'),recording_quality=load(N/'candidate-quality.json'),recording_power=load(N/'recording-power.json'),native_check=load(N/'native-check.json'),usb_delta=load(N/'usb-pair-delta.json'),restoration=load(N/'restoration-complete.json'),lease=load(N/'owner/lease.json'),source_freeze=dict(file='source-freeze.zip',bytes=(O/'source-freeze.zip').stat().st_size,sha256=sha(O/'source-freeze.zip')),closure=dict(file='closure.zip',bytes=(O/'closure.zip').stat().st_size,sha256=sha(O/'closure.zip')),installer_scope='Firmware/runtime248 API pair validated. Installer payload refresh is a separate canonical packaging action and must bind its exact new EXE/payload; original248 installer is not relabeled as containing these firmware assets.',limits=['Measured idle reduction only, sameboard/card5Vinput, one8s A/B/A window each. Not a LiPo, per-chip, allcard or recording-power saving.','New recording evidence is one ordinary3P20k CLoffBLE/SDStart/Stop/fullproductionUSBexport. Other rates/CL/USBstream/endurance use unchanged-parent evidence, not freshqualification.','Grid rows are scheduled cached snapshots; idle native-conversion omissions remain diagnostically counted. No native conversion-phase lock, analog stimulus/gain or arbitrary bit-error claim.','Source-window proofTrue in this capture does not make the unknown terminal finalordinal known.','Incremental checked driver plus USB expectedCRC constants; retained-object/source provenance limits of parent release remain. Not a complete clean source rebuild.','No new physical power-loss/torn-sector test. Shared mirroredjournal code retained unchanged; parent interrupted-write and normalDelete evidence reused.'],parent_acceptance_sha256='95D6FC028F7FB66DF46A575861D4158EBF70AEA0543F9A9038C9B926FC26201F')
(O/'acceptance.json').write_text(json.dumps(a,indent=2)+'\n',encoding='utf-8',newline='\n')
manifest=dict(status='validated_bounded',family='V2',app_crc32='C88F3B27',usb_crc32='E581FE41',recovery_crc32='6408DBB8',wildx_version='1.0.0.248',acceptance_sha256=sha(O/'acceptance.json'),files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in O.iterdir() if p.suffix in ('.hex','.xenp')},source_evidence='../../ReleaseSources/V2_IDLE_IMU_C88F3B27_E581FE41_20261106',limits=a['limits'])
manifest['files']['acceptance.json']=dict(bytes=(O/'acceptance.json').stat().st_size,sha256=sha(O/'acceptance.json'));(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
(O/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in sorted(O.iterdir()) if p.suffix in ('.hex','.xenp')),encoding='ascii',newline='\n')
(O/'README.md').write_text('''# V2 idle-power firmware —2026-11-06

APP C88F3B27 + USB E581FE41 + unchanged recovery6408DBB8. Use the fusedHEX for the complete image, or the sealed APP XENP with the matching service. Retained configuration is excluded. Runtime WILDX248 production APIs passed; use the separately identified canonical firmware-payload-refresh installer for bundled updates.

Same-board/card BLE/SD idle A/B/A measured21.900→20.676→21.711mA: bracketed1.129mA/5.682mW/5.18% lower USB input. Active sensor polling, NP/SD/PSRAM clocks and buffers remain unchanged. One ordinary3P20k CLoff recording/full export passed8612NPblocks,13778gridrows and2189native snapshots with reported gaps/queue losses0. This is bounded data acceptance, not all-mode/endurance/analog qualification. All22older recordings preserved; bench originals restored.

See acceptance.json and Note/V2_POWER_EFFICIENCY_20261106.md for timing/native/provenance and measurement limits. Source/evidence archives are separate; no private fullflash/preferences backup is published.
''',encoding='utf-8',newline='\n')
print(json.dumps(dict(fused_sha256=sha(f),acceptance_sha256=sha(O/'acceptance.json'),source_sha256=sha(O/'source-freeze.zip'),closure_sha256=sha(O/'closure.zip'),output=str(O)),indent=2))
