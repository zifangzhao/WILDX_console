param([Parameter(Mandatory=$true)][string]$Name,[uint32]$Target=128)
$ErrorActionPreference='Stop'
$taskLease=Get-Content (Join-Path $PSScriptRoot 'owner/lease.json') -Raw|ConvertFrom-Json
if($taskLease.status -ne 'active' -or $taskLease.global_status -ne 'held' -or !(Get-Process -Id $taskLease.pid -ErrorAction SilentlyContinue)){throw 'Fresh exclusive lease required'}
if($Name -notmatch '^[a-zA-Z0-9_-]+$' -or $Target -lt 128 -or $Target -ge 1152){throw 'Bounded metadata target required'}
$taskOut=Join-Path $PSScriptRoot $Name
if(Test-Path -LiteralPath $taskOut){throw 'Fresh observation folder required'}
$taskHost='C:/Frank/Code/USB_PCconsole/_artifacts/sd_usb_test_host/enabled248-bleready/WILDX_console.exe'
if((Get-FileHash $taskHost).Hash -ne '364BE7FF77B45C4B959FB72FE9CB657E8F04CEDBCF4C21E3F8F2AC22890DAF30'){throw 'Host changed'}
$taskAsm=[Reflection.Assembly]::LoadFrom($taskHost);$taskF=[Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
$taskType=$taskAsm.GetType('CE32_console.NpDownloadStream',$true)
$taskPath='\\?\usb#vid_1209&pid_b386#001a0004434250062039314e#{8f5a4a7b-0aa6-4f8e-a14f-a2f7b3c6aa4e}'
$taskCard=[IO.Stream][Activator]::CreateInstance($taskType,$taskF,$null,[object[]]@($taskPath,$false),$null)
try{
 if($taskCard.Length -ne 256666238976){throw 'Fresh card capacity differs'}
 New-Item -ItemType Directory -Path $taskOut|Out-Null
 $taskPins=@{}
 foreach($taskLba in @(112,113,114,115,116,$Target)){
  $taskBytes=New-Object byte[] 512;$taskCard.Position=512L*$taskLba;$taskAt=0
  while($taskAt -lt 512){$taskN=$taskCard.Read($taskBytes,$taskAt,512-$taskAt);if($taskN -le 0){throw 'Short metadata read'};$taskAt+=$taskN}
  $taskFile=Join-Path $taskOut ('sector-'+$taskLba+'.bin');[IO.File]::WriteAllBytes($taskFile,$taskBytes);$taskPins[[string]$taskLba]=(Get-FileHash $taskFile).Hash
 }
 @{status='READ_ONLY_PHYSICAL_METADATA';uid=$taskLease.uid;capacity=$taskCard.Length/512;target=$Target;pins=$taskPins;explicit_A1_A2=$false}|ConvertTo-Json -Depth 4|Set-Content (Join-Path $taskOut 'receipt.json')
}finally{$taskCard.Dispose()}
'PASS raw metadata observation'
