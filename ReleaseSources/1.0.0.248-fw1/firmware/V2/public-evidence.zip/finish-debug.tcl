init
targets stm32u5.cpu
set u [read_memory 0x0bfa0700 32 3]
if {[format "%08X%08X%08X" [lindex $u 0] [lindex $u 1] [lindex $u 2]] ne "001A0004434250062039314E"} {error "WrongUID"}
if {[lindex [read_memory 0xe000ed08 32 1] 0]!=0x8180000 || [lindex [read_memory 0x817e020 32 1] 0]!=0x74fc7104 || [lindex [read_memory 0x801e020 32 1] 0]!=0x7f238587} {error "OriginalImageIdentityMismatch"}
if {[lindex [read_memory 0x420c8034 32 1] 0]&0x103000 || [lindex [read_memory 0x420c8050 32 1] 0] || [lindex [read_memory 0x420c802c 32 1] 0]&1} {error "SDnotphysicallyquiet"}
for {set i 0} {$i<16} {incr i} {if {[lindex [read_memory [expr {0x40020064+$i*0x80}] 32 1] 0]&1} {error "DMAactive"}}
poll off
write_memory 0xe000edf0 32 {0xa05f0000}
set dhcsr [lindex [read_memory 0xe000edf0 32 1] 0]
if {$dhcsr&1 || $dhcsr&0x20000} {error "DebugOrHaltStillEnabled"}
set f [open {C:/Frank/Code/XE_NP/_artifacts/v2_power_efficiency_20261106/debug-restored.txt} w]
puts $f [format "UID correct, APP7F238587/USB74FC7104, physical SD/DMA quiet, DHCSR=%08X, C_DEBUGEN=0, S_HALT=0" $dhcsr]
close $f
shutdown
