param([Parameter(Mandatory=$true)][ValidateSet('B1','A2','B2')][string]$Stage)
$ErrorActionPreference='Stop';$n=$PSScriptRoot;$lease=Get-Content (Join-Path $n 'owner/lease.json') -Raw|ConvertFrom-Json
if($lease.status -ne 'active' -or $lease.global_status -ne 'held' -or $lease.uid -ne '001A0004434250062039314E' -or !(Get-Process -Id $lease.pid -ErrorAction SilentlyContinue)){throw 'Fresh exclusive exactUID lease required'}
$folder=Join-Path $n ('variant-'+$Stage);if(Test-Path $folder){throw 'One attempt per fresh stage'};New-Item -ItemType Directory -Path $folder|Out-Null
$usb='\\?\usb#vid_1209&pid_b386#001a0004434250062039314e#{8f5a4a7b-0aa6-4f8e-a14f-a2f7b3c6aa4e}'
& 'C:/Frank/Code/XE_NP/_artifacts/usb_sd_test_v2/raw-control/control-identity.exe' $usb in 6E 0 0 32 (Join-Path $folder 'before-service.bin')|Out-Null;if($LASTEXITCODE){throw 'No fresh USB idle proof'}
$b=[IO.File]::ReadAllBytes((Join-Path $folder 'before-service.bin'));if([BitConverter]::ToUInt32($b,8) -notin @(2,3) -or [BitConverter]::ToUInt32($b,16) -ne 0 -or [BitConverter]::ToUInt32($b,20) -ne 0){throw 'Not idle; no flash'}
$cli='C:/Program Files/STMicroelectronics/STM32Cube/STM32CubeProgrammer/bin/STM32_Programmer_CLI.exe'
function Cube([string]$name,[string[]]$args2){$log=& $cli -c port=SWD sn=004B00213532511131333430 mode=UR freq=3300 @args2 2>&1;$log|Out-File (Join-Path $folder ($name+'.log')) -Encoding utf8;if($LASTEXITCODE -ne 0 -or (($log|Out-String) -match '(?im)^\s*Error:')){throw ('Controlled stage failed; no replay: '+$name)}}
Cube 'uid' @('-u','0x0BFA0700','12',(Join-Path $folder 'uid.bin'))
if([BitConverter]::ToString([IO.File]::ReadAllBytes((Join-Path $folder 'uid.bin'))) -ne '04-00-1A-00-06-50-42-43-4E-31-39-20'){throw 'Wrong MCU; no flash'}
$base=[IO.File]::ReadAllBytes((Join-Path $n 'deployment/expected-full.bin'));$new=[byte[]]$base.Clone();$candidate=$Stage -ne 'A2'
$bodyPath=if($candidate){Join-Path $n 'build-app/application.bin'}else{'C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/build-app/application.bin'}
$manifestPath=if($candidate){Join-Path $n 'build-app/application.manifest.bin'}else{'C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/build-app/application.manifest.bin'}
$receiptPath=if($candidate){Join-Path $n 'build-app/receipt.json'}else{'C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/build-app/receipt.json'}
$r=Get-Content $receiptPath -Raw|ConvertFrom-Json;if((Get-FileHash $bodyPath).Hash -ne $r.body_sha256 -or (Get-FileHash $manifestPath).Hash -ne $r.manifest_sha256){throw 'Exact variant input identity mismatch'}
$body=[IO.File]::ReadAllBytes($bodyPath);$seal=[IO.File]::ReadAllBytes($manifestPath);[Array]::Copy($body,0,$new,0x20000,$body.Length);[Array]::Copy($seal,0,$new,0x1e000,$seal.Length)
if($Stage -eq 'B2'){
 $u=Get-Content (Join-Path $n 'build-usb/receipt.json') -Raw|ConvertFrom-Json
 $ub=Join-Path $n 'build-usb/application.bin';$um=Join-Path $n 'build-usb/application.manifest.bin'
 if((Get-FileHash $ub).Hash -ne $u.body_sha256 -or (Get-FileHash $um).Hash -ne $u.manifest_sha256){throw 'Exact pairedUSB identity mismatch'}
 $bodyUsb=[IO.File]::ReadAllBytes($ub);$sealUsb=[IO.File]::ReadAllBytes($um);[Array]::Copy($bodyUsb,0,$new,0x180000,$bodyUsb.Length);[Array]::Copy($sealUsb,0,$new,0x17e000,$sealUsb.Length)
}
[IO.File]::WriteAllBytes((Join-Path $folder 'expected-full.bin'),$new)
$pages=@(@('body',0x20000,385024),@('manifest',0x1e000,8192));if($Stage -eq 'B2'){$pages+=@(@('usb-body',0x180000,360448),@('usb-manifest',0x17e000,8192))};foreach($page in $pages){$bytes=New-Object byte[] $page[2];[Array]::Copy($new,$page[1],$bytes,0,$page[2]);$file=Join-Path $folder ($page[0]+'.bin');[IO.File]::WriteAllBytes($file,$bytes);Cube ('write-'+$page[0]) @('-w',$file,('0x{0:X8}' -f (0x08000000+$page[1])))}
Cube 'full-readback' @('-u','0x08000000','0x00400000',(Join-Path $folder 'full.bin'));Cube 'options' @('-u','0x40022040','64',(Join-Path $folder 'options.bin'))
$original=Get-Content (Join-Path $n 'original/receipt.json') -Raw|ConvertFrom-Json
if((Get-FileHash (Join-Path $folder 'full.bin')).Hash -ne (Get-FileHash (Join-Path $folder 'expected-full.bin')).Hash -or (Get-FileHash (Join-Path $folder 'options.bin')).Hash -ne $original.options_sha256){throw 'Variant readback mismatch; no reset'}
@{status='EXACT_VARIANT_FLASH_OPTIONS_VERIFIED';stage=$Stage;uid=$lease.uid;app_crc32=$r.crc32;usb_crc32=$(if($Stage -eq 'B2'){$u.crc32}else{'067D89A2'});whole_flash_sha256=(Get-FileHash (Join-Path $folder 'full.bin')).Hash;options_sha256=$original.options_sha256;utc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $folder 'verified.json')
Cube 'reset' @('-rst');'Exact variant '+$Stage+' APP'+$r.crc32+' installed'
