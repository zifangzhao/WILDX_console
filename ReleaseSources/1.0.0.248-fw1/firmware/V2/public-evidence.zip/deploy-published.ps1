param([ValidateSet('Install','Restore')][string]$Step='Install')
$ErrorActionPreference='Stop';$taskRoot=$PSScriptRoot;$taskD=Join-Path $taskRoot 'deployment'
$taskR=Get-Content (Join-Path $taskD 'receipt.json') -Raw|ConvertFrom-Json
$taskLease=Get-Content (Join-Path $taskRoot 'owner/lease.json') -Raw|ConvertFrom-Json
if($taskLease.status -ne 'active' -or $taskLease.global_status -ne 'held' -or !(Get-Process -Id $taskLease.pid -ErrorAction SilentlyContinue)){throw 'Exact hardware lease required'}
if($Step -eq 'Restore' -and !(Test-Path (Join-Path $taskD 'Install-verified.json'))){throw 'No verified candidate install'}
$taskFlag=[IO.File]::Open((Join-Path $taskD ($Step+'-ATTEMPTED')),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);$taskFlag.Dispose()
$taskCli='C:/Program Files/STMicroelectronics/STM32Cube/STM32CubeProgrammer/bin/STM32_Programmer_CLI.exe'
function Cube([string]$name,[string[]]$args2){$taskLog=& $taskCli -c port=SWD sn=004B00213532511131333430 mode=UR freq=3300 @args2 2>&1;$taskLog|Out-File (Join-Path $taskD ($Step+'-'+$name+'.log')) -Encoding utf8;if($LASTEXITCODE -ne 0 -or (($taskLog|Out-String) -match '(?im)^\s*Error:')){throw ('CLI failure; no automatic retry: '+$name)}}
$taskUsb='\\?\usb#vid_1209&pid_b386#001a0004434250062039314e#{8f5a4a7b-0aa6-4f8e-a14f-a2f7b3c6aa4e}'
$taskControl='C:/Frank/Code/XE_NP/_artifacts/usb_sd_test_v2/raw-control/control-identity.exe'
& $taskControl $taskUsb in 6E 0 0 32 (Join-Path $taskD ($Step+'-before-service.bin'))|Out-Null
if($LASTEXITCODE){throw 'Fresh known-idle USB service required before controlled flash'}
$taskB=[IO.File]::ReadAllBytes((Join-Path $taskD ($Step+'-before-service.bin')))
if([BitConverter]::ToUInt32($taskB,8) -notin @(2,3) -or [BitConverter]::ToUInt32($taskB,16) -ne 0 -or [BitConverter]::ToUInt32($taskB,20) -ne 0){throw 'USB not idle; no reset/flash'}
Cube 'fresh-uid' @('-u','0x0BFA0700','12',(Join-Path $taskD ($Step+'-uid.bin')))
if([BitConverter]::ToString([IO.File]::ReadAllBytes((Join-Path $taskD ($Step+'-uid.bin')))) -ne '04-00-1A-00-06-50-42-43-4E-31-39-20'){throw 'Fresh SWD UID mismatch; no flash'}
if($Step -eq 'Install'){
 Cube 'fresh-preimage' @('-u','0x08000000','0x00400000',(Join-Path $taskD 'Install-preimage.bin'))
 if((Get-FileHash (Join-Path $taskD 'Install-preimage.bin')).Hash -ne $taskR.install_preimage_sha256){throw 'Fresh final original image changed; no flash'}
}
foreach($taskPage in $taskR.pages){$taskKind=if($Step -eq 'Install'){'new'}else{'old'};$taskFile=Join-Path $taskD ($taskPage.name+'-'+$taskKind+'.bin');$taskExpected=if($Step -eq 'Install'){$taskPage.new_sha256}else{$taskPage.old_sha256};if((Get-FileHash $taskFile -Algorithm SHA256).Hash -ne $taskExpected){throw 'Page identity mismatch'};Cube ('write-'+$taskPage.name) @('-w',$taskFile,('0x{0:X8}' -f $taskPage.address))}
Cube 'full-readback' @('-u','0x08000000','0x00400000',(Join-Path $taskD ($Step+'-full.bin')))
Cube 'options-readback' @('-u','0x40022040','64',(Join-Path $taskD ($Step+'-options.bin')))
$taskExpected=if($Step -eq 'Install'){$taskR.candidate_full_sha256}else{$taskR.original_full_sha256}
if((Get-FileHash (Join-Path $taskD ($Step+'-full.bin')) -Algorithm SHA256).Hash -ne $taskExpected -or (Get-FileHash (Join-Path $taskD ($Step+'-options.bin')) -Algorithm SHA256).Hash -ne $taskR.options_sha256){throw 'Readback mismatch; no reset/retry'}
$taskProof=@{status='EXACT_FLASH_AND_OPTIONS_VERIFIED';step=$Step;uid=$taskR.uid;whole_flash_sha256=$taskExpected;options_sha256=$taskR.options_sha256;utc=[DateTime]::UtcNow.ToString('o')}
$taskProof|ConvertTo-Json|Set-Content (Join-Path $taskD ($Step+'-verified.json')) -Encoding utf8
Cube 'reset' @('-rst')
$taskProof|ConvertTo-Json -Compress
