from pathlib import Path
import hashlib, importlib.util, json, re, struct, subprocess, sys, zlib

T=Path(__file__).resolve().parent
R=Path('D:/Code/XE_NP_V2')
K=Path('C:/Keil_v5/ARM/ARMCLANG/bin')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def run(cmd, log):
    p=subprocess.run([str(x) for x in cmd],cwd=R,capture_output=True,text=True)
    log.write_text(p.stdout+p.stderr)
    assert p.returncode==0,p.stdout+p.stderr
def fixed_symbols(p):
    return {(m[1],m[4]):(int(m[2],16),int(m[3])) for m in re.finditer(r'^\s+(\S+)\s+(0x[\da-fA-F]+)\s+Data\s+(\d+)\s+([^\r\n]+)',p.read_text(),re.M) if m[4].endswith(('(NP_CAPTURE)','(NP2_CL_SELECTED)','(NP_USB_DOWNLOAD0)','(NP_USB_DOWNLOAD1)','(NP_AUX_ADC)','(NP_AUX_TX)','(NP_AUX_CAMERA)','(NP2_LIVE_RU0)','(NP2_LIVE_RU8)'))}
sys.path.insert(0,str(R/'Tools'))
import package_xe_np_firmware as pkg
from verify_xe_np_slot_hex import verify
pkg.LOADER_ABI_VERSION=4

def build(role, base, expected, commands, outname=None):
    parent=load(base/'receipt.json')
    assert parent['crc32']==expected and sha(base/'application.bin')==parent['body_sha256']
    out=T/(outname or 'build-'+role);out.mkdir(exist_ok=True)
    if (out/'receipt.json').exists():
        checked=load(out/'receipt.json')
        assert checked['body_sha256']==sha(out/'application.bin')
        assert all(sha(p)==h for p,h in checked['source_pins'].items())
        return checked['crc32']
    link=(base/'application.lnp').read_text()
    objects=re.findall(r'"([^"\r\n]+\.o)"',link)
    retained={};compiled={}
    for unit,template,source in commands:
        cmd=list(template)
        cmd[1:1]=['-I',str(T/'Core/Inc'),'-iquote',str(T/'usb/Core/Src'),'-iquote',str(T/'Core/Src')]
        if unit=='xe_np_np2_dual_sd_catalog' and not any(x.startswith('-DXE_NP_NP2_SD_CATALOG_ENABLE=') for x in cmd):
            cmd.insert(1,'-DXE_NP_NP2_SD_CATALOG_ENABLE=1U')
        if role=='app' and not any(x.startswith('-DXE_NP_IMU_GRID_CAPACITY=') for x in cmd):
            cmd.insert(1,'-DXE_NP_IMU_GRID_CAPACITY=512U')
        cmd=[('-DXE_NP_USB_SD_TEST_APP_CRC32=0x'+app_crc+'UL') if x.startswith('-DXE_NP_USB_SD_TEST_APP_CRC32=') and role=='usb' else x for x in cmd]
        cmd[cmd.index('-c')+1]=str(source)
        cmd[cmd.index('-o')+1]=str(out/(unit+'.o'))
        if '-MF' in cmd:cmd[cmd.index('-MF')+1]=str(out/(unit+'.d'))
        cache=out/(unit+'.compile.json')
        inputs={str(p):sha(p) for sub in ['Core/Src','Core/Inc','usb/Core/Src'] for p in (T/sub).glob('*') if p.is_file()}
        key=dict(command=cmd,inputs=inputs)
        if cache.exists():
            saved=load(cache);assert saved['key']==key and saved['object_sha256']==sha(out/(unit+'.o'))
        else:
            run(cmd,out/(unit+'.compile.log'))
            cache.write_text(json.dumps(dict(key=key,object_sha256=sha(out/(unit+'.o'))),indent=2)+'\n')
        old=[x for x in objects if Path(x).stem==unit];assert len(old)==1,(unit,old)
        link=link.replace(old[0],(out/(unit+'.o')).as_posix())
        compiled[unit]=cmd
    replaced={unit for unit,_,_ in commands}
    for p in objects:
        if Path(p).stem in replaced:continue
        h=sha(p)
        if p in parent['retained_objects']:assert h==parent['retained_objects'][p],p
        elif Path(p).stem in parent['compiler_commands']:
            assert Path(parent['compiler_commands'][Path(p).stem][parent['compiler_commands'][Path(p).stem].index('-o')+1])==Path(p)
        else:raise AssertionError('Unpinned parent object '+p)
        retained[p]=h
    for name in ['application.sct','application.axf','application.map']:
        link=link.replace((base/name).as_posix(),(out/name).as_posix())
    (out/'application.sct').write_bytes((base/'application.sct').read_bytes())
    (out/'application.lnp').write_text(link)
    run([K/'armlink.exe','--via',out/'application.lnp'],out/'link.log')
    assert fixed_symbols(base/'application.map')==fixed_symbols(out/'application.map')
    run([K/'fromelf.exe','--bin','--output',out/'application.bin',out/'application.axf'],out/'fromelf.log')
    b=(out/'application.bin').read_bytes()
    m=pkg.build_manifest(b,generation=3,image_id=pkg.IMAGE_ID_APPLICATION if role=='app' else pkg.IMAGE_ID_USB_SERVICE,usb_auto_app=role=='usb')
    (out/'application.manifest.bin').write_bytes(m)
    crc=f'{zlib.crc32(b):08X}'
    hp=out/('V2_'+role.upper()+crc+'.hex')
    pkg.write_intel_hex(hp,pkg.sealed_slot_memory(b,m));hp.write_bytes(hp.read_bytes().replace(b'\r\n',b'\n'))
    verify(hp,b,m)
    pins={str(p):sha(p) for sub in ['Core/Src','Core/Inc','usb/Core/Src'] for p in (T/sub).glob('*') if p.is_file()}
    regions=re.findall(r'^\s*Execution Region .+$',(out/'application.map').read_text(),re.M)
    receipt=dict(status='SOFTWARE_CHECKED_HIL_PENDING',parent_crc32=expected,crc32=crc,expected_app_crc32=crc if role=='app' else app_crc,body_bytes=len(b),body_sha256=sha(out/'application.bin'),manifest_sha256=sha(out/'application.manifest.bin'),hex_sha256=sha(hp),hex=str(hp),compiler_commands=compiled,source_pins=pins,retained_objects=retained,execution_regions=regions,stack_vector=hex(struct.unpack_from('<I',b)[0]),reset_vector=hex(struct.unpack_from('<I',b,4)[0]),scope='Stopped-only mirrored Delete Last redo and automatic admission reconciliation; unchanged NP/IMU/capture/writer objects and fixed stream buffers')
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:receipt[k] for k in ['status','crc32','body_bytes','body_sha256','stack_vector']},indent=2),flush=True)
    return crc


p=Path(r'C:/Frank/Code/XE_NP/_artifacts/grid16_sd_build_r8/plan.json');cmd=load(p)['commands']['xe_np_sensors']
base=Path(r'C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/build-app')
build('app',base,'7E463C83',[('xe_np_sensors',cmd,T/'Core/Src/xe_np_sensors.c')])
r=load(T/'build-app/receipt.json');r['scope']='APP-only idle BMX host polling40ms; recording5ms/USB unchanged, sensor registers/capture/storage unchanged; actual-source native regression passes; HIL/power pending';r['native_check']='Tools/Power/test_sd_idle_sensor_cadence.py roles1/2 PASS';r['parent_sensor_object_sha256']='2D99ED672137513BDC9A134F96C108B20D519332189F0E78261C8785852710E3';(T/'build-app/receipt.json').write_text(json.dumps(r,indent=2)+'\n')
