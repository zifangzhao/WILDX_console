param([Parameter(Mandatory=$true)][string]$Name)
$ErrorActionPreference='Stop'
$lease=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'owner/lease.json') -Raw|ConvertFrom-Json
if($lease.status -ne 'active' -or $lease.uid -ne '001A0004434250062039314E' -or !(Get-Process -Id $lease.pid -ErrorAction SilentlyContinue)){throw 'Exact lease required'}
$asm=[Reflection.Assembly]::LoadFrom('C:/Frank/Code/USB_PCconsole/_artifacts/sd_usb_test_host/enabled248-bleready/WILDX_console.exe');$f=[Reflection.BindingFlags]'Public,NonPublic,Static,Instance';$t=$asm.GetType('USB512_interface.NpV2UsbDevice',$true)
$path='\\?\usb#vid_1209&pid_b386#001a0004434250062039314e#{8f5a4a7b-0aa6-4f8e-a14f-a2f7b3c6aa4e}'
$watch=[Diagnostics.Stopwatch]::StartNew();$errors=[Collections.Generic.List[string]]::new()
do{try{$d=$t.GetMethod('Open',$f).Invoke($null,@($path));try{$s=$t.GetMethod('GetServiceStatus',$f).Invoke($d,@());$mode=$s.GetType().GetField('Mode',$f).GetValue($s);$busy=$s.GetType().GetField('Busy',$f).GetValue($s);$target=$s.GetType().GetField('Target',$f).GetValue($s);if($mode -in @(2,3) -and !$busy -and !$target){@{status='FRESH_USB_IDLE';mode=$mode;seconds=$watch.Elapsed.TotalSeconds;readonly_errors=$errors.ToArray();uid=$lease.uid}|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $PSScriptRoot ('preflight/'+$Name+'.json'));Write-Output ('USB idle mode '+$mode);return}}finally{$d.Dispose()}}catch{$errors.Add($_.Exception.Message)};Start-Sleep -Milliseconds 250}while($watch.Elapsed.TotalSeconds -lt 30)
throw 'USB return not confirmed; no mode mutation replayed'

