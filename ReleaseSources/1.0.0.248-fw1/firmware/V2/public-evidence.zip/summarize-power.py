from pathlib import Path
import csv,json,statistics,sys
n=Path(__file__).resolve().parent
for name in sys.argv[1:]:
 p=n/(name+'.csv');r=list(csv.DictReader(p.open(encoding='utf-8-sig')));start=float(r[0]['ts'])+2;window=[v for v in r if start<=float(v['ts'])<start+8];ts=[float(v['ts']) for v in window]
 x=dict(phase=name,current_mA=statistics.fmean(float(v['current_mA']) for v in window),power_mW=1000*statistics.fmean(float(v['power_w']) for v in window),voltage_V=statistics.fmean(float(v['voltage_v']) for v in window),samples=len(window),coverage_s=ts[-1]-ts[0],max_gap_ms=max(b-a for a,b in zip(ts,ts[1:]))*1000,mean_window_s=8,window_start=start,window_end=start+8)
 assert x['coverage_s']>=7.8 and x['max_gap_ms']<=250 and x['samples']>=300
 (n/(name+'-power.json')).write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x))
