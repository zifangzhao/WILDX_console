$ErrorActionPreference='Stop'
$taskRoot=$PSScriptRoot;$taskOut=Join-Path $taskRoot 'original';New-Item -ItemType Directory -Force $taskOut|Out-Null
$taskLease=Get-Content (Join-Path $taskRoot 'owner/lease.json') -Raw|ConvertFrom-Json
if($taskLease.status -ne 'active' -or $taskLease.global_status -ne 'held' -or !(Get-Process -Id $taskLease.pid -ErrorAction SilentlyContinue)){throw 'Exact hardware lease missing'}
$taskUsb='\\?\usb#vid_1209&pid_b386#001a0004434250062039314e#{8f5a4a7b-0aa6-4f8e-a14f-a2f7b3c6aa4e}'
$taskTool='C:/Frank/Code/XE_NP/_artifacts/usb_sd_test_v2/raw-control/control-identity.exe'
& $taskTool $taskUsb in 6E 0 0 32 (Join-Path $taskOut 'before-service.bin')|Out-Null;if($LASTEXITCODE){throw 'Fresh USB status failed'}
$taskB=[IO.File]::ReadAllBytes((Join-Path $taskOut 'before-service.bin'))
if([BitConverter]::ToUInt32($taskB,8) -notin @(2,3) -or [BitConverter]::ToUInt32($taskB,16) -ne 0 -or [BitConverter]::ToUInt32($taskB,20) -ne 0){throw 'Device is not idle download; no reset/backup'}
$taskAsm=[Reflection.Assembly]::LoadFrom('C:/Frank/Code/USB_PCconsole/_artifacts/sd_usb_test_host/enabled246-v1catalog/WILDX_console.exe');$taskFlags=[Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
$taskDeviceType=$taskAsm.GetType('USB512_interface.NpV2UsbDevice',$true)
$taskDevice=$taskDeviceType.GetMethod('Open',$taskFlags).Invoke($null,@($taskUsb))
try {if([BitConverter]::ToUInt32($taskB,8) -eq 2){$taskCap=$taskDeviceType.GetMethod('GetCaptureStatus',$taskFlags).Invoke($taskDevice,@());if($taskCap.GetType().GetProperty('State',$taskFlags).GetValue($taskCap,$null) -ne 0){throw 'Capture not idle; no reset/backup'}}}finally{$taskDevice.Dispose()}
$taskPref=Join-Path $env:LOCALAPPDATA 'WILDX_console/closed_loop_v2.json'
$taskPrefState=@{path=$taskPref;existed=(Test-Path -LiteralPath $taskPref);recorded_utc=[DateTime]::UtcNow.ToString('o')}
if($taskPrefState.existed){Copy-Item -LiteralPath $taskPref -Destination (Join-Path $taskOut 'closed_loop_v2.json');$taskPrefState.sha256=(Get-FileHash $taskPref -Algorithm SHA256).Hash}
$taskPrefState|ConvertTo-Json|Set-Content (Join-Path $taskOut 'preferences.json') -Encoding utf8
$taskCli='C:/Program Files/STMicroelectronics/STM32Cube/STM32CubeProgrammer/bin/STM32_Programmer_CLI.exe'
foreach($taskRead in @(@('uid','0x0BFA0700','12'),@('full','0x08000000','0x00400000'),@('options','0x40022040','64'))){
 $taskLog=& $taskCli -c port=SWD sn=004B00213532511131333430 mode=UR freq=3300 -u $taskRead[1] $taskRead[2] (Join-Path $taskOut ($taskRead[0]+'.bin')) 2>&1
 $taskLog|Out-File (Join-Path $taskOut ($taskRead[0]+'.log')) -Encoding utf8
 if($LASTEXITCODE -ne 0 -or (($taskLog|Out-String) -match '(?im)^\s*Error:')){throw ('Controlled backup failed '+$taskRead[0])}
 if($taskRead[0] -eq 'uid' -and [BitConverter]::ToString([IO.File]::ReadAllBytes((Join-Path $taskOut 'uid.bin'))) -ne '04-00-1A-00-06-50-42-43-4E-31-39-20'){throw 'Fresh SWD UID mismatch; no further access'}
}
if([BitConverter]::ToString([IO.File]::ReadAllBytes((Join-Path $taskOut 'uid.bin'))) -ne '04-00-1A-00-06-50-42-43-4E-31-39-20'){throw 'SWD MCU identity mismatch; no flash'}
$taskReceipt=@{status='FRESH_ORIGINAL_BACKUP_NO_FLASH';uid=$taskLease.uid;full_sha256=(Get-FileHash (Join-Path $taskOut 'full.bin') -Algorithm SHA256).Hash;options_sha256=(Get-FileHash (Join-Path $taskOut 'options.bin') -Algorithm SHA256).Hash;preferences=$taskPrefState;timestamp_utc=[DateTime]::UtcNow.ToString('o');scope='Explicit known-idle controlled-reset backup for temporary deployment; not a live CubeProgrammer diagnostic'}
$taskReceipt|ConvertTo-Json -Depth 5|Set-Content (Join-Path $taskOut 'receipt.json') -Encoding utf8
$taskReceipt|ConvertTo-Json -Depth 5 -Compress
