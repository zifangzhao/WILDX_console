"""Record production full-export integrity; do not promote unverified timing."""
from pathlib import Path
import hashlib,json,re,sys
T=Path(__file__).resolve().parent
folder=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve()
assert folder.is_relative_to(T) and not out.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
text=(folder/'np2_sd_export_status.txt').read_text(encoding='utf-8-sig')
status=dict(x.split(': ',1) for x in text.splitlines() if ': ' in x)
kv=lambda p:dict(x.split('=',1) for x in p.read_text(encoding='utf-8-sig').splitlines() if '=' in x)
grid=kv(folder/'imu_grid_status.txt');sensor=kv(folder/'imu_sd_export_status.txt')
manifest=json.loads((folder/'tail_export_manifest.json').read_text(encoding='utf-8-sig'));tail=manifest['tail']
assert manifest['after']['records'][:-1]==manifest['before']['records']
assert status['Export complete']==status['Recording complete']==status['Lossless']=='True'
assert all(status[x]=='0' for x in ['Stored fault','Source gap count','Missing source ticks','Dropped source blocks','Physical overflow events','Producer discarded raw ticks'])
assert tail['chunks']==int(status['Committed blocks']) and tail['session']==int(status['Session'])
probes=[]
for m in re.finditer(r'Probe (\d+): file=([^;]+); rows=(\d+); phase=(\d+); first_source_tick=(\d+); trailing_ticks=(\d+); SHA256=([A-F0-9]+)',text):
 probe,file,rows,phase,first,trailing,digest=m.groups();rows=int(rows);p=folder/file
 assert p.stat().st_size==rows*768
 assert int(status['Source ticks'])-int(first)==rows*1600+int(trailing)
 probes.append(dict(probe=int(probe),rows=rows,bytes=p.stat().st_size,writer_sha256=digest))
assert len(probes)==3
assert sensor['export_complete']=='True' and sensor['error']=='none'
assert all(sensor[x]=='0' for x in ['invalid_sensor_observations','sequence_gaps','reset_segments'])
assert all(grid[x]=='0' for x in ['queue_dropped','scheduler_missing','bad_sectors','known_accepted_rows_not_persisted'])
assert grid['pending_record_rows_unknown']=='False' and grid['error']=='none'
valid=(folder/'analogin_validity.dat').read_bytes()
assert len(valid)*32==(folder/'analogin.dat').stat().st_size
assert all((v&7)==7 and not(v&32) for v in valid),'Grid observation/AG/MAG validity or sensor error'
pins={str(p.relative_to(folder)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in folder.iterdir() if p.is_file() and p.suffix!='.dat'}
result=dict(status='PASS_FULL_PRODUCTION_EXPORT_WITH_TIMING_LIMITS',session=tail['session'],np_blocks=tail['chunks'],source_seconds=int(status['Source ticks'])/32000000,probe_mask=tail['mask'],hz=tail['hz'],np_loss_counters=0,probes=probes,grid_rows=len(valid),grid_queue_scheduler_accepted_unsaved=0,native_snapshots=int(sensor['snapshot_observations']),native_sequence_invalid_errors=0,source_window_verified=grid['source_window_verified'],phase_qualified=grid['phase_qualified'],limits=['Production exporter validates full stored neural framing/counters/lengths; DAT hashes are writer computed, not reread here.','No claim of analog or arbitrary ADC bit-error absence.','Scheduled IMU rows are cached fixed-grid snapshots, not native conversion lock.','source_window_verified and unknown terminal tail remain explicit; bounds are not silently promoted.'],small_input_pins=pins)
out.write_text(json.dumps(result,indent=2)+'\n')
proof=out.with_name(out.stem+'-own-verified.json')
proof.write_text(json.dumps(dict(status='verified_full_readback',uid=manifest['after']['uid'],start=tail['start'],end=tail['end'],session=tail['session'],quality_receipt=str(out),quality_sha256=sha(out)),indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','session','np_blocks','source_seconds','grid_rows','native_snapshots','source_window_verified']}))
print(proof)
