#include "xe_np_sensors.h"
#include "xe_np_image_role.h"
#include <math.h>
#include <stddef.h>
#include <string.h>

#define IO_DEADLINE_MS 20U
#define RETRY_MS 2000U
#define BMX_ID 0xd8U
#define BME_ID 0x60U
/* Preserve checked role profiles: USB MAG25, SD MAG100. */
#ifndef XE_NP_SENSOR_MAG_ODR
#if defined(XE_NP_IMAGE_ROLE) && XE_NP_IMAGE_ROLE==2U
#define XE_NP_SENSOR_MAG_ODR 0x06U
#else
#define XE_NP_SENSOR_MAG_ODR 0x08U
#endif
#endif
enum { OFF, IDENTIFY, RESET_SENSOR, CONFIGURE, POLL_STATUS, READ_SAMPLE,
       BME_NVM, BME_CAL1, BME_CAL2, BME_CONFIG, BME_TRIGGER, BME_MEASURING,
       BME_READ, FAILED, AG_CONFIG, AUX_WAIT };
enum { WRITE_REG, EXPECT_REG, MAG_TRIM1, MAG_TRIM2, MAG_TRIM3, MAG_TRIM4, VERIFY_CONFIG, EXPECT_PMU };
typedef struct { uint8_t reg,value,length,wait_ms,action; } SensorStep;
/* BMX160 (not BMI270): register 0x4c is MAG_IF_0. Internal BMM150 access
 * is indirect. Each write and its settling delay is a separate async step. */
static const SensorStep bmx_steps[] = {
    {0x00,BMX_ID,1,0,EXPECT_REG},
    {0x7e,0x11,1,5,WRITE_REG}, {0x7e,0x15,1,85,WRITE_REG},
    {0x7e,0x19,1,2,WRITE_REG},
    {0x40,0x29,1,1,WRITE_REG}, {0x41,0x08,1,1,WRITE_REG},
    {0x42,0x29,1,1,WRITE_REG}, {0x43,0x00,1,1,WRITE_REG},
    {0x44,XE_NP_SENSOR_MAG_ODR,1,1,WRITE_REG}, /* 200 Hz AG; role MAG profile */
    {0x4c,0x83,1,10,WRITE_REG}, /* manual, eight-byte shadow burst */
    {0x4f,0x01,1,1,WRITE_REG}, {0x4e,0x4b,1,10,WRITE_REG},
    {0x4d,0x40,1,10,WRITE_REG}, {0x04,0x32,1,0,EXPECT_REG},
    {0x4d,0x5d,1,10,WRITE_REG}, {0x04,0,8,0,MAG_TRIM1},
    {0x4d,0x62,1,10,WRITE_REG}, {0x04,0,8,0,MAG_TRIM2},
    {0x4d,0x68,1,10,WRITE_REG}, {0x04,0,8,0,MAG_TRIM3},
    {0x4d,0x70,1,10,WRITE_REG}, {0x04,0,8,0,MAG_TRIM4},
    {0x4f,0x04,1,1,WRITE_REG}, {0x4e,0x51,1,10,WRITE_REG},
    {0x4f,0x0e,1,1,WRITE_REG}, {0x4e,0x52,1,10,WRITE_REG},
    {0x4f,0x02,1,1,WRITE_REG}, {0x4e,0x4c,1,10,WRITE_REG},
    {0x4d,0x42,1,10,WRITE_REG}, {0x4c,0x03,1,45,WRITE_REG},
    {0x03,0x15,1,0,EXPECT_PMU}, {0x02,0x00,1,0,EXPECT_REG},
    {0x40,0,5,0,VERIFY_CONFIG}
};
static const SensorStep bme_steps[] = {
    {0xf2,1,1,0,WRITE_REG}, /* ctrl_hum must precede ctrl_meas */
    {0xf5,0,1,0,WRITE_REG}, {0xf4,0x24,1,0,WRITE_REG},
    {0xf2,1,1,0,EXPECT_REG}, {0xf4,0x24,1,0,EXPECT_REG},
    {0xf5,0,1,0,EXPECT_REG}
};
static const SensorStep ag_only_steps[] = {
    {0x7e,0x18,1,2,WRITE_REG}, /* suspend failed magnetic interface, preserve AG */
    {0x03,0x14,1,0,EXPECT_PMU}, {0x40,0,4,0,VERIFY_CONFIG}
};
static void mag_unavailable(XE_NP_Sensors *s,uint32_t now)
{
    s->mag_calibrated=0;s->snapshot.valid&=~XE_NP_SENSOR_VALID_MAG;
    memset(s->snapshot.mag_nano_tesla,0,sizeof(s->snapshot.mag_nano_tesla));
    s->snapshot.error[0]=XE_NP_SENSOR_ERR_MAG_UNAVAILABLE;
    s->device[0].step=0;s->device[0].state=AG_CONFIG;s->device[0].next_due=now;
    s->device[0].phase_deadline=now+100U;
}
static int reached(uint32_t now,uint32_t deadline) { return (int32_t)(now-deadline)>=0; }
static uint16_t u16(const uint8_t *p) { return (uint16_t)((uint16_t)p[0]|((uint16_t)p[1]<<8)); }
static int16_t s16(const uint8_t *p) { uint16_t v=u16(p);return (int16_t)((v&0x8000U)?(int32_t)v-65536:(int32_t)v); }
static int16_t signed12(uint16_t v) { return (int16_t)((v&0x800U)?(int32_t)v-4096:(int32_t)v); }
static int blank(const uint8_t *p,uint32_t n)
{ uint32_t zero=0,ones=0;for(uint32_t i=0;i<n;i++) { zero+=p[i]==0;ones+=p[i]==255; }return zero==n||ones==n; }
/* Compensation never performs I/O. Bosch's aux decoder checks these pointers
 * even though it only uses trim_data; fail if an unexpected bus call is added. */
static int8_t no_read(uint8_t a,uint8_t *p,uint32_t n,void *ctx) { (void)a;(void)p;(void)n;(void)ctx;return -1; }
static int8_t no_write(uint8_t a,const uint8_t *p,uint32_t n,void *ctx) { (void)a;(void)p;(void)n;(void)ctx;return -1; }
static void no_delay(uint32_t n,void *ctx) { (void)n;(void)ctx; }
static uint32_t crc32_ieee(const uint8_t *p,uint32_t bytes)
{
    uint32_t crc=0xffffffffU;
    while(bytes--) {
        crc^=*p++;
        for(uint32_t bit=0U;bit<8U;bit++)crc=(crc>>1)^((crc&1U)?0xedb88320U:0U);
    }
    return crc^0xffffffffU;
}
static void put32(uint8_t *p,uint32_t v)
{ p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);p[2]=(uint8_t)(v>>16);p[3]=(uint8_t)(v>>24); }
int XE_NP_Sensors_EncodeSdPacket(const XE_NP_SensorSnapshot *snapshot,uint8_t packet[XE_NP_SENSOR_SD_PACKET_BYTES])
{
    if(!snapshot || !packet)return -1;
    memcpy(packet,snapshot,XE_NP_SENSOR_SD_PACKET_PREFIX_BYTES);
    put32(packet,0x32534e53U);put32(packet+4U,2U);
    put32(packet+XE_NP_SENSOR_SD_PACKET_PREFIX_BYTES,
          crc32_ieee(packet,XE_NP_SENSOR_SD_PACKET_PREFIX_BYTES));
    return 0;
}

int XE_NP_Sensors_ParseBmeCalibration(const uint8_t *a,const uint8_t *h,struct bme280_calib_data *c)
{
    if(!a||!h||!c||blank(a,26)||blank(h,7)||u16(a)==0||u16(a+6)==0||u16(a)==65535||u16(a+6)==65535)return -1;
    memset(c,0,sizeof(*c));
    c->dig_t1=u16(a);c->dig_t2=s16(a+2);c->dig_t3=s16(a+4);
    c->dig_p1=u16(a+6);c->dig_p2=s16(a+8);c->dig_p3=s16(a+10);
    c->dig_p4=s16(a+12);c->dig_p5=s16(a+14);c->dig_p6=s16(a+16);
    c->dig_p7=s16(a+18);c->dig_p8=s16(a+20);c->dig_p9=s16(a+22);
    c->dig_h1=a[25];c->dig_h2=s16(h);c->dig_h3=h[2];
    c->dig_h4=signed12((uint16_t)((uint16_t)h[3]*16U+(h[4]&15U)));
    c->dig_h5=signed12((uint16_t)((uint16_t)h[5]*16U+(h[4]>>4)));
    c->dig_h6=(int8_t)h[6];return 0;
}
int XE_NP_Sensors_DecodeBme(const uint8_t *p,struct bme280_calib_data *c,XE_NP_SensorSnapshot *out)
{
    struct bme280_uncomp_data raw;struct bme280_data value;
    if(!p||!c||!out||!c->dig_p1||!c->dig_t1)return -1;
    raw.pressure=((uint32_t)p[0]<<12)|((uint32_t)p[1]<<4)|(p[2]>>4);
    raw.temperature=((uint32_t)p[3]<<12)|((uint32_t)p[4]<<4)|(p[5]>>4);
    raw.humidity=((uint32_t)p[6]<<8)|p[7];
    if(raw.pressure==0x80000U||raw.temperature==0x80000U||raw.humidity==0x8000U)return -1;
    if(bme280_compensate_data(BME280_ALL,&raw,&value,c)!=BME280_OK ||
       !isfinite(value.temperature)||!isfinite(value.pressure)||!isfinite(value.humidity))return -1;
    out->temperature_centi_c=(int32_t)(value.temperature*100.0+(value.temperature>=0?0.5:-0.5));
    out->pressure_pa=(uint32_t)(value.pressure+0.5);
    out->humidity_milli_percent=(uint32_t)(value.humidity*1000.0+0.5);return 0;
}
static int parse_mag_trim(XE_NP_Sensors *s)
{
    const uint8_t *a=s->device[0].calibration,*b=a+2,*c=b+4;
    struct bmm150_trim_registers *t=&s->magnetometer.trim_data;
    if(blank(a,16))return -1;
    t->dig_x1=(int8_t)a[0];t->dig_y1=(int8_t)a[1];
    t->dig_z4=s16(b);t->dig_x2=(int8_t)b[2];t->dig_y2=(int8_t)b[3];
    t->dig_z2=s16(c);t->dig_z1=u16(c+2);t->dig_xyz1=(uint16_t)(u16(c+4)&0x7fffU);
    t->dig_z3=s16(c+6);t->dig_xy2=(int8_t)c[8];t->dig_xy1=c[9];
    if(!t->dig_z1||!t->dig_z2||!t->dig_xyz1||t->dig_z1==65535U)return -1;
    s->mag_calibrated=1;return 0;
}
int XE_NP_Sensors_DecodeImu(XE_NP_Sensors *s,const uint8_t *p,uint8_t status,uint32_t now)
{
    if(!s||!p)return -1;
    XE_NP_SensorSnapshot *out=&s->snapshot;
    uint32_t time=(uint32_t)p[20]|((uint32_t)p[21]<<8)|((uint32_t)p[22]<<16);
    uint32_t delta=(time-s->previous_sensor_time)&0xffffffU;
    if(s->have_sensor_time && (!delta||delta>=0x800000U))return -1;
    if(s->have_sensor_time && delta>=256U)out->missed_imu_samples+=delta/128U-1U;
    s->previous_sensor_time=time;s->have_sensor_time=1;out->sensor_time_24=time;
    for(uint32_t i=0;i<3;i++) {
        out->accel_micro_g[i]=(int32_t)((int64_t)s16(p+14+i*2)*8000000/32768);
        out->gyro_milli_dps[i]=(int32_t)((int64_t)s16(p+8+i*2)*10000/164);
    }
    out->valid|=XE_NP_SENSOR_VALID_AG;out->imu_sequence++;out->imu_tick_ms=now;
    if(status&0x20U) {
        uint8_t mag[8];struct bmm150_mag_data value;
        int16_t x=(int16_t)((int16_t)(int8_t)p[1]*32+(p[0]>>3));
        int16_t y=(int16_t)((int16_t)(int8_t)p[3]*32+(p[2]>>3));
        int16_t z=(int16_t)((int16_t)(int8_t)p[5]*128+(p[4]>>1));
        uint16_t hall=(uint16_t)(((uint16_t)p[7]<<6)|(p[6]>>2));
        memcpy(mag,p,8); /* Bosch API modifies its input; never touch raw bytes. */
        out->valid&=~XE_NP_SENSOR_VALID_MAG;
        if(s->mag_calibrated && hall && x!=-4096 && y!=-4096 && z!=-16384 &&
           bmm150_aux_mag_data(mag,&value,&s->magnetometer)==BMM150_OK &&
           isfinite(value.x)&&isfinite(value.y)&&isfinite(value.z)&&
           fabsf(value.x)<10000.0f&&fabsf(value.y)<10000.0f&&fabsf(value.z)<10000.0f) {
            out->mag_nano_tesla[0]=(int32_t)(value.x*1000.0f);
            out->mag_nano_tesla[1]=(int32_t)(value.y*1000.0f);
            out->mag_nano_tesla[2]=(int32_t)(value.z*1000.0f);
            out->mag_sequence++;out->mag_tick_ms=now;out->valid|=XE_NP_SENSOR_VALID_MAG;
        } else out->invalid_mag_samples++;
    }
    return 0;
}
static void fail(XE_NP_Sensors *s,uint8_t bus,uint32_t error,uint32_t now)
{
    XE_NP_SensorDevice *d=&s->device[bus];
    s->io.stop(s->io.context,bus);d->pending=0;d->completion=0;d->token++;
    d->state=FAILED;d->configured=0;d->next_due=now+RETRY_MS;
    s->snapshot.error[bus]=error;
    s->snapshot.valid&=bus==0?~(XE_NP_SENSOR_VALID_AG|XE_NP_SENSOR_VALID_MAG):~XE_NP_SENSOR_VALID_ENV;
    if(error==XE_NP_SENSOR_ERR_TIMEOUT)s->snapshot.timeouts[bus]++;
    if(error==XE_NP_SENSOR_ERR_IO||error==XE_NP_SENSOR_ERR_BUSY)s->snapshot.io_errors[bus]++;
}
static void begin(XE_NP_Sensors *s,uint8_t bus,uint8_t reg,uint8_t length,uint8_t write,uint8_t value,uint32_t now)
{
    XE_NP_SensorDevice *d=&s->device[bus];int result;
    if(write)d->data[0]=value;
    d->token++;d->deadline=now+IO_DEADLINE_MS;d->completion=0;d->pending=1;
    result=s->io.start(s->io.context,bus,d->address,reg,d->data,length,write,d->token);
    if(result!=0)fail(s,bus,result>0?XE_NP_SENSOR_ERR_BUSY:XE_NP_SENSOR_ERR_IO,now);
}
void XE_NP_Sensors_Complete(XE_NP_Sensors *s,uint8_t bus,uint32_t token,uint32_t error,uint32_t now)
{
    XE_NP_SensorDevice *d;
    if(!s||bus>=2)return;
    d=&s->device[bus];
    if(!d->pending||token!=d->token||d->completion) { s->snapshot.ignored_completions++;return; }
    d->completed_token=token;d->completion_error=error;d->completion_tick=now;
    d->completion=1; /* Last store; target adapter supplies a memory barrier. */
}
void XE_NP_Sensors_Init(XE_NP_Sensors *s,const XE_NP_SensorIo *io,uint32_t enabled,uint32_t now)
{
    if(!s||!io||!io->start||!io->stop||!io->recover)return;
    memset(s,0,sizeof(*s));s->io=*io;
    s->snapshot.magic=0x31534e53UL;s->snapshot.version=1;s->snapshot.enabled=enabled&3U;
    s->magnetometer.read=no_read;s->magnetometer.write=no_write;s->magnetometer.delay_us=no_delay;
    s->magnetometer.intf_ptr=s;
    for(uint8_t i=0;i<2;i++) {
        XE_NP_SensorDevice *d=&s->device[i];d->enabled=(uint8_t)((enabled>>i)&1U);
        d->state=d->enabled?IDENTIFY:OFF;d->next_due=now+20U;d->address=i?0x76U:0x68U;
        s->snapshot.error[i]=d->enabled?0:XE_NP_SENSOR_ERR_DISABLED;
    }
}
static void completed(XE_NP_Sensors *s,uint8_t bus,uint32_t now)
{
    XE_NP_SensorDevice *d=&s->device[bus];const SensorStep *step;
    d->next_due=now;
    switch(d->state) {
    case IDENTIFY:
        s->snapshot.chip_id[bus]=d->data[0];
        if(d->data[0]!=(bus?BME_ID:BMX_ID)) { fail(s,bus,XE_NP_SENSOR_ERR_ID,now);return; }
        d->state=RESET_SENSOR;break;
    case RESET_SENSOR:
        d->step=0;d->state=bus?BME_NVM:CONFIGURE;d->next_due=now+(bus?3U:20U);
        d->phase_deadline=now+100U;if(!bus)s->have_sensor_time=0;break;
    case CONFIGURE:
        step=&bmx_steps[d->step];
        if(step->action==EXPECT_PMU && (d->data[0]&0x3fU)!=step->value) {
            if(!reached(now,d->phase_deadline)) { d->next_due=now+1U;return; }
            fail(s,bus,XE_NP_SENSOR_ERR_CONFIG,now);return;
        }
        if(step->action==EXPECT_REG && d->data[0]!=step->value) {
            /* The first autonomous MAG read can precede a completed conversion.
             * Give the exact MAG-only startup flag a bounded settling interval,
             * as on V1. Combined command/I2C/configuration errors stay fatal. */
            if(step->reg==0x02U && d->data[0]==0x80U && !reached(now,d->phase_deadline)) {
                d->next_due=now+40U;return;
            }
            /* Bosch BMX160 ERR_REG bit7 is mag_drdy_err. Only this exact
             * MAG-only error permits six-axis fallback; combined bits fail. */
            if(step->reg==0x02U && d->data[0]==0x80U)mag_unavailable(s,now);
            else fail(s,bus,XE_NP_SENSOR_ERR_CONFIG,now);
            return;
        }
        if(step->action==MAG_TRIM1)memcpy(d->calibration,d->data,2);
        if(step->action==MAG_TRIM2)memcpy(d->calibration+2,d->data,4);
        if(step->action==MAG_TRIM3)memcpy(d->calibration+6,d->data,8);
        if(step->action==MAG_TRIM4) {
            memcpy(d->calibration+14,d->data,2);
            if(parse_mag_trim(s)!=0) { fail(s,bus,XE_NP_SENSOR_ERR_CALIBRATION,now);return; }
        }
        if(step->action==VERIFY_CONFIG) {
            static const uint8_t expected[5]={0x29,0x08,0x29,0x00,XE_NP_SENSOR_MAG_ODR};
            if(memcmp(d->data,expected,5)!=0) { fail(s,bus,XE_NP_SENSOR_ERR_CONFIG,now);return; }
        }
        d->next_due=now+step->wait_ms;d->phase_deadline=now+100U;
        if(++d->step==sizeof(bmx_steps)/sizeof(bmx_steps[0])) { d->configured=1;d->state=POLL_STATUS;s->snapshot.error[bus]=0; }
        else if(step->action==WRITE_REG && (step->reg==0x4dU || step->reg==0x4eU)) {
            /* Host I2C completion is not completion of the internal MAG access.
             * Bosch DS 2.4.3.1.1 requires STATUS.mag_man_op to clear first. */
            d->state=AUX_WAIT;
        }
        break;
    case AUX_WAIT:
        if(d->data[0]&4U) {
            if(reached(now,d->phase_deadline))fail(s,bus,XE_NP_SENSOR_ERR_TIMEOUT,now);
            else d->next_due=now+1U;
        } else d->state=CONFIGURE;
        break;
    case AG_CONFIG:
        step=&ag_only_steps[d->step];
        if(step->action==EXPECT_PMU && (d->data[0]&0x3fU)!=step->value) {
            if(!reached(now,d->phase_deadline)) { d->next_due=now+1U;return; }
            fail(s,bus,XE_NP_SENSOR_ERR_CONFIG,now);return;
        }
        if(step->action==VERIFY_CONFIG) {
            static const uint8_t expected[4]={0x29,0x08,0x29,0x00};
            /* ACC_CONF/GYR_CONF are full-byte fields; ACC_RANGE[3:0]
             * and GYR_RANGE[2:0] exclude their reserved upper bits. */
            static const uint8_t mask[4]={0xff,0x0f,0xff,0x07};
            for(uint8_t i=0U;i<4U;i++)if((d->data[i]&mask[i])!=(expected[i]&mask[i])) {
                fail(s,bus,XE_NP_SENSOR_ERR_CONFIG,now);return;
            }
        }
        d->next_due=now+step->wait_ms;d->phase_deadline=now+100U;
        if(++d->step==sizeof(ag_only_steps)/sizeof(ag_only_steps[0])) { d->configured=1;d->state=POLL_STATUS; }
        break;
    case POLL_STATUS:
        d->status=d->data[0];
        if(!s->mag_calibrated)d->status=(uint8_t)(d->status&~0x20U);
        if((d->status&0xc0U)==0xc0U)d->state=READ_SAMPLE;
        else d->next_due=now+1U;
        break;
    case READ_SAMPLE:
    {
        if(XE_NP_Sensors_DecodeImu(s,d->data,d->status,now)!=0) {
            fail(s,bus,XE_NP_SENSOR_ERR_SAMPLE,now);return;
        }
        d->state=POLL_STATUS;d->next_due=d->poll_started+5U;break;
    }
    case BME_NVM:
        if(d->data[0]&1U) {
            if(reached(now,d->phase_deadline))fail(s,bus,XE_NP_SENSOR_ERR_TIMEOUT,now);
            else d->next_due=now+2U;
        } else d->state=BME_CAL1;
        break;
    case BME_CAL1:memcpy(d->calibration,d->data,26);d->state=BME_CAL2;break;
    case BME_CAL2:
        if(XE_NP_Sensors_ParseBmeCalibration(d->calibration,d->data,&s->bme_calibration)!=0) {
            fail(s,bus,XE_NP_SENSOR_ERR_CALIBRATION,now);return;
        }
        d->step=0;d->state=BME_CONFIG;break;
    case BME_CONFIG:
        step=&bme_steps[d->step];
        if(step->action==EXPECT_REG && d->data[0]!=step->value) { fail(s,bus,XE_NP_SENSOR_ERR_CONFIG,now);return; }
        if(++d->step==sizeof(bme_steps)/sizeof(bme_steps[0])) {
            d->configured=1;d->state=BME_TRIGGER;s->snapshot.error[bus]=0;
        }
        break;
    case BME_TRIGGER:d->state=BME_MEASURING;d->next_due=now+10U;d->phase_deadline=now+100U;break;
    case BME_MEASURING:
        if(d->data[0]&9U) {
            if(reached(now,d->phase_deadline))fail(s,bus,XE_NP_SENSOR_ERR_TIMEOUT,now);
            else d->next_due=now+2U;
        } else d->state=BME_READ;
        break;
    case BME_READ:
    {
        if(XE_NP_Sensors_DecodeBme(d->data,&s->bme_calibration,&s->snapshot)!=0) { fail(s,bus,XE_NP_SENSOR_ERR_SAMPLE,now);return; }
        s->snapshot.valid|=XE_NP_SENSOR_VALID_ENV;s->snapshot.env_sequence++;s->snapshot.env_tick_ms=now;
        d->state=BME_TRIGGER;d->next_due=d->poll_started+1000U;break;
    }
    default:fail(s,bus,XE_NP_SENSOR_ERR_CONFIG,now);break;
    }
}
void XE_NP_Sensors_Service(XE_NP_Sensors *s,uint32_t now,uint8_t recording)
{
    if(!s)return;
    for(uint8_t bus=0;bus<2;bus++) {
        XE_NP_SensorDevice *d=&s->device[bus];const SensorStep *step;
        if(!d->enabled)continue;
        if(d->pending) {
            if(d->completion) {
                uint32_t error=d->completion_error,tick=d->completion_tick;
                d->pending=0;d->completion=0;
                if(error) { fail(s,bus,XE_NP_SENSOR_ERR_IO,now);continue; }
                if(reached(tick,d->deadline)) { fail(s,bus,XE_NP_SENSOR_ERR_TIMEOUT,now);continue; }
                completed(s,bus,tick);
            } else if(reached(now,d->deadline)) { fail(s,bus,XE_NP_SENSOR_ERR_TIMEOUT,now);continue; }
            else continue;
        }
        /* Retire an idle-admitted transfer above, but do not advance partial
         * reset/configuration or recovery during NP preparation/capture. */
        if(recording && (!d->configured || d->state==AG_CONFIG))continue;
        if(!reached(now,d->next_due))continue;
#if XE_NP_IMAGE_ROLE == XE_NP_IMAGE_SD_APP
        /* Sparse idle snapshots leave sensor conversions/ODRs unchanged.
         * Recording bypasses this gate; pending I/O retires above first. */
        if(!recording && !bus && d->configured && d->state==POLL_STATUS &&
           !reached(now,d->poll_started+40U))continue;
#endif
        if(d->state==FAILED) {
            if(recording)continue; /* No resets/reinitialization during recording. */
            d->next_due=now+RETRY_MS;
            if(s->io.recover(s->io.context,bus)!=0)continue;
            if(s->snapshot.error[bus]==XE_NP_SENSOR_ERR_IO || s->snapshot.error[bus]==XE_NP_SENSOR_ERR_ID)
                d->address^=1U; /* bounded alternate-address probe on next idle retry */
            d->state=IDENTIFY;d->step=0;if(!bus)s->mag_calibrated=0;
        }
        switch(d->state) {
        case IDENTIFY:begin(s,bus,bus?0xd0:0x00,1,0,0,now);break;
        case RESET_SENSOR:begin(s,bus,bus?0xe0:0x7e,1,1,0xb6,now);break;
        case CONFIGURE:step=&bmx_steps[d->step];begin(s,bus,step->reg,step->length,step->action==WRITE_REG,step->value,now);break;
        case AG_CONFIG:step=&ag_only_steps[d->step];begin(s,bus,step->reg,step->length,step->action==WRITE_REG,step->value,now);break;
        case AUX_WAIT:begin(s,bus,0x1b,1,0,0,now);break;
        case POLL_STATUS:d->poll_started=now;begin(s,bus,0x1b,1,0,0,now);break;
        case READ_SAMPLE:begin(s,bus,0x04,23,0,0,now);break;
        case BME_NVM:case BME_MEASURING:begin(s,bus,0xf3,1,0,0,now);break;
        case BME_CAL1:begin(s,bus,0x88,26,0,0,now);break;
        case BME_CAL2:begin(s,bus,0xe1,7,0,0,now);break;
        case BME_CONFIG:step=&bme_steps[d->step];begin(s,bus,step->reg,step->length,step->action==WRITE_REG,step->value,now);break;
        case BME_TRIGGER:d->poll_started=now;begin(s,bus,0xf4,1,1,0x25,now);break;
        case BME_READ:begin(s,bus,0xf7,8,0,0,now);break;
        default:break;
        }
    }
}
void XE_NP_Sensors_Snapshot(const XE_NP_Sensors *s,XE_NP_SensorSnapshot *out,uint32_t now)
{
    if(!s||!out)return;
    *out=s->snapshot;XE_NP_Sensors_RefreshValidity(out,now);
}
void XE_NP_Sensors_RefreshValidity(XE_NP_SensorSnapshot *out,uint32_t now)
{
    if(!out)return;
    out->published_ms=now;
    if(!out->imu_sequence || (uint32_t)(now-out->imu_tick_ms)>100U)out->valid&=~XE_NP_SENSOR_VALID_AG;
    if(!out->mag_sequence || (uint32_t)(now-out->mag_tick_ms)>200U)out->valid&=~XE_NP_SENSOR_VALID_MAG;
    if(!out->env_sequence || (uint32_t)(now-out->env_tick_ms)>3000U)out->valid&=~XE_NP_SENSOR_VALID_ENV;
}
