"""Native actual-source APP idle cadence; recording/USB retain 5 ms polling."""
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
VC = Path("C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat")

NATIVE = r"""
#include <assert.h>
#include <stdio.h>
#include "xe_np_sensors.c"

typedef struct {
    XE_NP_Sensors sensors;
    uint32_t now,starts[2],writes[2],stops[2],recoveries[2];
    uint32_t polls[256],poll_count,env_starts[4],env_count;
} Model;

static void model_put20(uint8_t *p,uint32_t value)
{ p[0]=(uint8_t)(value>>12);p[1]=(uint8_t)(value>>4);p[2]=(uint8_t)(value<<4); }
static void model_raw(Model *m,uint8_t *p)
{
    uint32_t time=(uint32_t)((uint64_t)m->now*128U/5U)&0xffffffU;
    memset(p,0,23);p[20]=(uint8_t)time;p[21]=(uint8_t)(time>>8);p[22]=(uint8_t)(time>>16);
}
static int model_start(void *context,uint8_t bus,uint8_t address,uint8_t reg,
                       uint8_t *data,uint16_t length,uint8_t write,uint32_t token)
{
    Model *m=context;
    assert(bus<2U && address==(bus?0x76U:0x68U) && length && token);
    m->starts[bus]++;m->writes[bus]+=write!=0U;
    if(!bus && reg==0x1bU){
        assert(!write && length==1U && m->poll_count<256U);
        m->polls[m->poll_count++]=m->now;data[0]=0xc0U;
    }else if(!bus && reg==0x04U){
        assert(!write && length==23U);model_raw(m,data);
    }else if(!bus && reg==0x00U)data[0]=0xd8U;
    else if(bus && reg==0xf4U){
        assert(write && data[0]==0x25U && m->env_count<4U);
        m->env_starts[m->env_count++]=m->now;
    }else if(bus && reg==0xf3U)data[0]=0U;
    else if(bus && reg==0xf7U){
        model_put20(data,415148U);model_put20(data+3,519888U);data[6]=0x75U;data[7]=0x30U;
    }
    return 0;
}
static void model_stop(void *context,uint8_t bus)
{ Model *m=context;m->stops[bus]++; }
static int model_recover(void *context,uint8_t bus)
{ Model *m=context;m->recoveries[bus]++;return 0; }
static void model_fresh(Model *m,uint32_t enabled)
{
    XE_NP_SensorIo io={m,model_start,model_stop,model_recover};
    memset(m,0,sizeof(*m));XE_NP_Sensors_Init(&m->sensors,&io,enabled,0U);
}
static void model_configured(Model *m)
{
    model_fresh(m,1U);m->sensors.device[0].configured=1U;
    m->sensors.device[0].state=POLL_STATUS;m->sensors.device[0].next_due=5U;
}
static void model_service(Model *m,uint32_t now,uint8_t recording)
{ m->now=now;XE_NP_Sensors_Service(&m->sensors,now,recording); }
static void model_run(Model *m,uint32_t milliseconds,uint8_t recording)
{
    while(milliseconds--){
        for(uint8_t bus=0U;bus<2U;bus++){
            XE_NP_SensorDevice *d=&m->sensors.device[bus];
            if(d->pending && !d->completion)
                XE_NP_Sensors_Complete(&m->sensors,bus,d->token,0U,m->now);
        }
        model_service(m,m->now,recording);m->now++;
    }
}
static void model_pending(Model *m,uint8_t state,uint32_t tick)
{
    model_configured(m);m->sensors.device[0].state=state;
    m->sensors.device[0].poll_started=100U;m->sensors.device[0].next_due=100U;
    m->sensors.device[0].pending=1U;m->sensors.device[0].token=7U;
    m->sensors.device[0].deadline=120U;m->now=tick;
}
static void cadence(void)
{
    Model m;XE_NP_SensorSnapshot out;
    const uint32_t idle=XE_NP_IMAGE_ROLE==XE_NP_IMAGE_SD_APP?40U:5U;
    model_configured(&m);m.now=idle;model_run(&m,1000U,0U);
    assert(m.poll_count==1000U/idle && !m.writes[0]);
    for(uint32_t i=0U;i<m.poll_count;i++)assert(m.polls[i]==idle*(i+1U));
    XE_NP_Sensors_Snapshot(&m.sensors,&out,m.now);
    assert(out.valid==XE_NP_SENSOR_VALID_AG && !out.error[0] && !out.timeouts[0]);
    /* Intentional sparse idle reads may increase the unchanged conversion-gap
     * estimator; this is not an archived recording-grid loss counter. */
    assert((out.missed_imu_samples!=0U)==(idle==40U));
    model_configured(&m);m.now=5U;model_run(&m,1000U,1U);
    assert(m.poll_count==200U && !m.writes[0]);
    for(uint32_t i=0U;i<m.poll_count;i++)assert(m.polls[i]==5U*(i+1U));
    assert(!m.sensors.snapshot.missed_imu_samples);
}
static void edges_and_completion(void)
{
    Model m;XE_NP_SensorDevice *d;
    model_configured(&m);d=&m.sensors.device[0];d->poll_started=100U;d->next_due=105U;
    model_service(&m,101U,0U);model_service(&m,104U,1U);assert(!m.poll_count);
    model_service(&m,105U,1U);assert(m.poll_count==1U && m.polls[0]==105U);
    /* A completed final idle sample retires before any new polling admission. */
    model_pending(&m,READ_SAMPLE,102U);d=&m.sensors.device[0];model_raw(&m,d->data);
    XE_NP_Sensors_Complete(&m.sensors,0U,d->token,0U,102U);
    model_service(&m,102U,0U);
    assert(!d->pending && !d->completion && m.sensors.snapshot.imu_sequence==1U);
    assert(d->next_due==105U && !m.starts[0]);
#if XE_NP_IMAGE_ROLE == XE_NP_IMAGE_SD_APP
    model_service(&m,110U,0U);assert(!m.starts[0]);
    model_service(&m,111U,1U);assert(m.poll_count==1U && m.polls[0]==111U);
#else
    model_service(&m,105U,0U);assert(m.poll_count==1U && m.polls[0]==105U);
#endif
    /* Status completion must admit its data read immediately even while idle. */
    model_pending(&m,POLL_STATUS,102U);d=&m.sensors.device[0];d->data[0]=0xc0U;
    XE_NP_Sensors_Complete(&m.sensors,0U,d->token,0U,102U);
    model_service(&m,102U,0U);
    assert(d->pending && !d->completion && d->state==READ_SAMPLE && m.starts[0]==1U);
    m.now=103U;model_run(&m,1U,1U);assert(m.sensors.snapshot.imu_sequence==1U);
    model_pending(&m,POLL_STATUS,120U);model_service(&m,120U,0U);
    assert(!m.sensors.device[0].pending && m.sensors.snapshot.timeouts[0]==1U);
    assert(m.stops[0]==1U && !m.recoveries[0]);
}
static void setup_recovery_and_wrap(void)
{
    Model m;XE_NP_SensorDevice *d;
    model_fresh(&m,1U);model_service(&m,19U,0U);assert(!m.starts[0]);
    model_service(&m,20U,0U);assert(m.starts[0]==1U);
    d=&m.sensors.device[0];XE_NP_Sensors_Complete(&m.sensors,0U,d->token,0U,21U);
    model_service(&m,21U,1U);
    assert(!d->pending && d->state==RESET_SENSOR && m.starts[0]==1U);
    model_service(&m,22U,0U);assert(m.starts[0]==2U && m.writes[0]==1U);
    model_fresh(&m,1U);d=&m.sensors.device[0];d->state=FAILED;d->next_due=100U;
    model_service(&m,100U,1U);assert(!m.recoveries[0] && !m.starts[0]);
    model_service(&m,100U,0U);assert(m.recoveries[0]==1U && m.starts[0]==1U);
    model_configured(&m);d=&m.sensors.device[0];
    d->poll_started=UINT32_MAX-19U;d->next_due=d->poll_started+5U;
#if XE_NP_IMAGE_ROLE == XE_NP_IMAGE_SD_APP
    model_service(&m,UINT32_MAX-10U,0U);model_service(&m,19U,0U);assert(!m.poll_count);
    model_service(&m,20U,0U);assert(m.poll_count==1U && m.polls[0]==20U);
#else
    model_service(&m,UINT32_MAX-10U,0U);assert(m.poll_count==1U);
#endif
}
static void environment_and_validity(void)
{
    static const int32_t coefficients[12]={27504,26435,-1000,36477,-10685,3024,2855,140,-7,15500,-14600,6000};
    Model m;XE_NP_SensorSnapshot out;uint8_t cal[26]={0},hum[7]={0x6a,1,0,20,0x25,3,30};
    model_fresh(&m,2U);
    for(uint32_t i=0U;i<12U;i++){
        cal[2U*i]=(uint8_t)coefficients[i];cal[2U*i+1U]=(uint8_t)((uint32_t)coefficients[i]>>8);
    }
    cal[25]=75U;
    assert(!XE_NP_Sensors_ParseBmeCalibration(cal,hum,&m.sensors.bme_calibration));
    m.sensors.device[1].configured=1U;m.sensors.device[1].state=BME_TRIGGER;
    m.sensors.device[1].next_due=0U;model_run(&m,2100U,0U);
    assert(m.env_count==3U && m.env_starts[0]==0U && m.env_starts[1]==1000U && m.env_starts[2]==2000U);
    assert(m.sensors.snapshot.env_sequence==3U && m.sensors.snapshot.temperature_centi_c==2508);
    assert(!m.sensors.snapshot.error[1] && !m.starts[0]);
    memset(&out,0,sizeof(out));out.valid=7U;out.imu_sequence=out.mag_sequence=out.env_sequence=1U;
    out.imu_tick_ms=out.mag_tick_ms=out.env_tick_ms=100U;
    XE_NP_Sensors_RefreshValidity(&out,200U);assert(out.valid==7U);
    XE_NP_Sensors_RefreshValidity(&out,201U);assert(out.valid==6U);
    XE_NP_Sensors_RefreshValidity(&out,300U);assert(out.valid==6U);
    XE_NP_Sensors_RefreshValidity(&out,301U);assert(out.valid==4U);
    XE_NP_Sensors_RefreshValidity(&out,3100U);assert(out.valid==4U);
    XE_NP_Sensors_RefreshValidity(&out,3101U);assert(!out.valid);
}
int main(void)
{
    cadence();edges_and_completion();setup_recovery_and_wrap();environment_and_validity();
    printf("PASS actual sensor role %u: idle %u ms; active 5 ms; completion, edges, setup/recovery, wrap, BME, validity\n",
           (unsigned)XE_NP_IMAGE_ROLE,XE_NP_IMAGE_ROLE==XE_NP_IMAGE_SD_APP?40U:5U);
    return 0;
}
"""


def main():
    with tempfile.TemporaryDirectory(prefix="sd-idle-sensors-") as temporary:
        folder = Path(temporary)
        native = folder / "native.c"
        native.write_text(NATIVE, encoding="ascii")
        for role in (1, 2):
            out = folder / str(role)
            out.mkdir()
            sources = [
                native,
                ROOT / "Core/Src/xe_np_bme_compensation.c",
                ROOT / "Core/Src/xe_np_bmm_compensation.c",
            ]
            command = (
                f'call "{VC}" >nul && cl /nologo /std:c11 /W4 /WX /TC /O2 '
                f'/DXE_NP_IMAGE_ROLE={role}U /I"{ROOT / "Core/Inc"}" '
                f'/I"{ROOT / "Core/Src"}" '
                + " ".join(f'"{source}"' for source in sources)
                + f' /Fo"{out}/" /Fe"{out / "native.exe"}"'
            )
            built = subprocess.run(
                f'cmd /d /s /c "{command}"', cwd=out, capture_output=True,
                text=True, timeout=60,
            )
            assert built.returncode == 0, built.stdout + built.stderr
            tested = subprocess.run(
                [str(out / "native.exe")], cwd=out, capture_output=True,
                text=True, timeout=10,
            )
            assert tested.returncode == 0, tested.stdout + tested.stderr
            print(tested.stdout.strip())


if __name__ == "__main__":
    main()
