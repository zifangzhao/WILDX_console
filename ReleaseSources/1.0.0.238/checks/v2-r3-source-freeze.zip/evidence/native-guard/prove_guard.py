"""Compile the actual isolated retained-grid admission, without hardware."""
from pathlib import Path
import hashlib,json,subprocess
T=Path(__file__).resolve().parents[1]
O=Path(__file__).resolve().parent
S=T/'Core/Src/xe_np_usb_aux.inc'
def sha(b):return hashlib.sha256(b).hexdigest().upper()
src=S.read_text()
sig='static int xe_np_aux_grid_try_retained(void)'
a=src.index(sig);b=src.index('{',a);n=1;e=b+1
while n:
    n+=(src[e]=='{')-(src[e]=='}');e+=1
body=src[a:e]+'\n'
(O/'actual_guard.inc').write_text(body)
cmd='call "C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat" >nul && cl /nologo /std:c++17 /W4 /WX /EHsc /O2 /TP fixture.cpp /Fe:guard.exe >compile.log 2>&1'
r=subprocess.run('cmd /d /s /c "'+cmd+'"',cwd=O,capture_output=True,text=True)
assert r.returncode==0,(r.stdout,r.stderr,(O/'compile.log').read_text() if (O/'compile.log').exists() else 'no compiler log')
r=subprocess.run([str(O/'guard.exe')],cwd=O,capture_output=True,text=True)
(O/'result.txt').write_text(r.stdout+r.stderr)
assert r.returncode==0,r.stdout+r.stderr
receipt=dict(status='PASS',hardware_access=False,source=str(S),source_sha256=sha(S.read_bytes()),
             function_sha256=sha(body.encode()),fixture_sha256=sha((O/'fixture.cpp').read_bytes()),
             compiler_command=cmd,result=r.stdout,
             scope='Exact retained admission function. Fake coherent USB/producer/fine-clock inputs, all admission boundaries, races, wrap and bounded never-empty NP queue simulation. Not a hardware latency proof.',
             profile_constants=dict(slots=22,ring_bytes=737280,node_bytes=61440,retention=675840,unpublished=92160,reserve=65536))
(O/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
