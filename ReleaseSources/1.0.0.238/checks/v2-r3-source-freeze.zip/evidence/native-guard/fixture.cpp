#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <limits.h>
#include <assert.h>
enum {NP2_USB_CAPTURING=3, XE_NP_USB_AUX_IMU=4, XE_NP_NP2_PRODUCER_ACTIVE=1};
#define XE_NP_NP2_USB_SLOTS 22U
#define XE_NP_NP2_RETENTION_LIMIT 675840U
#define XE_NP_NP2_UNPUBLISHED_BOUND 92160U
typedef struct {uint32_t state,error,borrowed,source_bytes_per_tick;uint64_t produced,consumed;} XE_NP_Np2Producer;
typedef struct {uint64_t counter;uint32_t domain,counter_hz,ms,generation,source_epoch;} XE_NP_Np2SdFinePoint64;
static struct {uint32_t state,probe_mask,sample_hz,cancel,target,filled,submitted,completed,active,tx_segment;} np2_usb;
static struct {uint32_t flags,tx_active,stop_requested,fault_pending,interrupted,tx_abort_pending;} xe_np_aux;
static struct {uint32_t outstanding;} xe_np_aux_grid;
static uint32_t xe_np_grid_retained_tick,xe_np_grid_retained_tick_valid;
static volatile uint32_t xe_np_grid_retained_diag[8];
static XE_NP_Np2Producer producer;
static XE_NP_Np2SdFinePoint64 fine[2];
static uint32_t tick,ready,reads,failread,primask,irq_depth,mutate;
static unsigned checks;
static uint32_t HAL_GetTick(void){return tick;}
static uint32_t __get_PRIMASK(void){return primask;}
static void __disable_irq(void){primask=1;irq_depth++;}
static void __set_PRIMASK(uint32_t key){assert(irq_depth);irq_depth--;primask=key;}
static int XE_NP_Np2FirstSyncRuntime_GridNeedsPoll(void){return (int)ready;}
static void XE_NP_Np2CapturePort_Diagnostics(XE_NP_Np2Producer *p){assert(primask);*p=producer;}
static int XE_NP_Np2SdFineClock_Read64(XE_NP_Np2SdFinePoint64 *p){
    reads++;if(reads==failread)return 0;*p=fine[reads==1?0:1];
    if(reads==2){
        switch(mutate){
        case 1:np2_usb.state++;break;case 2:np2_usb.active=0;break;
        case 3:np2_usb.filled++;break;case 4:np2_usb.submitted++;break;
        case 5:np2_usb.completed++;break;case 6:np2_usb.tx_segment++;break;
        case 7:np2_usb.cancel=1;break;case 8:np2_usb.target=1;break;
        case 9:xe_np_aux.stop_requested=1;break;case 10:xe_np_aux.fault_pending=1;break;
        case 11:xe_np_aux.interrupted=1;break;case 12:xe_np_aux.tx_abort_pending=1;break;
        case 13:xe_np_aux.tx_active=1;break;case 14:xe_np_aux_grid.outstanding=1;break;
        default:break;
        }
    }
    return 1;
}
#include "actual_guard.inc"
#define CHECK(x) do{checks++;assert(x);}while(0)
static void reset(void){
    memset(&np2_usb,0,sizeof(np2_usb));memset(&xe_np_aux,0,sizeof(xe_np_aux));
    memset(&xe_np_aux_grid,0,sizeof(xe_np_aux_grid));memset((void*)xe_np_grid_retained_diag,0,sizeof(xe_np_grid_retained_diag));
    memset(&producer,0,sizeof(producer));memset(fine,0,sizeof(fine));
    np2_usb.state=NP2_USB_CAPTURING;np2_usb.probe_mask=7;np2_usb.sample_hz=20000;
    np2_usb.filled=4;np2_usb.submitted=2;np2_usb.completed=1;np2_usb.active=1;np2_usb.tx_segment=2;
    xe_np_aux.flags=XE_NP_USB_AUX_IMU;
    producer.state=XE_NP_NP2_PRODUCER_ACTIVE;producer.source_bytes_per_tick=1;producer.produced=10000;producer.consumed=5000;
    fine[0].counter=100000;fine[0].domain=3;fine[0].counter_hz=1000000;fine[0].generation=9;fine[0].source_epoch=11;
    fine[1]=fine[0];fine[1].counter+=10;
    tick=100;ready=1;reads=failread=primask=irq_depth=mutate=0;
    xe_np_grid_retained_tick=xe_np_grid_retained_tick_valid=0;
}
static void reject(void){CHECK(xe_np_aux_grid_try_retained()==0);CHECK(irq_depth==0);}
int main(void){
    reset();CHECK(xe_np_aux_grid_try_retained()==1);CHECK(primask==0&&irq_depth==0);CHECK(xe_np_grid_retained_diag[3]==1);
    CHECK(xe_np_aux_grid_try_retained()==0);tick++;reads=0;CHECK(xe_np_aux_grid_try_retained()==1);
    reset();primask=1;CHECK(xe_np_aux_grid_try_retained()==1);CHECK(primask==1&&irq_depth==0);
    for(uint32_t i=0;i<15;i++){reset();switch(i){
      case 0:np2_usb.state++;break;case 1:np2_usb.probe_mask=3;break;case 2:np2_usb.sample_hz=15000;break;
      case 3:xe_np_aux.flags=5;break;case 4:xe_np_aux.flags=6;break;case 5:xe_np_aux.flags=0;break;
      case 6:xe_np_aux.tx_active=1;break;case 7:xe_np_aux_grid.outstanding=1;break;
      case 8:np2_usb.cancel=1;break;case 9:np2_usb.target=1;break;case 10:xe_np_aux.stop_requested=1;break;
      case 11:xe_np_aux.fault_pending=1;break;case 12:xe_np_aux.interrupted=1;break;case 13:xe_np_aux.tx_abort_pending=1;break;
      default:ready=0;break;}reject();CHECK(reads==0);}
    for(uint32_t i=0;i<5;i++){reset();switch(i){case 0:failread=1;break;case 1:fine[0].counter_hz=999999;break;
      case 2:fine[0].domain=0;break;case 3:fine[0].generation=0;break;default:fine[0].source_epoch=0;break;}reject();}
    for(uint32_t i=0;i<10;i++){reset();switch(i){case 0:producer.state++;break;case 1:producer.error=1;break;
      case 2:producer.borrowed=1;break;case 3:producer.source_bytes_per_tick=3;break;case 4:producer.produced=4999;break;
      case 5:np2_usb.active=0;break;case 6:np2_usb.submitted=3;break;case 7:np2_usb.filled=22;break;
      case 8:np2_usb.submitted=0;break;default:producer.produced=producer.consumed+518144;break;}reject();}
    reset();producer.produced=producer.consumed+518143;CHECK(xe_np_aux_grid_try_retained()==1);
    reset();np2_usb.filled=21;CHECK(xe_np_aux_grid_try_retained()==1); /* exactly two free slots */
    for(uint32_t i=0;i<8;i++){reset();switch(i){case 0:failread=2;break;case 1:fine[1].counter_hz=1;break;
      case 2:fine[1].domain++;break;case 3:fine[1].generation++;break;case 4:fine[1].source_epoch++;break;
      case 5:fine[1].counter=fine[0].counter-1;break;case 6:fine[1].counter=fine[0].counter+101;break;
      default:fine[1].counter=0;break;}reject();}
    reset();fine[1].counter=fine[0].counter+100;CHECK(xe_np_aux_grid_try_retained()==1);
    for(uint32_t i=1;i<=14;i++){reset();mutate=i;reject();}
    reset();tick=UINT32_MAX;CHECK(xe_np_aux_grid_try_retained()==1);tick=0;reads=0;CHECK(xe_np_aux_grid_try_retained()==1);
    reset();np2_usb.completed=UINT32_MAX;np2_usb.submitted=0;np2_usb.filled=2;CHECK(xe_np_aux_grid_try_retained()==1);
    /* Native queue model only: NP is continuously nonempty. New admission can
       release ready32-row batches; old NP-empty-only policy never takes one. */
    reset();uint32_t oldq=0,newq=0,oldlost=0,newlost=0,maxq=0,takes=0;
    for(uint32_t ms=0;ms<8192;ms++){
      uint32_t added=(ms%4==3)?2U:1U;
      oldq+=added;newq+=added;if(oldq>256){oldlost+=oldq-256;oldq=256;}
      if(newq>256){newlost+=newq-256;newq=256;}if(newq>maxq)maxq=newq;
      tick=ms;reads=0;ready=newq>=32;
      if(xe_np_aux_grid_try_retained()){uint32_t n=newq<64?newq:64;newq-=n;takes++;}
    }
    CHECK(oldlost>256&&newlost==0&&takes>256&&maxq<=33);
    printf("PASS %u checks; never-empty model oldlost=%u newlost=%u takes=%u maxqueue=%u\n",checks,oldlost,newlost,takes,maxq);
    return 0;
}
