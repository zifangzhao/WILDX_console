param(
 [string]$Source='C:/Frank/Code/XE_NP/_artifacts/v2_usb_imu100_20261105/Core/Src/xe_np_usb_aux.inc',
 [string]$ExpectedSha='C91046AD355EBCF7CA5CD5C30648616352C8709B55AFDDD780A04326469D73A2'
)
$ErrorActionPreference='Stop'
function Hash($p){(Get-FileHash -LiteralPath $p).Hash}
if((Hash $Source) -cne $ExpectedSha){throw 'Owner-pinned source changed'}
$s=[IO.File]::ReadAllText($Source)
function FunctionText($name){
 $m=[regex]::Match($s,('(?m)^(?:static\s+)?(?:void|int|uint32_t|uint64_t)\s+'+[regex]::Escape($name)+'\s*\([^;{}]*\)\s*\{'))
 if(!$m.Success){throw ('Missing actual function '+$name)}
 $brace=$s.IndexOf('{',$m.Index);$depth=0
 for($i=$brace;$i -lt $s.Length;$i++){if($s[$i] -eq '{'){$depth++};if($s[$i] -eq '}'){$depth--};if(!$depth){return $s.Substring($m.Index,$i-$m.Index+1)}}
 throw 'Unbalanced actual function'
}
function Block($start,$end){$a=$s.IndexOf($start);if($a -lt 0){throw ('Missing actual block '+$start)};$b=$s.IndexOf($end,$a);if($b -lt 0){throw 'Missing block end'};$s.Substring($a,$b-$a+$end.Length)}
$names=@('XE_NP_UsbAux_BindGrid','xe_np_aux_grid_complete','xe_np_aux_put32','xe_np_aux_put64','xe_np_aux_error','xe_np_aux_latch_fault','xe_np_aux_header','xe_np_aux_send','xe_np_aux_begin','xe_np_aux_abort_endpoint','xe_np_aux_grid_u32','xe_np_aux_grid_u64','xe_np_aux_grid_body_valid','xe_np_aux_schedule_grid','xe_np_aux_retire_tx','XE_NP_UsbAux_Complete','XE_NP_UsbAux_IsBusy','xe_np_aux_schedule_fair','xe_np_aux_service_abort','xe_np_aux_timeout')
$routines=($names|ForEach-Object {FunctionText $_}) -join "`n"
$guardBody=(FunctionText 'xe_np_aux_grid_try_retained').Replace("`r`n","`n")+"`n"
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'actual-guard-reused.inc'),$guardBody,[Text.UTF8Encoding]::new($false))
if((Hash (Join-Path $PSScriptRoot 'actual-guard-reused.inc')) -cne '688201F731317F4ADB1B9E59CEA6EF2B24954B2229D27D5436535AFF4FF73DB5'){throw 'Original133-check guard function changed; cannot reuse its receipt'}
$f=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'fixture.cpp.in'))
$f=$f.Replace('/*ENUM*/',(Block 'enum {' '};'))
$f=$f.Replace('/*TX*/',(Block "typedef struct {`n    uint8_t header[XE_NP_AUX_HEADER_BYTES];" 'static XE_NP_AuxTxBuffers xe_np_aux_tx __attribute__((section("NP_AUX_TX"),aligned(32)));'))
$f=$f.Replace('/*STATE*/',(Block "typedef struct {`n    PCD_HandleTypeDef *pcd;" '} XE_NP_UsbAux;'))
$f=$f.Replace('/*GRID*/',(Block "static struct {`n    XE_NP_UsbAuxGridNext" '} xe_np_aux_grid;')).Replace('/*FUNCTIONS*/',$routines)
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'actual-functions.inc'),$routines,[Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'fixture.cpp'),$f,[Text.UTF8Encoding]::new($false))
$cmd='@echo off'+"`r`n"+'call "C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat" >nul && cl /nologo /std:c++17 /W4 /WX /wd4505 /wd4127 /EHsc /O2 /TP fixture.cpp /Fe:fixture.exe >compile.log 2>&1'+"`r`n"+'exit /b %errorlevel%'+"`r`n"
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'build.cmd'),$cmd,[Text.UTF8Encoding]::new($false))
$p=Start-Process -FilePath 'cmd.exe' -ArgumentList @('/d','/c',(Join-Path $PSScriptRoot 'build.cmd')) -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -Wait -PassThru
if($p.ExitCode){Get-Content -LiteralPath (Join-Path $PSScriptRoot 'compile.log');throw ('Native fixture compile exit '+$p.ExitCode)}
$out=& (Join-Path $PSScriptRoot 'fixture.exe') 2>&1
$exit=$LASTEXITCODE
$out|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'result.txt')
if($exit){$out;throw ('Native fixture failed '+$exit)}
if((Hash $Source) -cne $ExpectedSha){throw 'Source changed during native acceptance'}
$guard=Get-Content -Raw -LiteralPath 'C:/Frank/Code/XE_NP/_artifacts/v2_usb_imu100_20261105/native-guard/receipt.json'|ConvertFrom-Json
[ordered]@{status='PASS';hardware_access=$false;source=$Source;source_sha256=$ExpectedSha;actual_functions_sha256=(Hash (Join-Path $PSScriptRoot 'actual-functions.inc'));fixture_sha256=(Hash (Join-Path $PSScriptRoot 'fixture.cpp'));result=($out -join "`n");functions=$names;guard133_function_hash_verified=$true;guard133_reused=$guard;scope='Actual extracted source functions with mocked HAL/device/provider boundaries; source hash pinned before and after; native bytes/ownership only, no target throughput or timing claim.'}|ConvertTo-Json -Depth 7|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'receipt.json') -Encoding utf8
$out
