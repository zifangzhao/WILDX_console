#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#define __attribute__(x)
#define __DMB() ((void)0)
#define XE_NP_GRID_ENFORCED 1
#define XE_NP_NP2_USB_GRID_EXPERIMENT 0
#define XE_NP_NP2_FIRST_SYNC_ENABLE 0
#define XE_NP_GRID_AUX_COST_DIAG 0
#define XE_NP_GRID_STARTUP_DIAG 0
#define XE_NP_USB_AUX_CAMERA 1U
#define XE_NP_USB_AUX_ADC 2U
#define XE_NP_USB_AUX_IMU 4U
#define XE_NP_USB_AUX_EP 0x82U
#define HAL_OK 0
typedef struct { int unused; } PCD_HandleTypeDef;
typedef int (*XE_NP_UsbAuxGridNext)(void *,uint8_t *,uint32_t,uint32_t *,uint32_t *,uint64_t *,uint32_t);
typedef void (*XE_NP_UsbAuxGridComplete)(void *,uint32_t,uint32_t);
static unsigned checks;
#define CHECK(x) do{checks++;if(!(x)){printf("FAIL line%d: %s\n",__LINE__,#x);exit(2);}}while(0)
enum {
    XE_NP_AUX_OFF=0U, XE_NP_AUX_CONFIGURED=1U, XE_NP_AUX_PREPARING=2U,
    XE_NP_AUX_RUNNING=3U, XE_NP_AUX_DRAINING=4U, XE_NP_AUX_COMPLETE=5U,
    XE_NP_AUX_FAILED=255U,
    XE_NP_AUX_TYPE_CAMERA=1U, XE_NP_AUX_TYPE_ADC=2U,
    XE_NP_AUX_TYPE_IMU=3U, XE_NP_AUX_TYPE_TERMINAL=4U,
    XE_NP_AUX_FORMAT_CAMERA=1U, XE_NP_AUX_FORMAT_ADC=2U,
    XE_NP_AUX_FORMAT_IMU=3U,
    XE_NP_AUX_TYPE_GRID=5U, XE_NP_AUX_TYPE_GRID_PHASE=6U, XE_NP_AUX_TYPE_GRID_END=7U,
    XE_NP_AUX_HEADER_BYTES=64U, XE_NP_AUX_CAMERA_BYTES=320000U,
    XE_NP_AUX_ADC_BYTES=32768U, XE_NP_AUX_STAGING_BYTES=4096U,
    XE_NP_AUX_CAMERA_FRAME_BYTES=160000U,
    XE_NP_AUX_CAMERA_DATA_BYTES=157440U,
    XE_NP_AUX_CAMERA_FRAGMENT_BYTES=32768U,
    XE_NP_AUX_FLAG_CAMERA=1U, XE_NP_AUX_FLAG_ADC=2U,
    XE_NP_AUX_FLAG_IMU=4U, XE_NP_AUX_FLAG_SAFE=256U,
    XE_NP_AUX_FLAG_AV_ONLY=512U,
    XE_NP_AUX_ERROR_REQUEST=1U, XE_NP_AUX_ERROR_PREPARE=2U,
    XE_NP_AUX_ERROR_CAMERA=3U, XE_NP_AUX_ERROR_ADC=4U,
    XE_NP_AUX_ERROR_USB=5U, XE_NP_AUX_ERROR_GAP=6U,
    XE_NP_AUX_ERROR_STOP=7U, XE_NP_AUX_ERROR_INTERRUPTED=8U, XE_NP_AUX_ERROR_GRID=9U
};
typedef struct {
    uint8_t header[XE_NP_AUX_HEADER_BYTES];
    uint8_t staging[XE_NP_AUX_STAGING_BYTES];
    uint8_t status[128U];
} XE_NP_AuxTxBuffers;
typedef char aux_header_staging_contiguous[
    (offsetof(XE_NP_AuxTxBuffers,staging)==XE_NP_AUX_HEADER_BYTES)?1:-1];
static XE_NP_AuxTxBuffers xe_np_aux_tx __attribute__((section("NP_AUX_TX"),aligned(32)));
typedef struct {
    PCD_HandleTypeDef *pcd;
    uint32_t state,error,flags,fps,safe,av_only;
    uint32_t start_pending,stop_requested,prepared,camera_prepared,adc_prepared,sources_stopped,fault_pending;
    volatile uint32_t interrupted,tx_active,completion_token;
    uint32_t tx_phase,tx_type,tx_bytes,tx_offset,tx_total;
    uint32_t tx_sequence,tx_tick,tx_started_ms;
    const uint8_t *tx_direct;
    uint32_t camera_frame_id,camera_frame_tick,camera_frame_offset,camera_frame_total,camera_frame_valid;
    uint64_t adc_cursor,adc_produced,adc_sent,adc_dropped;
    uint32_t camera_completed,camera_sent,camera_dropped,cadence_missed;
    uint32_t imu_sent,usb_records,last_imu_ms,terminal_pending,terminal_sent;
    uint64_t usb_bytes;
    uint32_t start_tick,stop_tick,bus_errors;
    uint8_t fair_next,tx_abort_pending,cleanup_hold;
#if XE_NP_NP2_FIRST_SYNC_ENABLE
    uint32_t first_sync_withheld,first_sync_accepted;
    uint8_t first_sync_mode,first_sync_adc_wait;
#endif
} XE_NP_UsbAux;
static XE_NP_UsbAux xe_np_aux;
static struct {
    XE_NP_UsbAuxGridNext next;
    XE_NP_UsbAuxGridComplete complete;
    void *context;
    uint32_t type;
    uint8_t outstanding,phase_sent,ended;
#if (defined(XE_NP_GRID_POST_PROVIDER_PRIORITY_TEST) && XE_NP_GRID_POST_PROVIDER_PRIORITY_TEST) || \
    (defined(XE_NP_GRID_ENFORCED) && XE_NP_GRID_ENFORCED)
    /* Next owns staging until Complete.  An ordinary NP stop may defer that
     * one accepted record, but never asks the provider to recreate it. */
    uint32_t bytes;
    uint64_t source;
    uint8_t stop_deferred;
#endif
} xe_np_aux_grid;
static volatile uint32_t xe_np_grid_retained_diag[12];
static uint32_t xe_np_grid_retained_tick,xe_np_grid_retained_tick_valid;
static struct {uint32_t configured;} xe_np_usb_state;
enum {NP2_USB_IDLE=0,NP2_USB_CAPTURING=1,NP2_USB_DRAINING=2,NP2_USB_COMPLETE=3,NP2_USB_FAILED=4};
static struct {uint32_t state,cancel;} np2_usb;
static uint32_t np2_usb_aux_opportunity=1U;
static PCD_HandleTypeDef pcd;
static uint32_t sends,aborts,clean_calls,clean_bytes,fail_send,fail_abort,immediate,next_calls,completes,failed,offered=6U,transmits,consumes,retired;
static const uint8_t *last_ptr;
static uint32_t last_len;
static std::vector<uint8_t> wire;
static void xe_np_aux_grid_complete(uint32_t delivered);
static void xe_np_aux_retire_tx(void);
void XE_NP_UsbAux_Complete(void);
uint32_t XE_NP_UsbAux_IsBusy(void);
static uint32_t HAL_GetTick(void){return 10U;}
static void XE_NP_UsbStream_DCacheCleanTx(const uint8_t *,uint32_t n){clean_calls++;clean_bytes+=n;}
static int HAL_PCD_EP_Transmit(PCD_HandleTypeDef *p,uint8_t ep,uint8_t *data,uint32_t n){
 CHECK(p==&pcd&&ep==0x82);sends++;last_ptr=data;last_len=n;
 if(fail_send){fail_send=0;return -1;}wire.insert(wire.end(),data,data+n);
 if(immediate)XE_NP_UsbAux_Complete();return HAL_OK;
}
static int HAL_PCD_EP_Abort(PCD_HandleTypeDef *p,uint8_t ep){CHECK(p==&pcd&&ep==0x82);aborts++;return fail_abort?-1:0;}
static void XE_NP_MediaCamera_ConsumeFrame(void){consumes++;}
static void XE_NP_MediaCamera_Retire(void){retired++;}
static int xe_np_aux_np_capture_active(void){return np2_usb.state==NP2_USB_CAPTURING;}
static int XE_NP_Np2FirstSyncRuntime_GridNeedsPoll(void){return 1;}
static void np2_usb_transmit(void){transmits++;}
static int xe_np_aux_schedule_adc(void){return 0;}
static int xe_np_aux_schedule_imu(uint32_t){return 0;}
static int xe_np_aux_schedule_camera(void){return 0;}
int XE_NP_UsbAux_BindGrid(XE_NP_UsbAuxGridNext next,XE_NP_UsbAuxGridComplete complete,
                          void *context)
{
    if(XE_NP_UsbAux_IsBusy() || xe_np_aux_grid.outstanding ||
       ((next==NULL)!=(complete==NULL)) || (!next && context))return -1;
    memset(&xe_np_aux_grid,0,sizeof(xe_np_aux_grid));
#if XE_NP_GRID_ENFORCED
    if(next){
        memset((void *)xe_np_grid_retained_diag,0,sizeof(xe_np_grid_retained_diag));
        xe_np_grid_retained_diag[0]=0x31465247U;xe_np_grid_retained_diag[1]=1U;
        xe_np_grid_retained_tick=xe_np_grid_retained_tick_valid=0U;
    }
#endif
    xe_np_aux_grid.next=next;xe_np_aux_grid.complete=complete;xe_np_aux_grid.context=context;
    return 0;
}
static void xe_np_aux_grid_complete(uint32_t delivered)
{
    if(!xe_np_aux_grid.outstanding)return;
    uint32_t type=xe_np_aux_grid.type;
    xe_np_aux_grid.outstanding=0U;
#if XE_NP_GRID_STARTUP_DIAG
    if(delivered && type==XE_NP_AUX_TYPE_GRID_PHASE)
        XE_NP_Np2FirstSyncRuntime_GridDiagMark(XE_NP_GRID_DIAG_PHASE_COMPLETED);
    if(delivered && type==XE_NP_AUX_TYPE_GRID)
        XE_NP_Np2FirstSyncRuntime_GridDiagMark(XE_NP_GRID_DIAG_ROW_COMPLETED);
#endif
    if(delivered && type==XE_NP_AUX_TYPE_GRID_PHASE)xe_np_aux_grid.phase_sent=1U;
    if(type==XE_NP_AUX_TYPE_GRID_END || !delivered)xe_np_aux_grid.ended=1U;
    xe_np_aux_grid.complete(xe_np_aux_grid.context,type,delivered);
}
static void xe_np_aux_put32(uint8_t *p,uint32_t v)
{p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);p[2]=(uint8_t)(v>>16);p[3]=(uint8_t)(v>>24);}
static void xe_np_aux_put64(uint8_t *p,uint64_t v)
{xe_np_aux_put32(p,(uint32_t)v);xe_np_aux_put32(p+4U,(uint32_t)(v>>32));}
static void xe_np_aux_error(uint32_t error)
{if(!xe_np_aux.error)xe_np_aux.error=error;}
static void xe_np_aux_latch_fault(uint32_t error)
{
    xe_np_aux_error(error);
    if(!xe_np_aux.fault_pending) {
        if(xe_np_aux.camera_prepared)XE_NP_MediaCamera_Retire();
        xe_np_aux.fault_pending=1U;xe_np_aux.stop_requested=1U;
    }
}
static void xe_np_aux_header(uint32_t type,uint64_t source,uint32_t payload,
    uint32_t offset,uint32_t total,uint32_t hz,uint32_t bits,uint32_t format)
{
    uint8_t *h=xe_np_aux_tx.header;
    memset(h,0,XE_NP_AUX_HEADER_BYTES);memcpy(h,"NPAVUSB1",8U);
    xe_np_aux_put32(h+8U,1U);xe_np_aux_put32(h+12U,type);
    xe_np_aux_put32(h+16U,xe_np_aux.tx_sequence);
    xe_np_aux_put32(h+20U,xe_np_aux.tx_tick);xe_np_aux_put64(h+24U,source);
    xe_np_aux_put32(h+32U,payload);xe_np_aux_put32(h+36U,offset);
    xe_np_aux_put32(h+40U,total);xe_np_aux_put32(h+44U,hz);
    xe_np_aux_put32(h+48U,bits);xe_np_aux_put32(h+52U,xe_np_aux.error);
    xe_np_aux_put32(h+56U,format);
}
static int xe_np_aux_send(const uint8_t *data,uint32_t bytes,uint32_t direct)
{
    if(!xe_np_aux.pcd || !xe_np_usb_state.configured || !bytes)return -1;
    if(!direct)XE_NP_UsbStream_DCacheCleanTx(data,bytes);
    else if(xe_np_aux.camera_frame_offset==0U)
        XE_NP_UsbStream_DCacheCleanTx(data+XE_NP_AUX_CAMERA_DATA_BYTES,
            XE_NP_AUX_CAMERA_FRAME_BYTES-XE_NP_AUX_CAMERA_DATA_BYTES);
    xe_np_aux.tx_active=1U;xe_np_aux.completion_token=0U;xe_np_aux.tx_started_ms=HAL_GetTick();
    __DMB();
    if(HAL_PCD_EP_Transmit(xe_np_aux.pcd,XE_NP_USB_AUX_EP,(uint8_t *)(uintptr_t)data,bytes)!=HAL_OK) {
        xe_np_aux.tx_active=0U;return -1;
    }
    return 0;
}
static int xe_np_aux_begin(uint32_t type,uint64_t source,uint32_t bytes,uint32_t offset,
    uint32_t total,uint32_t tick,uint32_t hz,uint32_t bits,uint32_t format,const uint8_t *direct)
{
    uint32_t grid=(uint32_t)(type==XE_NP_AUX_TYPE_GRID ||
        type==XE_NP_AUX_TYPE_GRID_PHASE || type==XE_NP_AUX_TYPE_GRID_END);
    if(xe_np_aux.tx_active || (grid && (direct || !bytes || bytes>sizeof(xe_np_aux_tx.staging))))return -1;
    xe_np_aux.tx_type=type;xe_np_aux.tx_bytes=bytes;xe_np_aux.tx_offset=offset;
    xe_np_aux.tx_total=total;xe_np_aux.tx_direct=direct;xe_np_aux.tx_tick=tick;
    xe_np_aux.tx_sequence++;
    xe_np_aux_header(type,source,bytes,offset,total,hz,bits,format);
    /* The accepted provider already owns the adjacent header+body object.
     * One transfer preserves the byte stream while avoiding a short-header
     * completion and a second HAL submit. Phase2 retires that one owner. */
    xe_np_aux.tx_phase=grid?2U:1U;
#if XE_NP_GRID_ENFORCED
    if(grid && xe_np_grid_retained_diag[7]!=UINT32_MAX)xe_np_grid_retained_diag[7]++;
#endif
    const uint8_t *data=grid?(const uint8_t *)(const void *)&xe_np_aux_tx:xe_np_aux_tx.header;
    if(xe_np_aux_send(data,XE_NP_AUX_HEADER_BYTES+(grid?bytes:0U),0U)!=0){xe_np_aux_error(XE_NP_AUX_ERROR_USB);return -1;}
    return 0;
}
static int xe_np_aux_abort_endpoint(void)
{
    if(xe_np_aux.tx_active){
        /* Mark before calling HAL: an IRQ may publish completion during the
         * abort. A failed stop never releases endpoint/DMA staging ownership. */
        xe_np_aux.tx_abort_pending=2U; /* one HAL attempt made; never busy-loop retry */
        if(!xe_np_aux.pcd || HAL_PCD_EP_Abort(xe_np_aux.pcd,XE_NP_USB_AUX_EP)!=HAL_OK)
            return -1;
    }
    xe_np_aux_grid_complete(0U);
    xe_np_aux.tx_active=xe_np_aux.tx_phase=xe_np_aux.completion_token=0U;
    xe_np_aux.tx_abort_pending=0U;return 0;
}
static uint32_t xe_np_aux_grid_u32(const uint8_t *p)
{return (uint32_t)p[0]|((uint32_t)p[1]<<8U)|((uint32_t)p[2]<<16U)|((uint32_t)p[3]<<24U);}
static uint64_t xe_np_aux_grid_u64(const uint8_t *p)
{return xe_np_aux_grid_u32(p)|((uint64_t)xe_np_aux_grid_u32(p+4U)<<32U);}
static int xe_np_aux_grid_body_valid(uint32_t type,uint32_t bytes,uint64_t source)
{
    const uint8_t *b=xe_np_aux_tx.staging;
    if(type==XE_NP_AUX_TYPE_GRID){
        return xe_np_aux_grid.phase_sent && bytes>=48U && bytes<=480U &&
            !memcmp(b,"NSG1",4U) && b[4]==1U && b[5]==1U && b[6]==48U && !b[7] &&
            xe_np_aux_grid_u64(b+8U)==source && xe_np_aux_grid_u32(b+32U)==bytes-48U;
    }
    if(type==XE_NP_AUX_TYPE_GRID_PHASE){
        return !xe_np_aux_grid.phase_sent && bytes==84U && !memcmp(b,"NSGP",4U) &&
            b[4]==1U && !b[5] && b[6]==84U && !b[7] && xe_np_aux_grid_u64(b+44U)==source;
    }
    if(type==XE_NP_AUX_TYPE_GRID_END){
        uint32_t flags;
        if(xe_np_aux.state!=XE_NP_AUX_DRAINING || bytes!=80U ||
           memcmp(b,"NPGEND01",8U) || xe_np_aux_grid_u32(b+8U)!=1U ||
           xe_np_aux_grid_u32(b+12U)!=80U || xe_np_aux_grid_u32(b+72U) ||
           xe_np_aux_grid_u64(b+52U)!=source)return 0;
        flags=xe_np_aux_grid_u32(b+68U);
        return !(flags&~7U) && ((flags&1U)?source!=UINT64_MAX:source==UINT64_MAX);
    }
    return 0;
}
static int xe_np_aux_schedule_grid(void)
{
    uint32_t type=0U,bytes=0U;uint64_t source=UINT64_MAX;
    if(xe_np_aux.tx_active || !xe_np_aux_grid.next || xe_np_aux_grid.ended ||
       !(xe_np_aux.flags&XE_NP_USB_AUX_IMU))return 0;
#if (defined(XE_NP_GRID_POST_PROVIDER_PRIORITY_TEST) && XE_NP_GRID_POST_PROVIDER_PRIORITY_TEST) || \
    (defined(XE_NP_GRID_ENFORCED) && XE_NP_GRID_ENFORCED)
    if(xe_np_aux_grid.outstanding) {
        /* A deferred record keeps its original staging bytes/source.  Fault,
         * reset, and endpoint abort still retire it as incomplete. */
        if(!xe_np_aux_grid.stop_deferred)return 0;
        if(np2_usb.state==NP2_USB_FAILED || xe_np_aux.interrupted ||
           xe_np_aux.fault_pending || xe_np_aux.tx_abort_pending) {
            xe_np_aux_grid_complete(0U);xe_np_aux_error(XE_NP_AUX_ERROR_INTERRUPTED);return -1;
        }
        /* USB service may finish its final drain before AUX gets this
         * foreground turn. COMPLETE is a successful drain; IDLE is not. */
        if(np2_usb.state!=NP2_USB_DRAINING && np2_usb.state!=NP2_USB_COMPLETE)return 0;
        type=xe_np_aux_grid.type;bytes=xe_np_aux_grid.bytes;source=xe_np_aux_grid.source;
        xe_np_aux_grid.stop_deferred=0U;
        goto begin_accepted;
    }
#else
    if(xe_np_aux_grid.outstanding)return 0;
#endif
#if XE_NP_NP2_FIRST_SYNC_ENABLE
    if(xe_np_aux.first_sync_mode==XE_NP_AUX_FIRST_SYNC_WAIT ||
       (xe_np_aux.first_sync_withheld&1U)){
#if XE_NP_GRID_STARTUP_DIAG
        if(xe_np_grid_startup_diag.stage[XE_NP_GRID_DIAG_TIMER_START].valid)
            XE_NP_Np2FirstSyncRuntime_GridDiagMark(XE_NP_GRID_DIAG_FIRSTSYNC_BLOCKED_WITH_QUEUED);
#endif
        return 0;
    }
#endif
#if (defined(XE_NP_GRID_READY_GATE_TEST) && XE_NP_GRID_READY_GATE_TEST) || \
    (defined(XE_NP_GRID_FAIRNESS_TEST) && XE_NP_GRID_FAIRNESS_TEST) || \
    (defined(XE_NP_GRID_ENFORCED) && XE_NP_GRID_ENFORCED)
    /* Skip only empty active batches; errors, pending data and drain are
     * still offered. The strict empty-NP-take admission stays unchanged. */
    if(np2_usb.state==NP2_USB_CAPTURING && np2_usb_aux_opportunity &&
       !XE_NP_Np2FirstSyncRuntime_GridNeedsPoll())return 0;
#endif
#if XE_NP_NP2_USB_GRID_EXPERIMENT
    /* Defer new grid packing, but keep AUX retirement and timeout service live. */
    if(np2_usb.state==NP2_USB_CAPTURING && !np2_usb_aux_opportunity
#if XE_NP_GRID_ENFORCED
       && !xe_np_aux_grid_try_retained()
#endif
#if defined(XE_NP_GRID_FAIRNESS_TEST) && XE_NP_GRID_FAIRNESS_TEST
       && !xe_np_aux_grid_try_fair()
#endif
       ){
#if XE_NP_GRID_STARTUP_DIAG
        XE_NP_Np2FirstSyncRuntime_GridDiagMark(XE_NP_GRID_DIAG_OPPORTUNITY_DEFERRED);
#endif
        return 0;
    }
#endif
#if defined(XE_NP_GRID_FAIRNESS_TEST) && XE_NP_GRID_FAIRNESS_TEST
    /* Recheck both normal and experimental admission immediately before the
     * provider. An idle EP81 with queued NP gets the next foreground pass.
     * IRQs after this check remain bounded by the test assumption only. */
    if(np2_usb.state==NP2_USB_CAPTURING){
        uint32_t key=__get_PRIMASK();__disable_irq();
        uint32_t defer=(uint32_t)(np2_usb.cancel || np2_usb.target ||
            xe_np_aux.stop_requested || xe_np_aux.fault_pending ||
            xe_np_aux.interrupted || xe_np_aux.tx_abort_pending ||
            (!np2_usb.active && (np2_usb.filled!=np2_usb.submitted || np2_usb.tx_segment)));
        __set_PRIMASK(key);
        if(defer)return 0;
    }
#endif
#if XE_NP_GRID_STARTUP_DIAG
    if(xe_np_grid_startup_diag.stage[XE_NP_GRID_DIAG_PROOF_ATTACH].valid)
        XE_NP_Np2FirstSyncRuntime_GridDiagMark(XE_NP_GRID_DIAG_PROVIDER_POLLED);
#endif
#if XE_NP_GRID_AUX_COST_DIAG
    XE_NP_AuxCostStamp cost=XE_NP_AuxCost_Start();
#endif
    int result=xe_np_aux_grid.next(xe_np_aux_grid.context,xe_np_aux_tx.staging,
        XE_NP_AUX_STAGING_BYTES,&type,&bytes,&source,xe_np_aux.state==XE_NP_AUX_DRAINING);
#if XE_NP_GRID_AUX_COST_DIAG
    XE_NP_AuxCost_End(XE_NP_AUX_COST_PROVIDER,cost);
#endif
    if(result==0)return 0;
    if(result!=1){xe_np_aux_grid.ended=1U;xe_np_aux_error(XE_NP_AUX_ERROR_GRID);return -1;}
    xe_np_aux_grid.type=type;xe_np_aux_grid.outstanding=1U;
#if (defined(XE_NP_GRID_POST_PROVIDER_PRIORITY_TEST) && XE_NP_GRID_POST_PROVIDER_PRIORITY_TEST) || \
    (defined(XE_NP_GRID_ENFORCED) && XE_NP_GRID_ENFORCED)
    xe_np_aux_grid.bytes=bytes;xe_np_aux_grid.source=source;xe_np_aux_grid.stop_deferred=0U;
#endif
    if(!xe_np_aux_grid_body_valid(type,bytes,source)){
        xe_np_aux_grid_complete(0U);xe_np_aux_error(XE_NP_AUX_ERROR_GRID);return -1;
    }
#if (defined(XE_NP_GRID_POST_PROVIDER_PRIORITY_TEST) && XE_NP_GRID_POST_PROVIDER_PRIORITY_TEST) || \
    (defined(XE_NP_GRID_ENFORCED) && XE_NP_GRID_ENFORCED)

    /* Rearm already-published NP before starting EP82.  Next owns staging;
     * a normal NP cancel/stop defers its accepted record until DRAINING,
     * while fault/reset remains an explicit incomplete completion. */
    if(np2_usb.state==NP2_USB_FAILED){
        xe_np_aux_grid_complete(0U);xe_np_aux_error(XE_NP_AUX_ERROR_INTERRUPTED);return -1;
    }
    if(np2_usb.state==NP2_USB_CAPTURING || np2_usb.state==NP2_USB_DRAINING){
        if(np2_usb.state==NP2_USB_CAPTURING &&
           (xe_np_aux.interrupted || xe_np_aux.fault_pending)){
            xe_np_aux_grid_complete(0U);xe_np_aux_error(XE_NP_AUX_ERROR_INTERRUPTED);return -1;
        }
        if(np2_usb.state==NP2_USB_CAPTURING && (xe_np_aux.stop_requested || np2_usb.cancel)) {
            xe_np_aux_grid.stop_deferred=1U;return 0;
        }
        np2_usb_transmit();
        if(np2_usb.state==NP2_USB_FAILED ||
           (np2_usb.state==NP2_USB_CAPTURING &&
            (xe_np_aux.interrupted || xe_np_aux.fault_pending))){
            xe_np_aux_grid_complete(0U);xe_np_aux_error(XE_NP_AUX_ERROR_INTERRUPTED);return -1;
        }
        if(np2_usb.state==NP2_USB_CAPTURING && (xe_np_aux.stop_requested || np2_usb.cancel)) {
            xe_np_aux_grid.stop_deferred=1U;return 0;
        }
    }
#endif
begin_accepted:
#if XE_NP_GRID_AUX_COST_DIAG
    cost=XE_NP_AuxCost_Start();
#endif
    result=xe_np_aux_begin(type,source,bytes,0U,bytes,0U,
        type==XE_NP_AUX_TYPE_GRID?1250U:0U,3U,type,NULL);
#if XE_NP_GRID_AUX_COST_DIAG
    XE_NP_AuxCost_End(XE_NP_AUX_COST_HEADER,cost);
#endif
    if(result!=0){
        xe_np_aux_grid_complete(0U);xe_np_aux_error(XE_NP_AUX_ERROR_USB);return -1;
    }
#if XE_NP_GRID_STARTUP_DIAG
    if(type==XE_NP_AUX_TYPE_GRID_PHASE)
        XE_NP_Np2FirstSyncRuntime_GridDiagMark(XE_NP_GRID_DIAG_PHASE_SCHEDULED);
    if(type==XE_NP_AUX_TYPE_GRID)
        XE_NP_Np2FirstSyncRuntime_GridDiagMark(XE_NP_GRID_DIAG_ROW_SCHEDULED);
#endif
    return 0;
}
static void xe_np_aux_retire_tx(void)
{
    if(!xe_np_aux.completion_token)return;
    xe_np_aux.completion_token=0U;xe_np_aux.tx_active=0U;
    if(xe_np_aux.tx_abort_pending){
        /* This late completion proves the failed abort's owned transfer has
         * retired; do not send a payload or claim a complete grid record. */
        xe_np_aux_grid_complete(0U);
        xe_np_aux.tx_abort_pending=0U;xe_np_aux.tx_phase=xe_np_aux.tx_type=xe_np_aux.tx_bytes=0U;
        xe_np_aux.tx_direct=NULL;return;
    }
    if(xe_np_aux.tx_phase==1U) {
        xe_np_aux.tx_phase=2U;
        if(!xe_np_aux.tx_bytes) {xe_np_aux.usb_records++;xe_np_aux.usb_bytes+=XE_NP_AUX_HEADER_BYTES;return;}
        const uint8_t *payload=xe_np_aux.tx_direct?xe_np_aux.tx_direct:xe_np_aux_tx.staging;
#if XE_NP_GRID_AUX_COST_DIAG
        uint32_t grid_transfer=xe_np_aux_grid.outstanding;
        XE_NP_AuxCostStamp cost={0U,0U,0U};
        if(grid_transfer)cost=XE_NP_AuxCost_Start();
#endif
        int result=xe_np_aux_send(payload,xe_np_aux.tx_bytes,xe_np_aux.tx_direct!=NULL);
#if XE_NP_GRID_AUX_COST_DIAG
        if(grid_transfer)XE_NP_AuxCost_End(XE_NP_AUX_COST_PAYLOAD,cost);
#endif
        if(result!=0){
            xe_np_aux_error(XE_NP_AUX_ERROR_USB);
            if(xe_np_aux_grid.outstanding){
                xe_np_aux_grid_complete(0U);xe_np_aux.tx_phase=xe_np_aux.tx_type=xe_np_aux.tx_bytes=0U;
                xe_np_aux.stop_requested=1U;
            }
        }
        return;
    }
    xe_np_aux.usb_records++;xe_np_aux.usb_bytes+=(uint64_t)XE_NP_AUX_HEADER_BYTES+xe_np_aux.tx_bytes;
    if(xe_np_aux.tx_type==XE_NP_AUX_TYPE_CAMERA) {
        if(xe_np_aux.camera_frame_offset+xe_np_aux.tx_bytes==xe_np_aux.camera_frame_total) {
            XE_NP_MediaCamera_ConsumeFrame();xe_np_aux.camera_sent++;
            xe_np_aux.camera_frame_valid=0U;xe_np_aux.camera_frame_total=xe_np_aux.camera_frame_offset=0U;
        } else xe_np_aux.camera_frame_offset+=xe_np_aux.tx_bytes;
    } else if(xe_np_aux.tx_type==XE_NP_AUX_TYPE_ADC) {
        xe_np_aux.adc_cursor+=xe_np_aux.tx_bytes;xe_np_aux.adc_sent+=xe_np_aux.tx_bytes;
    } else if(xe_np_aux.tx_type==XE_NP_AUX_TYPE_IMU)xe_np_aux.imu_sent++;
    else if(xe_np_aux.tx_type==XE_NP_AUX_TYPE_GRID ||
            xe_np_aux.tx_type==XE_NP_AUX_TYPE_GRID_PHASE ||
            xe_np_aux.tx_type==XE_NP_AUX_TYPE_GRID_END)xe_np_aux_grid_complete(1U);
    xe_np_aux.tx_phase=xe_np_aux.tx_type=xe_np_aux.tx_bytes=0U;xe_np_aux.tx_direct=NULL;
}
void XE_NP_UsbAux_Complete(void)
{
    if(xe_np_aux.tx_active){__DMB();xe_np_aux.completion_token=1U;}
}
uint32_t XE_NP_UsbAux_IsBusy(void)
{
    return xe_np_aux.cleanup_hold || xe_np_aux.start_pending || xe_np_aux.tx_active || xe_np_aux.state==XE_NP_AUX_PREPARING ||
        xe_np_aux.state==XE_NP_AUX_RUNNING || xe_np_aux.state==XE_NP_AUX_DRAINING;
}
static int xe_np_aux_schedule_fair(uint32_t now)
{
#if (defined(XE_NP_GRID_POST_PROVIDER_PRIORITY_TEST) && XE_NP_GRID_POST_PROVIDER_PRIORITY_TEST) || \
    (defined(XE_NP_GRID_ENFORCED) && XE_NP_GRID_ENFORCED)
    /* One accepted deferred grid body owns staging.  Do not let an earlier
     * fair source overwrite it while NP reaches its finite drain boundary. */
    if(xe_np_aux_grid.outstanding && xe_np_aux_grid.stop_deferred)
        return xe_np_aux_schedule_grid();
#endif
    for(uint32_t n=0U;n<4U;n++){
        uint32_t which=(xe_np_aux.fair_next+n)&3U;int result=0;
        if(which==0U && (xe_np_aux.flags&XE_NP_USB_AUX_ADC)){
            result=xe_np_aux_schedule_adc();
            if(result){xe_np_aux_latch_fault(XE_NP_AUX_ERROR_ADC);return -1;}
        }else if(which==1U && xe_np_aux.state==XE_NP_AUX_RUNNING){
            result=xe_np_aux_schedule_imu(now);if(result)return -1;
        }else if(which==2U && (xe_np_aux.flags&XE_NP_USB_AUX_CAMERA)){
            result=xe_np_aux_schedule_camera();
            if(result){xe_np_aux_latch_fault(XE_NP_AUX_ERROR_CAMERA);return -1;}
        }else if(which==3U){
            /* A grid-only error is reported but does not stop other streams. */
            (void)xe_np_aux_schedule_grid();
#if (defined(XE_NP_GRID_POST_PROVIDER_PRIORITY_TEST) && XE_NP_GRID_POST_PROVIDER_PRIORITY_TEST) || \
    (defined(XE_NP_GRID_ENFORCED) && XE_NP_GRID_ENFORCED)
            /* Next may have just claimed staging and deferred it for NP's
             * finite stop.  Do not continue this same fair pass into an AUX
             * writer that could overwrite the accepted body. */
            if(xe_np_aux_grid.outstanding && xe_np_aux_grid.stop_deferred)return 0;
#endif
        }
        if(xe_np_aux.tx_active){xe_np_aux.fair_next=(uint8_t)((which+1U)&3U);return 1;}
    }
    return 0;
}
static int xe_np_aux_service_abort(void)
{
    if(!xe_np_aux.tx_abort_pending)return 0;
    if(xe_np_aux.completion_token){xe_np_aux_retire_tx();return 0;}
    if(xe_np_aux.tx_abort_pending==1U && !xe_np_aux_np_capture_active())
        return xe_np_aux_abort_endpoint()!=0;
    return 1;
}
static int xe_np_aux_timeout(uint32_t now)
{
    if(!xe_np_aux.tx_active || (uint32_t)(now-xe_np_aux.tx_started_ms)<5000U)return 0;
    xe_np_aux_error(XE_NP_AUX_ERROR_USB);xe_np_aux.stop_requested=1U;
    xe_np_aux.tx_abort_pending=1U;
    return xe_np_aux_service_abort();
}
static void put32(uint8_t *p,uint32_t v){for(unsigned i=0;i<4;i++)p[i]=(uint8_t)(v>>(i*8));}
static void put64(uint8_t *p,uint64_t v){put32(p,(uint32_t)v);put32(p+4,(uint32_t)(v>>32));}
static void done(void *ctx,uint32_t type,uint32_t delivered){CHECK(ctx==(void*)0x1234&&type==offered);completes++;if(!delivered)failed++;}
static int next(void *ctx,uint8_t *p,uint32_t cap,uint32_t *type,uint32_t *bytes,uint64_t *source,uint32_t){
 CHECK(ctx==(void*)0x1234&&cap==4096);next_calls++;memset(p,0,480);*type=offered;*source=5;
 if(offered==6){memcpy(p,"NSGP",4);p[4]=1;p[6]=84;put64(p+44,5);*bytes=84;}
 else if(offered==5){memcpy(p,"NSG1",4);p[4]=p[5]=1;p[6]=48;put64(p+8,5);put32(p+32,36);*bytes=84;}
 else{memcpy(p,"NPGEND01",8);put32(p+8,1);put32(p+12,80);put64(p+52,5);put32(p+68,1);*bytes=80;}return 1;
}
static void reset(void){
 memset(&xe_np_aux,0,sizeof xe_np_aux);memset(&xe_np_aux_grid,0,sizeof xe_np_aux_grid);memset(&xe_np_aux_tx,0,sizeof xe_np_aux_tx);
 xe_np_aux.pcd=&pcd;xe_np_aux.state=XE_NP_AUX_RUNNING;xe_np_aux.flags=4;xe_np_usb_state.configured=1;
 np2_usb.state=NP2_USB_IDLE;np2_usb.cancel=0;sends=aborts=clean_calls=clean_bytes=fail_send=fail_abort=immediate=next_calls=completes=failed=transmits=consumes=retired=0;wire.clear();
 xe_np_aux_grid.next=next;xe_np_aux_grid.complete=done;xe_np_aux_grid.context=(void*)0x1234;xe_np_aux_grid.phase_sent=1;
}
static void tick(void){XE_NP_UsbAux_Complete();xe_np_aux_retire_tx();}
static void prepare_offer(void){xe_np_aux_grid.phase_sent=offered!=6U;if(offered==7U)xe_np_aux.state=XE_NP_AUX_DRAINING;}
static std::vector<uint8_t> expected(uint32_t type,uint32_t n,const uint8_t *p){
 std::vector<uint8_t> b(64+n);memcpy(b.data(),"NPAVUSB1",8);put32(b.data()+8,1);put32(b.data()+12,type);put32(b.data()+16,1);
 put32(b.data()+20,9);put64(b.data()+24,UINT64_C(0x123456789abcdef0));put32(b.data()+32,n);put32(b.data()+36,0);put32(b.data()+40,n);
 put32(b.data()+44,type==5?1250:0);put32(b.data()+48,3);put32(b.data()+56,type);if(n)memcpy(b.data()+64,p,n);return b;
}
int main(void){
 CHECK(offsetof(XE_NP_AuxTxBuffers,staging)==64);CHECK(sizeof xe_np_aux_tx.staging==4096);
 const uint32_t sizes[]={1,48,80,84,480,4096};
 for(uint32_t type=5;type<=7;type++)for(unsigned j=0;j<sizeof sizes/sizeof sizes[0];j++){
  reset();uint32_t n=sizes[j];for(uint32_t i=0;i<n;i++)xe_np_aux_tx.staging[i]=(uint8_t)(i*29+7);auto want=expected(type,n,xe_np_aux_tx.staging);
  CHECK(!xe_np_aux_begin(type,UINT64_C(0x123456789abcdef0),n,0,n,9,type==5?1250:0,3,type,NULL));
  CHECK(sends==1&&last_len==64+n&&last_ptr==(const uint8_t*)&xe_np_aux_tx&&xe_np_aux.tx_phase==2&&xe_np_aux.tx_active);
  CHECK(wire==want&&clean_calls==1&&clean_bytes==64+n);tick();CHECK(sends==1&&!xe_np_aux.tx_active&&xe_np_aux.usb_records==1&&xe_np_aux.usb_bytes==64+n);
 }
 for(uint32_t type=5;type<=7;type++){
  reset();CHECK(xe_np_aux_begin(type,0,0,0,0,0,0,3,type,NULL)==-1&&sends==0);
  CHECK(xe_np_aux_begin(type,0,4097,0,4097,0,0,3,type,NULL)==-1&&sends==0);
  CHECK(xe_np_aux_begin(type,0,80,0,80,0,0,3,type,xe_np_aux_tx.staging)==-1&&sends==0);
  reset();offered=type;prepare_offer();immediate=1;CHECK(!xe_np_aux_schedule_grid());CHECK(xe_np_aux.tx_phase==2&&xe_np_aux.completion_token&&completes==0&&sends==1);
  xe_np_aux_retire_tx();CHECK(completes==1&&!failed&&!xe_np_aux_grid.outstanding);tick();CHECK(completes==1&&sends==1);
  reset();offered=type;prepare_offer();fail_send=1;CHECK(xe_np_aux_schedule_grid()==-1);CHECK(completes==1&&failed==1&&!xe_np_aux.tx_active&&!xe_np_aux_grid.outstanding);tick();CHECK(completes==1);
  reset();offered=type;prepare_offer();CHECK(!xe_np_aux_schedule_grid());std::vector<uint8_t> held((uint8_t*)&xe_np_aux_tx,(uint8_t*)&xe_np_aux_tx+64+xe_np_aux.tx_bytes);fail_abort=1;
  CHECK(xe_np_aux_abort_endpoint()==-1&&xe_np_aux.tx_active&&xe_np_aux.tx_abort_pending==2&&completes==0&&xe_np_aux_grid.outstanding);
  CHECK(XE_NP_UsbAux_IsBusy()&&XE_NP_UsbAux_BindGrid(NULL,NULL,NULL)==-1);
  CHECK(xe_np_aux_service_abort()==1&&aborts==1);CHECK(!xe_np_aux_schedule_grid()&&next_calls==1&&memcmp(held.data(),&xe_np_aux_tx,held.size())==0);
  tick();CHECK(completes==1&&failed==1&&!xe_np_aux.tx_active&&!xe_np_aux_grid.outstanding&&sends==1);tick();CHECK(completes==1);
  reset();offered=type;prepare_offer();CHECK(!xe_np_aux_schedule_grid());CHECK(!xe_np_aux_abort_endpoint());CHECK(aborts==1&&completes==1&&failed==1);tick();CHECK(completes==1);
 }
 /* Legacy paths retain separate header/payload completions and direct pointer. */
 for(uint32_t type=1;type<=4;type++){
  reset();uint32_t n=type==4?0:80;uint8_t direct[80]={0};const uint8_t *p=type==1?direct:NULL;
  CHECK(!xe_np_aux_begin(type,0,n,0,n,0,200000,3,type,p));CHECK(sends==1&&last_len==64&&xe_np_aux.tx_phase==1);tick();
  if(n){CHECK(sends==2&&last_len==n&&last_ptr==(p?p:xe_np_aux_tx.staging));tick();}else CHECK(sends==1);
  CHECK(!xe_np_aux.tx_active&&xe_np_aux.usb_records==1);if(type==2)CHECK(xe_np_aux.adc_cursor==80);if(type==3)CHECK(xe_np_aux.imu_sent==1);
 }
 /* Accepted body survives ordinary NP Stop and is sent once after drain. */
 reset();offered=6;prepare_offer();np2_usb.state=NP2_USB_CAPTURING;np2_usb.cancel=1;CHECK(!xe_np_aux_schedule_grid());CHECK(next_calls==1&&xe_np_aux_grid.outstanding&&xe_np_aux_grid.stop_deferred&&sends==0);
 uint8_t held[84];memcpy(held,xe_np_aux_tx.staging,84);CHECK(!xe_np_aux_schedule_fair(12)&&next_calls==1&&sends==0&&memcmp(held,xe_np_aux_tx.staging,84)==0);
 np2_usb.state=NP2_USB_COMPLETE;CHECK(!xe_np_aux_schedule_grid());CHECK(next_calls==1&&sends==1&&last_len==148&&memcmp(held,xe_np_aux_tx.staging,84)==0);tick();CHECK(completes==1&&!failed);
 /* Timeout while NP active holds ownership; late completion is incomplete. */
 reset();offered=6;prepare_offer();CHECK(!xe_np_aux_schedule_grid());np2_usb.state=NP2_USB_CAPTURING;CHECK(xe_np_aux_timeout(5010)==1&&aborts==0&&completes==0&&xe_np_aux_grid.outstanding);
 CHECK(xe_np_aux_service_abort()==1&&aborts==0);XE_NP_UsbAux_Complete();CHECK(!xe_np_aux_service_abort()&&failed==1&&completes==1&&sends==1);
 printf("PASS %u checks; exact extracted zero-copy AUX functions, no hardware\n",checks);return 0;
}
