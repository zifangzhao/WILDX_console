from pathlib import Path
import json,hashlib,subprocess,re,sys
T=Path(__file__).resolve().parent;O=T/'build';O.mkdir(parents=True,exist_ok=True)
P=T.parent/'v2_usb_selected_detectors_20261105';R=Path('D:/Code/XE_NP_V2')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
parent=load(P/'build/receipt.json');assert parent['crc32']=='112066CE' and sha(P/'build/application.bin')==parent['body_sha256']
frozen=T.parent/'v2_sd_recording_fix_20261104/input-freeze/files/FAEE4297886961DE3CFFB820A6DA988D9E6C90022135E7336F3AAD8D759E303C.c'
assert sha(frozen)==frozen.stem
src=T/'Core/Src/xe_np_sensors.c';src.parent.mkdir(parents=True,exist_ok=True)
before=frozen.read_text();old='/* Preserve checked role profiles: USB MAG25, SD MAG100. */\n#ifndef XE_NP_SENSOR_MAG_ODR\n#if defined(XE_NP_IMAGE_ROLE) && XE_NP_IMAGE_ROLE==2U\n#define XE_NP_SENSOR_MAG_ODR 0x06U\n#else\n#define XE_NP_SENSOR_MAG_ODR 0x08U\n#endif\n#endif'
assert before.count(old)==1
after=before.replace(old,'/* Preserve 200 Hz AG and the checked 100 Hz magnetic profile in both roles. */\n#ifndef XE_NP_SENSOR_MAG_ODR\n#define XE_NP_SENSOR_MAG_ODR 0x08U\n#endif')
src.write_text(after)
plan=load(R/'_artifacts/v2_grid_source_20261029/usb-grid-candidate/plan.json')
for logical,pin in plan['sources'].items():
 if Path(logical).name in ['xe_np_sensors.h','bmm150.h','bmm150_defs.h','bme280.h','bme280_defs.h']:
  assert sha(logical)==pin,(logical,pin,sha(logical))
flags=plan['flags'];command=['C:/Keil_v5/ARM/ARMCLANG/bin/armclang.exe']+flags+['-c',str(src),'-o',str(O/'xe_np_sensors.o'),'-MMD','-MF',str(O/'xe_np_sensors.d')]
if not (O/'xe_np_sensors.o').exists():
 r=subprocess.run(command,cwd=R,capture_output=True,text=True);(O/'sensor-compile.log').write_text(r.stdout+r.stderr);assert not r.returncode,r.stdout+r.stderr
link=(P/'build/application.lnp').read_text();objs=re.findall(r'"([^"\r\n]+\.o)"',link)
oldobj=[p for p in objs if Path(p).name=='xe_np_sensors.o'];assert len(oldobj)==1 and sha(oldobj[0])=='CC710100198866DCB479BD7B3A714E32C6F2F1F898C6779A70444CCA45484B71'
retained={p:sha(p) for p in objs if p!=oldobj[0]}
link=link.replace(oldobj[0],(O/'xe_np_sensors.o').as_posix())
for name in ['application.axf','application.map']:link=link.replace((P/'build'/name).as_posix(),(O/name).as_posix())
link=link.replace((P/'build/application.sct').as_posix(),(O/'application.sct').as_posix())
(O/'application.sct').write_bytes((P/'build/application.sct').read_bytes());(O/'application.lnp').write_text(link)
pending=dict(parent_crc32='112066CE',expected_app_crc32='99CC44F9',compiler_commands={'xe_np_sensors':command},source_pins={str(src):sha(src)},retained_objects=retained,old_sensor_object_sha256=sha(oldobj[0]),old_sensor_source_sha256=sha(frozen),scope='USB-only MAG25 toMAG100; AG200/5ms asyncpoll, gains,1250grid, NP/CL/media and SD APP bytes unchanged')
(O/'pending.json').write_text(json.dumps(pending,indent=2)+'\n')
if '--compile-only' in sys.argv:print('One sensor object compiled');sys.exit()
r=subprocess.run(['C:/Keil_v5/ARM/ARMCLANG/bin/armlink.exe','--via',str(O/'application.lnp')],capture_output=True,text=True);(O/'link.log').write_text(r.stdout+r.stderr);assert not r.returncode,r.stdout+r.stderr
def capture_symbols(path):
 return {(m[1],m[4]):(int(m[2],16),int(m[3])) for m in re.finditer(r'^\s+(\S+)\s+(0x[\da-fA-F]+)\s+Data\s+(\d+)\s+([^\r\n]+)',path.read_text(),re.M) if m[4].endswith(('(NP_CAPTURE)','(NP2_CL_SELECTED)'))}
assert capture_symbols(O/'application.map')==capture_symbols(P/'build/application.map')
(O/'memory-proof.json').write_text(json.dumps(dict(status='PASS',unchanged_capture_symbols=capture_symbols(O/'application.map').__len__(),scatter_sha256=sha(O/'application.sct'),claim='Exact parent scatter and all NP_CAPTURE/NP2_CL_SELECTED data addresses and sizes unchanged; only sensor object replaced'),indent=2)+'\n')
print('One sensor TU linked; NP/CL memory and all other objects unchanged')
