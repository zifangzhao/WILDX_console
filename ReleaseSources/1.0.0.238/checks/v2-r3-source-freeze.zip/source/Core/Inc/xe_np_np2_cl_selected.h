#ifndef XE_NP_NP2_CL_SELECTED_H
#define XE_NP_NP2_CL_SELECTED_H
#include <stdint.h>
#include "xe_np_np2_closed_loop_spi.h"
int XE_NP_Np2ClSelected_Prepare(void);
void XE_NP_Np2ClSelected_Enable(void);
void XE_NP_Np2ClSelected_Stop(void);
int XE_NP_Np2ClSelected_Calibrate(const uint8_t *,uint32_t);
int XE_NP_Np2ClSelected_Proof(uint16_t *phase);
int XE_NP_Np2ClSelected_Offer(XE_NP_Np2ClosedLoopSpi *,uint64_t,int);
int XE_NP_Np2ClCarrier_SelectedRequest(uint16_t channel[2],uint8_t *count);
void XE_NP_Np2ClSelected_DmaDispatch(void);
#endif
