#include "xe_np_np2_closed_loop_spi.h"
#include <string.h>
#include <limits.h>
#include "xe_np_np2_closed_loop_perf.h"
#if XE_NP_NP2_CLOSED_LOOP_SPI_ENABLE
#include "xe_np_np2_cl_selected.h"
#endif
#if XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
extern void XE_NP_Np2ClCarrier_PortDrain(void);
#endif
/* Q23, 2500 Hz, 41 taps: pass 0..300 Hz, stop 625..1250 Hz.
 * Native -> CIC4 (R=3/6/8/12) -> FIR -> decimate2 -> 1250 Hz.
 * Deliberately independent of the 500-Hz BLE display filter. */
static const int32_t coeff[41]={
    199,1555,3104,428,-8848,-14724,624,33988,42462,-15053,-99201,
    -89374,73908,241836,147315,-255619,-565229,-196703,996824,
    2391103,3012454,2391103,996824,-196703,-565229,-255619,147315,
    241836,73908,-89374,-99201,-15053,42462,33988,624,-14724,-8848,
    428,3104,1555,199};
static void reset_filter(XE_NP_Np2ClosedLoopSpi *s)
{
    memset(s->filter,0,sizeof(s->filter));
    s->cic_at=s->fir_at=0U;s->intermediate_count=0U;s->reset_pending=1U;
}
int XE_NP_Np2ClosedLoopSpi_Init(XE_NP_Np2ClosedLoopSpi *s,const XE_NP_Np2ClosedLoopSpiConfig *c)
{
    if(!s || !c)return -1;
    memset(s,0,sizeof(*s));
    if(!c->phase_verified || !c->origin_valid || !c->source_epoch || c->phase>=1600U || c->count<1U || c->count>2U ||
        !((c->probe==3U && c->lane==2U) || (c->probe==2U && c->lane==0U)) ||
       !(c->sample_hz==7500U || c->sample_hz==15000U ||
         c->sample_hz==20000U || c->sample_hz==30000U))return -1;
    if(c->count==2U && c->channel[0]==c->channel[1])return -1;
    s->config=*c;
    for(unsigned i=0U;i<c->count;i++){
        uint32_t ch=c->channel[i];
        if(ch>=384U || ch/128U!=c->lane)return -1;
        ch%=128U;
        uint32_t field=(ch%32U)/2U*100U+4U+((ch/32U)*2U+(ch&1U))*12U;
        s->offset[i]=(uint16_t)(c->probe==2U?
            (1600U-c->phase)%1600U+field:(1600U-c->phase+field)%1600U);
    }
    uint32_t r=c->sample_hz/2500U,gain=r*r*r*r;
    s->ratio=(uint8_t)r;
    s->reciprocal=(uint32_t)((8ULL*4294967296ULL+gain/2U)/gain);
    s->delay_source_ticks=(22U*r-2U)*1600U;
    s->enabled=1U;reset_filter(s);return 0;
}
void XE_NP_Np2ClosedLoopSpi_Gap(XE_NP_Np2ClosedLoopSpi *s,uint64_t first,uint64_t end,uint32_t reason)
{
    if(!s || !s->enabled)return;
    s->gap_events++;s->gap_first=first;s->gap_end=end;s->reason=(uint8_t)reason;s->notice=1U;
    s->in_head=s->in_tail=s->out_head=s->out_tail=0U;
    s->initialized=s->previous_bits=0U;s->bits[0]=s->bits[1]=0U;s->word[0]=s->word[1]=0U;
    s->expected=end;reset_filter(s);
}
void XE_NP_Np2ClosedLoopSpi_LoseOrigin(XE_NP_Np2ClosedLoopSpi *s,uint32_t reason)
{
    if(!s || !s->enabled)return;
    s->config.origin_valid=0U;
    XE_NP_Np2ClosedLoopSpi_Gap(s,0U,0U,reason);
}
/* Reverse n chronological LSB-first bits into an MSB-first ADC word. */
static uint16_t reverse_bits(uint32_t v,unsigned n)
{
    v=((v&0x5555U)<<1U)|((v>>1U)&0x5555U);
    v=((v&0x3333U)<<2U)|((v>>2U)&0x3333U);
    v=((v&0x0f0fU)<<4U)|((v>>4U)&0x0f0fU);
    v=((v&0x00ffU)<<8U)|((v>>8U)&0x00ffU);
    return (uint16_t)(v>>(16U-n));
}
static uint16_t gather(const uint8_t *raw,uint32_t bytes,uint32_t bit,unsigned n)
{
    uint32_t i=bit>>3U,shift=bit&7U,v=raw[i];
    if(shift+n>8U && i+1U<bytes)v|=(uint32_t)raw[i+1U]<<8U;
    if(shift+n>16U && i+2U<bytes)v|=(uint32_t)raw[i+2U]<<16U;
    return reverse_bits((v>>shift)&((1U<<n)-1U),n);
}
int XE_NP_Np2ClosedLoopSpi_Offer(XE_NP_Np2ClosedLoopSpi *s,const uint8_t *raw,uint32_t bytes,uint64_t first,int pressure)
{
    if(!s || !s->enabled || !s->config.origin_valid)return 0;
    if(!raw || !bytes || bytes>NP2_CL_SPI_MAX_BYTES || first>UINT64_MAX-(uint64_t)bytes*8U){
        XE_NP_Np2ClosedLoopSpi_Gap(s,first,first,NP2_CL_SPI_REASON_BOUNDS);return -1;
    }
    uint64_t end=first+(uint64_t)bytes*8U;
    if(pressure){XE_NP_Np2ClosedLoopSpi_Gap(s,first,end,NP2_CL_SPI_REASON_PRESSURE);return 0;}
    if(s->initialized && first!=s->expected)
        XE_NP_Np2ClosedLoopSpi_Gap(s,s->expected,first,NP2_CL_SPI_REASON_SOURCE);
    s->expected=end;
    if(!s->initialized){
        uint32_t skip=(uint32_t)((1600U-first%1600U)%1600U);
        if(first>UINT64_MAX-3200U){XE_NP_Np2ClosedLoopSpi_Gap(s,first,end,NP2_CL_SPI_REASON_BOUNDS);return -1;}
        s->frame_tick=first+skip;s->initialized=1U;
    }
    while(s->frame_tick<end){
        if(s->frame_tick>UINT64_MAX-3212U){XE_NP_Np2ClosedLoopSpi_Gap(s,first,end,NP2_CL_SPI_REASON_BOUNDS);return -1;}
        for(unsigned c=0U;c<s->config.count;c++)while(s->bits[c]<12U){
            uint64_t at=s->frame_tick+s->offset[c]+s->bits[c];
            if(at>=end)break;
            unsigned n=12U-s->bits[c];uint16_t word;
            if(at<first){
                uint64_t behind=first-at;
                if(behind>s->previous_bits){XE_NP_Np2ClosedLoopSpi_Gap(s,at,first,NP2_CL_SPI_REASON_SOURCE);return -1;}
                if(n>behind)n=(unsigned)behind;
                uint32_t v=(uint32_t)s->previous>>(s->previous_bits-(unsigned)behind);
                word=reverse_bits(v&((1U<<n)-1U),n);
            }else{
                if(n>end-at)n=(unsigned)(end-at);
                word=gather(raw,bytes,(uint32_t)(at-first),n);
            }
            s->word[c]=(uint16_t)((s->word[c]<<n)|word);s->bits[c]=(uint8_t)(s->bits[c]+n);
        }
        if(s->bits[0]!=12U || (s->config.count==2U && s->bits[1]!=12U))break;
        if((uint16_t)(s->in_head-s->in_tail)>=NP2_CL_SPI_INPUT_ROWS){
            s->queue_overflows++;XE_NP_Np2ClosedLoopSpi_Gap(s,first,end,NP2_CL_SPI_REASON_QUEUE);return 0;
        }
        XE_NP_Np2ClosedLoopSpiRow *row=&s->input[s->in_head%NP2_CL_SPI_INPUT_ROWS];
        row->frame_tick=s->frame_tick;row->word[0]=s->word[0];row->word[1]=s->word[1];s->in_head++;
        s->input_words+=s->config.count;
        s->bits[0]=s->bits[1]=0U;s->word[0]=s->word[1]=0U;s->frame_tick+=1600U;
    }
    if(bytes>=2U){s->previous=(uint16_t)((uint16_t)raw[bytes-2U]|((uint16_t)raw[bytes-1U]<<8U));s->previous_bits=16U;}
    else{
        if(!s->previous_bits){s->previous=raw[0];s->previous_bits=8U;}
        else{
            uint16_t older=s->previous_bits==8U?s->previous:(uint16_t)(s->previous>>8U);
            s->previous=(uint16_t)((older&255U)|((uint16_t)raw[0]<<8U));s->previous_bits=16U;
        }
    }
    return 1;
}
uint32_t XE_NP_Np2ClosedLoopSpi_Service(XE_NP_Np2ClosedLoopSpi *s,uint32_t limit)
{
    if(!s || !s->enabled)return 0U;
    if(limit>NP2_CL_SPI_SERVICE_ROWS)limit=NP2_CL_SPI_SERVICE_ROWS;
    uint32_t consumed=0U;
    while(s->in_tail!=s->in_head && consumed<limit){
        XE_NP_Np2ClosedLoopSpiRow row=s->input[s->in_tail%NP2_CL_SPI_INPUT_ROWS];s->in_tail++;consumed++;
        for(unsigned c=0U;c<s->config.count;c++){
            XE_NP_Np2ClosedLoopSpiFilter *f=&s->filter[c];
            f->integ[0]+=(uint32_t)(2048-(int32_t)row.word[c]);
            for(unsigned k=1U;k<4U;k++)f->integ[k]+=f->integ[k-1U];
        }
        if(++s->cic_at<s->ratio)continue;
        s->cic_at=0U;
        for(unsigned c=0U;c<s->config.count;c++){
            XE_NP_Np2ClosedLoopSpiFilter *f=&s->filter[c];uint32_t v=f->integ[3];
            for(unsigned k=0U;k<4U;k++){uint32_t next=v-f->comb[k];f->comb[k]=v;v=next;}
            int32_t signed_v;memcpy(&signed_v,&v,4U);
            int32_t q3=(int32_t)(((int64_t)signed_v*s->reciprocal+2147483648LL)>>32);
            if(q3<INT16_MIN || q3>INT16_MAX){XE_NP_Np2ClosedLoopSpi_Gap(s,row.frame_tick,row.frame_tick,NP2_CL_SPI_REASON_BOUNDS);break;}
            f->fir[s->fir_at]=(int16_t)q3;
        }
        if(s->notice && !s->initialized)break;
        if(++s->fir_at==41U)s->fir_at=0U;
        if(s->intermediate_count<46U)s->intermediate_count++;
        else s->intermediate_count^=1U;
        if(s->intermediate_count<46U || (s->intermediate_count&1U))continue;
        if((uint16_t)(s->out_head-s->out_tail)>=NP2_CL_SPI_OUTPUT_ROWS){
            s->queue_overflows++;XE_NP_Np2ClosedLoopSpi_Gap(s,row.frame_tick,row.frame_tick,NP2_CL_SPI_REASON_QUEUE);break;
        }
        XE_NP_Np2ClosedLoopSpiOutput *out=&s->output[s->out_head%NP2_CL_SPI_OUTPUT_ROWS];
        memset(out,0,sizeof(*out));out->source_tick=row.frame_tick-s->delay_source_ticks;
        uint32_t last=s->offset[0];if(s->config.count==2U && s->offset[1]>last)last=s->offset[1];
        out->input_end_tick=row.frame_tick+last+12U;out->delay_source_ticks=s->delay_source_ticks;
        out->count=s->config.count;out->source_epoch=s->config.source_epoch;
        out->flags=NP2_CL_SPI_VALID|NP2_CL_SPI_TIME_VALID|(s->reset_pending?NP2_CL_SPI_RESET:0U);
        for(unsigned c=0U;c<s->config.count;c++){
            int64_t acc=0;unsigned at=s->fir_at;
            for(unsigned k=0U;k<41U;k++){at=at?at-1U:40U;acc+=(int64_t)s->filter[c].fir[at]*coeff[k];}
            int32_t q3=(int32_t)((acc+4194304LL)>>23);
            if(q3<INT16_MIN || q3>INT16_MAX){XE_NP_Np2ClosedLoopSpi_Gap(s,row.frame_tick,row.frame_tick,NP2_CL_SPI_REASON_BOUNDS);return consumed;}
            out->nominal_q3[c]=(int16_t)q3;
        }
        s->reset_pending=0U;s->out_head++;s->output_rows++;
    }
    return consumed;
}
int XE_NP_Np2ClosedLoopSpi_Pop(XE_NP_Np2ClosedLoopSpi *s,XE_NP_Np2ClosedLoopSpiOutput *out)
{
    if(!s || !out || !s->enabled)return 0;
    if(s->notice){
        memset(out,0,sizeof(*out));out->source_tick=s->gap_first;out->input_end_tick=s->gap_end;
        out->source_epoch=s->config.source_epoch;
        out->flags=NP2_CL_SPI_GAP|NP2_CL_SPI_RESET|(s->config.origin_valid?NP2_CL_SPI_TIME_VALID:0U);
        out->reason=s->reason;s->notice=0U;return 1;
    }
    if(s->out_head==s->out_tail)return 0;
    *out=s->output[s->out_tail%NP2_CL_SPI_OUTPUT_ROWS];s->out_tail++;return 1;
}

#if XE_NP_NP2_CLOSED_LOOP_SPI_ENABLE
static XE_NP_Np2ClosedLoopSpi *port_source;
void XE_NP_Np2ClosedLoopSpi_PortBind(XE_NP_Np2ClosedLoopSpi *s){port_source=s;}
void XE_NP_Np2ClosedLoopSpi_PortOfferP3(const uint8_t *raw,uint32_t bytes,uint64_t first,uint32_t hz,int pressure)
{
    XE_NP_Np2ClosedLoopSpi *s=port_source;
    if(!s)return;
    if(!s->enabled)return;
    if(hz!=s->config.sample_hz){
        XE_NP_Np2ClosedLoopSpi_LoseOrigin(s,NP2_CL_SPI_REASON_SOURCE);return;
    }
#if XE_NP_NP2_CLOSED_LOOP_PERF_ENABLE
    XE_NP_Np2ClPerf *perf=XE_NP_Np2ClCarrier_PortPerf();
    uint32_t began=XE_NP_Np2ClPerf_Begin(perf),words=s->input_words;
#endif
    if(s->config.probe==2U && s->config.lane==0U)
        (void)XE_NP_Np2ClSelected_Offer(s,first+(uint64_t)bytes*8U,pressure);
    else if(s->config.probe==3U && s->config.lane==2U)
        (void)XE_NP_Np2ClosedLoopSpi_Offer(s,raw,bytes,first,pressure);
#if XE_NP_NP2_CLOSED_LOOP_PERF_ENABLE
    XE_NP_Np2ClPerf_End(perf,NP2_CL_PERF_DECODE,began,s->input_words-words);
#endif
}
void XE_NP_Np2ClosedLoopSpi_PortService(int pressure)
{
    XE_NP_Np2ClosedLoopSpi *s=port_source;
    if(!s || !s->enabled || (s->in_head==s->in_tail && s->out_head==s->out_tail && !s->notice))return;
#if XE_NP_NP2_CLOSED_LOOP_PERF_ENABLE
    XE_NP_Np2ClPerf *perf=XE_NP_Np2ClCarrier_PortPerf();
    uint32_t service_start=XE_NP_Np2ClPerf_Begin(perf),filter_start=service_start,rows=0U;
#endif
    if(!pressure){
        uint32_t consumed=XE_NP_Np2ClosedLoopSpi_Service(s,NP2_CL_SPI_SERVICE_ROWS);
#if XE_NP_NP2_CLOSED_LOOP_PERF_ENABLE
        rows=consumed;
#else
        (void)consumed;
#endif
    }
    else if(s->enabled && (s->in_tail!=s->in_head || s->out_tail!=s->out_head))
        XE_NP_Np2ClosedLoopSpi_Gap(s,s->expected,s->expected,NP2_CL_SPI_REASON_PRESSURE);
#if XE_NP_NP2_CLOSED_LOOP_PERF_ENABLE
    XE_NP_Np2ClPerf_End(perf,NP2_CL_PERF_FILTER,filter_start,rows);
#endif
#if XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
    XE_NP_Np2ClCarrier_PortDrain();
#endif
#if XE_NP_NP2_CLOSED_LOOP_PERF_ENABLE
    XE_NP_Np2ClPerf_End(perf,NP2_CL_PERF_SERVICE,service_start,1U);
#endif
}
#endif
