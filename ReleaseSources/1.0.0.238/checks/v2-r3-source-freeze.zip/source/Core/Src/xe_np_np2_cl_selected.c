/* Optional P2 lane0 passive tap. SPI1 reverses wire order in hardware; C15
 * retains only the two words enclosing the selected ADC pair each frame.
 * All RX words still cross the bus. This owns no NP, IMU, or clock output. */
#include "main.h"
#include "xe_np_np2_cl_selected.h"
#include "xe_np_np2_d8_calibration.h"
#include "xe_np_np2_sd_fine_clock.h"
#include <string.h>
#include <limits.h>
#define BOOT_WORDS 3072U
#define ROWS 256U
#define HALF 128U
#define ERRORS (DMA_FLAG_DTE|DMA_FLAG_ULE|DMA_FLAG_USE|DMA_FLAG_TO)
#define STORAGE __attribute__((aligned(32),section("NP_CL_CPU")))
#define DMA_STORAGE __attribute__((aligned(32),section("NP2_CL_SELECTED")))
static DMA_STORAGE uint32_t bootstrap[BOOT_WORDS],selected[ROWS][2],scratch[2];
static __attribute__((aligned(256),section("NP2_CL_SELECTED"))) DMA_NodeTypeDef node[4];
static STORAGE DMA_HandleTypeDef rx;
static STORAGE DMA_QListTypeDef list;
/* Fixed, stopped-observer ABI; no new wire/recording schema. */
STORAGE volatile uint32_t xe_np_np2_cl_selected_diag[32];
STORAGE volatile uint32_t xe_np_np2_cl_selected_guard[16];
STORAGE volatile uint32_t xe_np_np2_cl_selected_clock[10];
STORAGE volatile uint32_t xe_np_np2_cl_selected_calibration[10];
static uint16_t channels[2],offsets[2];static uint8_t count;
static uint32_t enabled,configured,consumed,first_frame,first_word,phase_value;
static int32_t delta;
static uint8_t field_bits[2];
static volatile uint32_t completed,events;
static uint32_t enable_cycles,first_irq_deadline,irq_last,offer_last;
static uint32_t enable_fine,fine_domain,fine_generation,fine_epoch,irq_last_fine,offer_last_fine;
extern void XE_NP_MediaCamera_DmaIrq(void);
static void selected_dma_irq(void);
static void (*dma_irq_owner)(void)=XE_NP_MediaCamera_DmaIrq;
void XE_NP_Np2ClSelected_DmaDispatch(void){dma_irq_owner();}

static uint32_t low_link(const DMA_NodeTypeDef *p){return (uint32_t)(uintptr_t)p&DMA_CLLR_LA;}
static void fault(uint32_t why){xe_np_np2_cl_selected_diag[2]=why;configured=0U;}
static int noncacheable_dma_memory(void)
{
    /* Existing recording region6, read through aliases without changing RNR.
     * Region7 is the sole higher-priority region; reject any overlapping map. */
    uint32_t rnr=MPU->RNR;
    if((MPU->TYPE&0xff00U)!=0x800U || !(MPU->CTRL&1U) || (rnr&~3U)!=4U)return 0;
    uint32_t b6=MPU->RBAR_A2&~31U,l6=MPU->RLAR_A2;
    uint32_t b7=MPU->RBAR_A3&~31U,l7=MPU->RLAR_A3;
    unsigned index=(l6>>1U)&7U;
    uint32_t attr=index<4U?(MPU->MAIR0>>(index*8U)):(MPU->MAIR1>>((index-4U)*8U));
    xe_np_np2_cl_selected_guard[12]=b6;xe_np_np2_cl_selected_guard[13]=l6;
    xe_np_np2_cl_selected_guard[14]=MPU->MAIR1;xe_np_np2_cl_selected_guard[15]=b7;
    if(!(l6&1U) || (attr&255U)!=0x44U)return 0;
    const uintptr_t bases[4]={(uintptr_t)bootstrap,(uintptr_t)selected,(uintptr_t)scratch,(uintptr_t)node};
    const uint32_t sizes[4]={sizeof(bootstrap),sizeof(selected),sizeof(scratch),sizeof(node)};
    for(unsigned i=0U;i<4U;i++){
        uintptr_t end=bases[i]+sizes[i]-1U;
        if(end<bases[i] || bases[i]<b6 || end>((l6&~31U)|31U) ||
           ((l7&1U) && bases[i]<=((l7&~31U)|31U) && end>=b7))return 0;
    }
    return rnr==MPU->RNR && (((uintptr_t)&node[0]^((uintptr_t)&node[4]-1U))&~65535U)==0U;
}
static int owner_quiet(void)
{
    volatile uint32_t *g=xe_np_np2_cl_selected_guard;
    g[0]=0x4752504EU;g[1]=1U;g[2]=0U;g[3]=SystemCoreClock;g[4]=DCACHE1->CR;
    g[5]=SPI1->CR1;g[6]=SPI1->CFG1;g[7]=GPDMA1_Channel15->CCR;g[8]=DBGMCU->CR;
    g[9]=NVIC->ISER[((uint32_t)GPDMA1_Channel15_IRQn)>>5U];g[10]=MPU->CTRL;g[11]=MPU->RNR;
    if(g[5]&(SPI_CR1_SPE|SPI_CR1_CSTART))g[2]|=1U;
    if(g[6]&(SPI_CFG1_RXDMAEN|SPI_CFG1_TXDMAEN))g[2]|=2U;
    if(g[7]&(DMA_CCR_EN|DMA_CCR_SUSP|DMA_CCR_RESET))g[2]|=4U;
    if(g[8]&DBGMCU_CR_TRACE_IOEN)g[2]|=8U;
    if(g[9]&(1UL<<((uint32_t)GPDMA1_Channel15_IRQn&31U)))g[2]|=16U;
    if(NVIC->ISER[((uint32_t)SPI1_IRQn)>>5U]&(1UL<<((uint32_t)SPI1_IRQn&31U)))g[2]|=128U;
    if(NVIC->ISPR[((uint32_t)SPI1_IRQn)>>5U]&(1UL<<((uint32_t)SPI1_IRQn&31U)))g[2]|=256U;
    if(NVIC->ISPR[((uint32_t)GPDMA1_Channel15_IRQn)>>5U]&(1UL<<((uint32_t)GPDMA1_Channel15_IRQn&31U)))g[2]|=512U;
    if(SPI1->IER)g[2]|=1024U;
    if(g[3]!=128000000U)g[2]|=32U;
    if(!noncacheable_dma_memory())g[2]|=64U;
    return g[2]==0U;
}
static void config_node(DMA_NodeConfTypeDef *c)
{
    memset(c,0,sizeof(*c));c->NodeType=DMA_GPDMA_2D_NODE;
    c->Init.Request=GPDMA1_REQUEST_SPI1_RX;c->Init.BlkHWRequest=DMA_BREQ_SINGLE_BURST;
    c->Init.Direction=DMA_PERIPH_TO_MEMORY;c->Init.SrcInc=DMA_SINC_FIXED;
    c->Init.DestInc=DMA_DINC_INCREMENTED;c->Init.SrcDataWidth=DMA_SRC_DATAWIDTH_WORD;
    c->Init.DestDataWidth=DMA_DEST_DATAWIDTH_WORD;c->Init.Priority=DMA_LOW_PRIORITY_LOW_WEIGHT;
    c->Init.SrcBurstLength=1U;c->Init.DestBurstLength=1U;
    c->Init.TransferAllocatedPort=DMA_SRC_ALLOCATED_PORT0|DMA_DEST_ALLOCATED_PORT1;
    c->Init.TransferEventMode=DMA_TCEM_LAST_LL_ITEM_TRANSFER;
    c->DataHandlingConfig.DataAlignment=DMA_DATA_RIGHTALIGN_ZEROPADDED;
    c->TriggerConfig.TriggerMode=DMA_TRIGM_SINGLE_BURST_TRANSFER;
    c->TriggerConfig.TriggerPolarity=DMA_TRIG_POLARITY_MASKED;
    c->SrcAddress=(uint32_t)(uintptr_t)&SPI1->RXDR;c->RepeatBlockConfig.RepeatCount=1U;
}
int XE_NP_Np2ClSelected_Prepare(void)
{
    /* Retain our old ownership flag if an earlier stop did not retire C15.
     * A new attempt may not forget/reassign a live optional DMA owner. */
    if(enabled){fault(12U);return -1;}
    memset((void*)xe_np_np2_cl_selected_diag,0,sizeof(xe_np_np2_cl_selected_diag));
    memset((void*)xe_np_np2_cl_selected_clock,0,sizeof(xe_np_np2_cl_selected_clock));
    memset((void*)xe_np_np2_cl_selected_calibration,0,sizeof(xe_np_np2_cl_selected_calibration));
    xe_np_np2_cl_selected_diag[0]=0x5332504EU;xe_np_np2_cl_selected_diag[1]=1U;
    enabled=configured=consumed=completed=events=0U;
    enable_cycles=first_irq_deadline=irq_last=offer_last=0U;
    enable_fine=fine_domain=fine_generation=fine_epoch=irq_last_fine=offer_last_fine=0U;
    if(!XE_NP_Np2ClCarrier_SelectedRequest(channels,&count))return 0;
    if(!owner_quiet()){fault(1U);return -1;}
    /* IRQ and both physical owners are quiet. Claim before fallible setup so
     * even a partially prepared private receiver can be retired at Stop. */
    dma_irq_owner=selected_dma_irq;enabled=1U;
    __HAL_RCC_GPIOB_CLK_ENABLE();__HAL_RCC_SPI1_CONFIG(RCC_SPI1CLKSOURCE_SYSCLK);
    __HAL_RCC_SPI1_CLK_ENABLE();__HAL_RCC_SPI1_FORCE_RESET();__HAL_RCC_SPI1_RELEASE_RESET();
    GPIO_InitTypeDef p={0};p.Pin=GPIO_PIN_3|GPIO_PIN_5;p.Mode=GPIO_MODE_AF_PP;
    p.Pull=GPIO_NOPULL;p.Speed=GPIO_SPEED_FREQ_VERY_HIGH;p.Alternate=GPIO_AF5_SPI1;
    HAL_GPIO_Init(GPIOB,&p); /* Slave SCK/MOSI are inputs. No MISO/NSS/clock output. */
    SPI1->CFG1=SPI_DATASIZE_32BIT|SPI_FIFO_THRESHOLD_01DATA;
    SPI1->CFG2=SPI_DIRECTION_2LINES_RXONLY|SPI_NSS_SOFT;
    SPI1->CR1=0U;SPI1->CR2=0U;SPI1->IER=0U;SPI1->IFCR=0xFFFFFFFFU;
    memset(&rx,0,sizeof(rx));memset(&list,0,sizeof(list));memset(node,0,sizeof(node));
    rx.Instance=GPDMA1_Channel15;rx.InitLinkedList.Priority=DMA_LOW_PRIORITY_LOW_WEIGHT;
    rx.InitLinkedList.LinkStepMode=DMA_LSM_FULL_EXECUTION;
    rx.InitLinkedList.LinkAllocatedPort=DMA_LINK_ALLOCATED_PORT1;
    rx.InitLinkedList.TransferEventMode=DMA_TCEM_LAST_LL_ITEM_TRANSFER;
    rx.InitLinkedList.LinkedListMode=DMA_LINKEDLIST_CIRCULAR;
    if(HAL_DMAEx_List_Init(&rx)!=HAL_OK){fault(2U);goto bad;}
    DMA_NodeConfTypeDef c;config_node(&c);c.DataSize=sizeof(bootstrap);
    c.DstAddress=(uint32_t)(uintptr_t)bootstrap;
    if(HAL_DMAEx_List_BuildNode(&c,&node[0])!=HAL_OK)goto bad;
    /* Safe fallback: discard forever if calibration misses its cold deadline.
     * This inactive node alone is replaced, never the running bootstrap. */
    c.Init.DestInc=DMA_DINC_FIXED;c.DataSize=200U;c.DstAddress=(uint32_t)(uintptr_t)scratch;
    c.RepeatBlockConfig.RepeatCount=2048U;
    if(HAL_DMAEx_List_BuildNode(&c,&node[1])!=HAL_OK)goto bad;
    if(HAL_DMAEx_List_InsertNode_Tail(&list,&node[0])!=HAL_OK ||
       HAL_DMAEx_List_InsertNode_Tail(&list,&node[1])!=HAL_OK ||
       HAL_DMAEx_List_SetCircularModeConfig(&list,&node[1])!=HAL_OK ||
       HAL_DMAEx_List_LinkQ(&rx,&list)!=HAL_OK)goto bad;
    GPDMA1_Channel15->CFCR=DMA_FLAG_TC|DMA_FLAG_HT|ERRORS|DMA_FLAG_SUSP;
    HAL_NVIC_DisableIRQ(GPDMA1_Channel15_IRQn);HAL_NVIC_ClearPendingIRQ(GPDMA1_Channel15_IRQn);
    if(HAL_DMAEx_List_Start(&rx)!=HAL_OK)goto bad;
    SET_BIT(SPI1->CFG1,SPI_CFG1_RXDMAEN);enabled=1U;
    xe_np_np2_cl_selected_diag[3]=(uint32_t)(uintptr_t)bootstrap;
    xe_np_np2_cl_selected_diag[4]=(uint32_t)(uintptr_t)selected;return 1;
bad:if(!xe_np_np2_cl_selected_diag[2])fault(3U);XE_NP_Np2ClSelected_Stop();return -1;
}
void XE_NP_Np2ClSelected_Enable(void)
{
    if(!enabled)return;
    XE_NP_Np2SdFinePoint p={0};
    /* Pure observation only. Never call ReadOwned64 here: its failure path
     * invalidates the primary owner's timer, which optional DSP may not do. */
    if(!XE_NP_Np2SdFineClock_ReadIrq(HAL_GetTick(),&p) ||
       p.counter_hz!=XE_NP_NP2_SD_FINE_HZ || !p.domain){fault(13U);return;}
    enable_fine=p.counter;fine_domain=p.domain;
    xe_np_np2_cl_selected_clock[0]=0x4B43504EU;xe_np_np2_cl_selected_clock[1]=1U;
    xe_np_np2_cl_selected_clock[2]=enable_fine;xe_np_np2_cl_selected_clock[3]=fine_domain;
    enable_cycles=DWT->CYCCNT;SET_BIT(SPI1->CR1,SPI_CR1_SPE);
}
static int read_bound_fine(uint32_t *now)
{
    XE_NP_Np2SdFinePoint64 p={0};
    if(!XE_NP_Np2SdFineClock_Read64Irq(HAL_GetTick(),&p) ||
       p.domain!=fine_domain || p.counter_hz!=XE_NP_NP2_SD_FINE_HZ ||
       p.generation!=fine_generation || p.source_epoch!=fine_epoch)return 0;
    *now=(uint32_t)p.counter;return 1;
}
static void selected_dma_irq(void)
{
    uint32_t began=DWT->CYCCNT;
    uint32_t f=GPDMA1_Channel15->CSR;GPDMA1_Channel15->CFCR=f&(DMA_FLAG_TC|ERRORS);
    if(!configured || xe_np_np2_cl_selected_diag[2]){
        HAL_NVIC_DisableIRQ(GPDMA1_Channel15_IRQn);return;
    }
    if(f&ERRORS){fault(4U);HAL_NVIC_DisableIRQ(GPDMA1_Channel15_IRQn);return;}
    if(f&DMA_FLAG_TC){
        uint32_t interval=began-irq_last;
        uint32_t now;
        if(!read_bound_fine(&now)){fault(14U);HAL_NVIC_DisableIRQ(GPDMA1_Channel15_IRQn);return;}
        /* Existing owned1MHz TIM5 continues through WFI. Absolute expected
         * deadlines detect coalesced TCs despite prior delayed delivery. */
        if((int32_t)(now-first_irq_deadline)>1000 ||
           (events && now-irq_last_fine>9600U)){
            fault(11U);HAL_NVIC_DisableIRQ(GPDMA1_Channel15_IRQn);return;
        }
        if(events && interval>xe_np_np2_cl_selected_diag[31])xe_np_np2_cl_selected_diag[31]=interval;
        if(events && now-irq_last_fine>xe_np_np2_cl_selected_clock[7])
            xe_np_np2_cl_selected_clock[7]=now-irq_last_fine;
        irq_last_fine=now;xe_np_np2_cl_selected_clock[6]=now;
        irq_last=began;first_irq_deadline+=6400U;completed+=HALF;events++;
    }
    uint32_t n=DWT->CYCCNT-began;uint64_t total=(uint64_t)xe_np_np2_cl_selected_diag[22]|
        ((uint64_t)xe_np_np2_cl_selected_diag[23]<<32U);total+=n;
    xe_np_np2_cl_selected_diag[22]=(uint32_t)total;xe_np_np2_cl_selected_diag[23]=(uint32_t)(total>>32U);
    if(n>xe_np_np2_cl_selected_diag[24])xe_np_np2_cl_selected_diag[24]=n;
    xe_np_np2_cl_selected_diag[21]++;
}
static uint32_t spi_word(uint32_t bit)
{
    uint32_t n=bit>>5U,s=bit&31U;
    return s?(bootstrap[n]<<s)|(bootstrap[n+1U]>>(32U-s)):bootstrap[n];
}
static uint32_t sync4_matches(const uint8_t *pssi,uint32_t at,uint32_t wanted)
{
    uint32_t raw;
    if(at<=1596U)memcpy(&raw,pssi+at,sizeof(raw));
    else{
        raw=0U;
        for(unsigned b=0U;b<4U;b++){
            uint32_t p=at+b;if(p>=1600U)p-=1600U;
            raw|=(uint32_t)pssi[p]<<(b*8U);
        }
    }
    uint32_t x=((raw>>3U)&0x07070707U)^wanted;
    uint32_t bad=(x|(x>>1U)|(x>>2U))&0x01010101U;
    return 4U-((bad*0x01010101U)>>24U);
}
int XE_NP_Np2ClSelected_Calibrate(const uint8_t *pssi,uint32_t ticks)
{
    if(!enabled)return 0;if(configured)return 1;if(xe_np_np2_cl_selected_diag[2])return -1;
    volatile uint32_t *cal=xe_np_np2_cl_selected_calibration;
    cal[0]=1U;cal[1]=GPDMA1_Channel15->CBR1;cal[2]=GPDMA1_Channel15->CLLR;cal[3]=SPI1->SR;
    cal[8]=GPDMA1_Channel15->CDAR;
    if(!pssi || ticks<4800U || (GPDMA1_Channel15->CSR&ERRORS) || (SPI1->SR&SPI_FLAG_OVR))goto bad;
    uint32_t began=DWT->CYCCNT;
    if((GPDMA1_Channel15->CBR1&DMA_CBR1_BNDT)>sizeof(bootstrap)-512U ||
       (GPDMA1_Channel15->CLLR&DMA_CLLR_LA)!=low_link(&node[1]))goto bad;
    cal[0]=2U;
    /* Compare one common settled interval after a complete superframe.
     * Initial receiver/partial-row bits are not accepted as alignment proof. */
    uint32_t words[8]={0},matches=0U;int32_t d=0;
    for(unsigned i=0U;i<256U;i++)words[i>>5U]=(words[i>>5U]<<1U)|((pssi[1600U+i]>>3U)&1U);
    for(int32_t k=-1600;k<1600;k++){
        uint32_t at=(uint32_t)(1600+k);
        if(spi_word(at)!=words[0])continue;unsigned n=1U;
        for(;n<8U && spi_word(at+n*32U)==words[n];n++);
        if(n==8U){d=k;matches++;}
    }
    cal[4]=matches;
    if(matches!=1U)goto bad;
    xe_np_np2_cl_selected_diag[19]=DWT->CYCCNT-began;
    cal[0]=3U;
    uint8_t expected[16][4];
    for(unsigned f=0U;f<16U;f++)for(unsigned b=0U;b<4U;b++)
        expected[f][b]=XE_NP_Np2D8ExpectedSync(f*100U+b);
    uint32_t packed[2]={0U,0U};
    for(unsigned f=0U;f<2U;f++)for(unsigned b=0U;b<4U;b++)
        packed[f]|=(uint32_t)expected[f][b]<<(b*8U);
    uint32_t best=0U,runner=0U,phase=0U,pm=0U;
    for(uint32_t k=0U;k<1600U;k++){
        uint32_t at0=k?1600U-k:0U,at1=at0+100U;
        if(at1>=1600U)at1-=1600U;
        uint32_t screen=sync4_matches(pssi,at0,packed[0])+sync4_matches(pssi,at1,packed[1]);
        if(screen<6U)continue;
        uint32_t score=0U;
        for(unsigned f=0U;f<16U;f++)for(unsigned b=0U;b<4U;b++){
            uint32_t at=f*100U+b+1600U-k;if(at>=1600U)at-=1600U;
            uint8_t wanted=expected[f][b];
            for(;at<4800U;at+=1600U)score+=((pssi[at]>>3U)&7U)==wanted;
        }
        if(score>best){runner=best;best=score;phase=k;pm=1U;}
        else if(score==best){runner=score;pm++;}else if(score>runner)runner=score;
    }
    xe_np_np2_cl_selected_diag[20]=DWT->CYCCNT-began;
    cal[5]=best;cal[6]=runner;
    if(pm!=1U || best<164U || best<runner+32U)goto bad;
    cal[0]=4U;
    uint32_t lo=UINT32_MAX,hi=0U,header=(1600U-phase)%1600U;
    for(unsigned i=0U;i<count;i++){
        /* Keep every field anchored to the same probe superframe. A field
         * after the global1600-bit boundary is not from the previous row. */
        uint32_t c=channels[i],o=header+(c%32U)/2U*100U+4U+((c/32U)*2U+(c&1U))*12U;
        offsets[i]=(uint16_t)o;if(o<lo)lo=o;if(o+12U>hi)hi=o+12U;
    }
    /* The selected native ADC pair must fit two adjacent hardware words. */
    uint32_t frame=(uint32_t)((BOOT_WORDS*32U-(int64_t)d)/1600U)+2U;
    uint32_t end=(uint32_t)(((int64_t)frame*1600U+hi+d+31U)/32U)*32U;
    uint32_t prefix=end-BOOT_WORDS*32U-1600U;
    if(prefix>3200U && frame){frame--;end-=1600U;prefix-=1600U;}
    if((int64_t)end-64U>(int64_t)frame*1600U+lo+d || end<BOOT_WORDS*32U+1600U)goto bad;
    for(unsigned i=0U;i<count;i++){
        int64_t b=(int64_t)frame*1600U+offsets[i]+d-(end-64U);
        if(b<0 || b>52)goto bad;field_bits[i]=(uint8_t)b;
    }
    if(!prefix || prefix>3200U || (prefix&31U))goto bad;
    cal[0]=5U;
    XE_NP_Np2SdFinePoint64 fp={0};
    if(!XE_NP_Np2SdFineClock_Read64Irq(HAL_GetTick(),&fp) || fp.domain!=fine_domain ||
       fp.counter_hz!=XE_NP_NP2_SD_FINE_HZ ||
       !XE_NP_Np2SdFineClock_BoundQualified64(fp.domain,fp.generation,fp.source_epoch))goto bad;
    fine_generation=fp.generation;fine_epoch=fp.source_epoch;
    xe_np_np2_cl_selected_clock[4]=fine_generation;xe_np_np2_cl_selected_clock[5]=fine_epoch;
    cal[7]=(uint32_t)fp.counter-enable_fine;
    /* CBR1 proves bootstrap is still running with >=512 requests/512us margin.
     * GPDMA loads the next linked node only at block completion. */
    if((GPDMA1_Channel15->CBR1&DMA_CBR1_BNDT)<2048U ||
       (GPDMA1_Channel15->CLLR&DMA_CLLR_LA)!=low_link(&node[1]) ||
       GPDMA1_Channel15->CDAR<(uint32_t)(uintptr_t)bootstrap ||
       GPDMA1_Channel15->CDAR>(uint32_t)(uintptr_t)(bootstrap+BOOT_WORDS)-2048U)goto bad;
    cal[0]=6U;
    DMA_NodeConfTypeDef c;config_node(&c);c.Init.DestBurstLength=2U;
    c.Init.TransferEventMode=DMA_TCEM_REPEATED_BLOCK_TRANSFER;
    c.DataSize=200U;c.RepeatBlockConfig.RepeatCount=HALF;
    c.RepeatBlockConfig.DestAddrOffset=-8;c.RepeatBlockConfig.BlkDestAddrOffset=8;
    for(unsigned i=0U;i<2U;i++){
        c.DstAddress=(uint32_t)(uintptr_t)&selected[i*HALF][0];
        if(HAL_DMAEx_List_BuildNode(&c,&node[2U+i])!=HAL_OK)goto bad;
    }
    /* Static2D node's CLLR is register7. All updated node fields are immutable
     * before publishing the still-inactive prologue's link. */
    node[2].LinkRegisters[7]=node[0].LinkRegisters[7]&~DMA_CLLR_LA;
    node[2].LinkRegisters[7]|=low_link(&node[3]);
    node[3].LinkRegisters[7]=node[2].LinkRegisters[7]&~DMA_CLLR_LA;
    node[3].LinkRegisters[7]|=low_link(&node[2]);
    config_node(&c);c.Init.DestInc=DMA_DINC_FIXED;c.DataSize=prefix/8U;
    c.DstAddress=(uint32_t)(uintptr_t)scratch;
    DMA_NodeTypeDef prologue;memset(&prologue,0,sizeof(prologue));
    if(HAL_DMAEx_List_BuildNode(&c,&prologue)!=HAL_OK)goto bad;
    cal[0]=7U;
    prologue.LinkRegisters[7]=node[2].LinkRegisters[7]&~DMA_CLLR_LA;
    prologue.LinkRegisters[7]|=low_link(&node[2]);
    uint32_t key=__get_PRIMASK();__disable_irq();uint32_t publish=DWT->CYCCNT;
    if((GPDMA1_Channel15->CBR1&DMA_CBR1_BNDT)<1024U ||
       (GPDMA1_Channel15->CLLR&DMA_CLLR_LA)!=low_link(&node[1])){
        __set_PRIMASK(key);goto bad;}
    memcpy(&node[1],&prologue,sizeof(prologue));__DMB();
    xe_np_np2_cl_selected_diag[20]=DWT->CYCCNT-publish;__set_PRIMASK(key);
    first_frame=frame;first_word=end-64U;phase_value=phase;delta=d;
    first_irq_deadline=enable_fine+(BOOT_WORDS*32U+prefix+HALF*1600U)/32U;
    configured=1U;
    GPDMA1_Channel15->CFCR=DMA_FLAG_TC|DMA_FLAG_HT;
    SET_BIT(GPDMA1_Channel15->CCR,DMA_CCR_TCIE|DMA_CCR_DTEIE|DMA_CCR_ULEIE|DMA_CCR_USEIE|DMA_CCR_TOIE);
    HAL_NVIC_SetPriority(GPDMA1_Channel15_IRQn,7U,0U);HAL_NVIC_EnableIRQ(GPDMA1_Channel15_IRQn);
    xe_np_np2_cl_selected_diag[5]=phase;xe_np_np2_cl_selected_diag[6]=(uint32_t)d;
    xe_np_np2_cl_selected_diag[7]=frame;xe_np_np2_cl_selected_diag[8]=first_word;
    xe_np_np2_cl_selected_diag[9]=best;xe_np_np2_cl_selected_diag[10]=runner;
    xe_np_np2_cl_selected_diag[11]=prefix;
    xe_np_np2_cl_selected_diag[19]=DWT->CYCCNT-began;cal[0]=8U;
    {XE_NP_Np2SdFinePoint p={0};cal[9]=XE_NP_Np2SdFineClock_ReadIrq(HAL_GetTick(),&p)&&p.domain==fine_domain?p.counter-enable_fine:UINT32_MAX;}
    return 1;
bad:
    {XE_NP_Np2SdFinePoint p={0};cal[9]=XE_NP_Np2SdFineClock_ReadIrq(HAL_GetTick(),&p)&&p.domain==fine_domain?p.counter-enable_fine:UINT32_MAX;}
    fault(5U);return -1;
}
int XE_NP_Np2ClSelected_Proof(uint16_t *phase)
{if(!configured || xe_np_np2_cl_selected_diag[2])return 0;*phase=(uint16_t)phase_value;return 1;}
static uint32_t frontier(void)
{
    uint32_t a=completed,b=GPDMA1_Channel15->CBR1,link=GPDMA1_Channel15->CLLR;
    if(a!=completed || (GPDMA1_Channel15->CSR&(ERRORS|DMA_FLAG_TC)) ||
       (link&DMA_CLLR_LA)!=(a%(ROWS)?low_link(&node[2]):low_link(&node[3])))return consumed;
    return a+(HALF-1U)-((b&DMA_CBR1_BRC)>>DMA_CBR1_BRC_Pos);
}
static void note_offer(void)
{
    uint32_t now=DWT->CYCCNT;
    if(offer_last && now-offer_last>xe_np_np2_cl_selected_diag[25])
        xe_np_np2_cl_selected_diag[25]=now-offer_last;
    offer_last=now;
    uint32_t fine;
    if(!read_bound_fine(&fine)){fault(14U);return;}
    if(offer_last_fine && fine-offer_last_fine>xe_np_np2_cl_selected_clock[8])
        xe_np_np2_cl_selected_clock[8]=fine-offer_last_fine;
    offer_last_fine=fine;xe_np_np2_cl_selected_clock[9]=fine;
}
int XE_NP_Np2ClSelected_Offer(XE_NP_Np2ClosedLoopSpi *s,uint64_t saved_end,int pressure)
{
    if(!s || !s->enabled || !s->config.origin_valid)return 0;
    note_offer();
    if(!configured || xe_np_np2_cl_selected_diag[2]){
        XE_NP_Np2ClosedLoopSpi_LoseOrigin(s,NP2_CL_SPI_REASON_SOURCE);return -1;}
    if((GPDMA1_Channel15->CSR&ERRORS) || (SPI1->SR&SPI_FLAG_OVR)){
        fault(6U);XE_NP_Np2ClosedLoopSpi_LoseOrigin(s,NP2_CL_SPI_REASON_SOURCE);return -1;}
    uint32_t end=frontier(),lag=end-consumed;
    if(lag>xe_np_np2_cl_selected_diag[12])xe_np_np2_cl_selected_diag[12]=lag;
    if(lag>=ROWS){fault(7U);XE_NP_Np2ClosedLoopSpi_LoseOrigin(s,NP2_CL_SPI_REASON_QUEUE);return -1;}
    while(consumed<end){
        uint64_t tick=(uint64_t)(first_frame+consumed)*1600U;
        uint32_t max=offsets[0]+12U;if(count==2U && offsets[1]+12U>max)max=offsets[1]+12U;
        if(tick+max>saved_end)break;
        if(pressure){XE_NP_Np2ClosedLoopSpi_Gap(s,tick,tick+1600U,NP2_CL_SPI_REASON_PRESSURE);consumed++;continue;}
        if((uint16_t)(s->in_head-s->in_tail)>=NP2_CL_SPI_INPUT_ROWS){
            s->queue_overflows++;XE_NP_Np2ClosedLoopSpi_Gap(s,tick,tick+1600U,NP2_CL_SPI_REASON_QUEUE);return 0;}
        __DMB();uint32_t w0=selected[consumed%ROWS][0],w1=selected[consumed%ROWS][1];
        if(frontier()-consumed>=ROWS){fault(8U);XE_NP_Np2ClosedLoopSpi_LoseOrigin(s,NP2_CL_SPI_REASON_QUEUE);return -1;}
        XE_NP_Np2ClosedLoopSpiRow *row=&s->input[s->in_head%NP2_CL_SPI_INPUT_ROWS];row->frame_tick=tick;
        for(unsigned i=0U;i<count;i++){
            uint32_t b=field_bits[i];
            uint64_t bits=((uint64_t)w0<<32U)|w1;row->word[i]=(uint16_t)((bits>>(52U-b))&4095U);
        }
        s->in_head++;s->input_words+=count;s->initialized=1U;s->expected=tick+1600U;
        s->frame_tick=tick+1600U;consumed++;
    }
    xe_np_np2_cl_selected_diag[13]=completed;xe_np_np2_cl_selected_diag[14]=consumed;
    xe_np_np2_cl_selected_diag[15]=events;return 1;
}
void XE_NP_Np2ClSelected_Stop(void)
{
    if(!enabled)return;
    xe_np_np2_cl_selected_diag[26]=configured?frontier():0U;
    xe_np_np2_cl_selected_diag[27]=GPDMA1_Channel15->CBR1;
    xe_np_np2_cl_selected_diag[28]=GPDMA1_Channel15->CLLR;
    xe_np_np2_cl_selected_diag[29]=SPI1->CFG1;xe_np_np2_cl_selected_diag[30]=SPI1->CFG2;
    HAL_NVIC_DisableIRQ(GPDMA1_Channel15_IRQn);
    if(GPDMA1_Channel15->CCR&DMA_CCR_EN){
        SET_BIT(GPDMA1_Channel15->CCR,DMA_CCR_SUSP);__DSB();
        for(uint32_t n=0U;n<1024U && (GPDMA1_Channel15->CCR&DMA_CCR_EN) &&
            !(GPDMA1_Channel15->CSR&DMA_FLAG_SUSP);n++)__NOP();
    }
    if(!(GPDMA1_Channel15->CCR&DMA_CCR_EN) || (GPDMA1_Channel15->CSR&DMA_FLAG_SUSP)){
        CLEAR_BIT(SPI1->CFG1,SPI_CFG1_RXDMAEN);CLEAR_BIT(SPI1->CR1,SPI_CR1_SPE);
        SET_BIT(GPDMA1_Channel15->CCR,DMA_CCR_RESET);__DSB();
        for(uint32_t n=0U;n<1024U && (GPDMA1_Channel15->CCR&DMA_CCR_EN);n++)__NOP();
    }
    xe_np_np2_cl_selected_diag[16]=GPDMA1_Channel15->CCR;
    xe_np_np2_cl_selected_diag[17]=GPDMA1_Channel15->CSR;
    xe_np_np2_cl_selected_diag[18]=SPI1->SR;
    if(GPDMA1_Channel15->CCR&DMA_CCR_EN)fault(10U);
    else{
        /* Only our retired channel may clear its flags/pending delivery.
         * Camera start later enables this same IRQ without clearing NVIC. */
        GPDMA1_Channel15->CFCR=DMA_FLAG_TC|DMA_FLAG_HT|ERRORS|DMA_FLAG_SUSP;
        HAL_NVIC_ClearPendingIRQ(GPDMA1_Channel15_IRQn);
        enabled=0U;dma_irq_owner=XE_NP_MediaCamera_DmaIrq;
    }
}
