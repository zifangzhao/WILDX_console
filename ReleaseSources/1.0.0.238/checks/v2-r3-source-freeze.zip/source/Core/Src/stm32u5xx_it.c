#include "xe_np_np2_cl_selected.h"
/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32u5xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32u5xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "CE32_HJ580.h"
#include "xe_np_np2_sd_ble.h"
#include "CE32_UART_INTERCOM.h"
#include "xe_np_app.h"
#include "xe_np_usb_stream.h"
#include "xe_np_np2_capture_port.h"
#include "xe_np_np2_sd_port.h"
#include "xe_np_np2_triple_synthetic_sd.h"
#include "xe_np_np2_live_sd.h"
#include "xe_np_np2_usb_source.h"
#include "xe_np_usb_unified.h"
#include "xe_np_media_app.h"
#include "xe_np_media_adc.h"
#include "xe_np_media_camera.h"
#if XE_NP_USB_UNIFIED_ENABLE
#include "xe_np_usb_fault.h"
#endif
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern SD_HandleTypeDef hsd1;
extern DMA_HandleTypeDef hdma_usart2_tx;
extern PCD_HandleTypeDef hpcd_USB_OTG_HS;

/* USER CODE BEGIN EV */
extern I2C_HandleTypeDef hi2c5;
extern I2C_HandleTypeDef hi2c6;

void I2C5_EV_IRQHandler(void) { HAL_I2C_EV_IRQHandler(&hi2c5); }
#if XE_NP_NP2_USB_SOURCE_ENABLE
void I2C2_EV_IRQHandler(void) { XE_NP_Np2UsbSource_I2cEventIrq(0U); }
void I2C2_ER_IRQHandler(void) { XE_NP_Np2UsbSource_I2cErrorIrq(0U); }
void I2C3_EV_IRQHandler(void) { XE_NP_Np2UsbSource_I2cEventIrq(1U); }
void I2C3_ER_IRQHandler(void) { XE_NP_Np2UsbSource_I2cErrorIrq(1U); }
void I2C4_EV_IRQHandler(void) { XE_NP_Np2UsbSource_I2cEventIrq(2U); }
void I2C4_ER_IRQHandler(void) { XE_NP_Np2UsbSource_I2cErrorIrq(2U); }
#endif
void I2C5_ER_IRQHandler(void) { HAL_I2C_ER_IRQHandler(&hi2c5); }
void I2C6_EV_IRQHandler(void) { HAL_I2C_EV_IRQHandler(&hi2c6); }
void I2C6_ER_IRQHandler(void) { HAL_I2C_ER_IRQHandler(&hi2c6); }

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
   while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Prefetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32U5xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32u5xx.s).                    */
/******************************************************************************/

/* USER CODE BEGIN 1 */

void GPDMA1_Channel12_IRQHandler(void)
{
#if XE_NP_NP2_CAPTURE_PORT_ENABLE
  XE_NP_Np2CapturePort_DmaIrq();
#elif !XE_NP_V2_MEDIA_ENABLE
  XE_NP_App_GpioeDmaIrqHandler();
#endif
}

void DCMI_PSSI_IRQHandler(void)
{
#if XE_NP_NP2_CAPTURE_PORT_ENABLE
  XE_NP_Np2CapturePort_PssiIrq();
#elif !XE_NP_V2_MEDIA_ENABLE
  XE_NP_App_PssiIrqHandler();
#endif
}

#if !XE_NP_NP2_LIVE_SD_ENABLE && !XE_NP_V2_MEDIA_ENABLE && !XE_NP_NP2_PSSI_TEST_DIAG_ENABLE
/* The exclusive live-SD image never enables these legacy IRQs. Keep their
 * startup-vector defaults instead of linking the NP1/USB/BLE application. */
void GPDMA1_Channel11_IRQHandler(void)
{
  HAL_DMA_IRQHandler(&hdma_usart2_tx);
}

void GPDMA1_Channel10_IRQHandler(void)
{
  XE_NP_UsbStream_StagingDmaIrqHandler();
}

void GPDMA1_Channel9_IRQHandler(void)
{
  XE_NP_App_SpiTapDmaIrqHandler();
}

void LPDMA1_Channel0_IRQHandler(void)
{
  XE_NP_UsbStream_StagingDmaIrqHandler();
}

void GPDMA1_Channel13_IRQHandler(void)
{
  XE_NP_App_GpiodDmaIrqHandler();
}

void GPDMA1_Channel14_IRQHandler(void)
{
  XE_NP_App_SdStageDmaIrqHandler();
  XE_NP_UsbStream_StagingDmaIrqHandler();
}
#endif

void SDMMC1_IRQHandler(void)
{
#if XE_NP_V2_MEDIA_ENABLE
  XE_NP_MediaApp_SdIrq();
#elif XE_NP_NP2_TRIPLE_SYNTHETIC_SD_ENABLE
  XE_NP_Np2TripleSyntheticSd_Irq(&hsd1);
#elif XE_NP_NP2_LIVE_SD_ENABLE
  XE_NP_Np2LiveSd_Irq(&hsd1);
#elif XE_NP_NP2_SD_PORT_ENABLE
  XE_NP_Np2SdPort_Irq();
#else
  HAL_SD_IRQHandler(&hsd1);
#endif
}

void OTG_HS_IRQHandler(void)
{
#if (XE_NP_IMAGE_ROLE != XE_NP_IMAGE_SD_APP)
#if XE_NP_USB_UNIFIED_ENABLE
  XE_NP_UsbFault_BeforeIrq(&hpcd_USB_OTG_HS);
#endif
  HAL_PCD_IRQHandler(&hpcd_USB_OTG_HS);
#endif
}

#if XE_NP_NP2_SD_BLE_ENABLE
void USART2_IRQHandler(void){XE_NP_Np2SdBle_Irq();}
#endif
#if XE_NP_V2_MEDIA_ENABLE || XE_NP_V2_AUX_ENABLE
void SPI1_IRQHandler(void) { XE_NP_MediaCamera_SpiIrq(); }
void GPDMA1_Channel15_IRQHandler(void) { XE_NP_Np2ClSelected_DmaDispatch(); }
void GPDMA1_Channel7_IRQHandler(void) { XE_NP_MediaAdc_DmaIrq(); }
#if XE_NP_V2_MEDIA_ENABLE
void USART2_IRQHandler(void) { XE_NP_MediaBle_Irq(); }
#endif
void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *spi) { XE_NP_MediaCamera_HalRxComplete(spi); }
void HAL_SPI_ErrorCallback(SPI_HandleTypeDef *spi) { XE_NP_MediaCamera_HalError(spi); }
#endif
#if !XE_NP_V2_MEDIA_ENABLE && !XE_NP_NP2_LIVE_SD_ENABLE && !XE_NP_NP2_PSSI_TEST_DIAG_ENABLE
#if !XE_NP_V2_AUX_ENABLE
void SPI1_IRQHandler(void)
{
  XE_NP_App_Spi1IrqHandler();
}
#endif

void USART2_IRQHandler(void)
{
  if(BLE_handle.COMM.UART != NULL)
  {
    if((BLE_handle.state & HJ580_STATE_CONFIG) != 0U)
    {
      (void)CE32_HJ580_RX_CONFIG_ISR(&BLE_handle);
      (void)CE32_HJ580_TX_CONFIG_ISR(&BLE_handle);
    }
    else
    {
      if(INTERCOM_UART_CHECK_RXNEIE((&BLE_handle.COMM)) &&
         INTERCOM_CHECK_RXNE((&BLE_handle.COMM)))
      {
        CE32_HJ185_DiagNoteStreamRxIrq();
      }
      (void)CE32_INTERCOM_RX_ISR((CE32_INTERCOM_Handle *)&BLE_handle);
      (void)CE32_INTERCOM_TX_ISR((CE32_INTERCOM_Handle *)&BLE_handle);
    }
  }
}

#endif

/* USER CODE END 1 */
