from pathlib import Path
import json,hashlib,subprocess
T=Path(__file__).resolve().parents[1];N=T/'native';old=Path('C:/Frank/Code/XE_NP/_artifacts/v1_usb_fast_startup_r79r2_20261006/source')
VC=Path('C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat');C=Path('C:/Frank/Code/XE_NP/Firmware/V1/Core/Src')
sources=[N/'fixture.c',T/'Core/Src/xe_np_sensors.c',C/'xe_np_bme_compensation.c',C/'xe_np_bmm_compensation.c']
cmd='call "'+str(VC)+'" >nul && cl /nologo /std:c11 /W4 /WX /TC /O2 /DNP_TEST_MAG_INTERVAL_MS=10U /I"'+str(old/'Core/Inc')+'" /I"'+str(old/'Middlewares/Bosch/BME280_SensorAPI')+'" /I"'+str(old/'Middlewares/Bosch/BMM150_SensorAPI')+'" '+' '.join('"'+str(x)+'"' for x in sources)+' /Fo"'+str(N)+'/" /Fe"'+str(N/'sensors.exe')+'"'
r=subprocess.run('cmd /d /s /c "'+cmd+'"',cwd=N,capture_output=True,text=True,timeout=60);(N/'compile.log').write_text(r.stdout+r.stderr);assert not r.returncode,r.stdout+r.stderr
r=subprocess.run([str(N/'sensors.exe')],cwd=N,capture_output=True,text=True,timeout=30);(N/'run.log').write_text(r.stdout+r.stderr);assert not r.returncode,r.stdout+r.stderr
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper();rec=dict(status='PASS',command=cmd,sources={str(p):sha(p) for p in sources},output=r.stdout,scope='Actual one-TU USB sensor source and existing asynchronous sensor/configuration/compensation/ownership/fault suite, fake100HzMAGDRDY, explicit register/preset/cadence checks. No device or recording claim.')
(N/'receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print(r.stdout,end='');print('receiptSHA256 '+sha(N/'receipt.json'))
