from pathlib import Path
import hashlib,json,re,sys
T=Path(__file__).resolve().parent;B=T/'build-r2';P=Path('C:/Frank/Code/XE_NP/_artifacts/closed_loop_qualification_20261104/V1/candidate/usb');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();r=json.loads((B/'pending.json').read_text())
assert h(T/'Core/Src/xe_np_sensors.c')==r['source']['staged_sha256'] and h(B/'xe_np_sensors.o')==r['new_sensor_object_sha256']
for p,d in r['retained_objects'].items():assert h(p)==d
sys.dont_write_bytecode=True;sys.path.insert(0,'C:/Frank/Code/XE_NP/Tools/V1Capture/ClosedLoopFix');from build_current import seal
ident=seal('usb',B);(B/'identity.json').write_text(json.dumps(ident,indent=2)+'\n')
def regions(p):return [(x[0],int(x[1],16),int(x[2],16),int(x[3],16)) for x in re.findall(r'Execution Region (\S+) \(Exec base: (0x\w+).*?Size: (0x\w+), Max: (0x\w+)',p.read_text())]
before=regions(P/'candidate.map');after=regions(B/'candidate.map');assert after and all(z<=m for n,b,z,m in after);assert [(n,b,z,m) for n,b,z,m in before if not n.startswith('ER_')]==[(n,b,z,m) for n,b,z,m in after if not n.startswith('ER_')]
r.update(status='SOFTWARE_CHECKED_PENDING_HARDWARE',identity=ident,link_command=['C:/Keil_v5/ARM/ARMCLANG/bin/armlink.exe','--via',str(B/'candidate.lnp')],regions=after,native_receipt_sha256=h(T/'native/receipt.json'))
(B/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(dict(crc32=ident['image_crc32'],hex_sha256=ident['sha256'],source_sha256=r['source']['staged_sha256'],native_receipt_sha256=r['native_receipt_sha256'],regions_unchanged=True),indent=2))
