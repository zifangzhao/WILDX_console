param([Parameter(Mandatory=$true)][ValidateSet('Status','EnterSd','RestoreUsbProfile','ReadFs2Metadata')][string]$Action,
      [Parameter(Mandatory=$true)][string]$Report,
      [long[]]$SectorLbas=@(16,24,112,113,210,211))
$ErrorActionPreference='Stop'
$uid='001D00065942500B20313354'
$hostApp='C:/Frank/Code/USB_PCconsole/_artifacts/sd_usb_test_host/enabled227-v1fixes/WILDX_console.exe'
if((Get-FileHash -LiteralPath $hostApp -Algorithm SHA256).Hash -ne '66078F77BB5034A2FB4C37AB1B6277020FFE0B2022FDB2DD59C16B68987FD197'){throw 'Frozen host identity mismatch'}
if(Test-Path -LiteralPath $Report){throw 'Fresh report path required'}
$original=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'bench/initial_status.json') -Raw|ConvertFrom-Json
if($original.uid -ne $uid -or !$original.read_only_preflight -or $original.final.Role -ne 3 -or $original.final.Busy -ne 0 -or $original.final.PendingMode -ne 0){throw 'Fresh original UID/profile/idle mode proof required'}
$originalMask=[int]$original.profile.ActiveMask
$originalRate=[int]$original.profile.ApHz
if($originalMask -lt 0 -or $originalMask -gt 7 -or $originalRate -notin @(7500,15000,20000,30000)){throw 'Unsupported original profile; do not guess restore'}
$script:a=[Reflection.Assembly]::LoadFrom($hostApp)
$script:flags=[Reflection.BindingFlags]'Public,NonPublic,Instance,Static'
function TypeOf([string]$name){if($name.Contains('.')){$script:a.GetType($name,$true)}else{$script:a.GetType('USB512_interface.'+$name,$true)}}
function Field($o,[string]$name){
 $t=$o.GetType();$f=$t.GetField($name,$script:flags)
 if($f){return $f.GetValue($o)}
 return $t.GetProperty($name,$script:flags).GetValue($o,$null)
}
function Call($o,[string]$name,[object[]]$values=@()){
 for($i=0;$i -lt $values.Count;$i++){if($null -ne $values[$i]){$values[$i]=$values[$i].PSObject.BaseObject}}
 $t=if($o -is [Type]){$o}else{$o.GetType()}
 $m=@($t.GetMethods($script:flags)|Where-Object{$_.Name -eq $name -and $_.GetParameters().Count -eq $values.Count})
 if($m.Count -ne 1){throw ('Ambiguous/absent actual API '+$name)}
 $instance=if($o -is [Type]){$null}else{$o.PSObject.BaseObject}
 try{return $m[0].Invoke($instance,$values)}catch{throw $_.Exception.GetBaseException()}
}
function NewObject([string]$name,[object[]]$values){
 for($i=0;$i -lt $values.Count;$i++){if($null -ne $values[$i]){$values[$i]=$values[$i].PSObject.BaseObject}}
 $ctors=@((TypeOf $name).GetConstructors($script:flags)|Where-Object{!$_.IsStatic -and $_.GetParameters().Count -eq $values.Count})
 if($ctors.Count -ne 1){throw 'Constructor ambiguity'}
 $ctors[0].Invoke($values)
}
function Fields($o){$d=@{};foreach($f in $o.GetType().GetFields($script:flags)){if(!$f.IsStatic){$d[$f.Name]=$f.GetValue($o)}};return $d}
function SelectedTarget {
 $targets=@(Call (TypeOf 'NpV1Management') 'Enumerate' @() | Where-Object{(Field $_ 'Uid') -eq $uid})
 if($targets.Count -ne 1){throw 'Exact V1 UID not uniquely enumerated'}
 return $targets[0]
}
$target=SelectedTarget;$manager=NewObject 'NpV1Management' @($target)
try{$initial=Call $manager 'ReadStatus' @();if((Field $initial 'Busy') -ne 0 -or (Field $initial 'PendingMode') -ne 0){throw 'V1 not idle'}}finally{$manager.Dispose()}
$result=@{uid=$uid;action=$Action;initial=(Fields $initial);capture_started=$false;card_command=$false}
if($Action -eq 'ReadFs2Metadata'){
 if((Field $initial 'Role') -ne 3){throw 'Idle download required'}
 $folder=Join-Path ([IO.Path]::GetDirectoryName($Report)) (([IO.Path]::GetFileNameWithoutExtension($Report))+'_sectors');if(Test-Path -LiteralPath $folder){throw 'Fresh metadata output required'}
 $stream=NewObject 'CE32_console.NpDownloadStream' @((Field $target 'Path'),$false)
 try{
  if(!(Field $stream 'TransportDescription').StartsWith('High-speed USB')){throw 'High-speed only'}
  $null=New-Item -ItemType Directory -Path $folder
  foreach($lba in $SectorLbas){
   $data=Call (TypeOf 'CE32_console.NpDownloadCatalog') 'Sector' @($stream,[long]$lba)
   [IO.File]::WriteAllBytes((Join-Path $folder ('lba'+$lba+'.bin')),[byte[]]$data)
  }
  $result.metadata_folder=$folder;$result.read_only_sectors=$SectorLbas
 }finally{$stream.Dispose()}
}
if($Action -eq 'EnterSd'){
 $result.acknowledgement=Call (TypeOf 'NpV1Management') 'SwitchMode' @($target,[uint16]1)
 $result.limitation='ACK only; actual APP/UID/idle must be proved through target and BLE CAPS before Start'
}
if($Action -eq 'RestoreUsbProfile'){
 $path=Call (TypeOf 'NpV1Management') 'EnsureStreaming' @((Field $target 'Path'))
 $transition=Call (TypeOf 'XeNpWinUsbDevice') 'OpenForControl' @($path)
 try{
  $status=Call $transition 'GetStatus' @();if(Field $status 'Streaming'){throw 'Capture active'}
  $caps=Call $transition 'GetModeCapabilities' @()
  if((Field $caps 'ApHz') -ne 20000){Call $transition 'VendorOut' @([byte]0x74,[uint16]3,[uint16]20000) | Out-Null}
 }finally{$transition.Dispose()}
 if((Field $caps 'ApHz') -ne 20000){$path=Call (TypeOf 'NpV1Management') 'WaitForStreaming' @($uid)}
 $device=Call (TypeOf 'XeNpWinUsbDevice') 'OpenForControl' @($path)
 try{
  $status=Call $device 'GetStatus' @();if(Field $status 'Streaming'){throw 'Capture active'}
  $request=NewObject 'NpCaptureRequest' @($originalMask,$originalRate)
  $parameters=[object[]]@($request.PSObject.BaseObject,$null,$null,$null,$false)
  $method=@($device.GetType().GetMethods($script:flags)|Where-Object{$_.Name -eq 'SelectCaptureMode' -and $_.GetParameters().Count -eq 5})[0]
  $null=$method.Invoke($device.PSObject.BaseObject,$parameters)
  $result.resolution=$parameters[2];$reconnect=$parameters[3]
 }finally{$device.Dispose()}
 if($reconnect){if($reconnect -ne $uid){throw 'Reconnection UID changed'};$path=Call (TypeOf 'NpV1Management') 'WaitForStreaming' @($uid)}
 $device=Call (TypeOf 'XeNpWinUsbDevice') 'OpenForControl' @($path)
 try{$caps=Call $device 'GetModeCapabilities' @();if((Field $caps 'ActiveMask') -ne $originalMask -or (Field $caps 'ApHz') -ne $originalRate){throw 'Fresh original USB profile not restored'};$result.verified_profile=Fields $caps}finally{$device.Dispose()}
 $null=Call (TypeOf 'NpV1Management') 'EnsureDownload' @($path,$null)
 $manager=NewObject 'NpV1Management' @((SelectedTarget))
 try{$s=Call $manager 'ReadStatus' @();if((Field $s 'Role') -ne 3 -or (Field $s 'Busy') -ne 0 -or (Field $s 'PendingMode') -ne 0){throw 'Original idle mode3 not restored'};$result.final=Fields $s}finally{$manager.Dispose()}
}
$result | ConvertTo-Json -Depth 6 | Out-File -LiteralPath $Report -Encoding utf8
$result | ConvertTo-Json -Depth 3




