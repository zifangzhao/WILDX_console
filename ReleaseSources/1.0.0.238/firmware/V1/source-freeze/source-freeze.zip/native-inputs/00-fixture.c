#define main sensor_regression_main
#include "C:/Frank/Code/XE_NP/Tools/V1Capture/SdLogger/Sensors/Tools/tests/test_np_sensors.c"
#undef main
int main(void){
 int rc=sensor_regression_main();CHECK(rc==0);
 Fake f;init(&f,1,0);run(&f,2500,0);
 CHECK(f.regs[0][0x40]==0x29 && f.regs[0][0x42]==0x29 && f.regs[0][0x44]==0x08);
 CHECK(f.mag[0x51]==4 && f.mag[0x52]==14 && f.mag[0x4c]==2);
 CHECK((f.sensors.snapshot.valid&3)==3 && f.sensors.snapshot.error[0]==0);
 CHECK(f.sensors.snapshot.imu_sequence>200 && f.sensors.snapshot.mag_sequence>100);
 printf("PASS V1 exactUSB sensor profile: AG200/MAG100, regular repetitions unchanged; native checks=%u; AG=%u MAG=%u\n",checks,f.sensors.snapshot.imu_sequence,f.sensors.snapshot.mag_sequence);
 return 0;
}
