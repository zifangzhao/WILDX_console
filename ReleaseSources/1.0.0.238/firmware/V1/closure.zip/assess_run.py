from pathlib import Path
import argparse,json,subprocess,sys
sys.dont_write_bytecode=True
import review_sensors
T=Path(__file__).resolve().parent
P=Path('C:/Frank/Code/XE_NP/_artifacts/closed_loop_qualification_20261104/V1')
HOST=Path('D:/Code/WILDX_console/WILDX_console/_artifacts/closed-loop-profile-limits/app/WILDX_console.exe')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
fields=lambda p:dict(s.split('=',1) for s in p.read_text().splitlines() if '=' in s)
parser=argparse.ArgumentParser();parser.add_argument('name');a=parser.parse_args()
run=T/'bench'/a.name
assert run.resolve().is_relative_to((T/'bench').resolve())
exp=read(run/'experiment.json');n=exp['closed_loop_detectors'];seconds=exp['requested_seconds']
assert n in (0,1,2) and seconds in (30,60)
assert exp['recording_worker_returned_successfully'] and exp['closed_loop_preference_restored']
assert read(run.parent/(run.name+'_stopped')/'proof.json')['result']=='PASS'
status=fields(run/'neuropixels_capture_status.txt');probes=fields(run/'neuropixels_probes.txt')
assert status['complete']=='True' and status['failure']=='none'
for key in ('firmware_recording_fault','raw_pool_dropped_wire_bytes','usb_sequence_gaps','frame_errors','counter_errors','imu_sequence_gaps','imu_queue_overflow','imu_error'):
    assert status[key]=='0',(key,status[key])
for p in (1,2):
    for key in ('missing_ap_rows','missing_lfp_rows','gap_events','host_dropped_lane_bytes','relocks','frame_errors','counter_errors','lfp_phase_errors'):
        assert probes[f'probe{p}.{key}']=='0',(p,key)
output=run/'imu-grid-current-assessment.json'
assert not output.exists()
r=subprocess.run([str(P/'usb-harness/reassess.exe'),str(HOST),str(run),str(output)],capture_output=True,text=True)
grid=read(output)
assert grid['imu_data_success'] and grid['np_relative_phase_qualified'] and grid['rtc_phase_qualified']
assert grid['sensor_error_rows']==0 and grid['observed_ordinal_span']>=max(25,seconds-5)*1250
sensor=review_sensors.analyze(run)
assert sensor['healthy_observed_grid'] and sensor['grid']['missing_prefix_only'] and len(sensor['grid']['missing_indices'])<=1
assert sensor['native']['partial_prefix_only']
assert 190<=sensor['native']['ag']['rate_hz']<=205
assert 90<=sensor['native']['mag']['rate_hz']<=105
(run/'sensor-review.json').write_text(json.dumps(sensor,indent=2)+'\n')
if n:
    r=subprocess.run([sys.executable,'-B',str(T/'replay.py'),str(run)],capture_output=True,text=True)
    (run/'native-replay.log').write_text(r.stdout+r.stderr)
    assert r.returncode==0,r.stdout+r.stderr
    assert read(run/'native_cl_identity.json')['result']=='PASS'
rtc=read(run/'recording_start_utc.json')
result=dict(result='PASS_SCOPED',detectors=n,seconds=seconds,
            usb_crc32='C91871BD',app_crc32='5F90FD3B',profile='V1P1+P2/15k/Ripple6',
            ag_hz=sensor['native']['ag']['rate_hz'],mag_hz=sensor['native']['mag']['rate_hz'],
            imu_observed=grid['observed'],imu_unavailable_startup_slots=grid['missing'],
            later_missing_imu_slots=0,sensor_errors=0,midstream_np_losses=0,
            ap_rows=[int(probes[f'probe{p}.ap_rows']) for p in (1,2)],
            lfp_rows=[int(probes[f'probe{p}.lfp_rows']) for p in (1,2)],
            startup_discarded_bytes=[int(probes[f'probe{p}.startup_discarded_bytes']) for p in (1,2)],
            preserved_original_lossless_flag=status.get('lossless'),
            retained_source_window_verified=grid['source_window_verified'],
            rtc_to_np_interval_us=rtc['local_interval_width_us'],
            relative_copy_jitter_bound_us=grid['relative_jitter_bound_us'],
            native_oracle='PASS' if n else 'not applicable',
            host_peak_queue=int(status['host_peak_queued_blocks']),host_queue_capacity=int(status['host_queue_capacity']),
            max_usb_completion_interval_ms=float(status['host_max_usb_completion_interval_ms']),
            cpu_load='not measured',
            limits=['Bounded recording check; not endurance qualification.',
                    'Initial trimming and unavailable startup slot are preserved; source-byte-zero completeness is not claimed.',
                    '1250Hz scheduled cache stream is not1250Hz physical sensor conversions; terminal-tail completeness remains unknown.',
                    'Original worker/assessor outcomes are retained; current15k/32-byte schema assessment is separate.'])
(run/'assessment.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
