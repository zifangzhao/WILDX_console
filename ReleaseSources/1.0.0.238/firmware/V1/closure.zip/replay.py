"""Stopped-file-only native LFP/event identity proof for one/two V1 lanes."""
import argparse
import csv
import io
import json
import struct
import subprocess
import zlib
from pathlib import Path
import sys
sys.dont_write_bytecode=True
sys.path.insert(0,r"C:/Frank/Code/XE_NP/Tools/V1Capture/ClosedLoopFix")
from prepare_current import ROOT,read,save,sha
TASK=Path(r"C:\Frank\Code\XE_NP\_artifacts\v1_usb_sensor_media_20261105")

def main():
    parser=argparse.ArgumentParser();parser.add_argument('run',type=Path);parser.add_argument('--output',default='native_cl_identity.json');a=parser.parse_args();run=a.run.resolve()
    if not run.is_relative_to(TASK.resolve()):raise ValueError('Current generated recording required')
    stopped=run.parent/(run.name+'_stopped');out=run/a.output
    if out.parent!=run or out.suffix!='.json':raise ValueError('Output must be one JSON file within this run')
    if out.exists():raise FileExistsError(out)
    code=TASK/"inspect_workspace.py"
    scope={'__name__':'retained','__file__':str(code)}
    exec(compile(read(code),str(code),'exec'),scope);w=scope['inspect'](stopped/'workspace.bin')
    raw=(run/'closed_loop_events.npcl').read_bytes();events=[]
    if not raw or len(raw)%64:raise ValueError('No complete hardware CL events')
    for at in range(0,len(raw),64):
        b=raw[at:at+64]
        if b[:5]!=b'NPCL\1' or zlib.crc32(b[:60])!=struct.unpack_from('<I',b,60)[0]:raise ValueError('Bad event CRC/header')
        if struct.unpack_from('<I',b,8)[0]!=w['session'] or struct.unpack_from('<I',b,40)[0]!=w['source_epoch']:raise ValueError('Event source binding differs')
        events.append(b)
    # Stop deliberately does not drain optional events. Prove an unsent final
    # tail from the frozen journal bytes; never excuse an in-recording hole.
    workspace=(stopped/'workspace.bin').read_bytes();journal=scope['LAYOUT']['cycles']+128
    if scope['LAYOUT']['confirmed']!=journal+536+16:raise ValueError('Frozen journal layout differs')
    generation,head,queued,next_sequence,dropped,tail_dropped=struct.unpack_from('<6I',workspace,journal+512)
    sequences=[struct.unpack_from('<I',b,12)[0] for b in events]
    if sequences!=list(range(1,len(events)+1)):raise ValueError('Saved event sequence is not a continuous prefix')
    if head or queued or dropped!=tail_dropped or tail_dropped>8:raise ValueError('Journal has non-tail loss or is not stopped')
    tails=[]
    for i in range(8):
        b=workspace[journal+i*64:journal+(i+1)*64]
        if b[:5]==b'NPCL\1' and struct.unpack_from('<I',b,12)[0]>len(events):
            if zlib.crc32(b[:60])!=struct.unpack_from('<I',b,60)[0] or struct.unpack_from('<I',b,8)[0]!=w['session'] or struct.unpack_from('<I',b,40)[0]!=w['source_epoch']:raise ValueError('Invalid retained Stop-tail event')
            tails.append(b)
    tails.sort(key=lambda b:struct.unpack_from('<I',b,12)[0])
    if len(tails)!=tail_dropped or [struct.unpack_from('<I',b,12)[0] for b in tails]!=list(range(len(events)+1,next_sequence)):raise ValueError('Unsent tail does not explain the complete event sequence')
    fields=dict(line.split('=',1) for line in read(run/'neuropixels_probes.txt').splitlines() if '=' in line)
    reports=[];passed=True
    for index,lane in enumerate(w['lanes']):
        if not lane['probe']:continue
        probe,channel=lane['probe'],lane['channel'];key='probe%d.'%probe
        first=lane['phase']+(((channel%24)//2+12-(lane['counter_origin']//13)%12)%12)*780+lane['word']
        counter=int(fields[key+'first_superframe_counter']);trim=int(fields[key+'startup_discarded_lfp_superframes'])
        if (lane['counter_origin']+(first-lane['word']-lane['phase'])//60-counter-(trim+(channel%24)//2)*13)%(1<<20):raise ValueError('Native LFP phase/counter mapping differs')
        data=run/('probe%d'%probe)/'neuropixels_lfp.dat';rows=data.stat().st_size//768
        count=min(rows,lane['samples'],*((run/('probe%d'%p)/'neuropixels_lfp.dat').stat().st_size//768 for p in (1,2)));last=first+(count-1)*9360
        saved_expected=[b for b in events if b[6]==index and b[5]!=5 and struct.unpack_from('<Q',b,24)[0]<=last]
        retained_expected=[b for b in tails if b[6]==index and b[5]!=5 and struct.unpack_from('<Q',b,24)[0]<=last]
        expected=saved_expected+retained_expected
        kinds=[b[5] for b in expected];matches={}
        for name,p,c in (('selected',probe,channel),('wrong_channel',probe,(channel+1)%384),('wrong_probe',2 if probe==1 else 1,channel)):
            path=run/('probe%d'%p)/'neuropixels_lfp.dat'
            r=subprocess.run([Path(r'C:\Frank\Code\XE_NP\_artifacts\closed_loop_qualification_20261104\V1\replay15.exe'),run/'closed_loop_config.bin',path,str(c),str(count),str(first),'384',str(index)],text=True,capture_output=True)
            if r.returncode:raise RuntimeError(r.stderr)
            rows_out=list(csv.DictReader(io.StringIO(r.stdout)))
            same=len(rows_out)==len(expected) and all(int(x['kind'])==e[5] and int(x['source_tick'])==struct.unpack_from('<Q',e,24)[0] and
                struct.pack('<f',float(x['envelope']))==e[44:48] and struct.pack('<f',float(x['threshold']))==e[48:52] for x,e in zip(rows_out,expected))
            matches[name]=same;save(run/('lane%d_%s.replay.csv'%(index,name)),r.stdout)
        gaps=sum(b[6]==index and b[5]==5 for b in events);tail=sum(b[6]==index and b[5]!=5 and struct.unpack_from('<Q',b,24)[0]>last for b in events)
        ok=matches['selected'] and not matches['wrong_channel'] and not matches['wrong_probe'] and 1 in kinds and 2 in kinds and not gaps and not lane['invalid']
        passed&=ok
        reports.append({'lane':index,'probe':probe,'channel':channel,'samples_replayed':count,'first_tick':first,
                        'hardware_samples':lane['samples'],'saved_native_rows':rows,'matched_events':len(expected),
                        'saved_events_matched':len(saved_expected),'retained_unsent_tail_events_matched':len(retained_expected),
                        'events_after_saved_complete_row_prefix':tail,'gaps':gaps,'matches':matches,'pass':ok})
    report={'result':'PASS' if passed and reports else 'FAIL','lanes':reports,'workspace':w,'events':len(events),
            'event_drops_max':max(struct.unpack_from('<I',b,52)[0] for b in events),
            'stop_tail':{'unsent_events':tail_dropped,'journal_dropped':dropped,'next_sequence':next_sequence,'exact_retained_tail_verified':True},
            'scope':'Exact native saved-complete-LFP-row event kinds/ticks/envelope/threshold float bits with wrong-channel/probe controls; final incomplete native rows/tail explicitly separate',
            'event_sha256':sha(run/'closed_loop_events.npcl'),'workspace_sha256':sha(stopped/'workspace.bin'),
            'oracle_sha256':sha(Path(r'C:\Frank\Code\XE_NP\_artifacts\closed_loop_qualification_20261104\V1\replay15.exe')),'hardware_access':False}
    if report['event_drops_max']:report['result']='FAIL'
    save(out,json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ('result','lanes','events','event_drops_max')},indent=2))
    if report['result']!='PASS':raise SystemExit(1)
if __name__=='__main__':main()
