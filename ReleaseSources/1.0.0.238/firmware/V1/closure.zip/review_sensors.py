"""Bounded V1 USB sensor review; never opens neural data or accesses a device."""
from pathlib import Path
import argparse, collections, hashlib, json, struct

AXES = ('ax', 'ay', 'az', 'gx', 'gy', 'gz', 'mx', 'my', 'mz')

def sha(data):
    return hashlib.sha256(data).hexdigest().upper()

def fields(path):
    return dict(line.split('=', 1) for line in path.read_text().splitlines() if '=' in line)

def cadence(rows, seq, tick):
    if len(rows) < 2:
        return {'snapshots': len(rows), 'rate_hz': None}
    steps = [(b[seq] - a[seq]) & 0xffffffff for a, b in zip(rows, rows[1:])]
    forward = [n for n in steps if 0 < n < 0x80000000]
    span = (rows[-1][tick] - rows[0][tick]) & 0xffffffff
    return dict(snapshots=len(rows), first_sequence=rows[0][seq], last_sequence=rows[-1][seq],
                span_ms=span, rate_hz=sum(forward) * 1000 / span if span else None,
                repeats=steps.count(0), unobserved_sequence_numbers=sum(n - 1 for n in forward),
                backwards=sum(n >= 0x80000000 for n in steps),
                scope='Observed counter advance; skipped observations are not proof of lost physical conversions.')

def axis_stats(rows):
    return {name: dict(unique=len({r[i] for r in rows}), minimum=min(r[i] for r in rows),
                       maximum=max(r[i] for r in rows), changes=sum(a[i] != b[i] for a, b in zip(rows, rows[1:])))
            for i, name in enumerate(AXES)} if rows else {}

def scaled(value, axis):
    n, d = (4096, 1000000) if axis < 3 else (164, 10000) if axis < 6 else (1, 300)
    q = (abs(value) * n + d // 2) // d
    return -q if value < 0 else q

def analyze(folder):
    names = ('imu_native_samples.jsonl', 'imu_native_samples_status.json', 'analogin.dat',
             'analogin_validity.dat', 'analogin_encoding.txt', 'imu_grid_status.txt')
    data = {n: (folder / n).read_bytes() for n in names}
    journal = [json.loads(line) for line in data[names[0]].decode().splitlines()]
    samples = [r for r in journal if r['kind'] == 'sample']
    status = json.loads(data[names[1]])
    native, values = [], []
    for sample in samples:
        raw = bytes.fromhex(sample['raw_snapshot_hex'])
        assert len(raw) == 140
        words = struct.unpack('<35I', raw)
        axes = struct.unpack_from('<9i', raw, 48)
        assert words[:2] == (0x31534e53, 1)
        assert sample['sequence'] == words[5] and sample['valid'] == words[3]
        assert tuple(sample['ag'] + sample['mag']) == axes
        native.append(words)
        values.append(axes)
    assert len(native) == status['accepted_samples'] == status['retained_samples']
    ag = [u for u in native if u[3] & 1 and u[5] and not u[26]]
    mag = [u for u in native if u[3] & 2 and u[6] and u[9] and not u[26]]
    partial = [i for i, u in enumerate(native) if u[3] & 3 != 3]
    valid_values = [v for u, v in zip(native, values) if u[3] & 3 == 3 and not u[26]]
    enc = fields(folder / 'analogin_encoding.txt')
    grid = fields(folder / 'imu_grid_status.txt')
    valid, analog = data['analogin_validity.dat'], data['analogin.dat']
    assert len(analog) == len(valid) * 32
    counts = collections.Counter()
    missing, invalid_ag, invalid_mag, errors = [], [], [], []
    prev = None
    repeat_bad = 0
    primary = []
    ag_set, mag_set = set(), set()
    for i, flag in enumerate(valid):
        w = struct.unpack_from('<16h', analog, i * 32)
        axes = w[1:10]
        assert flag & ~63 == 0
        assert w[0] == 0 and w[10:14] == (-32768, -1, 0, 0)
        if not flag & 1:
            assert flag == 0 and axes == (-32768,) * 9
            missing.append(i)
            counts['missing'] += 1
            prev = None
            continue
        counts['observed'] += 1
        primary.append(axes)
        for name, bit in (('ag_valid', 2), ('mag_valid', 4), ('ag_repeat', 8), ('mag_repeat', 16), ('error', 32)):
            counts[name] += bool(flag & bit)
        if flag & 2:
            ag_set.add(axes[:6])
            counts['ag_nonrepeat'] += not bool(flag & 8)
        else:
            invalid_ag.append(i)
        if flag & 4:
            mag_set.add(axes[6:])
            counts['mag_nonrepeat'] += not bool(flag & 16)
        else:
            invalid_mag.append(i)
        if flag & 32:
            errors.append(i)
        if prev:
            if flag & 8 and prev[0] & 2 and axes[:6] != prev[1][:6]:
                repeat_bad += 1
            if flag & 16 and prev[0] & 4 and axes[6:] != prev[1][6:]:
                repeat_bad += 1
        prev = flag, axes
    for key, name in (('observed', 'observed'), ('missing', 'missing'), ('ag_repeat', 'ag_repeated'), ('mag_repeat', 'mag_repeated')):
        assert counts[key] == int(enc[name])
    quantized = [tuple(scaled(x, i) for i, x in enumerate(v)) for v in valid_values]
    missing_prefix = missing == list(range(len(missing)))
    partial_prefix = partial == list(range(len(partial)))
    io_errors = collections.Counter(str(u[26]) for u in native)
    result = dict(status='REVIEWED_NO_AUTOMATIC_QUALIFICATION', folder=str(folder),
                  native=dict(accepted=len(native), invalid_observations=status['invalid_observations'],
                              partial_accepted_indices=partial, partial_prefix_only=partial_prefix,
                              valid_flags=dict(collections.Counter(str(u[3]) for u in native)),
                              error_codes=dict(io_errors), ag=cadence(ag, 5, 8), mag=cadence(mag, 6, 9),
                              valid_axes=axis_stats(valid_values), journal_status=status),
                  grid=dict(rows=len(valid), counts=dict(counts), missing_indices=missing,
                            missing_prefix_only=missing_prefix, invalid_ag_indices=invalid_ag,
                            invalid_mag_indices=invalid_mag, error_indices=errors,
                            repeat_value_mismatches=repeat_bad, axes=axis_stats(primary),
                            ag_nonrepeat_per_source_second=counts['ag_nonrepeat'] * 1250 / len(valid),
                            mag_nonrepeat_per_source_second=counts['mag_nonrepeat'] * 1250 / len(valid),
                            phase_qualified=grid.get('grid_phase_qualified'),
                            source_window_verified=grid.get('source_window_verified'),
                            queue_dropped=grid.get('queue_dropped', 'not reported by this older host'),
                            scheduler_missing=grid.get('scheduler_missing', 'not reported by this older host'),
                            error=grid['error']),
                  quantization_compatibility=dict(native_all_valid=len(quantized),
                      scaled_AG_tuple_in_grid=sum(v[:6] in ag_set for v in quantized),
                      scaled_MAG_tuple_in_grid=sum(v[6:] in mag_set for v in quantized),
                      scope='Value membership only; cached snapshots are not conversion-phase locked.'),
                  files={n: dict(bytes=len(b), sha256=sha(b)) for n, b in data.items()},
                  limitations=['Initial unavailable rows and partial native snapshots remain explicitly unavailable.',
                               '1250Hz is scheduled cached-copy rate; native AG/MAG conversion rates are separate.',
                               'Unknown terminal scheduled ordinal remains unknown; preserve recorded source-window result.',
                               'No neural payload or hardware was accessed.'])
    result['healthy_observed_grid'] = not errors and not invalid_ag and not invalid_mag and not repeat_bad
    return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('folder', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists(), 'Fresh receipt required'
    result = analyze(args.folder)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(status=result['status'], native_ag_hz=result['native']['ag']['rate_hz'],
                         native_mag_hz=result['native']['mag']['rate_hz'],
                         partial_native=len(result['native']['partial_accepted_indices']),
                         grid=result['grid']['counts'], healthy_observed_grid=result['healthy_observed_grid'],
                         receipt_sha256=sha(args.output.read_bytes())), indent=2))
