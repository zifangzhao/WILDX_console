"""Replay only retained selected-channel fixtures; no neural payload/device access."""
from pathlib import Path
import csv,hashlib,io,json,struct,subprocess
import inspect_workspace
T=Path(__file__).resolve().parent
ORACLE=Path('C:/Frank/Code/XE_NP/_artifacts/closed_loop_qualification_20261104/V1/replay15.exe')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
results=[]
for name in ('usb-cl1','usb-cl2','usb-cl2-r2'):
    run=T/'bench'/name
    native=json.loads((run/'native_cl_identity.json').read_text())
    raw=(run/'closed_loop_events.npcl').read_bytes()
    events=[raw[i:i+64] for i in range(0,len(raw),64)]
    workspace=(run.parent/(run.name+'_stopped')/'workspace.bin').read_bytes()
    journal=inspect_workspace.LAYOUT['cycles']+128
    tails=[]
    for i in range(8):
        b=workspace[journal+i*64:journal+(i+1)*64]
        if b[:5]==b'NPCL\1' and struct.unpack_from('<I',b,12)[0]>len(events):tails.append(b)
    tails.sort(key=lambda b:struct.unpack_from('<I',b,12)[0])
    for lane in native['lanes']:
        index,p,count,first=lane['lane'],lane['probe'],lane['samples_replayed'],lane['first_tick']
        expected=[e for e in events+tails if e[6]==index and e[5]!=5 and struct.unpack_from('<Q',e,24)[0]<=first+(count-1)*9360]
        assert len(expected)==lane['matched_events']
        matches={};inputs=[]
        for label,probe,ch in (('selected',p,0),('wrong_channel',p,1),('wrong_probe',3-p,0)):
            f=T/'compact'/name/f'probe{probe}'/f'neuropixels_lfp.dat.ch{ch}.bin'
            r=subprocess.run([str(ORACLE),str(run/'closed_loop_config.bin'),str(f),'0',str(count),str(first),'1',str(index)],capture_output=True,text=True)
            assert r.returncode==0,r.stderr
            got=list(csv.DictReader(io.StringIO(r.stdout)))
            matches[label]=len(got)==len(expected) and all(int(g['kind'])==e[5] and int(g['source_tick'])==struct.unpack_from('<Q',e,24)[0] and struct.pack('<f',float(g['envelope']))==e[44:48] and struct.pack('<f',float(g['threshold']))==e[48:52] for g,e in zip(got,expected))
            inputs.append(dict(name=label,path=str(f),sha256=sha(f)))
        assert matches==dict(selected=True,wrong_channel=False,wrong_probe=False),matches
        results.append(dict(run=name,lane=index,samples=count,events=len(expected),matches=matches,fixtures=inputs))
out=T/'compact/replay-result.json';assert not out.exists()
out.write_text(json.dumps(dict(result='PASS',hardware_access=False,oracle=str(ORACLE),oracle_sha256=sha(ORACLE),lanes=results),indent=2)+'\n')
print(f'Compact replay PASS: {len(results)} lanes, native event float bits and wrong-channel/probe controls; SHA '+sha(out))
