"""Close scoped V1 evidence and remove only this task's large generated neural data."""
from pathlib import Path
import datetime,hashlib,json,struct,zipfile
T=Path(__file__).resolve().parent
B=(T/'bench').resolve(strict=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
names=('usb-cl0','usb-cl1','usb-cl2','usb-cl2-r2')
runs=[read(B/n/'assessment.json') for n in names]
assert all(r['result']=='PASS_SCOPED' for r in runs)
restore=read(B/'restoration-complete.json');physical=read(B/'restore_verified.json');closed=read(B/'lease-closed.json')
assert restore['result']=='PASS' and physical['full_physical_flash_options_verified'] and closed['status']=='CLOSED'
assert physical['flash_sha256']=='01CC90B06C44B2B52962DD214AB82C4F9600F06F13BB11D4BCCE7F21F2B66A75'
assert sha(T/'source-freeze-candidate.zip')=='B408B57DA35F81EBB09131DB28CAD85822F7ECCF455B837217C15765599B21AE'
C=T/'compact';assert not C.exists();C.mkdir()
removed=[]
for name in names:
    for probe in (1,2):
        source=B/name/f'probe{probe}'
        for filename in ('neuropixels_ap.dat','neuropixels_lfp.dat','neuropixels_ap.dat.timestamps.calibrated.dat','neuropixels_lfp.dat.timestamps.calibrated.dat'):
            p=(source/filename).resolve(strict=True);assert p.is_relative_to(B) and p.parent==source.resolve()
            size=p.stat().st_size;rowbytes=8 if 'timestamps' in filename else 768
            assert size%rowbytes==0
            out=C/p.relative_to(B);out.parent.mkdir(parents=True,exist_ok=True)
            with p.open('rb') as f:
                front=f.read(min(size,rowbytes*64));f.seek(max(0,size-rowbytes*64));tail=f.read()
            first=out.with_suffix(out.suffix+'.first64rows.bin');last=out.with_suffix(out.suffix+'.last64rows.bin')
            first.write_bytes(front);last.write_bytes(tail)
            retained=[dict(path=str(q.relative_to(T)),sha256=sha(q),bytes=q.stat().st_size) for q in (first,last)]
            if filename=='neuropixels_lfp.dat':
                ch=[bytearray(),bytearray()]
                with p.open('rb') as f:
                    while True:
                        block=f.read(768*4096)
                        if not block:break
                        assert len(block)%768==0
                        for at in range(0,len(block),768):
                            ch[0].extend(block[at:at+2]);ch[1].extend(block[at+2:at+4])
                for i,values in enumerate(ch):
                    q=out.with_suffix(out.suffix+f'.ch{i}.bin');q.write_bytes(values)
                    retained.append(dict(path=str(q.relative_to(T)),sha256=sha(q),bytes=q.stat().st_size))
            removed.append(dict(path=str(p),bytes=size,rows=size//rowbytes,row_bytes=rowbytes,
                                whole_file_hash='not computed; no full AP/timestamp pass',retained=retained))
            p.unlink()
cleanup=dict(status='COMPLETE',removed_bytes=sum(x['bytes'] for x in removed),removed_files=len(removed),
             retained_bytes=sum(q['bytes'] for x in removed for q in x['retained']),files=removed,
             scope='Only generated neural DAT/calibrated timestamp arrays under this exact task bench. User recordings and card contents untouched; metadata/sensors/firmware restore backups retained.')
(C/'manifest.json').write_text(json.dumps(cleanup,indent=2)+'\n')
evidence=[]
for n in names:
    for file in ('assessment.json','experiment.json','sensor-review.json','imu-grid-current-assessment.json','recording_start_utc.json','neuropixels_capture_status.txt','neuropixels_probes.txt','native_cl_identity.json'):
        p=B/n/file
        if p.exists():evidence.append(dict(path=str(p),sha256=sha(p)))
    p=B/(n+'_stopped')/'proof.json';evidence.append(dict(path=str(p),sha256=sha(p)))
for name in ('restore_verified.json','restoration-complete.json','lease-closed.json','final_profile_ap/protected_profile.json','initial_status.json','restored-final-status.json'):
    p=B/name;evidence.append(dict(path=str(p),sha256=sha(p)))
result=dict(status='accepted',app_crc32='5F90FD3B',usb_crc32='C91871BD',
            qualified_usb_detector_counts=[1,2],profile=dict(probe_mask=3,sample_hz=15000,filter=6,filter_name='Ripple',gain=2,rectify=True,training_ms=1000,channels=[dict(probe=1,channel=0),dict(probe=2,channel=0)]),
            usb_sensor_summary='V1 two probes at15kHz: native AG198.89–199.40Hz/MAG99.53–99.74Hz;1250Hz held grid. Off/one/two detectors60s plus two-detector30s restart passed saved-span NP continuity and observed IMU validity. One unavailable startup slot each; terminal coverage remains limited.',
            original_restored=True,original_flash_sha256=physical['flash_sha256'],original_options_sha256=physical['options_sha256'],
            original_app_crc32='82E51DEA',original_usb_crc32='4F7B521A',uid='001D00065942500B20313354',
            original_profile=read(B/'initial_status.json')['profile'],restoration=restore,lease=closed,
            firmware=read(T/'matched-test-pair.json'),runs=runs,
            source_freeze=dict(path=str(T/'source-freeze-candidate.zip'),sha256=sha(T/'source-freeze-candidate.zip'),status='Immutable software-checked source/dependency/recipe parent; hardware closure is this receipt.'),
            cleanup=dict(path=str(C/'manifest.json'),sha256=sha(C/'manifest.json'),removed_bytes=cleanup['removed_bytes'],retained_bytes=cleanup['retained_bytes']),
            evidence=evidence,accepted_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            limits=['This is affected USB15kHz/two-probe qualification, not a claim for every V1 USB/media profile or endurance.',
                    'Unchanged APP/SD behavior reuses prior qualification, not a new SD test.',
                    'Native sensor conversion-phase lock, CPU/power usage and complete unknown terminal tail are not established.',
                    'Original lossless=False startup-trimming flags, partial native snapshots and two-detector retained source-window=False remain preserved.',
                    'The30s raw helper correctly fails its fixed55s span threshold; actual30s restart separately passes a25s minimum observed-span assessment. The raw helper result is not relabeled.'])
(T/'accepted.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],app_crc32=result['app_crc32'],usb_crc32=result['usb_crc32'],original_restored=True,accepted_sha256=sha(T/'accepted.json'),cleanup=result['cleanup']),indent=2))
