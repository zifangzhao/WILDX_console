param([Parameter(Mandatory=$true)][string]$Phase,
      [Parameter(Mandatory=$true)][ValidateSet('Status','EnterSd','RestoreUsbProfile')][string]$Action,
      [Parameter(Mandatory=$true)][string]$Report)
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath('C:\Frank\Code\XE_NP\_artifacts\v1_usb_sensor_media_20261105').TrimEnd('\')+'\'
$phase=[IO.Path]::GetFullPath($Phase)
$report=[IO.Path]::GetFullPath($Report)
if(!$phase.StartsWith($root,[StringComparison]::OrdinalIgnoreCase) -or
   !$report.StartsWith($phase.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){
    throw 'Current leased phase and a fresh report within it are required'
}
$lease=Get-Content -LiteralPath (Join-Path $phase 'lease_held.json') -Raw | ConvertFrom-Json
if($lease.uid -ne '001D00065942500B20313354' -or !(Get-Process -Id $lease.holder_pid -ErrorAction SilentlyContinue)){
    throw 'Exact V1 lease holder missing'
}
foreach($name in @('Local\WILDX_NP_TIMING_HIL','Local\XE_NP_V1_001D00065942500B20313354')){
    $mutex=[Threading.Mutex]::OpenExisting($name)
    try{if($mutex.WaitOne(0)){$mutex.ReleaseMutex();throw ('Lease not held: '+$name)}}finally{$mutex.Dispose()}
}
$parent='C:/Frank/Code/XE_NP/_artifacts/v1_first_guard_lab_20261028/hil/production_control.ps1'
if((Get-FileHash -LiteralPath $parent).Hash -ne '998550D22526CDF2B863CD3C175AC473A1AFAB8C96DD9A4E20A00AC71A3A85E7'){
    throw 'Pinned production-API helper changed'
}
$source=[IO.File]::ReadAllText($parent).
    Replace('D:/Code/WILDX_console/WILDX_console/_artifacts/first_sync_host_20261028/enabled162/WILDX_console.exe',
            'C:/Frank/Code/USB_PCconsole/_artifacts/sd_usb_test_host/enabled222-singlepass/WILDX_console.exe').
    Replace('2AFB074F72C59FB88F95EA361C773A9CC2174188FFB61B4AF9A56C5E432D251B',
            'D2485F77841699903BAB475131A86E09971999F993468E75EA0C0786A5A519CF')
$marker='$result | ConvertTo-Json -Depth 6 | Out-File -LiteralPath $Report -Encoding utf8'
if(($source.Split(@($marker),[StringSplitOptions]::None)).Count -ne 2){throw 'Production report seam changed'}
$augment=@'
if($Action -eq 'Status'){
 if((Field $initial 'Role') -ne 3){throw 'Fresh read-only idle download preflight required'}
 $d=Call (TypeOf 'XeNpWinUsbDevice') 'OpenForControl' @((Field $target 'Path'))
 try{$caps=Call $d 'GetModeCapabilities' @();$result.profile=Fields $caps}finally{$d.Dispose()}
 $m=NewObject 'NpV1Management' @((SelectedTarget))
 try{
  [byte[]]$info=Call $m 'Control' @([byte]0x60,[uint16]0,[int]32)
  if($info.Length -ne 32 -or [BitConverter]::ToUInt32($info,0) -ne 0x3144504e){throw 'Download info malformed'}
  $result.download_info_base64=[Convert]::ToBase64String($info)
  $result.card_sectors=[long][BitConverter]::ToUInt32($info,8)
  $result.card_bytes=$result.card_sectors*512L
  $result.final=Fields (Call $m 'ReadStatus' @())
 }finally{$m.Dispose()}
 $result.read_only_preflight=$true;$result.full_flash_config_options_fresh=$false
 $result.firmware_identity_capability=$false
}
'@
$source=$source.Replace($marker,$augment+"`n"+$marker)
& ([scriptblock]::Create($source)) -Action $Action -Report $report
