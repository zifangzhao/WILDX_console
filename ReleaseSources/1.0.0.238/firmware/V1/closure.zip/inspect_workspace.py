"""Decode only retained stopped workspace/layout evidence; no device access."""
import json
from pathlib import Path
import struct
import sys

HERE=Path(__file__).resolve().parent
elf=(HERE/"workspace_layout.o").read_bytes()
shoff=struct.unpack_from("<I",elf,32)[0];size,count,index=struct.unpack_from("<HHH",elf,46)
sections=[struct.unpack_from("<10I",elf,shoff+i*size) for i in range(count)]
strings=elf[sections[index][4]:sections[index][4]+sections[index][5]]
section=next(s for s in sections if strings[s[0]:].split(b"\0",1)[0]==b".rodata.np_test_layout")
values=struct.unpack_from("<"+"I"*(section[5]//4),elf,section[4])
names=("workspace_bytes","lanes","lane_bytes","decoders","decoder_bytes","source","source_bytes","source_reset","cycles",
       "flags","source_epoch","session","confirmed","recording","armed","lane_config","lane_main_state","lane_last_tick",
       "lane_state","lane_gaps","lane_initialized","config_probe","config_channel","config_lane","filter_x","filter_ptr",
       "decoder_phase","decoder_counter_origin","decoder_word","decoder_bit","decoder_phase_valid","decoder_initialized",
       "decoder_samples","decoder_invalid","decoder_available_tick","source_valid","source_seeded","source_lost","source_capture_generation")
assert len(names)==len(values)
LAYOUT=dict(zip(names,values))

def inspect(path):
    b=Path(path).read_bytes();assert len(b)==LAYOUT["workspace_bytes"]
    u=lambda offset:struct.unpack_from("<I",b,offset)[0]
    q=lambda offset:struct.unpack_from("<Q",b,offset)[0]
    result={k:u(LAYOUT[k]) for k in ("flags","source_epoch","session","recording","armed")}
    base=LAYOUT["source"]
    result["source"]={k:u(base+LAYOUT["source_"+k]) for k in ("valid","seeded","lost","capture_generation")}
    result["source"]["next_ticks"]=list(struct.unpack_from("<3Q",b,base))
    result["source"]["reset"]=dict(zip(("token","probe_mask","ap_hz","stage","release_ms","capture_generation","admission","last_ms","window_closed"),
                                           struct.unpack_from("<9I",b,base+LAYOUT["source_reset"])))
    result["lanes"]=[]
    for i in range(2):
        lane=LAYOUT["lanes"]+i*LAYOUT["lane_bytes"];d=LAYOUT["decoders"]+i*LAYOUT["decoder_bytes"]
        cfg=lane+LAYOUT["lane_config"]
        item={k:u(cfg+LAYOUT["config_"+k]) for k in ("probe","channel","lane")}
        item.update({k:u(d+LAYOUT["decoder_"+k]) for k in ("phase","counter_origin","word","bit","phase_valid","initialized","samples","invalid")})
        item.update(last_tick=q(lane+LAYOUT["lane_last_tick"]),available_tick=q(d+LAYOUT["decoder_available_tick"]),
                    gaps=u(lane+LAYOUT["lane_gaps"]),state=u(lane+LAYOUT["lane_state"]))
        state=lane+LAYOUT["lane_main_state"]
        ptr=b[state+LAYOUT["filter_ptr"]]
        item["last_raw_input"]=struct.unpack_from("<f",b,state+LAYOUT["filter_x"]+ptr*4)[0] if ptr<3 else None
        result["lanes"].append(item)
    return result

if __name__=="__main__":
    result=inspect(sys.argv[1]);print(json.dumps(result,indent=2))
    Path(sys.argv[1]).with_suffix(".json").write_text(json.dumps(result,indent=2)+"\n")
