param([string]$Phase='C:\Frank\Code\XE_NP\_artifacts\v1_usb_sensor_media_20261105\bench')
$ErrorActionPreference='Stop'
$expected='C:\Frank\Code\XE_NP\_artifacts\v1_usb_sensor_media_20261105\bench'
$phasePath=[IO.Path]::GetFullPath($Phase)
if($phasePath -cne $expected -or (Test-Path -LiteralPath $phasePath)) { throw 'Exact fresh qualification_20261104 phase required' }
$parent=[IO.DirectoryInfo]::new([IO.Path]::GetDirectoryName($phasePath))
while($null -ne $parent) {
    if($parent.Exists -and ($parent.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Redirected phase parent refused' }
    $parent=$parent.Parent
}
$names=@('openocd','ST-LINK_gdbserver','STM32_Programmer_CLI','WILDX_console','WILD_console','NpV1RtcHardware*','NpFirstSync*')
if(Get-Process -Name $names -ErrorAction SilentlyContinue){throw 'Competing hardware client; lease not acquired'}
$global=[Threading.Mutex]::new($false,'Local\WILDX_NP_TIMING_HIL')
$uid=[Threading.Mutex]::new($false,'Local\XE_NP_V1_001D00065942500B20313354')
$g=$false; $u=$false
try {
    $g=$global.WaitOne(0); if(!$g){throw 'Global timing lease held'}
    $u=$uid.WaitOne(0); if(!$u){throw 'Exact V1 UID lease held'}
    if(Get-Process -Name $names -ErrorAction SilentlyContinue){throw 'Hardware client appeared during acquisition'}
    New-Item -ItemType Directory -Path $phasePath -ErrorAction Stop | Out-Null
    $receipt=[ordered]@{uid='001D00065942500B20313354';holder_pid=$PID;global=$true;exact_uid=$true}
    $stream=[IO.File]::Open((Join-Path $phasePath 'lease_held.json'),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
    try { $writer=[IO.StreamWriter]::new($stream,[Text.UTF8Encoding]::new($false)); $writer.Write(($receipt|ConvertTo-Json -Compress)); $writer.Flush() }
    finally { $stream.Dispose() }
    while(!(Test-Path -LiteralPath (Join-Path $phasePath 'release_all.request'))) { Start-Sleep -Milliseconds 500 }
} finally {
    if($u){$uid.ReleaseMutex()}; if($g){$global.ReleaseMutex()}
    $uid.Dispose(); $global.Dispose()
}



