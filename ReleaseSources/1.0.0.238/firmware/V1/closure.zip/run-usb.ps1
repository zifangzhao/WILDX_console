param([ValidateSet('0','1','2')][string]$Detectors='0',
      [ValidateSet(30,60)][int]$Seconds=60,
      [ValidateSet('','-r2')][string]$Suffix='')
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$phase=Join-Path $root 'bench'
$uid='001D00065942500B20313354'
$lease=Get-Content -LiteralPath (Join-Path $phase 'lease_held.json') -Raw|ConvertFrom-Json
if($lease.uid -ne $uid -or !(Get-Process -Id $lease.holder_pid -ErrorAction SilentlyContinue)){throw 'Exact active V1 lease required'}
foreach($name in 'Local\WILDX_NP_TIMING_HIL',('Local\XE_NP_V1_'+$uid)){
 $mutex=[Threading.Mutex]::OpenExisting($name)
 try{if($mutex.WaitOne(0)){$mutex.ReleaseMutex();throw 'Bench lease not held'}}finally{$mutex.Dispose()}
}
$install=Get-Content -LiteralPath (Join-Path $phase 'install_verified.json') -Raw|ConvertFrom-Json
if(!$install.full_physical_flash_options_verified -or $install.flash_sha256 -ne ((Get-Content -LiteralPath (Join-Path $phase 'plan/plan.json') -Raw|ConvertFrom-Json).expected_sha256)){throw 'Installed pair differs'}
$hostExe='D:/Code/WILDX_console/WILDX_console/_artifacts/closed-loop-profile-limits/app/WILDX_console.exe'
$name="usb-cl$Detectors$Suffix"
$dir=Join-Path $phase $name
& 'C:/Frank/Code/XE_NP/_artifacts/closed_loop_qualification_20261104/V1/usb-harness/usb.exe' $hostExe $dir $uid $Seconds 15000 v1 3 $Detectors
$testCode=$LASTEXITCODE
if(!(Test-Path -LiteralPath (Join-Path $dir 'experiment.json'))){throw 'Missing returned worker receipt'}
$proof=Get-Content -LiteralPath (Join-Path $dir 'experiment.json') -Raw|ConvertFrom-Json
$extra=@()
if($testCode -ne 0 -and !$proof.recording_worker_returned_successfully){$extra+='--failed-worker'}
& 'C:/Users/antfe/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' -B (Join-Path $root 'bench_stop.py') "usb$Detectors" --run-name $name @extra
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
exit $testCode
