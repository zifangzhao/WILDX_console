from pathlib import Path
import subprocess,json,sys,zlib,hashlib,struct
T=Path(__file__).resolve().parent;O=T/'r4';R=Path('D:/Code/XE_NP_V2');ARM=Path('C:/Keil_v5/ARM/ARMCLANG/bin');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
r=subprocess.run([str(ARM/'fromelf.exe'),'--bin','--output',str(O/'application.bin'),str(O/'application.axf')],capture_output=True,text=True);assert not r.returncode,r.stdout+r.stderr
sys.path.insert(0,str(R/'Tools'));import package_xe_np_firmware as pkg
from verify_xe_np_slot_hex import verify
pkg.LOADER_ABI_VERSION=4;b=(O/'application.bin').read_bytes();m=pkg.build_manifest(b,generation=3,image_id=pkg.IMAGE_ID_USB_SERVICE,usb_auto_app=True);(O/'application.manifest.bin').write_bytes(m)
h=O/'V2_USB_PAIRED_SD_CANDIDATE.hex';pkg.write_intel_hex(h,pkg.sealed_slot_memory(b,m));h.write_bytes(h.read_bytes().replace(b'\r\n',b'\n'));verify(h,b,m)
q=json.loads((O/'pending.json').read_text());q.update(status='SOFTWARE_CHECKED_READONLY_PAIR_CAPS_PENDING',crc32=f'{zlib.crc32(b):08X}',body_bytes=len(b),body_sha256=sha(O/'application.bin'),manifest_sha256=sha(O/'application.manifest.bin'),hex_sha256=sha(h))
(O/'receipt.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:q[k] for k in ['crc32','body_sha256','expected_app_crc32','hex_sha256']},indent=2))
