from pathlib import Path
import json,re,subprocess,hashlib
T=Path(__file__).resolve().parent;B=T/'r3';O=T/'r4';O.mkdir(exist_ok=True)
P=T.parent/'v2_usb_selected_detectors_20261105';R=Path('D:/Code/XE_NP_V2')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
parent=load(B/'receipt.json');assert parent['crc32']=='72C9F2C6' and sha(B/'application.bin')==parent['body_sha256']
c=list(load(P/'build/receipt.json')['compiler_commands']['xe_np_np2_closed_loop_spi'])
c[1:1]=['-I',str(T/'Core/Inc'),'-iquote',str(T/'Core/Src')]
c=[a.replace('XE_NP_GRID_AUX_COST_DIAG=0U','XE_NP_GRID_AUX_COST_DIAG=1U') for a in c]
c[c.index('-c')+1]=str(T/'Core/Src/xe_np_np2_closed_loop_spi.c');c[c.index('-o')+1]=str(O/'xe_np_np2_closed_loop_spi.o');c[c.index('-MF')+1]=str(O/'xe_np_np2_closed_loop_spi.d')
if not (O/'xe_np_np2_closed_loop_spi.o').exists():
 r=subprocess.run(c,cwd=R,capture_output=True,text=True);(O/'compile.log').write_text(r.stdout+r.stderr);assert not r.returncode,r.stdout+r.stderr
link=(B/'application.lnp').read_text();objs=re.findall(r'"([^"\r\n]+\.o)"',link)
old=[p for p in objs if Path(p).name=='xe_np_np2_closed_loop_spi.o'];assert len(old)==1
retained={p:sha(p) for p in objs if p!=old[0]}
for p,h in retained.items():
 if p in parent['retained_objects']:assert parent['retained_objects'][p]==h,p
link=link.replace(old[0],(O/'xe_np_np2_closed_loop_spi.o').as_posix())
for n in ['application.axf','application.map','application.sct']:link=link.replace((B/n).as_posix(),(O/n).as_posix())
(O/'application.sct').write_bytes((B/'application.sct').read_bytes());(O/'application.lnp').write_text(link)
r=subprocess.run(['C:/Keil_v5/ARM/ARMCLANG/bin/armlink.exe','--via',str(O/'application.lnp')],capture_output=True,text=True);(O/'link.log').write_text(r.stdout+r.stderr);assert not r.returncode,r.stdout+r.stderr
def symbols(path):
 return {(m[1],m[4]):(int(m[2],16),int(m[3])) for m in re.finditer(r'^\s+(\S+)\s+(0x[\da-fA-F]+)\s+Data\s+(\d+)\s+([^\r\n]+)',path.read_text(),re.M) if m[4].endswith(('(NP_CAPTURE)','(NP2_CL_SELECTED)'))}
assert symbols(B/'application.map')==symbols(O/'application.map')
(O/'memory-proof.json').write_text(json.dumps(dict(status='PASS',unchanged_capture_symbols=len(symbols(O/'application.map')),scatter_sha256=sha(O/'application.sct'),claim='Parent scatter/capture buffers,256-rowIMU ABI and all other objects unchanged'),indent=2)+'\n')
pins={str(p):sha(p) for p in list((T/'Core/Src').glob('*'))+list((T/'Core/Inc').glob('*'))}
(O/'pending.json').write_text(json.dumps(dict(parent_crc32='72C9F2C6',baseline_failure=str(T/'usb-r3-cl1/quality.json'),expected_app_crc32='99CC44F9',compiler_commands={'xe_np_np2_closed_loop_spi':c},source_pins=pins,retained_objects=retained,scope='USB-only contiguous pressure-notice coalescing before recovery orStop, exact skipped range and actual startupvalid-from retained; WILDmath/NPpriority/sourceABI unchanged; MAG100 and zero-copygrid transfer retained'),indent=2)+'\n')
print('Single USBstream TU linked; producer/selected buffers unchanged')
