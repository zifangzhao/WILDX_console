"""Private USB-only prototype; no firmware build, device access or owner edits."""
from pathlib import Path
import hashlib,json,subprocess,difflib
O=Path(__file__).resolve().parent
T=Path('C:/Frank/Code/XE_NP/_artifacts/v2_usb_imu100_20261105')
S=T/'Core/Src/xe_np_np2_closed_loop_spi.c'
preimage=O/'actual_spi_preimage.c'
if not preimage.exists():preimage.write_bytes(Path('C:/Frank/Code/XE_NP/_artifacts/v2_usb_selected_detectors_20261105/Core/Src/xe_np_np2_closed_loop_spi.c').read_bytes())
K=O/'actual_kernel.c'
selected_source=O/'actual_selected.c'
if not K.exists():K.write_bytes(Path('C:/Frank/Code/XE_NP/Firmware/V1/Core/Src/np_cl_kernel.c').read_bytes())
if not selected_source.exists():selected_source.write_bytes((T/'Core/Src/xe_np_np2_cl_selected.c').read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
source=preimage.read_text();new=source
assert sha(preimage)=='73C6A3DF475529C97A9EC940423180EBC067CF45F587B47498621990F7059B00'
mark='void XE_NP_Np2ClosedLoopSpi_Gap('
insert='''#if XE_NP_IMAGE_ROLE == 2U
/* Raw pressure calls/rows remain distinct from coalesced interruption events. */
volatile uint32_t np2_cl_pressure_proto_diag[4];
#if XE_NP_NP2_CLOSED_LOOP_SPI_ENABLE && XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
static XE_NP_Np2ClosedLoopSpi *port_source;
#endif
#endif
'''
assert new.count(mark)==1;new=new.replace(mark,insert+mark,1)
old='''    if(!s || !s->enabled)return;
    s->gap_events++;s->gap_first=first;s->gap_end=end;s->reason=(uint8_t)reason;s->notice=1U;'''
replacement='''    if(!s || !s->enabled)return;
#if XE_NP_IMAGE_ROLE == 2U
#if XE_NP_NP2_CLOSED_LOOP_SPI_ENABLE && XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
    if(reason!=NP2_CL_SPI_REASON_PRESSURE && s==port_source && s->notice &&
       s->reason==NP2_CL_SPI_REASON_PRESSURE)XE_NP_Np2ClCarrier_PortDrain();
#endif
    if(reason==NP2_CL_SPI_REASON_PRESSURE){
        if(np2_cl_pressure_proto_diag[0]!=UINT32_MAX)np2_cl_pressure_proto_diag[0]++;
        uint64_t requested=end>=first?(end-first)/1600U:0U;
        np2_cl_pressure_proto_diag[1]=requested>UINT32_MAX-np2_cl_pressure_proto_diag[1]?UINT32_MAX:np2_cl_pressure_proto_diag[1]+(uint32_t)requested;
        if(s->in_head!=s->in_tail){
            uint64_t lo=s->input[s->in_tail%NP2_CL_SPI_INPUT_ROWS].frame_tick;
            uint64_t hi=s->input[(uint16_t)(s->in_head-1U)%NP2_CL_SPI_INPUT_ROWS].frame_tick+1600U;
            if(lo<first)first=lo;if(hi>end)end=hi;
        }
        if(s->out_head!=s->out_tail){
            uint64_t lo=s->output[s->out_tail%NP2_CL_SPI_OUTPUT_ROWS].source_tick;
            uint64_t hi=s->output[(uint16_t)(s->out_head-1U)%NP2_CL_SPI_OUTPUT_ROWS].input_end_tick;
            if(lo<first)first=lo;if(hi>end)end=hi;
        }
        if(s->notice && s->reason==NP2_CL_SPI_REASON_PRESSURE){
            if(first<s->gap_first)s->gap_first=first;if(end>s->gap_end)s->gap_end=end;
            s->in_head=s->in_tail=s->out_head=s->out_tail=0U;
            s->initialized=s->previous_bits=0U;s->bits[0]=s->bits[1]=0U;s->word[0]=s->word[1]=0U;
            s->expected=s->gap_end;
            if(np2_cl_pressure_proto_diag[2]!=UINT32_MAX)np2_cl_pressure_proto_diag[2]++;
            return;
        }
        if(np2_cl_pressure_proto_diag[3]!=UINT32_MAX)np2_cl_pressure_proto_diag[3]++;
    }
#endif
    s->gap_events++;s->gap_first=first;s->gap_end=end;s->reason=(uint8_t)reason;s->notice=1U;'''
assert new.count(old)==1;new=new.replace(old,replacement,1)
old='''    s->config.origin_valid=0U;
    XE_NP_Np2ClosedLoopSpi_Gap(s,0U,0U,reason);'''
replacement='''#if XE_NP_IMAGE_ROLE == 2U && XE_NP_NP2_CLOSED_LOOP_SPI_ENABLE && XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
    /* Preserve the known earlier gap before invalidating the later origin. */
    if(s==port_source && s->notice && s->reason==NP2_CL_SPI_REASON_PRESSURE)
        XE_NP_Np2ClCarrier_PortDrain();
#endif
    s->config.origin_valid=0U;
    XE_NP_Np2ClosedLoopSpi_Gap(s,0U,0U,reason);'''
assert new.count(old)==1;new=new.replace(old,replacement,1)
old='''    if(!s || !s->enabled)return 0U;
    if(limit>NP2_CL_SPI_SERVICE_ROWS)'''
replacement='''    if(!s || !s->enabled)return 0U;
#if XE_NP_IMAGE_ROLE == 2U
    /* Pop the recorded interruption before advancing any new filter history. */
    if(s->notice && s->reason==NP2_CL_SPI_REASON_PRESSURE)return 0U;
#endif
    if(limit>NP2_CL_SPI_SERVICE_ROWS)'''
assert new.count(old)==1;new=new.replace(old,replacement,1)
old='''    if(!s || !s->enabled || (s->in_head==s->in_tail && s->out_head==s->out_tail && !s->notice))return;
#if XE_NP_NP2_CLOSED_LOOP_PERF_ENABLE'''
replacement='''    if(!s || !s->enabled || (s->in_head==s->in_tail && s->out_head==s->out_tail && !s->notice))return;
#if XE_NP_IMAGE_ROLE == 2U
    if(pressure){
        if(s->in_tail!=s->in_head || s->out_tail!=s->out_head)
            XE_NP_Np2ClosedLoopSpi_Gap(s,s->expected,s->expected,NP2_CL_SPI_REASON_PRESSURE);
        return;
    }
    if(s->notice && s->reason==NP2_CL_SPI_REASON_PRESSURE)XE_NP_Np2ClCarrier_PortDrain();
#endif
#if XE_NP_NP2_CLOSED_LOOP_PERF_ENABLE'''
assert new.count(old)==1;new=new.replace(old,replacement,1)
(O/'actual_spi.c').write_text(source);(O/'prototype_spi.c').write_text(new)
(O/'proposal.patch').write_text(''.join(difflib.unified_diff(source.splitlines(True),new.splitlines(True),fromfile='actual_spi.c',tofile='prototype_spi.c')))
s=selected_source.read_text();sig='int XE_NP_Np2ClSelected_Offer('
a=s.index(sig);b=s.index('{',a);e=b+1;n=1
while n:n+=(s[e]=='{')-(s[e]=='}');e+=1
(O/'actual_selected_offer.inc').write_text(s[a:e]+'\n')
vc='C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat'
inc=['D:/Code/XE_NP_V2/Core/Inc',str(T/'Core/Inc'),'C:/Frank/Code/XE_NP/Firmware/V1/Core/Inc','D:/Code/WILDX_console/WILDX_console/Neuropixels/ClosedLoop']
cmd='call "'+vc+'" >nul && cl /nologo /std:c11 /W4 /WX /O2 /TC /DXE_NP_IMAGE_ROLE=2U /DXE_NP_NP2_CLOSED_LOOP_SPI_ENABLE=1U /DXE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE=1U '+' '.join('/I"'+p+'"' for p in inc)+' fixture.c "'+str(K)+'" /Fe:model.exe'
r=subprocess.run('cmd /d /s /c "'+cmd+'"',cwd=O,text=True,capture_output=True);(O/'compile.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
r=subprocess.run([str(O/'model.exe')],cwd=O,text=True,capture_output=True);(O/'result.txt').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
# Preprocess only the SPI TU forrole1; prove executable C text unchanged.
base='call "'+vc+'" >nul && cl /nologo /EP /TC /DXE_NP_IMAGE_ROLE=1U /DXE_NP_NP2_CLOSED_LOOP_SPI_ENABLE=0U /DXE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE=0U '+' '.join('/I"'+p+'"' for p in inc)
out=[]
for file in ('actual_spi.c','prototype_spi.c'):
    q=subprocess.run('cmd /d /s /c "'+base+' '+file+'"',cwd=O,capture_output=True,text=True);assert q.returncode==0,q.stderr;out.append(q.stdout)
assert ''.join(out[0].split())==''.join(out[1].split()),'Role1 preprocessed C tokens changed'
receipt=dict(status='PASS_PROTOTYPE_ONLY',hardware_access=False,firmware_build=False,source=str(S),source_sha256=sha(preimage),archived_preimage=str(preimage),native_newline_normalized_source_sha256=sha(O/'actual_spi.c'),selected_source_sha256=sha(selected_source),kernel=str(K),kernel_sha256=sha(K),prototype_sha256=sha(O/'prototype_spi.c'),patch_sha256=sha(O/'proposal.patch'),fixture_sha256=sha(O/'fixture.c'),command=cmd,result=r.stdout,role1_preprocessed_unchanged=True,
             limits=['Native prototype only; integrator must preserve ownership and epoch/fault semantics and qualify actual USB hardware.',
                     'Coalesced gap range includes all flushed queued data. Missing samples remain missing; this does not qualify gap-free detection from recording T0.',
                     'Existing PortStop drains notice; native STOP test models that existing Workspace_Drain operation. No recording/IMU code is changed.',
                     'Different-reason and origin-loss edges flush the earlier pressure interval for the matched bound port before the later fault; no cross-epoch inference is introduced.'])
(O/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
