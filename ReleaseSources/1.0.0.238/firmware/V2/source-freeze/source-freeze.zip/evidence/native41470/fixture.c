#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include <limits.h>
#include "xe_np_np2_closed_loop_spi.h"
#include "np_cl_kernel.h"
#include "np_cl_coefficients.h"
static unsigned checks;
#define CHECK(x) do{checks++;assert(x);}while(0)
static XE_NP_Np2ClosedLoopSpi source;
static NpClLane lane;
static uint32_t gap_count,training_count,ready_count,valid_count,first_training_count,first_ready_count;
static uint64_t gap_first,gap_end,first_valid_tick,training_tick,ready_tick;
static NpClEvent events_seen[32];static unsigned event_count;
static int sink(void *context,const NpClEvent *e){(void)context;assert(event_count<32);events_seen[event_count++]=*e;
 if(e->kind==NP_CL_EVENT_GAP)gap_count++;
 if(e->kind==NP_CL_EVENT_TRAINING){training_count++;training_tick=e->source_tick;first_training_count=valid_count;}
 if(e->kind==NP_CL_EVENT_READY){ready_count++;ready_tick=e->source_tick;first_ready_count=valid_count;}
 return 1;}
void XE_NP_Np2ClCarrier_PortDrain(void){XE_NP_Np2ClosedLoopSpiOutput row;
 while(XE_NP_Np2ClosedLoopSpi_Pop(&source,&row)){
  NpClInput in={row.source_tick,(float)row.nominal_q3[0]*0.125f,NP_CL_INPUT_VALID};
  if(!(row.flags&NP2_CL_SPI_VALID)){gap_first=row.source_tick;gap_end=row.input_end_tick;in.flags=!(row.flags&NP2_CL_SPI_TIME_VALID)?NP_CL_INPUT_FAULT:row.reason==NP2_CL_SPI_REASON_PRESSURE?NP_CL_INPUT_PRESSURE:NP_CL_INPUT_DISCONTINUITY;}
  else{if(!valid_count)first_valid_tick=row.source_tick;valid_count++;if((row.flags&NP2_CL_SPI_RESET)&&lane.have_tick)np_cl_reset(&lane,NP_CL_REASON_RESET);}
  (void)np_cl_input(&lane,&in);
 }}
#include "prototype_spi.c"
static uint32_t consumed,completed,events,first_frame,configured=1,count=1,field_bits[2]={0,12},offsets[2]={4,16};
static uint32_t selected[256][2],xe_np_np2_cl_selected_diag[32];
static struct{uint32_t CSR;} dma_regs;
static struct{uint32_t SR;} spi_regs;
#define GPDMA1_Channel15 (&dma_regs)
#define SPI1 (&spi_regs)
#define ERRORS 15U
#define SPI_FLAG_OVR 16U
#define ROWS 256U
#define __DMB() ((void)0)
static void note_offer(void){}
static void fault(uint32_t n){xe_np_np2_cl_selected_diag[2]=n;configured=0;}
static uint32_t frontier(void){return completed;}
#include "actual_selected_offer.inc"
static void init(void){
 XE_NP_Np2ClosedLoopSpiConfig c={0};c.sample_hz=20000;c.probe=2;c.lane=0;c.count=1;c.phase_verified=c.origin_valid=1;c.source_epoch=11;
 CHECK(XE_NP_Np2ClosedLoopSpi_Init(&source,&c)==0);XE_NP_Np2ClosedLoopSpi_PortBind(&source);
 NpClRate rate={1250,1};NpClCoefficients bank;CHECK(np_cl_coefficients_get(rate,6,&bank));
 NpClConfig cfg={0};cfg.sample_rate=rate;cfg.source_rate.num=32000000;cfg.source_rate.den=1;cfg.source_step=25600;cfg.session=9;cfg.probe=2;cfg.training_duration_ms=1000;cfg.threshold_gain=2;cfg.rectify=1;
 CHECK(np_cl_init(&lane,&cfg,&bank,sink,0)==NP_CL_OK);
 consumed=completed=first_frame=0;configured=1;count=1;
 memset(xe_np_np2_cl_selected_diag,0,sizeof(xe_np_np2_cl_selected_diag));memset((void*)np2_cl_pressure_proto_diag,0,sizeof(np2_cl_pressure_proto_diag));
 gap_count=training_count=ready_count=valid_count=event_count=0;gap_first=gap_end=first_valid_tick=training_tick=ready_tick=0;
}
static void frame(int pressure){
 uint64_t bits=((uint64_t)(2048U+(completed%3))<<52)|((uint64_t)2047U<<40);
 selected[completed%256][0]=(uint32_t)(bits>>32);selected[completed%256][1]=(uint32_t)bits;completed++;
 CHECK(XE_NP_Np2ClSelected_Offer(&source,(uint64_t)completed*1600+32,pressure)==1);
 XE_NP_Np2ClosedLoopSpi_PortService(pressure);
}
static void pressure_frames(unsigned n){for(unsigned i=0;i<n;i++)frame(1);}
int main(void){
 init();pressure_frames(400); /*20ms atnative20k*/
 CHECK(source.gap_events==1&&gap_count==0&&source.notice&&source.in_head==source.in_tail);
 CHECK(np2_cl_pressure_proto_diag[0]==400&&np2_cl_pressure_proto_diag[1]==400&&np2_cl_pressure_proto_diag[2]==399);
 CHECK(source.gap_first==0&&source.gap_end==640000);
 CHECK(XE_NP_Np2ClosedLoopSpi_Service(&source,16)==0);
 frame(0);CHECK(gap_count==1&&gap_first==0&&gap_end==640000);
 while(ready_count==0&&completed<25000)frame(0);
 CHECK(ready_count==1&&training_count==1);CHECK(first_valid_tick>=640000&&training_tick==first_valid_tick);
 CHECK(first_ready_count-first_training_count==1250);CHECK(ready_tick-training_tick==1250ULL*25600);
 CHECK(gap_count==1&&source.gap_events==1&&source.queue_overflows==0);
 uint64_t first_valid_saved=first_valid_tick,ready_saved=ready_tick;
 /*A genuine postREADY interruption must stillresetandretrain.*/
 uint32_t pressure_start=completed;pressure_frames(273);CHECK(gap_count==1&&source.gap_events==2);
 frame(0);CHECK(gap_count==2&&gap_first==(uint64_t)pressure_start*1600&&gap_end==(uint64_t)(pressure_start+273)*1600);
 uint32_t before=valid_count;
 while(ready_count<2&&completed<60000)frame(0);
 CHECK(ready_count==2&&training_count==2&&valid_count-before>=1251);
 /*STOPmustflushonependingintervalwithoutfakevalidoutput.*/
 pressure_start=completed;pressure_frames(12);uint32_t v=valid_count;XE_NP_Np2ClCarrier_PortDrain();
 CHECK(gap_count==3&&valid_count==v&&gap_first==(uint64_t)pressure_start*1600&&gap_end==(uint64_t)(pressure_start+12)*1600);
 /*Earliestqueuedinput/output bounds mustbeincludedinfirstflush.*/
 init();source.in_head=2;source.input[0].frame_tick=100;source.input[1].frame_tick=1700;
 source.out_head=1;source.output[0].source_tick=50;source.output[0].input_end_tick=500;
 XE_NP_Np2ClosedLoopSpi_Gap(&source,10000,11600,NP2_CL_SPI_REASON_PRESSURE);
 CHECK(source.gap_first==50&&source.gap_end==11600&&source.gap_events==1);
 XE_NP_Np2ClosedLoopSpi_Gap(&source,11600,13200,NP2_CL_SPI_REASON_PRESSURE);
 CHECK(source.gap_first==50&&source.gap_end==13200&&source.gap_events==1);
 XE_NP_Np2ClCarrier_PortDrain();CHECK(gap_count==1);
 init();pressure_frames(8);XE_NP_Np2ClosedLoopSpi_Gap(&source,16000,17600,NP2_CL_SPI_REASON_QUEUE);
 CHECK(gap_count==1&&gap_first==0&&gap_end==12800&&source.notice&&source.reason==NP2_CL_SPI_REASON_QUEUE);
 XE_NP_Np2ClCarrier_PortDrain();CHECK(gap_count==2&&lane.last_gap_reason==NP_CL_REASON_DISCONTINUITY);
 init();pressure_frames(8);XE_NP_Np2ClosedLoopSpi_LoseOrigin(&source,NP2_CL_SPI_REASON_SOURCE);
 CHECK(gap_count==1&&gap_first==0&&gap_end==12800&&!source.config.origin_valid);
 XE_NP_Np2ClCarrier_PortDrain();CHECK(gap_count==2&&lane.last_gap_reason==NP_CL_REASON_FAULT);
 printf("PASS %u checks:20ms400 skippedframes ->1fullrangeGAP/1WILDreset; firstvalid=%llu READY=%llu; full1250steptraining; separate/postREADY/STOP/queuedbounds/faultordering verified\n",checks,(unsigned long long)first_valid_saved,(unsigned long long)ready_saved);
 return 0;
}
