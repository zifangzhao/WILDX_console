#ifndef XE_NP_NP2_CLOSED_LOOP_SPI_H
#define XE_NP_NP2_CLOSED_LOOP_SPI_H
#include <stdint.h>
#ifndef XE_NP_NP2_CLOSED_LOOP_SPI_ENABLE
#define XE_NP_NP2_CLOSED_LOOP_SPI_ENABLE 0U
#endif
#if XE_NP_NP2_CLOSED_LOOP_SPI_ENABLE!=0U && XE_NP_NP2_CLOSED_LOOP_SPI_ENABLE!=1U
#error "Closed-loop SPI opt-in must be boolean"
#endif
/* Software-only, foreground adapter. No register, GPIO, DMA or output ownership.
 * Input bit0 is the first chronological SPI bit; ADC words are MSB first.
 * Existing P3 lane2 is the sole SPI2 tap choice. */
#define NP2_CL_SPI_CHANNELS 2U
#define NP2_CL_SPI_INPUT_ROWS 64U
#define NP2_CL_SPI_OUTPUT_ROWS 8U
#define NP2_CL_SPI_MAX_BYTES 2048U
#define NP2_CL_SPI_SERVICE_ROWS 16U
#define NP2_CL_SPI_HZ 1250U
#define NP2_CL_SPI_FILTER_ID 1U
#define NP2_CL_SPI_VALID 1U
#define NP2_CL_SPI_RESET 2U
#define NP2_CL_SPI_GAP 4U
#define NP2_CL_SPI_TIME_VALID 8U
#define NP2_CL_SPI_REASON_SOURCE 1U
#define NP2_CL_SPI_REASON_PRESSURE 2U
#define NP2_CL_SPI_REASON_QUEUE 3U
#define NP2_CL_SPI_REASON_BOUNDS 4U

typedef struct {
    uint32_t sample_hz;
    uint16_t phase; /* Verified (absolute source tick + phase) % 1600 framing. */
    uint16_t channel[2]; /* Logical ADC channels, NOT electrode/site numbers. */
    uint8_t probe,lane,count,phase_verified;
    uint8_t origin_valid;
    uint32_t source_epoch; /* Supplied by acquisition owner, never inferred. */
} XE_NP_Np2ClosedLoopSpiConfig;
typedef struct {
    uint64_t source_tick,input_end_tick;
    uint32_t delay_source_ticks,flags,reason;
    int16_t nominal_q3[2]; /* 8 * (2048 - raw12), after anti-alias filtering. */
    uint8_t count,reserved[3];
    uint32_t source_epoch;
} XE_NP_Np2ClosedLoopSpiOutput;
typedef struct { uint64_t frame_tick; uint16_t word[2]; } XE_NP_Np2ClosedLoopSpiRow;
typedef struct { uint32_t integ[4],comb[4]; int16_t fir[41]; } XE_NP_Np2ClosedLoopSpiFilter;
typedef struct {
    XE_NP_Np2ClosedLoopSpiConfig config;
    XE_NP_Np2ClosedLoopSpiRow input[NP2_CL_SPI_INPUT_ROWS];
    XE_NP_Np2ClosedLoopSpiOutput output[NP2_CL_SPI_OUTPUT_ROWS];
    XE_NP_Np2ClosedLoopSpiFilter filter[2];
    uint64_t expected,frame_tick,gap_first,gap_end;
    uint32_t reciprocal,delay_source_ticks,input_words,output_rows,gap_events,queue_overflows;
    uint16_t offset[2],word[2],previous;
    uint16_t in_head,in_tail,out_head,out_tail;
    uint16_t intermediate_count;
    uint8_t bits[2],previous_bits,initialized,enabled,notice,reason,reset_pending;
    uint8_t ratio,cic_at,fir_at;
} XE_NP_Np2ClosedLoopSpi;
int XE_NP_Np2ClosedLoopSpi_Init(XE_NP_Np2ClosedLoopSpi *,const XE_NP_Np2ClosedLoopSpiConfig *);
/* Call only after recording has accepted/released the source. No borrowed
 * pointer is retained. At most 2048 packed bytes / 11 native frames per offer.
 * pressure drops detector work, never recording. Missing framing is a gap. */
int XE_NP_Np2ClosedLoopSpi_Offer(XE_NP_Np2ClosedLoopSpi *,const uint8_t *,uint32_t bytes,uint64_t first_tick,int pressure);
/* Unknown physical origin invalidates time and suppresses all input until a
 * new stopped-time Init with an owner-supplied epoch/origin. No ordinal repair. */
void XE_NP_Np2ClosedLoopSpi_LoseOrigin(XE_NP_Np2ClosedLoopSpi *,uint32_t reason);
void XE_NP_Np2ClosedLoopSpi_Gap(XE_NP_Np2ClosedLoopSpi *,uint64_t first,uint64_t end,uint32_t reason);
/* Run only AFTER the recording transport/writer has been serviced. */
uint32_t XE_NP_Np2ClosedLoopSpi_Service(XE_NP_Np2ClosedLoopSpi *,uint32_t max_rows);
/* GAP/RESET without VALID resets the detector; never detect on that row.
 * VALID starts only after CIC+FIR warmup; source_tick includes filter-delay
 * correction in the original MCLK/PSSI tick frame (source Hz=sample_hz*1600).
 * input_end_tick is the last word boundary, not wall-clock processing time. */
int XE_NP_Np2ClosedLoopSpi_Pop(XE_NP_Np2ClosedLoopSpi *,XE_NP_Np2ClosedLoopSpiOutput *);
#if XE_NP_NP2_CLOSED_LOOP_SPI_ENABLE
/* Caller configures/enables at stopped time; never auto-arm a detector. */
void XE_NP_Np2ClosedLoopSpi_PortBind(XE_NP_Np2ClosedLoopSpi *);
void XE_NP_Np2ClosedLoopSpi_PortOfferP3(const uint8_t *,uint32_t bytes,uint64_t first,uint32_t hz,int pressure);
void XE_NP_Np2ClosedLoopSpi_PortService(int pressure);
#endif
#endif
