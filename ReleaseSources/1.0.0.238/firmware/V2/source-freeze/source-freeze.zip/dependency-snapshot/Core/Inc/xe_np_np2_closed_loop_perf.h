#ifndef XE_NP_NP2_CLOSED_LOOP_PERF_H
#define XE_NP_NP2_CLOSED_LOOP_PERF_H
#include <stdint.h>
#ifndef XE_NP_NP2_CLOSED_LOOP_PERF_ENABLE
#define XE_NP_NP2_CLOSED_LOOP_PERF_ENABLE 0U
#endif
#if XE_NP_NP2_CLOSED_LOOP_PERF_ENABLE
/* Candidate-only diagnostics. Interrupt/preemption cycles are INCLUDED.
 * Event is a subset of Kernel, and Filter/Kernel are subsets of Service:
 * never sum all five buckets as independent CPU time. Decode excludes the
 * existing SPI receiver/DMA/CopyD8. No counter reset or new wire messages. */
enum {NP2_CL_PERF_DECODE=0,NP2_CL_PERF_FILTER=1,NP2_CL_PERF_KERNEL=2,NP2_CL_PERF_EVENT=3,NP2_CL_PERF_SERVICE=4};
typedef struct {uint64_t cycles,work;uint32_t calls,max_cycles;} XE_NP_Np2ClPerfBucket;
typedef struct {XE_NP_Np2ClPerfBucket bucket[5];uint32_t core_hz,cycles_valid;} XE_NP_Np2ClPerf;
static inline uint32_t XE_NP_Np2ClPerf_Now(void)
{return *(volatile const uint32_t *)(uintptr_t)0xe0001004U;}
static inline uint32_t XE_NP_Np2ClPerf_Available(void)
{uint32_t v=*(volatile const uint32_t *)(uintptr_t)0xe0001000U;return (v&1U) && !(v&(1U<<25U));}
static inline uint32_t XE_NP_Np2ClPerf_Begin(const XE_NP_Np2ClPerf *p)
{return p && p->cycles_valid?XE_NP_Np2ClPerf_Now():0U;}
static inline void XE_NP_Np2ClPerf_End(XE_NP_Np2ClPerf *p,unsigned kind,uint32_t began,uint32_t work)
{
    if(!p)return;XE_NP_Np2ClPerfBucket *b=&p->bucket[kind];
    if(b->calls!=UINT32_MAX)b->calls++;b->work+=work;
    if(p->cycles_valid){uint32_t elapsed=XE_NP_Np2ClPerf_Now()-began;b->cycles+=elapsed;if(elapsed>b->max_cycles)b->max_cycles=elapsed;}
}
XE_NP_Np2ClPerf *XE_NP_Np2ClCarrier_PortPerf(void);
#endif
#endif
