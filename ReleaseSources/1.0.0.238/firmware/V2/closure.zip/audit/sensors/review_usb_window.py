"""USB saved-prefix IMU interval and per-second update comparison, sidecars only."""
from pathlib import Path
from fractions import Fraction
import argparse,csv,hashlib,json,struct,zlib
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
def fields(p):return dict(x.split('=',1) for x in p.read_text().splitlines() if '=' in x)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('folder',type=Path);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists();e=a.folder.resolve()
 phase=(e/'imu_grid_phase.bin').read_bytes();terminal=(e/'imu_grid_terminal.bin').read_bytes()
 assert len(phase)==84 and zlib.crc32(phase[:80])==struct.unpack_from('<I',phase,80)[0]
 assert len(terminal)==80 and zlib.crc32(terminal[:76])==struct.unpack_from('<I',terminal,76)[0]
 first=struct.unpack_from('<Q',phase,44)[0];lo,hi=struct.unpack_from('<qq',phase,52);den,jitter,flags=struct.unpack_from('<III',phase,68)
 utc=json.loads((e/'recording_start_utc.json').read_text());reference=utc['reference_source_tick'];hz=utc['reference_source_hz']
 meta=json.loads((e/'first_sample_timestamps.json').read_text());anchor=meta['anchor'];status=fields(e/'neuropixels_np2usb_status.txt');grid=fields(e/'imu_grid_status.txt')
 assert anchor['exported_source_origin']==0 and hz==32000000 and status['raw_dropped_blocks']=='0' and status['complete']=='True'
 assert status['verified_blocks']==status['received_blocks']
 extent=int(status['verified_blocks'])*int(status['ticks_per_block'])
 rows=list(csv.DictReader((e/'imu_grid_segments.csv').open()));assert len(rows)==1
 begin=int(rows[0]['first_slot']);count=int(rows[0]['row_count']);last=begin+count-1;assert first==begin==0
 step=hz//1250
 def interval(slot):
  j=0 if slot==first else jitter
  l=Fraction(reference+(slot-first)*step-j)+Fraction(lo,den);u=Fraction(reference+(slot-first)*step+j)+Fraction(hi,den)
  return dict(slot=slot,lower_tick=int(l) if l.denominator==1 else str(l),upper_tick=int(u) if u.denominator==1 else str(u),lower_relative_to_saved_end_us=float((l-extent)*1000000/hz),upper_relative_to_saved_end_us=float((u-extent)*1000000/hz))
 remaining=extent-reference-(last-first)*step-jitter
 verified=remaining>=0 and hi<=remaining*den and lo+(step-jitter)*den>=0
 assert verified==(grid['source_window_verified']=='True')
 intervals=[interval(last-2),interval(last-1),interval(last)]
 base=json.loads((HERE/'usb-r3-cl0-review.json').read_text());current=json.loads((HERE/(e.name+'-review.json')).read_text())
 comparison={}
 for group in ('ag','mag'):
  name=group+'_nonrepeat_rows_per_second';b=base['grid'][name];c=current['grid'][name]
  comparison[group]=dict(baseline_nonrepeat_per_second=b,current_nonrepeat_per_second=c,delta_hz=c-b,relative_delta_percent=(c-b)/b*100,baseline_sparse_counter_advance_hz=base['native'][group]['sequence_advance_hz'],current_sparse_counter_advance_hz=current['native'][group]['sequence_advance_hz'])
 r=dict(status='RETAINED_INTERVALS_WITHIN_SAVED_PREFIX' if verified else 'FALSE_PRESERVED_RETAINED_TERMINAL_BOUND_OUTSIDE_SAVED_PREFIX',folder=str(e),source_extent_ticks=extent,extent_evidence='complete verified contiguous USBblocks×ticks_per_block, exported source origin0; decoded neural rows/payload not reread',reference_tick=reference,source_hz=hz,step_ticks=step,phase=dict(first=first,lower_numerator=lo,upper_numerator=hi,denominator=den,jitter_ticks=jitter,flags=flags,crc_validated=True),observed=dict(first=begin,last=last,count=count,missing_intervals=list(csv.DictReader((e/'imu_grid_gaps.csv').open()))),writer_complete=dict(remaining_ticks=remaining,required_upper_numerator=hi,available_upper_numerator=remaining*den,source_window_verified=verified),first_interval=interval(first),last_three_intervals=intervals,terminal=dict(crc_validated=True,final_exclusive=struct.unpack_from('<Q',terminal,52)[0],final_slot_known=grid['final_slot_known'],queue_dropped=grid['queue_dropped'],scheduler_missing=grid['scheduler_missing']),update_comparison_to_detector_off=comparison,interpretation=['All saved scheduled rows are contiguous and valid; false source_window is preserved and does not invent a missing sensor row.','Intervals are relative to the complete retained NP prefix only. Unknown physical partial NP suffix and unknown final scheduled ordinal prevent a physical after-stop or terminal completeness claim.','Value updates per source second are compared with detector-off baseline; this is the measured run comparison, not a universal CPU/load or physical-conversion guarantee.'],inputs=[dict(path=str(p),sha256=sha(p)) for p in (e/'imu_grid_phase.bin',e/'imu_grid_terminal.bin',e/'imu_grid_segments.csv',e/'imu_grid_gaps.csv',e/'imu_grid_status.txt',e/'neuropixels_np2usb_status.txt',e/'recording_start_utc.json',e/'first_sample_timestamps.json')])
 a.output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ('status','source_extent_ticks','writer_complete','last_three_intervals','update_comparison_to_detector_off')},indent=2));print('receiptSHA256 '+sha(a.output))
if __name__=='__main__':main()
