"""Read only USB sensor sidecars; no neural payloads or device access."""
from pathlib import Path
import argparse,collections,hashlib,json,struct
AXES=('accel_x','accel_y','accel_z','gyro_x','gyro_y','gyro_z','mag_x','mag_y','mag_z')
def sha(b):return hashlib.sha256(b).hexdigest().upper()
def fields(p):return dict(x.split('=',1) for x in p.read_text().splitlines() if '=' in x)
def scaled(v,i):
 n,d=(4096,1000000) if i<3 else (164,10000) if i<6 else (1,300)
 q=(abs(v)*n+d//2)//d
 return -q if v<0 else q

def axes(rows):
 return {a:dict(min=min(r[i] for r in rows),max=max(r[i] for r in rows),unique=len({r[i] for r in rows}),changes=sum(x[i]!=y[i] for x,y in zip(rows,rows[1:]))) for i,a in enumerate(AXES)}
def sequence(rows,seq,tick):
 v=[u[seq] for u in rows];t=[u[tick] for u in rows];steps=[(b-a)&0xffffffff for a,b in zip(v,v[1:])];forward=[x for x in steps if 0<x<0x80000000];span=(t[-1]-t[0])&0xffffffff
 return dict(first=v[0],last=v[-1],source_ms_span=span,sequence_advance=sum(forward),sequence_advance_hz=sum(forward)*1000/span if span else None,retained_observation_hz=(len(rows)-1)*1000/span if span else None,repeat_snapshots=steps.count(0),unobserved_sequence_numbers=sum(x-1 for x in forward),step_counts=dict(sorted(collections.Counter(steps).items())),backwards_or_ambiguous=sum(x>=0x80000000 for x in steps),scope='Counters observed in sparse bulk metadata. Skipped counter values are unobserved snapshots, not primary-grid loss or proof of dropped physical conversions.')
def analyze(folder):
 folder=folder.resolve(strict=True);names=('imu_native_samples.jsonl','imu_native_samples_status.json','imu_snapshots.bin','analogin.dat','analogin_validity.dat','analogin_encoding.txt','imu_observation_status.txt','imu_grid_status.txt')
 data={n:(folder/n).read_bytes() for n in names};files={n:dict(bytes=len(b),sha256=sha(b)) for n,b in data.items()}
 j=[json.loads(x) for x in data['imu_native_samples.jsonl'].decode().splitlines()];samples=[x for x in j if x['kind']=='sample'];metadata=[x for x in j if x['kind']=='metadata'];assert len(metadata)==1
 status=json.loads(data['imu_native_samples_status.json']);enc=fields(folder/'analogin_encoding.txt');obs=fields(folder/'imu_observation_status.txt');grid=fields(folder/'imu_grid_status.txt')
 assert len(data['imu_snapshots.bin'])%140==0
 raw=[struct.unpack_from('<35I',data['imu_snapshots.bin'],i) for i in range(0,len(data['imu_snapshots.bin']),140)]
 assert all(u[0]==0x31534e53 and u[1]==1 for u in raw)
 invalid=[i for i,u in enumerate(raw) if not(u[3]&1) or not u[5]]
 native=[];native_axes=[]
 for s in samples:
  b=bytes.fromhex(s['raw_snapshot_hex']);assert len(b)==140;u=struct.unpack('<35I',b);v=struct.unpack_from('<9i',b,48)
  assert s['sequence']==u[5] and s['valid']==u[3] and tuple(s['ag']+s['mag'])==v
  assert (u[3]&3)==3 and u[26]==0
  native.append(u);native_axes.append(v)
 assert len(samples)==status['accepted_samples']==status['retained_samples']
 assert len(raw)==status['observations'] and len(invalid)==status['invalid_observations']
 ag=sequence(native,5,8);mag=sequence(native,6,9)
 assert ag['unobserved_sequence_numbers']==status['sequence_gaps']
 assert not ag['backwards_or_ambiguous'] and not mag['backwards_or_ambiguous']
 valid=data['analogin_validity.dat'];analog=data['analogin.dat'];assert len(analog)==32*len(valid)
 counts=collections.Counter();prev=None;repeat_bad=0;grid_axes=[];grid_ag=set();grid_mag=set();pc_words=collections.Counter()
 for i,f in enumerate(valid):
  w=struct.unpack_from('<16h',analog,i*32);v=w[1:10];assert not f&~63
  assert w[0]==0 and w[10]==-32768 and w[11]==-1 and w[12:14]==(0,0)
  pc_words[struct.unpack_from('<I',analog,i*32+28)[0]]+=1
  if not f&1:
   assert f==0 and v==(-32768,)*9;counts['missing']+=1;prev=None;continue
  counts['observed']+=1;grid_axes.append(v)
  for name,mask in (('ag_valid',2),('mag_valid',4),('ag_repeat',8),('mag_repeat',16),('error',32)):
   if f&mask:counts[name]+=1
  if f&2:grid_ag.add(v[:6]);counts['ag_nonrepeat']+=not bool(f&8)
  if f&4:grid_mag.add(v[6:]);counts['mag_nonrepeat']+=not bool(f&16)
  if prev:
   if f&8 and prev[0]&2 and v[:6]!=prev[1][:6]:repeat_bad+=1
   if f&16 and prev[0]&4 and v[6:]!=prev[1][6:]:repeat_bad+=1
  prev=(f,v)
 for key,field in (('observed','observed'),('missing','missing'),('ag_repeat','ag_repeated'),('mag_repeat','mag_repeated')):assert counts[key]==int(enc[field])
 q=[tuple(scaled(x,i) for i,x in enumerate(v)) for v in native_axes]
 matches_ag=sum(v[:6] in grid_ag for v in q);matches_mag=sum(v[6:] in grid_mag for v in q)
 assert counts['observed']==len(valid) and not counts['missing'] and not counts['error'] and not repeat_bad
 assert counts['ag_valid']==len(valid) and counts['mag_valid']==len(valid)
 assert grid['queue_dropped']=='0' and grid['scheduler_missing']=='0' and grid['error']=='none'
 assert all(x['changes'] for x in axes(native_axes).values()) and all(x['changes'] for x in axes(grid_axes).values())
 dur=len(valid)/1250
 return dict(status='PRIMARY_GRID_VALID_WITH_UPDATING_NATIVE_SENSORS',folder=str(folder),native=dict(observations=len(raw),accepted=len(native),invalid_observation_indices=invalid,invalid_prefix_only=invalid==list(range(len(invalid))),first_invalid_flags=raw[0][3] if invalid else None,valid_flags=dict(collections.Counter(str(u[3]) for u in raw)),imu_error_codes=dict(collections.Counter(str(u[26]) for u in raw)),environment_error_codes=dict(collections.Counter(str(u[27]) for u in raw)),ag=ag,mag=mag,axes=axes(native_axes),firmware_counters_first_last={k:[raw[0][i],raw[-1][i]] for k,i in (('imu_io_errors',28),('imu_timeouts',30),('missed_imu_estimate',32),('invalid_mag_estimate',33),('ignored_completions',34))}),
 grid=dict(rows=len(valid),extent_seconds=dur,counts=dict(counts),repeat_value_mismatches=repeat_bad,axes=axes(grid_axes),ag_nonrepeat_rows_per_second=counts['ag_nonrepeat']/dur,mag_nonrepeat_rows_per_second=counts['mag_nonrepeat']/dur,PC_time_word_values=dict(pc_words),phase_qualified=grid['phase_qualified'],source_window_verified=grid['source_window_verified'],terminal_final_slot_known=grid['final_slot_known']),
 quantization_compatibility=dict(accepted_native_snapshots=len(q),scaled_AG_tuple_found_in_primary_grid=matches_ag,scaled_MAG_tuple_found_in_primary_grid=matches_mag,scope='Value-membership comparison only. Native sparse observations and scheduled cache copies are independent observations; membership does not prove physical conversion or exact row-time alignment.'),files=files,
 limits=['One invalid startup snapshot retained as invalid; accepted journal intentionally excludes it.','Sparse native journal is capped20Hz; AG sequence gaps do not measure missing primary1250Hz rows.','Candidate target is nominal200HzAG/100HzMAG; measured rates are reported separately and do not imply1250Hz sensor conversions.','1250Hz scheduled cache-copy stream repeats held sensor values; not1250Hz sensor conversions or conversion-phase lock.','Relative phase/source-window qualification is retained as recorded; unknown final scheduled ordinal and physical terminal tail remain unknown.','No neural DAT payload opened; no device access or new capture.'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('folder',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args();assert not a.output.exists(),'Fresh receipt required';r=analyze(a.folder);a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(dict(status=r['status'],native_observations=r['native']['observations'],startup_invalid=r['native']['invalid_observation_indices'],AG_Hz=r['native']['ag']['sequence_advance_hz'],MAG_Hz=r['native']['mag']['sequence_advance_hz'],grid=r['grid']['counts'],scaled_matches=r['quantization_compatibility'],receipt_sha256=sha(a.output.read_bytes())),indent=2))
