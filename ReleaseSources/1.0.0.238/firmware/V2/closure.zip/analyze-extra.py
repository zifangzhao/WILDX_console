from pathlib import Path
import json,struct,sys,hashlib
T=Path(__file__).resolve().parent;r=T/sys.argv[1]
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
u=lambda name:struct.unpack('<'+'I'*((r/name).stat().st_size//4),(r/name).read_bytes())
s=load(T/'audit/sensors'/(r.name+'-review.json'));q=load(r/'quality.json')
d=u('xe_np_grid_retained_diag.bin');c=u('xe_np_aux_cost_diag.bin');result=load(r/'usb-report.json')['result']
checks=dict(ordinary_quality=q['status']=='PASS',AG_profile=190<=s['native']['ag']['sequence_advance_hz']<=205,MAG100=90<=s['native']['mag']['sequence_advance_hz']<=105,valid_grid=s['grid']['counts'].get('missing',0)==0 and s['grid']['counts'].get('error',0)==0,retained_guard_exercised=d[3]>0,combined_transfer_exercised=d[7]>0,no_grid_second_payload=c[11:]==(0,0,0,0,0),actual_header_submissions=c[6]==d[7],no_cost_counter_errors=c[2]==c[7]==c[12]==0,source_memory_history=(r/'usb_read_history_lab.csv').exists())
bins={}
for name,i in [('provider',1),('header_and_combined_submit',6),('second_payload_submit',11)]:
 v=c[i:i+5];bins[name]=dict(calls=v[0],invalid=v[1],max_cycles=v[2],max_us=v[2]/128,total_cycles=v[3],saturated=v[4],instrumented_percent_of_capture=100*v[3]/(128e6*result['DataSeconds']))
out=dict(status='PASS' if all(checks.values()) else 'FAIL',checks=checks,profile='AG200/MAG100,1250Hz scheduledheld-valuegrid,unchangedgains/repetitions',native_hz={k:s['native'][k]['sequence_advance_hz'] for k in ['ag','mag']},grid_nonrepeat_per_second={k:s['grid'][k+'_nonrepeat_rows_per_second'] for k in ['ag','mag']},grid_counters=s['grid']['counts'],firmware_sensor_error_and_estimates=s['native']['firmware_counters_first_last'],guard=dict(attempts=d[2],grants=d[3],max_EP82_inflight_ms=d[4],max_source_backlog_at_grant=d[5],max_guard_snapshot_us=d[6],combined_grid_attempts=d[7]),cost=bins,lab_observer='Existing final238 opt-in1024-entry in-memory history, no active filewrites; observation overhead present, not USB packet timing.',cost_scope='Instrumented cycles include preemption; not wholeCPU, WCET or a universal host/bus-latency guarantee. RetainedCRC was already nibble-optimized; no CRC speedup claimed.')
(r/'imu100-extra.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));assert out['status']=='PASS'
