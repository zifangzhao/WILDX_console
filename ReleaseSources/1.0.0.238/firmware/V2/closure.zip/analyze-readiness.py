"""Validate the production READY boundary without hiding a startup interruption."""
from pathlib import Path
import csv,json,struct,sys
T=Path(__file__).resolve().parent;r=T/sys.argv[1];lanes=int(sys.argv[2])
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
q=load(r/'quality.json');s=load(r/'stopped-summary.json')
events=list(csv.DictReader((r/'closed_loop_events.csv').open()))
ready={};training={};gaps=[];checks={}
for lane in range(lanes):
 e=[x for x in events if int(x['lane'])==lane]
 rs=[x for x in e if x['kind']=='ready'];assert rs,'No actual READY event'
 first=rs[0];tick=int(first['source_tick']);ts=[x for x in e if x['kind']=='training' and int(x['source_tick'])<=tick];assert ts
 last=ts[-1];delta=tick-int(last['source_tick'])
 ready[str(lane)]=dict(source_tick=tick,input_end_tick=int(first['input_end_tick']),seconds_from_NP_origin=tick/32000000,sequence=int(first['sequence']),probe=2,channel=lane)
 training[str(lane)]=dict(recovery_training_source_tick=int(last['source_tick']),duration_ticks=delta,duration_seconds=delta/32000000)
 checks['full_training_lane'+str(lane)]=32000000<=delta<=32000000+25600
 checks['no_detection_before_READY_lane'+str(lane)]=all(int(x['source_tick'])>=tick for x in e if x['kind'] in ['rise','fall'])
 for x in e:
  if x['kind']=='gap':
   before=int(x['input_end_tick'])<tick and int(x['source_tick'])<=int(x['input_end_tick'])
   gaps.append(dict(lane=lane,first_source_tick=int(x['source_tick']),end_source_tick=int(x['input_end_tick']),reason=int(x['reason']),before_first_READY=before))
 checks['no_gap_after_READY_lane'+str(lane)]=all(x['before_first_READY'] and x['reason']==4 for x in gaps if x['lane']==lane)
checks['strict_recording_and_IMU']=all(q['checks'][x] for x in ['normal_complete','np_all_blocks_verified','np_firmware_errors_zero','imu_no_new_losses','imu_enforced_and_phase','imu_rows_retained','imu_cadence','selected_native_matches_dat'])
checks['all_events_retained_and_bound']=len(events)==s['carrier']['committed'] and all(x['source_time_valid']=='1' and x['cumulative_drops']=='0' and x['missing_records_before']=='0' and int(x['probe'])==2 and int(x['channel'])==int(x['lane']) for x in events)
checks['carrier_and_source_queue_clean']=all(s['carrier'][k]==0 for k in ['dropped','tail_dropped','rejected','quality_unknown']) and s['source']['source_queue_overflows']==0
unique={(x['first_source_tick'],x['end_source_tick'],x['reason']) for x in gaps}
checks['every_source_interruption_recorded']=len(unique)==s['source']['source_gap_events'] and len(gaps)==len(unique)*lanes
extent=q['np_blocks']*40960
checks['meaningful_READY_span']=(extent-max(x['source_tick'] for x in ready.values()))/32000000>=(5 if q['seconds']<30 else 30)
pressure=struct.unpack('<4I',(r/'np2_cl_pressure_proto_diag.bin').read_bytes())
out=dict(status=('PASS_AFTER_RECORDED_STARTUP_INTERRUPTION' if gaps else 'PASS_NO_SOURCE_INTERRUPTION') if all(checks.values()) else 'FAIL',checks=checks,source_hz=32000000,actual_valid_from_by_lane=ready,full_training_after_last_reset=training,recorded_startup_interruption_intervals=gaps,raw_pressure=dict(calls=pressure[0],requested_skipped_frame_units=pressure[1],coalesced_extensions=pressure[2],reset_episodes=pressure[3]),original_zero_from_T0_quality_status=q['status'],source_gap_intervals=s['source']['source_gap_events'],post_READY_gap_count=sum(not x['before_first_READY'] for x in gaps),carrier_drops=s['carrier']['dropped'],policy='Detections are valid only from each actual READY source tick after full unchanged WILD training. Any recorded pressure prefix remains unavailable; raw NP/IMU start and saved data are unchanged. Every interruption after READY fails this qualification. No silent splice or zero-gap-from-NP-T0 claim.',native_model_receipt=str(T.parent/'v2_cl_pressure_model_20261105/receipt.json'))
(r/'readiness-scope.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));assert out['status'].startswith('PASS')
