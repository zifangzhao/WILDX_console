using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web.Script.Serialization;

namespace USB512_interface
{
    internal sealed class NpFirstSyncSdUtcContext
    {
        internal string ExpectedUid,CoordinateEvidence;
        internal ulong ExpectedToken=0;
        internal NpFirstSyncBinding CoordinateBinding=null;
        // Neither current producer is qualified. Only independently established
        // final-generation exported-source-zero equivalence may set this true.
        internal bool ExportedSourceZeroConfirmed=false;
    }
    internal sealed class NpFirstSyncSdUtcState
    {
        internal NpFirstSyncSdBound Bound;
        internal byte[] ClockSector;
        internal string Error,OriginalCrc;
        internal uint ClockGeneration;
    }
    internal static class NpFirstSyncSdUtc
    {
        const string StatusFile="first_sync_sd_status.json";
        static readonly JavaScriptSerializer Json=new JavaScriptSerializer();
        static NpFirstSyncBinding Binding(NpFirstSyncReceipt r){return new NpFirstSyncBinding {Family=r.Family,Session=r.Session,Generation=r.Generation,
            SourceEpoch=r.SourceEpoch,Domain=r.Domain,CounterHz=r.CounterHz,ProfileCrc=r.ProfileCrc,Mask=r.Mask,ApHz=r.ApHz};}
        static bool Flag(Dictionary<string,object> d,string key){object value;return d.TryGetValue(key,out value)&&value is bool&&(bool)value;}
        internal static NpFirstSyncSdUtcState Read(byte[] sector,uint session,int family,uint apHz,NpFirstSyncSdUtcContext context=null)
        {
            if(sector==null||sector.Length!=512||sector.Skip(160).Take(348).All(b=>b==0))return null;
            var state=new NpFirstSyncSdUtcState();
            try{
                state.Bound=NpFirstSyncSd.ReadSector(sector,family,session,apHz,context==null?null:context.ExpectedUid,context==null?0:context.ExpectedToken);
                if(state.Bound==null)return null;
                state.OriginalCrc=BitConverter.ToUInt32(sector,508).ToString("X8",CultureInfo.InvariantCulture);
                state.ClockGeneration=BitConverter.ToUInt32(sector,20); // clock sync generation, never capture generation
                state.ClockSector=(byte[])sector.Clone();Array.Clear(state.ClockSector,160,348);
                NpAcquisitionAnchor.Put(state.ClockSector,508,NpAcquisitionAnchor.Crc(state.ClockSector,508));
            }catch(Exception error){state.Error=error.Message;state.Bound=null;state.ClockSector=null;}
            return state;
        }
        static void Status(string folder,NpFirstSyncSdUtcState state,bool clockValid,bool coordinateProof,string error)
        {
            try{File.WriteAllText(Path.Combine(folder,StatusFile),Json.Serialize(new {schema=1,raw_file="recorded_clock.bin",bound_receipt_valid=state.Bound!=null,
                legacy_clock_and_provider_area_valid=clockValid,exported_source_zero_coordinate_confirmed=coordinateProof,
                clock_sync_generation=state.Bound==null?(uint?)null:state.ClockGeneration,capture_generation=state.Bound==null?(uint?)null:state.Bound.Receipt.Generation,
                error=error,limitation="Current V1/V2 producers do not qualify source-clock mapping. UTC2 alone, ARM, discovery, release and file-download time cannot establish STARTBYTE UTC."}));}catch{}
        }
        internal static void Write(string folder,NpFirstSyncSdUtcState state,IEnumerable<Dictionary<string,object>> rows,uint session,int family,uint apHz,
            bool clockValid,ulong lo,ulong hi,uint uncertainty,NpFirstSyncSdUtcContext context=null)
        {
            var items=rows.ToList();Dictionary<string,object> report=null;string error=state.Error;
            if(error==null&&!clockValid)error="Legacy UTC2 clock/provider area is invalid or unavailable; STARTBYTE UTC remains unknown.";
            bool coordinateProof=context!=null&&context.ExportedSourceZeroConfirmed&&!String.IsNullOrWhiteSpace(context.CoordinateEvidence)&&state.Bound!=null&&
                context.ExpectedToken==state.Bound.Token&&context.ExpectedToken!=0&&String.Equals(context.ExpectedUid,state.Bound.Uid,StringComparison.OrdinalIgnoreCase)&&
                NpFirstSyncWire.GateMatch(state.Bound.Receipt,context.CoordinateBinding);
            try{
                if(state.Bound!=null){
                    var bound=state.Bound;var receipt=bound.Receipt;var binding=Binding(receipt);NpFirstSyncUtcBounds clock=null;
                    if(clockValid&&coordinateProof&&(receipt.Flags&NpFirstSyncWire.SourceClock)!=0){
                        decimal offset=receipt.ReferenceTick*1000000m/receipt.SourceHz;
                        clock=new NpFirstSyncUtcBounds {DeviceIdentity=bound.Uid,Binding=binding,SourceHz=receipt.SourceHz,ReferenceTick=receipt.ReferenceTick,
                            LowerUs=lo+offset-uncertainty,UpperUs=hi+offset+uncertainty+1000,SourceClockQualified=true,
                            Kind=NpFirstSyncUtcBoundsKind.RecordedUtc2Milliseconds,SourcePrecisionUs=1000,
                            Evidence="Strict UTC2 exported-source-zero bracket plus nominal STARTBYTE offset; "+context.CoordinateEvidence};
                    }
                    report=NpFirstSyncUtc.Build(receipt.Raw,binding,bound.Uid,new NpFirstSyncUtcContext {DeviceIdentity=bound.Uid,Binding=binding,
                        IdentityAndBindingValidated=true,Evidence="recorded_clock.bin strict sealed SD UID/token/family/session/AP-rate binding"},NpRecordingUtc.StartsFromNpRows(items),clock);
                    report["sd_bound_first_sync"]=true;report["sd_bound_token_hex"]=bound.Token.ToString("X16",CultureInfo.InvariantCulture);
                    report["sd_recorded_clock_crc32"]=state.OriginalCrc;report["sd_ap_hz"]=apHz;
                    report["sd_profile_crc"]=receipt.ProfileCrc;report["sd_probe_mask"]=receipt.Mask;
                    report["sd_clock_sync_generation"]=state.ClockGeneration;
                    report["sd_exported_source_zero_coordinate_confirmed"]=coordinateProof;
                    report["sd_coordinate_evidence"]=coordinateProof?context.CoordinateEvidence:null;
                }
            }catch(Exception failure){error=failure.Message;}
            if(report==null){
                var unknown=items.Select(row=>{var copy=new Dictionary<string,object>(row);copy["pc_time_valid"]=false;return copy;}).ToList();
                report=NpRecordingUtc.FromNpRows(unknown,family,null,session,null,"Optional first-sync SD evidence rejected; legacy source positions only");
                report["sd_bound_first_sync"]=false;report["np_start_byte_sync_confirmed"]=false;
            }
            report["sd_first_sync_refresh_required"]=true;report["first_sync_sd_error"]=error;report["sd_legacy_clock_and_provider_area_valid"]=clockValid;
            NpRecordingUtc.Write(folder,report);Status(folder,state,clockValid,coordinateProof,error);
        }
        // Called only after the first-sample layout report has been updated.
        // Revalidate the unchanged archived sector; never replace STARTBYTE T0
        // with an AP-row estimate merely because DAT files have been merged.
        internal static bool Refresh(string folder,IEnumerable<Dictionary<string,object>> rows,int family,uint? session)
        {
            string path=Path.Combine(folder,NpRecordingUtc.FileName);if(!File.Exists(path))return false;
            var previous=Json.Deserialize<Dictionary<string,object>>(File.ReadAllText(path));if(!Flag(previous,"sd_bound_first_sync")&&!Flag(previous,"sd_first_sync_refresh_required"))return false;
            try{
                if(!Flag(previous,"sd_bound_first_sync"))throw new InvalidDataException("Original optional first-sync SD binding was not qualified.");
                if(!session.HasValue||Convert.ToUInt32(previous["session_id"])!=session.Value||Convert.ToInt32(previous["logger_version"])!=family)
                    throw new InvalidDataException("Archived first-sync SD family/session changed during layout refresh.");
                var context=new NpFirstSyncSdUtcContext {ExpectedUid=Convert.ToString(previous["device_identity"]),
                    ExpectedToken=UInt64.Parse(Convert.ToString(previous["sd_bound_token_hex"]),NumberStyles.HexNumber,CultureInfo.InvariantCulture),
                    ExportedSourceZeroConfirmed=Flag(previous,"sd_exported_source_zero_coordinate_confirmed"),CoordinateEvidence=Convert.ToString(previous["sd_coordinate_evidence"])};
                context.CoordinateBinding=new NpFirstSyncBinding {Family=(uint)family,Session=session.Value,Generation=Convert.ToUInt32(previous["capture_generation"]),
                    SourceEpoch=Convert.ToUInt32(previous["source_epoch"]),Domain=Convert.ToUInt32(previous["counter_domain"]),CounterHz=Convert.ToUInt32(previous["counter_hz"]),
                    ApHz=Convert.ToUInt32(previous["sd_ap_hz"]),ProfileCrc=Convert.ToUInt32(previous["sd_profile_crc"]),Mask=Convert.ToUInt32(previous["sd_probe_mask"])};
                uint apHz=Convert.ToUInt32(previous["sd_ap_hz"]);byte[] raw=File.ReadAllBytes(Path.Combine(folder,"recorded_clock.bin"));
                var state=Read(raw,session.Value,family,apHz,context);
                if(state==null||state.Bound==null||state.OriginalCrc!=Convert.ToString(previous["sd_recorded_clock_crc32"])||
                    state.Bound.Receipt.Generation!=Convert.ToUInt32(previous["capture_generation"])||state.Bound.Receipt.SourceEpoch!=Convert.ToUInt32(previous["source_epoch"]))
                    throw new InvalidDataException("Archived first-sync SD binding/seal is unavailable or changed.");
                var safe=NpRecordingUtc.SafeFirstSyncLayout(previous,rows);
                ulong lo,hi;uint uncertainty;bool valid=NpAcquisitionTiming.SdClockBounds(state.ClockSector,session.Value,family,apHz,out lo,out hi,out uncertainty);
                Write(folder,state,safe,session.Value,family,apHz,valid,lo,hi,uncertainty,context);
            }catch(Exception error){
                NpRecordingUtc.InvalidateFirstSync(previous,error.Message);previous["first_sync_sd_error"]=error.Message;
                previous["sd_exported_source_zero_coordinate_confirmed"]=false;previous["sd_bound_first_sync"]=false;previous["sd_first_sync_refresh_required"]=true;
                previous["sd_legacy_clock_and_provider_area_valid"]=false;previous["sd_coordinate_evidence"]=null;
                NpRecordingUtc.Write(folder,previous);Status(folder,new NpFirstSyncSdUtcState {Error=error.Message},false,false,error.Message);
            }
            return true;
        }
    }
}
