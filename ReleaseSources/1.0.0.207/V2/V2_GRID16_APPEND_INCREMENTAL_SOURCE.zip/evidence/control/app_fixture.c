#include <assert.h>
#include <stdio.h>
#include <string.h>
#ifndef NP_BLE_CATALOG_ZERO_CANCEL_TEST
#define NP_BLE_CATALOG_ZERO_CANCEL_TEST 0
#endif
#ifndef NP_BLE_CATALOG_APP_SOURCE
#define NP_BLE_CATALOG_APP_SOURCE "C:/Frank/Code/XE_NP/_artifacts/grid16_append_control/app_mock.c"
#endif
#include NP_BLE_CATALOG_APP_SOURCE
#include "xe_np_np2_sd_control.h"
#include "xe_np_np2_grid16_meta.h"
#ifndef NP_BLE_CATALOG_NO_WIRE_REWIND
#define NP_BLE_CATALOG_NO_WIRE_REWIND 0
#endif
#define PREFIX_FLAGS (XE_NP_NP2_CATALOG_DEGRADED|XE_NP_NP2_CATALOG_RECOVERY| \
    (NP_BLE_CATALOG_NO_WIRE_REWIND?0U:XE_NP_NP2_CATALOG_REWIND_AVAILABLE))

SDMMC_TypeDef native_sd;
PSSI_TypeDef native_pssi;
SPI_TypeDef native_spi[2];
DMA_Channel_TypeDef native_dma[16];
volatile XE_NP_Np2LiveSdMailbox xe_np_np2_live_sd_mailbox;
volatile uint32_t xe_np_sd_status_raw[16];
static SD_HandleTypeDef model_card;
static DCACHE_HandleTypeDef model_cache;
static uint32_t model_cid[4]={1U,2U,3U,4U};
#define CAPACITY 8388608U
#define SECTORS 1024U
static struct {uint32_t lba;uint8_t bytes[512];} media[SECTORS];
static uint32_t used,reads,writes,commands,armed,source_busy,source_ready;
static uint32_t failed_read=UINT32_MAX,failed_write,fail_after,delete_only;
static uint8_t request[64],reply[64];
#if NP_BLE_CATALOG_ZERO_CANCEL_TEST
static uint32_t zero_model_enabled,zero_cancel_calls,zero_service_calls,zero_write_guard,zero_clock_ready;
static int zero_cancel_result;
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
static XE_NP_Np2SdAppendCounts model_counts;
int XE_NP_Np2LiveSd_GetAppendCounts(XE_NP_Np2SdAppendCounts *out){*out=model_counts;return 0;}
int XE_NP_Np2LiveSd_InitExtentAppendProfile(SD_HandleTypeDef *c,DCACHE_HandleTypeDef *dc,
    uint32_t lba,uint32_t blocks,uint32_t mask,uint32_t hz,uint32_t au,uint32_t end)
{(void)c;(void)dc;(void)au;(void)end;xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_CONFIGURING;xe_np_np2_live_sd_mailbox.start_lba=lba;xe_np_np2_live_sd_mailbox.target_blocks=blocks;xe_np_np2_live_sd_mailbox.probe_mask=mask;xe_np_np2_live_sd_mailbox.sample_hz=hz;return 0;}
void XE_NP_Np2LiveSd_InitExtentClassicAuProfile(SD_HandleTypeDef *c,DCACHE_HandleTypeDef *dc,
    uint32_t lba,uint32_t blocks,uint32_t mask,uint32_t hz,uint32_t au,uint32_t end)
{(void)c;(void)dc;(void)lba;(void)blocks;(void)mask;(void)hz;(void)au;(void)end;assert(0);}
void XE_NP_Np2LiveSd_InitExtentAuProfile(SD_HandleTypeDef *c,DCACHE_HandleTypeDef *dc,
    uint32_t lba,uint32_t blocks,uint32_t mask,uint32_t hz,uint32_t au)
{(void)c;(void)dc;(void)lba;(void)blocks;(void)mask;(void)hz;(void)au;assert(0);}
#endif
static uint32_t u32(const uint8_t *p)
{return (uint32_t)p[0]|((uint32_t)p[1]<<8U)|((uint32_t)p[2]<<16U)|((uint32_t)p[3]<<24U);}
static uint8_t *sector(uint32_t lba)
{
    for(uint32_t i=0U;i<used;i++)if(media[i].lba==lba)return media[i].bytes;
    assert(used<SECTORS);media[used].lba=lba;memset(media[used].bytes,0,512U);return media[used++].bytes;
}
uint32_t HAL_GetTick(void){return 123U;}
uint32_t HAL_RCC_GetHCLKFreq(void){return 192000000U;}
uint32_t HAL_SD_GetCardState(SD_HandleTypeDef *c){assert(c==&model_card);return HAL_SD_CARD_TRANSFER;}
uint32_t HAL_SD_GetCardStatus(SD_HandleTypeDef *c,HAL_SD_CardStatusTypeDef *s)
{assert(c==&model_card);memset(s,0,sizeof(*s));s->UhsSpeedGrade=1U;s->UhsAllocationUnitSize=10U;return HAL_OK;}
uint32_t HAL_SD_ReadBlocks(SD_HandleTypeDef *c,uint8_t *out,uint32_t lba,uint32_t count,uint32_t timeout)
{
    assert(c==&model_card && count==1U && timeout==1000U && lba<CAPACITY);reads++;
    if(lba==failed_read)return 1U;
    memcpy(out,sector(lba),512U);c->Context=SD_CONTEXT_READ_SINGLE_BLOCK;return HAL_OK;
}
uint32_t HAL_SD_WriteBlocks(SD_HandleTypeDef *c,const uint8_t *in,uint32_t lba,uint32_t count,uint32_t timeout)
{
    assert(c==&model_card && count==1U && timeout==1000U && lba<CAPACITY);writes++;
#if NP_BLE_CATALOG_ZERO_CANCEL_TEST
    if(zero_write_guard)assert(lba==reservation.reservation_start_lba+4U ||
        lba==reservation.reservation_start_lba+5U || lba==112U || lba==113U || (lba>=128U && lba<1152U));
#endif
    if(delete_only)assert(lba==112U || lba==113U || (lba>=128U && lba<1152U));
    if(writes==failed_write && !fail_after)return 1U;
    memcpy(sector(lba),in,512U);c->Context=SD_CONTEXT_WRITE_SINGLE_BLOCK;
    if(writes==failed_write && fail_after){c->Context=SD_CONTEXT_NONE;return 1U;}
    return HAL_OK;
}
uint32_t SDMMC_SendCommand(SDMMC_TypeDef *sd,const SDMMC_CmdInitTypeDef *cmd)
{assert(sd==SDMMC1 && cmd->CmdIndex==20U && !delete_only);commands++;return HAL_OK;}
uint32_t SDMMC_GetCmdResp1(SDMMC_TypeDef *sd,uint32_t cmd,uint32_t timeout)
{assert(sd==SDMMC1 && cmd==20U && timeout==10U);return 0U;}
void HAL_NVIC_DisableIRQ(uint32_t irq){assert(irq==SDMMC1_IRQn);}
void HAL_NVIC_ClearPendingIRQ(uint32_t irq){assert(irq==SDMMC1_IRQn);}
int XE_NP_Board_SdUhsReadyForNpRaw(void){return 1;}
int XE_NP_Np2CapturePort_Armed(void){return (int)armed;}
int XE_NP_Np2UsbSource_IsBusy(void){return (int)source_busy;}
int XE_NP_Np2UsbSource_IsReady(void){return (int)source_ready;}
int XE_NP_Np2SdBle_ModeAvailable(uint32_t mode){return mode>=1U && mode<=3U;}
void XE_NP_Np2SdBle_ClockSnapshot(XE_NP_Np2OnlineClock *out){memset(out,0,sizeof(*out));
#if NP_BLE_CATALOG_ZERO_CANCEL_TEST
    if(zero_clock_ready)out->valid=1U;
#endif
}
uint64_t XE_NP_Np2Online_Utc(const XE_NP_Np2OnlineClock *clock,uint32_t now)
{(void)clock;(void)now;
#if NP_BLE_CATALOG_ZERO_CANCEL_TEST
    if(zero_clock_ready && clock->valid)return UINT64_C(1000000000);
#endif
    return 0U;}
const uint8_t *XE_NP_Np2Config_Selection(uint32_t port){(void)port;return NULL;}
uint32_t XE_NP_Np2Config_Crc(const uint8_t *p,uint32_t n){return XE_NP_Np2DualSd_Crc32(p,n);}
int XE_NP_Np2LiveSd_SupportsProfile(uint32_t mask,uint32_t hz)
{return XE_NP_Np2DualSd_ProfileTicks(mask,hz)!=0U;}
void XE_NP_Np2LiveSd_InitExtentProfile(SD_HandleTypeDef *c,DCACHE_HandleTypeDef *dc,
                                       uint32_t lba,uint32_t blocks,uint32_t mask,uint32_t hz)
{(void)c;(void)dc;(void)lba;(void)blocks;(void)mask;(void)hz;assert(0);}
void XE_NP_Np2LiveSd_Service(void){
#if NP_BLE_CATALOG_ZERO_CANCEL_TEST
    assert(zero_model_enabled);zero_service_calls++;
#else
    assert(0);
#endif
}
int XE_NP_Np2LiveSd_RequestStop(void){assert(0);return -1;}
int XE_NP_Np2LiveSd_CancelPrepared(void){
#if NP_BLE_CATALOG_ZERO_CANCEL_TEST
    assert(zero_model_enabled && xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_CONFIGURING);
    zero_cancel_calls++;
    if(armed || native_sd.IDMACTRL)return -1;
    if(!zero_cancel_result){xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_COMPLETE;
        xe_np_np2_live_sd_mailbox.target_blocks=0U;}
    return zero_cancel_result;
#else
    assert(0);return -1;
#endif
}
static void frame(uint32_t op,uint32_t id)
{
    memset(request,0,sizeof(request));put32(request,XE_NP_NP2_SD_CONTROL_REQUEST);
    put32(request+4U,2U);put32(request+8U,op);put32(request+12U,id);
}
static uint32_t send(void)
{
    put32(request+60U,XE_NP_Np2DualSd_Crc32(request,60U));
    assert(!XE_NP_Np2SdControl_Exchange(request,reply));
    assert(u32(reply)==XE_NP_NP2_SD_CONTROL_REPLY && u32(reply+4U)==2U &&
        u32(reply+8U)==u32(request+8U) && u32(reply+12U)==u32(request+12U) &&
        u32(reply+60U)==XE_NP_Np2DualSd_Crc32(reply,60U));
    return u32(reply+16U);
}
static void reset_model(void)
{
#if NP_BLE_CATALOG_ZERO_CANCEL_TEST
    zero_model_enabled=zero_cancel_calls=zero_service_calls=zero_write_guard=zero_clock_ready=0U;zero_cancel_result=0;
#endif
    memset(media,0,sizeof(media));used=reads=writes=commands=0U;
    failed_read=UINT32_MAX;failed_write=fail_after=delete_only=0U;
    memset(&native_sd,0,sizeof(native_sd));native_sd.CLKCR=1U;
    memset(&native_pssi,0,sizeof(native_pssi));memset(native_spi,0,sizeof(native_spi));
    memset(native_dma,0,sizeof(native_dma));armed=source_busy=source_ready=0U;
    model_card.Instance=SDMMC1;model_card.State=HAL_SD_STATE_READY;
    model_card.ErrorCode=0U;model_card.Context=0U;model_card.SdCard.LogBlockNbr=CAPACITY;
    model_card.SdCard.CardType=CARD_SDHC_SDXC;
    memcpy(model_card.CID,model_cid,sizeof(model_cid));
    started=stop_pending=finished=0U;scheduled_utc=0U;
    arm_valid=arm_before=arm_after=0U;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    delete_nonce=0U;
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    reservation_append=append_writer_bound=0U;
#endif
    memset((void *)&xe_np_np2_live_sd_mailbox,0,sizeof(xe_np_np2_live_sd_mailbox));
    memset((void *)&xe_np_np2_dual_sd_app_mailbox,0,sizeof(xe_np_np2_dual_sd_app_mailbox));
    xe_np_np2_dual_sd_app_mailbox.card_blocks=CAPACITY;
    static const uint8_t system[512]="native only";
    {int r=XE_NP_Np2DualSdCatalogPort_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system);if(r)fprintf(stderr,"FORMAT failed writes=%u used=%u started=%u grid=%u bound=%u\n",writes,used,started,reservation_grid16,grid_writer_bound);assert(!r);}
    uint32_t next;
    assert(!XE_NP_Np2DualSdCatalogPort_Mount(&next));
    xe_np_np2_dual_sd_app_mailbox.state=1U;xe_np_np2_dual_sd_app_mailbox.next_start_lba=next;
    XE_NP_Np2SdControl_Init();
}
static void append(uint32_t ordinal,uint32_t state,uint32_t full)
{
    uint8_t configuration[2048]={0};XE_NP_Np2DualSdMeta m;
    uint32_t blocks=4U;
    if(full){
        uint32_t next=xe_np_np2_dual_sd_app_mailbox.next_start_lba;
        uint32_t payload=(next+8192U+16383U)&~16383U;
        blocks=(CAPACITY-payload)/XE_NP_NP2_DUAL_SD_SECTORS_PER_RU*4U;
    }
    assert(!XE_NP_Np2DualSdCatalogPort_PlanProfile(3U,20000U,blocks,ordinal+1U,
        XE_NP_Np2DualSd_Crc32(configuration,sizeof(configuration)),&m));
    assert(!XE_NP_Np2DualSdCatalogPort_Reserve(&m,configuration));
    assert(!XE_NP_Np2DualSdCatalogPort_Finish(state,state==4U?8U:0U,blocks));
    uint32_t next;assert(!XE_NP_Np2DualSdCatalogPort_Mount(&next));
    xe_np_np2_dual_sd_app_mailbox.next_start_lba=next;
}
#if NP_BLE_CATALOG_ZERO_CANCEL_TEST
static void zero_prepare(uint32_t append_mode,uint32_t prior)
{
    reset_model();if(prior)append(0U,3U,0U);
    uint8_t configuration[2048];memset(configuration,0xA6,sizeof(configuration));
    uint32_t front=xe_np_np2_dual_sd_app_mailbox.next_start_lba;
    uint32_t payload=(front+8192U+16383U)&~16383U;
    uint32_t blocks=(CAPACITY-payload)/XE_NP_NP2_DUAL_SD_SECTORS_PER_RU*4U;
    assert(!XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(3U,20000U,blocks,1101U,
        XE_NP_Np2DualSd_Crc32(configuration,sizeof(configuration)),16384U,&reservation));
    assert(reservation.reservation_end_lba==CAPACITY); /* Continuous reserves all remaining space. */
    if(append_mode)assert(!XE_NP_Np2DualSdCatalogPort_ReserveAppend(&reservation,configuration));
    else assert(!XE_NP_Np2DualSdCatalogPort_Reserve(&reservation,configuration));
    reservation_append=(uint8_t)append_mode;append_writer_bound=(uint8_t)append_mode;
    memset(&model_counts,0,sizeof(model_counts));memset(&session_clock,0,sizeof(session_clock));
    started=stop_pending=1U;finished=0U;arm_valid=0U;
    xe_np_np2_dual_sd_app_mailbox.sample_hz=20000U;
    xe_np_np2_dual_sd_app_mailbox.state=XE_NP_NP2_DUAL_SD_PREPARING;
    xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_CONFIGURING;
    xe_np_np2_live_sd_mailbox.start_lba=reservation.run.payload_start_lba;
    xe_np_np2_live_sd_mailbox.target_blocks=blocks;
    assert(!save_time());zero_model_enabled=zero_write_guard=1U;
}
static void zero_decode(uint32_t append_mode,uint32_t *state,uint32_t *reason,uint32_t *blocks)
{
    const uint8_t *h=sector(reservation.reservation_start_lba+3U),*f=sector(reservation.reservation_start_lba+4U);
    if(append_mode){XE_NP_Np2SdAppendCounts c;
        assert(!XE_NP_Np2SdAppend_DecodeFooter(h,f,state,reason,&c));*blocks=c.physical_blocks;
        assert(!c.logical_prefix_blocks && !c.logical_high_water_blocks);
    }else assert(!XE_NP_Np2DualSd_DecodeFooter(h,f,state,reason,blocks));
}
static void zero_emit(const char *directory)
{
    if(!directory)return;
    static const char *names[]={"descriptor.bin","footer.bin","utc.bin","configuration.bin"};
    const uint32_t offsets[]={3U,4U,5U,8U},counts[]={1U,1U,1U,4U};char path[2048];FILE *file=NULL;
    for(uint32_t i=0U;i<4U;i++){
        assert(sprintf_s(path,sizeof(path),"%s/%s",directory,names[i])>0 && !fopen_s(&file,path,"wb"));
        for(uint32_t k=0U;k<counts[i];k++)assert(fwrite(sector(reservation.reservation_start_lba+offsets[i]+k),1U,512U,file)==512U);
        assert(!fclose(file));
    }
    assert(sprintf_s(path,sizeof(path),"%s/fixture.json",directory)>0 && !fopen_s(&file,path,"wb"));
    assert(fprintf(file,"{\"startLba\":%u,\"directoryEndLba\":%u,\"cardBlocks\":%u,\"sampleHz\":%u,\"probeMask\":%u,\"metadataVersion\":14,\"state\":4,\"fault\":%u,\"committedBlocks\":0}\n",
        reservation.reservation_start_lba,reservation.run.payload_start_lba,CAPACITY,reservation.run.sample_hz,
        reservation.run.probe_mask,XE_NP_NP2_DUAL_SD_META_CANCELLED_EMPTY)>0 && !fclose(file));
}
static void zero_actual_app(const char *directory)
{
    for(uint32_t mode=0U;mode<2U;mode++)for(uint32_t prior=0U;prior<2U;prior++){
        zero_prepare(mode,prior);uint8_t immutable[6][512],prior_meta[2][512],canary[512];
        uint32_t start=reservation.reservation_start_lba,payload=reservation.run.payload_start_lba;
        const uint32_t offsets[]={3U,5U,8U,9U,10U,11U};
        for(uint32_t i=0U;i<6U;i++)memcpy(immutable[i],sector(start+offsets[i]),512U);
        if(prior){memcpy(prior_meta[0],sector(8195U),512U);memcpy(prior_meta[1],sector(8196U),512U);}
        memset(sector(CAPACITY-1U),0xD3,512U);memcpy(canary,sector(CAPACITY-1U),512U);
        uint32_t cmds=commands;XE_NP_Np2DualSdApp_Service();
        assert(zero_cancel_calls==1U && !zero_service_calls && !started && !stop_pending &&
            xe_np_np2_dual_sd_app_mailbox.state==XE_NP_NP2_DUAL_SD_CANCELLED && !xe_np_np2_dual_sd_app_mailbox.error);
        uint32_t state,reason,blocks;zero_decode(mode,&state,&reason,&blocks);
        assert(state==4U && reason==XE_NP_NP2_DUAL_SD_META_CANCELLED_EMPTY && !blocks && (reason&255U)==8U);
        if(mode && !prior)zero_emit(directory);
        for(uint32_t i=0U;i<6U;i++)assert(!memcmp(immutable[i],sector(start+offsets[i]),512U));
        if(prior)assert(!memcmp(prior_meta[0],sector(8195U),512U) && !memcmp(prior_meta[1],sector(8196U),512U));
        assert(!memcmp(canary,sector(CAPACITY-1U),512U) && commands==cmds);
        uint32_t before=writes,next=0U;assert(!XE_NP_Np2DualSdCatalogPort_MountAvailable(&next) &&
            next==payload && !XE_NP_Np2DualSdCatalog_Status() && writes==before);
        assert(!XE_NP_Np2DualSdCatalogPort_MountAvailable(&next) && next==payload && writes==before);
#if XE_NP_NP2_SD_CATALOG_ENABLE
        frame(9U,901U);assert(!send() && u32(reply+24U)==prior+1U && u32(reply+28U)==payload);
        uint32_t token=u32(reply+20U);frame(10U,902U);put32(request+16U,token);put32(request+20U,prior+1U);
        put32(request+24U,prior);assert(!send() && u32(reply+36U)==payload &&
            (u32(reply+56U)&XE_NP_NP2_CATALOG_INCOMPLETE) && !(u32(reply+56U)&XE_NP_NP2_CATALOG_DELETE_ALLOWED));
#endif
        zero_clock_ready=1U; /* Existing production START still requires a fresh PC-time anchor. */
        frame(1U,1001U);put32(request+16U,3U);put32(request+20U,20000U);assert(!send());
        frame(2U,1002U);put32(request+16U,3U);put32(request+20U,20000U); /* blocks0: continuous again. */
        uint32_t start_error=send();
        if(start_error)fprintf(stderr,"Second START error=%u state=%u next=%u capacity=%u catalog=%08X mask=%u\n",
            start_error,xe_np_np2_dual_sd_app_mailbox.state,xe_np_np2_dual_sd_app_mailbox.next_start_lba,
            xe_np_np2_dual_sd_app_mailbox.card_blocks,XE_NP_Np2DualSdCatalog_Status(),XE_NP_Np2DualSdApp_ProfileMask());
        assert(!start_error && xe_np_np2_dual_sd_app_mailbox.command==XE_NP_NP2_DUAL_SD_CMD_START);
        xe_np_np2_dual_sd_app_mailbox.command=0U; /* Admission only: never execute modeled capture. */
    }
    puts("PASS actual pre-arm APP CancelPrepared/Port finalization: v13/v14 zero FAILED reason, retained metadata/canaries, repeated remount and second START admission; no capture");
}
static void zero_app_guards(void)
{
    for(uint32_t which=0U;which<16U;which++){
        zero_prepare(1U,0U);
        switch(which){case 0:arm_valid=1U;break;case 1:xe_np_np2_live_sd_mailbox.produced_blocks=1U;break;
        case 2:xe_np_np2_live_sd_mailbox.written_rus=1U;break;case 3:xe_np_np2_live_sd_mailbox.verified_blocks=1U;break;
        case 4:xe_np_np2_live_sd_mailbox.source_produced_lo=1U;break;case 5:xe_np_np2_live_sd_mailbox.source_produced_hi=1U;break;
        case 6:xe_np_np2_live_sd_mailbox.source_consumed_lo=1U;break;case 7:xe_np_np2_live_sd_mailbox.source_consumed_hi=1U;break;
        case 8:model_counts.physical_blocks=model_counts.logical_prefix_blocks=model_counts.logical_high_water_blocks=4U;break;
        case 9:model_counts.physical_blocks=8U;model_counts.logical_prefix_blocks=4U;model_counts.logical_high_water_blocks=12U;break;
        case 10:zero_cancel_result=1;break;case 11:zero_cancel_result=-1;break;case 12:armed=1U;break;
        case 13:native_sd.IDMACTRL=1U;break;case 14:xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_DRAINING;break;
        default:xe_np_np2_live_sd_mailbox.start_lba++;break;}
        XE_NP_Np2DualSdApp_Service();assert(u32(sector(reservation.reservation_start_lba+4U)+104U)!=XE_NP_NP2_DUAL_SD_META_CANCELLED_EMPTY);
        /* Release only the fake fixture's still-open owner conservatively so
         * the next case can start; this cleanup is not part of the assertion. */
        armed=native_sd.IDMACTRL=0U;uint32_t next=0U;
        if(XE_NP_Np2DualSdCatalogPort_MountAvailable(&next)){
            const XE_NP_Np2SdAppendCounts zero={0};
            assert(!XE_NP_Np2DualSdCatalogPort_FinishAppend(4U,8U,&zero));
            assert(!XE_NP_Np2DualSdCatalogPort_MountAvailable(&next));
        }
        assert(next>=reservation.reservation_end_lba || (XE_NP_Np2DualSdCatalog_Status()&XE_NP_NP2_CATALOG_RECOVERY));
    }
    puts("PASS no empty-reclaim marker for armed/produced/written/verified/source ticks/sparse append/nonidle/pending/failed cancellation or wrong writer extent");
}
static void zero_unproven_footers(void)
{
    for(uint32_t which=0U;which<7U;which++){
        zero_prepare(0U,0U);XE_NP_Np2DualSdApp_Service();uint32_t start=reservation.reservation_start_lba;
        uint8_t *h=sector(start+3U),*f=sector(start+4U);
        if(which==0U)put32(f+104U,8U);
        if(which==1U)assert(!XE_NP_Np2DualSd_EncodeFooter(f,&reservation,1U,1U,0U));
        if(which==2U)f[508U]^=1U;
        if(which==3U){put32(h+80U,u32(h+80U)^1U);put32(f+80U,u32(f+80U)^1U);put32(h+508U,XE_NP_Np2DualSd_Crc32(h,508U));}
        if(which==4U)put32(f+12U,u32(f+12U)^1U);
        if(which==5U){assert(!XE_NP_Np2DualSd_EncodeFooter(f,&reservation,4U,8U,4U));put32(f+104U,XE_NP_NP2_DUAL_SD_META_CANCELLED_EMPTY);}
        if(which==6U)put32(f+104U,XE_NP_NP2_DUAL_SD_META_VERIFY_PENDING);
        if(which!=2U)put32(f+508U,XE_NP_Np2DualSd_Crc32(f,508U));
        uint32_t next=0U,before=writes;assert(!XE_NP_Np2DualSdCatalogPort_MountAvailable(&next) && writes==before);
        assert(next>=reservation.reservation_end_lba || (XE_NP_Np2DualSdCatalog_Status()&XE_NP_NP2_CATALOG_RECOVERY));
    }
    puts("PASS ordinary8/RESERVED/tornCRC/wrong CID/session/nonzero-tag/VERI cannot create a writable header-only frontier");
}
/* Only crash interpretation below uses a portable rebind over the same HAL
 * card fake; this is not a second hardware-reset or physical-port test. */
static int zero_reopen_read(void *u,uint32_t lba,uint8_t out[512])
{(void)u;uint32_t result=HAL_SD_ReadBlocks(&model_card,out,lba,1U,1000U);model_card.Context=0U;return result?-1:0;}
static int zero_reopen_write(void *u,uint32_t lba,const uint8_t in[512])
{(void)u;uint32_t result=HAL_SD_WriteBlocks(&model_card,in,lba,1U,1000U);model_card.Context=0U;return result?-1:0;}
static int zero_reopen_command(void *u,uint32_t argument)
{(void)u;assert((argument&0xF8FFFFFFU)==0x88000000U);commands++;return 0;}
static void zero_publication_cuts(void)
{
    for(uint32_t mode=0U;mode<2U;mode++)for(uint32_t cut=1U;cut<=5U;cut++)for(uint32_t after=0U;after<2U;after++){
        zero_prepare(mode,1U);uint8_t descriptor[512],config0[512],utc[512],previous[512];
        uint32_t start=reservation.reservation_start_lba;memcpy(descriptor,sector(start+3U),512U);
        memcpy(config0,sector(start+8U),512U);memcpy(utc,sector(start+5U),512U);memcpy(previous,sector(8196U),512U);
        uint32_t before=writes,cmds=commands;failed_write=before+cut;fail_after=after;
        const XE_NP_Np2SdAppendCounts zero={0};int result=mode?
            XE_NP_Np2DualSdCatalogPort_FinishAppend(4U,XE_NP_NP2_DUAL_SD_META_CANCELLED_EMPTY,&zero):
            XE_NP_Np2DualSdCatalogPort_Finish(4U,XE_NP_NP2_DUAL_SD_META_CANCELLED_EMPTY,0U);
        assert(result && writes<=before+5U && commands==cmds);failed_write=fail_after=0U;model_card.Context=0U;
        XE_NP_Np2DualSdCatalogIo io={0};io.card_blocks=CAPACITY;memcpy(io.cid,model_cid,16U);
        io.read_sector=zero_reopen_read;io.write_sector=zero_reopen_write;io.stopped_command=zero_reopen_command;
        assert(!XE_NP_Np2DualSdCatalog_Bind(&io));uint32_t next=0U;before=writes;
        assert(!XE_NP_Np2DualSdCatalog_MountAvailable(&next) && writes==before);
        if(cut==1U && !after)assert(next>=reservation.reservation_end_lba);
        else assert(next==reservation.run.payload_start_lba);
        assert(!XE_NP_Np2DualSdCatalog_MountAvailable(&next) && writes==before && commands==cmds);
        assert(!memcmp(descriptor,sector(start+3U),512U) && !memcmp(config0,sector(start+8U),512U) &&
            !memcmp(utc,sector(start+5U),512U) && !memcmp(previous,sector(8196U),512U));
    }
    puts("PASS20 v13/v14 cuts before/after zero FAILED footer and four journal writes; read-only restart conservative until durable proof, no payload/descriptor/config/UTC/prior-footer writes or CMD20");
}
#endif
#if XE_NP_NP2_SD_CATALOG_ENABLE
static uint32_t test_words_crc(const uint32_t words[15])
{
    uint8_t bytes[60];for(unsigned i=0U;i<15U;i++)put32(bytes+4U*i,words[i]);
    return XE_NP_Np2DualSd_Crc32(bytes,sizeof(bytes));
}
static uint32_t cid_crc(void)
{
    uint8_t bytes[16];for(unsigned i=0U;i<4U;i++)put32(bytes+4U*i,model_cid[i]);
    return XE_NP_Np2DualSd_Crc32(bytes,sizeof(bytes));
}
/* Solve the 32-bit linear CRC patch, not a production CRC override. */
static void zero_patch(uint8_t span[4],uint32_t (*calculate)(void))
{
    uint32_t basis[32]={0},masks[32]={0},base=calculate();
    for(unsigned bit=0U;bit<32U;bit++){
        span[bit/8U]^=(uint8_t)(1U<<(bit%8U));uint32_t value=calculate()^base,mask=1U<<bit;
        span[bit/8U]^=(uint8_t)(1U<<(bit%8U));
        for(int top=31;top>=0;top--)if(value&(1U<<(unsigned)top)){
            if(basis[top]){value^=basis[top];mask^=masks[top];}
            else{basis[top]=value;masks[top]=mask;break;}
        }
    }
    uint32_t patch=0U;
    for(int top=31;top>=0;top--)if(base&(1U<<(unsigned)top)){
        assert(basis[top]);base^=basis[top];patch^=masks[top];
    }
    for(unsigned bit=0U;bit<32U;bit++)if(patch&(1U<<bit))span[bit/8U]^=(uint8_t)(1U<<(bit%8U));
    assert(calculate()==0U);
}
static uint32_t empty_token_crc(void)
{
    uint32_t words[15]={0x5343324EU,CAPACITY,model_cid[0],model_cid[1],model_cid[2],model_cid[3],
        0U,8192U,128U,XE_NP_Np2DualSd_Crc32(sector(128U),512U),UINT32_MAX,0U,0U,0U,0U};
    return test_words_crc(words);
}
static uint32_t cookie_crc(void)
{
    uint32_t end=u32(sector(128U)+4U);
    uint32_t words[15]={0x4543324EU,CAPACITY,model_cid[0],model_cid[1],model_cid[2],model_cid[3],
        0U,8192U,end,end,XE_NP_Np2DualSd_Crc32(sector(8195U),508U),
        XE_NP_Np2DualSd_Crc32(sector(8196U),508U),u32(sector(8195U)+8U),u32(sector(8196U)+8U),0U};
    return test_words_crc(words);
}
static XE_NP_Np2DualSdCatalogInfo info(void)
{
    frame(9U,1U);uint32_t error=send();
    if(error)fprintf(stderr,"INFO error%u state%u command%u started%u stop%u schedule%llu writer%u ready%d reads%u writes%u\n",
        error,xe_np_np2_dual_sd_app_mailbox.state,xe_np_np2_dual_sd_app_mailbox.command,started,stop_pending,
        (unsigned long long)scheduled_utc,xe_np_np2_live_sd_mailbox.state,XE_NP_Np2DualSdCatalogPort_Ready(),reads,writes);
    if(error)fprintf(stderr,"raw directory count%u end%u event%u\n",u32(sector(128U)),u32(sector(128U)+4U),u32(sector(128U)+256U));
    assert(!error);
    XE_NP_Np2DualSdCatalogInfo i={u32(reply+20U),u32(reply+24U),u32(reply+28U),u32(reply+32U),
        u32(reply+36U),u32(reply+40U),u32(reply+44U),u32(reply+48U),u32(reply+52U),u32(reply+56U)};
    return i;
}
static void entry(XE_NP_Np2DualSdCatalogInfo i,uint32_t ordinal)
{
    frame(10U,2U);put32(request+16U,i.token);put32(request+20U,i.count);put32(request+24U,ordinal);
    assert(!send());assert(u32(reply+20U)==i.token && u32(reply+24U)==i.count && u32(reply+28U)==ordinal);
}
static void deletion(XE_NP_Np2DualSdCatalogInfo i,uint32_t id)
{
    frame(11U,id);put32(request+16U,i.token);put32(request+20U,i.count);put32(request+24U,i.last_ordinal);
    put32(request+28U,i.last_start);put32(request+32U,i.last_end);put32(request+36U,i.last_cookie);
    put32(request+40U,XE_NP_NP2_CATALOG_DELETE_KEY);
}
static void list_delete(void)
{
    static const uint32_t counts[]={0U,1U,3U,63U,64U};
    for(unsigned n=0U;n<sizeof(counts)/sizeof(counts[0]);n++){
        reset_model();uint32_t count=counts[n];
        for(uint32_t k=0U;k<count;k++)append(k,3U,0U);
        frame(1U,100U);put32(request+16U,3U);put32(request+20U,20000U);assert(!send());
        XE_NP_Np2DualSdCatalogInfo i=info();assert(i.count==count);
        if(!count){assert(i.last_ordinal==UINT32_MAX && !i.last_start && !i.last_end && !i.last_cookie && i.next==8192U);continue;}
        uint32_t previous=8192U,prefix_crc=0U;
        for(uint32_t k=0U;k<count;k++){
            entry(i,k);assert(u32(reply+32U)==previous);
            previous=(u32(reply+36U)+8191U)&~8191U;
            assert(((u32(reply+56U)&XE_NP_NP2_CATALOG_LAST)!=0U)==(k==count-1U));
            if(k==count-1U)assert(u32(reply+56U)&XE_NP_NP2_CATALOG_DELETE_ALLOWED);
            else prefix_crc^=u32(reply+40U);
        }
        assert(previous==i.next);
        xe_np_np2_dual_sd_app_mailbox.command_error=10U;
        deletion(i,101U);uint32_t before=writes,cmds=commands;delete_only=1U;
        assert(!send() && writes==before && (u32(reply+52U)&8U) && u32(reply+56U)==101U && !u32(reply+24U));
        assert(xe_np_np2_dual_sd_app_mailbox.command==XE_NP_NP2_DUAL_SD_CMD_DELETE_LAST && sizeof(XE_NP_Np2DualSdAppMailbox)==104U);
        assert(!send() && writes==before); /* Exact ACK replay never requeues. */
        uint8_t exact[64];memcpy(exact,request,sizeof(exact));
        XE_NP_Np2DualSdApp_Service();
        assert(!xe_np_np2_dual_sd_app_mailbox.command && !xe_np_np2_dual_sd_app_mailbox.command_error && commands==cmds);
        assert(writes==before+4U);before=writes;
        assert(!send() && !xe_np_np2_dual_sd_app_mailbox.command && writes==before);
        put32(request+36U,i.last_cookie^1U);assert(send()==6U && writes==before);
        memcpy(request,exact,sizeof(exact));assert(!send() && writes==before);
        XE_NP_Np2DualSdCatalogInfo after=info();assert(after.count==count-1U && after.card_blocks==i.card_blocks && after.cid_crc==i.cid_crc);
        uint32_t after_crc=0U;
        for(uint32_t k=0U;k<after.count;k++){entry(after,k);after_crc^=u32(reply+40U);}
        assert(after_crc==prefix_crc);
        frame(0U,1U);assert(!send() && u32(reply+56U)==101U && !(u32(reply+52U)&8U));
    }
    puts("PASS actual B9/app/port/catalog: empty, sole, COMPLETE, 63/64 boundaries, queued ACK, immutable prefix, replay/conflict and 104-byte ABI");
}
static void owner(uint32_t which)
{
    if(which<48U){native_dma[which/3U].CCR=1U<<(which%3U);return;}
    switch(which){
    case 48U:native_pssi.CR=1U;break;case 49U:native_spi[0].CR1=1U;break;case 50U:native_spi[1].CR1=1U;break;
    case 51U:armed=1U;break;case 52U:source_busy=1U;break;case 53U:source_ready=1U;break;
    case 54U:native_sd.IDMACTRL=1U;break;case 55U:native_sd.DCTRL=1U;break;
    case 56U:native_sd.STA=SDMMC_STA_BUSYD0;break;case 57U:native_sd.STA=SDMMC_STA_DPSMACT;break;
    case 58U:native_sd.STA=SDMMC_STA_CPSMACT;break;case 59U:model_card.Context=9U;break;
    case 60U:model_card.State=0U;break;case 61U:model_card.ErrorCode=1U;break;
    case 62U:model_card.CID[0]^=1U;break;case 63U:model_card.SdCard.LogBlockNbr--;break;
    case 64U:started=1U;break;case 65U:stop_pending=1U;break;case 66U:scheduled_utc=1U;break;
    case 67U:xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_CONFIGURING;break;
    case 68U:xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_CAPTURING;break;
    case 69U:xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_DRAINING;break;
    case 70U:xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_VERIFYING;break;
    default:assert(0);
    }
}
static void owners(void)
{
    for(uint32_t which=0U;which<71U;which++){
        reset_model();append(0U,3U,0U);XE_NP_Np2DualSdCatalogInfo i=info();owner(which);
        uint32_t before=reads,write_before=writes;
        frame(9U,3U);assert(send()==2U && reads==before && writes==write_before && u32(reply+20U)==1U);
        frame(10U,4U);put32(request+16U,i.token);put32(request+20U,i.count);assert(send()==2U && reads==before);
        deletion(i,5U);assert(send()==2U && !xe_np_np2_dual_sd_app_mailbox.command && reads==before);
        reset_model();append(0U,3U,0U);i=info();deletion(i,6U);assert(!send());
        owner(which);before=reads;write_before=writes;
        command(); /* Actual foreground executor; do not advance unrelated modeled recording services. */
        assert(!xe_np_np2_dual_sd_app_mailbox.command && xe_np_np2_dual_sd_app_mailbox.command_error && reads==before && writes==write_before);
        uint32_t fault=xe_np_np2_dual_sd_app_mailbox.command_error;assert(!send() && u32(reply+24U)==fault && reads==before);
    }
    reset_model();append(0U,3U,0U);
    static const uint32_t states[]={0U,2U,3U,4U,6U,255U};
    for(unsigned k=0U;k<sizeof(states)/sizeof(states[0]);k++){
        xe_np_np2_dual_sd_app_mailbox.state=states[k];uint32_t before=reads;
        frame(9U,10U);assert(send() && reads==before);
    }
    for(unsigned k=0U;k<sizeof(states)/sizeof(states[0]);k++){
        reset_model();append(0U,3U,0U);XE_NP_Np2DualSdCatalogInfo i=info();
        deletion(i,10U);assert(!send());xe_np_np2_dual_sd_app_mailbox.state=states[k];uint32_t before=reads;
        XE_NP_Np2DualSdApp_Service();
        assert(!xe_np_np2_dual_sd_app_mailbox.command && xe_np_np2_dual_sd_app_mailbox.command_error==9U && reads==before);
    }
    reset_model();append(0U,3U,0U);
    frame(5U,11U);put32(request+16U,2U);assert(!send());uint32_t before=reads;
    frame(9U,12U);assert(send()==2U && reads==before);XE_NP_Np2SdControl_CancelMode();
    xe_np_np2_dual_sd_app_mailbox.command=XE_NP_NP2_DUAL_SD_CMD_MOUNT;
    frame(9U,13U);assert(send()==2U && reads==before);
    puts("PASS 71 physical/software owner fences before any SD I/O at admission and execution, active/unmounted states and pending mode/command");
}
static void errors_and_cache(void)
{
    reset_model();append(0U,3U,0U);XE_NP_Np2DualSdCatalogInfo i=info();
    uint8_t valid[64];memcpy(valid,request,sizeof(valid));
    for(unsigned at=0U;at<5U;at++){
        static const unsigned offsets[]={0U,4U,12U,60U,63U};
        memcpy(request,valid,sizeof(valid));request[offsets[at]]^=1U;
        uint32_t before=reads;assert(XE_NP_Np2SdControl_Exchange(request,reply)<0 && reads==before);
    }
    for(uint32_t op=9U;op<=11U;op++){
        frame(op,20U+op);request[op==9U?16U:op==10U?28U:44U]=1U;
        uint32_t before=reads;assert(send()==1U && reads==before && u32(reply+20U)==1U && u32(reply+48U)==CAPACITY);
    }
    frame(10U,40U);put32(request+16U,i.token^1U);put32(request+20U,i.count);assert(send()==9U);
    frame(10U,41U);put32(request+16U,i.token);put32(request+20U,i.count);put32(request+24U,i.count);assert(send()==3U);
    deletion(i,42U);put32(request+40U,0U);uint32_t before=reads;assert(send()==3U && reads==before);
    deletion(i,43U);put32(request+36U,i.last_cookie^1U);assert(send()==9U && !xe_np_np2_dual_sd_app_mailbox.command);
    failed_read=i.last_start+3U;frame(9U,44U);assert(send()==10U && u32(reply+20U)==1U);failed_read=UINT32_MAX;
    uint32_t remounted;assert(!XE_NP_Np2DualSdCatalogPort_Mount(&remounted));
    i=info();sector(i.last_start+3U)[400]^=1U;
    frame(10U,45U);put32(request+16U,i.token);put32(request+20U,i.count);assert(send()==9U);
    reset_model();append(0U,3U,0U);i=info();deletion(i,50U);assert(!send());
    sector(i.last_start+4U)[400]^=1U;before=writes;command();
    assert(xe_np_np2_dual_sd_app_mailbox.command_error && writes==before);
    reset_model();append(0U,3U,0U);i=info();append(1U,3U,0U);
    frame(10U,51U);put32(request+16U,i.token);put32(request+20U,i.count);assert(send()==9U);
    i=info();deletion(i,52U);assert(!send());append(2U,3U,0U);before=writes;command();
    assert(xe_np_np2_dual_sd_app_mailbox.command_error==9U && writes==before);
    reset_model();append(0U,3U,1U);i=info();assert(i.flags==XE_NP_NP2_CATALOG_FULL);
    deletion(i,53U);assert(!send());command();assert(!xe_np_np2_dual_sd_app_mailbox.command_error && info().count==0U);
    reset_model();append(0U,3U,0U);i=info();sector(i.last_start+4U)[400]^=1U;
    i=info();assert(i.flags==XE_NP_NP2_CATALOG_DEGRADED);entry(i,0U);assert(!(u32(reply+56U)&XE_NP_NP2_CATALOG_DELETE_ALLOWED));
    deletion(i,54U);before=writes;assert(send()==8U && writes==before);
    /* A damaged directory fence with intact metadata stages the known
     * allocation, not healthy empty/free space or an unnecessary rewind. */
    reset_model();append(0U,3U,0U);i=info();put32(sector(128U)+4U,8193U);
    before=writes;frame(9U,55U);
    assert(!send() && u32(reply+24U)==i.count && u32(reply+28U)==i.next &&
        u32(reply+52U)==i.last_end && u32(reply+40U)==XE_NP_NP2_CATALOG_DEGRADED && writes==before);
    puts("PASS reserved/envelope validation, STATUS errors, stale token/cookie/count, I/O, mutation invalidation, execution revalidation, FULL deletion and recovery refusal");
}
static void power_cuts(void)
{
    for(uint32_t count=1U;count<=64U;count+=63U)for(uint32_t stage=1U;stage<=4U;stage++)for(uint32_t after=0U;after<=1U;after++){
        reset_model();for(uint32_t n=0U;n<count;n++)append(n,3U,0U);
        XE_NP_Np2DualSdCatalogInfo i=info();deletion(i,60U);assert(!send());
        uint32_t cmds=commands,before=writes;delete_only=1U;failed_write=before+stage;fail_after=after;command();
        assert(xe_np_np2_dual_sd_app_mailbox.command_error==10U && !xe_np_np2_dual_sd_app_mailbox.command && commands==cmds);
        failed_write=0U;model_card.Context=SD_CONTEXT_NONE;
        before=writes;assert(!send() && writes==before); /* Failed ACK never retries. */
        uint32_t next;assert(!XE_NP_Np2DualSdCatalogPort_Mount(&next));
        uint32_t flags=XE_NP_Np2DualSdCatalog_Status();
        if(flags&XE_NP_NP2_CATALOG_RECOVERY){
            assert(flags&XE_NP_NP2_CATALOG_RECOVERABLE);
            uint32_t unchanged=writes;
            assert(!XE_NP_Np2DualSdCatalogPort_MountAvailable(&next) && writes==unchanged);
            assert(XE_NP_Np2DualSdCatalog_Status()&XE_NP_NP2_CATALOG_RECOVERY);
            XE_NP_Np2DualSdCatalogInfo pending=info();
            assert(pending.count==(stage==1U || (stage==2U && !after)?count:count-1U) &&
                (pending.flags&XE_NP_NP2_CATALOG_RECOVERY) && writes==unchanged && commands==cmds);
            if(pending.count){entry(pending,pending.count-1U);
                assert(!(u32(reply+56U)&XE_NP_NP2_CATALOG_DELETE_ALLOWED));}
            assert(writes==unchanged); /* INFO/ENTRY must not replay the empty-page journal. */
            assert(!XE_NP_Np2DualSdCatalogPort_Recover(&next));
        }
        xe_np_np2_dual_sd_app_mailbox.next_start_lba=next;
        XE_NP_Np2DualSdCatalogInfo result=info();
        assert(result.count==(stage==1U || (stage==2U && !after)?count:count-1U));
        assert(!(result.flags&XE_NP_NP2_CATALOG_RECOVERY) && commands==cmds);
        for(uint32_t n=0U;n<result.count;n++){entry(result,n);assert(u32(reply+44U)==n+1U);}
    }
    puts("PASS 16 delete publication cuts around sole-entry and 63-entry page transition; read-only mount/explicit journal recovery; no payload write/CMD20/erase");
}
static void zero_values(void)
{
    reset_model();zero_patch(sector(128U)+4U,empty_token_crc);
    XE_NP_Np2DualSdCatalogInfo i=info();assert(i.token==0U && i.cid_crc==0U && i.count==0U);
    frame(10U,80U);put32(request+16U,0U);assert(send()==3U); /* Valid token, ordinal out of range. */
    reset_model();append(0U,3U,0U);zero_patch(sector(8195U)+400U,cookie_crc);
    i=info();assert(i.last_cookie==0U && i.cid_crc==0U);entry(i,0U);assert(u32(reply+40U)==0U);
    puts("PASS actual zero-valued token, cookie and CID CRC via linear CRC patches; frozen 15-word LE formulas");
}
static void sealed_metadata_fingerprint(void)
{
    reset_model();append(0U,3U,0U);XE_NP_Np2DualSdCatalogInfo before=info();
    deletion(before,90U);assert(!send()); /* Snapshot queued before a valid metadata edit. */
    uint8_t *descriptor=sector(8195U),*footer=sector(8196U);
    uint32_t residue=XE_NP_Np2DualSd_Crc32(descriptor,512U);
    assert(residue==0x2144DF1CU && XE_NP_Np2DualSd_Crc32(footer,512U)==residue);
    put32(descriptor+12U,2U);put32(descriptor+508U,XE_NP_Np2DualSd_Crc32(descriptor,508U));
    put32(footer+12U,2U);put32(footer+508U,XE_NP_Np2DualSd_Crc32(footer,508U));
    uint32_t writes_before=writes;command();
    assert(!xe_np_np2_dual_sd_app_mailbox.command && xe_np_np2_dual_sd_app_mailbox.command_error==9U && writes==writes_before);
    assert(!send() && writes==writes_before && u32(reply+24U)==9U); /* Receipt replay never requeues. */
    XE_NP_Np2DualSdCatalogInfo after=info();entry(after,0U);
    assert(u32(reply+44U)==2U && (u32(reply+56U)&XE_NP_NP2_CATALOG_METADATA_VALID));
    assert(after.token!=before.token && after.last_cookie!=before.last_cookie &&
        after.count==before.count && after.last_start==before.last_start && after.last_end==before.last_end &&
        XE_NP_Np2DualSd_Crc32(descriptor,512U)==residue && XE_NP_Np2DualSd_Crc32(footer,512U)==residue);
    assert(after.last_cookie==cookie_crc()); /* Independent explicit first508-byte formula. */
    deletion(before,91U);assert(send()==9U && !xe_np_np2_dual_sd_app_mailbox.command && writes==writes_before);
    frame(10U,92U);put32(request+16U,before.token);put32(request+20U,before.count);assert(send()==9U);
    puts("PASS corrected first508-byte fingerprint: CRC-valid re-sealed same-extent metadata changes cookie/token; stale ENTRY/DELETE and already-queued DELETE refuse without writes/replay; full512 residue remains2144DF1C");
}

static void incomplete_read_only(void)
{
    for(uint32_t version=11U;version<=14U;version++)for(uint32_t state=1U;state<=4U;state+=3U){
        reset_model();uint8_t configuration[2048]={0},reserved_footer[512];
        XE_NP_Np2DualSdMeta m;
        uint32_t crc=XE_NP_Np2DualSd_Crc32(configuration,sizeof(configuration));
        if(version==11U)assert(!XE_NP_Np2DualSdCatalogPort_PlanProfile(3U,20000U,16U,700U,crc,&m));
        else if(version==12U)assert(!XE_NP_Np2DualSdCatalog_PlanAuProfile(3U,20000U,16U,700U,crc,16384U,&m));
        else assert(!XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(3U,20000U,16U,700U,crc,16384U,&m));
        if(version==14U){
            assert(!XE_NP_Np2DualSdCatalogPort_ReserveAppend(&m,configuration));
            memcpy(reserved_footer,sector(m.reservation_start_lba+4U),512U);
            const XE_NP_Np2SdAppendCounts gap={8U,4U,12U};
            assert(!XE_NP_Np2DualSdCatalogPort_FinishAppend(4U,9U,&gap));
        }else{
            assert(!XE_NP_Np2DualSdCatalogPort_Reserve(&m,configuration));
            memcpy(reserved_footer,sector(m.reservation_start_lba+4U),512U);
            assert(!XE_NP_Np2DualSdCatalogPort_Finish(4U,9U,8U));
        }
        /* Model an intact RESERVED footer from a prior interrupted boot, not
         * an active reservation/loan. Directory retains its whole allocation. */
        if(state==1U)memcpy(sector(m.reservation_start_lba+4U),reserved_footer,512U);
        uint32_t next;assert(!XE_NP_Np2DualSdCatalogPort_MountAvailable(&next));
        xe_np_np2_dual_sd_app_mailbox.next_start_lba=next;
        XE_NP_Np2DualSdCatalogInfo i=info();assert(i.count==1U);
        entry(i,0U);uint32_t flags=u32(reply+56U);
        assert((flags&255U)==version && ((flags>>8U)&255U)==state &&
            (flags&XE_NP_NP2_CATALOG_METADATA_VALID) && (flags&XE_NP_NP2_CATALOG_INCOMPLETE) &&
            !(flags&XE_NP_NP2_CATALOG_DELETE_ALLOWED) && i.last_end==m.reservation_end_lba);
        deletion(i,200U);uint32_t before=writes,cmds=commands;
        memcpy(reserved_footer,sector(m.reservation_start_lba+4U),512U);
        assert(send()==8U && writes==before && commands==cmds && !xe_np_np2_dual_sd_app_mailbox.command);
        assert(!memcmp(sector(m.reservation_start_lba+4U),reserved_footer,512U));
    }
    puts("PASS actual v11/v12/v13/v14 RESERVED/FAILED directory entries visible but read-only; full unused allocation retained");
}
static void terminal_catalog_refresh(void)
{
    for(uint32_t append_mode=0U;append_mode<=1U;append_mode++)for(uint32_t cancelled=0U;cancelled<=1U;cancelled++){
        reset_model();uint8_t configuration[2048]={0};uint32_t crc=XE_NP_Np2DualSd_Crc32(configuration,2048U);
        assert(!XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(3U,30000U,16U,801U,crc,16384U,&reservation));
        if(append_mode)assert(!XE_NP_Np2DualSdCatalogPort_ReserveAppend(&reservation,configuration));
        else assert(!XE_NP_Np2DualSdCatalogPort_Reserve(&reservation,configuration));
        reservation_append=(uint8_t)append_mode;append_writer_bound=(uint8_t)append_mode;
        model_counts.physical_blocks=model_counts.logical_prefix_blocks=model_counts.logical_high_water_blocks=8U;
        started=1U;finished=0U;stop_pending=1U;
        xe_np_np2_dual_sd_app_mailbox.sample_hz=30000U;
        xe_np_np2_live_sd_mailbox.written_rus=2U;xe_np_np2_live_sd_mailbox.verified_blocks=8U;
        xe_np_np2_live_sd_mailbox.target_blocks=8U;xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_COMPLETE;
        terminal(cancelled?4U:3U,cancelled?8U:0U);
        assert(!started && !stop_pending && !xe_np_np2_dual_sd_app_mailbox.error &&
            xe_np_np2_dual_sd_app_mailbox.state==(cancelled?7U:5U));
        XE_NP_Np2DualSdCatalogInfo i=info();entry(i,0U);
        assert(i.count==1U && i.last_start==reservation.reservation_start_lba &&
            (u32(reply+56U)&255U)==(append_mode?14U:13U) &&
            i.next==((i.last_end+8191U)&~8191U));
        uint32_t expected_end=cancelled?reservation.reservation_end_lba:reservation.run.payload_start_lba+8U*91U;
        assert(i.last_end==expected_end && ((u32(reply+56U)&XE_NP_NP2_CATALOG_DELETE_ALLOWED)!=0U)==!cancelled);
    }
    puts("PASS actual legacy/v14 terminal Complete/Stop finalization then fresh physical INFO/ENTRY count/frontier");
}
static void unsafe_empty_and_rewind_surface(void)
{
    reset_model();append(0U,3U,0U);XE_NP_Np2DualSdCatalogInfo i=info();
    sector(16U)[0]^=1U;uint32_t before=writes;frame(9U,300U);
    assert(send()==10U && writes==before && !xe_np_np2_dual_sd_app_mailbox.command);
    reset_model();append(0U,3U,0U);i=info();
    /* A cache that previously held records cannot turn an unprovable physical
     * directory into a healthy empty response on Refresh. */
    put32(sector(128U),64U);before=writes;frame(9U,301U);
    assert(!send() && !u32(reply+24U) && u32(reply+28U)==8192U && writes==before &&
        u32(reply+40U)==PREFIX_FLAGS);
    reset_model();append(0U,3U,0U);i=info();
    frame(12U,302U);put32(request+16U,XE_NP_NP2_CATALOG_REWIND_KEY);
    put32(request+20U,i.next);put32(request+24U,CAPACITY);
    uint32_t rewind_error=send();
    assert((rewind_error==2U || rewind_error==4U) && !xe_np_np2_dual_sd_app_mailbox.command);
    /* APP660 has no op12; the separate current-source candidate refuses it. */
    frame(9U,1U);assert(!send()); /* Catalog reads do not consume mutation IDs. */
    frame(1U,303U);put32(request+16U,3U);put32(request+20U,20000U);assert(!send());
    frame(1U,302U);put32(request+16U,3U);put32(request+20U,20000U);assert(send()==6U);
    puts("PASS unknown bounds never healthy empty; op12 unsupported/refused and independent read/mutation ID surface");
}
static void read_only_snapshot(uint32_t count,uint32_t next,uint32_t flags)
{
    uint32_t before=writes,cmds=commands,prior_sectors=used;
    uint32_t media_crc=XE_NP_Np2DualSd_Crc32((const uint8_t *)media,prior_sectors*(uint32_t)sizeof(media[0]));
    XE_NP_Np2DualSdCatalogInfo i=info(),again=info();
    assert(!memcmp(&i,&again,sizeof(i)) && i.count==count && i.next==next && i.flags==flags);
#if NP_BLE_CATALOG_NO_WIRE_REWIND
    frame(0U,503U);assert(!send() && !(u32(reply+52U)&XE_NP_NP2_CATALOG_REWIND_AVAILABLE));
#endif
    uint32_t previous=8192U;
    for(uint32_t ordinal=0U;ordinal<count;ordinal++){
        entry(i,ordinal);uint32_t entry_flags=u32(reply+56U);
        assert(u32(reply+32U)==previous && (entry_flags&XE_NP_NP2_CATALOG_METADATA_VALID) &&
            !(entry_flags&XE_NP_NP2_CATALOG_DELETE_ALLOWED));
        assert(((entry_flags&XE_NP_NP2_CATALOG_LAST)!=0U)==(ordinal==count-1U));
        previous=(u32(reply+36U)+8191U)&~8191U;
    }
    assert(previous==next);
    if(!count){
        assert(i.last_ordinal==UINT32_MAX && !i.last_start && !i.last_end && !i.last_cookie);
        frame(10U,501U);put32(request+16U,i.token);assert(send()==3U);
    }
    deletion(i,502U);assert(send()==8U && !xe_np_np2_dual_sd_app_mailbox.command);
    assert(writes==before && commands==cmds &&
        media_crc==XE_NP_Np2DualSd_Crc32((const uint8_t *)media,prior_sectors*(uint32_t)sizeof(media[0])));
}
static void degraded_and_rewind_listing(void)
{
    /* Keep one valid prefix entry and a v14 FAILED tail whose physical
     * directory still has the older header fence. INFO stages its whole
     * known allocation without publishing quarantine or changing the footer. */
    reset_model();append(0U,3U,0U);uint8_t configuration[2048]={0};XE_NP_Np2DualSdMeta m;
    assert(!XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(3U,20000U,16U,901U,
        XE_NP_Np2DualSd_Crc32(configuration,sizeof(configuration)),16384U,&m));
    assert(!XE_NP_Np2DualSdCatalogPort_ReserveAppend(&m,configuration));
    const XE_NP_Np2SdAppendCounts gap={8U,4U,12U};
    assert(!XE_NP_Np2DualSdCatalogPort_FinishAppend(4U,9U,&gap));
    put32(sector(128U)+8U,m.run.payload_start_lba);put32(sector(128U)+260U,m.run.payload_start_lba);
    xe_np_np2_dual_sd_app_mailbox.state=5U;
    read_only_snapshot(2U,(m.reservation_end_lba+8191U)&~8191U,XE_NP_NP2_CATALOG_DEGRADED);
    XE_NP_Np2DualSdCatalogInfo i=info();entry(i,1U);
    assert((u32(reply+56U)&65535U)==(14U|(4U<<8U)) &&
        (u32(reply+56U)&XE_NP_NP2_CATALOG_INCOMPLETE) && u32(reply+36U)==m.reservation_end_lba);

    /* An unknown final allocation may expose only the coherent readable
     * prefix, including empty and a full63-entry preceding page. No hunt,
     * implicit Recover/Rewind, mutation permission or fabricated free space. */
    static const uint32_t counts[]={0U,1U,63U,64U};
    for(unsigned n=0U;n<sizeof(counts)/sizeof(counts[0]);n++){
        reset_model();uint32_t count=counts[n];
        for(uint32_t ordinal=0U;ordinal<count;ordinal++)append(ordinal,3U,0U);
        uint32_t offered=xe_np_np2_dual_sd_app_mailbox.next_start_lba;
        append(count,3U,0U);uint32_t tail=info().last_start;
        sector(tail+3U)[508]^=1U;sector(tail+4U)[508]^=1U;
        xe_np_np2_dual_sd_app_mailbox.state=5U;
        read_only_snapshot(count,offered,PREFIX_FLAGS);
    }
    puts("PASS actual stopped B9 INFO/ENTRY: stable read-only v14 known-allocation overlay and zero/1/63/64-entry rewind prefixes; contiguous next geometry, delete disabled, all prior sectors/CMD20 unchanged");
}
static void foreign_media_read_only(void)
{
    reset_model();memcpy(sector(16U)+32U,"NP_CE64_1",9U);
    /* Small synthetic finalized v8 metadata admitted by the existing strict
     * camera-tail validator; this does not claim camera payload validation. */
    for(uint32_t footer=0U;footer<=1U;footer++){
        uint8_t *b=sector(8195U+footer);memset(b,0,512U);
        memcpy(b,footer?"NPSDEND1":"NPSDLOG1",8U);
        put32(b+8U,8U);put32(b+12U,91U);put32(b+20U,1U);
        put32(b+32U,15360U);put32(b+36U,128U);put32(b+40U,8192U);
        put32(b+44U,CAPACITY);put32(b+48U,8192U);put32(b+60U,footer?3U:1U);
        put32(b+68U,footer?8U:0U);put32(b+80U,2U);put32(b+96U,61632U);
        put32(b+112U,50U);put32(b+116U,200000U);put32(b+120U,1U);
        memcpy(b+128U,"NPMEDX1",8U);put32(b+136U,1U);put32(b+140U,footer?28U:24U);
        put32(b+168U,50U);put32(b+220U,200000U);
        if(footer){put32(b+172U,1U);put32(b+176U,1U);put32(b+180U,1U);
            put32(b+184U,1U);put32(b+228U,1U);put32(b+236U,1U);}
        put32(b+508U,XE_NP_Np2DualSd_Crc32(b,508U));
    }
    put32(sector(128U),1U);put32(sector(128U)+4U,17408U);put32(sector(128U)+256U,17408U);
    uint32_t before=writes;XE_NP_Np2DualSdCatalogInfo i=info();entry(i,0U);
    assert(i.count==1U && !i.flags && i.next==24576U && i.last_end==17408U &&
        u32(reply+56U)==(8U|(3U<<8U)|XE_NP_NP2_CATALOG_METADATA_VALID|XE_NP_NP2_CATALOG_LAST));
    deletion(i,401U);assert(send()==8U && writes==before && !xe_np_np2_dual_sd_app_mailbox.command);
    puts("PASS shared-card finalized foreign v8 listed read-only, no relabel/delete or metadata writes");
}
#if XE_NP_NP2_SD_GRID16_ENABLE
static void grid16_tail(uint32_t state)
{
    XE_NP_Np2DualSdCatalogInfo before=info();
    uint32_t start=before.next,payload=(start+8192U+16383U)&~16383U;
    XE_NP_Grid16Meta m={0};m.session=901;m.mask=7;m.sample_hz=20000;m.base=11;
    m.reservation_start=start;m.payload_start=payload;m.max_groups=2;
    m.payload_end=payload+2U*365U;m.reservation_end=(m.payload_end+16383U)&~16383U;
    m.card_blocks=CAPACITY;memcpy(m.cid,model_cid,sizeof(m.cid));
    uint8_t *descriptor=sector(start+3U),*footer=sector(start+4U);
    assert(!XE_NP_Grid16_EncodeDescriptor(descriptor,&m));
    XE_NP_Grid16Footer f={0};f.state=state;f.error=state==3U?0U:8U;
    f.np_blocks=8U;f.empty=2U;f.final_exclusive=UINT64_MAX;
    assert(!XE_NP_Grid16_EncodeFooter(footer,descriptor,&f));
    uint32_t end=state==3U?m.payload_end:m.reservation_end;
    put32(sector(128U)+4U+before.count*4U,end);
    put32(sector(128U)+256U+before.count*4U,end);
    put32(sector(128U),before.count+1U);
}
static void grid16_catalog(void)
{
    reset_model();append(0U,3U,0U);XE_NP_Np2DualSdCatalogInfo prior=info();
    uint8_t prior_header[512],prior_footer[512];
    memcpy(prior_header,sector(prior.last_start+3U),512U);
    memcpy(prior_footer,sector(prior.last_start+4U),512U);
    grid16_tail(3U);XE_NP_Np2DualSdCatalogInfo i=info();
    assert(i.count==2U && i.last_start==prior.next && !i.flags);
    entry(i,1U);assert((u32(reply+56U)&255U)==16U &&
       (u32(reply+56U)&XE_NP_NP2_CATALOG_DELETE_ALLOWED));
    deletion(i,601U);put32(request+36U,i.last_cookie^1U);uint32_t before=writes;
    assert(send()==9U && writes==before);
    deletion(i,602U);assert(!send());uint32_t cmds=commands;delete_only=1U;
    XE_NP_Np2DualSdApp_Service();assert(!xe_np_np2_dual_sd_app_mailbox.command_error &&
        writes==before+4U && commands==cmds);
    XE_NP_Np2DualSdCatalogInfo after=info();assert(after.count==1U && after.next==prior.next &&
        after.last_start==prior.last_start && after.last_end==prior.last_end &&
        !memcmp(prior_header,sector(prior.last_start+3U),512U) &&
        !memcmp(prior_footer,sector(prior.last_start+4U),512U));
    delete_only=0U;
    reset_model();append(0U,3U,0U);grid16_tail(4U);i=info();entry(i,1U);
    assert((u32(reply+56U)&XE_NP_NP2_CATALOG_INCOMPLETE) &&
        !(u32(reply+56U)&XE_NP_NP2_CATALOG_DELETE_ALLOWED));
    before=writes;deletion(i,603U);assert(send()==8U && writes==before);
    /* An incomplete tail at the short physical fence is overlaid with the
     * full declared allocation, without a write or implicit deletion. */
    uint32_t tail=i.last_start,payload=u32(sector(tail+3U)+60U);
    put32(sector(128U)+8U,payload+730U);put32(sector(128U)+260U,payload+730U);
    i=info();entry(i,1U);assert(i.flags==XE_NP_NP2_CATALOG_DEGRADED &&
        i.last_end==u32(sector(tail+3U)+68U) && writes==before &&
        !(u32(reply+56U)&XE_NP_NP2_CATALOG_DELETE_ALLOWED));
    /* A queued operation must be revalidated after a CRC-correct metadata
     * mutation, not just at BLE acknowledgment. */
    reset_model();append(0U,3U,0U);grid16_tail(3U);i=info();deletion(i,604U);
    assert(!send());tail=i.last_start;sector(tail+4U)[276U]^=1U;
    put32(sector(tail+4U)+508U,XE_NP_Np2DualSd_Crc32(sector(tail+4U),508U));
    before=writes;XE_NP_Np2DualSdApp_Service();
    assert(xe_np_np2_dual_sd_app_mailbox.command_error && writes==before);
    /* Both sealed copies can agree while belonging to a different card. */
    reset_model();append(0U,3U,0U);grid16_tail(3U);i=info();
    tail=i.last_start;sector(tail+3U)[80U]^=1U;sector(tail+4U)[80U]^=1U;
    put32(sector(tail+3U)+508U,XE_NP_Np2DualSd_Crc32(sector(tail+3U),508U));
    put32(sector(tail+4U)+508U,XE_NP_Np2DualSd_Crc32(sector(tail+4U),508U));
    before=writes;deletion(i,605U);assert(send()!=0U && writes==before);
    /* No footer-only v16 reconstruction. */
    reset_model();append(0U,3U,0U);grid16_tail(3U);i=info();tail=i.last_start;
    sector(tail+3U)[508U]^=1U;before=writes;i=info();
    assert((i.flags&XE_NP_NP2_CATALOG_RECOVERY) && i.count==1U && writes==before);
    /* CRC-correct malformed optional schema2 quality must not hide NP. */
    reset_model();append(0U,3U,0U);grid16_tail(3U);i=info();tail=i.last_start;
    assert(u32(sector(tail+3U)+216U)==2U);
    put32(sector(tail+4U)+400U,2U);
    put32(sector(tail+4U)+508U,XE_NP_Np2DualSd_Crc32(sector(tail+4U),508U));
    i=info();entry(i,1U);
    assert(i.count==2U && !i.flags && (u32(reply+56U)&255U)==16U &&
        (u32(reply+56U)&XE_NP_NP2_CATALOG_DELETE_ALLOWED));
    /* Existing schema1 descriptor/footer remain listable. */
    put32(sector(tail+3U)+216U,1U);put32(sector(tail+4U)+216U,1U);
    put32(sector(tail+4U)+400U,0U);
    put32(sector(tail+3U)+508U,XE_NP_Np2DualSd_Crc32(sector(tail+3U),508U));
    put32(sector(tail+4U)+508U,XE_NP_Np2DualSd_Crc32(sector(tail+4U),508U));
    i=info();entry(i,1U);
    assert(i.count==2U && !i.flags && (u32(reply+56U)&255U)==16U);
    puts("PASS SD16 real catalog: physical end, list, journal-only delete, stale/CID/incomplete refusal and preserved prefix");
}
static void grid16_reservation(void)
{
    static const uint32_t rates[]={7500U,15000U,20000U,30000U},masks[]={1U,3U,7U};
    reset_model();
    for(unsigned a=0U;a<3U;a++)for(unsigned b=0U;b<4U;b++){
        XE_NP_Grid16Meta exact,full;uint32_t k=XE_NP_Grid16_K(masks[a],rates[b]);
        assert(!XE_NP_Np2DualSdCatalogPort_PlanGrid16(masks[a],rates[b],8U,99U,0U,11U,0U,&exact));
        assert(exact.max_groups==2U && exact.payload_end-exact.payload_start==2U*(364U+k));
        assert(!XE_NP_Np2DualSdCatalogPort_PlanGrid16(masks[a],rates[b],0U,99U,0U,13U,16384U,&full));
        assert(full.max_groups>2U && full.reservation_end<=CAPACITY &&
            full.payload_end-full.payload_start==full.max_groups*(364U+k) &&
            (uint64_t)full.payload_end+364U+k>full.reservation_end);
    }
    append(0U,3U,0U);XE_NP_Np2DualSdCatalogInfo old=info();uint8_t old_header[512];
    memcpy(old_header,sector(old.last_start+3U),512U);
    XE_NP_Grid16Meta m;assert(!XE_NP_Np2DualSdCatalogPort_PlanGrid16(7U,20000U,8U,99U,0U,11U,0U,&m));
    uint8_t grid_config[2048]={0};memcpy(grid_config,"N2SDCFG1",8U);put32(grid_config+8U,1U);
    put32(grid_config+16U,m.sample_hz);put32(grid_config+20U,m.sample_hz*1600U);put32(grid_config+24U,m.mask);
    put32(grid_config+28U,511U);put32(grid_config+32U,6U);put32(grid_config+36U,9U);put32(grid_config+40U,46592U);
    put32(grid_config+44U,m.max_groups*4U);memcpy(grid_config+48U,m.cid,16U);
    m.config_crc=XE_NP_Np2DualSd_Crc32(grid_config,sizeof(grid_config));
    uint32_t before=writes,cmds=commands;m.cid[0]^=1U;
    assert(XE_NP_Np2DualSdCatalogPort_ReserveGrid16(&m,grid_config,0) && writes==before && commands==cmds);m.cid[0]^=1U;
    put32(grid_config+44U,4U);m.config_crc=XE_NP_Np2DualSd_Crc32(grid_config,sizeof(grid_config));
    assert(XE_NP_Np2DualSdCatalogPort_ReserveGrid16(&m,grid_config,0) && writes==before && commands==cmds);
    put32(grid_config+44U,8U);m.config_crc=XE_NP_Np2DualSd_Crc32(grid_config,sizeof(grid_config));
    assert(!XE_NP_Np2DualSdCatalogPort_ReserveGrid16(&m,grid_config,0));before=writes;
    assert(XE_NP_Np2DualSdCatalogPort_Finish(3U,0U,4U) && writes==before);
    XE_NP_Grid16Footer f={0};f.state=3U;f.np_blocks=4U;f.empty=1U;f.final_exclusive=UINT64_MAX;
    failed_write=writes+1U;assert(XE_NP_Np2DualSdCatalogPort_FinishGrid16(&f));failed_write=0U;
    assert(!XE_NP_Np2DualSdCatalogPort_FinishGrid16(&f));
    XE_NP_Np2DualSdCatalogInfo now=info();assert(now.count==2U && now.last_end==m.payload_start+365U &&
        !memcmp(old_header,sector(old.last_start+3U),512U));entry(now,1U);
    assert((u32(reply+56U)&255U)==16U && (u32(reply+56U)&XE_NP_NP2_CATALOG_DELETE_ALLOWED));
    /* A partially completed group count never trims a FAILED allocation. */
    reset_model();assert(!XE_NP_Np2DualSdCatalogPort_PlanGrid16(7U,20000U,8U,99U,0U,11U,0U,&m));
    put32(grid_config+44U,8U);memcpy(grid_config+48U,m.cid,16U);m.config_crc=XE_NP_Np2DualSd_Crc32(grid_config,sizeof(grid_config));
    assert(!XE_NP_Np2DualSdCatalogPort_ReserveGrid16(&m,grid_config,0));f.state=4U;f.error=8U;
    assert(!XE_NP_Np2DualSdCatalogPort_FinishGrid16(&f));now=info();entry(now,0U);
    assert(now.last_end==m.reservation_end && (u32(reply+56U)&XE_NP_NP2_CATALOG_INCOMPLETE) &&
        !(u32(reply+56U)&XE_NP_NP2_CATALOG_DELETE_ALLOWED));
    puts("PASS SD16 plan/reserve/finish: 12 profiles, exact/continuous groups, ownership, confirmed end and incomplete fence");
}
#endif
#endif
static int pool_init_allowed=1,pool_finish_allowed=1,writer_init_allowed=1;
static uint32_t init_called,finish_called,init_k,abort_called;
uint32_t test_grid16_nonce;
#if XE_NP_NP2_FIRST_SYNC_ENABLE
static uint32_t mock_grid_active,mock_discard_pending,discard_calls;
static uint64_t mock_discard_rows;
void XE_NP_Np2FirstSyncRuntime_Init(void){}
void XE_NP_Np2FirstSyncRuntime_SdPrepare(uint32_t n,uint32_t s,uint32_t m,uint32_t h){(void)n;(void)s;(void)m;(void)h;}
void XE_NP_Np2FirstSyncRuntime_Stop(void){}
void XE_NP_Np2FirstSyncRuntime_Service(void){}
void XE_NP_Np2FirstSyncRuntime_SdTime(uint8_t b[512]){(void)b;}
int XE_NP_Np2FirstSyncRuntime_SdOpted(void){return 0;}
void XE_NP_Np2FirstSyncRuntime_SdGridStatus(XE_NP_Np2SdGridStatus *s)
{memset(s,0,sizeof(*s));s->started=s->attached=mock_grid_active;s->stopped_discarded_pending=mock_discard_pending;}
int XE_NP_Np2FirstSyncRuntime_SdGridDiscardStopped(uint64_t *rows)
{discard_calls++;if(rows)*rows=mock_discard_rows;return 1;}
void XE_NP_Np2FirstSyncSd_CancelStart(uint32_t n){(void)n;}
void XE_NP_Np2FirstSyncSd_AcceptedLegacyStart(uint32_t n){(void)n;}
void XE_NP_Np2FirstSyncSd_AcceptedLegacyStop(uint32_t n){(void)n;}
#endif
int XE_NP_Grid16Pool_Init(uint32_t k){init_called++;init_k=k;return pool_init_allowed;}
int XE_NP_Grid16Pool_AbortPrepared(void){abort_called++;return 1;}
const uint8_t *XE_NP_Grid16Pool_Acquire(void *c,uint32_t first,uint32_t k)
{(void)c;(void)first;(void)k;return NULL;}
void XE_NP_Grid16Pool_Release(void *c,uint32_t first,const uint8_t *p)
{(void)c;(void)first;(void)p;}
void XE_NP_Grid16Pool_Commit(void *c,uint32_t first,uint32_t n,uint32_t end)
{(void)c;(void)first;(void)n;(void)end;}
void XE_NP_Grid16Pool_SourceStopped(void *c,uint32_t n){(void)c;(void)n;}
int XE_NP_Grid16Pool_Finish(XE_NP_Grid16Footer *f)
{assert(f->np_blocks==xe_np_np2_live_sd_mailbox.written_rus*4U);finish_called++;f->empty=init_k*xe_np_np2_live_sd_mailbox.written_rus;return pool_finish_allowed;}
int XE_NP_Np2LiveSd_InitExtentGrid16(SD_HandleTypeDef *c,DCACHE_HandleTypeDef *dc,
 uint32_t start,uint32_t end,uint32_t blocks,uint32_t mask,uint32_t hz,uint32_t k,
 XE_NP_Np2LiveSdGrid16Acquire a,XE_NP_Np2LiveSdGrid16Release r,
 XE_NP_Np2LiveSdGrid16Commit commit,XE_NP_Np2LiveSdGrid16SourceStopped stop,XE_NP_Np2LiveSdGrid16PrepareStop prep,void *context)
{
 assert(c==&model_card && dc==&model_cache && end==start+(blocks/4)*(364U+k) &&
        a==XE_NP_Grid16Pool_Acquire && r==XE_NP_Grid16Pool_Release &&
        commit==XE_NP_Grid16Pool_Commit && stop==XE_NP_Grid16Pool_SourceStopped && prep==XE_NP_Grid16Pool_PrepareStop && !context);
 if(!writer_init_allowed)return -1;
 xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_CONFIGURING;
 xe_np_np2_live_sd_mailbox.start_lba=start;xe_np_np2_live_sd_mailbox.target_blocks=blocks;
 xe_np_np2_live_sd_mailbox.probe_mask=mask;xe_np_np2_live_sd_mailbox.sample_hz=hz;return 0;
}
uint32_t test_append_nonce; static uint32_t mock_stored,append_inits; static XE_NP_Grid16Footer append_counts;
#undef XE_NP_Np2FirstSyncSd_Grid16Start
uint32_t XE_NP_Np2FirstSyncSd_Grid16Start(uint32_t n){(void)n;return 0;}
uint32_t XE_NP_Np2FirstSyncSd_BridgeGrid16(void){return 0;}
int XE_NP_Grid16Pool_SetPartialWindow(uint32_t n){(void)n;return 1;}
const XE_NP_Np2FirstSyncSdContext *XE_NP_Np2FirstSyncSd_Record(void){return NULL;}
int XE_NP_Np2FirstSyncRuntime_SdFineAnchor(uint8_t out[64]){(void)out;return 0;}
int XE_NP_Np2FirstSyncRuntime_FineCounter64(void){return 0;}
const uint8_t *XE_NP_Np2FirstSyncRuntime_RtcFrozen(void){return NULL;}
uint32_t HAL_GetUIDw0(void){return 1U;} uint32_t HAL_GetUIDw1(void){return 2U;} uint32_t HAL_GetUIDw2(void){return 3U;}
uint32_t XE_NP_Np2LiveSd_StoredBlocks(void){return mock_stored;}
int XE_NP_Grid16Pool_PrepareStop(void *c,uint32_t x,uint32_t y,uint32_t *z){(void)c;(void)x;(void)y;(void)z;return 1;}
const uint8_t *XE_NP_Grid16Pool_AcquireAppend(void *c,uint32_t p,uint32_t l,uint32_t k){(void)c;(void)p;(void)l;(void)k;return NULL;}
void XE_NP_Grid16Pool_ReleaseAppend(void *c,uint32_t p,uint32_t l,const uint8_t *s){(void)c;(void)p;(void)l;(void)s;}
int XE_NP_Grid16Pool_AppendFault(void *c){(void)c;return 0;}
void XE_NP_Grid16Pool_CommitAppend(void *c,uint32_t p,uint32_t n,uint32_t e){(void)c;(void)p;(void)n;(void)e;}
int XE_NP_Grid16Pool_PrepareStopAppend(void *c,uint32_t a,uint32_t b,uint32_t *d){(void)c;(void)a;(void)b;(void)d;return 1;}
int XE_NP_Np2LiveSd_GetGrid16AppendCounts(XE_NP_Grid16Footer *f){*f=append_counts;return 0;}
int XE_NP_Np2LiveSd_InitExtentGrid16Append(SD_HandleTypeDef *c,DCACHE_HandleTypeDef *dc,uint32_t start,uint32_t end,uint32_t blocks,uint32_t mask,uint32_t hz,uint32_t k,XE_NP_Np2LiveSdGrid16AcquireAppend a,XE_NP_Np2LiveSdGrid16ReleaseAppend r,XE_NP_Np2LiveSdGrid16AppendFault f,XE_NP_Np2LiveSdGrid16Commit commit,XE_NP_Np2LiveSdGrid16SourceStopped stop,XE_NP_Np2LiveSdGrid16PrepareStop prep,void *context){(void)c;(void)dc;(void)end;(void)k;(void)context;assert(a==XE_NP_Grid16Pool_AcquireAppend&&r==XE_NP_Grid16Pool_ReleaseAppend&&f==XE_NP_Grid16Pool_AppendFault&&commit==XE_NP_Grid16Pool_CommitAppend&&stop==XE_NP_Grid16Pool_SourceStopped&&prep==XE_NP_Grid16Pool_PrepareStopAppend);append_inits++;if(!writer_init_allowed)return -1;xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_CONFIGURING;xe_np_np2_live_sd_mailbox.start_lba=start;xe_np_np2_live_sd_mailbox.target_blocks=blocks;xe_np_np2_live_sd_mailbox.probe_mask=mask;xe_np_np2_live_sd_mailbox.sample_hz=hz;return 0;}
static void grid16_app_test(void)
{
 reset_model();memcpy((void *)xe_np_np2_dual_sd_app_mailbox.cid,model_cid,sizeof(model_cid));
 selected_mask=7U;pool_init_allowed=1;abort_called=0;
 test_grid16_nonce=332U;assert(XE_NP_Grid16Pool_Init(1U));
 assert(begin(UINT32_MAX-3U,20000U,332U) && abort_called==1U);
 /* CID mismatch causes reserve rejection before ownership; release the pool. */
 reset_model();memcpy((void *)xe_np_np2_dual_sd_app_mailbox.cid,model_cid,sizeof(model_cid));
 xe_np_np2_dual_sd_app_mailbox.cid[0]^=1U;selected_mask=7U;
 test_grid16_nonce=333U;assert(XE_NP_Grid16Pool_Init(1U));
 assert(begin(8U,20000U,333U) && abort_called==2U);
 reset_model();memcpy((void *)xe_np_np2_dual_sd_app_mailbox.cid,model_cid,sizeof(model_cid));
 selected_mask=7U;writer_init_allowed=0;
 test_grid16_nonce=334U;assert(XE_NP_Grid16Pool_Init(1U));
 assert(begin(8U,20000U,334U) && abort_called==3U && !XE_NP_Np2DualSdCatalog_Reserved());
 writer_init_allowed=1;
 reset_model();memcpy((void *)xe_np_np2_dual_sd_app_mailbox.cid,model_cid,sizeof(model_cid));
 selected_mask=7U;init_called=finish_called=0;pool_init_allowed=pool_finish_allowed=1;
 test_grid16_nonce=333U;assert(XE_NP_Grid16Pool_Init(1U));
 assert(!begin(8U,20000U,333U) && reservation_grid16 && grid_writer_bound && init_called==1 && init_k==1);
 uint32_t start=reservation.reservation_start_lba,payload=reservation.run.payload_start_lba;
 assert(u32(sector(start+3U)+8U)==16U && grid_reservation.payload_end==payload+730U);
 xe_np_np2_live_sd_mailbox.written_rus=1U;xe_np_np2_live_sd_mailbox.target_blocks=4U;
 xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_COMPLETE;xe_np_np2_live_sd_mailbox.error=0U;
#if XE_NP_NP2_FIRST_SYNC_ENABLE
 mock_grid_active=1U;mock_discard_rows=3U;mock_discard_pending=0U;discard_calls=0U;
#endif
 terminal(3U,0U);assert(finish_called==1 && xe_np_np2_dual_sd_app_mailbox.state==XE_NP_NP2_DUAL_SD_COMPLETE);
 assert(u32(sector(start+4U)+116U)==payload+365U && u32(sector(128U)+4U)==payload+365U);
#if XE_NP_NP2_FIRST_SYNC_ENABLE
 assert(discard_calls==1U && (u32(sector(start+4U)+272U)&4U));mock_grid_active=0U;
#endif
 reset_model();frame(1U,400U);put32(request+16U,7U);put32(request+20U,20000U);assert(!send());
 frame(2U,401U);put32(request+16U,7U);put32(request+20U,20000U);put32(request+24U,0U);assert(!send());
 assert(xe_np_np2_dual_sd_app_mailbox.requested_blocks==((CAPACITY-16384U)/364U)*4U);
 reset_model();memcpy((void *)xe_np_np2_dual_sd_app_mailbox.cid,model_cid,sizeof(model_cid));
 selected_mask=7U;pool_init_allowed=0;
 test_grid16_nonce=0U;
 memset(&model_counts,0,sizeof(model_counts));
 assert(!begin(8U,20000U,335U) && !reservation_grid16 && reservation_append);
 assert(u32(sector(reservation.reservation_start_lba+3U)+8U)==14U);
 xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_COMPLETE;
 xe_np_np2_live_sd_mailbox.target_blocks=xe_np_np2_live_sd_mailbox.written_rus=0U;
 terminal(4U,8U);assert(!XE_NP_Np2DualSdCatalog_Reserved());pool_init_allowed=1;
 reset_model();memcpy((void *)xe_np_np2_dual_sd_app_mailbox.cid,model_cid,sizeof(model_cid));
 selected_mask=7U;pool_finish_allowed=0;test_grid16_nonce=334U;assert(XE_NP_Grid16Pool_Init(1U));assert(!begin(8U,20000U,334U));
 start=reservation.reservation_start_lba;xe_np_np2_live_sd_mailbox.written_rus=1U;
 xe_np_np2_live_sd_mailbox.target_blocks=4U;xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_COMPLETE;
 terminal(3U,0U);assert(xe_np_np2_dual_sd_app_mailbox.state==XE_NP_NP2_DUAL_SD_FAILED &&
    XE_NP_Np2DualSdCatalog_Reserved() && u32(sector(start+4U)+100U)==1U);
 pool_finish_allowed=1;
}
static void append_app_test(void){
 uint32_t start,payload;
 /* No admitted writer: never reuse the previous writer's append counts. */
 reset_model();memcpy((void *)xe_np_np2_dual_sd_app_mailbox.cid,model_cid,sizeof(model_cid));
 selected_mask=7U;writer_init_allowed=0;test_grid16_nonce=test_append_nonce=450U;
 assert(XE_NP_Grid16Pool_Init(1U));assert(begin(16U,20000U,450U));
 start=reservation.reservation_start_lba;assert(!XE_NP_Np2DualSdCatalog_Reserved());
 assert(u32(sector(start+4U)+416U)==UINT32_MAX && u32(sector(start+4U)+420U)==0U);
 /* V5 uses physical N, independent of logical P; seal through real catalog. */
 reset_model();memcpy((void *)xe_np_np2_dual_sd_app_mailbox.cid,model_cid,sizeof(model_cid));
 selected_mask=7U;pool_finish_allowed=writer_init_allowed=1;test_grid16_nonce=test_append_nonce=451U;
 assert(XE_NP_Grid16Pool_Init(1U));append_inits=0U;assert(!begin(16U,20000U,451U));
 assert(reservation_grid16_append && grid_writer_bound && append_inits==1U && grid_reservation.schema==3U);
 start=reservation.reservation_start_lba;payload=reservation.run.payload_start_lba;
 assert(u32(sector(start+3U)+216U)==3U && u32(sector(start+3U)+224U)==1U);
 mock_stored=8U;xe_np_np2_live_sd_mailbox.written_rus=2U;xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_FAILED;
 memset(&append_counts,0,sizeof(append_counts));append_counts.logical_prefix_blocks=4U;
 append_counts.logical_high_water_blocks=12U;append_counts.admitted_blocks=13U;append_counts.append_flags=1U;
 terminal(4U,9U);assert(!XE_NP_Np2DualSdCatalog_Reserved());
 assert(u32(sector(start+4U)+116U)==payload+730U && u32(sector(start+4U)+408U)==4U &&
        u32(sector(start+4U)+412U)==12U && u32(sector(start+4U)+416U)==13U && u32(sector(start+4U)+420U)==1U);
 test_append_nonce=0U;puts("PASS SD16 app reserve/write/finalize and append partial N/P/H/A");
}

int main(int argc,char **argv)
{
    (void)argc;(void)argv;
    model_card.Instance=SDMMC1;model_card.State=HAL_SD_STATE_READY;
    model_card.SdCard.LogBlockNbr=CAPACITY;model_card.SdCard.CardType=CARD_SDHC_SDXC;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    zero_patch((uint8_t *)&model_cid[3],cid_crc);
#endif
    memcpy(model_card.CID,model_cid,sizeof(model_cid));
    assert(!XE_NP_Np2DualSdApp_Init(&model_card,&model_cache));reset_model();
    if(argc==1){append_app_test();return 0;}
    assert(XE_NP_NP2_DUAL_SD_CMD_REWIND==6U && XE_NP_NP2_DUAL_SD_CMD_DELETE_LAST==7U);
    assert(sizeof(XE_NP_Np2DualSdAppMailbox)==104U && offsetof(XE_NP_Np2DualSdAppMailbox,writer_verified_blocks)==100U);
    frame(0U,1U);assert(!send());
#if NP_BLE_CATALOG_ZERO_CANCEL_TEST
    if(argc>1 && !strcmp(argv[1],"--zero-cancel-only")){
        zero_actual_app(argc>2?argv[2]:NULL);zero_app_guards();zero_unproven_footers();zero_publication_cuts();return 0;
    }
#endif
#if XE_NP_NP2_SD_CATALOG_ENABLE
    assert(u32(reply+52U)&XE_NP_NP2_SD_CAP_CATALOG);
    list_delete();owners();errors_and_cache();power_cuts();zero_values();sealed_metadata_fingerprint();
    incomplete_read_only();terminal_catalog_refresh();unsafe_empty_and_rewind_surface();
    foreign_media_read_only();degraded_and_rewind_listing();
#if XE_NP_NP2_SD_GRID16_ENABLE
    grid16_catalog();
    grid16_reservation();grid16_app_test();
#endif
#else
    assert(!(u32(reply+52U)&XE_NP_NP2_SD_CAP_CATALOG));
    append(0U,3U,0U);uint32_t before=reads;
    for(uint32_t op=9U;op<=11U;op++){frame(op,op);assert(send()==4U && reads==before && !xe_np_np2_dual_sd_app_mailbox.command);}
    puts("PASS compile-default OFF: bit22 absent, ops9/10/11 unsupported before I/O, unchanged104-byte mailbox");
#endif
    return 0;
}
