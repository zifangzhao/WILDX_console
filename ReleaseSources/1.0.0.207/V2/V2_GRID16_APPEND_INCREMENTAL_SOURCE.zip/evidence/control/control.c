#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "xe_np_np2_sd_control.h"
#include "xe_np_np2_dual_sd_app.h"
#include "xe_np_np2_live_sd.h"
#include "xe_np_np2_first_sync_sd.h"

volatile XE_NP_Np2DualSdAppMailbox xe_np_np2_dual_sd_app_mailbox;
volatile XE_NP_Np2LiveSdMailbox xe_np_np2_live_sd_mailbox;
static uint32_t mask,init_count,set_count,window,init_ok,abort_count;
static uint32_t append_count;
uint32_t HAL_GetUIDw0(void){return 1U;}uint32_t HAL_GetUIDw1(void){return 2U;}uint32_t HAL_GetUIDw2(void){return 3U;}
uint32_t XE_NP_Np2DualSdApp_ProfileMask(void){return mask;}
int XE_NP_Np2DualSdApp_SelectProfile(uint32_t m,uint32_t hz){(void)hz;mask=m;return 0;}
int XE_NP_Np2DualSdApp_Schedule(uint64_t when){(void)when;return 0;}
void XE_NP_Np2DualSdApp_CancelSchedule(void){}
int XE_NP_Np2LiveSd_SupportsProfile(uint32_t m,uint32_t hz){return XE_NP_Np2DualSd_ProfileTicks(m,hz)!=0;}
uint32_t XE_NP_Np2DualSdCatalog_Status(void){return 0;}
int XE_NP_Np2SdBle_ModeAvailable(uint32_t m){return m>0;}
/* Control integration uses a pool stub to capture call ordering and arguments;
 * the separate r15 actual-pool fixture tests its implementation. */
uint32_t XE_NP_Grid16_K(uint32_t m,uint32_t hz){(void)m;(void)hz;return 1U;}
int XE_NP_Grid16Pool_Init(uint32_t k){assert(k==1U);assert(!set_count);init_count++;return (int)init_ok;}
int XE_NP_Grid16Pool_InitAppend(uint32_t k){assert(k==1U);assert(!set_count);init_count++;append_count++;return (int)init_ok;}
int XE_NP_Grid16Pool_SetPartialWindow(uint32_t first){assert(init_count==1U && init_ok);assert(!xe_np_np2_dual_sd_app_mailbox.command);set_count++;window=first;return 1;}
int XE_NP_Grid16Pool_AbortPrepared(void){abort_count++;return 1;}
static void legacy(uint8_t out[64],uint32_t id,uint32_t op,uint32_t m,uint32_t hz,uint32_t blocks)
{
 memset(out,0,64U);np_first_put32(out,UINT32_C(0x32444c4e));np_first_put32(out+4,2U);
 np_first_put32(out+8,op);np_first_put32(out+12,id);np_first_put32(out+16,m);
 np_first_put32(out+20,hz);np_first_put32(out+24,blocks);np_first_put32(out+60,np_first_crc(out,60U));
}
static void run(uint32_t m,uint32_t hz,uint32_t requested,uint32_t expected_window,int enabled,int valid)
{
 XE_NP_Np2FirstSyncSdContext c={0};uint8_t l[64],q[64],a[64];const uint32_t uid[3]={1,2,3};
 memset((void *)&xe_np_np2_dual_sd_app_mailbox,0,sizeof(xe_np_np2_dual_sd_app_mailbox));
 xe_np_np2_dual_sd_app_mailbox.state=1U;xe_np_np2_dual_sd_app_mailbox.card_blocks=16777216U;
 xe_np_np2_dual_sd_app_mailbox.next_start_lba=8192U;mask=m;init_count=set_count=abort_count=0U;window=UINT32_MAX;init_ok=1U;
 XE_NP_Np2FirstSyncSd_Bind(&c);XE_NP_Np2SdControl_Init();
 legacy(l,1U,1U,m,hz,0U);assert(!XE_NP_Np2SdControl_Exchange(l,a));assert(np_first_u32(a+16U)==0U);
 legacy(l,2U,2U,m,hz,requested);assert(np_first_sd_grid16_wrap(q,l,2U,uid,11U,0U));
 assert(XE_NP_Np2FirstSyncSd_Exchange(q,a));
 if(!valid){assert(np_first_u32(a+32U)!=0U && init_count==0U && set_count==0U && !xe_np_np2_dual_sd_app_mailbox.command);return;}
 if(!(np_first_u32(a+32U)==0U && init_count==1U && set_count==(uint32_t)enabled))
  fprintf(stderr,"failure mask=%lu hz=%lu requested=%lu err=%lu init=%lu set=%lu expected=%d\n",(unsigned long)m,(unsigned long)hz,(unsigned long)requested,(unsigned long)np_first_u32(a+32U),(unsigned long)init_count,(unsigned long)set_count,enabled);
 assert(np_first_u32(a+32U)==0U && init_count==1U && set_count==(uint32_t)enabled);
 assert(xe_np_np2_dual_sd_app_mailbox.command==2U);
 uint32_t resolved=requested?requested:((16777216U-16384U)/365U)*4U;
 assert(xe_np_np2_dual_sd_app_mailbox.requested_blocks==resolved);
 if(enabled)assert(window==expected_window && !(window&3U));else assert(window==UINT32_MAX);
 uint8_t saved[64];memcpy(saved,a,64U);assert(XE_NP_Np2FirstSyncSd_Exchange(q,a));
 assert(!memcmp(saved,a,64U) && init_count==1U && set_count==(uint32_t)enabled);
}
static void admission_failure(void)
{
 XE_NP_Np2FirstSyncSdContext c={0};uint8_t l[64],q[64],a[64];const uint32_t uid[3]={1,2,3};
 memset((void *)&xe_np_np2_dual_sd_app_mailbox,0,sizeof(xe_np_np2_dual_sd_app_mailbox));
 xe_np_np2_dual_sd_app_mailbox.state=1U;xe_np_np2_dual_sd_app_mailbox.card_blocks=16777216U;
 xe_np_np2_dual_sd_app_mailbox.next_start_lba=8192U;mask=7U;init_count=set_count=abort_count=0U;init_ok=0U;
 XE_NP_Np2FirstSyncSd_Bind(&c);XE_NP_Np2SdControl_Init();
 legacy(l,2U,2U,7U,20000U,16U);assert(np_first_sd_grid16_wrap(q,l,2U,uid,11U,0U));
 assert(XE_NP_Np2FirstSyncSd_Exchange(q,a));
 assert(np_first_u32(a+32U)!=0U && init_count==1U && set_count==0U && !xe_np_np2_dual_sd_app_mailbox.command);
 init_count=set_count=0U;init_ok=1U;XE_NP_Np2SdControl_Init();
 legacy(l,3U,2U,7U,20000U,16U);assert(!XE_NP_Np2SdControl_Exchange(l,a));
 assert(np_first_u32(a+16U)==0U && init_count==0U && set_count==0U);
}
static void append_admission(void)
{
 XE_NP_Np2FirstSyncSdContext c={0};uint8_t l[64],q[64],a[64],saved[64];const uint32_t uid[3]={1,2,3};
 memset((void *)&xe_np_np2_dual_sd_app_mailbox,0,sizeof(xe_np_np2_dual_sd_app_mailbox));
 xe_np_np2_dual_sd_app_mailbox.state=1U;xe_np_np2_dual_sd_app_mailbox.card_blocks=16777216U;
 xe_np_np2_dual_sd_app_mailbox.next_start_lba=8192U;mask=7U;init_count=set_count=append_count=abort_count=0U;init_ok=1U;
 XE_NP_Np2FirstSyncSd_Bind(&c);XE_NP_Np2SdControl_Init();
 legacy(l,1U,1U,7U,20000U,0U);assert(!XE_NP_Np2SdControl_Exchange(l,a));assert(np_first_u32(a+16)==0U);
 legacy(l,2U,2U,7U,20000U,16U);assert(np_first_sd_grid16_append_wrap(q,l,2U,uid,11U,0U));
 assert(XE_NP_Np2FirstSyncSd_Exchange(q,a));
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
 assert(np_first_u32(a+32)==0U && init_count==1U && append_count==1U);
 assert(XE_NP_Np2FirstSyncSd_Grid16AppendStart(2U) && XE_NP_Np2FirstSyncSd_Grid16Start(2U));
 assert(XE_NP_Np2FirstSyncSd_CurrentContinuity());
 memcpy(saved,a,64U);assert(XE_NP_Np2FirstSyncSd_Exchange(q,a));assert(!memcmp(saved,a,64U)&&init_count==1U);
#else
 (void)saved;assert(np_first_u32(a+32)==NP_FIRST_SD_UNSUPPORTED && init_count==0U && append_count==0U);
#endif
}
int main(void)
{
 run(7U,20000U,4U,0U,1,1);run(7U,20000U,8U,0U,1,1);
 run(7U,20000U,12U,0U,1,1);run(7U,20000U,16U,4U,1,1);
 run(7U,20000U,93752U,93740U,1,1);
 run(7U,20000U,0U,((16777216U-16384U)/365U)*4U-12U,1,1);
 run(7U,20000U,5U,0U,0,0);
 run(7U,7500U,16U,0U,0,1);run(7U,15000U,16U,0U,0,1);run(7U,30000U,16U,0U,0,1);
 run(3U,20000U,16U,0U,0,1);run(1U,20000U,16U,0U,0,1);
 admission_failure();
 append_admission();
 puts("PASS actual SD control: init ordering, profiles, aligned/continuous and rejected short geometry");
 return 0;
}
