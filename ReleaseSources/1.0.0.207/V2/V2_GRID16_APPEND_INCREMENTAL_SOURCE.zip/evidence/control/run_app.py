"""Native SD16 APP/control/catalog lifecycle, with mocked writer and pool."""
from pathlib import Path
import os
import subprocess

root=Path('D:/Code/XE_NP_V2')
out=Path('C:/Frank/Code/XE_NP/_artifacts/grid16_append_control')
out.mkdir(parents=True,exist_ok=True)
flags=['XE_NP_NP2_SD_APPEND_ORDER_TEST=1U','XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE=1U',
 'XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES=1U','XE_NP_NP2_LIVE_SD_WRITE_RUS=6U',
 'XE_NP_NP2_LIVE_SD_WRITE_CAP_RUS=6U','XE_NP_NP2_LIVE_SD_MIN_WRITE_RUS=1U',
 'XE_NP_NP2_LIVE_SD_OVERFLOW_DMA=1U','XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER=1U',
 'XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST=1024U','XE_NP_NP2_LIVE_SD_VSC_TEST=1U',
 'XE_NP_NP2_SD_PROFILE_CLASSIC_TEST=1U','XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST=1U',
 'XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST=1U','XE_NP_NP2_SD_CARD_AU_POLICY_TEST=1U',
 'XE_NP_NP2_CLASSIC_RUNTIME_PROFILES_TEST=1U','XE_NP_NP2_CLASSIC_FIXED_RUNTIME_PROFILES_TEST=1U',
 'XE_NP_NP2_MIXED_SEQUENTIAL_POWER_RUNTIME_PROFILES_TEST=1U','XE_NP_NP2_LIVE_SD_BLOCK_LIMIT=32U',
 'XE_NP_NP2_SD_CATALOG_ENABLE=1U','XE_NP_NP2_SD_GRID16_ENABLE=1U','XE_NP_NP2_LIVE_SD_GRID16_ENABLE=1U',
 'XE_NP_NP2_FIRST_SYNC_ENABLE=1U','NP_FINE_COUNTER64_ENABLE=1U','XE_NP_NP2_SD_GRID16_APPEND_ENABLE=1U']
sources=['xe_np_np2_sd_control.c','xe_np_np2_dual_sd_catalog.c','xe_np_np2_dual_sd_catalog_port.c',
         'xe_np_np2_dual_sd_meta.c','xe_np_np2_dual_sd_run.c','xe_np_np2_grid16_meta.c']
stub=root/'Tools/V2SdLogger/tests/catalog_native'
vc=r'C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvars64.bat'
defs=' '.join('/D'+f for f in flags)
includes=' '.join('/I"'+str(p)+'"' for p in (Path('C:/Frank/Code/XE_NP/_artifacts/grid16_append_pool/Core/Inc'),Path('C:/Frank/Code/XE_NP/_artifacts/grid16_append_main/Core/Inc'),stub,root/'Core/Inc',root/'Core/Src',root/'Shared/Timing'))
units=' '.join('"'+str((root/'Core/Src'/p))+'"' for p in sources)
cmd=f'call "{vc}" >nul && cl /nologo /std:c11 /W4 /WX /TC /O2 {defs} /FI"{stub / "hardware.h"}" /FI"{out / "uid.h"}" /FI"{root / "Core/Inc/xe_np_np2_grid16_meta.h"}" /FI"C:/Frank/Code/XE_NP/_artifacts/grid16_append_main/Core/Inc/xe_np_np2_live_sd.h" /I"{out}" {includes} "{out / "app_fixture.c"}" {units} /Fo"{out}/" /Fe"{out / "test.exe"}" && "{out / "test.exe"}"'
subprocess.run(cmd,shell=True,check=True)
