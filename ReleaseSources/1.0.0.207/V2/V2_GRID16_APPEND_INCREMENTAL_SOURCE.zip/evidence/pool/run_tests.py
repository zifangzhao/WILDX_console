from pathlib import Path
import hashlib,json,subprocess

out=Path(__file__).resolve().parent
base=out.parent/'grid16_vsc_fix/r17-two-credit'
native=base/'tests/native6'
source=(out/'Core/Src/xe_np_np2_grid16_pool.c').read_text()
source=source.replace('#include "xe_np_np2_first_sync_runtime.h"','#include "tail_first_sync_stub.h"').replace('#include "xe_np_np2_capture_port.h"','#include "tail_capture_stub.h"')
assert source.count('XE_NP_Np2FirstSyncRuntime_SdGridNext(')==1 and source.count('XE_NP_Np2FirstSyncRuntime_SdGridNextPartial(')==1
source=source.replace('XE_NP_Np2FirstSyncRuntime_SdGridNext(', 'TestPool_Next(').replace('XE_NP_Np2FirstSyncRuntime_SdGridNextPartial(', 'TestPool_NextPartial(')
prefix='''#pragma warning(push)\n#pragma warning(disable:4324)\n#include <stdint.h>\nstatic int TestPool_Next(uint8_t *,uint32_t,uint32_t *,uint32_t *,uint64_t *);\nstatic int TestPool_NextPartial(uint8_t *,uint32_t,uint32_t *,uint32_t *,uint64_t *);\n'''
suffix=r'''
static uint32_t test_pool_fail_after_data,test_pool_data_claims;
void TestPool_SetFault(uint32_t enabled){test_pool_fail_after_data=enabled;test_pool_data_claims=0U;}
uint32_t TestPool_ActiveCount(void){uint32_t n=0U;for(uint32_t i=0U;i<4U;i++)n+=pool.slot[i].active!=0U;return n;}
uint32_t TestPool_CommittedCount(void){return pool.nonempty+pool.empty;}
static int TestPool_Next(uint8_t *b,uint32_t c,uint32_t *t,uint32_t *n,uint64_t *s)
{
 if(test_pool_fail_after_data && test_pool_data_claims)return -1;
 int r=XE_NP_Np2FirstSyncRuntime_SdGridNext(b,c,t,n,s);
 if(r==1 && *t==5U)test_pool_data_claims++;
 return r;
}
static int TestPool_NextPartial(uint8_t *b,uint32_t c,uint32_t *t,uint32_t *n,uint64_t *s)
{
 if(test_pool_fail_after_data && test_pool_data_claims)return -1;
 int r=XE_NP_Np2FirstSyncRuntime_SdGridNextPartial(b,c,t,n,s);
 if(r==1 && *t==5U)test_pool_data_claims++;
 return r;
}
'''
pool_file=out/'actual_pool.c';pool_file.write_text(prefix+source+'\n#pragma warning(pop)\n'+(base/'tests/tail_pool_faults.inc').read_text()+suffix)
fixture=(native/'actual_grid16_fixture.c').read_text()
marker='int main(int argc,char **argv)\n{'
assert fixture.count(marker)==1
cases=r'''
#include "xe_np_np2_grid16_sector.h"
void TestPool_SetFault(uint32_t);
uint32_t TestPool_ActiveCount(void);
uint32_t TestPool_CommittedCount(void);
static void append_order(void)
{
 TailRuntime_Begin(36U,0U);assert(XE_NP_Grid16Pool_InitAppend(1U));
 assert(XE_NP_Grid16Pool_AcquireAppend(NULL,UINT32_MAX,UINT32_MAX,1U));
 const uint8_t *s[3];uint32_t logical[3]={0U,8U,4U};
 for(uint32_t i=0;i<3U;i++){
  s[i]=XE_NP_Grid16Pool_AcquireAppend(NULL,i*4U,logical[i],1U);assert(s[i]);
  NpImuGridView view;assert(XE_NP_Grid16Sector_Read(s[i],9U,logical[i]+3U,&view)==1);
  assert(view.header.first_slot==i*12U && TailRuntime_Observed(s[i],logical[i]+3U)==12U);
 }
 XE_NP_Grid16Pool_ReleaseAppend(NULL,4U,8U,s[1]);
 assert(XE_NP_Grid16Pool_AcquireAppend(NULL,4U,8U,1U)==s[1]);
 for(uint32_t i=0;i<3U;i++)XE_NP_Grid16Pool_ReleaseAppend(NULL,i*4U,logical[i],s[i]);
 XE_NP_Grid16Pool_CommitAppend(NULL,0U,3U,1095U);
 assert(!XE_NP_Grid16Pool_AppendFault(NULL));
 XE_NP_Grid16Pool_SourceStopped(NULL,12U);XE_NP_Grid16Footer f;assert(TailRuntime_Footer(12U,&f));
 assert(f.observed==36U && f.nonempty==3U && !f.empty);puts("PASS physical 0/1/2 logical 0/2/1 firstslot order, retries, exact parents");
}
static void append_bad_claim(uint32_t mode)
{
 TailRuntime_Begin(24U,0U);assert(XE_NP_Grid16Pool_InitAppend(1U));
 const uint8_t *a=NULL;
 if(mode){a=XE_NP_Grid16Pool_AcquireAppend(NULL,0U,0U,1U);assert(a);}
 if(mode==3U){XE_NP_Grid16Pool_ReleaseAppend(NULL,0U,0U,a);XE_NP_Grid16Pool_CommitAppend(NULL,0U,1U,0U);}
 if(mode==0U)assert(!XE_NP_Grid16Pool_AcquireAppend(NULL,4U,8U,1U));
 else if(mode==1U)assert(!XE_NP_Grid16Pool_AcquireAppend(NULL,0U,4U,1U));
 else if(mode==2U)assert(!XE_NP_Grid16Pool_AcquireAppend(NULL,4U,0U,1U));
 else assert(!XE_NP_Grid16Pool_AcquireAppend(NULL,0U,0U,1U));
 assert(XE_NP_Grid16Pool_AppendFault(NULL));
 if(mode==1U || mode==2U)assert(TestPool_ActiveCount()==1U && !TestPool_CommittedCount());
 puts("PASS bad ticket/parent latches fault without retagging");
}
static void append_capacity(void)
{
 TailRuntime_Begin(60U,0U);assert(XE_NP_Grid16Pool_InitAppend(1U));const uint8_t *p[5];
 for(uint32_t i=0U;i<4U;i++){p[i]=XE_NP_Grid16Pool_AcquireAppend(NULL,4U*i,4U*i,1U);assert(p[i]);}
 assert(!XE_NP_Grid16Pool_AcquireAppend(NULL,16U,16U,1U) && !XE_NP_Grid16Pool_AppendFault(NULL));
 XE_NP_Grid16Pool_ReleaseAppend(NULL,0U,0U,p[0]);XE_NP_Grid16Pool_CommitAppend(NULL,0U,1U,0U);
 p[4]=XE_NP_Grid16Pool_AcquireAppend(NULL,16U,16U,1U);assert(p[4]);
 for(uint32_t i=1U;i<5U;i++)XE_NP_Grid16Pool_ReleaseAppend(NULL,4U*i,4U*i,p[i]);
 XE_NP_Grid16Pool_CommitAppend(NULL,4U,4U,0U);XE_NP_Grid16Pool_SourceStopped(NULL,20U);
 XE_NP_Grid16Footer f;assert(TailRuntime_Footer(20U,&f) && f.observed==60U && !XE_NP_Grid16Pool_AppendFault(NULL));
 puts("PASS four-stage busy is transient and next ticket stays in order");
}
static void append_wrong_commit(void)
{
 TailRuntime_Begin(24U,0U);assert(XE_NP_Grid16Pool_InitAppend(1U));
 const uint8_t *a=XE_NP_Grid16Pool_AcquireAppend(NULL,0U,0U,1U),*b=XE_NP_Grid16Pool_AcquireAppend(NULL,4U,8U,1U);assert(a&&b);
 XE_NP_Grid16Pool_ReleaseAppend(NULL,0U,0U,a);XE_NP_Grid16Pool_ReleaseAppend(NULL,4U,8U,b);
 XE_NP_Grid16Pool_CommitAppend(NULL,4U,1U,0U);
 assert(TestPool_ActiveCount()==2U && !TestPool_CommittedCount());
 assert(!XE_NP_Grid16Pool_AcquireAppend(NULL,8U,4U,1U));
 XE_NP_Grid16Pool_SourceStopped(NULL,8U);XE_NP_Grid16Footer f;assert(!TailRuntime_Footer(8U,&f));
 puts("PASS out-of-order commit faults without releasing claimed stage");
}
static void append_bad_release(void)
{
 TailRuntime_Begin(12U,0U);assert(XE_NP_Grid16Pool_InitAppend(1U));
 const uint8_t *a=XE_NP_Grid16Pool_AcquireAppend(NULL,0U,0U,1U);assert(a);
 XE_NP_Grid16Pool_ReleaseAppend(NULL,0U,4U,a);
 XE_NP_Grid16Pool_CommitAppend(NULL,0U,1U,0U);
 assert(TestPool_ActiveCount()==1U && !TestPool_CommittedCount());
 XE_NP_Grid16Pool_SourceStopped(NULL,4U);XE_NP_Grid16Footer f;assert(!TailRuntime_Footer(4U,&f));
 puts("PASS wrong-parent release faults without committing claimed stage");
}
static void append_partial_commit(void)
{
 TailRuntime_Begin(24U,0U);assert(XE_NP_Grid16Pool_InitAppend(1U));
 const uint8_t *a=XE_NP_Grid16Pool_AcquireAppend(NULL,0U,0U,1U),*b=XE_NP_Grid16Pool_AcquireAppend(NULL,4U,4U,1U);assert(a&&b);
 XE_NP_Grid16Pool_ReleaseAppend(NULL,0U,0U,a);XE_NP_Grid16Pool_CommitAppend(NULL,0U,2U,0U);
 assert(XE_NP_Grid16Pool_AppendFault(NULL) && TestPool_ActiveCount()==2U && !TestPool_CommittedCount());
 puts("PASS failed second-owner commit changes no earlier owner or count");
}
static void append_unavailable(void)
{
 TailRuntime_Begin(0U,1U);assert(XE_NP_Grid16Pool_InitAppend(1U));
 const uint8_t *a=XE_NP_Grid16Pool_AcquireAppend(NULL,0U,0U,1U);assert(a && !TailRuntime_Observed(a,3U));
 assert(!XE_NP_Grid16Pool_AppendFault(NULL));
 XE_NP_Grid16Pool_ReleaseAppend(NULL,0U,0U,a);XE_NP_Grid16Pool_CommitAppend(NULL,0U,1U,0U);
 XE_NP_Grid16Pool_SourceStopped(NULL,4U);XE_NP_Grid16Footer f;assert(TailRuntime_Footer(4U,&f) && f.empty==1U && (f.flags&4U));
 puts("PASS unavailable optional AUX seals empty without structural fault");
}
static void append_stop_bad_ticket(void)
{
 TailRuntime_Begin(12U,0U);assert(XE_NP_Grid16Pool_InitAppend(1U));
 const uint8_t *a=XE_NP_Grid16Pool_AcquireAppend(NULL,0U,8U,1U);assert(a);
 uint32_t minimum=0U;assert(!XE_NP_Grid16Pool_PrepareStopAppend(NULL,0U,32U,&minimum));
 assert(TestPool_ActiveCount()==1U && !TestPool_CommittedCount());
 XE_NP_Grid16Pool_ReleaseAppend(NULL,0U,8U,a);XE_NP_Grid16Pool_CommitAppend(NULL,0U,1U,0U);
 XE_NP_Grid16Pool_SourceStopped(NULL,4U);XE_NP_Grid16Footer f;assert(TailRuntime_Footer(4U,&f) && (f.flags&4U));
 puts("PASS bad first-unacquired Stop preserves NP and flags AUX uncertainty");
}
static void append_failed_partial(void)
{
 TailRuntime_Begin(24U,0U);assert(XE_NP_Grid16Pool_InitAppend(2U));TestPool_SetFault(1U);
 const uint8_t *a=XE_NP_Grid16Pool_AcquireAppend(NULL,0U,0U,2U);assert(a);
 assert(!XE_NP_Grid16Pool_AppendFault(NULL));
 assert(TailRuntime_Observed(a,3U)==12U && !TailRuntime_Observed(a+512U,3U));
 assert(XE_NP_Grid16Pool_AcquireAppend(NULL,0U,0U,2U)==a);TestPool_SetFault(0U);
 const uint8_t *b=XE_NP_Grid16Pool_AcquireAppend(NULL,4U,4U,2U);assert(b && TailRuntime_Observed(b,7U)==12U);
 XE_NP_Grid16Pool_ReleaseAppend(NULL,0U,0U,a);XE_NP_Grid16Pool_ReleaseAppend(NULL,4U,4U,b);
 XE_NP_Grid16Pool_CommitAppend(NULL,0U,2U,0U);XE_NP_Grid16Pool_SourceStopped(NULL,8U);
 XE_NP_Grid16Footer f;assert(TailRuntime_Footer(8U,&f));assert(f.observed==24U && f.nonempty==2U && f.empty==2U && (f.flags&4U));
 puts("PASS failed partial claim retains rows and pads honestly with AUX quality flag");
}
static void append_stop(uint32_t partial)
{
 TailRuntime_Begin(partial?3U:17U,0U);assert(XE_NP_Grid16Pool_InitAppend(1U));
 if(partial)assert(XE_NP_Grid16Pool_SetPartialWindow(4U));
 const uint8_t *a=XE_NP_Grid16Pool_AcquireAppend(NULL,0U,8U,1U);assert(a);
 if(partial){assert(!TailRuntime_Observed(a,11U));const uint8_t *b=XE_NP_Grid16Pool_AcquireAppend(NULL,4U,0U,1U);assert(b&&TailRuntime_Observed(b,3U)==3U);
  XE_NP_Grid16Pool_ReleaseAppend(NULL,0U,8U,a);XE_NP_Grid16Pool_ReleaseAppend(NULL,4U,0U,b);XE_NP_Grid16Pool_CommitAppend(NULL,0U,2U,0U);
  XE_NP_Grid16Pool_SourceStopped(NULL,8U);XE_NP_Grid16Footer f;assert(TailRuntime_Footer(8U,&f));assert(f.observed==3U);puts("PASS finite physical partial window");return;
 }
 uint32_t minimum=0U;assert(XE_NP_Grid16Pool_PrepareStopAppend(NULL,4U,32U,&minimum));assert(minimum>=4U && !(minimum&3U));
 assert(XE_NP_Grid16Pool_AcquireAppend(NULL,0U,8U,1U)==a);
 XE_NP_Grid16Pool_ReleaseAppend(NULL,0U,8U,a);XE_NP_Grid16Pool_CommitAppend(NULL,0U,1U,0U);
 XE_NP_Grid16Pool_SourceStopped(NULL,minimum);
 for(uint32_t t=4U;t<minimum;t+=4U){const uint8_t *p=XE_NP_Grid16Pool_AcquireAppend(NULL,t,t-4U,1U);assert(p);XE_NP_Grid16Pool_ReleaseAppend(NULL,t,t-4U,p);XE_NP_Grid16Pool_CommitAppend(NULL,t,1U,0U);}
 XE_NP_Grid16Footer f;assert(TailRuntime_Footer(minimum,&f));assert(f.observed==17U);puts("PASS manual stop budgets physical tickets");
}
'''
fixture=fixture.replace(marker,cases+marker+'''
 if(argc==2 && !strcmp(argv[1],"append-order")){append_order();return 0;}
 if(argc==2 && !strcmp(argv[1],"append-wrong-commit")){append_wrong_commit();return 0;}
 if(argc==2 && !strcmp(argv[1],"append-bad-release")){append_bad_release();return 0;}
 if(argc==2 && !strcmp(argv[1],"append-partial-commit")){append_partial_commit();return 0;}
 if(argc==2 && !strcmp(argv[1],"append-unavailable")){append_unavailable();return 0;}
 if(argc==2 && !strcmp(argv[1],"append-stop-bad-ticket")){append_stop_bad_ticket();return 0;}
 if(argc==2 && !strcmp(argv[1],"append-capacity")){append_capacity();return 0;}
 if(argc==2 && !strncmp(argv[1],"append-bad-claim-",17)){append_bad_claim((uint32_t)atoi(argv[1]+17));return 0;}
 if(argc==2 && !strcmp(argv[1],"append-partial-fault")){append_failed_partial();return 0;}
 if(argc==2 && !strcmp(argv[1],"append-manual")){append_stop(0U);return 0;}
 if(argc==2 && !strcmp(argv[1],"append-finite")){append_stop(1U);return 0;}
''')
(out/'fixture.c').write_text(fixture)
args=[]
for arg in json.loads((native/'receipt.json').read_text())['argv']:
 if arg==str(native/'actual_grid16_fixture.c'):arg=str(out/'fixture.c')
 elif arg==str(native/'actual_pool.c'):arg=str(pool_file)
 elif arg.startswith('/Fo'):arg='/Fo'+str(out)+'\\'
 elif arg.startswith('/Fe'):arg='/Fe'+str(out/'fixture.exe')
 args.append(arg)
args[1:1]=['/FI'+str(out.parent/'grid16_append_metadata/Core/Inc/xe_np_np2_grid16_meta.h'),'/I'+str(out/'Core/Inc'),'/I'+str(out.parent/'grid16_append_metadata/Core/Inc')]
vc=Path('C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat')
p=subprocess.run('call "'+str(vc)+'" >nul && '+subprocess.list2cmdline(args),shell=True,cwd=out,text=True,capture_output=True)
(out/'compile.log').write_text(p.stdout+p.stderr)
if p.returncode:raise RuntimeError('compile failed')
results=[]
for name in ('append-order','append-wrong-commit','append-bad-release','append-partial-commit','append-unavailable','append-stop-bad-ticket','append-partial-fault','append-manual','append-finite','append-capacity',
             'append-bad-claim-0','append-bad-claim-1','append-bad-claim-2','append-bad-claim-3',
             'tail-pool-capacity','tail-budget-1-24-0-0','tail-cached-budget','tail-finite-3'):
 p=subprocess.run([str(out/'fixture.exe'),name],cwd=out,text=True,capture_output=True,timeout=30)
 (out/(name+'.log')).write_text(p.stdout+p.stderr)
 results.append({'case':name,'exit':p.returncode,'stdout':p.stdout});print(results[-1],flush=True)
 if p.returncode:raise RuntimeError('case failed: '+name)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
(out/'receipt.json').write_text(json.dumps({'cases':results,'pool_source':sha(out/'Core/Src/xe_np_np2_grid16_pool.c'),'pool_header':sha(out/'Core/Inc/xe_np_np2_grid16_pool.h'),'scope':'isolated native pool/provider; no firmware build or hardware'},indent=2))
