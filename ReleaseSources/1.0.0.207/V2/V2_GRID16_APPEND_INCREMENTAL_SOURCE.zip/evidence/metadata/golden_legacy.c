#include "xe_np_np2_grid16_meta.h"
#include <stdint.h>
#include <stdio.h>
#include <string.h>
int main(int argc,char **argv){
 static const uint32_t masks[]={1U,3U,7U}, rates[]={7500U,15000U,20000U,30000U}, schemas[]={0U,1U,2U};
 if(argc!=2)return 2;FILE *file=fopen(argv[1],"wb");if(!file)return 3;
 for(unsigned i=0;i<3;i++)for(unsigned j=0;j<4;j++)for(unsigned s=0;s<3;s++)for(unsigned c=0;c<2;c++){
  uint8_t d[512],f[512];XE_NP_Grid16Meta m={0};XE_NP_Grid16Footer x={0};
  m.session=17U;m.mask=masks[i];m.sample_hz=rates[j];m.base=11U;m.reservation_start=8192U;
  m.payload_start=16384U;m.max_groups=2U;m.payload_end=16384U+2U*(364U+XE_NP_Grid16_K(m.mask,m.sample_hz));
  m.reservation_end=32768U;m.card_blocks=65536U;m.config_crc=919U;m.cid[0]=0x12345678U;
  m.schema=schemas[s];m.cl_enabled=c;m.cl_crc=c?55U:0U;
  x.state=3U;x.np_blocks=8U;x.empty=2U*XE_NP_Grid16_K(m.mask,m.sample_hz);x.final_exclusive=UINT64_MAX;
  if(schemas[s]!=1U){x.unpersisted_rows=12345U;x.pending_rows_unknown=1U;}
  if(XE_NP_Grid16_EncodeDescriptor(d,&m)||XE_NP_Grid16_EncodeFooter(f,d,&x))return 4;
  if(fwrite(d,1,512,file)!=512 || fwrite(f,1,512,file)!=512)return 5;
 }
 return fclose(file)?6:0;
}
