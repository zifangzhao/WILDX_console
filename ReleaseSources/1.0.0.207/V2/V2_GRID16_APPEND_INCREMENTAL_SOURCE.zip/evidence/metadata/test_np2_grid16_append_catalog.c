#define main legacy_catalog_main
#include "../V2SdLogger/tests/test_np2_dual_sd_catalog.c"
#undef main
#include "xe_np_np2_usb_wire.h"
static uint32_t data_begin,data_end,data_reads;
static int guard_read(void *u,uint32_t lba,uint8_t out[512])
{if(data_begin && lba>=data_begin && lba<data_end)data_reads++;return read_sector(u,lba,out);}
static void bind_guard(void){XE_NP_Np2DualSdCatalogIo io={0};io.read_sector=guard_read;io.write_sector=write_sector;
 io.stopped_command=command;io.card_blocks=card.capacity;io.cid[0]=1;io.cid[1]=2;io.cid[2]=3;io.cid[3]=4;
 assert(!XE_NP_Np2DualSdCatalog_Bind(&io));}
static XE_NP_Grid16Meta reserve(uint32_t schema){
 static const uint8_t system[512]="schema3 catalog test";uint32_t next;uint8_t config[2048]={0};XE_NP_Grid16Meta m;
 data_begin=data_end=data_reads=0;setup();bind_guard();assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
 assert(!XE_NP_Np2DualSdCatalog_Mount(&next)&&next==8192);
 memcpy(config,"N2SDCFG1",8);np_put32(config+8,1);np_put32(config+16,20000);np_put32(config+20,32000000);
 np_put32(config+24,7);np_put32(config+28,XE_NP_Np2UsbV3_WireMask(7));np_put32(config+32,6);
 np_put32(config+36,9);np_put32(config+40,46592);np_put32(config+44,16);
 for(uint32_t i=0;i<4;i++)np_put32(config+48+4*i,i+1);
 assert(!XE_NP_Np2DualSdCatalog_PlanGrid16(7,20000,16,77,crc32(config,2048),11,0,&m));
 assert(m.schema==0);m.schema=schema;assert(!XE_NP_Np2DualSdCatalog_ReserveGrid16(&m,config,NULL));
 data_begin=m.payload_start;data_end=m.payload_end;data_reads=0;return m;
}
static void test_failed_prefix(uint32_t known){
 XE_NP_Grid16Meta m=reserve(3);uint8_t d[512],f[512],directory[512];uint32_t next;int grid,cl;XE_NP_Grid16Footer x={0},decoded;
 assert(!read_sector(NULL,m.reservation_start+3,d)&&!read_sector(NULL,m.reservation_start+4,f));
 assert(!XE_NP_Grid16_DecodeFooter(d,f,&decoded,&grid,&cl)&&decoded.admitted_blocks==UINT32_MAX&&decoded.append_flags==0);
 x.state=4;x.error=9;x.np_blocks=8;x.empty=2;x.final_exclusive=UINT64_MAX;x.logical_prefix_blocks=4;
 x.logical_high_water_blocks=12;x.admitted_blocks=known?13:UINT32_MAX;x.append_flags=known?1:0;
 uint32_t writes=card.writes;x.logical_prefix_blocks=12;assert(XE_NP_Np2DualSdCatalog_FinishGrid16(&x));assert(card.writes==writes);
 x.logical_prefix_blocks=4;assert(!XE_NP_Np2DualSdCatalog_FinishGrid16(&x));
 assert(!read_sector(NULL,m.reservation_start+4,f));assert(!XE_NP_Grid16_DecodeFooter(d,f,&decoded,&grid,&cl));
 assert(decoded.np_blocks==8&&decoded.logical_prefix_blocks==4&&decoded.logical_high_water_blocks==12&&
        decoded.admitted_blocks==x.admitted_blocks&&decoded.append_flags==x.append_flags);
 assert(!read_sector(NULL,128,directory)&&get32(directory+4)==m.payload_start+2*365&&get32(directory+256)==m.payload_start+2*365);
 bind_guard();assert(!XE_NP_Np2DualSdCatalog_Mount(&next));assert(!(XE_NP_Np2DualSdCatalog_Status()&XE_NP_NP2_CATALOG_RECOVERY));
 assert(next==(m.payload_start+2*365+8191U)/8192U*8192U && data_reads==0);
 /* Simulate an older reservation fence at interrupted journal recovery: only
  * the strictly decoded sealed physical prefix may be published. */
 np_put32(directory+4,m.reservation_end);np_put32(directory+256,m.reservation_end);assert(!write_sector(NULL,128,directory));
 bind_guard();assert(!XE_NP_Np2DualSdCatalog_Mount(&next));assert((XE_NP_Np2DualSdCatalog_Status()&(XE_NP_NP2_CATALOG_RECOVERY|XE_NP_NP2_CATALOG_RECOVERABLE))==(XE_NP_NP2_CATALOG_RECOVERY|XE_NP_NP2_CATALOG_RECOVERABLE));
 assert(!XE_NP_Np2DualSdCatalog_Recover(&next));assert(next==(m.payload_start+2*365+8191U)/8192U*8192U);
 assert(!read_sector(NULL,128,directory)&&get32(directory+4)==m.payload_start+2*365&&data_reads==0);
 /* A directory extent inconsistent with every known fence is never silently shrunk. */
 np_put32(directory+4,m.payload_start+2*365+1);np_put32(directory+256,m.payload_start+2*365+1);
 assert(!write_sector(NULL,128,directory));bind_guard();assert(!XE_NP_Np2DualSdCatalog_MountAvailable(&next));
 assert((XE_NP_Np2DualSdCatalog_Status()&XE_NP_NP2_CATALOG_RECOVERY)!=0);
 assert((XE_NP_Np2DualSdCatalog_Status()&XE_NP_NP2_CATALOG_RECOVERABLE)==0&&data_reads==0);
 assert(!read_sector(NULL,m.reservation_start+4,f)&&!XE_NP_Grid16_DecodeFooter(d,f,&decoded,&grid,&cl)&&decoded.admitted_blocks==x.admitted_blocks);
}
static void test_complete_and_reserved(void){
 uint8_t d[512],f[512],directory[512];uint32_t next;int grid,cl;XE_NP_Grid16Footer x={0},decoded;XE_NP_Grid16Meta m=reserve(3);
 x.state=3;x.np_blocks=12;x.empty=3;x.final_exclusive=UINT64_MAX;
 x.logical_prefix_blocks=x.logical_high_water_blocks=x.admitted_blocks=12;x.append_flags=1;
 assert(!XE_NP_Np2DualSdCatalog_FinishGrid16(&x));assert(!read_sector(NULL,128,directory));
 assert(get32(directory+4)==m.payload_start+3*365);bind_guard();assert(!XE_NP_Np2DualSdCatalog_Mount(&next));assert(!XE_NP_Np2DualSdCatalog_Status()&&data_reads==0);
 /* Reserved with no sealed failed footer remains fenced: no recovered A
  * or phantom committed data is inferred from possible physical writes. */
 m=reserve(3);assert(!read_sector(NULL,m.reservation_start+3,d)&&!read_sector(NULL,m.reservation_start+4,f));
 assert(!XE_NP_Grid16_DecodeFooter(d,f,&decoded,&grid,&cl)&&decoded.admitted_blocks==UINT32_MAX);
 bind_guard();assert(!XE_NP_Np2DualSdCatalog_MountAvailable(&next));assert(next==m.reservation_end&&data_reads==0);
 /* Ordered schema2 failed fence is unchanged. */
 m=reserve(2);memset(&x,0,sizeof(x));x.state=4;x.error=9;x.np_blocks=8;x.empty=2;x.final_exclusive=UINT64_MAX;
 assert(!XE_NP_Np2DualSdCatalog_FinishGrid16(&x));assert(!read_sector(NULL,128,directory)&&get32(directory+4)==m.reservation_end);
}
int main(void){data_begin=data_end=0;legacy_catalog_main();test_failed_prefix(0);test_failed_prefix(1);test_complete_and_reserved();
 puts("PASS schema3 catalog complete/partial known+unknown A, durable physical-prefix recovery, reserved and schema2 fences; no payload scan");return 0;}
