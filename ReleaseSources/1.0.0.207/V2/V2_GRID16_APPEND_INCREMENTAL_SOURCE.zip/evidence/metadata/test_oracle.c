#include "xe_np_np2_grid16_meta.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
typedef struct {const char *name;int accept;} Case;
int main(int argc,char **argv){
 static const Case cases[]={
  {"complete_0_2_1",1},{"partial_0_2_known",1},{"partial_0_2_unknown",1},
  {"partial_leading_hole",1},{"partial_unsealed_admitted",1},
  {"bad_index_prefix",1},{"bad_index_high_water",0},{"duplicate_logical_group",1},
  {"bad_complete_coverage",0},{"bad_unknown_A_sentinel",0},{"bad_known_A_capacity",0},
  {"bad_reserved_404",0},{"bad_reserved_424",0},{"bad_schema2_order1",0},{"bad_crc",0}};
 if(argc!=2)return 2;
 for(unsigned i=0;i<sizeof(cases)/sizeof(cases[0]);i++){
  char path[1024];uint8_t d[512],f[512];FILE *file;XE_NP_Grid16Meta m;XE_NP_Grid16Footer result;int grid,cl;
  if(snprintf(path,sizeof(path),"%s/%s/descriptor.bin",argv[1],cases[i].name)<0)return 3;
  file=fopen(path,"rb");if(!file||fread(d,1,512,file)!=512)return 4;fclose(file);
  if(snprintf(path,sizeof(path),"%s/%s/footer.bin",argv[1],cases[i].name)<0)return 5;
  file=fopen(path,"rb");if(!file||fread(f,1,512,file)!=512)return 6;fclose(file);
  int accepted=!XE_NP_Grid16_DecodeDescriptor(d,&m)&&!XE_NP_Grid16_DecodeFooter(d,f,&result,&grid,&cl);
  if(accepted!=cases[i].accept){fprintf(stderr,"%s actual=%d expected=%d\n",cases[i].name,accepted,cases[i].accept);return 7;}
 }
 puts("PASS 15 independent oracle vectors: codec accepts metadata-consistent cases; index-only rejection remains host responsibility");
 return 0;
}
