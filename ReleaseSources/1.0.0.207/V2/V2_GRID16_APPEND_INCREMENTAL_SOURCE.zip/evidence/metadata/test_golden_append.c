#include "xe_np_np2_grid16_meta.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static void load(const char *path,uint8_t b[512]){FILE *f=fopen(path,"rb");assert(f&&fread(b,1,512,f)==512&&fgetc(f)==EOF);fclose(f);}
int main(int argc,char **argv){
 assert(argc==3);uint8_t d[512],f[512],encoded[512];XE_NP_Grid16Meta m;XE_NP_Grid16Footer x;int grid,cl;
 load(argv[1],d);load(argv[2],f);assert(!XE_NP_Grid16_DecodeDescriptor(d,&m));
 assert(m.schema==3&&m.mask==7&&m.sample_hz==20000&&m.max_groups==4);
 assert(!XE_NP_Grid16_DecodeFooter(d,f,&x,&grid,&cl)&&grid&&cl);
 assert(x.state==4&&x.error==9&&x.np_blocks==8&&x.logical_prefix_blocks==4&&
        x.logical_high_water_blocks==12&&x.admitted_blocks==13&&x.append_flags==1);
 assert(!XE_NP_Grid16_EncodeDescriptor(encoded,&m)&&!memcmp(d,encoded,512));
 assert(!XE_NP_Grid16_EncodeFooter(encoded,d,&x)&&!memcmp(f,encoded,512));
 puts("PASS independent schema3 partial 0/2 golden decode and exact re-encode");return 0;
}
