#include "xe_np_np2_grid16_pool.h"
#include "xe_np_np2_grid16_stage.h"
#include "xe_np_np2_first_sync_runtime.h"
#include "xe_np_np2_capture_port.h"
#include <string.h>

#if defined(_MSC_VER)
#define GRID_ALIGN32 __declspec(align(32))
#define GRID_STORAGE
#else
#define GRID_ALIGN32 __attribute__((aligned(32)))
#define GRID_STORAGE __attribute__((section("NP_GRID16_CPU")))
#endif

/* Stage ownership is retained through CMD13, even if IDMA BTC released the
 * bytes earlier. This lets retries reuse the same data and keeps the small
 * committed-count ledger separate from DMA completion. */
typedef struct {
    XE_NP_Grid16Stage stage;
    uint32_t first,active,released;
    GRID_ALIGN32 uint8_t sectors[5U*512U];
} PoolStage;
typedef struct {
    PoolStage slot[4];
    uint8_t scratch[480],phase[84];
    uint32_t k,generation,nonempty,empty,fault,source_stopped,finished;
    uint32_t stop_prepared,stop_unknown,stop_minimum,partial_first,append,aux_fault;
    uint64_t observed;
} Pool;
GRID_ALIGN32 static Pool pool GRID_STORAGE;

int XE_NP_Grid16Pool_Init(uint32_t k)
{
    if(k<1U || k>5U || (pool.k && !pool.finished))return 0;
    memset(&pool,0,sizeof(pool));pool.k=k;pool.partial_first=UINT32_MAX;return 1;
}
int XE_NP_Grid16Pool_InitAppend(uint32_t k)
{
    if(!XE_NP_Grid16Pool_Init(k))return 0;
    pool.append=1U;return 1;
}
int XE_NP_Grid16Pool_AppendFault(void *context)
{(void)context;return pool.append && pool.fault;}
int XE_NP_Grid16Pool_SetPartialWindow(uint32_t first)
{
    if(!pool.k || pool.finished || pool.nonempty || pool.empty || (first&3U))return 0;
    for(uint32_t i=0U;i<4U;i++)if(pool.slot[i].active)return 0;
    pool.partial_first=first;return 1;
}
int XE_NP_Grid16Pool_AbortPrepared(void)
{
    if(!pool.k || pool.finished || pool.source_stopped || pool.nonempty || pool.empty)return 0;
    for(uint32_t i=0;i<4U;i++)if(pool.slot[i].active)return 0;
    pool.finished=1U;return 1;
}
static uint32_t generation(void)
{
    XE_NP_AcquisitionAnchor a;
    if(!pool.generation && XE_NP_Np2CapturePort_GetAnchor(&a) && a.generation)
        pool.generation=a.generation;
    return pool.generation;
}
static const uint8_t *acquire(uint32_t first,uint32_t logical,uint32_t k,uint32_t append)
{
    PoolStage *s=NULL;uint32_t gen,type,bytes;uint64_t source;int r;
    if(!pool.k || (append && (pool.finished || pool.fault)) || pool.append!=append)return NULL;
    if(k!=pool.k){if(append)pool.fault=1U;return NULL;}
    /* Registration probe is only an alignment/ownership check, never data. */
    if(first==UINT32_MAX){if(logical==UINT32_MAX)return pool.slot[0].sectors;if(append)pool.fault=1U;return NULL;}
    if((first&3U) || first>UINT32_MAX-3U || (logical&3U) || logical>UINT32_MAX-3U ||
       (append && first>UINT32_MAX-4U)){if(append)pool.fault=1U;return NULL;}
    gen=generation();if(!gen){if(append)pool.fault=1U;return NULL;}
    for(uint32_t i=0;i<4U;i++){
        if(pool.slot[i].active && pool.slot[i].first==first){
            if(append && (pool.slot[i].stage.preceding!=(uint64_t)logical+3U || !pool.slot[i].stage.sealed)){pool.fault=1U;return NULL;}
            pool.slot[i].released=0U;return pool.slot[i].sectors;
        }
        if(!pool.slot[i].active && !s)s=&pool.slot[i];
    }
    if(append){
        uint64_t total=(uint64_t)pool.nonempty+pool.empty;
        if(total%k || total/k>UINT32_MAX/4U){pool.fault=1U;return NULL;}
        uint32_t next=(uint32_t)(total/k)*4U;
        for(uint32_t i=0U;i<4U;i++)if(pool.slot[i].active){
            PoolStage *owned=&pool.slot[i];
            if(!owned->stage.sealed || owned->stage.k!=k || owned->stage.generation!=gen ||
               owned->stage.preceding==(uint64_t)logical+3U){pool.fault=1U;return NULL;}
        }
        for(uint32_t n=0U;n<4U;n++){
            uint32_t matches=0U;
            for(uint32_t i=0U;i<4U;i++)matches+=pool.slot[i].active && pool.slot[i].first==next;
            if(matches>1U){pool.fault=1U;return NULL;}
            if(!matches)break;
            if(next>UINT32_MAX-4U){pool.fault=1U;return NULL;}
            next+=4U;
        }
        for(uint32_t i=0U;i<4U;i++)if(pool.slot[i].active && pool.slot[i].first>=next){pool.fault=1U;return NULL;}
        if(first!=next){pool.fault=1U;return NULL;}
    }
    if(!s)return NULL;
    if(!XE_NP_Grid16Stage_Init(&s->stage,s->sectors,sizeof(s->sectors),gen,(uint64_t)logical+3U,k)){
        if(append)pool.fault=1U;return NULL;
    }
    s->first=first;s->active=1U;s->released=0U;
    /* One phase and one terminal may accompany K data packets. No waiting. */
    for(uint32_t n=0;n<k+2U && s->stage.used<k;n++){
        r=first>=pool.partial_first?
            XE_NP_Np2FirstSyncRuntime_SdGridNextPartial(pool.scratch,sizeof(pool.scratch),&type,&bytes,&source):
            XE_NP_Np2FirstSyncRuntime_SdGridNext(pool.scratch,sizeof(pool.scratch),&type,&bytes,&source);
        if(r==0)break;
        if(r!=1){if(r<0){if(append)pool.aux_fault=1U;else pool.fault=1U;}break;}
        if(type==6U && bytes==sizeof(pool.phase)){
            memcpy(pool.phase,pool.scratch,sizeof(pool.phase));
            XE_NP_Np2FirstSyncRuntime_SdGridComplete(type,1U);
        }else if(type==5U && XE_NP_Grid16Stage_Add(&s->stage,pool.scratch,bytes)){
            XE_NP_Np2FirstSyncRuntime_SdGridComplete(type,1U);
        }else if(type==7U){
            XE_NP_Np2FirstSyncRuntime_SdGridComplete(type,1U);break;
        }else{
            XE_NP_Np2FirstSyncRuntime_SdGridComplete(type,0U);
            if(append)pool.aux_fault=1U;else pool.fault=1U;break;
        }
    }
    if(!XE_NP_Grid16Stage_Seal(&s->stage)){if(!append)s->active=0U;pool.fault=1U;return NULL;}
    return s->sectors;
}
const uint8_t *XE_NP_Grid16Pool_Acquire(void *context,uint32_t first,uint32_t k)
{(void)context;return acquire(first,first,k,0U);}
const uint8_t *XE_NP_Grid16Pool_AcquireAppend(void *context,uint32_t ticket,uint32_t logical,uint32_t k)
{(void)context;return acquire(ticket,logical,k,1U);}
void XE_NP_Grid16Pool_Release(void *context,uint32_t first,const uint8_t *sectors)
{
    (void)context;if(first==UINT32_MAX)return;
    if(pool.append){pool.fault=1U;return;}
    for(uint32_t i=0;i<4U;i++)if(pool.slot[i].active && pool.slot[i].first==first && pool.slot[i].sectors==sectors){pool.slot[i].released=1U;return;}
    pool.fault=1U;
}
void XE_NP_Grid16Pool_ReleaseAppend(void *context,uint32_t ticket,uint32_t logical,const uint8_t *sectors)
{
    (void)context;if(ticket==UINT32_MAX && logical==UINT32_MAX)return;
    if(pool.append)for(uint32_t i=0U;i<4U;i++){
        PoolStage *s=&pool.slot[i];
        if(s->active && s->first==ticket && s->stage.preceding==(uint64_t)logical+3U && s->sectors==sectors){s->released=1U;return;}
    }
    pool.fault=1U;
}
void XE_NP_Grid16Pool_Commit(void *context,uint32_t first,uint32_t groups,uint32_t end)
{
    (void)context;(void)end;
    if(pool.append){pool.fault=1U;return;}
    for(uint32_t n=0;n<groups;n++){
        PoolStage *s=NULL;uint32_t ordinal=first+4U*n;
        for(uint32_t i=0;i<4U;i++)if(pool.slot[i].active && pool.slot[i].first==ordinal){s=&pool.slot[i];break;}
        if(!s || !s->released || UINT32_MAX-pool.nonempty<s->stage.used ||
           UINT32_MAX-pool.empty<pool.k-s->stage.used || UINT64_MAX-pool.observed<s->stage.observed){pool.fault=1U;return;}
        pool.nonempty+=s->stage.used;pool.empty+=pool.k-s->stage.used;pool.observed+=s->stage.observed;s->active=0U;
    }
}
void XE_NP_Grid16Pool_CommitAppend(void *context,uint32_t ticket,uint32_t groups,uint32_t end)
{
    PoolStage *selected[4];uint64_t nonempty=pool.nonempty,empty=pool.empty,observed=pool.observed;
    uint64_t total=(uint64_t)pool.nonempty+pool.empty;(void)context;(void)end;
    if(!pool.append || pool.fault || !pool.k || !groups || groups>4U || total%pool.k ||
       total/pool.k>UINT32_MAX/4U || ticket!=(uint32_t)(total/pool.k)*4U ||
       ticket>UINT32_MAX-4U*groups){pool.fault=1U;return;}
    for(uint32_t n=0U;n<groups;n++){
        PoolStage *s=NULL;uint32_t ordinal=ticket+4U*n,matches=0U;
        for(uint32_t i=0U;i<4U;i++)if(pool.slot[i].active && pool.slot[i].first==ordinal){s=&pool.slot[i];matches++;}
        if(matches!=1U || s->released!=1U || !s->stage.sealed || s->stage.k!=pool.k ||
           s->stage.sectors!=s->sectors || s->stage.generation!=pool.generation ||
           (s->stage.preceding&3U)!=3U || s->stage.preceding>UINT32_MAX || s->stage.used>pool.k ||
           UINT64_MAX-observed<s->stage.observed){pool.fault=1U;return;}
        nonempty+=s->stage.used;empty+=pool.k-s->stage.used;observed+=s->stage.observed;
        if(nonempty>UINT32_MAX || empty>UINT32_MAX){pool.fault=1U;return;}
        selected[n]=s;
    }
    pool.nonempty=(uint32_t)nonempty;pool.empty=(uint32_t)empty;pool.observed=observed;
    for(uint32_t n=0U;n<groups;n++)selected[n]->active=0U;
}
void XE_NP_Grid16Pool_SourceStopped(void *context,uint32_t final_np_block)
{
    (void)context;(void)final_np_block;
    if(!pool.source_stopped){XE_NP_Np2FirstSyncRuntime_Stop();pool.source_stopped=1U;}
}
int XE_NP_Grid16Pool_PrepareStop(void *context,uint32_t first,uint32_t maximum,uint32_t *minimum)
{
    uint32_t packets=0U,count=0U;uint64_t base,total;XE_NP_AcquisitionAnchor anchor;(void)context;
    if(!minimum || !pool.k || pool.finished)return 0;
    if(pool.stop_prepared){
        if(!pool.stop_unknown && ((first&3U) || (maximum&3U) || first>maximum ||
           pool.stop_minimum>maximum || !XE_NP_Np2CapturePort_GetAnchor(&anchor) ||
           anchor.generation!=pool.generation))pool.stop_unknown=1U;
        *minimum=pool.stop_minimum;return !pool.stop_unknown;
    }
    pool.stop_prepared=1U;pool.stop_minimum=first;pool.stop_unknown=1U;
    /* This stops only the IMU timer/provider. SourceStopped is a later, true
     * NP-quiescence event; never freeze NP's clock or gate here. */
    if(!XE_NP_Np2FirstSyncRuntime_SdGridPrepareStop(&packets))return 0;
    if((first&3U) || (maximum&3U) || first>maximum ||
       !XE_NP_Np2CapturePort_GetAnchor(&anchor) || !anchor.generation ||
       (pool.generation && pool.generation!=anchor.generation))return 0;
    if(!pool.generation)pool.generation=anchor.generation;
    total=(uint64_t)pool.nonempty+pool.empty;
    if(total%pool.k || total/pool.k>UINT32_MAX/4U)return 0;
    base=total/pool.k*4U;
    if(base>first)return 0;
    /* Active sealed stages must be one unique prefix after durable groups.
     * They cannot be repacked, and an arbitrary max(first) could hide a gap. */
    for(uint32_t i=0U;i<4U;i++)if(pool.slot[i].active){
        PoolStage *s=&pool.slot[i];
        if(s->active!=1U || s->released>1U || (s->first&3U) || s->first>UINT32_MAX-4U ||
           s->stage.sectors!=s->sectors || !s->stage.sealed || s->stage.k!=pool.k ||
           s->stage.generation!=pool.generation ||
           (pool.append?((s->stage.preceding&3U)!=3U || s->stage.preceding>UINT32_MAX):
                        s->stage.preceding!=(uint64_t)s->first+3U) ||
           s->stage.used>pool.k)return 0;
        count++;
    }
    for(uint32_t n=0U;n<count;n++){
        uint32_t matches=0U;
        for(uint32_t i=0U;i<4U;i++)matches+=pool.slot[i].active && pool.slot[i].first==base;
        if(matches!=1U)return 0;
        base+=4U;
    }
    if(pool.append ? base!=first : base<first)return 0;
    uint64_t groups=((uint64_t)packets+pool.k-1U)/pool.k;
    uint64_t end=base+groups*4U;
    if(end>maximum)return 0;
    pool.stop_minimum=(uint32_t)end;pool.stop_unknown=0U;*minimum=(uint32_t)end;return 1;
}
int XE_NP_Grid16Pool_PrepareStopAppend(void *context,uint32_t first,uint32_t maximum,uint32_t *minimum)
{if(!pool.append)return 0;return XE_NP_Grid16Pool_PrepareStop(context,first,maximum,minimum);}
int XE_NP_Grid16Pool_Finish(XE_NP_Grid16Footer *footer)
{
    XE_NP_Np2SdGridStatus status={0};uint64_t misses;
    if(!footer || pool.fault || !pool.source_stopped || (footer->np_blocks&3U) ||
       ((uint64_t)footer->np_blocks/4U)*pool.k!=(uint64_t)pool.nonempty+pool.empty)return 0;
    for(uint32_t i=0;i<4U;i++)if(pool.slot[i].active)return 0;
    XE_NP_Np2FirstSyncRuntime_SdGridStatus(&status);
    footer->nonempty=pool.nonempty;footer->empty=pool.empty;footer->observed=pool.observed;
    footer->final_exclusive=UINT64_MAX;footer->flags=0U;
    footer->queue_drops=status.queue_dropped;
    misses=status.scheduler_missing>UINT64_MAX-status.discarded_prefix?UINT64_MAX:
        status.scheduler_missing+status.discarded_prefix;
    footer->scheduler_misses=misses>=UINT32_MAX?UINT32_MAX:(uint32_t)misses;
    if(footer->queue_drops==UINT32_MAX || footer->scheduler_misses==UINT32_MAX)footer->flags|=2U;
    /* Padding from a healthy, attached provider is an honest empty group.
     * A provider that never attached or became incomplete is different: keep
     * the already card-confirmed NN groups, but make that condition visible
     * in the Grid16 footer rather than presenting it as a healthy empty tail. */
    if(pool.stop_unknown || pool.aux_fault || status.incomplete || !status.available || status.fault || status.counter_faults ||
       status.scheduler_faults || status.late_copies || status.discarded_prefix)footer->flags|=4U;
    memcpy(footer->phase,pool.phase,sizeof(pool.phase));
    pool.finished=1U;return 1;
}
