#include "xe_np_np2_grid16_meta.h"
#include "xe_np_np2_dual_sd_meta.h"
#include "xe_np_np2_usb_wire.h"
#include "np_imu_grid_phase.h"
#include <string.h>

static uint32_t u32(const uint8_t *p){return np_imu_grid_phase_u32(p);}
static uint64_t u64(const uint8_t *p){return np_imu_grid_phase_u64(p);}
static void p32(uint8_t *p,uint32_t v){np_imu_grid_phase_put32(p,v);}
static void p64(uint8_t *p,uint64_t v){np_imu_grid_phase_put64(p,v);}
static int zero(const uint8_t *p,unsigned n){while(n--)if(*p++)return 0;return 1;}
static void seal(uint8_t *p){p32(p+508,XE_NP_Np2DualSd_Crc32(p,508));}
static uint64_t up(uint64_t n,uint32_t a){return ((n+a-1U)/a)*a;}
uint32_t XE_NP_Grid16_K(uint32_t m,uint32_t hz)
{
    if(!XE_NP_Np2DualSd_ProfileTicks(m,hz))return 0U;
    if(m==1U)return hz==7500U?5U:hz==15000U?3U:2U;
    if(m==3U)return hz==7500U?3U:hz==15000U?2U:1U;
    return hz==7500U?2U:1U;
}
static int geometry(const XE_NP_Grid16Meta *m)
{
    static const uint32_t legacy[]={2048,4096,8192,16384,24576,32768,49152,65536,131072};
    if(!m || !m->session || !XE_NP_Grid16_K(m->mask,m->sample_hz) ||
       m->cl_enabled>1U || m->schema>3U || (!m->cl_enabled && m->cl_crc) || !m->max_groups ||
       m->max_groups>UINT32_MAX/4U || m->reservation_start<8192U ||
       m->reservation_start%8192U || m->reservation_end%16384U ||
       m->reservation_end>m->card_blocks)return 0;
    uint64_t start=up((uint64_t)m->reservation_start+8192U,16384U);
    if(m->base==11U){if(m->au)return 0;}
    else if(m->base==12U){if(m->au<1024U || m->au%1024U)return 0;start=up(start,m->au);}
    else if(m->base==13U){
        unsigned i;for(i=0;i<sizeof(legacy)/sizeof(legacy[0]) && legacy[i]!=m->au;i++);
        if(i==sizeof(legacy)/sizeof(legacy[0]))return 0;start=up(start,m->au);
    }else return 0;
    uint64_t end=start+(uint64_t)m->max_groups*(364U+XE_NP_Grid16_K(m->mask,m->sample_hz));
    uint64_t alloc=up(m->au?up(end,m->au):end,16384U);
    if(start>UINT32_MAX || end>UINT32_MAX || alloc>UINT32_MAX ||
       start!=m->payload_start || end!=m->payload_end || alloc!=m->reservation_end ||
       end>m->card_blocks)return 0;
    if(m->base==12U && (start/1024U>0x3fffffU || (up(end,m->au)-m->au)/1024U>0x3fffffU))return 0;
    return 1;
}
int XE_NP_Grid16_EncodeDescriptor(uint8_t out[512],const XE_NP_Grid16Meta *m)
{
    if(!out || !geometry(m))return -1;
    uint8_t b[512]={0};memcpy(b,"N2SDLOG1",8);p32(b+8,16);p32(b+12,m->session);
    p32(b+16,m->sample_hz);p32(b+20,m->sample_hz*1600U);p32(b+24,m->mask);
    p32(b+28,XE_NP_Np2UsbV3_WireMask(m->mask));p32(b+32,m->mask==7U?6U:4U);
    p32(b+36,m->mask==1U?3U:m->mask==3U?6U:9U);p32(b+40,46592U);
    p32(b+44,XE_NP_Np2DualSd_ProfileTicks(m->mask,m->sample_hz));p32(b+48,91);p32(b+52,4);
    p32(b+56,m->reservation_start);p32(b+60,m->payload_start);p32(b+64,m->payload_end);
    p32(b+68,m->reservation_end);p32(b+72,m->card_blocks);p32(b+76,m->config_crc);
    for(unsigned i=0;i<4;i++)p32(b+80+4*i,m->cid[i]);
    p32(b+96,(m->base==11U?15U:m->base==12U?31U:47U)|(m->cl_enabled?128U:0U));
    p32(b+100,1U);p32(b+128,m->au);
    if(m->cl_enabled){p32(b+132,m->cl_crc);p32(b+136,m->base);p32(b+140,0x314d4c43U);}
    memcpy(b+208,"N2GRP016",8);p32(b+216,m->schema?m->schema:2U);p32(b+220,m->base);p32(b+224,m->schema==3U?1U:0U);
    p32(b+228,XE_NP_Grid16_K(m->mask,m->sample_hz));p32(b+232,364U+XE_NP_Grid16_K(m->mask,m->sample_hz));
    p32(b+236,4);p32(b+240,1);p32(b+244,2);p32(b+248,1250);seal(b);memcpy(out,b,512);return 0;
}
int XE_NP_Grid16_DecodeDescriptor(const uint8_t in[512],XE_NP_Grid16Meta *out)
{
    if(!in || !out || memcmp(in,"N2SDLOG1",8) || u32(in+8)!=16U ||
       u32(in+508)!=XE_NP_Np2DualSd_Crc32(in,508))return -1;
    XE_NP_Grid16Meta m={0};m.session=u32(in+12);m.sample_hz=u32(in+16);m.mask=u32(in+24);
    m.reservation_start=u32(in+56);m.payload_start=u32(in+60);m.payload_end=u32(in+64);
    m.reservation_end=u32(in+68);m.card_blocks=u32(in+72);m.config_crc=u32(in+76);
    for(unsigned i=0;i<4;i++)m.cid[i]=u32(in+80+4*i);
    m.base=u32(in+220);m.schema=u32(in+216);m.au=u32(in+128);
    if(m.schema!=1U && m.schema!=2U && m.schema!=3U)return -1;m.cl_enabled=(u32(in+96)&128U)!=0;
    m.cl_crc=m.cl_enabled?u32(in+132):0U;
    uint32_t k=XE_NP_Grid16_K(m.mask,m.sample_hz);
    if(!k || m.payload_end<=m.payload_start || (m.payload_end-m.payload_start)%(364U+k))return -1;
    m.max_groups=(m.payload_end-m.payload_start)/(364U+k);
    uint8_t expected[512];if(XE_NP_Grid16_EncodeDescriptor(expected,&m) || memcmp(expected,in,512))return -1;
    *out=m;return 0;
}
int XE_NP_Grid16_MatchesCard(const XE_NP_Grid16Meta *m,const uint32_t cid[4],uint32_t blocks)
{return m && cid && m->card_blocks==blocks && !memcmp(m->cid,cid,sizeof(m->cid));}
static int state_valid(uint32_t s,uint32_t e,uint32_t n)
{
    return (s==3U && n && !e) || (s==4U && e && (e!=XE_NP_NP2_DUAL_SD_META_CANCELLED_EMPTY || !n)) ||
           (s==1U && !n && e);
}
/* Metadata coverage is separate from acquisition/source continuity. */
static int append_valid(const XE_NP_Grid16Meta *m,const XE_NP_Grid16Footer *f)
{
    uint32_t p=f->logical_prefix_blocks,h=f->logical_high_water_blocks;
    uint32_t a=f->admitted_blocks,n=f->np_blocks,known=f->append_flags&1U;
    uint32_t cap=m->max_groups*4U;
    if((f->append_flags&~1U) || (p&3U) || (h&3U) || p>n || n>h || h>cap ||
       ((h==0U)!=(n==0U)))return 0;
    if(known){if(a<h || a>cap)return 0;}
    else if(a!=UINT32_MAX)return 0;
    if(f->state==3U && (!known || !n || p!=n || h!=n || a!=n))return 0;
    return 1;
}
static int cl_valid(const uint8_t *p,const XE_NP_Grid16Meta *m)
{
    if(!m->cl_enabled)return zero(p,64);
    if(zero(p,64))return 0;
    uint32_t attempted=u32(p+28),committed=u32(p+32),dropped=u32(p+36);
    return !memcmp(p,"NPCLEND1",8) && u32(p+8)==1U && u32(p+12)==64U &&
      u32(p+16)==m->session && u32(p+20)==m->cl_crc && u32(p+24) &&
      (u32(p+52)&1U) && !(u32(p+52)&~7U) && !u32(p+56) &&
      u32(p+60)==XE_NP_Np2DualSd_Crc32(p,60) && u32(p+40)<=dropped &&
      u32(p+44)<=dropped && u32(p+48)<=attempted &&
      (attempted==UINT32_MAX || (uint64_t)committed+dropped==attempted);
}
static int grid_valid(const uint8_t *p,uint64_t sectors,uint32_t session)
{
    uint32_t flags=u32(p+272),q=u32(p+276),s=u32(p+280),n=u32(p+284),e=u32(p+372);
    uint64_t final=u64(p+376),observed=u64(p+384);NpImuGridPhaseRecord ph;
    if((flags&~7U) || ((flags&1U)!=0)!=(final!=UINT64_MAX) ||
       (((flags&2U)!=0)!=(q==UINT32_MAX || s==UINT32_MAX)) ||
       (uint64_t)n+e!=sectors || observed>(uint64_t)n*12U ||
       ((flags&1U) && observed>final))return 0;
    if(!zero(p+288,84) && (!np_imu_grid_phase_read(p+288,84,&ph) || ph.binding.session!=session))return 0;
    return 1;
}
int XE_NP_Grid16_EncodeFooter(uint8_t out[512],const uint8_t desc[512],const XE_NP_Grid16Footer *f)
{
    XE_NP_Grid16Meta m;if(!out || !f || XE_NP_Grid16_DecodeDescriptor(desc,&m) ||
      f->np_blocks%4U || f->np_blocks/4U>m.max_groups || !state_valid(f->state,f->error,f->np_blocks) ||
      f->pending_rows_unknown>1U || (m.schema==1U && (f->unpersisted_rows || f->pending_rows_unknown)) ||
      (m.schema==3U && !append_valid(&m,f)))return -1;
    uint32_t groups=f->np_blocks/4U,k=XE_NP_Grid16_K(m.mask,m.sample_hz);
    uint64_t physical=(uint64_t)groups*(364U+k),aux=(uint64_t)groups*k;
    uint8_t b[512];memcpy(b,desc,512);memcpy(b,"N2SDEND1",8);p32(b+100,f->state);p32(b+104,f->error);
    p32(b+108,f->np_blocks);p32(b+112,groups);p32(b+116,m.payload_start+(uint32_t)physical);
    p64(b+120,(uint64_t)f->np_blocks*XE_NP_Np2DualSd_ProfileTicks(m.mask,m.sample_hz));
    memset(b+132,0,76);memcpy(b+144,f->cl_summary,64);
    p64(b+256,physical);p64(b+264,aux);p32(b+272,f->flags);p32(b+276,f->queue_drops);
    p32(b+280,f->scheduler_misses);p32(b+284,f->nonempty);memcpy(b+288,f->phase,84);
    p32(b+372,f->empty);p64(b+376,f->final_exclusive);p64(b+384,f->observed);
    if(m.schema>=2U){p64(b+392,f->unpersisted_rows);p32(b+400,f->pending_rows_unknown);}
    if(m.schema==3U){p32(b+408,f->logical_prefix_blocks);p32(b+412,f->logical_high_water_blocks);
        p32(b+416,f->admitted_blocks);p32(b+420,f->append_flags);}
    if(!grid_valid(b,aux,m.session) || (!m.cl_enabled && !zero(f->cl_summary,64)) ||
       (m.cl_enabled && !zero(f->cl_summary,64) && !cl_valid(f->cl_summary,&m)))return -1;
    seal(b);memcpy(out,b,512);return 0;
}
int XE_NP_Grid16_DecodeFooter(const uint8_t desc[512],const uint8_t b[512],
                              XE_NP_Grid16Footer *out,int *grid_quality,int *cl_quality)
{
    XE_NP_Grid16Meta m;if(!b || !out || !grid_quality || !cl_quality ||
      XE_NP_Grid16_DecodeDescriptor(desc,&m) || memcmp(b,"N2SDEND1",8) ||
      u32(b+508)!=XE_NP_Np2DualSd_Crc32(b,508) || memcmp(b+8,desc+8,92) ||
      memcmp(b+208,desc+208,48) || u32(b+128)!=m.au || !zero(b+132,12) || (m.schema==1U && !zero(b+392,116)) ||
      (m.schema==3U && (!zero(b+404,4) || !zero(b+424,84))))return -1;
    uint32_t n=u32(b+108),g=u32(b+112),k=XE_NP_Grid16_K(m.mask,m.sample_hz);
    uint64_t physical=(uint64_t)g*(364U+k),aux=(uint64_t)g*k;
    if(n%4U || g!=n/4U || g>m.max_groups || !state_valid(u32(b+100),u32(b+104),n) ||
       u64(b+256)!=physical || u64(b+264)!=aux || (uint64_t)m.payload_start+physical!=u32(b+116) ||
       u64(b+120)!=(uint64_t)n*XE_NP_Np2DualSd_ProfileTicks(m.mask,m.sample_hz))return -1;
    XE_NP_Grid16Footer f={0};f.state=u32(b+100);f.error=u32(b+104);f.np_blocks=n;f.flags=u32(b+272);
    f.queue_drops=u32(b+276);f.scheduler_misses=u32(b+280);f.nonempty=u32(b+284);
    memcpy(f.phase,b+288,84);f.empty=u32(b+372);f.final_exclusive=u64(b+376);
    f.observed=u64(b+384);memcpy(f.cl_summary,b+144,64);
    if(m.schema>=2U){f.unpersisted_rows=u64(b+392);f.pending_rows_unknown=u32(b+400);}
    if(m.schema==3U){f.logical_prefix_blocks=u32(b+408);f.logical_high_water_blocks=u32(b+412);
        f.admitted_blocks=u32(b+416);f.append_flags=u32(b+420);if(!append_valid(&m,&f))return -1;}
    *grid_quality=grid_valid(b,aux,m.session) &&
      (m.schema==1U || (f.pending_rows_unknown<=1U && (m.schema==3U || zero(b+404,104))));*cl_quality=cl_valid(b+144,&m);*out=f;return 0;
}
