#ifndef XE_NP_NP2_GRID16_META_H
#define XE_NP_NP2_GRID16_META_H
#include <stdint.h>
#ifndef XE_NP_NP2_SD_GRID16_ENABLE
#define XE_NP_NP2_SD_GRID16_ENABLE 0U
#endif
#if XE_NP_NP2_SD_GRID16_ENABLE!=0U && XE_NP_NP2_SD_GRID16_ENABLE!=1U
#error "SD16 catalog support must be an explicit boolean"
#endif

/* Cold-path codec; group counts refer only to card-confirmed whole groups. */
typedef struct {
    uint32_t session, sample_hz, mask, reservation_start, payload_start;
    uint32_t payload_end, reservation_end, card_blocks, config_crc, cid[4];
    uint32_t base, au, max_groups, cl_enabled, cl_crc;
    uint32_t schema; /* 0 selects schema 2; 1/2 ordered, 3 indexed append. */
} XE_NP_Grid16Meta;
typedef struct {
    uint32_t state, error, np_blocks, flags, queue_drops, scheduler_misses;
    uint32_t nonempty, empty;
    uint64_t final_exclusive, observed;
    uint8_t phase[84], cl_summary[64];
    uint64_t unpersisted_rows; /* Known lower bound, not a complete loss count. */
    uint32_t pending_rows_unknown; /* 0 or 1. */
    /* Schema 3 only. A unknown is UINT32_MAX with bit0 clear. */
    uint32_t logical_prefix_blocks, logical_high_water_blocks;
    uint32_t admitted_blocks, append_flags;
} XE_NP_Grid16Footer;

uint32_t XE_NP_Grid16_K(uint32_t mask, uint32_t sample_hz);
int XE_NP_Grid16_EncodeDescriptor(uint8_t out[512], const XE_NP_Grid16Meta *meta);
int XE_NP_Grid16_DecodeDescriptor(const uint8_t in[512], XE_NP_Grid16Meta *meta);
/* Must match the freshly read card before using any extent for I/O. */
int XE_NP_Grid16_MatchesCard(const XE_NP_Grid16Meta *meta, const uint32_t cid[4], uint32_t card_blocks);
int XE_NP_Grid16_EncodeFooter(uint8_t out[512], const uint8_t descriptor[512],
                              const XE_NP_Grid16Footer *footer);
/* Zero means NP geometry valid. grid_quality means internal consistency only:
 * missing phase, grid faults and missing external source binding still require
 * separate checks. cl_quality means the CL summary is valid or not enabled. */
int XE_NP_Grid16_DecodeFooter(const uint8_t descriptor[512], const uint8_t footer[512],
                              XE_NP_Grid16Footer *out, int *grid_quality, int *cl_quality);
#endif
