#ifndef XE_NP_NP2_GRID16_POOL_H
#define XE_NP_NP2_GRID16_POOL_H
#include <stdint.h>
#include "xe_np_np2_grid16_meta.h"

/* Foreground-only SD16 provider. NP never waits for an AUX sample. */
int XE_NP_Grid16Pool_Init(uint32_t k);
/* Append tickets name physical groups; logical_first names the immutable NN parent. */
int XE_NP_Grid16Pool_InitAppend(uint32_t k);
/* Distinguish a latched structural provider error from transient busy/NULL. */
int XE_NP_Grid16Pool_AppendFault(void *context);
const uint8_t *XE_NP_Grid16Pool_AcquireAppend(void *context,uint32_t physical_ticket,uint32_t logical_first,uint32_t k);
void XE_NP_Grid16Pool_ReleaseAppend(void *context,uint32_t physical_ticket,uint32_t logical_first,const uint8_t *sectors);
void XE_NP_Grid16Pool_CommitAppend(void *context,uint32_t physical_ticket,uint32_t groups,uint32_t physical_end_lba);
int XE_NP_Grid16Pool_PrepareStopAppend(void *context,uint32_t first_unacquired_physical_ticket,
    uint32_t maximum_np_blocks,uint32_t *minimum_np_blocks);
/* Startup only: permit partial packet flush starting at this NP group. */
int XE_NP_Grid16Pool_SetPartialWindow(uint32_t first_np_block);
/* Before writer binding only; refuses any acquired group. */
int XE_NP_Grid16Pool_AbortPrepared(void);
const uint8_t *XE_NP_Grid16Pool_Acquire(void *context,uint32_t first_np_block,uint32_t k);
void XE_NP_Grid16Pool_Release(void *context,uint32_t first_np_block,const uint8_t *sectors);
void XE_NP_Grid16Pool_Commit(void *context,uint32_t first_np_block,uint32_t groups,uint32_t physical_end_lba);
void XE_NP_Grid16Pool_SourceStopped(void *context,uint32_t final_np_block);
int XE_NP_Grid16Pool_PrepareStop(void *context,uint32_t first_unacquired_np_block,
    uint32_t maximum_np_blocks,uint32_t *minimum_np_blocks);
int XE_NP_Grid16Pool_Finish(XE_NP_Grid16Footer *footer);
#endif
