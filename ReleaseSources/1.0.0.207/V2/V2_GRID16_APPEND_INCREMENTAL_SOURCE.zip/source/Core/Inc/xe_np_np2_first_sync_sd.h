#ifndef XE_NP_NP2_FIRST_SYNC_SD_H
#define XE_NP_NP2_FIRST_SYNC_SD_H

#include <stdint.h>

#ifndef XE_NP_NP2_FIRST_SYNC_ENABLE
#define XE_NP_NP2_FIRST_SYNC_ENABLE 0U
#endif
#ifndef NP_FINE_COUNTER64_ENABLE
#define NP_FINE_COUNTER64_ENABLE 0U
#endif
#ifndef XE_NP_NP2_SD_GRID16_ENABLE
#define XE_NP_NP2_SD_GRID16_ENABLE 0U
#endif

#ifndef XE_NP_NP2_SD_GRID16_APPEND_ENABLE
#define XE_NP_NP2_SD_GRID16_APPEND_ENABLE 0U
#endif

#if XE_NP_NP2_FIRST_SYNC_ENABLE
#include "np_first_sync_sd.h"

/* Caller-owned: no adapter-side request/ACK allocation.  `history` is the
 * immutable duplicate ACK; `current` is only the record eligible for STATUS
 * and later capture binding. */
typedef struct {
    uint8_t accepted[64],ack[64];
    uint64_t token;
    uint32_t nonce;
#if NP_FINE_COUNTER64_ENABLE
    uint32_t negotiated_version,negotiated_features;
#endif
    NpFirstSdReply current;
    uint8_t history_valid,current_valid,bridge_active,retired;
#if XE_NP_NP2_SD_GRID16_ENABLE && NP_FINE_COUNTER64_ENABLE
    uint8_t bridge_grid16;
#endif
} XE_NP_Np2FirstSyncSdContext;

/* Bind a zero-initialized caller-owned context.  Passing NULL leaves NPSD
 * unsupported; this adapter never creates a runtime provider by itself. */
void XE_NP_Np2FirstSyncSd_Bind(XE_NP_Np2FirstSyncSdContext *context);
/* Returns nonzero only when `in` is NPSD and `out` contains the matching NPSA. */
int XE_NP_Np2FirstSyncSd_Exchange(const uint8_t in[64],uint8_t out[64]);
/* SD control calls this after it has actually admitted an op2/op4 START. */
void XE_NP_Np2FirstSyncSd_AcceptedLegacyStart(uint32_t nonce);
/* A newer successfully admitted ordinary Stop retires only the live optional
 * association; the immutable duplicate ACK remains historical evidence. */
void XE_NP_Np2FirstSyncSd_AcceptedLegacyStop(uint32_t nonce);
/* Cancels only a pending optional association; captured metadata is retained. */
void XE_NP_Np2FirstSyncSd_CancelStart(uint32_t nonce);
/* Binds actual capture identity after the recorder has accepted this nonce. */
int XE_NP_Np2FirstSyncSd_Capture(uint32_t nonce,uint32_t session,uint32_t generation,
                                  uint32_t source_epoch,uint32_t profile_crc);
/* Read-only current association, including a retired captured record retained
 * for its footer. `retired` forbids any later Capture update. */
const NpFirstSdReply *XE_NP_Np2FirstSyncSd_Current(void);
/* Returns caller-owned immutable wrapper/token metadata while current exists. */
const XE_NP_Np2FirstSyncSdContext *XE_NP_Np2FirstSyncSd_Record(void);
#if NP_FINE_COUNTER64_ENABLE
/* True only while the live admitted v3 association selected continuity. */
uint32_t XE_NP_Np2FirstSyncSd_CurrentContinuity(void);
#endif
#if XE_NP_NP2_SD_GRID16_ENABLE && NP_FINE_COUNTER64_ENABLE
uint32_t XE_NP_Np2FirstSyncSd_BridgeGrid16(void);
uint32_t XE_NP_Np2FirstSyncSd_Grid16Start(uint32_t nonce);
uint32_t XE_NP_Np2FirstSyncSd_BridgeGrid16Append(void);
uint32_t XE_NP_Np2FirstSyncSd_Grid16AppendStart(uint32_t nonce);
#endif
#endif
#if !XE_NP_NP2_FIRST_SYNC_ENABLE || !XE_NP_NP2_SD_GRID16_ENABLE || !NP_FINE_COUNTER64_ENABLE
#define XE_NP_Np2FirstSyncSd_BridgeGrid16() 0U
#define XE_NP_Np2FirstSyncSd_Grid16Start(nonce) 0U
#define XE_NP_Np2FirstSyncSd_BridgeGrid16Append() 0U
#define XE_NP_Np2FirstSyncSd_Grid16AppendStart(nonce) 0U
#endif
#endif
