from pathlib import Path
h=Path(__file__).resolve().parent
header=h/'Core/Inc/xe_np_np2_live_sd.h';s=header.read_text()
marker='#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE\n/* Acquire supplies'
assert s.count(marker)==1
s=s.replace(marker,'#ifndef XE_NP_NP2_SD_GRID16_APPEND_ENABLE\n#define XE_NP_NP2_SD_GRID16_APPEND_ENABLE 0U\n#endif\nuint32_t XE_NP_Np2LiveSd_StoredBlocks(void);\n'+marker)
marker='    XE_NP_Np2LiveSdGrid16SourceStopped,XE_NP_Np2LiveSdGrid16PrepareStop,void *context);\n#endif'
api='''    XE_NP_Np2LiveSdGrid16SourceStopped,XE_NP_Np2LiveSdGrid16PrepareStop,void *context);
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
#include "xe_np_np2_grid16_meta.h"
typedef const uint8_t *(*XE_NP_Np2LiveSdGrid16AcquireAppend)(void *,uint32_t,uint32_t,uint32_t);
typedef void (*XE_NP_Np2LiveSdGrid16ReleaseAppend)(void *,uint32_t,uint32_t,const uint8_t *);
typedef int (*XE_NP_Np2LiveSdGrid16AppendFault)(void *);
int XE_NP_Np2LiveSd_InitExtentGrid16Append(SD_HandleTypeDef *,DCACHE_HandleTypeDef *,
    uint32_t start,uint32_t physical_end,uint32_t blocks,uint32_t mask,uint32_t rate,
    uint32_t aux_sectors,XE_NP_Np2LiveSdGrid16AcquireAppend,
    XE_NP_Np2LiveSdGrid16ReleaseAppend,XE_NP_Np2LiveSdGrid16AppendFault,
    XE_NP_Np2LiveSdGrid16Commit,XE_NP_Np2LiveSdGrid16SourceStopped,
    XE_NP_Np2LiveSdGrid16PrepareStop,void *context);
int XE_NP_Np2LiveSd_GetGrid16AppendCounts(XE_NP_Grid16Footer *footer);
#endif
#endif'''
assert s.count(marker)==1;s=s.replace(marker,api);header.write_text(s)
p=h/'Core/Src/xe_np_np2_live_sd.c';s=p.read_text()
def once(old,new,n=1):
 global s
 assert s.count(old)==n,(old[:100],s.count(old),n)
 s=s.replace(old,new)
once('    uint8_t requested,active,stop_prepared;','''    uint8_t requested,active,stop_prepared;
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
    XE_NP_Np2LiveSdGrid16AcquireAppend acquire_append;
    XE_NP_Np2LiveSdGrid16ReleaseAppend release_append;
    XE_NP_Np2LiveSdGrid16AppendFault append_fault;
    uint32_t pending_ticket;
    uint8_t append,pending,pending_groups,claimed_groups;
#endif''')
once('''            if(!aux || !grid16.release){fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0x47313601U|owner);return;}
            grid16.release(grid16.context,grid16.first_np_block[owner],aux);''','''            if(!aux){fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0x47313601U|owner);return;}
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
            if(grid16.append)
                grid16.release_append(grid16.context,grid16.pending_ticket+owner*BLOCKS_PER_RU,
                                      grid16.first_np_block[owner],aux);
            else
#endif
            {
                if(!grid16.release){fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0x47313601U|owner);return;}
                grid16.release(grid16.context,grid16.first_np_block[owner],aux);
            }''')
once('''               grid16.first_np_block[owner]!=(xe_np_np2_live_sd_mailbox.written_rus+owner)*BLOCKS_PER_RU ||
               ru_first_block[slot]!=grid16.first_np_block[owner])''','''#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
               (!grid16.append &&
#endif
               grid16.first_np_block[owner]!=(xe_np_np2_live_sd_mailbox.written_rus+owner)*BLOCKS_PER_RU
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
               )
#endif
               || ru_first_block[slot]!=grid16.first_np_block[owner])''')
marker='/* Return the first missing future group after the immutable accepted command'
once(marker,'#include "xe_np_np2_grid16_append.inc"\n\n'+marker)
# Move the shared final admission/launch code without changing its ordered path.
begin=s.index('    grid16.active=1U;dma_units=(uint8_t)groups;',s.index('static void grid16_start_write'))
end=s.index('\n}\n#endif\n\nstatic void start_write',begin)
tail=s[begin:end]
tail=tail.replace('grid16_release_acquired(first_ru,groups);','''
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
        if(!grid16.append)
#endif
        grid16_release_acquired(xe_np_np2_live_sd_mailbox.written_rus,groups);''')
tail=tail.replace('    dma_active=1U;dma_buffer_released=0U;','''#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
    grid16.pending=0U;
#endif
    dma_active=1U;dma_buffer_released=0U;''')
s=s[:begin]+'    grid16_launch(groups);'+s[end:]
launch='static void grid16_launch(uint32_t groups)\n{\n'+tail+'\n}\n\n'
pos=s.index('static void grid16_start_write(void)');s=s[:pos]+launch+s[pos:]
once('''    grid16_release_pending();
    if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED)return;
    while(groups<XE_NP_NP2_GRID16_GROUPS''','''    grid16_release_pending();
    if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED)return;
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
    if(grid16.append){
        int selected=grid16_append_select();
        if(selected<=0)return;
        groups=(uint32_t)selected;
        if(grid16_append_acquire(groups)!=1)return;
        if(XE_NP_Np2Grid16Idma_Build(grid16.physical_confirmed_lba,groups,
            grid16.aux_sectors,&grid16.plan) || grid16.plan.end_lba>record_end_lba){
            fail(XE_NP_NP2_LIVE_SD_ERROR_RANGE,0x47415008U);return;
        }
        grid16_launch(groups);return;
    }
#endif
    while(groups<XE_NP_NP2_GRID16_GROUPS''')
once('''        for(uint32_t owner=0U;owner<dma_units;owner++)
            if(grid16.first_np_block[owner]!=(xe_np_np2_live_sd_mailbox.written_rus+owner)*BLOCKS_PER_RU){''','''        for(uint32_t owner=0U;owner<dma_units;owner++)
            if(
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
               !grid16.append &&
#endif
               grid16.first_np_block[owner]!=(xe_np_np2_live_sd_mailbox.written_rus+owner)*BLOCKS_PER_RU){''')
once('''        grid16.commit(grid16.context,grid16.first_np_block[0],
                      dma_units,grid16.physical_confirmed_lba);''','''        grid16.commit(grid16.context,
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
                      grid16.append?grid16.pending_ticket:
#endif
                      grid16.first_np_block[0],dma_units,grid16.physical_confirmed_lba);''')
once('''        xe_np_np2_live_sd_mailbox.written_rus+=dma_units;
        grid16.active=0U;''','''#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
        if(grid16.append){
            dma_first_ru=grid16.first_np_block[0]/BLOCKS_PER_RU;
            dma_complete_units=dma_units;
            for(uint32_t owner=0U;owner<dma_units;owner++){
                uint32_t end=grid16.first_np_block[owner]+BLOCKS_PER_RU;
                if(end>append_logical_high_water_blocks)append_logical_high_water_blocks=end;
            }
            if(commit_overflow_order())return;
        }else
#endif
        xe_np_np2_live_sd_mailbox.written_rus+=dma_units;
        grid16.active=0U;''')
once('''static int grid16_copy_begin(void)
{
    uint32_t free_count''','''static int grid16_copy_begin(void)
{
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
    if(grid16.append)return grid16_append_copy_begin();
#endif
    uint32_t free_count''')
once('''        acquired=((uint64_t)xe_np_np2_live_sd_mailbox.written_rus+
                  (dma_active?dma_units:0U))*BLOCKS_PER_RU;
        if(acquired>active_target_blocks || (dma_active && !grid16.active))admitted=0;''','''        acquired=((uint64_t)xe_np_np2_live_sd_mailbox.written_rus+
                  (dma_active?dma_units:0U))*BLOCKS_PER_RU;
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
        if(grid16.append)acquired=(uint64_t)grid16_append_ticket()+
            (grid16.active?(uint32_t)dma_units*BLOCKS_PER_RU:
             grid16.pending?(uint32_t)grid16.claimed_groups*BLOCKS_PER_RU:0U);
#endif
        if(acquired>active_target_blocks || (dma_active && !grid16.active))admitted=0;''')
once('''        if(!grid16.acquire || !grid16.release || !grid16.commit || !grid16.source_stopped || !grid16.prepare_stop || !grid16.aux_sectors ||''','''        uint32_t callbacks=grid16.acquire && grid16.release;
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
        if(grid16.append)callbacks=grid16.acquire_append && grid16.release_append && grid16.append_fault;
#endif
        if(!callbacks || !grid16.commit || !grid16.source_stopped || !grid16.prepare_stop || !grid16.aux_sectors ||''')
once('''            if(!grid16.acquire || !grid16.release || !grid16.commit || !grid16.source_stopped || !grid16.prepare_stop)reason|=1U;''','''            if(!callbacks || !grid16.commit || !grid16.source_stopped || !grid16.prepare_stop)reason|=1U;''')
# Public new admission is deliberately separate; ordinary Init remains exact.
marker='\n#if XE_NP_NP2_SD_APPEND_ORDER_TEST\nint XE_NP_Np2LiveSd_InitExtentAppendProfile'
newapi='''
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
int XE_NP_Np2LiveSd_InitExtentGrid16Append(SD_HandleTypeDef *input,DCACHE_HandleTypeDef *input_cache,
    uint32_t start,uint32_t physical_end,uint32_t blocks,uint32_t mask,uint32_t rate,
    uint32_t aux_sectors,XE_NP_Np2LiveSdGrid16AcquireAppend acquire,
    XE_NP_Np2LiveSdGrid16ReleaseAppend release,XE_NP_Np2LiveSdGrid16AppendFault fault,
    XE_NP_Np2LiveSdGrid16Commit commit,XE_NP_Np2LiveSdGrid16SourceStopped stopped,
    XE_NP_Np2LiveSdGrid16PrepareStop prepare_stop,void *context)
{
    if(grid16.active || dma_active || grid16.pending || !acquire || !release || !fault ||
       !commit || !stopped || !prepare_stop || overflow_kind || spill_count || spill_dma_bytes ||
       (GPDMA1_Channel14->CCR&DMA_CCR_EN) || !aux_sectors ||
       aux_sectors>XE_NP_NP2_GRID16_MAX_AUX_SECTORS)return -1;
    const uint8_t *probe=acquire(context,UINT32_MAX,UINT32_MAX,aux_sectors);
    if(!probe || ((uintptr_t)probe&31U) || fault(context))return -1;
    release(context,UINT32_MAX,UINT32_MAX,probe);
    memset(&grid16,0,sizeof(grid16));grid16.requested=grid16.append=1U;
    grid16.requested_end_lba=physical_end;grid16.aux_sectors=aux_sectors;
    grid16.acquire_append=acquire;grid16.release_append=release;grid16.append_fault=fault;
    grid16.commit=commit;grid16.source_stopped=stopped;grid16.prepare_stop=prepare_stop;
    grid16.context=context;
    if(init_extent_profile(input,input_cache,start,blocks,mask,rate,0U,0U,0U) ||
       !initialized || xe_np_np2_live_sd_mailbox.error || !grid16.requested){
        memset(&grid16,0,sizeof(grid16));return -1;
    }
    return 0;
}
int XE_NP_Np2LiveSd_GetGrid16AppendCounts(XE_NP_Grid16Footer *out)
{
    if(!out || !initialized || !grid16.requested || !grid16.append ||
       (xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_COMPLETE &&
        xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_FAILED))return -1;
    out->np_blocks=grid16_append_ticket();
    out->logical_prefix_blocks=xe_np_np2_live_sd_mailbox.written_rus*BLOCKS_PER_RU;
    out->logical_high_water_blocks=append_logical_high_water_blocks;
    out->admitted_blocks=xe_np_np2_live_sd_mailbox.produced_blocks;out->append_flags=1U;
    return 0;
}
#endif
uint32_t XE_NP_Np2LiveSd_StoredBlocks(void)
{
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
    if(grid16.requested && grid16.append)return grid16_append_ticket();
#endif
    return xe_np_np2_live_sd_mailbox.written_rus*BLOCKS_PER_RU;
}
'''
once(marker,newapi+marker)
p.write_text(s)
print('Staged Grid16 append writer/API integration; no build/hardware')
