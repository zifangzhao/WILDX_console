from pathlib import Path
import hashlib,json
root=Path(r'D:\Code\XE_NP_V2')
h=Path(__file__).resolve().parent
paths=['Shared/Timing/np_first_sync_sd.h','Core/Inc/xe_np_np2_first_sync_sd.h',
 'Core/Src/xe_np_np2_first_sync_sd.c','Core/Src/xe_np_np2_sd_control.c',
 'Core/Src/xe_np_np2_dual_sd_app.c','Core/Inc/xe_np_np2_live_sd.h','Core/Src/xe_np_np2_live_sd.c']
pins={}
for rel in paths:
 p=root/rel;q=h/rel
 assert not q.exists(),rel
 q.parent.mkdir(parents=True,exist_ok=True)
 raw=p.read_bytes();q.write_bytes(raw)
 pins[rel]=hashlib.sha256(raw).hexdigest().upper()
(h/'parent-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
def change(rel,edits):
 p=h/rel;s=p.read_text()
 for old,new,count in edits:
  assert s.count(old)==count,(rel,old,s.count(old),count)
  s=s.replace(old,new)
 p.write_text(s,encoding='utf-8')
rel='Shared/Timing/np_first_sync_sd.h'
change(rel,[
 ('!(version==4U && family==2U)','!((version==4U || version==5U) && family==2U)',2),
 ('static inline int np_first_sd_grid16_request_valid(const uint8_t *b,size_t bytes,uint32_t family,const uint32_t uid[3])\n{return np_first_sd_shape_version(b,bytes,family,uid,1,4U);}',
  'static inline int np_first_sd_grid16_request_valid(const uint8_t *b,size_t bytes,uint32_t family,const uint32_t uid[3])\n{return np_first_sd_shape_version(b,bytes,family,uid,1,4U);}\n/* Explicit V2 append opt-in; existing entry points retain their versions. */\nstatic inline int np_first_sd_grid16_append_request_valid(const uint8_t *b,size_t bytes,uint32_t family,const uint32_t uid[3])\n{return np_first_sd_shape_version(b,bytes,family,uid,1,5U);}',1),
 ('static inline int np_first_sd_grid16_query_pack(uint8_t out[64],uint32_t op,uint32_t id,uint32_t family,const uint32_t uid[3],uint64_t token)\n{return np_first_sd_query_pack_version(out,op,id,family,uid,token,4U);}',
  'static inline int np_first_sd_grid16_query_pack(uint8_t out[64],uint32_t op,uint32_t id,uint32_t family,const uint32_t uid[3],uint64_t token)\n{return np_first_sd_query_pack_version(out,op,id,family,uid,token,4U);}\nstatic inline int np_first_sd_grid16_append_query_pack(uint8_t out[64],uint32_t op,uint32_t id,uint32_t family,const uint32_t uid[3],uint64_t token)\n{return np_first_sd_query_pack_version(out,op,id,family,uid,token,5U);}',1),
 ('static inline int np_first_sd_grid16_wrap(uint8_t out[64],const uint8_t legacy[64],uint32_t family,const uint32_t uid[3],uint64_t token,uint64_t last_token)\n{return np_first_sd_wrap_version(out,legacy,family,uid,token,last_token,4U);}',
  'static inline int np_first_sd_grid16_wrap(uint8_t out[64],const uint8_t legacy[64],uint32_t family,const uint32_t uid[3],uint64_t token,uint64_t last_token)\n{return np_first_sd_wrap_version(out,legacy,family,uid,token,last_token,4U);}\nstatic inline int np_first_sd_grid16_append_wrap(uint8_t out[64],const uint8_t legacy[64],uint32_t family,const uint32_t uid[3],uint64_t token,uint64_t last_token)\n{return np_first_sd_wrap_version(out,legacy,family,uid,token,last_token,5U);}',1),
 ('static inline int np_first_sd_grid16_unwrap(uint8_t out[64],const uint8_t request[64],uint32_t family,const uint32_t uid[3])\n{return np_first_sd_unwrap_version(out,request,family,uid,4U);}',
  'static inline int np_first_sd_grid16_unwrap(uint8_t out[64],const uint8_t request[64],uint32_t family,const uint32_t uid[3])\n{return np_first_sd_unwrap_version(out,request,family,uid,4U);}\nstatic inline int np_first_sd_grid16_append_unwrap(uint8_t out[64],const uint8_t request[64],uint32_t family,const uint32_t uid[3])\n{return np_first_sd_unwrap_version(out,request,family,uid,5U);}',1),
 ('static inline int np_first_sd_grid16_reply_valid(const uint8_t *b,size_t bytes,const uint8_t request[64],uint32_t family)\n{return np_first_sd_reply_valid_version(b,bytes,request,family,4U);}',
  'static inline int np_first_sd_grid16_reply_valid(const uint8_t *b,size_t bytes,const uint8_t request[64],uint32_t family)\n{return np_first_sd_reply_valid_version(b,bytes,request,family,4U);}\nstatic inline int np_first_sd_grid16_append_reply_valid(const uint8_t *b,size_t bytes,const uint8_t request[64],uint32_t family)\n{return np_first_sd_reply_valid_version(b,bytes,request,family,5U);}',1)])
change('Core/Inc/xe_np_np2_first_sync_sd.h',[
 ('#if XE_NP_NP2_FIRST_SYNC_ENABLE\n#include "np_first_sync_sd.h"',
  '#ifndef XE_NP_NP2_SD_GRID16_APPEND_ENABLE\n#define XE_NP_NP2_SD_GRID16_APPEND_ENABLE 0U\n#endif\n\n#if XE_NP_NP2_FIRST_SYNC_ENABLE\n#include "np_first_sync_sd.h"',1),
 ('uint32_t XE_NP_Np2FirstSyncSd_Grid16Start(uint32_t nonce);',
  'uint32_t XE_NP_Np2FirstSyncSd_Grid16Start(uint32_t nonce);\nuint32_t XE_NP_Np2FirstSyncSd_BridgeGrid16Append(void);\nuint32_t XE_NP_Np2FirstSyncSd_Grid16AppendStart(uint32_t nonce);',1),
 ('#define XE_NP_Np2FirstSyncSd_Grid16Start(nonce) 0U',
  '#define XE_NP_Np2FirstSyncSd_Grid16Start(nonce) 0U\n#define XE_NP_Np2FirstSyncSd_BridgeGrid16Append() 0U\n#define XE_NP_Np2FirstSyncSd_Grid16AppendStart(nonce) 0U',1)])
change('Core/Src/xe_np_np2_first_sync_sd.c',[
 ('if(version==4U){failure_v3(out,in,NP_FIRST_SD_UNSUPPORTED);return 1;}',
  'if(version==4U || version==5U){failure_v3(out,in,NP_FIRST_SD_UNSUPPORTED);return 1;}',1),
 ('#endif\n    op=np_first_u16(in+6);id=np_first_u32(in+8);\n    if(op==NP_FIRST_SD_CAPS){',
  '#endif\n    op=np_first_u16(in+6);id=np_first_u32(in+8);\n#if !XE_NP_NP2_SD_GRID16_APPEND_ENABLE\n    if(version==5U){failure_v3(out,in,NP_FIRST_SD_UNSUPPORTED);return 1;}\n#endif\n    if(op==NP_FIRST_SD_CAPS){',1),
 ('bound->bridge_grid16=(uint8_t)(version==4U);','bound->bridge_grid16=(uint8_t)((version==4U || version==5U)?version:0U);',1),
 ('(bound->negotiated_version==3U || bound->negotiated_version==4U)',
  '(bound->negotiated_version==3U || bound->negotiated_version==4U || bound->negotiated_version==5U)',1),
 ('bound->negotiated_version==4U && bound->negotiated_features==NPSD_V3_RECORD;}',
  '(bound->negotiated_version==4U || bound->negotiated_version==5U) && bound->negotiated_features==NPSD_V3_RECORD;}\nuint32_t XE_NP_Np2FirstSyncSd_BridgeGrid16Append(void)\n{return XE_NP_Np2FirstSyncSd_BridgeGrid16() && bound->bridge_grid16==5U;}\nuint32_t XE_NP_Np2FirstSyncSd_Grid16AppendStart(uint32_t nonce)\n{return XE_NP_Np2FirstSyncSd_Grid16Start(nonce) && bound->negotiated_version==5U;}',1),
 ('if(np_first_u16(in+4)==3U || np_first_u16(in+4)==4U)return exchange_v3(in,out,actual);',
  'if(np_first_u16(in+4)==3U || np_first_u16(in+4)==4U || np_first_u16(in+4)==5U)return exchange_v3(in,out,actual);',1),
 ('if(np_first_u16(in+4)==4U){\n        if(np_first_sd_grid16_request_valid(in,64U,2U,actual)){',
  'if(np_first_u16(in+4)==4U || np_first_u16(in+4)==5U){\n        uint32_t version=np_first_u16(in+4);\n        if(np_first_sd_shape_version(in,64U,2U,actual,1,version)){',1),
 ('(void)np_first_sd_reply_pack_version(out,in,2U,&r,4U);',
  '(void)np_first_sd_reply_pack_version(out,in,2U,&r,version);',1),
 ('|| bound->negotiated_version==4U\n',
  '|| bound->negotiated_version==4U || bound->negotiated_version==5U\n',1)])
print(json.dumps({'staged':len(paths),'parent_pins':str(h/'parent-pins.json')}))
