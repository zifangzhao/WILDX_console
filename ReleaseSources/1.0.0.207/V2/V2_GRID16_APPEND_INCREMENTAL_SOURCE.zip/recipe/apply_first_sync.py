from pathlib import Path
import ast
h=Path(__file__).resolve().parent
tree=ast.parse((h/'prepare_sources.py').read_text())
rel='Core/Src/xe_np_np2_first_sync_sd.c'
edits=None
for n in tree.body:
 if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='change' and isinstance(n.value.args[0],ast.Constant) and ast.literal_eval(n.value.args[0])==rel:
  edits=ast.literal_eval(n.value.args[1])
assert edits
p=h/rel;s=p.read_text()
for old,new,count in edits:
 assert s.count(old)==count,(old,s.count(old),count)
 s=s.replace(old,new)
p.write_text(s,encoding='utf-8')
print('Staged first-sync v5 adapter only; no firmware build/hardware')
