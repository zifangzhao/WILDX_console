"""One incremental APP and USB-catalog build; no hardware/publication."""
from pathlib import Path
import hashlib,json,re,subprocess,sys,struct,zlib
h=Path(__file__).resolve().parent;root=Path(r'D:\Code\XE_NP_V2')
arm=Path('C:/Keil_v5/ARM/ARMCLANG/bin')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
integration=json.loads((h/'integration-receipt.json').read_text())
for rel,pin in {**integration['sources'],**integration['already_integrated_metadata']}.items():assert sha(root/rel)==pin,rel
appbase=Path('C:/Frank/Code/XE_NP/_artifacts/grid16_vsc_fix/r26-firstgap-v2/build')
usbbase=root/'_artifacts/v2_grid_source_20261029/usb-grid-enforced-r2'
assert sha(appbase/'application.bin')=='D509E7519D6EA839B2BBC1589E86942237FBDFDF2BBF19930219E54DD3429F24'
assert sha(usbbase/'application.bin')=='D12D9D797DC456C9084B0632FF5249B5DEB8CA8836E569B6207035A96A0659BD'
appplan=json.loads(Path('C:/Frank/Code/XE_NP/_artifacts/grid16_sd_build_r8/plan.json').read_text())['commands']
usbplan=json.loads((root/'_artifacts/v2_release_overlay_20261025/usb/build-r1/usb/incremental-build.json').read_text())['compiler_args_by_unit']
units=['xe_np_np2_live_sd','xe_np_np2_first_sync_sd','xe_np_np2_sd_control',
       'xe_np_np2_dual_sd_app','xe_np_np2_grid16_pool','xe_np_np2_grid16_meta','xe_np_np2_dual_sd_catalog']
def command_for(recipe,unit,out,append):
 cmd=list(recipe)
 if not cmd[0].endswith('armclang.exe'):
  cmd=[str(arm/'armclang.exe'),*cmd]
  if '-c' not in cmd:cmd+=['-c',str(root/'Core/Src'/f'{unit}.c')]
  if '-o' not in cmd:cmd+=['-o',str(out/f'{unit}.o')]
 # Keep each role's actual macro recipe, changing only the explicit new mode.
 cmd=[x for x in cmd if not x.startswith('-DXE_NP_NP2_SD_GRID16_APPEND_ENABLE=') and not x.startswith('-DXE_NP_NP2_SD_GRID16_ENABLE=')]
 cmd[1:1]=['-DXE_NP_NP2_SD_GRID16_ENABLE=1U',
     '-DXE_NP_NP2_SD_GRID16_APPEND_ENABLE='+('1U' if append else '0U'),
     '-I',str(root/'Core/Inc'),'-I',str(root/'Shared/Timing')]
 source=str(root/'Core/Src'/f'{unit}.c')
 # Source/output positions in retained recipes are independent of any -MD tail.
 ci=cmd.index('-c');cmd[ci+1]=source
 oi=cmd.index('-o');cmd[oi+1]=str(out/f'{unit}.o')
 if '-MF' in cmd:cmd[cmd.index('-MF')+1]=str(out/f'{unit}.d')
 assert '-O3' in cmd and cmd[0].endswith('armclang.exe')
 return cmd
def run(args,out,name):
 r=subprocess.run(args,cwd=root,capture_output=True,text=True)
 (out/(name+'.log')).write_text(r.stdout+r.stderr)
 if r.returncode:raise RuntimeError(name+' failed; see '+str(out/(name+'.log')))
def build(role,base,recipes,suffix=''):
 out=h/('build-'+role+suffix);assert not out.exists();out.mkdir()
 lnp=(base/'application.lnp').read_text();objects=re.findall(r'"([^"\r\n]+\.o)"',lnp)
 retained={x:sha(Path(x)) for x in objects}
 changed=units if role=='app' else ['xe_np_np2_dual_sd_catalog','xe_np_np2_grid16_meta']
 commands={}
 for unit in changed:
  recipe=recipes[unit] if role=='app' else recipes['xe_np_np2_dual_sd_catalog']
  cmd=command_for(recipe,unit,out,role=='app');commands[unit]=cmd
  run(cmd,out,unit)
  found=[x for x in objects if Path(x).stem==unit]
  if found:
   assert len(found)==1;lnp=lnp.replace(found[0],(out/f'{unit}.o').as_posix())
  else:
   assert role=='usb' and unit=='xe_np_np2_grid16_meta'
   lnp='"'+(out/f'{unit}.o').as_posix()+'"\n'+lnp
 lnp=lnp.replace((base/'application.map').as_posix(),(out/'application.map').as_posix()).replace((base/'application.axf').as_posix(),(out/'application.axf').as_posix())
 (out/'application.lnp').write_text(lnp)
 for path,pin in retained.items():assert sha(Path(path))==pin,('retained object changed',path)
 run([str(arm/'armlink.exe'),'--via',str(out/'application.lnp')],out,'link')
 run([str(arm/'fromelf.exe'),'--bin','--output',str(out/'application.bin'),str(out/'application.axf')],out,'fromelf')
 body=(out/'application.bin').read_bytes();sp,pc=struct.unpack_from('<II',body)
 sys.path.insert(0,str(root/'Tools'));import package_xe_np_firmware as pkg
 from verify_xe_np_slot_hex import verify
 pkg.LOADER_ABI_VERSION=4
 kind=pkg.IMAGE_ID_APPLICATION if role=='app' else pkg.IMAGE_ID_USB_SERVICE
 manifest=pkg.build_manifest(body,generation=3,image_id=kind,usb_auto_app=(role=='usb'))
 target=out/('V2_'+role.upper()+'_GRID16_APPEND_TEST_ONLY.hex')
 pkg.write_intel_hex(target,pkg.sealed_slot_memory(body,manifest));target.write_bytes(target.read_bytes().replace(b'\r\n',b'\n'))
 verify(target,body,manifest);(out/'application.manifest.bin').write_bytes(manifest)
 regions=re.findall(r'Execution Region[^\r\n]+',(out/'application.map').read_text(errors='replace'))
 receipt={'role':role,'test_only':True,'hardware_tested':False,'source_integration':sha(h/'integration-receipt.json'),
  'compiler_commands':commands,'source_sha256':{u:sha(root/'Core/Src'/f'{u}.c') for u in changed},
  'retained_objects':retained,'body_sha256':sha(out/'application.bin'),'body_crc32':f'{zlib.crc32(body):08X}',
  'hex_sha256':sha(target),'body_bytes':len(body),'sp':hex(sp),'reset':hex(pc),'execution_regions':regions}
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({k:receipt[k] for k in ('role','body_crc32','body_sha256','hex_sha256','body_bytes','sp','reset')}),flush=True)
if '--usb-only' in sys.argv:
 build('usb',usbbase,usbplan,'-r2')
else:
 build('app',appbase,appplan)
 build('usb',usbbase,usbplan)
