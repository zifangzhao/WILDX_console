from pathlib import Path
import hashlib,json
h=Path(__file__).resolve().parent;root=Path(r'D:\Code\XE_NP_V2')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
parents=json.loads((h/'parent-pins.json').read_text())
pool=h.parent/'grid16_append_pool'
parent_pool={'Core/Src/xe_np_np2_grid16_pool.c':'243AA449EB0A8E0A6C41F57EFFFF05C7483B30127C19D3ED88268683CD13D411',
 'Core/Inc/xe_np_np2_grid16_pool.h':'DE63DD7D1F35FF78D52A2BCE6B9ECA17730F9D5706D65D62D46D82B30AFC6C83'}
pool_expected={'Core/Src/xe_np_np2_grid16_pool.c':'EBEFAEAF373C52F5066108E78D1397F3FFDE5BF100F1030EEFACA12656EA37FF',
 'Core/Inc/xe_np_np2_grid16_pool.h':'CE4C8F59065F17A6AA71408BE46AEF0ABDC0EBA86FAFA00791E6365CA6962F5E'}
already={'Core/Inc/xe_np_np2_grid16_meta.h':'7BA02970C3C5E1735070BD23B9339DD08657F24B796F8A55D8CB69EF5323FC12',
 'Core/Src/xe_np_np2_grid16_meta.c':'8CB9CF0D197D004E5515293B9065DF55743D0E653BE8DEC9BFB92046A477E454',
 'Core/Src/xe_np_np2_dual_sd_catalog.c':'FE15B601D5FC34C88002279E1DFAA6C4488A9EE89F1044DE9845570F0D17CDD7'}
contract=Path(r'D:/Code/WILDX_console/WILDX_console/Note/NP2_SD_GRID16_APPEND_WIRE.md')
assert sha(contract)=='4E5578FD874A6A3C868A48B23F3F15654809CA3FE47B67CF8172D856F203B09F'
assert not (h/'integration-receipt.json').exists()
staged={rel:h/rel for rel in parents}
for rel,expected in parents.items():assert sha(root/rel)==expected,('canonical drift',rel)
for rel,expected in parent_pool.items():
 assert sha(root/rel)==expected,('pool parent drift',rel)
 assert sha(pool/rel)==pool_expected[rel],('pool staged drift',rel)
 staged[rel]=pool/rel
for rel,expected in already.items():assert sha(root/rel)==expected,('metadata handoff drift',rel)
rel='Core/Src/xe_np_np2_grid16_append.inc';assert not (root/rel).exists();staged[rel]=h/rel
for rel,p in staged.items():
 target=root/rel
 if target.exists():
  backup=h/'preimages'/rel;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(target.read_bytes())
 target.write_bytes(p.read_bytes())
for rel,p in staged.items():assert sha(root/rel)==sha(p),rel
spec=root/'Note/NP2_SD_GRID16_APPEND_WIRE.md'
if spec.exists():assert sha(spec)==sha(contract)
else:spec.write_bytes(contract.read_bytes())
receipt={'sources':{rel:sha(root/rel) for rel in staged},'already_integrated_metadata':already,
 'contract_sha256':sha(spec),'scope':'Guarded source integration only; no ARM build, firmware installation or hardware proof'}
(h/'integration-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'integrated_files':len(staged),'already_metadata':len(already)}))
