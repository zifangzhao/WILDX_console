from pathlib import Path
import json,re,subprocess,hashlib,sys,zlib
T=Path(__file__).resolve().parent;B=T/'build';O=T/'build-r2';O.mkdir(exist_ok=False)
R=Path('D:/Code/XE_NP_V2');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
parent=json.loads((B/'receipt.json').read_text());assert parent['crc32']=='0CDE584C' and sha(B/'application.bin')==parent['body_sha256']
c=list(parent['compiler_commands']['xe_np_usb_stream']);c[c.index('-o')+1]=str(O/'xe_np_usb_stream.o');c[c.index('-MF')+1]=str(O/'xe_np_usb_stream.d')
r=subprocess.run(c,cwd=R,capture_output=True,text=True);(O/'compile.log').write_text(r.stdout+r.stderr);assert not r.returncode,r.stdout+r.stderr
link=(B/'application.lnp').read_text();objs=re.findall(r'"([^"\r\n]+\.o)"',link)
old=[p for p in objs if Path(p).name=='xe_np_usb_stream.o'];assert len(old)==1
retained={p:sha(p) for p in objs if p!=old[0]}
link=link.replace(old[0],(O/'xe_np_usb_stream.o').as_posix())
for n in ('application.axf','application.map','application.sct'):link=link.replace((B/n).as_posix(),(O/n).as_posix())
(O/'application.sct').write_bytes((B/'application.sct').read_bytes());(O/'application.lnp').write_text(link)
r=subprocess.run(['C:/Keil_v5/ARM/ARMCLANG/bin/armlink.exe','--via',str(O/'application.lnp')],capture_output=True,text=True);(O/'link.log').write_text(r.stdout+r.stderr);assert not r.returncode,r.stdout+r.stderr
def syms(p):return {(m[1],m[4]):(int(m[2],16),int(m[3])) for m in re.finditer(r'^\s+(\S+)\s+(0x[\da-fA-F]+)\s+Data\s+(\d+)\s+([^\r\n]+)',p.read_text(),re.M) if m[4].endswith(('(NP_CAPTURE)','(NP2_CL_SELECTED)'))}
assert syms(B/'application.map')==syms(O/'application.map')
(O/'memory-proof.json').write_text(json.dumps(dict(status='PASS',unchanged_capture_symbols=len(syms(O/'application.map')),scatter_sha256=sha(O/'application.sct')),indent=2)+'\n')
r=subprocess.run(['C:/Keil_v5/ARM/ARMCLANG/bin/fromelf.exe','--bin','--output',str(O/'application.bin'),str(O/'application.axf')],capture_output=True,text=True);assert not r.returncode,r.stdout+r.stderr
sys.path.insert(0,str(R/'Tools'));import package_xe_np_firmware as pkg
from verify_xe_np_slot_hex import verify
pkg.LOADER_ABI_VERSION=4;b=(O/'application.bin').read_bytes();m=pkg.build_manifest(b,generation=3,image_id=pkg.IMAGE_ID_USB_SERVICE,usb_auto_app=True);(O/'application.manifest.bin').write_bytes(m)
h=O/'V2_USB_GUI_SUPPORT_CANDIDATE.hex';pkg.write_intel_hex(h,pkg.sealed_slot_memory(b,m));h.write_bytes(h.read_bytes().replace(b'\r\n',b'\n'));verify(h,b,m)
pins={str(p):sha(p) for sub in ('Core/Src','Core/Inc') for p in (T/sub).glob('*') if p.is_file()}
q=dict(status='SOFTWARE_CHECKED_HIL_PENDING',parent_crc32='0CDE584C',published_parent_crc32='D43FE162',crc32=f'{zlib.crc32(b):08X}',expected_app_crc32='99CC44F9',body_bytes=len(b),body_sha256=sha(O/'application.bin'),manifest_sha256=sha(O/'application.manifest.bin'),hex_sha256=sha(h),compiler_commands={'xe_np_usb_stream':c},source_pins=pins,retained_objects=retained,scope='Finalreview: immutable foreground receiptpublication, exactdirectoryjournalwrite whitelist, query+restoreCID/cap reconciliation; unchanged NP/IMU/CLobjects and captureaddresses')
(O/'receipt.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:q[k] for k in ('status','crc32','body_sha256','body_bytes')},indent=2))
