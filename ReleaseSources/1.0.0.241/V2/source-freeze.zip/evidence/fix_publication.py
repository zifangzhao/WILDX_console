from pathlib import Path
p=Path(__file__).resolve().parent/'Core/Src/xe_np_usb_maintenance.inc'
s=p.read_text();start=s.index('static void usb_delete_service(void)');pre=s[:start];f=s[start:]
old='    uint32_t op=usb_delete_queued;usb_delete_queued=0U;usb_delete_report[3]=2U;usb_delete_seal();'
new='    uint32_t op=usb_delete_queued;usb_delete_queued=0U;\n    uint32_t publish_key=__get_PRIMASK();__disable_irq();usb_delete_report[3]=2U;usb_delete_seal();\n    uint32_t work[32];memcpy(work,usb_delete_report,128U);__set_PRIMASK(publish_key);'
assert f.count(old)==1;f=f.replace(old,new)
cut=f.index('    xe_np_usb_delete_writes_allowed=0U;')
head=f[:cut];body=f[cut:].replace('usb_delete_report[','work[')
old='    work[3]=result?4U:3U;usb_delete_seal();\n    if(!result && op==1U)memcpy(usb_delete_confirmed,usb_delete_report,128U);'
new='    work[3]=result?4U:3U;work[31]=usb_maintenance_crc(work);memcpy(usb_delete_report,work,128U);\n    if(!result && op==1U)memcpy(usb_delete_confirmed,work,128U);'
assert body.count(old)==1;body=body.replace(old,new)
p.write_text(pre+head+body)
print('Foreground result now private; only atomic immutable report publications remain')
