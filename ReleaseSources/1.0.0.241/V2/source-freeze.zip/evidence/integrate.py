from pathlib import Path
T=Path(__file__).resolve().parent
def replace(p,old,new):
 s=p.read_text();assert s.count(old)==1,(p,old,s.count(old));p.write_text(s.replace(old,new))
src=T/'Core/Src/xe_np_usb_stream.c';uni=T/'Core/Src/xe_np_usb_unified.inc';cat=T/'Core/Src/xe_np_usb_catalog.inc'
replace(src,'static volatile uint8_t xe_np_usb_sd_info_pending;','static volatile uint8_t xe_np_usb_sd_info_pending;\nstatic volatile uint32_t xe_np_usb_maintenance_active;\nstatic void usb_maintenance_cancel(void);')
replace(src,'#include "xe_np_usb_idle_sleep.inc"','#include "xe_np_usb_idle_sleep.inc"\n#include "xe_np_usb_maintenance.inc"')
replace(src,'    /* IN79/64 is format INFO; existing IN79/256 is still self-test. */','    if(xe_np_usb_sd_info_pending && !(req->bmRequest&0x80U) && req->bRequest!=0xA6U && req->bRequest!=0x4CU){XE_NP_UsbStream_Stall(hpcd);return;}\n    if(usb_sd_info_request(hpcd,req) || usb_delete_request_setup(hpcd,req))return;\n    /* IN79/64 is format INFO; existing IN79/256 is still self-test. */')
replace(src,'    xe_np_usb_mode_service();\n    if(XE_NP_UsbUnified_IsDownload()){','    xe_np_usb_mode_service();\n    if(usb_sd_info_service())return;\n    if(XE_NP_UsbUnified_IsDownload()){\n        usb_delete_service();')
start=src.read_text().index('    if(xe_np_usb_sd_info_pending) {\n        XE_NP_SdInfo result;')
s=src.read_text();end=s.index('\n    }\n#endif',start)+len('\n    }');s=s[:start]+s[end:];src.write_text(s)
replace(src,'    XE_NP_UsbStream_ParseSetup(hpcd, &req);','    XE_NP_UsbStream_ParseSetup(hpcd, &req);\n#if XE_NP_USB_UNIFIED_ENABLE\n    usb_maintenance_setup();\n#endif')
replace(src,'        if(xe_np_usb_sd_test_out(hpcd)){XE_NP_UsbStream_UpdateDiag();return;}','        if(xe_np_usb_sd_test_out(hpcd)){XE_NP_UsbStream_UpdateDiag();return;}\n        if(usb_delete_out(hpcd)){XE_NP_UsbStream_UpdateDiag();return;}')
replace(uni,'    if(xe_np_usb_selftest_busy())return 1;','    if(xe_np_usb_selftest_busy() || xe_np_usb_sd_info_pending)return 1;')
replace(uni,'        xe_np_usb_mode_info[3]=15U;','        xe_np_usb_mode_info[3]=15U;') if False else None
replace(uni,'xe_np_usb_mode_info[2]=xe_np_usb_personality;xe_np_usb_mode_info[3]=15U;','xe_np_usb_mode_info[2]=xe_np_usb_personality;xe_np_usb_mode_info[3]=15U|0x00020000U|0x00040000U;')
replace(cat,'return xe_np_usb_catalog.queued || xe_np_usb_catalog.running || xe_np_usb_catalog.sector_owned','return xe_np_usb_maintenance_active || xe_np_usb_catalog.queued || xe_np_usb_catalog.running || xe_np_usb_catalog.sector_owned')
replace(cat,'    /* Repair and explicit format have separate, fixed metadata whitelists. */','    /* Repair, explicit format and confirmed DeleteLast share metadata-only whitelists. */')
replace(cat,'#if XE_NP_USB_SD_FORMAT_ENABLE\n    writable|=','    writable|=xe_np_usb_catalog.operation==0xA7U &&\n        (lba==112U || lba==113U || (lba>=128U && lba<1152U));\n#if XE_NP_USB_SD_FORMAT_ENABLE\n    writable|=')
replace(cat,'    uint32_t prepared=xe_np_usb_catalog.inspected;','    uint32_t prepared=xe_np_usb_catalog.inspected;\n    usb_maintenance_cancel();')
print('Maintenance routing, foreground service, cancel and journal whitelist integrated')
