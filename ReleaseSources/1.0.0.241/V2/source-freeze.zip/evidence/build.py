from pathlib import Path
import hashlib,json,re,subprocess,zlib,sys
T=Path(__file__).resolve().parent
P=T.parent/'v2_usb_imu100_20261105'
R=Path('D:/Code/XE_NP_V2')
B=P/'r4'; O=T/'build'; O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
parent=load(B/'receipt.json')
assert parent['crc32']=='D43FE162' and sha(B/'application.bin')==parent['body_sha256']
stream_base=load(P/'r3/receipt.json')['compiler_commands']['xe_np_usb_stream']
catalog_base=load('C:/Frank/Code/USB_PCconsole/_artifacts/closed_loop_20261102/V2/build-usb/receipt.json')['compiler_commands']['xe_np_np2_dual_sd_catalog']
commands={}; replacements={}
link=(B/'application.lnp').read_text()
old_objects=re.findall(r'"([^"\r\n]+\.o)"',link)
for unit,base in [('xe_np_usb_stream',stream_base),('xe_np_np2_dual_sd_catalog',catalog_base)]:
    c=list(base)
    c[1:1]=['-I',str(T/'Core/Inc'),'-iquote',str(T/'Core/Src'),'-DXE_NP_NP2_SD_CATALOG_ENABLE=1U']
    c[c.index('-c')+1]=str(T/'Core/Src'/f'{unit}.c')
    c[c.index('-o')+1]=str(O/f'{unit}.o')
    c[c.index('-MF')+1]=str(O/f'{unit}.d')
    if '--resume-link' not in sys.argv:
        assert not (O/f'{unit}.o').exists(),'Use a new candidate output for any changed source'
        r=subprocess.run(c,cwd=R,capture_output=True,text=True)
        (O/f'{unit}.compile.log').write_text(r.stdout+r.stderr)
        assert not r.returncode,r.stdout+r.stderr
    else:
        assert (O/f'{unit}.o').exists() and (O/f'{unit}.d').exists()
    commands[unit]=c
    old=[p for p in old_objects if Path(p).name==f'{unit}.o'];assert len(old)==1
    replacements[old[0]]=(O/f'{unit}.o').as_posix()
retained={p:sha(p) for p in old_objects if p not in replacements}
for p,h in retained.items():
    if p in parent['retained_objects']: assert parent['retained_objects'][p]==h,p
for old,new in replacements.items():link=link.replace(old,new)
for n in ['application.axf','application.map','application.sct']:link=link.replace((B/n).as_posix(),(O/n).as_posix())
(O/'application.sct').write_bytes((B/'application.sct').read_bytes());(O/'application.lnp').write_text(link)
r=subprocess.run(['C:/Keil_v5/ARM/ARMCLANG/bin/armlink.exe','--via',str(O/'application.lnp')],capture_output=True,text=True)
(O/'link.log').write_text(r.stdout+r.stderr);assert not r.returncode,r.stdout+r.stderr
def capture_symbols(path):
    return {(m[1],m[4]):(int(m[2],16),int(m[3])) for m in re.finditer(r'^\s+(\S+)\s+(0x[\da-fA-F]+)\s+Data\s+(\d+)\s+([^\r\n]+)',path.read_text(),re.M) if m[4].endswith(('(NP_CAPTURE)','(NP2_CL_SELECTED)'))}
assert capture_symbols(B/'application.map')==capture_symbols(O/'application.map')
(O/'memory-proof.json').write_text(json.dumps(dict(status='PASS',unchanged_capture_symbols=len(capture_symbols(O/'application.map')),scatter_sha256=sha(O/'application.sct'),claim='Exact parent fixed NP/selected-source buffers retained; maintenance-only BSS may grow'),indent=2)+'\n')
r=subprocess.run(['C:/Keil_v5/ARM/ARMCLANG/bin/fromelf.exe','--bin','--output',str(O/'application.bin'),str(O/'application.axf')],capture_output=True,text=True);assert not r.returncode,r.stdout+r.stderr
sys.path.insert(0,str(R/'Tools'));import package_xe_np_firmware as pkg
from verify_xe_np_slot_hex import verify
pkg.LOADER_ABI_VERSION=4
body=(O/'application.bin').read_bytes();manifest=pkg.build_manifest(body,generation=3,image_id=pkg.IMAGE_ID_USB_SERVICE,usb_auto_app=True)
(O/'application.manifest.bin').write_bytes(manifest)
hexpath=O/'V2_USB_GUI_SUPPORT_CANDIDATE.hex';pkg.write_intel_hex(hexpath,pkg.sealed_slot_memory(body,manifest));hexpath.write_bytes(hexpath.read_bytes().replace(b'\r\n',b'\n'));verify(hexpath,body,manifest)
pins={str(p):sha(p) for sub in ('Core/Src','Core/Inc') for p in (T/sub).glob('*') if p.is_file()}
receipt=dict(status='SOFTWARE_CHECKED_HIL_PENDING',parent_crc32='D43FE162',crc32=f'{zlib.crc32(body):08X}',expected_app_crc32='99CC44F9',body_bytes=len(body),body_sha256=sha(O/'application.bin'),manifest_sha256=sha(O/'application.manifest.bin'),hex_sha256=sha(hexpath),compiler_commands=commands,source_pins=pins,retained_objects=retained,scope='Stopped USB maintenance controls; APP99 and NP/IMU/selected detector objects retained')
(O/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ('status','crc32','body_bytes','body_sha256')},indent=2))
