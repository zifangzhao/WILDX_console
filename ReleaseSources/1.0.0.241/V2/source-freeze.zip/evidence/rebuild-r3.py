from pathlib import Path
T=Path(__file__).resolve().parent
s=(T/'rebuild-stream.py').read_text().replace("B=T/'build';O=T/'build-r2'","B=T/'build-r2';O=T/'build-r3'").replace("parent['crc32']=='0CDE584C'","parent['crc32']=='C7A2A84D'").replace("parent_crc32='0CDE584C'","parent_crc32='C7A2A84D'").replace("Finalreview: immutable foreground receiptpublication, exactdirectoryjournalwrite whitelist, query+restoreCID/cap reconciliation; unchanged NP/IMU/CLobjects and captureaddresses","Fix inherited NP2 USB NULL legacy App runtime admission; retain all actualNP2 source/physical owners and all prior nativechecked maintenance safeguards; C7 rejection retained")
exec(compile(s,str(T/'rebuild-r3.py'),'exec'),{'__file__':str(T/'rebuild-r3.py'),'__name__':'__main__'})
