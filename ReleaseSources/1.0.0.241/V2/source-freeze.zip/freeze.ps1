$ErrorActionPreference='Stop'
$task='C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105'
$output=$PSScriptRoot
function Hash($p){(Get-FileHash -LiteralPath $p).Hash}
if(Test-Path -LiteralPath (Join-Path $output 'source-freeze.zip')){throw 'Immutable source archive already exists'}
$watch=[Diagnostics.Stopwatch]::StartNew()
$receipt=Join-Path $task 'build-r4/receipt.json'
if((Hash $receipt) -cne '808D0DEEF65008613D05DC02DD13AE563ABD9E3E38016878C9AEED1798749918'){throw 'Owner receipt pin changed'}
$r=Get-Content -Raw -LiteralPath $receipt|ConvertFrom-Json
$first=Get-Content -Raw -LiteralPath (Join-Path $task 'build/receipt.json')|ConvertFrom-Json
if($r.crc32 -cne 'EDEB6C3A' -or ($first.compiler_commands.xe_np_np2_dual_sd_catalog -join ' ') -notmatch 'XE_NP_NP2_SD_CATALOG_ENABLE=1U'){throw 'Exact candidate/catalog compilation missing'}
$files=New-Object Collections.Generic.List[object]
function AddFile($from,$relative,$role){
 $to=Join-Path $output ('payload/'+$relative)
 [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($to))
 Copy-Item -LiteralPath $from -Destination $to
 $files.Add([ordered]@{path=$relative;origin=[IO.Path]::GetFullPath($from);sha256=(Hash $to);bytes=(Get-Item -LiteralPath $to).Length;role=$role})
}
foreach($pin in $r.source_pins.PSObject.Properties){
 if((Hash $pin.Name) -cne $pin.Value){throw 'Build-pinned source changed'}
 AddFile $pin.Name ('source/'+$pin.Name.Substring($task.Length+1).Replace('\','/')) 'Exact build-pinned final candidate source'
}
foreach($name in @('build-r4/receipt.json','build-r4/xe_np_usb_stream.d','build-r4/application.lnp','build-r4/application.sct','build-r4/application.map','build-r4/memory-proof.json','build-r4/compile.log','build-r4/link.log','build/receipt.json','build/xe_np_np2_dual_sd_catalog.d','build/xe_np_np2_dual_sd_catalog.compile.log','build-r3/receipt.json','build-r2/receipt.json','build.py','rebuild-stream.py','rebuild-r3.py','rebuild-r4.py','integrate.py','fix_publication.py','source-preimages/maintenance-C7A2A84D.inc','source-preimages/maintenance-E664B82A.inc','source-preimages/catalog-E664B82A.inc','sdinfo-stream-diagnostic/report.txt','sdinfo-stream-diagnostic/result.json','sdinfo-stream-passive/report.txt','sdinfo-stream-passive/result.json','a7-rejected-snapshot/values.json','a7-rejected-snapshot/addresses.json','a7-rejected-snapshot/read-only.log')){
 AddFile (Join-Path $task $name) ('evidence/'+$name) 'Build/dependency/recipe and failed-parent context; not candidate acceptance'
}
$native='C:/Frank/Code/USB_PCconsole/_artifacts/gui_preview_maintenance_evidence_20261105/r3/source-evidence.zip'
if((Hash $native) -cne 'B5F9CEDCF1AD99342D3A8300D6B61E78FFB19F3D7586952FBCBD7B91E90F9F7C'){throw 'Native bundle changed'}
AddFile $native 'evidence/host-native-checks/source-evidence.zip' 'Immutable host708/native2192+671CRC compact checks'
if((Hash (Join-Path $task 'build-r4/application.bin')) -cne $r.body_sha256){throw 'Linked body differs from receipt'}
$body=[IO.File]::ReadAllBytes((Join-Path $task 'build-r4/application.bin'))
$seal=[IO.File]::ReadAllBytes((Join-Path $task 'build-r4/application.manifest.bin'))
$base=[BitConverter]::ToUInt32($seal,24);$address=[Convert]::ToUInt32('08197A78',16)
$bytes=([BitConverter]::ToString($body,$address-$base,4)).Replace('-','')
if($bytes -cne '00207047'){throw 'Actual linked NULL-runtime proof changed'}
$proof=[ordered]@{role='Read-only local linked-body identity proof';symbol='XE_NP_App_GetRuntime';thumb_symbol='0x08197A79';code_address='0x08197A78';body_base=('0x{0:X8}' -f $base);bytes=$bytes;decoded='MOVS r0,#0; BX lr';body_sha256=$r.body_sha256;body_crc32=$r.crc32;scope='No device action; inherited NP2 USB generic runtime getter intentionally returnsNULL. Physical/source ownership guards remain authoritative.'}
[IO.File]::WriteAllText((Join-Path $output 'runtime-null-proof.json'),($proof|ConvertTo-Json)+"`n",[Text.UTF8Encoding]::new($false))
AddFile (Join-Path $output 'runtime-null-proof.json') 'runtime-null-proof.json' 'Four-byte proof; full body is not archived'
AddFile $PSCommandPath 'freeze.ps1' 'Exact bounded source-freeze assembly recipe'
$total=0L;foreach($file in $files){$total+=[long]$file['bytes']}
$manifest=[ordered]@{status='SOURCE_FROZEN_EDEB6C3A_CANDIDATE_PENDING_HARDWARE_ACCEPTANCE_AND_RESTORATION';created_utc=[DateTimeOffset]::UtcNow.ToString('o');usb_crc32='EDEB6C3A';expected_app_crc32='99CC44F9';actual_build_receipt_sha256=(Hash $receipt);source_pins=$r.source_pins;compiler_commands=$r.compiler_commands;initial_catalog_compiler_command=$first.compiler_commands.xe_np_np2_dual_sd_catalog;retained_object_identities=$r.retained_objects;published_parent=[ordered]@{version='1.0.0.238';usb_crc32='D43FE162';r4_source_zip_sha256='E9814DE808B4AC5DB58DF35950654862D5BC8A7022398FFDCC4D8FBB3F58D4D6';r3_source_zip_sha256='B29ABB6BA6DA0140E185A5F1132E6573CFCD8EFDCFF008A3804B87D3646AED0B'};portable_catalog_source_sha256='FE15B601D5FC34C88002279E1DFAA6C4488A9EE89F1044DE9845570F0D17CDD7';native_bundle_sha256='B5F9CEDCF1AD99342D3A8300D6B61E78FFB19F3D7586952FBCBD7B91E90F9F7C';files=$files.ToArray();stored_bytes=$total;limits=@('EDEB HIL/restoration pending; source/native freeze is not accepted firmware.','Failed C7 NULL-runtime and E664 idle-cache cases are retained parent context.','Published238 dependency/object-history limitations remain; no whole retained-source rebuild-equivalence claim.','No recording payloads, firmware binaries, objects/toolchain files, hardware actions, new build or installer work.','Append final acceptance/restoration/cleanup closure separately; never mutate this source ZIP.')}
$json=($manifest|ConvertTo-Json -Depth 25)+"`n"
[IO.File]::WriteAllText((Join-Path $output 'payload/manifest.json'),$json,[Text.UTF8Encoding]::new($false))
Copy-Item -LiteralPath (Join-Path $output 'payload/manifest.json') -Destination (Join-Path $output 'manifest.json')
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zipStart=$watch.Elapsed.TotalSeconds
[IO.Compression.ZipFile]::CreateFromDirectory((Join-Path $output 'payload'),(Join-Path $output 'source-freeze.zip'),[IO.Compression.CompressionLevel]::Fastest,$false)
$compression=$watch.Elapsed.TotalSeconds-$zipStart
[ordered]@{status=$manifest.status;files=$files.Count;stored_bytes=$total;zip_bytes=(Get-Item -LiteralPath (Join-Path $output 'source-freeze.zip')).Length;zip_sha256=(Hash (Join-Path $output 'source-freeze.zip'));manifest_sha256=(Hash (Join-Path $output 'manifest.json'));seconds=$watch.Elapsed.TotalSeconds;compression_seconds=$compression}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $output 'receipt.json') -Encoding utf8
Get-Content -LiteralPath (Join-Path $output 'receipt.json')
