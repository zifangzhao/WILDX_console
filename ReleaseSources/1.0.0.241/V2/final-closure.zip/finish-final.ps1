$ErrorActionPreference='Stop'
$taskRoot=$PSScriptRoot
$taskLease=Get-Content -LiteralPath (Join-Path $taskRoot 'owner-final/lease.json') -Raw|ConvertFrom-Json
if($taskLease.status -ne 'active' -or $taskLease.uid -ne '001A0004434250062039314E'){throw 'Exact live lease required'}
$taskOriginal=Get-Content -LiteralPath (Join-Path $taskRoot 'original-final/receipt.json') -Raw|ConvertFrom-Json
$taskRestored=Get-Content -LiteralPath (Join-Path $taskRoot 'deployment-final/Restore-verified.json') -Raw|ConvertFrom-Json
if($taskRestored.whole_flash_sha256 -ne $taskOriginal.full_sha256 -or $taskRestored.options_sha256 -ne $taskOriginal.options_sha256){throw 'Exact restoration identity proof required'}
$taskA=[Reflection.Assembly]::LoadFrom((Join-Path $taskRoot 'runtime/WILDX_console.exe'))
$taskF=[Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
$taskT=$taskA.GetType('USB512_interface.NpV2UsbDevice',$true)
$taskPath='\\?\usb#vid_1209&pid_b386#001a0004434250062039314e#{8f5a4a7b-0aa6-4f8e-a14f-a2f7b3c6aa4e}'
function V($taskObject,$taskName){$taskObject.GetType().GetField($taskName,$taskF).GetValue($taskObject)}
$taskDevice=$taskT.GetMethod('Open',$taskF).Invoke($null,@($taskPath))
try {
 $taskStatus=$taskT.GetMethod('GetServiceStatus',$taskF).Invoke($taskDevice,@())
 if((V $taskStatus 'Mode') -notin @(2,3) -or (V $taskStatus 'Busy') -ne 0 -or (V $taskStatus 'Target') -ne 0){throw 'Restored device not idle'}
 $taskMode=V $taskStatus 'Mode'
} finally {$taskDevice.Dispose()}
$taskPreferences=Join-Path $env:LOCALAPPDATA 'WILDX_console/closed_loop_v2.json'
if($taskOriginal.preferences.existed){throw 'This task only backed up absent preferences'}
if(Test-Path -LiteralPath $taskPreferences){throw 'Original absent preference not restored'}
$taskReceipt=[ordered]@{status='EXACT_ORIGINAL_FLASH_OPTIONS_AND_PREFERENCES_RESTORED_IDLE';uid=$taskLease.uid;app_crc32='7F238587';usb_crc32='74FC7104';flash_sha256=$taskOriginal.full_sha256;options_sha256=$taskOriginal.options_sha256;mode=$taskMode;busy=0;target=0;preference_absent=$true;own_record_verified=(Test-Path (Join-Path $taskRoot 'sd-job-final-readback/own-verified.json'));own_delete_verified=(Test-Path (Join-Path $taskRoot 'delete-own-final/preserved.json'));card_format=$false;card_actions_scope='See explicit SD-job and delete-own receipts; no old recording deletion authorized';utc=[DateTime]::UtcNow.ToString('o')}
$taskReceipt|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $taskRoot 'restoration-final-complete.json') -Encoding utf8
[IO.File]::WriteAllText((Join-Path $taskRoot 'owner-final/release.flag'),'Exact originals verified and idle')
$taskReceipt|ConvertTo-Json -Compress
