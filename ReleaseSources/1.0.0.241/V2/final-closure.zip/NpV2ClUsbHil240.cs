using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

// Deliberately isolated HIL adapter. selftest reflects only; run requires a
// main-owned GLOBAL+UID lease and never expands a one-lane run to two lanes.
internal static class NpV2ClUsbHil
{
    sealed class MockSetup { public byte[] Request,Receipt; public bool Enabled; public int Lanes,Calls; public uint Flags,ConfigCrc; }
    const string Host="C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/runtime/WILDX_console.exe";
    const string HostSha="BD0416D30E53946B65380D8F925AE002C277D9C835D22F6A59598D1675F26ECD";
    const string SdkSha="EBC98EEB84FDE42DEE06B713F1F6246B30B3527732075D9F84C6DF57BCA69EFB";
    const string Uid="001A0004434250062039314E";
    const string WorkerSource="C:/Frank/Code/USB_PCconsole/_artifacts/sd_usb_test_host/source237-usbcl/Neuropixels/USBConsoleV2/NpV2UsbConsole.cs";
    const long RunCapBytes=5L*1024*1024*1024;
    const BindingFlags All=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Static|BindingFlags.Instance;
    static readonly JavaScriptSerializer Json=new JavaScriptSerializer();
    static double targetDataSeconds=60.0; static Assembly app; static string output; static Stopwatch wall; static long firstData; static int requestedLanes; static uint requestedMask,requestedHz,confirmConfigurationCalls,beforeDeviceDisposeCalls;
    static readonly Dictionary<string,object> Report=new Dictionary<string,object>();
    static Type T(string name){var t=app.GetType(name,false);if(t!=null)return t;foreach(var a in AppDomain.CurrentDomain.GetAssemblies()){t=a.GetType(name,false);if(t!=null)return t;}throw new TypeLoadException(name);}
    static object Get(object o,string n){var f=o.GetType().GetField(n,All);if(f!=null)return f.GetValue(o);var p=o.GetType().GetProperty(n,All);if(p!=null)return p.GetValue(o,null);throw new MissingMemberException(o.GetType().FullName,n);}
    static void Set(object o,string n,object v){var f=o.GetType().GetField(n,All);if(f==null)throw new MissingFieldException(o.GetType().FullName,n);f.SetValue(o,v);}
    static long N(object o,string n){return Convert.ToInt64(Get(o,n));}
    static void Need(bool v,string why){if(!v)throw new InvalidOperationException(why);}
    static string Hash(string p){using(var h=SHA256.Create())using(var f=File.OpenRead(p))return BitConverter.ToString(h.ComputeHash(f)).Replace("-","");}
    static void GuardInputs(){Need(Hash(Host)==HostSha,"Pinned host SHA256 differs");Need(Hash(Path.Combine(Path.GetDirectoryName(Host),"NpV2SdDatExport.dll"))==SdkSha,"Pinned SDK SHA256 differs");}
    static object Call(object target,string name,params object[] args){var t=target as Type??target.GetType();var m=t.GetMethods(All).Single(x=>x.Name==name&&x.IsStatic==(target is Type)&&x.GetParameters().Length==args.Length);try{return m.Invoke(target is Type?null:target,args);}catch(TargetInvocationException e){throw e.InnerException??e;}}
    static bool Cancel(){return firstData!=0?(Stopwatch.GetTimestamp()-firstData)/(double)Stopwatch.Frequency>=targetDataSeconds:wall.Elapsed.TotalSeconds>=120.0;}
    static void Progress(object p){if(N(p,"ReceivedBlocks")>0&&Interlocked.CompareExchange(ref firstData,Stopwatch.GetTimestamp(),0)==0)Console.WriteLine("first-data");}
    static object[] Signature(Type t,string name){return t.GetMethods(All).Where(m=>m.Name==name).Select(m=>new{signature=m.ToString(),parameters=m.GetParameters().Select(p=>new{name=p.Name,type=p.ParameterType.FullName}).ToArray()}).ToArray();}
    static void Put(byte[] b,int at,uint value){Buffer.BlockCopy(BitConverter.GetBytes(value),0,b,at,4);}
    static byte[] MockClosedLoopReply(byte[] request)
    {
        var reply=new byte[64];Buffer.BlockCopy(System.Text.Encoding.ASCII.GetBytes("NPCR"),0,reply,0,4);Put(reply,4,1U);var op=BitConverter.ToUInt32(request,8);Put(reply,8,op);Put(reply,12,BitConverter.ToUInt32(request,12));
        var enabled=op==1U&&BitConverter.ToUInt32(request,32)!=0U;Put(reply,20,enabled?3U:1U);Put(reply,24,enabled?BitConverter.ToUInt32(request,60):0U);Put(reply,40,2U);Put(reply,44,2U);Put(reply,48,1U<<6);Put(reply,52,1U<<3);Put(reply,60,Convert.ToUInt32(Call(T("WildNpClosedLoop.NpClosedLoopEvent"),"Crc",reply,60)));return reply;
    }
    static void Noop<TValue>(TValue ignored){}
    static MockSetup MockPrepare(bool enabled,int lanes)
    {
        var settingsType=T("USB512_interface.NpClosedLoopSettings");var cfg=Activator.CreateInstance(settingsType);Set(cfg,"Enabled",enabled);Set(cfg,"MayBeConfigured",true);Set(cfg,"TrainingStartMs",0U);Set(cfg,"TrainingDurationMs",1000U);var channelType=T("WildNpClosedLoop.NpClosedLoopChannel");var channels=Array.CreateInstance(channelType,Math.Max(1,lanes));for(int i=0;i<channels.Length;i++){var row=Activator.CreateInstance(channelType);Set(row,"Probe",(byte)2);Set(row,"Channel",(ushort)i);Set(row,"Filter",(byte)6);Set(row,"Gain",2.0f);Set(row,"Rectify",true);channels.SetValue(row,i);}Set(cfg,"Channels",channels);
        var prepare=settingsType.GetMethods(All).Single(m=>m.Name=="Prepare"&&m.GetParameters().Length==10);var persist=Delegate.CreateDelegate(typeof(Action<>).MakeGenericType(settingsType),typeof(NpV2ClUsbHil).GetMethod("Noop",All).MakeGenericMethod(settingsType));var calls=0;Func<byte[],CancellationToken,Task<byte[]>> exchange=(wireRequest,token)=>{calls++;return Task.FromResult(MockClosedLoopReply(wireRequest));};var setup=Await(prepare.Invoke(null,new object[]{cfg,true,7U,20000U,exchange,CancellationToken.None,(Action<string>)(_=>{}),persist,null,false}));Need(setup!=null&&calls==2,"Pinned Prepare mock did not exchange CAPS+CONFIG once");var configRequest=(byte[])Get(setup,"Request");var receipt=(byte[])Get(setup,"Receipt");var reply=Call(T("WildNpClosedLoop.NpClosedLoopControl"),"ParseReply",receipt,1U,BitConverter.ToUInt32(configRequest,12));Need(N(reply,"Result")==0&&((N(reply,"Flags")&2)!=0)==enabled&&(!enabled?N(reply,"ConfigCrc")==0U:N(reply,"ConfigCrc")==BitConverter.ToUInt32(configRequest,60)),"Pinned Prepare mock receipt semantics differ");return new MockSetup{Request=configRequest,Receipt=receipt,Enabled=enabled,Lanes=lanes,Calls=calls,Flags=(uint)N(reply,"Flags"),ConfigCrc=(uint)N(reply,"ConfigCrc")};
    }
    static void ExpectReject(Action action,string message){var rejected=false;try{action();}catch(Exception){rejected=true;}Need(rejected,message);}
    static object ReceiptGuardSelftest(MockSetup off,MockSetup one,MockSetup two)
    {
        requestedMask=7U;requestedHz=20000U;requestedLanes=0;ValidateWorkerReceipt(off.Request,off.Receipt);requestedLanes=1;ValidateWorkerReceipt(one.Request,one.Receipt);requestedLanes=2;ValidateWorkerReceipt(two.Request,two.Receipt);
        ExpectReject(()=>ValidateWorkerReceipt(off.Request,off.Receipt),"Stale disabled receipt accepted for one lane");var corrupt=(byte[])one.Receipt.Clone();corrupt[60]^=1;ExpectReject(()=>ValidateWorkerReceipt(one.Request,corrupt),"Corrupt receipt accepted");ExpectReject(()=>ValidateWorkerReceipt(one.Request,null),"Missing receipt accepted");return new{valid=3,stale_lanes_rejected=true,corrupt_rejected=true,missing_rejected=true};
    }
    static object RunArgumentRoles(Type recording,MockSetup one)
    {
        var method=recording.GetMethods(All).Single(m=>m.Name=="RunContinuousInFolder"&&m.GetParameters().Length==11);var p=method.GetParameters();
        Need(p.Any(x=>x.Name=="confirmConfiguration")&&p.Any(x=>x.Name=="beforeDeviceDispose"),"Pinned Host223 method lacks named device callback roles");
        var callbackDir=Path.Combine(output,"argument-role-callback");Directory.CreateDirectory(callbackDir);File.WriteAllBytes(Path.Combine(callbackDir,"closed_loop_requested.bin"),one.Request);File.WriteAllBytes(Path.Combine(callbackDir,"closed_loop_control_receipt.bin"),one.Receipt);
        requestedMask=7U;requestedHz=20000U;requestedLanes=1;output=callbackDir;confirmConfigurationCalls=0;beforeDeviceDisposeCalls=0;var args=RunArgs(method,"mock-device");
        Need(args.Length==11&&args.Select((x,i)=>x!=null||p[i].Name=="decodedApRow").All(x=>x),"Pinned Host223 argument construction left a required argument unset");
        ((Delegate)args[Array.FindIndex(p,x=>x.Name=="confirmConfiguration")]).DynamicInvoke(new object[]{null});
        ((Delegate)args[Array.FindIndex(p,x=>x.Name=="beforeDeviceDispose")]).DynamicInvoke(new object[]{null});
        Need(confirmConfigurationCalls==1&&beforeDeviceDisposeCalls==1,"Host223 device callbacks are not bound to their named roles");
        return new{parameters=p.Select(x=>new{name=x.Name,type=x.ParameterType.FullName}).ToArray(),confirm_configuration_calls=confirmConfigurationCalls,before_device_dispose_calls=beforeDeviceDisposeCalls,configure_did_not_dispatch_npcc=true,dispose_is_noop=true};
    }
    static int Selftest(string outDir)
    {
        GuardInputs();Assembly.LoadFrom(Path.Combine(Path.GetDirectoryName(Host),"NpV2SdDatExport.dll"));app=Assembly.LoadFrom(Host);output=Path.GetFullPath(outDir);var worker=File.ReadAllText(WorkerSource);Need(worker.IndexOf("closedLoopSetup=NpClosedLoopSettings.Prepare",StringComparison.Ordinal)<worker.IndexOf("if (confirmConfiguration != null) confirmConfiguration(device)",StringComparison.Ordinal),"Pinned worker no longer stages NPCC before confirmConfiguration");
        var recording=T("USB512_interface.NpV2Recording");var settings=T("USB512_interface.NpClosedLoopSettings");
        var off=MockPrepare(false,0);var one=MockPrepare(true,1);var two=MockPrepare(true,2);var result=new Dictionary<string,object>{{"status","PASS"},{"host_sha256",HostSha},{"sdk_sha256",SdkSha},{"worker_source_sha256",Hash(WorkerSource)},{"hardware_calls",0},{"settings_writes",0},{"mock_prepare",new[]{new{enabled=off.Enabled,lanes=off.Lanes,calls=off.Calls,flags=off.Flags,config_crc=off.ConfigCrc},new{enabled=one.Enabled,lanes=one.Lanes,calls=one.Calls,flags=one.Flags,config_crc=one.ConfigCrc},new{enabled=two.Enabled,lanes=two.Lanes,calls=two.Calls,flags=two.Flags,config_crc=two.ConfigCrc}}},{"receipt_guard",ReceiptGuardSelftest(off,one,two)},{"run_argument_roles",RunArgumentRoles(recording,one)},
            {"run_continuous",Signature(recording,"RunContinuousInFolder")},{"settings_save",Signature(settings,"Save")},
            {"configure_profile",Signature(T("USB512_interface.NpV2UsbDevice"),"ConfigureProfile")},
            {"switch_mode",Signature(T("USB512_interface.NpV2FirmwareForm"),"SwitchUsbMode")},
            {"scope","Reflection/static API only; no device enumeration, open, settings write, or recording."}};
        Directory.CreateDirectory(outDir);File.WriteAllText(Path.Combine(outDir,"usb-selftest.json"),Json.Serialize(result));Console.WriteLine(Json.Serialize(result));return 0;
    }
    static void NeedLease(string lease)
    {
        var text=File.ReadAllText(lease);Need(text.IndexOf("GLOBAL",StringComparison.OrdinalIgnoreCase)>=0&&text.IndexOf(Uid,StringComparison.OrdinalIgnoreCase)>=0&&text.IndexOf("v2_gui_support_fix_20261105",StringComparison.OrdinalIgnoreCase)>=0,"Explicit current GLOBAL+UID closed-loop lease required");
        Report["lease_sha256"]=Hash(lease);
    }
    static string PathNow()
    {return ((IEnumerable)Call(T("CE32_console.NpDownloadNative"),"EnumerateNpPaths")).Cast<string>().Single(p=>p.IndexOf(Uid,StringComparison.OrdinalIgnoreCase)>=0);}
    static object Service(string path){return Call(T("USB512_interface.NpV2FirmwareForm"),"DownloadStatus",path,Uid);}
    static string SettingsPath(){return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"WILDX_console","closed_loop_v2.json");}
    static void SaveSettings(int lanes)
    {
        Report["settings_path"]=SettingsPath();Report["settings_before_sha256"]=File.Exists(SettingsPath())?Hash(SettingsPath()):null;
        var cfg=Activator.CreateInstance(T("USB512_interface.NpClosedLoopSettings"));Set(cfg,"Enabled",lanes!=0);Set(cfg,"MayBeConfigured",true);Set(cfg,"TrainingStartMs",0U);Set(cfg,"TrainingDurationMs",1000U);
        var field=cfg.GetType().GetField("Channels",All);var element=field.FieldType.GetElementType();var rows=Array.CreateInstance(element,Math.Max(1,lanes));
        for(int i=0;i<rows.Length;i++){var row=Activator.CreateInstance(element);Set(row,"Probe",(byte)2);Set(row,"Channel",(ushort)i);Set(row,"Filter",(byte)6);Set(row,"Gain",2.0f);Set(row,"Rectify",true);rows.SetValue(row,i);}field.SetValue(cfg,rows);Call(cfg,"Save",true);
        Report["npcc"]="fresh production Prepare/Start will use P2 ADC0"+(lanes==2?"+1":"")+", filter6/gain2/training1000ms/eventonly";
        Report["p3_native_mapping"]=lanes==0?"closed-loop off":"P2 native ADC0"+(lanes==2?" and1":"")+" at1250Hz";
    }
    static object Await(object value)
    {
        var task=value as Task;Need(task!=null,"Expected production Task");task.GetAwaiter().GetResult();
        var result=task.GetType().GetProperty("Result",All);return result==null?null:result.GetValue(task,null);
    }
    // The 222 worker itself stages NPCC before its read-arm callback.  This
    // callback verifies that immutable worker receipt; issuing another NPCC
    // here would turn a valid disabled receipt into an optional-off null.
    static void ValidateWorkerReceipt(byte[] request,byte[] receipt)
    {
        Need(request!=null&&receipt!=null&&request.Length==64&&receipt.Length==64,"Worker did not stage its fresh NPCC receipt");Need(requestedMask==7U&&requestedHz==20000U,"Unexpected configured 3P/20k profile");
        var enabled=requestedLanes!=0;var parsed=Call(T("WildNpClosedLoop.NpClosedLoopControl"),"Parse",request);
        var reply=Call(T("WildNpClosedLoop.NpClosedLoopControl"),"ParseReply",receipt,1U,BitConverter.ToUInt32(request,12));
        var channels=(Array)Get(parsed,"Channels");Need(N(parsed,"Operation")==1U&&N(parsed,"RequestId")!=0U&&N(reply,"RequestId")==N(parsed,"RequestId")&&N(reply,"Result")==0&&((N(reply,"Flags")&2)!=0)==enabled&&channels.Length==(enabled?requestedLanes:0),"Worker NPCC request identity, enable state, or lane count rejected; ordinary Start refused");
        if(enabled){Need(N(parsed,"ApHz")==requestedHz&&N(parsed,"TrainingStartMs")==0U&&N(parsed,"TrainingDurationMs")==1000U,"Worker NPCC profile/training fields rejected");for(int i=0;i<channels.Length;i++){var row=channels.GetValue(i);Need(N(row,"Probe")==2U&&N(row,"Channel")==0U+(uint)i&&N(row,"Filter")==6U&&Math.Abs(Convert.ToSingle(Get(row,"Gain"))-2.0f)<0.0001f&&Convert.ToBoolean(Get(row,"Rectify")),"Worker NPCC P2 detector selection rejected");}}
        else Need(N(parsed,"ApHz")==0U&&N(parsed,"TrainingStartMs")==0U&&N(parsed,"TrainingDurationMs")==0U,"Worker disabled NPCC request has nonzero payload");
        Need(!enabled?N(reply,"ConfigCrc")==0U:N(reply,"ConfigCrc")==BitConverter.ToUInt32(request,60),"Worker NPCC CRC semantics rejected; ordinary Start refused");
    }
    static void ConfirmConfiguration(object device)
    {
        confirmConfigurationCalls++;
        var request=File.ReadAllBytes(Path.Combine(output,"closed_loop_requested.bin"));var receipt=File.ReadAllBytes(Path.Combine(output,"closed_loop_control_receipt.bin"));
        ValidateWorkerReceipt(request,receipt);
        Report["npcc_receipt_sha256"]=BitConverter.ToString(SHA256.Create().ComputeHash(receipt)).Replace("-","");
    }
    static void BeforeDeviceDispose(object device){beforeDeviceDisposeCalls++;}
    static void IgnoreOne(object ignored){}
    static void Waveform(int index,short[] rows){}
    static object DelegateArg(ParameterInfo parameter)
    {
        var type=parameter.ParameterType;var name=parameter.Name??"";
        var invoke=type.GetMethod("Invoke");var p=invoke.GetParameters();
        if(p.Length==0&&invoke.ReturnType==typeof(bool))return Delegate.CreateDelegate(type,typeof(NpV2ClUsbHil).GetMethod("Cancel",All));
        if(p.Length==1&&invoke.ReturnType==typeof(void)){
            var method=name=="confirmConfiguration"?"ConfirmConfiguration":name=="beforeDeviceDispose"?"BeforeDeviceDispose":p[0].ParameterType.Name=="NpV2RecordingProgress"?"Progress":"IgnoreOne";
            return Delegate.CreateDelegate(type,typeof(NpV2ClUsbHil).GetMethod(method,All));
        }
        if(p.Length==2&&p[0].ParameterType==typeof(int)&&p[1].ParameterType==typeof(short[])&&invoke.ReturnType==typeof(void))return Delegate.CreateDelegate(type,typeof(NpV2ClUsbHil).GetMethod("Waveform",All));
        throw new InvalidOperationException("Unsupported pinned RunContinuousInFolder delegate: "+type);
    }
    static object[] RunArgs(MethodInfo m,string path)
    {
        var a=new object[m.GetParameters().Length];var p=m.GetParameters();
        for(int i=0;i<a.Length;i++){
            var name=p[i].Name??"";
            if(name=="devicePath"&&p[i].ParameterType==typeof(string))a[i]=path;
            else if(name=="folder"&&p[i].ParameterType==typeof(string))a[i]=output;
            else if(name=="decodedApRow")a[i]=null; // Actual GUI preview-off behavior.
            else if(typeof(Delegate).IsAssignableFrom(p[i].ParameterType))a[i]=DelegateArg(p[i]);
            // Preserve the 222 direct-DAT default: retain sensor sidecars, but
            // do not merge probes or request the optional full raw duplicate.
            else if(p[i].ParameterType==typeof(bool)){var n=p[i].Name??"";a[i]=String.Equals(n,"saveSensors",StringComparison.OrdinalIgnoreCase);}
            else if(p[i].ParameterType==typeof(CancellationToken))a[i]=CancellationToken.None;
            else a[i]=p[i].HasDefaultValue?p[i].DefaultValue:null;
        }return a;
    }
    static int Run(string lease,string outDir,int lanes)
    {
        GuardInputs();Need(lanes>=0&&lanes<=2,"Only CL off/one/two lanes are valid");Need(!Directory.Exists(outDir),"Fresh output directory required");Need(new DriveInfo(Path.GetPathRoot(Path.GetFullPath(outDir))).AvailableFreeSpace>=4L*1024*1024*1024,"At least 4GiB free space required");NeedLease(lease);app=Assembly.LoadFrom(Host);output=Path.GetFullPath(outDir);requestedLanes=lanes;Directory.CreateDirectory(output);Report["run_cap_bytes"]=RunCapBytes;
        string path=PathNow();var service=Service(path);Need(N(service,"Mode")==2&&N(service,"Busy")==0&&N(service,"Target")==0,"Exact UID must already be idle USB streaming mode; no mode switch/restart is performed");
        using(var device=(IDisposable)Call(T("USB512_interface.NpV2UsbDevice"),"Open",path)){Need(N(Call(device,"GetCaptureStatus"),"State")==0,"Idle capture required; no reset/replay");var profile=Call(device,"ConfigureProfile",7U,20000U);Need(Convert.ToBoolean(Get(profile,"Valid"))&&N(profile,"SelectedProbeMask")==7U&&N(profile,"SampleHz")==20000U,"Explicit 3P/20k profile admission failed");requestedMask=(uint)N(profile,"SelectedProbeMask");requestedHz=(uint)N(profile,"SampleHz");Report["profile"]=profile;}
        SaveSettings(lanes);wall=Stopwatch.StartNew();var type=T("USB512_interface.NpV2Recording");var method=type.GetMethods(All).Single(m=>m.Name=="RunContinuousInFolder"&&m.GetParameters().Length==11);object result;
        try{result=method.Invoke(null,RunArgs(method,path));}catch(TargetInvocationException e){throw e.InnerException??e;}
        var files=Directory.GetFiles(output,"*",SearchOption.AllDirectories);var bytes=files.Sum(p=>new FileInfo(p).Length);Need(bytes<=RunCapBytes,"Run output exceeded the 5GiB cap");Report["complete"]=Get(result,"Complete");Report["error"]=Get(result,"Error");Report["first_data_seen"]=firstData!=0;Report["result"]=result.GetType().GetFields(All).Where(f=>!f.IsStatic).ToDictionary(f=>f.Name,f=>f.GetValue(result));Report["output_bytes"]=bytes;Report["output_files"]=files.Select(p=>p.Substring(output.Length).TrimStart('\\','/')).ToArray();
        File.WriteAllText(Path.Combine(output,"usb-report.json"),Json.Serialize(Report));Need(Convert.ToBoolean(Get(result,"Complete")),"Meaningful USB failure retained; do not run lanes=2 after a failed lanes=1 run");return 0;
    }
    static int Main(string[] a){try{if(a.Length==2&&a[0]=="selftest")return Selftest(a[1]);if((a.Length==4||a.Length==5)&&a[0]=="run"){if(a.Length==5){targetDataSeconds=Double.Parse(a[4],System.Globalization.CultureInfo.InvariantCulture);Need(targetDataSeconds>=10.0&&targetDataSeconds<=60.0,"Bounded duration10..60s required");}return Run(a[1],a[2],Int32.Parse(a[3]));}throw new ArgumentException("selftest <out> | run <main-owned-lease> <fresh-out> <0|1|2>");}catch(Exception e){Console.Error.WriteLine(e);return 1;}}
}
