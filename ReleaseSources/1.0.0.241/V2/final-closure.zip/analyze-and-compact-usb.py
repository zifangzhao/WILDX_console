from pathlib import Path
import json,hashlib
T=Path(__file__).resolve().parent;r=T/'post-sdinfo-usb-cl0';out=T/'compact/post-sdinfo-usb-cl0';out.mkdir(parents=True,exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
kv=lambda p:dict(l.strip().split('=',1) for l in p.read_text(encoding='utf-8-sig').splitlines() if '=' in l)
rep=load(r/'usb-report.json');a=rep['result'];n=kv(r/'neuropixels_np2usb_status.txt');g=kv(r/'imu_grid_status.txt');enc=kv(r/'analogin_encoding.txt')
checks=dict(complete=rep['complete'] and not rep['error'] and n['complete']=='True',all_np_verified=a['ReceivedBlocks']>0 and a['ReceivedBlocks']==a['VerifiedBlocks'] and not a['RawDroppedBlocks'] and not a['DecodedDroppedLaneBlocks'],firmware_errors_zero=all(n[k]=='0' for k in ('final_capture_error','final_producer_error','final_source_error')),imu_zero_loss=all(g[k]=='0' for k in ('queue_dropped','scheduler_missing','aux_sequence_gap_count')) and g['error']==g['transport_error']=='none',imu_grid_phase=all(g[k]=='True' for k in ('enforced_schedule_verified','phase_qualified','first_source_verified','retirement_confirmed')),imu_all_rows=a['ImuGridObserved']==a['ImuGridRows'] and (r/'analogin.dat').stat().st_size==a['ImuGridRows']*32)
quality=dict(status='PASS' if all(checks.values()) else 'FAIL',usb_crc32='E664B82A',probe_mask=7,hz=20000,detectors=0,seconds=a['DataSeconds'],np_verified=a['VerifiedBlocks'],imu_rows=a['ImuGridRows'],checks=checks,source_window=g['source_window_verified'],final_slot_known=g['final_slot_known'],sensor_encoding=enc,scope='Bounded post-SDInfo USB recording; no new CL qualification; existing immutable NP/IMU/CL data-path object qualification reused')
(r/'quality.json').write_text(json.dumps(quality,indent=2)+'\n');assert quality['status']=='PASS',checks
files=[];removed=0
for p in r.rglob('*.dat'):
 if p.name not in ('neuropixels_ap.dat','timestamps.dat','timestamps_calibrated.dat'):continue
 assert p.resolve().is_relative_to(r.resolve()) and not p.is_symlink()
 rel=p.relative_to(r);size=p.stat().st_size;window=min(size,384*2*64 if p.name=='neuropixels_ap.dat' else 8*64)
 with p.open('rb') as f:first=f.read(window);f.seek(max(0,size-window));last=f.read(window)
 dest=out/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 for suffix,b in [('first64',first),('last64',last)]:
  q=dest.with_name(dest.name+'.'+suffix+'.bin');q.write_bytes(b)
 files.append(dict(path=str(rel),original_bytes=size,window_bytes=window,first_sha256=hashlib.sha256(first).hexdigest().upper(),last_sha256=hashlib.sha256(last).hexdigest().upper()))
 removed+=size;p.unlink()
receipt=dict(status='COMPACT_EVIDENCE_SECURED_GENERATED_NEURAL_PAYLOADS_REMOVED',root=str(r),quality=str(r/'quality.json'),removed_bytes=removed,files=files,kept='Full small IMU/native/grid/status/timing/metadata and bounded first/last64 neural rows. No device or user recording deleted.')
(out/'cleanup.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(dict(status=quality['status'],seconds=a['DataSeconds'],removed_bytes=removed,compact_files=len(files)),indent=2))
