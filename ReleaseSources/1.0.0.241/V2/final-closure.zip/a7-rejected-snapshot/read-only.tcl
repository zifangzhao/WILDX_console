init
set u [read_memory 0x0BFA0700 32 3]
if {[format "%08X%08X%08X" [lindex $u 0] [lindex $u 1] [lindex $u 2]] ne "001A0004434250062039314E"} {error "Wrong MCU"}
if {[lindex [read_memory 0xE000ED08 32 1] 0]!=0x08180000} {error "Wrong role"}
if {[lindex [read_memory 0x0817E020 32 1] 0]!=0xE664B82A} {error "Wrong exact image"}
if {[lindex [read_memory 0x4202C400 32 1] 0]&0x4000} {error "PSSI active"}
if {[lindex [read_memory 0x420C8050 32 1] 0]} {error "SD IDMA active"}
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/np_download_state.bin} 0x20001a8c 4
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/np_download_prefetch.bin} 0x20001b24 24
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/np_download_burst_armed.bin} 0x20001a90 4
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/np_download_burst_remaining.bin} 0x200b02c4 4
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/np2_usb.bin} 0x200b46f8 296
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/xe_np_usb_state.bin} 0x2001d5e8 96
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/xe_np_aux.bin} 0x2001bcc0 240
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/hsd1.bin} 0x200b4370 128
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/usb_sd_test_queued.bin} 0x20001a30 1
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/usb_sd_test_receiving.bin} 0x20001a94 4
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/usb_sd_test_received.bin} 0x20001a98 4
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/usb_sd_test_ack_wait.bin} 0x200b02b8 4
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/usb_sd_test_acked.bin} 0x200b02bc 4
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/usb_sd_test_cancelled.bin} 0x200b02c0 4
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/job_active.bin} 0x200b00e8 4
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/xe_np_usb_maintenance_active.bin} 0x200b02d8 4
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/xe_np_selftest_dirty.bin} 0x20001a24 1
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/xe_np_usb_sd_info_pending.bin} 0x20001a25 1
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/np2_config_receiving.bin} 0x20001a44 4
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/np2_config_pending.bin} 0x20001a88 4
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/rcc.bin} 0x46020c00 64
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/spi1.bin} 0x40013000 64
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/spi2.bin} 0x40003800 64
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/pssi.bin} 0x4202c400 32
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/sdmmc.bin} 0x420c8000 88
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105/a7-rejected-snapshot/gpdma.bin} 0x40020050 2048
shutdown
