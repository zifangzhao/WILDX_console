from pathlib import Path
T=Path(__file__).resolve().parent;P=T.parent/'v2_usb_imu100_20261105'
for old,new in [('hold-leases-r3.ps1','hold-final.ps1'),('backup-original-r3.ps1','backup-final.ps1')]:
 s=(P/old).read_text(encoding='utf-8-sig').replace('owner-r3','owner-final').replace('original-r3','original-final').replace('v2_usb_imu100_20261105/V2','v2_gui_support_fix_20261105/final/V2');(T/new).write_text(s)
d=(P/'deploy-r4.ps1').read_text().replace('deployment-r4','deployment-final').replace('owner-r3','owner-final').replace('CheckedR3 current image changed','Fresh final original image changed');(T/'deploy-final.ps1').write_text(d)
s=(P/'prepare-deployment-r4.py').read_text().replace("O=T/'deployment-r4'","O=T/'deployment-final'").replace("U=T/'r4'","U=T/'build-r4'").replace('original-r3','original-final').replace("sha((T/'deployment-r3/Install-full.bin').read_bytes())","sha(old)")
(T/'prepare-final-pages.py').write_text(s)
s=(P/'finish-restore-r4.ps1').read_text().replace('owner-r3','owner-final').replace('original-r3','original-final').replace('deployment-r4','deployment-final').replace("'restoration-complete.json'","'restoration-final-complete.json'")
# Final SD-job/maintenance APIs never change detector preferences. Any unexpected preference is retained and blocks cleanup.
start=s.index('if(Test-Path -LiteralPath $taskPreferences){');end=s.index("if(Test-Path -LiteralPath $taskPreferences){throw 'Original absent preference not restored'}",start)
s=s[:start]+s[end:]
s=s.replace("card_writes_in_this_task=$false;card_format_or_delete=$false","own_record_verified=(Test-Path (Join-Path $taskRoot 'sd-job-final/own-verified.json'));own_delete_verified=(Test-Path (Join-Path $taskRoot 'delete-own-final/preserved.json'));card_format=$false;card_actions_scope='See explicit SD-job and delete-own receipts; no old recording deletion authorized'")
(T/'finish-final.ps1').write_text(s)
p=T/'NpV2MaintenanceHil.cs';s=p.read_text().replace('Root+"/owner/lease.json"','Root+"/owner-final/lease.json"');p.write_text(s)
print('Prepared fresh final lease/backup/pages/restore adapters; helper now pins final owner path; no hardware calls')
