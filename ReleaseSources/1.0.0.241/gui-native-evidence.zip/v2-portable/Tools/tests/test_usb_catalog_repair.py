"""Actual foreground USB adapter + portable catalog, with software HAL/USB only."""
import argparse
import hashlib
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'Tools/Power'))
sys.path.insert(0, str(ROOT / 'Tools/V2SdLogger/tests'))
from test_sd_high_two_classic import invoke
from test_np2_counted_hal_irq_native import constants

MODEL = r'''
#define main historical_catalog_suite_not_executed
#include "@CATALOG_TEST@"
#undef main
/* Reuse the existing sparse card/real metadata setup, not a synthetic mount. */
typedef enum {HAL_OK=0,HAL_ERROR=1} HAL_StatusTypeDef;
typedef uint32_t HAL_SD_CardStateTypeDef;
#define HAL_SD_STATE_READY 1U
#define HAL_SD_CARD_TRANSFER 4U
#define HAL_SD_CARD_PROGRAMMING 7U
#define HAL_SD_CARD_ERROR 255U
typedef struct {volatile uint32_t CLKCR,STA,IDMACTRL,DCTRL,RESPCMD,RESP1;} SDMMC_TypeDef;
static SDMMC_TypeDef sd_regs;
#define SDMMC1 (&sd_regs)
typedef struct {SDMMC_TypeDef *Instance;uint32_t State,ErrorCode,Context;
 struct {uint32_t LogBlockNbr;} SdCard;uint32_t CID[4];} SD_HandleTypeDef;
static SD_HandleTypeDef hsd1;
typedef struct {uint32_t token;} PCD_HandleTypeDef;
typedef struct {uint8_t bmRequest,bRequest;uint16_t wValue,wIndex,wLength;} XE_NP_UsbSetup;
static PCD_HandleTypeDef fixture_pcd;
static struct {PCD_HandleTypeDef *hpcd;uint32_t configured,bootloader_reset_pending,
 bootloader_reset_armed,streaming,real_start_pending,tx_busy,tx_pending;} xe_np_usb_state;
static struct {uint32_t target;} xe_np_usb_mode;
static uint32_t xe_np_usb_sd_info_pending,np_download_state,np_download_burst_armed;
static uint32_t np_download_burst_remaining,np_download_epoch,np2_config_receiving,np2_config_pending;
static struct {uint32_t valid;} np_download_prefetch;
static uint32_t download,selftest,aux,np2busy,sourcebusy,sourceready,armed;
typedef struct {uint32_t CR,CR1;} Peripheral;
static Peripheral pssi,spi1,spi2;
static struct {uint32_t CFGR1;} rcc;
#define PSSI (&pssi)
#define SPI1 (&spi1)
#define SPI2 (&spi2)
#define RCC (&rcc)
#define PSSI_CR_ENABLE 1U
#define SPI_CR1_SPE 1U
#define RCC_CFGR1_MCOSEL 0xFU
#define RCC_CFGR1_MCOPRE 0xF0U
#define DMA_CCR_EN 1U
#define DMA_CCR_RESET 2U
#define DMA_CCR_SUSP 4U
typedef struct {volatile uint32_t CCR;uint8_t pad[124];} DMA_Channel_TypeDef;
static DMA_Channel_TypeDef dma[16];
#define GPDMA1_Channel0 (&dma[0])
static uint32_t primask,ipsr,basepri,faultmask,tick,stalls,acks,sends,dsbs;
static uint32_t hal_reads,hal_writes,polls,rdy_wait,program_wait,poll_timeout;
static uint32_t cancel_read,cancel_write,epoch_read,identity_read,owner_read,active_read;
static uint32_t sent[16];
#define __get_PRIMASK() primask
#define __get_IPSR() ipsr
#define __get_BASEPRI() basepri
#define __get_FAULTMASK() faultmask
#define __disable_irq() (primask=1U)
#define __set_PRIMASK(key) (primask=(key))
#define __DMB() ((void)0)
#define __DSB() (++dsbs)
static uint32_t HAL_GetTick(void){return tick++;}
static int XE_NP_UsbUnified_IsDownload(void){return download!=0U;}
static int xe_np_usb_selftest_busy(void){return selftest!=0U;}
static int XE_NP_UsbAux_IsBusy(void){return aux!=0U;}
static int np2_usb_busy(void){return np2busy!=0U;}
static int XE_NP_Np2UsbSource_IsBusy(void){return sourcebusy!=0U;}
static int XE_NP_Np2UsbSource_IsReady(void){return sourceready!=0U;}
static int XE_NP_Np2CapturePort_Armed(void){return armed!=0U;}
static uint32_t NP_SD_DownloadCapacity(void){return download?hsd1.SdCard.LogBlockNbr:0U;}
static void XE_NP_UsbStream_Stall(PCD_HandleTypeDef *p){(void)p;stalls++;}
static void XE_NP_UsbStream_CtlStatus(PCD_HandleTypeDef *p){assert(p==&fixture_pcd);acks++;}
static void XE_NP_UsbStream_CtlSend(PCD_HandleTypeDef *p,const uint8_t *b,uint32_t n,uint32_t requested){
 assert(p==&fixture_pcd && n==64U && requested==64U);memcpy(sent,b,64U);sends++;
}
static void xe_np_usb_catalog_cancel(void);
static HAL_StatusTypeDef HAL_SD_ReadBlocks(SD_HandleTypeDef *h,uint8_t *out,uint32_t lba,uint32_t n,uint32_t timeout){
 assert(!ipsr && !primask && h==&hsd1 && n==1U && timeout==1000U && (h->Instance->CLKCR&1023U)==8U);
 assert(!((uintptr_t)out&31U));hal_reads++;h->Context=SD_CONTEXT_READ_SINGLE_BLOCK;
 int result=read_sector(NULL,lba,out);
 if(cancel_read==hal_reads)xe_np_usb_catalog_cancel();
 if(epoch_read==hal_reads)np_download_epoch++;
 if(identity_read==hal_reads)hsd1.CID[0]^=1U;
 if(owner_read==hal_reads)dma[5].CCR=DMA_CCR_EN;
 if(active_read==hal_reads){sd_regs.DCTRL=SDMMC_DCTRL_DTEN;sd_regs.STA=SDMMC_STA_DPSMACT;sd_regs.IDMACTRL=1U;}
 return result?HAL_ERROR:HAL_OK;
}
static HAL_StatusTypeDef HAL_SD_WriteBlocks(SD_HandleTypeDef *h,uint8_t *in,uint32_t lba,uint32_t n,uint32_t timeout){
 assert(!ipsr && !primask && h==&hsd1 && n==1U && timeout==1000U && (h->Instance->CLKCR&1023U)==8U);
 assert(!((uintptr_t)in&31U) && (lba==112U || lba==113U || (lba>=128U && lba<1152U)));
 hal_writes++;h->Context=SD_CONTEXT_WRITE_SINGLE_BLOCK;
 int result=write_sector(NULL,lba,in);
 if(cancel_write==hal_writes)xe_np_usb_catalog_cancel();
 return result?HAL_ERROR:HAL_OK;
}
static HAL_SD_CardStateTypeDef HAL_SD_GetCardState(SD_HandleTypeDef *h){
 assert(!ipsr && !primask && h==&hsd1);polls++;h->Instance->RESPCMD=13U;
 h->Instance->RESP1=(rdy_wait || poll_timeout)?0U:(1U<<8U);
 if(rdy_wait){rdy_wait--;assert(h->Context!=SD_CONTEXT_NONE);}
 if(program_wait){program_wait--;return HAL_SD_CARD_PROGRAMMING;}
 return HAL_SD_CARD_TRANSFER;
}
'''

CASES = r'''
static void reset_usb(void){
 memset(&xe_np_usb_catalog,0,sizeof(xe_np_usb_catalog));
 memset(xe_np_usb_catalog_report,0,64U);
 xe_np_usb_catalog_report[0]=XE_NP_USB_CATALOG_MAGIC;xe_np_usb_catalog_report[1]=1U;
 memset(&sd_regs,0,sizeof(sd_regs));memset(dma,0,sizeof(dma));
 memset(&xe_np_usb_state,0,sizeof(xe_np_usb_state));
 memset(&pssi,0,sizeof(pssi));memset(&spi1,0,sizeof(spi1));memset(&spi2,0,sizeof(spi2));rcc.CFGR1=0U;
 hsd1.Instance=SDMMC1;hsd1.State=HAL_SD_STATE_READY;hsd1.ErrorCode=hsd1.Context=0U;
 hsd1.SdCard.LogBlockNbr=card.capacity;for(uint32_t i=0U;i<4U;i++)hsd1.CID[i]=i+1U;
 sd_regs.CLKCR=0x002B4000U;xe_np_usb_state.hpcd=&fixture_pcd;xe_np_usb_state.configured=1U;
 download=1U;selftest=aux=np2busy=sourcebusy=sourceready=armed=0U;xe_np_usb_mode.target=0U;
 np_download_state=np_download_burst_armed=np_download_burst_remaining=np_download_prefetch.valid=0U;
 np2_config_receiving=np2_config_pending=xe_np_usb_sd_info_pending=0U;
 np_download_epoch=7U;primask=ipsr=basepri=faultmask=tick=stalls=acks=sends=dsbs=0U;
 hal_reads=hal_writes=polls=rdy_wait=program_wait=poll_timeout=0U;
 cancel_read=cancel_write=epoch_read=identity_read=owner_read=active_read=0U;
}
static void request(uint32_t operation,uint32_t nonce){
 XE_NP_UsbSetup r={0x40U,(uint8_t)operation,(uint16_t)nonce,(uint16_t)(nonce>>16U),0U};
 uint32_t reads=card.reads,writes=card.writes;ipsr=16U;
 assert(xe_np_usb_catalog_request(&fixture_pcd,&r)==1);ipsr=0U;
 assert(card.reads==reads && card.writes==writes); /* SETUP never touches storage. */
}
static void report(void){
 XE_NP_UsbSetup r={0xC0U,XE_NP_USB_CATALOG_REPORT,0U,0U,64U};
 assert(xe_np_usb_catalog_request(&fixture_pcd,&r)==1);
 assert(sent[0]==XE_NP_USB_CATALOG_MAGIC && sent[1]==1U);
}
static void run(uint32_t operation,uint32_t nonce,uint32_t state){
 uint32_t saved=sd_regs.CLKCR;request(operation,nonce);assert(xe_np_usb_catalog_busy());
 xe_np_usb_catalog_service();report();
 assert((uint32_t)(xe_np_usb_catalog_busy()!=0)==xe_np_usb_catalog.sector_owned);
 assert(sent[3]==state && sent[4]==nonce && primask==0U);
 assert(sd_regs.CLKCR==(xe_np_usb_catalog.clock_held?xe_np_usb_catalog.metadata_clock:saved));
}
static XE_NP_Np2DualSdMeta fresh_record(uint32_t blocks){
 XE_NP_Np2DualSdMeta m=interrupted(blocks);reset_usb();return m;
}
static void positive(void){
 XE_NP_Np2DualSdMeta m=fresh_record(400U);uint8_t d[512],f[512];
 assert(!read_sector(NULL,m.reservation_start_lba+3U,d));assert(!read_sector(NULL,m.reservation_start_lba+4U,f));
 uint32_t writes=card.writes;run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_COMPLETE);
 assert(card.writes==writes && sent[14]==1U && sent[15]==7U && sent[6]==card.capacity);
 assert(sent[9]==XE_NP_Np2DualSd_Crc32((const uint8_t *)hsd1.CID,16U));
 assert(!memcmp(sent+10U,hsd1.CID,16U));
 report();uint32_t cached[16];memcpy(cached,sent,64U);
 xe_np_usb_catalog_report[8]^=1U;assert(!memcmp(cached,xe_np_usb_catalog_ep0,64U));xe_np_usb_catalog_report[8]^=1U;
 rdy_wait=2U;program_wait=2U;
 run(XE_NP_USB_CATALOG_REPAIR,2U,XE_NP_USB_CATALOG_COMPLETE);
 assert(sent[8]==m.reservation_end_lba && !sent[5] && hal_writes==4U && polls>hal_reads+hal_writes);
 assert_original_allocation(&m,d,f); /* Descriptor/footer and both payload canaries unchanged. */
 uint32_t after=card.writes;request(XE_NP_USB_CATALOG_REPAIR,2U);
 assert(stalls && !xe_np_usb_catalog_busy() && card.writes==after);
 request(XE_NP_USB_CATALOG_REPAIR,3U);assert(!xe_np_usb_catalog_busy()); /* Consumed INSPECT. */
}
static void refusals(void){
 (void)fresh_record(400U);
 volatile uint32_t *guards[]={&download,&xe_np_usb_state.configured,&np_download_state,&np_download_burst_armed,
  &np_download_burst_remaining,&np_download_prefetch.valid,&selftest,&aux,&np2busy,&sourcebusy,&sourceready,&armed,
  &np2_config_receiving,&np2_config_pending,&xe_np_usb_mode.target,&xe_np_usb_state.bootloader_reset_pending,
  &xe_np_usb_state.bootloader_reset_armed,&xe_np_usb_state.streaming,&xe_np_usb_state.real_start_pending,
  &xe_np_usb_state.tx_busy,&xe_np_usb_state.tx_pending,&xe_np_usb_sd_info_pending,
  &hsd1.ErrorCode,&hsd1.Context,&sd_regs.IDMACTRL,&sd_regs.DCTRL,&sd_regs.STA,
  &pssi.CR,&spi1.CR1,&spi2.CR1,&rcc.CFGR1,&dma[15].CCR};
 for(unsigned i=0U;i<sizeof(guards)/sizeof(guards[0]);i++){
  reset_usb();uint32_t old=*guards[i];
  *guards[i]=i<2U?0U:1U;
  if(guards[i]==&sd_regs.DCTRL)*guards[i]=SDMMC_DCTRL_DTEN;
  if(guards[i]==&sd_regs.STA)*guards[i]=SDMMC_STA_DPSMACT;
  request(XE_NP_USB_CATALOG_INSPECT,1U);assert(stalls==1U && !xe_np_usb_catalog_busy());*guards[i]=old;
 }
 const uint32_t status[]={SDMMC_STA_DPSMACT,SDMMC_STA_CPSMACT,SDMMC_STA_BUSYD0,SDMMC_STA_DTIMEOUT};
 for(unsigned i=0U;i<4U;i++){reset_usb();sd_regs.STA=status[i];request(XE_NP_USB_CATALOG_INSPECT,1U);assert(stalls);}
 for(unsigned i=0U;i<16U;i++)for(uint32_t bit=1U;bit<=4U;bit<<=1U){
  reset_usb();dma[i].CCR=bit;request(XE_NP_USB_CATALOG_INSPECT,1U);assert(stalls);
 }
 reset_usb();hsd1.State=2U;request(XE_NP_USB_CATALOG_INSPECT,1U);assert(stalls);
 reset_usb();hsd1.Instance=NULL;request(XE_NP_USB_CATALOG_INSPECT,1U);assert(stalls);
 reset_usb();XE_NP_UsbSetup bad={0xC0U,XE_NP_USB_CATALOG_INSPECT,1U,0U,0U};
 assert(xe_np_usb_catalog_request(&fixture_pcd,&bad)==1 && stalls && !hal_reads && !hal_writes);
 reset_usb();bad.bmRequest=0x40U;bad.wLength=1U;
 assert(xe_np_usb_catalog_request(&fixture_pcd,&bad)==1 && stalls && !hal_reads && !hal_writes);
 reset_usb();bad.bRequest=0xA3U;assert(!xe_np_usb_catalog_request(&fixture_pcd,&bad));
 reset_usb();request(XE_NP_USB_CATALOG_REPAIR,1U);assert(stalls && !hal_writes);
 reset_usb();request(XE_NP_USB_CATALOG_INSPECT,2U);assert(stalls && !xe_np_usb_catalog_busy());
 reset_usb();request(XE_NP_USB_CATALOG_INSPECT,1U);request(XE_NP_USB_CATALOG_INSPECT,2U);assert(stalls && xe_np_usb_catalog.queued);
 xe_np_usb_catalog_cancel();assert(!xe_np_usb_catalog_busy() && !xe_np_usb_catalog.inspected);
 xe_np_usb_catalog_service();assert(!hal_reads && !hal_writes);
 reset_usb();xe_np_usb_catalog.last_nonce=UINT32_MAX;request(XE_NP_USB_CATALOG_INSPECT,0U);assert(stalls);
}
static void invalidation(void){
 for(unsigned which=0U;which<4U;which++){
  (void)fresh_record(400U);run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_COMPLETE);
  switch(which){case 0:np_download_epoch++;break;case 1:hsd1.CID[0]++;break;
   case 2:hsd1.SdCard.LogBlockNbr--;break;default:xe_np_usb_catalog_cancel();break;}
  request(XE_NP_USB_CATALOG_REPAIR,2U);assert(stalls && !hal_writes);
  if(which==3U){report();assert(sent[3]==XE_NP_USB_CATALOG_FAILED && sent[5]==XE_NP_USB_CATALOG_CANCELLED && !sent[14]);}
 }
 for(unsigned which=0U;which<4U;which++){
  (void)fresh_record(400U);
  switch(which){case 0:cancel_read=1U;break;case 1:epoch_read=1U;break;
   case 2:identity_read=1U;break;default:owner_read=1U;break;}
  run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_FAILED);
  assert(hal_reads==1U && !hal_writes && hsd1.Context==SD_CONTEXT_READ_SINGLE_BLOCK);
  assert(!xe_np_usb_catalog.inspected && xe_np_usb_catalog_busy());
 }
 (void)fresh_record(400U);poll_timeout=1U;
 run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_FAILED);
 assert(polls>=1000U && hsd1.Context==SD_CONTEXT_READ_SINGLE_BLOCK && !hal_writes);
 assert(xe_np_usb_catalog_rescue_ready());uint32_t context=hsd1.Context;
 sd_regs.STA=SDMMC_STA_DPSMACT;assert(!xe_np_usb_catalog_rescue_ready());sd_regs.STA=SDMMC_STA_CPSMACT;
 assert(!xe_np_usb_catalog_rescue_ready());sd_regs.STA=SDMMC_STA_BUSYD0;assert(!xe_np_usb_catalog_rescue_ready());
 sd_regs.STA=0U;sd_regs.IDMACTRL=1U;assert(!xe_np_usb_catalog_rescue_ready());sd_regs.IDMACTRL=0U;
 sd_regs.DCTRL=SDMMC_DCTRL_DTEN;assert(!xe_np_usb_catalog_rescue_ready());sd_regs.DCTRL=0U;
 armed=1U;assert(!xe_np_usb_catalog_rescue_ready());armed=0U;
 xe_np_usb_catalog_cancel();assert(xe_np_usb_catalog_busy() && xe_np_usb_catalog_rescue_ready() && hsd1.Context==context);
 (void)fresh_record(400U);active_read=1U;
 run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_FAILED);
 assert(xe_np_usb_catalog.clock_held && xe_np_usb_catalog_busy() && !xe_np_usb_catalog_rescue_ready());
 assert(sd_regs.CLKCR==xe_np_usb_catalog.metadata_clock && hsd1.Context==SD_CONTEXT_READ_SINGLE_BLOCK);
 sd_regs.DCTRL=sd_regs.STA=sd_regs.IDMACTRL=0U; /* Model later hardware quiet, not helper retirement. */
 assert(xe_np_usb_catalog_rescue_ready() && hsd1.Context==SD_CONTEXT_READ_SINGLE_BLOCK);
 assert(sd_regs.CLKCR==xe_np_usb_catalog.metadata_clock); /* The query does not retime it. */
}
static void append_metadata(void){
 setup();uint32_t next=0U;uint8_t system[512]={0},config[2048]={0},d[512],f[512],b[512];
 XE_NP_Np2DualSdMeta m={0};
 assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
 assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
 assert(!XE_NP_Np2DualSdCatalog_PlanProfile(3U,20000U,8U,992U,crc32(config,2048U),&m));
 assert(!XE_NP_Np2DualSdCatalog_ReserveAppend(&m,config));reboot();reset_usb();
 assert(!read_sector(NULL,m.reservation_start_lba+3U,d) && get32(d+8U)==14U);
 assert(!read_sector(NULL,m.reservation_start_lba+4U,f));
 run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_COMPLETE);
 run(XE_NP_USB_CATALOG_REPAIR,2U,XE_NP_USB_CATALOG_COMPLETE);
 assert(sent[8]==m.reservation_end_lba);
 assert(!read_sector(NULL,m.reservation_start_lba+3U,b) && !memcmp(b,d,512U));
 assert(!read_sector(NULL,m.reservation_start_lba+4U,b) && !memcmp(b,f,512U));
}
static void damaged(void){
 XE_NP_Np2DualSdMeta m=fresh_record(400U);uint8_t b[512];
 assert(!read_sector(NULL,m.reservation_start_lba+4U,b));b[508]^=1U;
 assert(!write_sector(NULL,m.reservation_start_lba+4U,b));
 assert(!read_sector(NULL,m.reservation_start_lba+3U,b));b[508]^=1U;
 assert(!write_sector(NULL,m.reservation_start_lba+3U,b));
 uint32_t writes=card.writes;run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_FAILED);assert(card.writes==writes);
 request(XE_NP_USB_CATALOG_REPAIR,2U);assert(stalls && !hal_writes);
 m=fresh_record(1244U);assert(m.reservation_end_lba==card.capacity);
 run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_FAILED);
 assert(sent[7]&XE_NP_NP2_CATALOG_FULL);writes=card.writes;
 request(XE_NP_USB_CATALOG_REPAIR,2U);assert(stalls && card.writes==writes);
 for(uint32_t cut=1U;cut<=4U;cut++){
  (void)fresh_record(400U);run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_COMPLETE);
  card.failed_write=card.writes+cut;card.torn_write=cut&1U;
  run(XE_NP_USB_CATALOG_REPAIR,2U,XE_NP_USB_CATALOG_FAILED);
  uint32_t after=card.writes;xe_np_usb_catalog_service();assert(card.writes==after);
  /* Explicit new INSPECT after a modeled target restart; never replay the write. */
  card.failed_write=0U;card.torn_write=0U;reset_usb();
  run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_COMPLETE);
  run(XE_NP_USB_CATALOG_REPAIR,2U,XE_NP_USB_CATALOG_COMPLETE);
 }
 (void)fresh_record(400U);run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_COMPLETE);
 cancel_write=1U;run(XE_NP_USB_CATALOG_REPAIR,2U,XE_NP_USB_CATALOG_FAILED);
 assert(hal_writes==1U && !xe_np_usb_catalog.inspected);
}
int main(void){positive();refusals();invalidation();damaged();append_metadata();
 puts("PASS actual USB foreground catalog adapter/real metadata: no SETUP I/O, explicit recovery, owner/epoch/nonce/bounds/fault guards; modeled HAL only");return 0;}
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-directory', required=True, type=Path)
    args = parser.parse_args()
    out = args.output_directory.resolve()
    out.mkdir(parents=True, exist_ok=False)
    path = ROOT / 'Core/Src/xe_np_usb_catalog.inc'
    adapter = path.read_text()
    assert not re.search(r'Catalog_(?:Format|Rewind|Reserve|Finish|Delete)', adapter)
    # Only translate GCC declaration alignment for MSVC; actual adapter logic
    # and every catalog/meta implementation remain unmodified.
    adapter, aligned = re.subn(r'(?m)^(static (?:uint8_t|uint32_t) xe_np_usb_catalog_(?:read|write|ep0)\[[^;]+\]) __attribute__\(\(aligned\(32\)\)\);',
                              r'__declspec(align(32)) \1;', adapter)
    assert aligned == 3 and adapter.count('__attribute__((noinline))') == 1
    adapter = adapter.replace('__attribute__((noinline))', '__declspec(noinline)')
    assert '__attribute__' not in adapter
    actual = out / 'actual_adapter.inc'
    actual.write_text(adapter)
    off = out / 'default_off.c'
    off.write_text('#include <stdint.h>\n#include <assert.h>\n'
        'typedef struct {int unused;} PCD_HandleTypeDef;\n'
        'typedef struct {int unused;} XE_NP_UsbSetup;\n#include "actual_adapter.inc"\n'
        'int main(void){PCD_HandleTypeDef p={0};XE_NP_UsbSetup r={0};'
        'assert(!xe_np_usb_catalog_busy() && !xe_np_usb_catalog_rescue_ready() && !xe_np_usb_catalog_request(&p,&r));'
        'xe_np_usb_catalog_service();xe_np_usb_catalog_cancel();return 0;}\n')
    invoke(out, 'default_off', off, {})
    model = MODEL.replace('@CATALOG_TEST@', (ROOT / 'Tools/V2SdLogger/tests/test_np2_dual_sd_catalog.c').as_posix())
    fixture = out / 'native.c'
    fixture.write_text(constants(adapter + MODEL + CASES, cmsis='stm32u595xx.h') + model + '\n#include "actual_adapter.inc"\n' + CASES)
    definitions = {'XE_NP_USB_CATALOG_REPAIR_ENABLE': '1U', 'XE_NP_NP2_SD_CATALOG_ENABLE': '1U',
                   'XE_NP_NP2_SD_APPEND_ORDER_TEST': '1U',
                   'XE_NP_NP2_USB_SOURCE_ENABLE': '1U', 'NP_SD_USB_PREFETCH': '1U', 'NP_SD_USB_CONTINUOUS': '1U'}
    sources = tuple(ROOT / ('Core/Src/' + name + '.c') for name in
        ('xe_np_np2_dual_sd_catalog', 'xe_np_np2_dual_sd_meta', 'xe_np_np2_dual_sd_run'))
    invoke(out, 'adapter', fixture, definitions, extra_sources=sources)
    boolean = out / 'boolean.c'
    boolean.write_text('#include "xe_np_usb_catalog.h"\nint main(void){return 0;}\n')
    invoke(out, 'boolean', boolean, {'XE_NP_USB_CATALOG_REPAIR_ENABLE': '2U'},
           expected_error='USB catalog repair must be an explicit boolean')
    print('Adapter SHA256 ' + hashlib.sha256(path.read_bytes()).hexdigest().upper())


if __name__ == '__main__':
    main()
