#include "xe_np_np2_dual_sd_catalog.h"
#define NP_SD_VSC 1
#define NP_SD_CE64 1
#define NP_SD_MEDIA_METADATA 1
#include "../../../Firmware/V1/Core/Inc/np_ce64.h"
#include "../../../Firmware/V1/Core/Inc/np_media_metadata.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

typedef struct {uint32_t lba;uint8_t bytes[512];} Slot;
enum {MODEL_SECTORS=128}; /* Nine real metadata records in the mixed-profile check. */
typedef struct {
    Slot slot[MODEL_SECTORS];uint32_t count,reads,writes,commands,failed_lba,failed_write,capacity;
    uint32_t failed_read_lba,torn_write;
} CardModel;
static CardModel card;

static uint32_t get32(const uint8_t *p)
{return (uint32_t)p[0]|((uint32_t)p[1]<<8U)|((uint32_t)p[2]<<16U)|((uint32_t)p[3]<<24U);}
static uint32_t crc32(const uint8_t *p,uint32_t n)
{
    uint32_t value=UINT32_MAX;
    while(n--){value^=*p++;for(uint32_t i=0U;i<8U;i++)
        value=(value>>1U)^((value&1U)?0xEDB88320U:0U);}
    return ~value;
}
static int read_sector(void *unused,uint32_t lba,uint8_t out[512])
{
    (void)unused;card.reads++;if(lba==card.failed_read_lba)return -1;memset(out,0,512U);
    for(uint32_t i=0U;i<card.count;i++)if(card.slot[i].lba==lba){
        memcpy(out,card.slot[i].bytes,512U);break;
    }
    return 0;
}
static int write_sector(void *unused,uint32_t lba,const uint8_t in[512])
{
    (void)unused;int fail=card.writes+1U==card.failed_write;
    if(lba==card.failed_lba || (fail && !card.torn_write))return -1;
    assert(lba<card.capacity && card.count<MODEL_SECTORS);
    uint32_t index=card.count;
    for(uint32_t i=0U;i<card.count;i++)if(card.slot[i].lba==lba){index=i;break;}
    if(index==card.count){card.slot[index].lba=lba;card.count++;}
    memcpy(card.slot[index].bytes,in,fail?256U:512U);card.writes++;return fail?-1:0;
}
static int command(void *unused,uint32_t argument)
{
    (void)unused;assert((argument&0xF8FFFFFFU)==0x88000000U);
    card.commands++;return 0;
}
static void setup(void)
{
    memset(&card,0,sizeof(card));card.failed_lba=card.failed_read_lba=UINT32_MAX;card.capacity=131072U;
    XE_NP_Np2DualSdCatalogIo io={0};
    io.read_sector=read_sector;io.write_sector=write_sector;
    io.stopped_command=command;io.card_blocks=131072U;
    io.cid[0]=1U;io.cid[1]=2U;io.cid[2]=3U;io.cid[3]=4U;
    assert(XE_NP_Np2DualSdCatalog_Bind(&io)==0);
}
static void test_two_sessions(void)
{
    setup();uint32_t next=0U;
    assert(XE_NP_Np2DualSdCatalog_Mount(&next)<0);
    static const uint8_t system[512]="WILD-X V2 dual-NP2 logger";
    assert(XE_NP_Np2DualSdCatalog_Format(0U,system)<0);
    assert(!card.writes);
    assert(XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system)==0);
    assert(card.commands==8U);
    assert(XE_NP_Np2DualSdCatalog_Mount(&next)==0 && next==8192U);
    uint8_t config[2048]={0};memcpy(config,"NP2 dual static profile",23U);
    XE_NP_Np2DualSdMeta m={0};
    assert(XE_NP_Np2DualSdCatalog_Plan(20000U,8U,0x91823457U,crc32(config,2048U),&m)==0);
    assert(m.reservation_start_lba==8192U && m.run.payload_start_lba==16384U &&
           m.reservation_end_lba==32768U && m.run.max_blocks>=8U);
    assert(XE_NP_Np2DualSdCatalog_Reserve(&m,config)==0);
    assert(XE_NP_Np2DualSdCatalog_Mount(&next)<0);
    uint8_t descriptor[512],footer[512],directory[512],saved_config[512];
    assert(read_sector(NULL,8195U,descriptor)==0);
    assert(read_sector(NULL,8196U,footer)==0);
    uint32_t state=0U,error=0U,blocks=0U;
    assert(XE_NP_Np2DualSd_DecodeFooter(descriptor,footer,&state,&error,&blocks)==0 &&
           state==XE_NP_NP2_DUAL_SD_META_RESERVED && error==1U && blocks==0U);
    assert(read_sector(NULL,8200U,saved_config)==0 && !memcmp(saved_config,config,512U));
    assert(read_sector(NULL,128U,directory)==0 && get32(directory)==1U &&
           get32(directory+4U)==16384U && get32(directory+256U)==16384U);
    assert(XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0U,8U)==0);
    assert(read_sector(NULL,8196U,footer)==0);
    assert(XE_NP_Np2DualSd_DecodeFooter(descriptor,footer,&state,&error,&blocks)==0 &&
           state==XE_NP_NP2_DUAL_SD_META_COMPLETE && !error && blocks==8U);
    assert(XE_NP_Np2DualSdCatalog_Mount(&next)==0 && next==24576U);
    assert(XE_NP_Np2DualSdCatalog_Plan(30000U,12U,0x91823458U,crc32(config,2048U),&m)==0);
    assert(m.reservation_start_lba==24576U && m.run.payload_start_lba==32768U &&
           m.reservation_end_lba==49152U);
    assert(XE_NP_Np2DualSdCatalog_Reserve(&m,config)==0);
    assert(XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_FAILED,9U,4U)==0);
    assert(read_sector(NULL,24580U,footer)==0);
    assert(read_sector(NULL,24579U,descriptor)==0);
    assert(XE_NP_Np2DualSd_DecodeFooter(descriptor,footer,&state,&error,&blocks)==0 &&
           state==XE_NP_NP2_DUAL_SD_META_FAILED && error==9U && blocks==4U);
    assert(XE_NP_Np2DualSdCatalog_Mount(&next)==0 && next==m.reservation_end_lba && next==49152U);
    puts("PASS dual-NP2 catalog: format, read-only mount, two durable 20/30-kHz reservations and terminal footers");
}
static void test_failed_footer_is_not_complete(void)
{
    setup();uint32_t next=0U;
    uint8_t system[512]={0},config[2048]={0};
    assert(XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system)==0);
    assert(XE_NP_Np2DualSdCatalog_Mount(&next)==0);
    XE_NP_Np2DualSdMeta m={0};
    assert(XE_NP_Np2DualSdCatalog_Plan(20000U,8U,1U,crc32(config,2048U),&m)==0);
    assert(XE_NP_Np2DualSdCatalog_Reserve(&m,config)==0);
    card.failed_lba=8196U;
    assert(XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0U,8U)<0);
    card.failed_lba=UINT32_MAX;
    uint8_t descriptor[512],footer[512];uint32_t state=0U,error=0U,blocks=0U;
    assert(read_sector(NULL,8195U,descriptor)==0 && read_sector(NULL,8196U,footer)==0);
    assert(XE_NP_Np2DualSd_DecodeFooter(descriptor,footer,&state,&error,&blocks)==0 &&
           state==XE_NP_NP2_DUAL_SD_META_RESERVED && error==1U && blocks==0U);
    puts("PASS dual-NP2 catalog: terminal write failure leaves reserved, never optimistic COMPLETE");
}
static void test_trim_journal_failure_retains_reservation(void)
{
    setup();uint32_t next=0U;uint8_t system[512]={0},config[2048]={0};
    assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    XE_NP_Np2DualSdMeta m={0};
    assert(!XE_NP_Np2DualSdCatalog_Plan(20000U,400U,5U,crc32(config,2048U),&m));
    assert(!XE_NP_Np2DualSdCatalog_Reserve(&m,config));
    card.failed_lba=128U; /* Fail directory write after durable shadow/journal. */
    assert(XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0,4)<0);
    uint8_t directory[512],journal[512];
    assert(!read_sector(NULL,128U,directory) && get32(directory+4)==m.run.payload_start_lba);
    assert(!read_sector(NULL,112U,journal) && !memcmp(journal,"NPC64TX1",8));
    assert(XE_NP_Np2DualSdCatalog_Mount(&next)<0);
}
static void rebind_card(uint32_t card_blocks,uint32_t cid0)
{
    card.capacity=card_blocks;
    XE_NP_Np2DualSdCatalogIo io={0};io.read_sector=read_sector;io.write_sector=write_sector;
    io.stopped_command=command;io.card_blocks=card_blocks;
    io.cid[0]=cid0;io.cid[1]=2U;io.cid[2]=3U;io.cid[3]=4U;
    assert(!XE_NP_Np2DualSdCatalog_Bind(&io));
}
static void reboot(void){rebind_card(131072U,1U);}
static void test_counter_wrap_remount(uint32_t rate)
{
    static const uint32_t counts[]={69904U,69908U,92180U,92184U};
    for(uint32_t n=0U;n<sizeof(counts)/sizeof(counts[0]);n++){
        /* A large logical card still stores only the maintained metadata
         * sectors in this sparse fixture; no multi-GB payload is allocated. */
        const uint32_t capacity=250347520U,blocks=counts[n];
        const uint64_t ticks=(uint64_t)blocks*61440U,bytes=(uint64_t)blocks*46592U;
        setup();rebind_card(capacity,1U);
        uint32_t next=0U;uint8_t system[512]={0},config[2048]={0};
        XE_NP_Np2DualSdMeta meta,append;
        assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && next==8192U);
        assert(!XE_NP_Np2DualSdCatalog_Plan(rate,blocks,42U,crc32(config,2048U),&meta));
        assert(!XE_NP_Np2DualSdCatalog_Reserve(&meta,config));
        assert(!XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0U,blocks));
        uint8_t descriptor[512],footer[512],directory[512];
        const uint32_t end=meta.run.payload_start_lba+blocks*91U;
        const uint32_t cursor=(end+8191U)&~8191U;
        assert(!read_sector(NULL,meta.reservation_start_lba+3U,descriptor));
        assert(!read_sector(NULL,meta.reservation_start_lba+4U,footer));
        assert(get32(footer+116U)==end && get32(footer+120U)==(uint32_t)ticks &&
               get32(footer+124U)==(uint32_t)(ticks>>32U));
        assert((uint64_t)(end-meta.run.payload_start_lba)*512U==bytes);
        assert((ticks>UINT32_MAX)==(n!=0U) && (bytes>UINT32_MAX)==(n==3U));
        assert(!read_sector(NULL,128U,directory) && get32(directory)==1U &&
               get32(directory+4U)==end && get32(directory+256U)==end);
        rebind_card(capacity,1U);uint32_t writes=card.writes,commands=card.commands;
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && next==cursor &&
               !XE_NP_Np2DualSdCatalog_Status() && card.writes==writes && card.commands==commands);
        assert(!XE_NP_Np2DualSdCatalog_Plan(rate,4U,43U,crc32(config,2048U),&append) &&
               append.reservation_start_lba==cursor);
        /* Valid CRC is insufficient when the recorded source high word is
         * wrong: mount must block append/recovery without touching sectors. */
        np_put32(footer+124U,get32(footer+124U)^1U);
        np_put32(footer+508U,crc32(footer,508U));
        assert(!write_sector(NULL,meta.reservation_start_lba+4U,footer));
        rebind_card(capacity,1U);writes=card.writes;commands=card.commands;
        uint32_t state=17U,error=18U,count=19U;
        assert(XE_NP_Np2DualSd_DecodeFooter(descriptor,footer,&state,&error,&count)<0);
        assert(state==17U && error==18U && count==19U);
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && next==cursor &&
               XE_NP_Np2DualSdCatalog_Status()==XE_NP_NP2_CATALOG_RECOVERY);
        assert(XE_NP_Np2DualSdCatalog_Plan(rate,4U,43U,crc32(config,2048U),&append)<0);
        assert(XE_NP_Np2DualSdCatalog_Recover(&next)<0 && card.writes==writes && card.commands==commands);
        uint8_t after[512];assert(!read_sector(NULL,128U,after) && !memcmp(after,directory,512U));
    }
    puts("PASS catalog: sparse 32-bit source/byte boundaries, exact committed end/remount cursor, wrong-high fail-closed");
}
static void test_recovery(void)
{
    setup();uint32_t next;uint8_t system[512]={0},config[2048]={0};XE_NP_Np2DualSdMeta m;
    assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    assert(!XE_NP_Np2DualSdCatalog_Plan(20000,400,7,crc32(config,2048),&m));
    assert(!XE_NP_Np2DualSdCatalog_Reserve(&m,config));
    reboot();uint32_t writes=card.writes;
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    assert(XE_NP_Np2DualSdCatalog_Status()==(XE_NP_NP2_CATALOG_RECOVERY|XE_NP_NP2_CATALOG_QUARANTINABLE));
    assert(card.writes==writes); /* Mount never publishes the quarantine. */
    assert(XE_NP_Np2DualSdCatalog_Plan(20000,8,8,crc32(config,2048),&m)<0);
    /* A valid FAILED footer cannot justify shrinking an ambiguous directory
     * fence larger than the descriptor's validated allocation. */
    uint8_t desc[512],footer[512],directory[512];
    assert(!read_sector(NULL,8195,desc) && !XE_NP_Np2DualSd_DecodeDescriptor(desc,&m));
    assert(!XE_NP_Np2DualSd_EncodeFooter(footer,&m,XE_NP_NP2_DUAL_SD_META_FAILED,9,4));
    assert(!write_sector(NULL,8196,footer));
    assert(!read_sector(NULL,128,directory));
    uint32_t full=131072;memcpy(directory+4,&full,4);memcpy(directory+256,&full,4);
    assert(!write_sector(NULL,128,directory));reboot();writes=card.writes;
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && next==131072 && writes==card.writes);
    assert(XE_NP_Np2DualSdCatalog_Status()==(XE_NP_NP2_CATALOG_FULL|XE_NP_NP2_CATALOG_RECOVERY));
    assert(XE_NP_Np2DualSdCatalog_Recover(&next)<0 && card.writes==writes);
    full=m.reservation_end_lba;memcpy(directory+4,&full,4);memcpy(directory+256,&full,4);
    assert(!write_sector(NULL,128,directory));reboot();writes=card.writes;
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && next==m.reservation_end_lba && writes==card.writes);
    assert(!XE_NP_Np2DualSdCatalog_Recover(&next) && next==m.reservation_end_lba && writes==card.writes);
    assert(!XE_NP_Np2DualSdCatalog_Status());
    uint8_t preserved[512];assert(!read_sector(NULL,8196,preserved)&&!memcmp(preserved,footer,512));
    /* Torn footer: readable directory remains mounted but cannot be appended. */
    footer[508]^=1;assert(!write_sector(NULL,8196,footer));reboot();writes=card.writes;
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    assert(XE_NP_Np2DualSdCatalog_Recover(&next)<0 && card.writes==writes);
    puts("PASS ambiguous oversized FAILED fence refuses shrink; full validated allocation and corrupt-footer protection");
}
static void test_journal_recovery(void)
{
    setup();uint32_t next;uint8_t system[512]={0},config[2048]={0};XE_NP_Np2DualSdMeta m;
    assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    assert(!XE_NP_Np2DualSdCatalog_Plan(20000,400,9,crc32(config,2048),&m));
    assert(!XE_NP_Np2DualSdCatalog_Reserve(&m,config));card.failed_lba=128;
    assert(XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0,4)<0);
    reboot();card.failed_lba=UINT32_MAX;uint32_t writes=card.writes;
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && writes==card.writes);
    assert(XE_NP_Np2DualSdCatalog_Status()&XE_NP_NP2_CATALOG_RECOVERABLE);
    assert(!XE_NP_Np2DualSdCatalog_Recover(&next) && next==24576);
    assert(!XE_NP_Np2DualSdCatalog_Status());
    puts("PASS read-only pending-journal view and explicit sealed-end recovery");
}
static void test_every_finish_cut(void)
{
    for(uint32_t cut=1;cut<=5;cut++){
        setup();uint32_t next;uint8_t system[512]={0},config[2048]={0};XE_NP_Np2DualSdMeta m;
        assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
        assert(!XE_NP_Np2DualSdCatalog_Plan(20000,400,123,crc32(config,2048),&m));
        assert(!XE_NP_Np2DualSdCatalog_Reserve(&m,config));
        card.failed_write=card.writes+cut;
        assert(XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0,4)<0);
        card.failed_write=0;reboot();uint32_t writes=card.writes;
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next)&&card.writes==writes);
        if(cut==1){assert(!XE_NP_Np2DualSdCatalog_Recover(&next)&&next==m.reservation_end_lba);}
        else {assert(!XE_NP_Np2DualSdCatalog_Recover(&next)&&next==24576);}
    }
    puts("PASS all five terminal metadata write-cut boundaries; missing footer retains entire allocation, never claims samples");
}
static XE_NP_Np2DualSdMeta interrupted(uint32_t blocks)
{
    setup();uint32_t next;uint8_t system[512]={0},config[2048]={0};XE_NP_Np2DualSdMeta m;
    assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    assert(!XE_NP_Np2DualSdCatalog_Plan(30000,blocks,321,crc32(config,2048),&m));
    assert(!XE_NP_Np2DualSdCatalog_Reserve(&m,config));
    uint8_t payload[512];memset(payload,0xAD,sizeof(payload));
    assert(!write_sector(NULL,m.run.payload_start_lba,payload));
    assert(!write_sector(NULL,m.reservation_end_lba-1U,payload));
    reboot();return m;
}
static void assert_original_allocation(const XE_NP_Np2DualSdMeta *m,const uint8_t *desc,const uint8_t *footer)
{
    uint8_t actual[512];uint32_t state,error,blocks;
    assert(!read_sector(NULL,m->reservation_start_lba+3U,actual)&&!memcmp(actual,desc,512));
    assert(!read_sector(NULL,m->reservation_start_lba+4U,actual)&&!memcmp(actual,footer,512));
    assert(!XE_NP_Np2DualSd_DecodeFooter(desc,actual,&state,&error,&blocks));
    assert(state==XE_NP_NP2_DUAL_SD_META_RESERVED&&error==1U&&blocks==0U);
    assert(!read_sector(NULL,m->run.payload_start_lba,actual));
    for(uint32_t i=0;i<512;i++)assert(actual[i]==0xAD);
    assert(!read_sector(NULL,m->reservation_end_lba-1U,actual));
    for(uint32_t i=0;i<512;i++)assert(actual[i]==0xAD);
}
static void test_quarantine_preserves_extent_and_allows_next_session(void)
{
    XE_NP_Np2DualSdMeta m=interrupted(400);uint32_t next,writes=card.writes;
    uint8_t desc[512],footer[512],config[2048]={0};XE_NP_Np2DualSdMeta new_record;
    assert(!read_sector(NULL,m.reservation_start_lba+3U,desc));
    assert(!read_sector(NULL,m.reservation_start_lba+4U,footer));
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next)&&card.writes==writes);
    assert(XE_NP_Np2DualSdCatalog_Status()&XE_NP_NP2_CATALOG_QUARANTINABLE);
    assert(XE_NP_Np2DualSdCatalog_Plan(20000,8,322,crc32(config,2048),&new_record)<0);
    assert(!XE_NP_Np2DualSdCatalog_Recover(&next)&&next==m.reservation_end_lba);
    assert(!XE_NP_Np2DualSdCatalog_Status());
    assert_original_allocation(&m,desc,footer);
    writes=card.writes;reboot();
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next)&&card.writes==writes&&next==m.reservation_end_lba);
    assert(!XE_NP_Np2DualSdCatalog_Plan(20000,8,322,crc32(config,2048),&new_record));
    assert(new_record.reservation_start_lba>=m.reservation_end_lba);
    assert(!XE_NP_Np2DualSdCatalog_Reserve(&new_record,config));
    assert(!XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0,8));
    assert_original_allocation(&m,desc,footer);
    puts("PASS explicit stopped quarantine: entire incomplete allocation retained, read-only mounts, safe next 20-kHz session");
}
static void test_every_quarantine_cut(void)
{
    for(uint32_t cut=1;cut<=4;cut++){
        XE_NP_Np2DualSdMeta m=interrupted(400);uint32_t next;
        uint8_t desc[512],footer[512];
        assert(!read_sector(NULL,m.reservation_start_lba+3U,desc));
        assert(!read_sector(NULL,m.reservation_start_lba+4U,footer));
        card.failed_write=card.writes+cut;
        assert(XE_NP_Np2DualSdCatalog_Recover(&next)<0);
        card.failed_write=0;reboot();uint32_t writes=card.writes;
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next)&&card.writes==writes);
        assert(!XE_NP_Np2DualSdCatalog_Recover(&next)&&next==m.reservation_end_lba);
        assert(!XE_NP_Np2DualSdCatalog_Status());
        assert_original_allocation(&m,desc,footer);
    }
    puts("PASS all four quarantine journal publication cuts; no payload/footer rewrite, no allocation reuse");
}
static void test_unknown_quarantine_bounds_fail_closed(void)
{
    for(uint32_t corrupt=0;corrupt<4;corrupt++){
        XE_NP_Np2DualSdMeta m=interrupted(400);uint32_t next;
        uint8_t b[512];uint32_t lba=corrupt==0?m.reservation_start_lba+3U:
                                   corrupt==1?m.reservation_start_lba+4U:128U;
        assert(!read_sector(NULL,lba,b));
        if(corrupt<2)b[508]^=1;
        else {uint32_t end=corrupt==2?m.run.payload_start_lba+364U:m.run.payload_start_lba;
              memcpy(b+4,&end,4);end=m.run.payload_start_lba+364U;memcpy(b+256,&end,4);}
        assert(!write_sector(NULL,lba,b));reboot();uint32_t writes=card.writes;
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
        assert(XE_NP_Np2DualSdCatalog_Status()&XE_NP_NP2_CATALOG_RECOVERY);
        assert(!(XE_NP_Np2DualSdCatalog_Status()&XE_NP_NP2_CATALOG_QUARANTINABLE));
        assert(XE_NP_Np2DualSdCatalog_Recover(&next)<0&&card.writes==writes);
    }
    puts("PASS corrupt descriptor/footer, ambiguous directory extent and event-end mismatch refuse quarantine");
}
static void test_quarantine_card_identity_and_full_capacity(void)
{
    for(uint32_t wrong=0U;wrong<2U;wrong++){
        XE_NP_Np2DualSdMeta m=interrupted(400U);uint32_t next;
        uint8_t desc[512],footer[512];
        assert(!read_sector(NULL,m.reservation_start_lba+3U,desc));
        assert(!read_sector(NULL,m.reservation_start_lba+4U,footer));
        rebind_card(wrong?262144U:131072U,wrong?1U:5U);
        uint32_t writes=card.writes;
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
        assert(XE_NP_Np2DualSdCatalog_Status()==XE_NP_NP2_CATALOG_RECOVERY);
        assert(XE_NP_Np2DualSdCatalog_Recover(&next)<0&&card.writes==writes);
        assert_original_allocation(&m,desc,footer);
    }
    XE_NP_Np2DualSdMeta m=interrupted(1244U);uint32_t next;
    uint8_t desc[512],footer[512],config[2048]={0};XE_NP_Np2DualSdMeta new_record;
    assert(m.reservation_end_lba==131072U);
    assert(!read_sector(NULL,m.reservation_start_lba+3U,desc));
    assert(!read_sector(NULL,m.reservation_start_lba+4U,footer));
    assert(!XE_NP_Np2DualSdCatalog_Recover(&next)&&next==131072U);
    assert(XE_NP_Np2DualSdCatalog_Status()==XE_NP_NP2_CATALOG_FULL);
    assert_original_allocation(&m,desc,footer);
    reboot();uint32_t writes=card.writes;
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next)&&next==131072U&&card.writes==writes);
    assert(XE_NP_Np2DualSdCatalog_Status()==XE_NP_NP2_CATALOG_FULL);
    assert(XE_NP_Np2DualSdCatalog_Plan(20000U,4U,322U,crc32(config,2048U),&new_record)<0);
    assert(XE_NP_Np2DualSdCatalog_Plan(30000U,4U,322U,crc32(config,2048U),&new_record)<0);
    assert(card.writes==writes);
    puts("PASS quarantine rejects wrong card CID/capacity; full allocation retained and 20/30-kHz append refused at card end");
}
static void test_stopped_written_checkpoint(uint32_t rate)
{
    setup();uint32_t next,writes;uint8_t system[512]={0},config[2048]={0};
    XE_NP_Np2DualSdMeta m;
    assert(XE_NP_Np2DualSdCatalog_CheckpointWritten(4U)<0 && !card.writes);
    assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    assert(!XE_NP_Np2DualSdCatalog_Plan(rate,8U,23U,crc32(config,2048U),&m));
    assert(!XE_NP_Np2DualSdCatalog_Reserve(&m,config));
    uint8_t directory[512],after[512],descriptor[512],footer[512],original[512];
    assert(!read_sector(NULL,128U,directory));
    assert(!read_sector(NULL,m.reservation_start_lba+3U,descriptor));
    assert(!read_sector(NULL,m.reservation_start_lba+4U,original));
    writes=card.writes;
    assert(XE_NP_Np2DualSdCatalog_CheckpointWritten(0U)<0);
    assert(XE_NP_Np2DualSdCatalog_CheckpointWritten(2U)<0);
    assert(XE_NP_Np2DualSdCatalog_CheckpointWritten(m.run.max_blocks+4U)<0);
    assert(card.writes==writes);
    card.failed_lba=m.reservation_start_lba+4U;
    assert(XE_NP_Np2DualSdCatalog_CheckpointWritten(8U)<0 && card.writes==writes);
    card.failed_lba=UINT32_MAX;
    assert(!read_sector(NULL,m.reservation_start_lba+4U,footer) && !memcmp(original,footer,512U));
    assert(!XE_NP_Np2DualSdCatalog_CheckpointWritten(8U) && card.writes==writes+1U);
    assert(!read_sector(NULL,128U,after) && !memcmp(directory,after,512U));
    assert(!read_sector(NULL,m.reservation_start_lba+4U,footer));
    uint32_t state,error,blocks;
    assert(!XE_NP_Np2DualSd_DecodeFooter(descriptor,footer,&state,&error,&blocks));
    assert(state==XE_NP_NP2_DUAL_SD_META_FAILED && error==XE_NP_NP2_DUAL_SD_META_VERIFY_PENDING && blocks==8U);
    assert(XE_NP_Np2DualSdCatalog_Mount(&next)<0); /* Reservation still owned. */
    assert(!XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0U,8U));
    assert(!read_sector(NULL,m.reservation_start_lba+4U,after));
    assert(!XE_NP_Np2DualSd_DecodeFooter(descriptor,after,&state,&error,&blocks));
    assert(state==XE_NP_NP2_DUAL_SD_META_COMPLETE && !error && blocks==8U);
    /* Reset during verification: read-only mount retains INCOMPLETE, and
     * explicit directory repair never relabels the saved count COMPLETE. */
    assert(!write_sector(NULL,m.reservation_start_lba+4U,footer));
    assert(!write_sector(NULL,128U,directory));reboot();writes=card.writes;
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && card.writes==writes);
    assert(XE_NP_Np2DualSdCatalog_Status()==(XE_NP_NP2_CATALOG_RECOVERY|XE_NP_NP2_CATALOG_QUARANTINABLE));
    assert(!XE_NP_Np2DualSdCatalog_Recover(&next) && next==m.reservation_end_lba);
    assert(!read_sector(NULL,m.reservation_start_lba+4U,after) && !memcmp(footer,after,512U));
    assert(!XE_NP_Np2DualSd_DecodeFooter(descriptor,after,&state,&error,&blocks));
    assert(state==XE_NP_NP2_DUAL_SD_META_FAILED && error==XE_NP_NP2_DUAL_SD_META_VERIFY_PENDING && blocks==8U);
    puts("PASS stopped written checkpoint: count durable, no directory/ownership release, no optimistic COMPLETE, reset repair retains INCOMPLETE");
}
/* Common sectors are generated by the maintained V1 formatter, not a second
 * implementation of its wire layout. Earlier directory entries are sparse
 * synthetic extents; the last record uses the validated real media geometry. */
static NpMediaMetadata fixture_media;
uint32_t NP_SD_MicrophoneRate(void){return 200000U;}
uint32_t NP_SD_CameraRate(void){return 50U;}
uint32_t NP_SD_CameraSequence(unsigned slot){(void)slot;return 0U;}
void NP_SD_MediaMetadata(uint8_t sector[512],uint32_t kind)
{
    NpMediaMetadata metadata=fixture_media;
    if(kind==3U)metadata.flags|=NP_MEDIA_META_FOOTER;
    np_media_metadata_write(sector,&metadata);
}
#define FIXTURE_MEDIA_START 1105920U
#define FIXTURE_MEDIA_END 1332224U
#define FIXTURE_MEDIA_NEXT 1335296U
#define FIXTURE_MEDIA_CAPACITY 1000005632U
static void seed_media_tail(void)
{
    setup();rebind_card(FIXTURE_MEDIA_CAPACITY,1U);
    uint8_t identity[512]={0},sector[512]={0};
    memcpy(identity,"CE_FILESYSTEM_V1",16U);memcpy(identity+32U,"NP_CE64_1",9U);
    assert(!write_sector(NULL,16U,identity));
    NpCe64SysLog directory={0};directory.count=9U;
    for(uint32_t i=0U;i<8U;i++)directory.end[i]=directory.event_end[i]=
        i==7U?FIXTURE_MEDIA_START:163840U+i*131072U;
    directory.end[8]=directory.event_end[8]=FIXTURE_MEDIA_END;
    assert(!write_sector(NULL,128U,(const uint8_t *)&directory));
    NpSdLog media={0};
    media.config.start_lba=FIXTURE_MEDIA_START;media.config.end_lba=FIXTURE_MEDIA_CAPACITY&~1023U;
    media.config.session=30735U;media.config.sample_bytes=1U;media.state=NP_SD_RUNNING;
    memset(&fixture_media,0,sizeof(fixture_media));
    fixture_media.flags=NP_MEDIA_META_CAMERA_REQUESTED|NP_MEDIA_META_MIC_REQUESTED;
    fixture_media.camera_hz=50U;fixture_media.mic_hz=200000U;
    np_sd_header(sector,&media,1U,0U);
    assert(!write_sector(NULL,FIXTURE_MEDIA_START+3U,sector));
    media.state=NP_SD_COMPLETE;media.committed_chunks=1704U;
    fixture_media.camera_source_completed=fixture_media.camera_saved=544U;
    fixture_media.camera_first_id=1375U;fixture_media.camera_last_id=1918U;
    fixture_media.camera_first_tick=30750U;fixture_media.camera_last_tick=41610U;
    fixture_media.mic_produced=fixture_media.mic_saved=2172673U;
    np_sd_header(sector,&media,3U,0U);
    assert(!write_sector(NULL,FIXTURE_MEDIA_START+4U,sector));
    memset(sector,0xAD,512U);
    assert(!write_sector(NULL,FIXTURE_MEDIA_START+8192U,sector));
    assert(!write_sector(NULL,FIXTURE_MEDIA_END-1U,sector));
    rebind_card(FIXTURE_MEDIA_CAPACITY,1U);
}
static int fixture_ce64_read(uint32_t lba,uint8_t *out){return read_sector(NULL,lba,out);}
static int fixture_ce64_write(uint32_t lba,const uint8_t *in){return write_sector(NULL,lba,in);}
static void test_finalized_media_append_preserves_camera_mount(uint32_t rate,uint32_t au)
{
    seed_media_tail();uint32_t next,writes=card.writes,commands=card.commands;
    uint8_t descriptor[512],footer[512],actual[512],config[2048]={0};
    assert(!read_sector(NULL,FIXTURE_MEDIA_START+3U,descriptor));
    assert(!read_sector(NULL,FIXTURE_MEDIA_START+4U,footer));
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && next==FIXTURE_MEDIA_NEXT);
    assert(!XE_NP_Np2DualSdCatalog_Status() && writes==card.writes && commands==card.commands);
    XE_NP_Np2DualSdMeta neural;
    assert(!XE_NP_Np2DualSdCatalog_PlanAu(rate,8U,30736U,crc32(config,2048U),au,&neural));
    assert(neural.reservation_start_lba==FIXTURE_MEDIA_NEXT && neural.au_blocks==au);
    assert(!XE_NP_Np2DualSdCatalog_Reserve(&neural,config));
    assert(!XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0U,8U));
    assert(!read_sector(NULL,16U,actual) && !memcmp(actual+32U,"NP_CE64_1",9U));
    assert(!read_sector(NULL,FIXTURE_MEDIA_START+3U,actual) && !memcmp(actual,descriptor,512U));
    assert(!read_sector(NULL,FIXTURE_MEDIA_START+4U,actual) && !memcmp(actual,footer,512U));
    const uint32_t sentinels[2]={FIXTURE_MEDIA_START+8192U,FIXTURE_MEDIA_END-1U};
    for(unsigned n=0U;n<2U;n++){
        assert(!read_sector(NULL,sentinels[n],actual));
        for(unsigned i=0U;i<512U;i++)assert(actual[i]==0xADU);
    }
    rebind_card(FIXTURE_MEDIA_CAPACITY,1U);writes=card.writes;
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && !XE_NP_Np2DualSdCatalog_Status());
    NpCe64Directory camera_directory;
    assert(!np_ce64_mount(&camera_directory,FIXTURE_MEDIA_CAPACITY,
        fixture_ce64_read,fixture_ce64_write));
    assert(camera_directory.start==next && camera_directory.index==10U && card.writes==writes);
    puts("PASS finalized canonical V8 tail: read-only admission, safe v11/v12 append, media preserved, canonical camera mount survives");
}
static void test_uncertain_media_tail_refuses_append(void)
{
    /* Recompute CRC for semantic corruptions, so rejection cannot be credited
     * only to the checksum. Both media sectors retain unknown bytes as-is. */
    static const struct {uint32_t sector,offset,value;} cases[]={
        {3U,8U,7U},{3U,12U,0U},{4U,12U,30736U},{3U,16U,1U},{3U,20U,2U},
        {3U,24U,30000U},{3U,28U,2500U},{3U,32U,0U},{3U,36U,127U},
        {3U,40U,FIXTURE_MEDIA_START+8192U},{3U,44U,FIXTURE_MEDIA_CAPACITY-1024U},
        {3U,48U,16384U},{3U,52U,1U},{3U,56U,1U},{3U,60U,3U},{3U,64U,1U},
        {3U,68U,8U},{4U,60U,4U},{4U,64U,1U},{4U,68U,0U},{4U,68U,1703U},
        {4U,68U,1712U},{4U,80U,1U},{4U,88U,1U},{4U,92U,1U},
        {4U,96U,0U},{4U,100U,1U},{4U,104U,1U},{4U,108U,1U},
        {4U,112U,25U},{4U,116U,100000U},{4U,120U,2U},{4U,124U,1U},
        {4U,128U,0U},{4U,136U,2U},{4U,140U,24U},{4U,140U,60U},
        {4U,168U,25U},{4U,172U,545U},{4U,176U,0U},{4U,184U,1919U},
        {4U,196U,1U},{4U,200U,1U},{4U,204U,1U},{4U,212U,1U},{4U,216U,1U},
        {4U,220U,100000U},{4U,228U,2172674U},{4U,236U,0U},
        {4U,244U,1U},{4U,248U,1U},{3U,140U,28U}
    };
    for(unsigned n=0U;n<sizeof(cases)/sizeof(cases[0])+6U;n++){
        seed_media_tail();uint8_t b[512];uint32_t next;
        if(n<sizeof(cases)/sizeof(cases[0])){
            uint32_t lba=FIXTURE_MEDIA_START+cases[n].sector;
            assert(!read_sector(NULL,lba,b));np_put32(b+cases[n].offset,cases[n].value);
            np_put32(b+508U,crc32(b,508U));assert(!write_sector(NULL,lba,b));
        }else{
            unsigned extra=n-(unsigned)(sizeof(cases)/sizeof(cases[0]));
            if(extra<2U){
                uint32_t lba=FIXTURE_MEDIA_START+3U+extra;
                assert(!read_sector(NULL,lba,b));b[508]^=1U;assert(!write_sector(NULL,lba,b));
            }else if(extra==2U){
                assert(!read_sector(NULL,128U,b));np_put32(b+256U+8U*4U,FIXTURE_MEDIA_END+1024U);
                assert(!write_sector(NULL,128U,b));
            }else if(extra==3U)rebind_card(FIXTURE_MEDIA_CAPACITY+1024U,1U);
            else if(extra==4U){
                assert(!read_sector(NULL,128U,b));assert(!write_sector(NULL,113U,b));
                uint8_t journal[512]={0};memcpy(journal,"NPC64TX1",8U);np_put32(journal+8U,128U);
                np_put32(journal+12U,crc32(b,512U));np_put32(journal+508U,crc32(journal,508U));
                assert(!write_sector(NULL,112U,journal));
            }else{
                assert(!read_sector(NULL,16U,b));memcpy(b+32U,"NP_PSSI_7",9U);
                assert(!write_sector(NULL,16U,b));
            }
        }
        uint32_t writes=card.writes,commands=card.commands;
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
        assert(XE_NP_Np2DualSdCatalog_Status()==XE_NP_NP2_CATALOG_RECOVERY);
        assert(XE_NP_Np2DualSdCatalog_Recover(&next)<0);
        XE_NP_Np2DualSdMeta neural;uint8_t config[2048]={0};
        assert(XE_NP_Np2DualSdCatalog_Plan(30000U,8U,30736U,crc32(config,2048U),&neural)<0);
        assert(card.writes==writes && card.commands==commands);
    }
    puts("PASS uncertain media CRC/state/session/geometry/bounds/source/counter/journal tails remain recovery-blocked without writes");
}
static void test_shared_tag_guard_and_legacy_upgrade(void)
{
    seed_media_tail();uint32_t next;uint8_t config[2048]={0},identity[512];
    XE_NP_Np2DualSdMeta neural;
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    assert(!XE_NP_Np2DualSdCatalog_Plan(20000U,8U,30736U,crc32(config,2048U),&neural));
    assert(!read_sector(NULL,16U,identity));memcpy(identity+32U,"NP_PSSI_7",9U);
    assert(!write_sector(NULL,16U,identity));uint32_t writes=card.writes,commands=card.commands;
    assert(XE_NP_Np2DualSdCatalog_Reserve(&neural,config)<0 && card.writes==writes && card.commands==commands);
    setup();memset(identity,0,512U);memcpy(identity,"CE_FILESYSTEM_V1",16U);
    memcpy(identity+32U,"NP_PSSI_6",9U);assert(!write_sector(NULL,16U,identity));
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    assert(!XE_NP_Np2DualSdCatalog_Plan(20000U,8U,1U,crc32(config,2048U),&neural));
    assert(!XE_NP_Np2DualSdCatalog_Reserve(&neural,config));
    assert(!read_sector(NULL,16U,identity) && !memcmp(identity+32U,"NP_PSSI_7",9U));
    puts("PASS shared tag change refuses before mutation; native NP_PSSI_6 writer upgrade unchanged");
}

static void test_au_plan_and_actual_end(uint32_t rate)
{
    const uint32_t capacity=501301248U,au=86016U;
    setup();rebind_card(capacity,1U);
    uint32_t next;uint8_t system[512]={0},config[2048]={0};
    XE_NP_Np2DualSdMeta legacy,zero,first,second,bad;
    assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    assert(!XE_NP_Np2DualSdCatalog_Plan(rate,12U,51U,crc32(config,2048U),&legacy));
    assert(!XE_NP_Np2DualSdCatalog_PlanAu(rate,12U,51U,crc32(config,2048U),0U,&zero));
    uint8_t descriptor[512],other[512],footer[512],saved_footer[512];
    assert(!XE_NP_Np2DualSd_EncodeDescriptor(descriptor,&legacy));
    assert(!XE_NP_Np2DualSd_EncodeDescriptor(other,&zero) && !memcmp(descriptor,other,512U));
    assert(!zero.au_blocks && zero.run.max_blocks==legacy.run.max_blocks && legacy.run.max_blocks>12U);
    assert(!XE_NP_Np2DualSdCatalog_PlanAu(rate,12U,51U,crc32(config,2048U),au,&first));
    assert(first.reservation_start_lba==8192U && first.run.payload_start_lba==86016U &&
           first.run.payload_end_lba==87108U && first.run.max_blocks==12U &&
           first.run.max_rus==3U && first.reservation_end_lba==180224U && first.au_blocks==au);
    uint32_t writes=card.writes,commands=card.commands;
    bad=first;bad.au_blocks=1023U;
    assert(XE_NP_Np2DualSdCatalog_Reserve(&bad,config)<0 && card.writes==writes && card.commands==commands);
    bad=first;bad.run.max_blocks+=4U;
    assert(XE_NP_Np2DualSdCatalog_Reserve(&bad,config)<0 && card.writes==writes && card.commands==commands);
    assert(!XE_NP_Np2DualSdCatalog_Reserve(&first,config));
    assert(!read_sector(NULL,8195U,descriptor) && get32(descriptor+8U)==12U &&
           get32(descriptor+96U)==31U && get32(descriptor+128U)==au);
    /* Only one genuine RU is committed; the rest of the planned AU tail is
     * not recorded data and receives no footer/directory credit. */
    uint8_t payload[512];memset(payload,0xAD,sizeof(payload));
    const uint32_t committed_end=first.run.payload_start_lba+364U;
    assert(!write_sector(NULL,first.run.payload_start_lba,payload));
    assert(!write_sector(NULL,committed_end-1U,payload));
    assert(!XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0U,4U));
    assert(!read_sector(NULL,8196U,saved_footer));
    uint32_t state,error,blocks;
    assert(!XE_NP_Np2DualSd_DecodeFooter(descriptor,saved_footer,&state,&error,&blocks) &&
           state==XE_NP_NP2_DUAL_SD_META_COMPLETE && !error && blocks==4U &&
           get32(saved_footer+116U)==committed_end && get32(saved_footer+128U)==au);
    rebind_card(capacity,1U);writes=card.writes;commands=card.commands;
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && next==90112U &&
           !XE_NP_Np2DualSdCatalog_Status() && writes==card.writes && commands==card.commands);
    assert(!XE_NP_Np2DualSdCatalog_PlanAu(rate,8U,52U,crc32(config,2048U),au,&second));
    assert(second.reservation_start_lba==90112U && second.run.payload_start_lba==172032U &&
           second.run.max_blocks==8U && second.reservation_end_lba==262144U &&
           second.run.payload_start_lba/au>(committed_end-1U)/au);
    assert(!XE_NP_Np2DualSdCatalog_Reserve(&second,config));
    assert(!XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0U,8U));
    assert(!read_sector(NULL,8195U,other) && !memcmp(other,descriptor,512U));
    assert(!read_sector(NULL,8196U,footer) && !memcmp(footer,saved_footer,512U));
    assert(!read_sector(NULL,first.run.payload_start_lba,other) && !memcmp(other,payload,512U));
    assert(!read_sector(NULL,committed_end-1U,other) && !memcmp(other,payload,512U));
    rebind_card(capacity,1U);writes=card.writes;
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && next==180224U && card.writes==writes);
    assert(!XE_NP_Np2DualSdCatalog_PlanAu(rate,4U,53U,crc32(config,2048U),au,&second) &&
           second.run.payload_start_lba==258048U);
    puts("PASS v12 catalog 20/30: zero-AU v11 bytes unchanged, exact requested RUs, short actual end and no retained-AU reuse");
}

static void test_au_recovery(void)
{
    const uint32_t capacity=501301248U;
    for(uint32_t terminal=0U;terminal<2U;terminal++){
        setup();rebind_card(capacity,1U);
        uint32_t next;uint8_t system[512]={0},config[2048]={0},descriptor[512],footer[512],after[512];
        XE_NP_Np2DualSdMeta m,decoded,append;
        assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
        assert(!XE_NP_Np2DualSdCatalog_PlanAu(30000U,12U,61U,crc32(config,2048U),86016U,&m));
        assert(!XE_NP_Np2DualSdCatalog_Reserve(&m,config));
        if(terminal){
            card.failed_lba=128U;
            assert(XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_FAILED,9U,4U)<0);
            card.failed_lba=UINT32_MAX;
        }else{
            memset(after,0xAD,sizeof(after));
            assert(!write_sector(NULL,m.run.payload_start_lba,after));
            assert(!write_sector(NULL,m.reservation_end_lba-1U,after));
        }
        assert(!read_sector(NULL,m.reservation_start_lba+3U,descriptor));
        assert(!read_sector(NULL,m.reservation_start_lba+4U,footer));
        rebind_card(capacity,1U);uint32_t writes=card.writes,commands=card.commands;
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && writes==card.writes && commands==card.commands);
        assert(XE_NP_Np2DualSdCatalog_Status()==(XE_NP_NP2_CATALOG_RECOVERY|XE_NP_NP2_CATALOG_QUARANTINABLE));
        assert(!XE_NP_Np2DualSdCatalog_Recover(&next) && next==180224U);
        assert(!XE_NP_Np2DualSdCatalog_Status());
        assert(!read_sector(NULL,m.reservation_start_lba+3U,after) && !memcmp(after,descriptor,512U));
        assert(!read_sector(NULL,m.reservation_start_lba+4U,after) && !memcmp(after,footer,512U));
        assert(!XE_NP_Np2DualSd_DecodeDescriptor(descriptor,&decoded) && decoded.au_blocks==86016U);
        if(!terminal)assert_original_allocation(&m,descriptor,footer);
        assert(!XE_NP_Np2DualSdCatalog_PlanAu(20000U,4U,62U,crc32(config,2048U),86016U,&append) &&
               append.run.payload_start_lba==258048U);
    }
    puts("PASS v12 sealed recovery and full-AU quarantine: original metadata retained, no incomplete data promotion");
}

static void test_au_rejections(void)
{
    setup();rebind_card(501301248U,1U);
    uint32_t next;uint8_t system[512]={0},config[2048]={0};
    assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    static const uint32_t bad_aus[]={1U,1023U,1536U,UINT32_MAX,UINT32_MAX-1023U};
    XE_NP_Np2DualSdMeta m;memset(&m,0xA5,sizeof(m));uint8_t original[sizeof(m)];
    memcpy(original,&m,sizeof(m));uint32_t writes=card.writes,commands=card.commands;
    for(uint32_t n=0U;n<sizeof(bad_aus)/sizeof(bad_aus[0]);n++)
        assert(XE_NP_Np2DualSdCatalog_PlanAu(20000U,8U,71U,crc32(config,2048U),bad_aus[n],&m)<0 &&
               !memcmp(&m,original,sizeof(m)));
    assert(XE_NP_Np2DualSdCatalog_PlanAu(20000U,UINT32_MAX-3U,71U,crc32(config,2048U),86016U,&m)<0);
    assert(card.writes==writes && card.commands==commands);
    assert(!XE_NP_Np2DualSdCatalog_PlanAu(30000U,8U,71U,crc32(config,2048U),3072U,&m) &&
           m.run.payload_start_lba==18432U && m.run.max_blocks==8U && m.reservation_end_lba==32768U);
    rebind_card(180223U,1U);assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    assert(XE_NP_Np2DualSdCatalog_PlanAu(20000U,8U,71U,crc32(config,2048U),86016U,&m)<0);
    rebind_card(UINT32_MAX,1U);assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    assert(XE_NP_Np2DualSdCatalog_PlanAu(20000U,4U,71U,crc32(config,2048U),UINT32_MAX-1023U,&m)<0);
    /* Identity, known-version, CRC and exact footer-AU guards remain active
     * for an open v12 reservation; recovery may not guess its allocation. */
    for(uint32_t bad=0U;bad<7U;bad++){
        setup();rebind_card(501301248U,1U);
        assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
        assert(!XE_NP_Np2DualSdCatalog_PlanAu(20000U,8U,71U,crc32(config,2048U),86016U,&m));
        assert(!XE_NP_Np2DualSdCatalog_Reserve(&m,config));
        if(bad<5U){
            uint8_t b[512];uint32_t lba=m.reservation_start_lba+(bad==3U?4U:3U);
            assert(!read_sector(NULL,lba,b));
            if(bad==0U)np_put32(b+8U,13U);
            else if(bad==1U)np_put32(b+128U,0U);
            else if(bad==2U)np_put32(b+96U,15U);
            else if(bad==3U)np_put32(b+128U,43008U);
            else b[508U]^=1U;
            if(bad!=4U)np_put32(b+508U,crc32(b,508U));
            assert(!write_sector(NULL,lba,b));
        }
        rebind_card(bad==6U?501302272U:501301248U,bad==5U?5U:1U);
        writes=card.writes;commands=card.commands;
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next) &&
               XE_NP_Np2DualSdCatalog_Status()==XE_NP_NP2_CATALOG_RECOVERY);
        assert(XE_NP_Np2DualSdCatalog_Recover(&next)<0 &&
               XE_NP_Np2DualSdCatalog_PlanAu(30000U,4U,72U,crc32(config,2048U),86016U,&m)<0 &&
               card.writes==writes && card.commands==commands);
    }
    puts("PASS v12 AU/capacity/overflow/identity/CRC/unknown-format rejection without card mutation");
}

static void test_legacy_au_sessions(void)
{
    static const struct {uint32_t au,payload,allocation;} geometry[]={
        {2048U,16384U,65536U},{4096U,16384U,65536U},{8192U,16384U,65536U},
        {16384U,16384U,65536U},{24576U,24576U,81920U},{32768U,32768U,98304U},
        {49152U,49152U,98304U},{65536U,65536U,131072U},{131072U,131072U,262144U}
    };
    for(uint32_t i=0U;i<sizeof(geometry)/sizeof(geometry[0]);i++){
        setup();rebind_card(501301248U,1U);
        uint32_t next,mask=i%2U?3U:7U;
        uint8_t system[512]={0},config[2048]={0},descriptor[512],footer[512],after[512];
        XE_NP_Np2DualSdMeta first,decoded,second;
        assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && next==8192U);
        uint32_t reads=card.reads,writes=card.writes,commands=card.commands;
        assert(!XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(mask,15000U,400U,131U,
                   crc32(config,2048U),geometry[i].au,&first));
        assert(card.reads==reads && card.writes==writes && card.commands==commands &&
               !first.au_blocks && first.legacy_au_blocks==geometry[i].au &&
               first.reservation_start_lba==8192U && first.run.payload_start_lba==geometry[i].payload &&
               first.run.payload_end_lba==geometry[i].payload+36400U &&
               first.run.max_blocks==400U && first.run.max_rus==100U &&
               first.reservation_end_lba==geometry[i].allocation);
        assert(!XE_NP_Np2DualSdCatalog_Reserve(&first,config));
        assert(!read_sector(NULL,8195U,descriptor) && get32(descriptor+8U)==13U &&
               get32(descriptor+96U)==47U && get32(descriptor+128U)==geometry[i].au);
        assert(!XE_NP_Np2DualSd_DecodeDescriptor(descriptor,&decoded) &&
               !decoded.au_blocks && decoded.legacy_au_blocks==geometry[i].au);
        assert(!XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0U,8U));
        assert(!read_sector(NULL,8196U,footer));
        uint32_t state,error,blocks,committed=first.run.payload_start_lba+728U;
        assert(!XE_NP_Np2DualSd_DecodeFooter(descriptor,footer,&state,&error,&blocks) &&
               state==XE_NP_NP2_DUAL_SD_META_COMPLETE && !error && blocks==8U &&
               get32(footer+116U)==committed && get32(footer+128U)==geometry[i].au);
        rebind_card(501301248U,1U);writes=card.writes;commands=card.commands;
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && next==((committed+8191U)&~8191U) &&
               !XE_NP_Np2DualSdCatalog_Status() && card.writes==writes && card.commands==commands);
        assert(!XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(mask==7U?3U:7U,15000U,4U,
                   132U,crc32(config,2048U),geometry[i].au,&second) &&
               second.reservation_start_lba==next && second.run.max_blocks==4U &&
               second.run.payload_end_lba==second.run.payload_start_lba+364U &&
               second.run.payload_start_lba/geometry[i].au>(committed-1U)/geometry[i].au);
        assert(!XE_NP_Np2DualSdCatalog_Reserve(&second,config));
        assert(!XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0U,4U));
        assert(!read_sector(NULL,8195U,after) && !memcmp(after,descriptor,512U));
        assert(!read_sector(NULL,8196U,after) && !memcmp(after,footer,512U));
        rebind_card(501301248U,1U);
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && !XE_NP_Np2DualSdCatalog_Status());
    }
    puts("PASS v13 legacy UHS-AU: all nine units, exact requested bounds, strict short COMPLETE/remount, next-session AU separation and original seals preserved");
}

static void test_legacy_au_recovery(void)
{
    for(uint32_t scenario=0U;scenario<6U;scenario++){
        setup();rebind_card(501301248U,1U);
        uint32_t next,au=scenario%2U?131072U:24576U;
        uint8_t system[512]={0},config[2048]={0},descriptor[512],footer[512],after[512],directory[512];
        XE_NP_Np2DualSdMeta m,append;
        assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
        assert(!XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(7U,15000U,400U,141U,
                   crc32(config,2048U),au,&m));
        assert(!XE_NP_Np2DualSdCatalog_Reserve(&m,config));
        if(scenario==3U)assert(!XE_NP_Np2DualSdCatalog_CheckpointWritten(4U));
        else if(scenario){
            if(scenario==2U || scenario==4U)card.failed_lba=128U;
            int result=XE_NP_Np2DualSdCatalog_Finish(scenario==4U?XE_NP_NP2_DUAL_SD_META_COMPLETE:
                       XE_NP_NP2_DUAL_SD_META_FAILED,scenario==4U?0U:9U,4U);
            assert(scenario==2U || scenario==4U?result<0:result==0);
            card.failed_lba=UINT32_MAX;
        }
        assert(!read_sector(NULL,m.reservation_start_lba+3U,descriptor));
        assert(!read_sector(NULL,m.reservation_start_lba+4U,footer));
        if(scenario==5U){
            assert(!read_sector(NULL,128U,directory));
            np_put32(directory+4U,m.run.payload_start_lba+728U);
            np_put32(directory+256U,m.run.payload_start_lba+728U);
            assert(!write_sector(NULL,128U,directory));
        }
        rebind_card(501301248U,1U);uint32_t writes=card.writes,commands=card.commands;
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && card.writes==writes && card.commands==commands);
        if(scenario==5U){
            assert(XE_NP_Np2DualSdCatalog_Status()==XE_NP_NP2_CATALOG_RECOVERY);
            assert(XE_NP_Np2DualSdCatalog_Recover(&next)<0 &&
                   XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(3U,15000U,4U,142U,
                       crc32(config,2048U),au,&append)<0 && card.writes==writes && card.commands==commands);
        }else{
            uint32_t expected_status=scenario==1U?0U:XE_NP_NP2_CATALOG_RECOVERY|
                (scenario==4U?XE_NP_NP2_CATALOG_RECOVERABLE:XE_NP_NP2_CATALOG_QUARANTINABLE);
            assert(XE_NP_Np2DualSdCatalog_Status()==expected_status);
            assert(!XE_NP_Np2DualSdCatalog_Recover(&next) && !XE_NP_Np2DualSdCatalog_Status());
            uint32_t end=scenario==4U?m.run.payload_start_lba+364U:m.reservation_end_lba;
            assert(next==((end+8191U)&~8191U));
            assert(!XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(3U,15000U,4U,142U,
                       crc32(config,2048U),au,&append) && append.reservation_start_lba==next);
        }
        uint32_t state,error,blocks;
        assert(!XE_NP_Np2DualSd_DecodeFooter(descriptor,footer,&state,&error,&blocks) &&
               state==(!scenario?XE_NP_NP2_DUAL_SD_META_RESERVED:
                       scenario==4U?XE_NP_NP2_DUAL_SD_META_COMPLETE:XE_NP_NP2_DUAL_SD_META_FAILED) &&
               blocks==(!scenario?0U:4U) &&
               error==(!scenario?1U:scenario==3U?XE_NP_NP2_DUAL_SD_META_VERIFY_PENDING:scenario==4U?0U:9U));
        assert(!read_sector(NULL,m.reservation_start_lba+3U,after) && !memcmp(after,descriptor,512U));
        assert(!read_sector(NULL,m.reservation_start_lba+4U,after) && !memcmp(after,footer,512U));
    }
    puts("PASS v13 RESERVED/partial FAILED/VERIFY_PENDING allocation quarantine, failed publication recovery, strict COMPLETE seal recovery and ambiguous-tail refusal");
}

static void test_legacy_au_rejections(void)
{
    setup();rebind_card(501301248U,1U);
    uint32_t next;uint8_t system[512]={0},config[2048]={0};
    assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    static const uint32_t invalid[]={0U,1U,1024U,3072U,12288U,43008U,86016U,131073U,UINT32_MAX};
    XE_NP_Np2DualSdMeta m;memset(&m,0xA5,sizeof(m));
    uint8_t unchanged[sizeof(m)];memcpy(unchanged,&m,sizeof(m));
    uint32_t reads=card.reads,writes=card.writes,commands=card.commands;
    for(uint32_t i=0U;i<sizeof(invalid)/sizeof(invalid[0]);i++)
        assert(XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(7U,15000U,8U,151U,
                   crc32(config,2048U),invalid[i],&m)<0 && !memcmp(&m,unchanged,sizeof(m)));
    assert(XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(2U,15000U,8U,151U,0U,2048U,&m)<0);
    assert(XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(7U,25000U,8U,151U,0U,2048U,&m)<0);
    assert(XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(7U,15000U,6U,151U,0U,2048U,&m)<0);
    assert(XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(7U,15000U,8U,0U,0U,2048U,&m)<0);
    assert(XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(7U,15000U,UINT32_MAX-3U,151U,0U,2048U,&m)<0);
    assert(XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(7U,15000U,8U,151U,0U,2048U,NULL)<0);
    assert(!memcmp(&m,unchanged,sizeof(m)) && card.reads==reads && card.writes==writes && card.commands==commands);
    rebind_card(262143U,1U);assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    reads=card.reads;writes=card.writes;commands=card.commands;
    assert(XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(7U,15000U,400U,151U,0U,131072U,&m)<0 &&
           !memcmp(&m,unchanged,sizeof(m)) && card.reads==reads && card.writes==writes && card.commands==commands);
    puts("PASS v13 unsupported legacy AU/profile/count/session/capacity refusal before any I/O or output mutation");
}

static void test_mixed_profiles(void)
{
    const uint32_t capacity=501301248U;
    enum {PROFILES=9};
    static const uint32_t masks[]={1U,1U,1U,3U,3U,3U,7U,7U,7U};
    static const uint32_t rates[]={15000U,20000U,30000U,15000U,20000U,30000U,15000U,20000U,30000U};
    static const uint32_t aus[]={0U,0U,86016U,0U,86016U,0U,0U,86016U,0U};
    uint8_t system[512]={0},config[2048]={0},descriptors[PROFILES][512],footers[PROFILES][512],after[512];
    uint32_t starts[PROFILES],ends[PROFILES],next;
    setup();rebind_card(capacity,1U);
    assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    for(uint32_t i=0U;i<PROFILES;i++){
        XE_NP_Np2DualSdMeta m,decoded;
        assert(!XE_NP_Np2DualSdCatalog_PlanAuProfile(masks[i],rates[i],8U,81U+i,
                    crc32(config,2048U),aus[i],&m));
        assert(m.reservation_start_lba==next && m.run.probe_mask==masks[i]);
        starts[i]=m.reservation_start_lba;
        assert(!XE_NP_Np2DualSdCatalog_Reserve(&m,config));
        uint32_t state=i==1U?XE_NP_NP2_DUAL_SD_META_FAILED:XE_NP_NP2_DUAL_SD_META_COMPLETE;
        uint32_t error=i==1U?9U:0U,blocks=i==1U?4U:8U;
        assert(!XE_NP_Np2DualSdCatalog_Finish(state,error,blocks));
        assert(!read_sector(NULL,starts[i]+3U,descriptors[i]));
        assert(!read_sector(NULL,starts[i]+4U,footers[i]));
        uint32_t got_state,got_error,got_blocks;
        assert(!XE_NP_Np2DualSd_DecodeDescriptor(descriptors[i],&decoded) &&
               decoded.run.probe_mask==masks[i] && decoded.run.sample_hz==rates[i] && decoded.au_blocks==aus[i]);
        assert(!XE_NP_Np2DualSd_DecodeFooter(descriptors[i],footers[i],&got_state,&got_error,&got_blocks) &&
               got_state==state && got_error==error && got_blocks==blocks);
        uint32_t committed_end=m.run.payload_start_lba+blocks*91U;
        ends[i]=state==XE_NP_NP2_DUAL_SD_META_FAILED?m.reservation_end_lba:committed_end;
        assert(get32(footers[i]+116U)==committed_end &&
               get32(footers[i]+120U)==blocks*(masks[i]==1U?122880U:masks[i]==3U?61440U:40960U));
        rebind_card(capacity,1U);uint32_t writes=card.writes,commands=card.commands;
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && next==((ends[i]+8191U)&~8191U) &&
               !XE_NP_Np2DualSdCatalog_Status() && card.writes==writes && card.commands==commands);
        for(uint32_t j=0U;j<=i;j++){
            assert(!read_sector(NULL,starts[j]+3U,after) && !memcmp(after,descriptors[j],512U));
            assert(!read_sector(NULL,starts[j]+4U,after) && !memcmp(after,footers[j],512U));
        }
    }
    assert(!read_sector(NULL,128U,after) && get32(after)==PROFILES);
    for(uint32_t i=0U;i<PROFILES;i++)assert(get32(after+4U+4U*i)==ends[i] && get32(after+256U+4U*i)==ends[i]);
    puts("PASS all nine prefix/rate profiles mixed v11/v12 append and read-only remount; FAILED allocation remains fenced");
}

static void test_triple_recovery(uint32_t rate,uint32_t au)
{
    const uint32_t capacity=501301248U;
    for(uint32_t terminal=0U;terminal<2U;terminal++){
        setup();rebind_card(capacity,1U);
        uint32_t next;uint8_t system[512]={0},config[2048]={0},descriptor[512],footer[512],after[512];
        XE_NP_Np2DualSdMeta m,append;
        assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
        assert(!XE_NP_Np2DualSdCatalog_PlanAuProfile(7U,rate,12U,91U,crc32(config,2048U),au,&m));
        assert(!XE_NP_Np2DualSdCatalog_Reserve(&m,config));
        if(terminal){
            card.failed_lba=128U;
            assert(XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_FAILED,9U,4U)<0);
            card.failed_lba=UINT32_MAX;
        }
        assert(!read_sector(NULL,m.reservation_start_lba+3U,descriptor));
        assert(!read_sector(NULL,m.reservation_start_lba+4U,footer));
        rebind_card(capacity,1U);uint32_t writes=card.writes,commands=card.commands;
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && card.writes==writes && card.commands==commands);
        assert(XE_NP_Np2DualSdCatalog_Status()==(XE_NP_NP2_CATALOG_RECOVERY|XE_NP_NP2_CATALOG_QUARANTINABLE));
        assert(!XE_NP_Np2DualSdCatalog_Recover(&next) &&
               next==m.reservation_end_lba &&
               !XE_NP_Np2DualSdCatalog_Status());
        assert(!read_sector(NULL,m.reservation_start_lba+3U,after) && !memcmp(after,descriptor,512U));
        assert(!read_sector(NULL,m.reservation_start_lba+4U,after) && !memcmp(after,footer,512U));
        uint32_t state,error,blocks;
        assert(!XE_NP_Np2DualSd_DecodeFooter(descriptor,footer,&state,&error,&blocks) &&
               state==(terminal?XE_NP_NP2_DUAL_SD_META_FAILED:XE_NP_NP2_DUAL_SD_META_RESERVED) &&
               error==(terminal?9U:1U) && blocks==(terminal?4U:0U) &&
               get32(footer+120U)==blocks*40960U);
        assert(!XE_NP_Np2DualSdCatalog_Plan(30000U,4U,92U,crc32(config,2048U),&append) &&
               append.run.probe_mask==3U && append.reservation_start_lba==next);
    }
}

static void test_failed_ooo_allocation_fence(uint32_t mask,uint32_t rate,uint32_t au)
{
    const uint32_t capacity=501301248U;
    /* Normal Finish, all five metadata-write cuts, legacy exact prefix and
     * legacy payload-only fences, plus an ambiguous middle-of-tail fence. */
    for(uint32_t scenario=0U;scenario<9U;scenario++){
        setup();rebind_card(capacity,1U);
        uint32_t next;uint8_t system[512]={0},config[2048]={0};
        uint8_t descriptor[512],footer[512],directory[512],after[512],payload[512];
        XE_NP_Np2DualSdMeta m,append;
        assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
        assert(!XE_NP_Np2DualSdCatalog_PlanAuProfile(mask,rate,400U,117U,
                    crc32(config,2048U),au,&m));
        assert(!XE_NP_Np2DualSdCatalog_Reserve(&m,config));
        const uint32_t prefix=m.run.payload_start_lba+364U;
        const uint32_t ooo=prefix+364U; /* Beyond an uncommitted RU hole. */
        memset(payload,0xD7,sizeof(payload));
        assert(!write_sector(NULL,m.run.payload_start_lba,payload));
        assert(!write_sector(NULL,ooo,payload));
        assert(!write_sector(NULL,m.reservation_end_lba-1U,payload));
        assert(!read_sector(NULL,m.reservation_start_lba+3U,descriptor));
        if(scenario>=1U && scenario<=5U)card.failed_write=card.writes+scenario;
        int result=XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_FAILED,9U,4U);
        assert(scenario>=1U && scenario<=5U?result<0:result==0);
        card.failed_write=0U;
        assert(!read_sector(NULL,m.reservation_start_lba+4U,footer));
        uint32_t state,error,blocks;
        assert(!XE_NP_Np2DualSd_DecodeFooter(descriptor,footer,&state,&error,&blocks));
        assert(state==(scenario==1U?XE_NP_NP2_DUAL_SD_META_RESERVED:XE_NP_NP2_DUAL_SD_META_FAILED) &&
               error==(scenario==1U?1U:9U) && blocks==(scenario==1U?0U:4U) &&
               get32(footer+116U)==(scenario==1U?m.run.payload_start_lba:prefix));
        assert(!read_sector(NULL,128U,directory));
        if(!scenario)assert(get32(directory+4U)==m.reservation_end_lba &&
                            get32(directory+256U)==m.reservation_end_lba);
        if(scenario>=6U){
            uint32_t legacy=scenario==6U?prefix:scenario==7U?m.run.payload_start_lba:ooo;
            np_put32(directory+4U,legacy);np_put32(directory+256U,legacy);
            assert(!write_sector(NULL,128U,directory));
        }
        rebind_card(capacity,1U);uint32_t writes=card.writes,commands=card.commands;
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && card.writes==writes && card.commands==commands);
        if(scenario==8U){
            assert(XE_NP_Np2DualSdCatalog_Status()==XE_NP_NP2_CATALOG_RECOVERY);
            assert(XE_NP_Np2DualSdCatalog_Recover(&next)<0 && card.writes==writes && card.commands==commands);
            assert(XE_NP_Np2DualSdCatalog_PlanProfile(mask,rate,8U,118U,crc32(config,2048U),&append)<0);
        }else{
            assert(XE_NP_Np2DualSdCatalog_Status()==(scenario?
                   XE_NP_NP2_CATALOG_RECOVERY|XE_NP_NP2_CATALOG_QUARANTINABLE:0U));
            if(scenario)assert(XE_NP_Np2DualSdCatalog_PlanProfile(mask,rate,8U,118U,
                               crc32(config,2048U),&append)<0);
            assert(!XE_NP_Np2DualSdCatalog_Recover(&next) && next==m.reservation_end_lba &&
                   !XE_NP_Np2DualSdCatalog_Status() && card.commands==commands);
            rebind_card(capacity,1U);writes=card.writes;
            assert(!XE_NP_Np2DualSdCatalog_Mount(&next) && next==m.reservation_end_lba && card.writes==writes);
            assert(!XE_NP_Np2DualSdCatalog_PlanProfile(mask,rate,8U,118U,crc32(config,2048U),&append) &&
                   append.reservation_start_lba==m.reservation_end_lba);
            assert(!XE_NP_Np2DualSdCatalog_Reserve(&append,config));
            assert(!XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0U,8U));
        }
        assert(!read_sector(NULL,m.reservation_start_lba+3U,after) && !memcmp(after,descriptor,512U));
        assert(!read_sector(NULL,m.reservation_start_lba+4U,after) && !memcmp(after,footer,512U));
        assert(!read_sector(NULL,m.run.payload_start_lba,after) && !memcmp(after,payload,512U));
        assert(!read_sector(NULL,ooo,after) && !memcmp(after,payload,512U));
        assert(!read_sector(NULL,m.reservation_end_lba-1U,after) && !memcmp(after,payload,512U));
    }
    puts("PASS FAILED OOO fence: full allocation, exact prefix/footer unchanged, five cuts, legacy expansion, ambiguous-tail refusal and safe next append");
}

static void test_profile_refusals_before_writes(void)
{
    uint32_t next;uint8_t system[512]={0},config[2048]={0};
    setup();rebind_card(501301248U,1U);
    assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    XE_NP_Np2DualSdMeta m,bad;memset(&bad,0xA5,sizeof(bad));
    uint8_t unchanged[sizeof(bad)];memcpy(unchanged,&bad,sizeof(bad));
    uint32_t writes=card.writes,commands=card.commands;
    static const struct {uint32_t mask,rate;} profiles[]={
        {0U,20000U},{2U,20000U},{4U,20000U},{5U,20000U},{6U,20000U},{8U,20000U},
        {1U,25000U},{3U,25000U},{7U,25000U}
    };
    for(uint32_t i=0U;i<sizeof(profiles)/sizeof(profiles[0]);i++){
        assert(XE_NP_Np2DualSdCatalog_PlanProfile(profiles[i].mask,profiles[i].rate,8U,101U,
                   crc32(config,2048U),&bad)<0 && !memcmp(&bad,unchanged,sizeof(bad)));
        assert(XE_NP_Np2DualSdCatalog_PlanAuProfile(profiles[i].mask,profiles[i].rate,8U,101U,
                   crc32(config,2048U),86016U,&bad)<0 && !memcmp(&bad,unchanged,sizeof(bad)));
    }
    assert(XE_NP_Np2DualSdCatalog_Plan(25000U,8U,101U,crc32(config,2048U),&bad)<0);
    assert(!XE_NP_Np2DualSdCatalog_PlanProfile(7U,20000U,8U,101U,crc32(config,2048U),&m));
    for(uint32_t i=0U;i<4U;i++){
        bad=m;
        if(i==0U)bad.run.probe_mask=8U;
        else if(i==1U)bad.run.sample_hz=25000U;
        else if(i==2U)bad.run.mclk_hz++;
        else bad.run.max_source_ticks=(uint64_t)bad.run.max_blocks*61440U;
        assert(XE_NP_Np2DualSdCatalog_Reserve(&bad,config)<0 && card.writes==writes && card.commands==commands);
    }
    /* Both seals carry the same forged fields: refusal must come from the
     * closed tuple/rate, not merely mismatched descriptor/footer identity. */
    static const struct {uint32_t offset,value;} corrupt[]={
        {24U,8U},{24U,3U},{16U,25000U},{20U,1U},{28U,63U},{32U,4U},
        {32U,5U},{36U,6U},{44U,61440U}
    };
    for(uint32_t i=0U;i<sizeof(corrupt)/sizeof(corrupt[0]);i++){
        setup();rebind_card(501301248U,1U);
        assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
        assert(!XE_NP_Np2DualSdCatalog_PlanAuProfile(7U,20000U,8U,101U,crc32(config,2048U),
                    i%2U?86016U:0U,&m));
        assert(!XE_NP_Np2DualSdCatalog_Reserve(&m,config));
        for(uint32_t sector=3U;sector<=4U;sector++){
            uint8_t bytes[512];assert(!read_sector(NULL,m.reservation_start_lba+sector,bytes));
            np_put32(bytes+corrupt[i].offset,corrupt[i].value);np_put32(bytes+508U,crc32(bytes,508U));
            assert(!write_sector(NULL,m.reservation_start_lba+sector,bytes));
        }
        rebind_card(501301248U,1U);writes=card.writes;commands=card.commands;
        assert(!XE_NP_Np2DualSdCatalog_Mount(&next) &&
               XE_NP_Np2DualSdCatalog_Status()==XE_NP_NP2_CATALOG_RECOVERY);
        assert(XE_NP_Np2DualSdCatalog_Recover(&next)<0);
        assert(XE_NP_Np2DualSdCatalog_Plan(30000U,4U,102U,crc32(config,2048U),&bad)<0);
        assert(XE_NP_Np2DualSdCatalog_PlanProfile(7U,15000U,4U,102U,crc32(config,2048U),&bad)<0);
        assert(card.writes==writes && card.commands==commands);
    }
    puts("PASS closed profiles and CRC-valid malformed dual/triple tuple/rate refuse before writes or stopped CMD20");
}
static XE_NP_Np2DualSdMeta available_tail(uint32_t state,uint32_t error,uint32_t mask,uint32_t rate,uint32_t legacy)
{
    setup();uint32_t next;uint8_t zero[2048]={0},footer[512],payload[512];XE_NP_Np2DualSdMeta m;
    assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,zero));
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    int result=legacy?XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(mask,rate,400U,901U,crc32(zero,2048U),2048U,&m):
                      XE_NP_Np2DualSdCatalog_PlanProfile(mask,rate,400U,901U,crc32(zero,2048U),&m);
    assert(!result && !XE_NP_Np2DualSdCatalog_Reserve(&m,zero));
    memset(payload,0xAD,512U);assert(!write_sector(NULL,m.run.payload_start_lba,payload));
    uint32_t prefix=m.run.payload_start_lba+8U*XE_NP_NP2_DUAL_SD_SECTORS_PER_BLOCK;
    assert(!write_sector(NULL,prefix-1U,payload));
    if(error!=XE_NP_NP2_DUAL_SD_META_VERIFY_PENDING && state!=XE_NP_NP2_DUAL_SD_META_COMPLETE)
        assert(!write_sector(NULL,m.reservation_end_lba-1U,payload)); /* Possible late OOO write. */
    assert(!XE_NP_Np2DualSd_EncodeFooter(footer,&m,state,error,8U));
    assert(!write_sector(NULL,m.reservation_start_lba+4U,footer));reboot();return m;
}
static void assert_retained(const XE_NP_Np2DualSdMeta *m,const uint8_t *header,const uint8_t *footer)
{
    uint8_t actual[512];
    assert(!read_sector(NULL,m->reservation_start_lba+3U,actual) && !memcmp(actual,header,512U));
    assert(!read_sector(NULL,m->reservation_start_lba+4U,actual) && !memcmp(actual,footer,512U));
    assert(!read_sector(NULL,m->run.payload_start_lba,actual));
    for(unsigned i=0U;i<512U;i++)assert(actual[i]==0xAD);
}
static void test_available_append(void)
{
    for(unsigned scenario=0U;scenario<9U;scenario++){
        uint32_t state=scenario==2U?XE_NP_NP2_DUAL_SD_META_COMPLETE:XE_NP_NP2_DUAL_SD_META_FAILED;
        uint32_t fault=state==XE_NP_NP2_DUAL_SD_META_COMPLETE?0U:scenario==1U?9U:XE_NP_NP2_DUAL_SD_META_VERIFY_PENDING;
        XE_NP_Np2DualSdMeta m=available_tail(state,fault,7U,15000U,scenario%2U);
        uint8_t h[512],f[512],directory[512],zero[2048]={0};uint32_t next,writes,commands;
        assert(!read_sector(NULL,m.reservation_start_lba+3U,h));assert(!read_sector(NULL,m.reservation_start_lba+4U,f));
        if(scenario==2U || scenario==4U){h[508]^=1;assert(!write_sector(NULL,m.reservation_start_lba+3U,h));}
        if(scenario==3U || scenario==4U){f[508]^=1;assert(!write_sector(NULL,m.reservation_start_lba+4U,f));}
        if(scenario==5U){assert(!read_sector(NULL,128U,directory));np_put32(directory,64U);assert(!write_sector(NULL,128U,directory));}
        if(scenario==6U){memset(directory,0xFF,512U);assert(!write_sector(NULL,112U,directory));}
        if(scenario==7U){assert(!read_sector(NULL,128U,directory));np_put32(directory+4U,m.reservation_end_lba+16384U);assert(!write_sector(NULL,128U,directory));}
        if(scenario==8U)rebind_card(card.capacity,5U);else reboot();
        writes=card.writes;commands=card.commands;
        assert(!XE_NP_Np2DualSdCatalog_MountAvailable(&next));
        assert(card.writes==writes && card.commands==commands);
        assert(XE_NP_Np2DualSdCatalog_Status()&XE_NP_NP2_CATALOG_DEGRADED);
        XE_NP_Np2DualSdMeta fresh;
        if(scenario>=4U){
            assert(next>=8192U && (XE_NP_Np2DualSdCatalog_Status()&XE_NP_NP2_CATALOG_RECOVERY));
            assert(XE_NP_Np2DualSdCatalog_Status()&XE_NP_NP2_CATALOG_REWIND_AVAILABLE);
            assert(XE_NP_Np2DualSdCatalog_PlanProfile(7U,15000U,4U,902U,crc32(zero,2048U),&fresh)<0);
            assert(card.writes==writes && card.commands==commands);assert_retained(&m,h,f);continue;
        }
        uint32_t protected_end=(scenario==1U || scenario==3U)?m.reservation_end_lba:
            m.run.payload_start_lba+8U*XE_NP_NP2_DUAL_SD_SECTORS_PER_BLOCK;
        assert(next==((protected_end+8191U)&~8191U) && XE_NP_Np2DualSdCatalog_Status()==XE_NP_NP2_CATALOG_DEGRADED);
        assert(!XE_NP_Np2DualSdCatalog_PlanProfile(7U,15000U,4U,902U,crc32(zero,2048U),&fresh));
        assert(fresh.reservation_start_lba>=protected_end && card.writes==writes);
        assert(!XE_NP_Np2DualSdCatalog_Reserve(&fresh,zero));
        assert(!read_sector(NULL,128U,directory) && get32(directory)==2U && get32(directory+4U)==protected_end);
        assert_retained(&m,h,f);
        if(scenario==1U){uint8_t actual[512];assert(!read_sector(NULL,m.reservation_end_lba-1U,actual));for(unsigned i=0;i<512U;i++)assert(actual[i]==0xAD);}
        assert(!XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0U,4U));reboot();
        assert(!XE_NP_Np2DualSdCatalog_MountAvailable(&next) && !XE_NP_Np2DualSdCatalog_Status());
    }
    puts("PASS available mount: checkpoint/COMPLETE/corrupt-header mirror/corrupt-footer append without old data changes; unknown directory/journal/CID/allocation stays mounted read-only");
}
static void test_available_start_cuts(void)
{
    XE_NP_Np2DualSdMeta old=available_tail(XE_NP_NP2_DUAL_SD_META_FAILED,XE_NP_NP2_DUAL_SD_META_VERIFY_PENDING,3U,20000U,0U);
    uint8_t h[512],f[512],zero[2048]={0},directory[512];
    assert(!read_sector(NULL,old.reservation_start_lba+3U,h));assert(!read_sector(NULL,old.reservation_start_lba+4U,f));
    static CardModel saved;saved=card;unsigned completed=0U;
    uint32_t prefix=old.run.payload_start_lba+8U*XE_NP_NP2_DUAL_SD_SECTORS_PER_BLOCK;
    for(uint32_t cut=1U;cut<32U;cut++){
        card=saved;reboot();uint32_t next,writes=card.writes,commands=card.commands;
        assert(!XE_NP_Np2DualSdCatalog_MountAvailable(&next) && card.writes==writes);
        XE_NP_Np2DualSdMeta fresh;assert(!XE_NP_Np2DualSdCatalog_Plan(20000U,4U,903U,crc32(zero,2048U),&fresh));
        card.failed_write=card.writes+cut;int result=XE_NP_Np2DualSdCatalog_Reserve(&fresh,zero);
        if(card.commands>commands){assert(!read_sector(NULL,128U,directory));assert(get32(directory+4U)>=prefix);}
        assert_retained(&old,h,f);card.failed_write=0U;reboot();writes=card.writes;
        assert(!XE_NP_Np2DualSdCatalog_MountAvailable(&next) && card.writes==writes);
        assert((XE_NP_Np2DualSdCatalog_Status()&XE_NP_NP2_CATALOG_RECOVERY) || next>=((prefix+8191U)&~8191U));
        if(!result){completed=cut;break;}
    }
    assert(completed>10U);
    puts("PASS every available-START publication write cut: old fence durable before CMD20/new metadata, source never armed, reboot never reuses old payload");
}
static XE_NP_Np2DualSdMeta rewind_tail(XE_NP_Np2DualSdMeta *retained)
{
    setup();uint8_t zero[2048]={0},sector[512];uint32_t next;
    assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,zero));
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    assert(!XE_NP_Np2DualSdCatalog_Plan(20000U,8U,910U,crc32(zero,2048U),retained));
    assert(!XE_NP_Np2DualSdCatalog_Reserve(retained,zero));
    memset(sector,0xAD,512U);assert(!write_sector(NULL,retained->run.payload_start_lba,sector));
    assert(!XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0U,8U));
    assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
    XE_NP_Np2DualSdMeta damaged;
    assert(!XE_NP_Np2DualSdCatalog_Plan(20000U,400U,911U,crc32(zero,2048U),&damaged));
    assert(!XE_NP_Np2DualSdCatalog_Reserve(&damaged,zero));
    assert(!read_sector(NULL,damaged.reservation_start_lba+3U,sector));sector[508]^=1U;
    assert(!write_sector(NULL,damaged.reservation_start_lba+3U,sector));
    assert(!read_sector(NULL,damaged.reservation_start_lba+4U,sector));sector[508]^=1U;
    assert(!write_sector(NULL,damaged.reservation_start_lba+4U,sector));
    reboot();return damaged;
}
static void test_explicit_rewind(void)
{
    XE_NP_Np2DualSdMeta old,damaged=rewind_tail(&old),fresh;
    uint8_t h[512],f[512],bad_h[512],bad_f[512],actual[512],zero[2048]={0};
    assert(!read_sector(NULL,old.reservation_start_lba+3U,h));assert(!read_sector(NULL,old.reservation_start_lba+4U,f));
    assert(!read_sector(NULL,damaged.reservation_start_lba+3U,bad_h));assert(!read_sector(NULL,damaged.reservation_start_lba+4U,bad_f));
    uint32_t next,writes=card.writes,commands=card.commands;
    assert(!XE_NP_Np2DualSdCatalog_MountAvailable(&next) && next==damaged.reservation_start_lba);
    assert(XE_NP_Np2DualSdCatalog_Status()==(XE_NP_NP2_CATALOG_DEGRADED|XE_NP_NP2_CATALOG_RECOVERY|XE_NP_NP2_CATALOG_REWIND_AVAILABLE));
    assert(XE_NP_Np2DualSdCatalog_Plan(20000U,4U,912U,crc32(zero,2048U),&fresh)<0);
    assert(XE_NP_Np2DualSdCatalog_Rewind(0U,next,&next)<0);
    assert(XE_NP_Np2DualSdCatalog_Rewind(XE_NP_NP2_CATALOG_REWIND_KEY,next+8192U,&next)<0);
    assert(card.writes==writes && card.commands==commands); /* Showing/canceling the offer writes nothing. */
    assert(!XE_NP_Np2DualSdCatalog_Rewind(XE_NP_NP2_CATALOG_REWIND_KEY,next,&next));
    assert(card.writes==writes+4U && card.commands==commands);
    assert(next==damaged.reservation_start_lba && XE_NP_Np2DualSdCatalog_Status()==XE_NP_NP2_CATALOG_DEGRADED);
    assert_retained(&old,h,f);
    assert(!read_sector(NULL,damaged.reservation_start_lba+3U,actual) && !memcmp(actual,bad_h,512U));
    assert(!read_sector(NULL,damaged.reservation_start_lba+4U,actual) && !memcmp(actual,bad_f,512U));
    assert(!read_sector(NULL,128U,actual) && get32(actual)==1U && get32(actual+4U)==old.run.payload_start_lba+8U*XE_NP_NP2_DUAL_SD_SECTORS_PER_BLOCK);
    writes=card.writes;
    assert(XE_NP_Np2DualSdCatalog_Rewind(XE_NP_NP2_CATALOG_REWIND_KEY,next,&next)<0 && card.writes==writes);
    assert(!XE_NP_Np2DualSdCatalog_Plan(20000U,4U,912U,crc32(zero,2048U),&fresh));
    assert(fresh.reservation_start_lba==damaged.reservation_start_lba);
    assert(!XE_NP_Np2DualSdCatalog_Reserve(&fresh,zero));
    assert(!XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0U,4U));assert_retained(&old,h,f);
    reboot();assert(!XE_NP_Np2DualSdCatalog_MountAvailable(&next) && !XE_NP_Np2DualSdCatalog_Status());
    puts("PASS explicit rewind: aligned offered prefix, no ordinary START bypass, key/position guards, journal-only truncation, raw data unchanged until later recording, safe append");
}
static void test_rewind_cuts_and_prefix(void)
{
    XE_NP_Np2DualSdMeta old,damaged=rewind_tail(&old);
    uint8_t h[512],f[512],directory[512];
    assert(!read_sector(NULL,old.reservation_start_lba+3U,h));assert(!read_sector(NULL,old.reservation_start_lba+4U,f));
    static CardModel saved;saved=card;
    for(uint32_t torn=0U;torn<2U;torn++)for(uint32_t cut=1U;cut<=5U;cut++){
        card=saved;reboot();uint32_t next,writes=card.writes,commands=card.commands;
        assert(!XE_NP_Np2DualSdCatalog_MountAvailable(&next) && next==damaged.reservation_start_lba && writes==card.writes);
        card.failed_write=card.writes+cut;card.torn_write=torn;
        int result=XE_NP_Np2DualSdCatalog_Rewind(XE_NP_NP2_CATALOG_REWIND_KEY,next,&next);
        assert((result==0)==(cut==5U));assert(card.commands==commands);assert_retained(&old,h,f);
        card.failed_write=card.torn_write=0U;reboot();writes=card.writes;
        assert(!XE_NP_Np2DualSdCatalog_MountAvailable(&next) && writes==card.writes);
        assert(next>=damaged.reservation_start_lba);assert_retained(&old,h,f);
    }
    /* A bad later entry retains the preceding entries even in the same page. */
    card=saved;assert(!read_sector(NULL,128U,directory));np_put32(directory+8U,1U);
    assert(!write_sector(NULL,128U,directory));reboot();uint32_t next,writes=card.writes;
    assert(!XE_NP_Np2DualSdCatalog_MountAvailable(&next) && next==damaged.reservation_start_lba && writes==card.writes);
    assert(XE_NP_Np2DualSdCatalog_Status()&XE_NP_NP2_CATALOG_REWIND_AVAILABLE);
    assert(!XE_NP_Np2DualSdCatalog_Rewind(XE_NP_NP2_CATALOG_REWIND_KEY,next,&next));assert_retained(&old,h,f);
    /* Failed later-page read keeps the full earlier page and offers a new page. */
    setup();card.capacity=1048576U;rebind_card(card.capacity,1U);
    uint8_t zero[512]={0};assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,zero));
    NpCe64SysLog log={0};log.count=63U;
    for(uint32_t i=0U;i<63U;i++)log.end[i]=log.event_end[i]=8192U+(i+1U)*8192U;
    assert(!write_sector(NULL,128U,(const uint8_t *)&log));card.failed_read_lba=129U;rebind_card(card.capacity,1U);writes=card.writes;
    assert(!XE_NP_Np2DualSdCatalog_MountAvailable(&next) && next==524288U && writes==card.writes);
    assert(XE_NP_Np2DualSdCatalog_Status()&XE_NP_NP2_CATALOG_REWIND_AVAILABLE);
    card.failed_read_lba=UINT32_MAX;
    /* A recovered read may change the offer; stale confirmation cannot write. */
    assert(XE_NP_Np2DualSdCatalog_Rewind(XE_NP_NP2_CATALOG_REWIND_KEY,next,&next)<0 && writes==card.writes);
    memset(directory,0,512U);np_put32(directory,64U);assert(!write_sector(NULL,129U,directory));
    rebind_card(card.capacity,1U);assert(!XE_NP_Np2DualSdCatalog_MountAvailable(&next) && next==524288U);
    assert(!XE_NP_Np2DualSdCatalog_Rewind(XE_NP_NP2_CATALOG_REWIND_KEY,next,&next));
    assert(!read_sector(NULL,128U,directory) && !memcmp(directory,&log,512U));
    assert(!read_sector(NULL,129U,directory) && !get32(directory));
    /* Unknown identity never offers this operation; use explicit Format instead. */
    setup();assert(!XE_NP_Np2DualSdCatalog_MountAvailable(&next) && !next);
    assert(!(XE_NP_Np2DualSdCatalog_Status()&XE_NP_NP2_CATALOG_REWIND_AVAILABLE));
    writes=card.writes;assert(XE_NP_Np2DualSdCatalog_Rewind(XE_NP_NP2_CATALOG_REWIND_KEY,8192U,&next)<0 && writes==card.writes);
    puts("PASS rewind four write cuts before/torn publication, retained earlier payload, same-page prefix, failed later page, identity admission; no erase/CMD20/source arm");
}
int main(void)
{test_two_sessions();test_failed_footer_is_not_complete();test_trim_journal_failure_retains_reservation();test_recovery();test_journal_recovery();test_every_finish_cut();test_quarantine_preserves_extent_and_allows_next_session();test_every_quarantine_cut();test_unknown_quarantine_bounds_fail_closed();test_quarantine_card_identity_and_full_capacity();test_stopped_written_checkpoint(20000U);test_stopped_written_checkpoint(30000U);test_finalized_media_append_preserves_camera_mount(20000U,0U);test_finalized_media_append_preserves_camera_mount(30000U,0U);test_finalized_media_append_preserves_camera_mount(20000U,86016U);test_finalized_media_append_preserves_camera_mount(30000U,86016U);test_uncertain_media_tail_refuses_append();test_shared_tag_guard_and_legacy_upgrade();test_counter_wrap_remount(20000U);test_counter_wrap_remount(30000U);test_au_plan_and_actual_end(20000U);test_au_plan_and_actual_end(30000U);test_au_recovery();test_au_rejections();test_legacy_au_sessions();test_legacy_au_recovery();test_legacy_au_rejections();test_mixed_profiles();test_triple_recovery(15000U,0U);test_triple_recovery(20000U,0U);test_triple_recovery(15000U,86016U);test_triple_recovery(20000U,86016U);test_failed_ooo_allocation_fence(3U,20000U,0U);test_failed_ooo_allocation_fence(3U,30000U,0U);test_failed_ooo_allocation_fence(7U,15000U,0U);test_failed_ooo_allocation_fence(7U,20000U,86016U);test_profile_refusals_before_writes();test_available_append();test_available_start_cuts();test_explicit_rewind();test_rewind_cuts_and_prefix();return 0;}
