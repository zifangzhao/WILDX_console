from pathlib import Path
import hashlib, importlib.util, json, re, sys
R=Path('D:/Code/XE_NP_V2');T=Path('C:/Frank/Code/XE_NP/_artifacts/v2_gui_support_fix_20261105');O=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
pins={'xe_np_usb_maintenance.inc':'E206A763A72C153DD1A8EC060EA52EB18E28843522677AA722E774AEFB5AB755','xe_np_usb_catalog.inc':'651A9DA8ED61E9141C8D80645FB9AC812C12CD2A1E570BF931F7202F8386161F'}
for n,h in pins.items():assert sha(T/'Core/Src'/n)==h,(n,'owner pin changed')
spec=importlib.util.spec_from_file_location('prior',R/'Tools/tests/test_usb_catalog_repair.py');prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
def actual(name):
 s=(T/'Core/Src'/name).read_text()
 s=re.sub(r'(?m)^(static [^;\n]+?) __attribute__\(\(aligned\(32\)\)\);',r'__declspec(align(32)) \1;',s)
 s=s.replace('__attribute__((noinline))','__declspec(noinline)')
 assert '__attribute__' not in s
 (O/('actual_'+name)).write_text(s)
 return s
adapter=actual('xe_np_usb_catalog.inc');maintenance=actual('xe_np_usb_maintenance.inc')
model=prior.MODEL.replace('@CATALOG_TEST@',(R/'Tools/V2SdLogger/tests/test_np2_dual_sd_catalog.c').as_posix())
model=model.replace('typedef struct {uint32_t token;} PCD_HandleTypeDef;','typedef struct {uint32_t token;struct {uint32_t dma_enable;} Init;} PCD_HandleTypeDef;')
model=model.replace('static struct {uint32_t valid;} np_download_prefetch;','static struct {uint32_t valid,lba,blocks,slot,error;} np_download_prefetch;')
model=model.replace('static uint32_t sent[16];','static uint32_t sent[96],sent_len;\nstatic void report_probe(void);')
model=model.replace('#define __set_PRIMASK(key) (primask=(key))','#define __set_PRIMASK(key) do{primask=(key);if(!primask)report_probe();}while(0)')
model=model.replace('assert(p==&fixture_pcd && n==64U && requested==64U);memcpy(sent,b,64U);sends++;','assert(p==&fixture_pcd && n==requested && n<=384U);memcpy(sent,b,n);sent_len=n;sends++;')
model=model.replace('hal_reads++;h->Context=SD_CONTEXT_READ_SINGLE_BLOCK;','report_probe();hal_reads++;h->Context=SD_CONTEXT_READ_SINGLE_BLOCK;')
model=model.replace('hal_writes++;h->Context=SD_CONTEXT_WRITE_SINGLE_BLOCK;','report_probe();assert(xe_np_usb_catalog.operation!=0xA7U || (xe_np_usb_delete_writes_allowed && (lba==112U || lba==113U || lba==xe_np_usb_delete_directory_lba)));hal_writes++;h->Context=SD_CONTEXT_WRITE_SINGLE_BLOCK;')
# HAL mocks precede the actual adapter declaration: put only its operation
# through a callback, while retaining all real write-allowlist code below.
model=model.replace('assert(xe_np_usb_catalog.operation!=0xA7U || (xe_np_usb_delete_writes_allowed && (lba==112U || lba==113U || lba==xe_np_usb_delete_directory_lba)));','assert_delete_write(lba);')
model=model.replace('static void report_probe(void);','static void report_probe(void);static void assert_delete_write(uint32_t lba);')
prefix=r'''
#include <stdlib.h>
#pragma warning(disable:4459) /* Existing mock global 'download' vs actual local. */
#include "xe_np_sd_info.h"
static void usb_maintenance_cancel(void);
static uint32_t xe_np_usb_maintenance_active,xe_np_usb_delete_writes_allowed,xe_np_usb_delete_directory_lba;
static uint32_t xe_np_selftest_dirty,sd_test_busy,sd_test_active,raw_sink,xe_np_usb_card_ready;
static uint32_t board_queries,reinits,irq_disabled,query_wrong_cid,query_wrong_capacity,restore_wrong_cid,restore_wrong_capacity,restore_fail,restore_busy;
static uint32_t rx_count,receive_fail;static uint8_t *rx_target;
static uint32_t uid0=0x12345678U,uid1=0x23456789U,uid2=0x34567890U;
static uint32_t probe_enable,probing,snapshot_checks;
typedef struct {uint32_t flags;} XE_NP_Runtime;
static XE_NP_Runtime runtime;
static uint32_t null_runtime;
#define XE_NP_RUNTIME_FLAG_NP_CAPTURE_DMA_ACTIVE 1U
#define RCC_PERIPHCLK_SDMMC 1U
#define SDMMC1_IRQn 1U
static uint32_t HAL_RCCEx_GetPeriphCLKFreq(uint32_t n){assert(n==RCC_PERIPHCLK_SDMMC);return 216000000U;}
static uint32_t HAL_GetUIDw0(void){return uid0;}static uint32_t HAL_GetUIDw1(void){return uid1;}static uint32_t HAL_GetUIDw2(void){return uid2;}
static const XE_NP_Runtime *XE_NP_App_GetRuntime(void){return null_runtime?NULL:&runtime;}
static int XE_NP_App_IsRawSdSinkActive(void){return raw_sink!=0;}
static int xe_np_usb_sd_test_busy(void){return sd_test_busy!=0;}static int XE_NP_UsbSdTest_Active(void){return sd_test_active!=0;}
static void XE_NP_Capture_DCacheInvalidate(const void *p,uint32_t n){assert(p&&n);}
'''
# prefix needs assert/uint before the reused sparse model includes them.
model='#include <assert.h>\n#include <stdint.h>\n'+prefix+model
bridge=r'''
static XE_NP_SdInfo xe_np_usb_sd_info,xe_np_usb_sd_info_ep0;
static uint32_t HAL_PCD_EP_GetRxCount(PCD_HandleTypeDef *p,uint32_t ep){assert(p==&fixture_pcd&&ep==0);return rx_count;}
static HAL_StatusTypeDef HAL_PCD_EP_Receive(PCD_HandleTypeDef *p,uint32_t ep,uint8_t *b,uint32_t n){assert(p==&fixture_pcd&&ep==0&&n==64);rx_target=b;return receive_fail?HAL_ERROR:HAL_OK;}
static void HAL_NVIC_DisableIRQ(uint32_t n){assert(n==SDMMC1_IRQn);irq_disabled++;}
void XE_NP_Board_ReadSdInfo(XE_NP_SdInfo *info){
 assert(!ipsr&&!primask);board_queries++;info->state=XE_NP_SD_INFO_READY;info->sectors_low=card.capacity;
 for(uint32_t i=0;i<16;i++)info->cid[i]=(uint8_t)(hsd1.CID[i/4]>>(24-8*(i%4)));
 if(query_wrong_cid)info->cid[0]^=1;if(query_wrong_capacity)info->sectors_low--;
 hsd1.Instance=NULL;hsd1.State=0;hsd1.SdCard.LogBlockNbr=0;memset(hsd1.CID,0,16);
}
static int XE_NP_Board_InitSdDownload(void){
 reinits++;hsd1.Instance=SDMMC1;hsd1.State=HAL_SD_STATE_READY;hsd1.Context=hsd1.ErrorCode=0;
 hsd1.SdCard.LogBlockNbr=card.capacity;for(uint32_t i=0;i<4;i++)hsd1.CID[i]=i+1;
 if(restore_wrong_cid)hsd1.CID[0]^=1;if(restore_wrong_capacity)hsd1.SdCard.LogBlockNbr--;
 if(restore_busy)hsd1.Context=SD_CONTEXT_READ_SINGLE_BLOCK;return restore_fail?-1:0;
}
'''
cases=prior.CASES.replace('int main(void){positive();','int prior_adapter_cases(void){positive();')
tail=(O/'cases.c').read_text()
text=prior.constants(adapter+maintenance+model+bridge+cases+tail,cmsis='stm32u595xx.h')+model+'\n#include "actual_xe_np_usb_catalog.inc"\n'+bridge+'\n#include "actual_xe_np_usb_maintenance.inc"\n'+cases+tail
(O/'fixture.c').write_text(text)
defs={'XE_NP_IMAGE_ROLE':'2U','XE_NP_USB_CATALOG_REPAIR_ENABLE':'1U','XE_NP_NP2_SD_CATALOG_ENABLE':'1U','XE_NP_NP2_SD_APPEND_ORDER_TEST':'1U','XE_NP_NP2_USB_SOURCE_ENABLE':'1U','NP_SD_USB_PREFETCH':'1U','NP_SD_USB_CONTINUOUS':'1U'}
sources=tuple(R/('Core/Src/'+n+'.c') for n in ('xe_np_np2_dual_sd_catalog','xe_np_np2_dual_sd_meta','xe_np_np2_dual_sd_run'))
prior.invoke(O,'maintenance',O/'fixture.c',defs,extra_sources=sources)
for n,h in pins.items():assert sha(T/'Core/Src'/n)==h,'Source changed during native acceptance'
receipt={'status':'PASS','hardware_access':False,'firmware_build':False,'owner_pins':pins,'fixture_sha256':sha(O/'fixture.c'),'runner_sha256':sha(__file__),'result':(O/'maintenance.run.log').read_text(),'scope':'Actual full staged maintenance+catalog adapter and real portable sparse-card catalog/meta/run; mocked HAL/USB/query boundaries, no hardware throughput or power-cut claim.'}
(O/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
