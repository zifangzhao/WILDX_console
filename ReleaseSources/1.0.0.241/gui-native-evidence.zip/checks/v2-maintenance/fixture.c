#define HAL_SD_ERROR_GENERAL_UNKNOWN_ERR SDMMC_ERROR_GENERAL_UNKNOWN_ERR
#define SDMMC_CLKCR_CLKDIV SDMMC_CLKCR_CLKDIV_Msk
#define SDMMC_CLKCR_CLKDIV_Msk (0x3FFUL << SDMMC_CLKCR_CLKDIV_Pos)
#define SDMMC_CLKCR_CLKDIV_Pos (0UL)
#define SDMMC_DCTRL_DTEN SDMMC_DCTRL_DTEN_Msk
#define SDMMC_DCTRL_DTEN_Msk (0x1UL << SDMMC_DCTRL_DTEN_Pos)
#define SDMMC_DCTRL_DTEN_Pos (0UL)
#define SDMMC_ERROR_GENERAL_UNKNOWN_ERR ((uint32_t)0x00010000U)
#define SDMMC_STA_BUSYD0 SDMMC_STA_BUSYD0_Msk
#define SDMMC_STA_BUSYD0_Msk (0x1UL << SDMMC_STA_BUSYD0_Pos)
#define SDMMC_STA_BUSYD0_Pos (20UL)
#define SDMMC_STA_CPSMACT SDMMC_STA_CPSMACT_Msk
#define SDMMC_STA_CPSMACT_Msk (0x1UL << SDMMC_STA_CPSMACT_Pos)
#define SDMMC_STA_CPSMACT_Pos (13UL)
#define SDMMC_STA_DCRCFAIL SDMMC_STA_DCRCFAIL_Msk
#define SDMMC_STA_DCRCFAIL_Msk (0x1UL << SDMMC_STA_DCRCFAIL_Pos)
#define SDMMC_STA_DCRCFAIL_Pos (1UL)
#define SDMMC_STA_DPSMACT SDMMC_STA_DPSMACT_Msk
#define SDMMC_STA_DPSMACT_Msk (0x1UL << SDMMC_STA_DPSMACT_Pos)
#define SDMMC_STA_DPSMACT_Pos (12UL)
#define SDMMC_STA_DTIMEOUT SDMMC_STA_DTIMEOUT_Msk
#define SDMMC_STA_DTIMEOUT_Msk (0x1UL << SDMMC_STA_DTIMEOUT_Pos)
#define SDMMC_STA_DTIMEOUT_Pos (3UL)
#define SDMMC_STA_IDMATE SDMMC_STA_IDMATE_Msk
#define SDMMC_STA_IDMATE_Msk (0x1UL << SDMMC_STA_IDMATE_Pos)
#define SDMMC_STA_IDMATE_Pos (27UL)
#define SDMMC_STA_RXOVERR SDMMC_STA_RXOVERR_Msk
#define SDMMC_STA_RXOVERR_Msk (0x1UL << SDMMC_STA_RXOVERR_Pos)
#define SDMMC_STA_RXOVERR_Pos (5UL)
#define SDMMC_STA_TXUNDERR SDMMC_STA_TXUNDERR_Msk
#define SDMMC_STA_TXUNDERR_Msk (0x1UL << SDMMC_STA_TXUNDERR_Pos)
#define SDMMC_STA_TXUNDERR_Pos (4UL)
#define SD_CONTEXT_NONE ((uint32_t)0x00000000U)
#define SD_CONTEXT_READ_SINGLE_BLOCK ((uint32_t)0x00000001U)
#define SD_CONTEXT_WRITE_SINGLE_BLOCK ((uint32_t)0x00000010U)
#include <assert.h>
#include <stdint.h>

#include <stdlib.h>
#pragma warning(disable:4459) /* Existing mock global 'download' vs actual local. */
#include "xe_np_sd_info.h"
static void usb_maintenance_cancel(void);
static uint32_t xe_np_usb_maintenance_active,xe_np_usb_delete_writes_allowed,xe_np_usb_delete_directory_lba;
static uint32_t xe_np_selftest_dirty,sd_test_busy,sd_test_active,raw_sink,xe_np_usb_card_ready;
static uint32_t board_queries,reinits,irq_disabled,query_wrong_cid,query_wrong_capacity,restore_wrong_cid,restore_wrong_capacity,restore_fail,restore_busy;
static uint32_t rx_count,receive_fail;static uint8_t *rx_target;
static uint32_t uid0=0x12345678U,uid1=0x23456789U,uid2=0x34567890U;
static uint32_t probe_enable,probing,snapshot_checks;
typedef struct {uint32_t flags;} XE_NP_Runtime;
static XE_NP_Runtime runtime;
static uint32_t null_runtime;
#define XE_NP_RUNTIME_FLAG_NP_CAPTURE_DMA_ACTIVE 1U
#define RCC_PERIPHCLK_SDMMC 1U
#define SDMMC1_IRQn 1U
static uint32_t HAL_RCCEx_GetPeriphCLKFreq(uint32_t n){assert(n==RCC_PERIPHCLK_SDMMC);return 216000000U;}
static uint32_t HAL_GetUIDw0(void){return uid0;}static uint32_t HAL_GetUIDw1(void){return uid1;}static uint32_t HAL_GetUIDw2(void){return uid2;}
static const XE_NP_Runtime *XE_NP_App_GetRuntime(void){return null_runtime?NULL:&runtime;}
static int XE_NP_App_IsRawSdSinkActive(void){return raw_sink!=0;}
static int xe_np_usb_sd_test_busy(void){return sd_test_busy!=0;}static int XE_NP_UsbSdTest_Active(void){return sd_test_active!=0;}
static void XE_NP_Capture_DCacheInvalidate(const void *p,uint32_t n){assert(p&&n);}

#define main historical_catalog_suite_not_executed
#include "D:/Code/XE_NP_V2/Tools/V2SdLogger/tests/test_np2_dual_sd_catalog.c"
#undef main
/* Reuse the existing sparse card/real metadata setup, not a synthetic mount. */
typedef enum {HAL_OK=0,HAL_ERROR=1} HAL_StatusTypeDef;
typedef uint32_t HAL_SD_CardStateTypeDef;
#define HAL_SD_STATE_READY 1U
#define HAL_SD_CARD_TRANSFER 4U
#define HAL_SD_CARD_PROGRAMMING 7U
#define HAL_SD_CARD_ERROR 255U
typedef struct {volatile uint32_t CLKCR,STA,IDMACTRL,DCTRL,RESPCMD,RESP1;} SDMMC_TypeDef;
static SDMMC_TypeDef sd_regs;
#define SDMMC1 (&sd_regs)
typedef struct {SDMMC_TypeDef *Instance;uint32_t State,ErrorCode,Context;
 struct {uint32_t LogBlockNbr;} SdCard;uint32_t CID[4];} SD_HandleTypeDef;
static SD_HandleTypeDef hsd1;
typedef struct {uint32_t token;struct {uint32_t dma_enable;} Init;} PCD_HandleTypeDef;
typedef struct {uint8_t bmRequest,bRequest;uint16_t wValue,wIndex,wLength;} XE_NP_UsbSetup;
static PCD_HandleTypeDef fixture_pcd;
static struct {PCD_HandleTypeDef *hpcd;uint32_t configured,bootloader_reset_pending,
 bootloader_reset_armed,streaming,real_start_pending,tx_busy,tx_pending;} xe_np_usb_state;
static struct {uint32_t target;} xe_np_usb_mode;
static uint32_t xe_np_usb_sd_info_pending,np_download_state,np_download_burst_armed;
static uint32_t np_download_burst_remaining,np_download_epoch,np2_config_receiving,np2_config_pending;
static struct {uint32_t valid,lba,blocks,slot,error;} np_download_prefetch;
static uint32_t download,selftest,aux,np2busy,sourcebusy,sourceready,armed;
typedef struct {uint32_t CR,CR1;} Peripheral;
static Peripheral pssi,spi1,spi2;
static struct {uint32_t CFGR1;} rcc;
#define PSSI (&pssi)
#define SPI1 (&spi1)
#define SPI2 (&spi2)
#define RCC (&rcc)
#define PSSI_CR_ENABLE 1U
#define SPI_CR1_SPE 1U
#define RCC_CFGR1_MCOSEL 0xFU
#define RCC_CFGR1_MCOPRE 0xF0U
#define DMA_CCR_EN 1U
#define DMA_CCR_RESET 2U
#define DMA_CCR_SUSP 4U
typedef struct {volatile uint32_t CCR;uint8_t pad[124];} DMA_Channel_TypeDef;
static DMA_Channel_TypeDef dma[16];
#define GPDMA1_Channel0 (&dma[0])
static uint32_t primask,ipsr,basepri,faultmask,tick,stalls,acks,sends,dsbs;
static uint32_t hal_reads,hal_writes,polls,rdy_wait,program_wait,poll_timeout;
static uint32_t cancel_read,cancel_write,epoch_read,identity_read,owner_read,active_read;
static uint32_t sent[96],sent_len;
static void report_probe(void);static void assert_delete_write(uint32_t lba);
#define __get_PRIMASK() primask
#define __get_IPSR() ipsr
#define __get_BASEPRI() basepri
#define __get_FAULTMASK() faultmask
#define __disable_irq() (primask=1U)
#define __set_PRIMASK(key) do{primask=(key);if(!primask)report_probe();}while(0)
#define __DMB() ((void)0)
#define __DSB() (++dsbs)
static uint32_t HAL_GetTick(void){return tick++;}
static int XE_NP_UsbUnified_IsDownload(void){return download!=0U;}
static int xe_np_usb_selftest_busy(void){return selftest!=0U;}
static int XE_NP_UsbAux_IsBusy(void){return aux!=0U;}
static int np2_usb_busy(void){return np2busy!=0U;}
static int XE_NP_Np2UsbSource_IsBusy(void){return sourcebusy!=0U;}
static int XE_NP_Np2UsbSource_IsReady(void){return sourceready!=0U;}
static int XE_NP_Np2CapturePort_Armed(void){return armed!=0U;}
static uint32_t NP_SD_DownloadCapacity(void){return download?hsd1.SdCard.LogBlockNbr:0U;}
static void XE_NP_UsbStream_Stall(PCD_HandleTypeDef *p){(void)p;stalls++;}
static void XE_NP_UsbStream_CtlStatus(PCD_HandleTypeDef *p){assert(p==&fixture_pcd);acks++;}
static void XE_NP_UsbStream_CtlSend(PCD_HandleTypeDef *p,const uint8_t *b,uint32_t n,uint32_t requested){
 assert(p==&fixture_pcd && n==requested && n<=384U);memcpy(sent,b,n);sent_len=n;sends++;
}
static void xe_np_usb_catalog_cancel(void);
static HAL_StatusTypeDef HAL_SD_ReadBlocks(SD_HandleTypeDef *h,uint8_t *out,uint32_t lba,uint32_t n,uint32_t timeout){
 assert(!ipsr && !primask && h==&hsd1 && n==1U && timeout==1000U && (h->Instance->CLKCR&1023U)==8U);
 assert(!((uintptr_t)out&31U));report_probe();hal_reads++;h->Context=SD_CONTEXT_READ_SINGLE_BLOCK;
 int result=read_sector(NULL,lba,out);
 if(cancel_read==hal_reads)xe_np_usb_catalog_cancel();
 if(epoch_read==hal_reads)np_download_epoch++;
 if(identity_read==hal_reads)hsd1.CID[0]^=1U;
 if(owner_read==hal_reads)dma[5].CCR=DMA_CCR_EN;
 if(active_read==hal_reads){sd_regs.DCTRL=SDMMC_DCTRL_DTEN;sd_regs.STA=SDMMC_STA_DPSMACT;sd_regs.IDMACTRL=1U;}
 return result?HAL_ERROR:HAL_OK;
}
static HAL_StatusTypeDef HAL_SD_WriteBlocks(SD_HandleTypeDef *h,uint8_t *in,uint32_t lba,uint32_t n,uint32_t timeout){
 assert(!ipsr && !primask && h==&hsd1 && n==1U && timeout==1000U && (h->Instance->CLKCR&1023U)==8U);
 assert(!((uintptr_t)in&31U) && (lba==112U || lba==113U || (lba>=128U && lba<1152U)));
 report_probe();assert_delete_write(lba);hal_writes++;h->Context=SD_CONTEXT_WRITE_SINGLE_BLOCK;
 int result=write_sector(NULL,lba,in);
 if(cancel_write==hal_writes)xe_np_usb_catalog_cancel();
 return result?HAL_ERROR:HAL_OK;
}
static HAL_SD_CardStateTypeDef HAL_SD_GetCardState(SD_HandleTypeDef *h){
 assert(!ipsr && !primask && h==&hsd1);polls++;h->Instance->RESPCMD=13U;
 h->Instance->RESP1=(rdy_wait || poll_timeout)?0U:(1U<<8U);
 if(rdy_wait){rdy_wait--;assert(h->Context!=SD_CONTEXT_NONE);}
 if(program_wait){program_wait--;return HAL_SD_CARD_PROGRAMMING;}
 return HAL_SD_CARD_TRANSFER;
}

#include "actual_xe_np_usb_catalog.inc"

static XE_NP_SdInfo xe_np_usb_sd_info,xe_np_usb_sd_info_ep0;
static uint32_t HAL_PCD_EP_GetRxCount(PCD_HandleTypeDef *p,uint32_t ep){assert(p==&fixture_pcd&&ep==0);return rx_count;}
static HAL_StatusTypeDef HAL_PCD_EP_Receive(PCD_HandleTypeDef *p,uint32_t ep,uint8_t *b,uint32_t n){assert(p==&fixture_pcd&&ep==0&&n==64);rx_target=b;return receive_fail?HAL_ERROR:HAL_OK;}
static void HAL_NVIC_DisableIRQ(uint32_t n){assert(n==SDMMC1_IRQn);irq_disabled++;}
void XE_NP_Board_ReadSdInfo(XE_NP_SdInfo *info){
 assert(!ipsr&&!primask);board_queries++;info->state=XE_NP_SD_INFO_READY;info->sectors_low=card.capacity;
 for(uint32_t i=0;i<16;i++)info->cid[i]=(uint8_t)(hsd1.CID[i/4]>>(24-8*(i%4)));
 if(query_wrong_cid)info->cid[0]^=1;if(query_wrong_capacity)info->sectors_low--;
 hsd1.Instance=NULL;hsd1.State=0;hsd1.SdCard.LogBlockNbr=0;memset(hsd1.CID,0,16);
}
static int XE_NP_Board_InitSdDownload(void){
 reinits++;hsd1.Instance=SDMMC1;hsd1.State=HAL_SD_STATE_READY;hsd1.Context=hsd1.ErrorCode=0;
 hsd1.SdCard.LogBlockNbr=card.capacity;for(uint32_t i=0;i<4;i++)hsd1.CID[i]=i+1;
 if(restore_wrong_cid)hsd1.CID[0]^=1;if(restore_wrong_capacity)hsd1.SdCard.LogBlockNbr--;
 if(restore_busy)hsd1.Context=SD_CONTEXT_READ_SINGLE_BLOCK;return restore_fail?-1:0;
}

#include "actual_xe_np_usb_maintenance.inc"

static void reset_usb(void){
 memset(&xe_np_usb_catalog,0,sizeof(xe_np_usb_catalog));
 memset(xe_np_usb_catalog_report,0,64U);
 xe_np_usb_catalog_report[0]=XE_NP_USB_CATALOG_MAGIC;xe_np_usb_catalog_report[1]=1U;
 memset(&sd_regs,0,sizeof(sd_regs));memset(dma,0,sizeof(dma));
 memset(&xe_np_usb_state,0,sizeof(xe_np_usb_state));
 memset(&pssi,0,sizeof(pssi));memset(&spi1,0,sizeof(spi1));memset(&spi2,0,sizeof(spi2));rcc.CFGR1=0U;
 hsd1.Instance=SDMMC1;hsd1.State=HAL_SD_STATE_READY;hsd1.ErrorCode=hsd1.Context=0U;
 hsd1.SdCard.LogBlockNbr=card.capacity;for(uint32_t i=0U;i<4U;i++)hsd1.CID[i]=i+1U;
 sd_regs.CLKCR=0x002B4000U;xe_np_usb_state.hpcd=&fixture_pcd;xe_np_usb_state.configured=1U;
 download=1U;selftest=aux=np2busy=sourcebusy=sourceready=armed=0U;xe_np_usb_mode.target=0U;
 np_download_state=np_download_burst_armed=np_download_burst_remaining=np_download_prefetch.valid=0U;
 np2_config_receiving=np2_config_pending=xe_np_usb_sd_info_pending=0U;
 np_download_epoch=7U;primask=ipsr=basepri=faultmask=tick=stalls=acks=sends=dsbs=0U;
 hal_reads=hal_writes=polls=rdy_wait=program_wait=poll_timeout=0U;
 cancel_read=cancel_write=epoch_read=identity_read=owner_read=active_read=0U;
}
static void request(uint32_t operation,uint32_t nonce){
 XE_NP_UsbSetup r={0x40U,(uint8_t)operation,(uint16_t)nonce,(uint16_t)(nonce>>16U),0U};
 uint32_t reads=card.reads,writes=card.writes;ipsr=16U;
 assert(xe_np_usb_catalog_request(&fixture_pcd,&r)==1);ipsr=0U;
 assert(card.reads==reads && card.writes==writes); /* SETUP never touches storage. */
}
static void report(void){
 XE_NP_UsbSetup r={0xC0U,XE_NP_USB_CATALOG_REPORT,0U,0U,64U};
 assert(xe_np_usb_catalog_request(&fixture_pcd,&r)==1);
 assert(sent[0]==XE_NP_USB_CATALOG_MAGIC && sent[1]==1U);
}
static void run(uint32_t operation,uint32_t nonce,uint32_t state){
 uint32_t saved=sd_regs.CLKCR;request(operation,nonce);assert(xe_np_usb_catalog_busy());
 xe_np_usb_catalog_service();report();
 assert((uint32_t)(xe_np_usb_catalog_busy()!=0)==xe_np_usb_catalog.sector_owned);
 assert(sent[3]==state && sent[4]==nonce && primask==0U);
 assert(sd_regs.CLKCR==(xe_np_usb_catalog.clock_held?xe_np_usb_catalog.metadata_clock:saved));
}
static XE_NP_Np2DualSdMeta fresh_record(uint32_t blocks){
 XE_NP_Np2DualSdMeta m=interrupted(blocks);reset_usb();return m;
}
static void positive(void){
 XE_NP_Np2DualSdMeta m=fresh_record(400U);uint8_t d[512],f[512];
 assert(!read_sector(NULL,m.reservation_start_lba+3U,d));assert(!read_sector(NULL,m.reservation_start_lba+4U,f));
 uint32_t writes=card.writes;run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_COMPLETE);
 assert(card.writes==writes && sent[14]==1U && sent[15]==7U && sent[6]==card.capacity);
 assert(sent[9]==XE_NP_Np2DualSd_Crc32((const uint8_t *)hsd1.CID,16U));
 assert(!memcmp(sent+10U,hsd1.CID,16U));
 report();uint32_t cached[16];memcpy(cached,sent,64U);
 xe_np_usb_catalog_report[8]^=1U;assert(!memcmp(cached,xe_np_usb_catalog_ep0,64U));xe_np_usb_catalog_report[8]^=1U;
 rdy_wait=2U;program_wait=2U;
 run(XE_NP_USB_CATALOG_REPAIR,2U,XE_NP_USB_CATALOG_COMPLETE);
 assert(sent[8]==m.reservation_end_lba && !sent[5] && hal_writes==4U && polls>hal_reads+hal_writes);
 assert_original_allocation(&m,d,f); /* Descriptor/footer and both payload canaries unchanged. */
 uint32_t after=card.writes;request(XE_NP_USB_CATALOG_REPAIR,2U);
 assert(stalls && !xe_np_usb_catalog_busy() && card.writes==after);
 request(XE_NP_USB_CATALOG_REPAIR,3U);assert(!xe_np_usb_catalog_busy()); /* Consumed INSPECT. */
}
static void refusals(void){
 (void)fresh_record(400U);
 volatile uint32_t *guards[]={&download,&xe_np_usb_state.configured,&np_download_state,&np_download_burst_armed,
  &np_download_burst_remaining,&np_download_prefetch.valid,&selftest,&aux,&np2busy,&sourcebusy,&sourceready,&armed,
  &np2_config_receiving,&np2_config_pending,&xe_np_usb_mode.target,&xe_np_usb_state.bootloader_reset_pending,
  &xe_np_usb_state.bootloader_reset_armed,&xe_np_usb_state.streaming,&xe_np_usb_state.real_start_pending,
  &xe_np_usb_state.tx_busy,&xe_np_usb_state.tx_pending,&xe_np_usb_sd_info_pending,
  &hsd1.ErrorCode,&hsd1.Context,&sd_regs.IDMACTRL,&sd_regs.DCTRL,&sd_regs.STA,
  &pssi.CR,&spi1.CR1,&spi2.CR1,&rcc.CFGR1,&dma[15].CCR};
 for(unsigned i=0U;i<sizeof(guards)/sizeof(guards[0]);i++){
  reset_usb();uint32_t old=*guards[i];
  *guards[i]=i<2U?0U:1U;
  if(guards[i]==&sd_regs.DCTRL)*guards[i]=SDMMC_DCTRL_DTEN;
  if(guards[i]==&sd_regs.STA)*guards[i]=SDMMC_STA_DPSMACT;
  request(XE_NP_USB_CATALOG_INSPECT,1U);assert(stalls==1U && !xe_np_usb_catalog_busy());*guards[i]=old;
 }
 const uint32_t status[]={SDMMC_STA_DPSMACT,SDMMC_STA_CPSMACT,SDMMC_STA_BUSYD0,SDMMC_STA_DTIMEOUT};
 for(unsigned i=0U;i<4U;i++){reset_usb();sd_regs.STA=status[i];request(XE_NP_USB_CATALOG_INSPECT,1U);assert(stalls);}
 for(unsigned i=0U;i<16U;i++)for(uint32_t bit=1U;bit<=4U;bit<<=1U){
  reset_usb();dma[i].CCR=bit;request(XE_NP_USB_CATALOG_INSPECT,1U);assert(stalls);
 }
 reset_usb();hsd1.State=2U;request(XE_NP_USB_CATALOG_INSPECT,1U);assert(stalls);
 reset_usb();hsd1.Instance=NULL;request(XE_NP_USB_CATALOG_INSPECT,1U);assert(stalls);
 reset_usb();XE_NP_UsbSetup bad={0xC0U,XE_NP_USB_CATALOG_INSPECT,1U,0U,0U};
 assert(xe_np_usb_catalog_request(&fixture_pcd,&bad)==1 && stalls && !hal_reads && !hal_writes);
 reset_usb();bad.bmRequest=0x40U;bad.wLength=1U;
 assert(xe_np_usb_catalog_request(&fixture_pcd,&bad)==1 && stalls && !hal_reads && !hal_writes);
 reset_usb();bad.bRequest=0xA3U;assert(!xe_np_usb_catalog_request(&fixture_pcd,&bad));
 reset_usb();request(XE_NP_USB_CATALOG_REPAIR,1U);assert(stalls && !hal_writes);
 reset_usb();request(XE_NP_USB_CATALOG_INSPECT,2U);assert(stalls && !xe_np_usb_catalog_busy());
 reset_usb();request(XE_NP_USB_CATALOG_INSPECT,1U);request(XE_NP_USB_CATALOG_INSPECT,2U);assert(stalls && xe_np_usb_catalog.queued);
 xe_np_usb_catalog_cancel();assert(!xe_np_usb_catalog_busy() && !xe_np_usb_catalog.inspected);
 xe_np_usb_catalog_service();assert(!hal_reads && !hal_writes);
 reset_usb();xe_np_usb_catalog.last_nonce=UINT32_MAX;request(XE_NP_USB_CATALOG_INSPECT,0U);assert(stalls);
}
static void invalidation(void){
 for(unsigned which=0U;which<4U;which++){
  (void)fresh_record(400U);run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_COMPLETE);
  switch(which){case 0:np_download_epoch++;break;case 1:hsd1.CID[0]++;break;
   case 2:hsd1.SdCard.LogBlockNbr--;break;default:xe_np_usb_catalog_cancel();break;}
  request(XE_NP_USB_CATALOG_REPAIR,2U);assert(stalls && !hal_writes);
  if(which==3U){report();assert(sent[3]==XE_NP_USB_CATALOG_FAILED && sent[5]==XE_NP_USB_CATALOG_CANCELLED && !sent[14]);}
 }
 for(unsigned which=0U;which<4U;which++){
  (void)fresh_record(400U);
  switch(which){case 0:cancel_read=1U;break;case 1:epoch_read=1U;break;
   case 2:identity_read=1U;break;default:owner_read=1U;break;}
  run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_FAILED);
  assert(hal_reads==1U && !hal_writes && hsd1.Context==SD_CONTEXT_READ_SINGLE_BLOCK);
  assert(!xe_np_usb_catalog.inspected && xe_np_usb_catalog_busy());
 }
 (void)fresh_record(400U);poll_timeout=1U;
 run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_FAILED);
 assert(polls>=1000U && hsd1.Context==SD_CONTEXT_READ_SINGLE_BLOCK && !hal_writes);
 assert(xe_np_usb_catalog_rescue_ready());uint32_t context=hsd1.Context;
 sd_regs.STA=SDMMC_STA_DPSMACT;assert(!xe_np_usb_catalog_rescue_ready());sd_regs.STA=SDMMC_STA_CPSMACT;
 assert(!xe_np_usb_catalog_rescue_ready());sd_regs.STA=SDMMC_STA_BUSYD0;assert(!xe_np_usb_catalog_rescue_ready());
 sd_regs.STA=0U;sd_regs.IDMACTRL=1U;assert(!xe_np_usb_catalog_rescue_ready());sd_regs.IDMACTRL=0U;
 sd_regs.DCTRL=SDMMC_DCTRL_DTEN;assert(!xe_np_usb_catalog_rescue_ready());sd_regs.DCTRL=0U;
 armed=1U;assert(!xe_np_usb_catalog_rescue_ready());armed=0U;
 xe_np_usb_catalog_cancel();assert(xe_np_usb_catalog_busy() && xe_np_usb_catalog_rescue_ready() && hsd1.Context==context);
 (void)fresh_record(400U);active_read=1U;
 run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_FAILED);
 assert(xe_np_usb_catalog.clock_held && xe_np_usb_catalog_busy() && !xe_np_usb_catalog_rescue_ready());
 assert(sd_regs.CLKCR==xe_np_usb_catalog.metadata_clock && hsd1.Context==SD_CONTEXT_READ_SINGLE_BLOCK);
 sd_regs.DCTRL=sd_regs.STA=sd_regs.IDMACTRL=0U; /* Model later hardware quiet, not helper retirement. */
 assert(xe_np_usb_catalog_rescue_ready() && hsd1.Context==SD_CONTEXT_READ_SINGLE_BLOCK);
 assert(sd_regs.CLKCR==xe_np_usb_catalog.metadata_clock); /* The query does not retime it. */
}
static void append_metadata(void){
 setup();uint32_t next=0U;uint8_t system[512]={0},config[2048]={0},d[512],f[512],b[512];
 XE_NP_Np2DualSdMeta m={0};
 assert(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
 assert(!XE_NP_Np2DualSdCatalog_Mount(&next));
 assert(!XE_NP_Np2DualSdCatalog_PlanProfile(3U,20000U,8U,992U,crc32(config,2048U),&m));
 assert(!XE_NP_Np2DualSdCatalog_ReserveAppend(&m,config));reboot();reset_usb();
 assert(!read_sector(NULL,m.reservation_start_lba+3U,d) && get32(d+8U)==14U);
 assert(!read_sector(NULL,m.reservation_start_lba+4U,f));
 run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_COMPLETE);
 run(XE_NP_USB_CATALOG_REPAIR,2U,XE_NP_USB_CATALOG_COMPLETE);
 assert(sent[8]==m.reservation_end_lba);
 assert(!read_sector(NULL,m.reservation_start_lba+3U,b) && !memcmp(b,d,512U));
 assert(!read_sector(NULL,m.reservation_start_lba+4U,b) && !memcmp(b,f,512U));
}
static void damaged(void){
 XE_NP_Np2DualSdMeta m=fresh_record(400U);uint8_t b[512];
 assert(!read_sector(NULL,m.reservation_start_lba+4U,b));b[508]^=1U;
 assert(!write_sector(NULL,m.reservation_start_lba+4U,b));
 assert(!read_sector(NULL,m.reservation_start_lba+3U,b));b[508]^=1U;
 assert(!write_sector(NULL,m.reservation_start_lba+3U,b));
 uint32_t writes=card.writes;run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_FAILED);assert(card.writes==writes);
 request(XE_NP_USB_CATALOG_REPAIR,2U);assert(stalls && !hal_writes);
 m=fresh_record(1244U);assert(m.reservation_end_lba==card.capacity);
 run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_FAILED);
 assert(sent[7]&XE_NP_NP2_CATALOG_FULL);writes=card.writes;
 request(XE_NP_USB_CATALOG_REPAIR,2U);assert(stalls && card.writes==writes);
 for(uint32_t cut=1U;cut<=4U;cut++){
  (void)fresh_record(400U);run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_COMPLETE);
  card.failed_write=card.writes+cut;card.torn_write=cut&1U;
  run(XE_NP_USB_CATALOG_REPAIR,2U,XE_NP_USB_CATALOG_FAILED);
  uint32_t after=card.writes;xe_np_usb_catalog_service();assert(card.writes==after);
  /* Explicit new INSPECT after a modeled target restart; never replay the write. */
  card.failed_write=0U;card.torn_write=0U;reset_usb();
  run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_COMPLETE);
  run(XE_NP_USB_CATALOG_REPAIR,2U,XE_NP_USB_CATALOG_COMPLETE);
 }
 (void)fresh_record(400U);run(XE_NP_USB_CATALOG_INSPECT,1U,XE_NP_USB_CATALOG_COMPLETE);
 cancel_write=1U;run(XE_NP_USB_CATALOG_REPAIR,2U,XE_NP_USB_CATALOG_FAILED);
 assert(hal_writes==1U && !xe_np_usb_catalog.inspected);
}
int prior_adapter_cases(void){positive();refusals();invalidation();damaged();append_metadata();
 puts("PASS actual USB foreground catalog adapter/real metadata: no SETUP I/O, explicit recovery, owner/epoch/nonce/bounds/fault guards; modeled HAL only");return 0;}
static unsigned maintenance_checks;
#define CHECK(x) do{maintenance_checks++;if(!(x)){fprintf(stderr,"FAIL %d: %s\n",__LINE__,#x);abort();}}while(0)
static void assert_delete_write(uint32_t lba){
 if(xe_np_usb_catalog.operation==0xA7U)CHECK(xe_np_usb_delete_writes_allowed&&(lba==112U||lba==113U||lba==xe_np_usb_delete_directory_lba));
}
static void report_probe(void){
 if(!probe_enable||probing||primask)return;probing=1;
 uint32_t saved[96],oldlen=sent_len,oldsends=sends;memcpy(saved,sent,sizeof saved);
 XE_NP_UsbSetup q={0xC0,0xA7,0,0,128};CHECK(usb_delete_request_setup(&fixture_pcd,&q)==1);
 CHECK(sent_len==128&&sent[0]==USB_MAINT_DELETE_MAGIC&&sent[31]==usb_maintenance_crc(sent));snapshot_checks++;
 memcpy(sent,saved,sizeof saved);sent_len=oldlen;sends=oldsends;probing=0;
}
static void reset_maintenance(void){
 reset_usb();memset(usb_delete_report,0,sizeof usb_delete_report);memset(usb_delete_confirmed,0,sizeof usb_delete_confirmed);
 memset(&np_download_prefetch,0,sizeof np_download_prefetch);
 memset(usb_delete_request,0,sizeof usb_delete_request);memset(&xe_np_usb_sd_info,0,sizeof xe_np_usb_sd_info);
 usb_delete_receiving=usb_delete_rx_bytes=usb_delete_queued=usb_delete_last_nonce=0;
 xe_np_usb_maintenance_active=xe_np_usb_delete_writes_allowed=xe_np_usb_delete_directory_lba=0;
 xe_np_selftest_dirty=sd_test_busy=sd_test_active=raw_sink=runtime.flags=null_runtime=0;
 board_queries=reinits=irq_disabled=query_wrong_cid=query_wrong_capacity=restore_wrong_cid=restore_wrong_capacity=restore_fail=restore_busy=0;
 rx_count=receive_fail=0;xe_np_usb_card_ready=1;probe_enable=probing=0;
}
static void fresh_complete(void){
 setup();uint32_t n;uint8_t system[512]={0},config[2048]={0};XE_NP_Np2DualSdMeta m;
 CHECK(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));CHECK(!XE_NP_Np2DualSdCatalog_Mount(&n));
 CHECK(!XE_NP_Np2DualSdCatalog_Plan(20000,8,321,crc32(config,2048),&m));CHECK(!XE_NP_Np2DualSdCatalog_Reserve(&m,config));
 CHECK(!XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0,8));reboot();reset_maintenance();
}
static void inspect(void){
 XE_NP_UsbSetup q={0x40,0xA7,1,0,0};uint32_t reads=card.reads,writes=card.writes,clock=sd_regs.CLKCR;ipsr=16;
 CHECK(usb_delete_request_setup(&fixture_pcd,&q)==1&&usb_delete_queued==1&&card.reads==reads&&card.writes==writes&&sd_regs.CLKCR==clock);ipsr=0;
 probe_enable=1;usb_delete_service();probe_enable=0;CHECK(usb_delete_report[3]==3&&usb_delete_report[5]==0);
 CHECK(card.writes==writes&&hal_writes==0&&sd_regs.CLKCR==clock&&!xe_np_usb_maintenance_active&&!xe_np_usb_delete_writes_allowed);
 CHECK(usb_delete_report[31]==usb_maintenance_crc(usb_delete_report)&&usb_delete_report[20]==uid0);
}
static void confirmation(uint32_t q[32]){memcpy(q,usb_delete_confirmed,128);q[2]=2;q[4]=usb_delete_last_nonce+1;q[24]=usb_delete_last_nonce;q[31]=usb_maintenance_crc(q);}
static void submit(const uint32_t q[32]){
 XE_NP_UsbSetup r={0x40,0xA7,0,0,128};uint32_t reads=card.reads,writes=card.writes;ipsr=16;
 CHECK(usb_delete_request_setup(&fixture_pcd,&r)==1);if(usb_delete_receiving){memcpy(rx_target,q,64);rx_count=64;CHECK(usb_delete_out(&fixture_pcd)==1);if(usb_delete_receiving){memcpy(rx_target,(const uint8_t*)q+64,64);CHECK(usb_delete_out(&fixture_pcd)==1);}}
 ipsr=0;CHECK(card.reads==reads&&card.writes==writes);
}
static void sd_info_cases(void){
 fresh_complete();XE_NP_UsbSetup get={0xC0,0xA5,0,0,384},refresh={0x40,0xA6,1,0,0};
 CHECK(usb_sd_info_request(&fixture_pcd,&get)==1&&sent_len==384&&sent[0]==XE_NP_SD_INFO_MAGIC&&sent[3]==XE_NP_SD_INFO_EMPTY);
 CHECK(usb_sd_info_request(&fixture_pcd,&refresh)==1&&xe_np_usb_sd_info_pending&&board_queries==0);
 CHECK(usb_sd_info_request(&fixture_pcd,&refresh)==1&&board_queries==0);CHECK(usb_sd_info_service()==1);
 CHECK(board_queries==1&&reinits==1&&irq_disabled==1&&xe_np_usb_card_ready&&xe_np_usb_sd_info.state==XE_NP_SD_INFO_READY&&!xe_np_usb_sd_info_pending);
 CHECK(usb_sd_info_request(&fixture_pcd,&refresh)==1&&usb_sd_info_service()==0&&board_queries==1);
 /* The inherited NP2 USB runtime getter is intentionally NULL. Physical
  * source/peripheral/SD ownership remains authoritative for this role. */
 reset_maintenance();null_runtime=1;
 CHECK(usb_sd_info_request(&fixture_pcd,&refresh)==1&&xe_np_usb_sd_info_pending&&usb_sd_info_service()==1);
 CHECK(xe_np_usb_sd_info.state==XE_NP_SD_INFO_READY&&xe_np_usb_card_ready&&board_queries==1&&reinits==1);
 volatile uint32_t *owners[]={&aux,&np2busy,&sourcebusy,&sourceready,&armed,&raw_sink,&sd_test_busy,&sd_test_active,&xe_np_selftest_dirty,&selftest,
  &xe_np_usb_state.streaming,&xe_np_usb_state.real_start_pending,&xe_np_usb_state.bootloader_reset_pending,&xe_np_usb_state.bootloader_reset_armed,
  &xe_np_usb_mode.target,&np2_config_receiving,&np2_config_pending,&np_download_state,&np_download_burst_armed,&hsd1.Context,&sd_regs.IDMACTRL};
 for(unsigned n=0;n<sizeof owners/sizeof owners[0];n++){
  reset_maintenance();null_runtime=1;*owners[n]=1;uint32_t before=stalls;
  CHECK(usb_sd_info_request(&fixture_pcd,&refresh)==1&&stalls==before+1&&!xe_np_usb_sd_info_pending&&board_queries==0);
 }
 for(unsigned n=0;n<23;n++){
  reset_maintenance();null_runtime=1;
  if(n<16)dma[n].CCR=DMA_CCR_EN;
  else if(n==16)pssi.CR=PSSI_CR_ENABLE;else if(n==17)spi1.CR1=SPI_CR1_SPE;else if(n==18)spi2.CR1=SPI_CR1_SPE;
  else if(n==19)rcc.CFGR1=RCC_CFGR1_MCOSEL;else if(n==20)sd_regs.DCTRL=SDMMC_DCTRL_DTEN;
  else if(n==21)sd_regs.STA=SDMMC_STA_DPSMACT;else sd_regs.STA=SDMMC_STA_CPSMACT;
  uint32_t before=stalls;CHECK(usb_sd_info_request(&fixture_pcd,&refresh)==1&&stalls==before+1&&!xe_np_usb_sd_info_pending&&board_queries==0);
 }
 for(unsigned fault=0;fault<5;fault++){
  reset_maintenance();query_wrong_cid=fault==0;query_wrong_capacity=fault==1;restore_wrong_cid=fault==2;restore_fail=fault==3;restore_busy=fault==4;
  CHECK(usb_sd_info_request(&fixture_pcd,&refresh)==1&&usb_sd_info_service()==1);
  CHECK(xe_np_usb_sd_info.state==XE_NP_SD_INFO_FAILED);CHECK(usb_sd_info_service()==0&&reinits==1);
 }
 for(unsigned busy=0;busy<8;busy++){
  reset_maintenance();if(busy==0)aux=1;if(busy==1)np2busy=1;if(busy==2)runtime.flags=1;if(busy==3)dma[3].CCR=DMA_CCR_EN;
  if(busy==4)hsd1.Context=SD_CONTEXT_READ_SINGLE_BLOCK;if(busy==5)np_download_burst_armed=1;if(busy==6)raw_sink=1;if(busy==7)sd_regs.IDMACTRL=1;
  uint32_t before=stalls;CHECK(usb_sd_info_request(&fixture_pcd,&refresh)==1&&stalls==before+1&&!xe_np_usb_sd_info_pending&&board_queries==0);
 }
 reset_maintenance();get.wLength=383;CHECK(usb_sd_info_request(&fixture_pcd,&get)==1&&stalls==1);get.wLength=384;get.bRequest=0x4B;CHECK(usb_sd_info_request(&fixture_pcd,&get)==1&&sent_len==384);
}
static void delete_cases(void){
 fresh_complete();XE_NP_UsbSetup get={0xC0,0xA7,0,0,128};CHECK(usb_delete_request_setup(&fixture_pcd,&get)==1&&sent[20]==uid0&&sent[31]==usb_maintenance_crc(sent));
 inspect();CHECK(usb_delete_report[7]&2U);uint32_t q[32];confirmation(q);uint32_t clock=sd_regs.CLKCR,writes=card.writes;
 submit(q);CHECK(usb_delete_queued==2&&xe_np_usb_maintenance_active);probe_enable=1;usb_delete_service();probe_enable=0;
 CHECK(usb_delete_report[3]==3&&usb_delete_report[5]==0&&usb_delete_report[9]==0&&card.writes>writes);
 CHECK(!xe_np_usb_delete_writes_allowed&&!xe_np_usb_maintenance_active&&!xe_np_usb_catalog.running&&sd_regs.CLKCR==clock);
 writes=card.writes;usb_delete_service();submit(q);CHECK(card.writes==writes&&!usb_delete_queued);CHECK(snapshot_checks>0);
 /* Every bound report word is compared, even when the supplied CRC is valid. */
 for(unsigned field=6;field<=24;field++){
  fresh_complete();inspect();confirmation(q);q[field]^=1;q[31]=usb_maintenance_crc(q);uint32_t before=stalls;submit(q);CHECK(stalls==before+1&&!usb_delete_queued&&hal_writes==0);
 }
 for(unsigned stale=0;stale<3;stale++){
  fresh_complete();inspect();confirmation(q);if(stale==0)np_download_epoch++;if(stale==1)hsd1.CID[0]^=1;if(stale==2)hsd1.SdCard.LogBlockNbr--;
  uint32_t before=stalls;submit(q);CHECK(stalls==before+1&&!usb_delete_queued&&hal_writes==0);
 }
 /* A failed journal write is a terminal failed operation, never replayed. */
 fresh_complete();inspect();confirmation(q);submit(q);card.failed_write=card.writes+1;usb_delete_service();CHECK(usb_delete_report[3]==4&&!usb_delete_queued&&!xe_np_usb_delete_writes_allowed);
 writes=card.writes;usb_delete_service();submit(q);CHECK(card.writes==writes&&!usb_delete_queued);
 /* Incomplete tails remain read-only and never acquire a delete lease. */
 (void)fresh_record(8);reset_maintenance();inspect();CHECK(!(usb_delete_report[7]&2U));confirmation(q);uint32_t before=stalls;submit(q);CHECK(stalls==before+1&&!usb_delete_queued&&hal_writes==0);
 /* Canceling queued/partially received work cannot leave a live token. */
 fresh_complete();inspect();confirmation(q);submit(q);usb_maintenance_cancel();writes=card.writes;usb_delete_service();CHECK(!usb_delete_queued&&card.writes==writes&&usb_delete_report[3]==4);
 fresh_complete();inspect();XE_NP_UsbSetup receive={0x40,0xA7,0,0,128};CHECK(usb_delete_request_setup(&fixture_pcd,&receive)==1);rx_count=63;before=stalls;CHECK(usb_delete_out(&fixture_pcd)==1&&stalls==before+1&&!usb_delete_receiving&&!xe_np_usb_maintenance_active);
}
static void seed_idle_cache(void){np_download_prefetch.valid=1;np_download_prefetch.lba=1020;np_download_prefetch.blocks=1020;np_download_prefetch.slot=1;np_download_prefetch.error=0;}
static void idle_cache_cases(void){
 fresh_complete();seed_idle_cache();
 uint32_t epoch=np_download_epoch;inspect();
 CHECK(!np_download_prefetch.valid&&np_download_prefetch.lba==1020&&np_download_prefetch.blocks==1020&&np_download_prefetch.slot==1&&!np_download_prefetch.error&&np_download_epoch==epoch);
 CHECK(usb_delete_report[7]&2U);
 /* An idle cached block is not an active read/USB/SD/capture owner. Every
  * real owner must still reject and leave that cached block untouched. */
 for(unsigned op=0;op<2;op++)for(unsigned busy=0;busy<18;busy++){
  fresh_complete();seed_idle_cache();
  if(busy==0)np_download_state=1;if(busy==1)np_download_burst_armed=1;if(busy==2)np_download_burst_remaining=1;
  if(busy==3)xe_np_usb_state.tx_busy=1;if(busy==4)xe_np_usb_state.tx_pending=1;if(busy==5)hsd1.Context=SD_CONTEXT_READ_SINGLE_BLOCK;
  if(busy==6)sd_regs.IDMACTRL=1;if(busy==7)sd_regs.DCTRL=SDMMC_DCTRL_DTEN;if(busy==8)sd_regs.STA=SDMMC_STA_DPSMACT;
  if(busy==9)sd_regs.STA=SDMMC_STA_CPSMACT;if(busy==10)sd_regs.STA=SDMMC_STA_BUSYD0;if(busy==11)aux=1;
  if(busy==12)np2busy=1;if(busy==13)sourcebusy=1;if(busy==14)sourceready=1;if(busy==15)armed=1;
  if(busy==16)dma[15].CCR=DMA_CCR_EN;if(busy==17)xe_np_usb_catalog.queued=1;
  XE_NP_UsbSetup q={0x40,op?XE_NP_USB_CATALOG_INSPECT:0xA7,1,0,0};uint32_t before=stalls,reads=card.reads,writes=card.writes;epoch=np_download_epoch;
  CHECK((op?xe_np_usb_catalog_request(&fixture_pcd,&q):usb_delete_request_setup(&fixture_pcd,&q))==1&&stalls==before+1&&!usb_delete_queued&&np_download_prefetch.valid==1);
  CHECK(card.reads==reads&&card.writes==writes&&np_download_epoch==epoch);
 }
 /* Read-only A1 is also allowed after a completed list/quality read. Only
  * foreground service retires the cache; SETUP performs no I/O or reset. */
 fresh_complete();seed_idle_cache();uint32_t writes=card.writes;epoch=np_download_epoch;
 request(XE_NP_USB_CATALOG_INSPECT,1);CHECK(!stalls&&xe_np_usb_catalog.queued&&np_download_prefetch.valid==1);
 xe_np_usb_catalog_service();CHECK(!np_download_prefetch.valid&&card.writes==writes&&np_download_epoch==epoch&&xe_np_usb_catalog_report[3]==XE_NP_USB_CATALOG_COMPLETE);
 seed_idle_cache();uint32_t before=stalls,reads=card.reads;request(XE_NP_USB_CATALOG_REPAIR,2);
 CHECK(stalls==before+1&&np_download_prefetch.valid==1&&!xe_np_usb_catalog.queued&&card.reads==reads&&card.writes==writes);
 /* A read may finish after IRQ admission, then publish its cache before the
  * next foreground turn. Both read-only operations recheck/retire it there. */
 for(unsigned op=0;op<2;op++){
  fresh_complete();XE_NP_UsbSetup q={0x40,op?XE_NP_USB_CATALOG_INSPECT:0xA7,1,0,0};
  CHECK((op?xe_np_usb_catalog_request(&fixture_pcd,&q):usb_delete_request_setup(&fixture_pcd,&q))==1&&!stalls);
  seed_idle_cache();writes=card.writes;epoch=np_download_epoch;if(op)xe_np_usb_catalog_service();else usb_delete_service();
  CHECK(!np_download_prefetch.valid&&card.writes==writes&&np_download_epoch==epoch);
  fresh_complete();CHECK((op?xe_np_usb_catalog_request(&fixture_pcd,&q):usb_delete_request_setup(&fixture_pcd,&q))==1&&!stalls);
  seed_idle_cache();sd_regs.IDMACTRL=1;reads=card.reads;writes=card.writes;
  if(op)xe_np_usb_catalog_service();else usb_delete_service();CHECK(np_download_prefetch.valid==1&&card.reads==reads&&card.writes==writes);
 }
 for(unsigned op=0;op<2;op++)for(unsigned bad=0;bad<7;bad++){
  fresh_complete();seed_idle_cache();if(bad==0)np_download_prefetch.valid=2;if(bad==1)np_download_prefetch.error=1;if(bad==2)np_download_prefetch.blocks=0;
  if(bad==3)np_download_prefetch.blocks=1021;if(bad==4)np_download_prefetch.slot=2;if(bad==5)np_download_prefetch.lba=card.capacity;if(bad==6)np_download_prefetch.lba=card.capacity-10;
  XE_NP_UsbSetup q={0x40,op?XE_NP_USB_CATALOG_INSPECT:0xA7,1,0,0};before=stalls;reads=card.reads;writes=card.writes;
  CHECK((op?xe_np_usb_catalog_request(&fixture_pcd,&q):usb_delete_request_setup(&fixture_pcd,&q))==1&&stalls==before+1&&np_download_prefetch.valid!=0&&card.reads==reads&&card.writes==writes);
 }
}
int main(void){prior_adapter_cases();sd_info_cases();delete_cases();idle_cache_cases();printf("PASS %u actual maintenance lifecycle/identity/metadata-only delete checks; %u immutable CRC snapshots; modeled HAL/USB, no hardware\n",maintenance_checks,snapshot_checks);return 0;}
