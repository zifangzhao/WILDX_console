static unsigned maintenance_checks;
#define CHECK(x) do{maintenance_checks++;if(!(x)){fprintf(stderr,"FAIL %d: %s\n",__LINE__,#x);abort();}}while(0)
static void assert_delete_write(uint32_t lba){
 if(xe_np_usb_catalog.operation==0xA7U)CHECK(xe_np_usb_delete_writes_allowed&&(lba==112U||lba==113U||lba==xe_np_usb_delete_directory_lba));
}
static void report_probe(void){
 if(!probe_enable||probing||primask)return;probing=1;
 uint32_t saved[96],oldlen=sent_len,oldsends=sends;memcpy(saved,sent,sizeof saved);
 XE_NP_UsbSetup q={0xC0,0xA7,0,0,128};CHECK(usb_delete_request_setup(&fixture_pcd,&q)==1);
 CHECK(sent_len==128&&sent[0]==USB_MAINT_DELETE_MAGIC&&sent[31]==usb_maintenance_crc(sent));snapshot_checks++;
 memcpy(sent,saved,sizeof saved);sent_len=oldlen;sends=oldsends;probing=0;
}
static void reset_maintenance(void){
 reset_usb();memset(usb_delete_report,0,sizeof usb_delete_report);memset(usb_delete_confirmed,0,sizeof usb_delete_confirmed);
 memset(&np_download_prefetch,0,sizeof np_download_prefetch);
 memset(usb_delete_request,0,sizeof usb_delete_request);memset(&xe_np_usb_sd_info,0,sizeof xe_np_usb_sd_info);
 usb_delete_receiving=usb_delete_rx_bytes=usb_delete_queued=usb_delete_last_nonce=0;
 xe_np_usb_maintenance_active=xe_np_usb_delete_writes_allowed=xe_np_usb_delete_directory_lba=0;
 xe_np_selftest_dirty=sd_test_busy=sd_test_active=raw_sink=runtime.flags=null_runtime=0;
 board_queries=reinits=irq_disabled=query_wrong_cid=query_wrong_capacity=restore_wrong_cid=restore_wrong_capacity=restore_fail=restore_busy=0;
 rx_count=receive_fail=0;xe_np_usb_card_ready=1;probe_enable=probing=0;
}
static void fresh_complete(void){
 setup();uint32_t n;uint8_t system[512]={0},config[2048]={0};XE_NP_Np2DualSdMeta m;
 CHECK(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));CHECK(!XE_NP_Np2DualSdCatalog_Mount(&n));
 CHECK(!XE_NP_Np2DualSdCatalog_Plan(20000,8,321,crc32(config,2048),&m));CHECK(!XE_NP_Np2DualSdCatalog_Reserve(&m,config));
 CHECK(!XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0,8));reboot();reset_maintenance();
}
static void inspect(void){
 XE_NP_UsbSetup q={0x40,0xA7,1,0,0};uint32_t reads=card.reads,writes=card.writes,clock=sd_regs.CLKCR;ipsr=16;
 CHECK(usb_delete_request_setup(&fixture_pcd,&q)==1&&usb_delete_queued==1&&card.reads==reads&&card.writes==writes&&sd_regs.CLKCR==clock);ipsr=0;
 probe_enable=1;usb_delete_service();probe_enable=0;CHECK(usb_delete_report[3]==3&&usb_delete_report[5]==0);
 CHECK(card.writes==writes&&hal_writes==0&&sd_regs.CLKCR==clock&&!xe_np_usb_maintenance_active&&!xe_np_usb_delete_writes_allowed);
 CHECK(usb_delete_report[31]==usb_maintenance_crc(usb_delete_report)&&usb_delete_report[20]==uid0);
}
static void confirmation(uint32_t q[32]){memcpy(q,usb_delete_confirmed,128);q[2]=2;q[4]=usb_delete_last_nonce+1;q[24]=usb_delete_last_nonce;q[31]=usb_maintenance_crc(q);}
static void submit(const uint32_t q[32]){
 XE_NP_UsbSetup r={0x40,0xA7,0,0,128};uint32_t reads=card.reads,writes=card.writes;ipsr=16;
 CHECK(usb_delete_request_setup(&fixture_pcd,&r)==1);if(usb_delete_receiving){memcpy(rx_target,q,64);rx_count=64;CHECK(usb_delete_out(&fixture_pcd)==1);if(usb_delete_receiving){memcpy(rx_target,(const uint8_t*)q+64,64);CHECK(usb_delete_out(&fixture_pcd)==1);}}
 ipsr=0;CHECK(card.reads==reads&&card.writes==writes);
}
static void sd_info_cases(void){
 fresh_complete();XE_NP_UsbSetup get={0xC0,0xA5,0,0,384},refresh={0x40,0xA6,1,0,0};
 CHECK(usb_sd_info_request(&fixture_pcd,&get)==1&&sent_len==384&&sent[0]==XE_NP_SD_INFO_MAGIC&&sent[3]==XE_NP_SD_INFO_EMPTY);
 CHECK(usb_sd_info_request(&fixture_pcd,&refresh)==1&&xe_np_usb_sd_info_pending&&board_queries==0);
 CHECK(usb_sd_info_request(&fixture_pcd,&refresh)==1&&board_queries==0);CHECK(usb_sd_info_service()==1);
 CHECK(board_queries==1&&reinits==1&&irq_disabled==1&&xe_np_usb_card_ready&&xe_np_usb_sd_info.state==XE_NP_SD_INFO_READY&&!xe_np_usb_sd_info_pending);
 CHECK(usb_sd_info_request(&fixture_pcd,&refresh)==1&&usb_sd_info_service()==0&&board_queries==1);
 /* The inherited NP2 USB runtime getter is intentionally NULL. Physical
  * source/peripheral/SD ownership remains authoritative for this role. */
 reset_maintenance();null_runtime=1;
 CHECK(usb_sd_info_request(&fixture_pcd,&refresh)==1&&xe_np_usb_sd_info_pending&&usb_sd_info_service()==1);
 CHECK(xe_np_usb_sd_info.state==XE_NP_SD_INFO_READY&&xe_np_usb_card_ready&&board_queries==1&&reinits==1);
 volatile uint32_t *owners[]={&aux,&np2busy,&sourcebusy,&sourceready,&armed,&raw_sink,&sd_test_busy,&sd_test_active,&xe_np_selftest_dirty,&selftest,
  &xe_np_usb_state.streaming,&xe_np_usb_state.real_start_pending,&xe_np_usb_state.bootloader_reset_pending,&xe_np_usb_state.bootloader_reset_armed,
  &xe_np_usb_mode.target,&np2_config_receiving,&np2_config_pending,&np_download_state,&np_download_burst_armed,&hsd1.Context,&sd_regs.IDMACTRL};
 for(unsigned n=0;n<sizeof owners/sizeof owners[0];n++){
  reset_maintenance();null_runtime=1;*owners[n]=1;uint32_t before=stalls;
  CHECK(usb_sd_info_request(&fixture_pcd,&refresh)==1&&stalls==before+1&&!xe_np_usb_sd_info_pending&&board_queries==0);
 }
 for(unsigned n=0;n<23;n++){
  reset_maintenance();null_runtime=1;
  if(n<16)dma[n].CCR=DMA_CCR_EN;
  else if(n==16)pssi.CR=PSSI_CR_ENABLE;else if(n==17)spi1.CR1=SPI_CR1_SPE;else if(n==18)spi2.CR1=SPI_CR1_SPE;
  else if(n==19)rcc.CFGR1=RCC_CFGR1_MCOSEL;else if(n==20)sd_regs.DCTRL=SDMMC_DCTRL_DTEN;
  else if(n==21)sd_regs.STA=SDMMC_STA_DPSMACT;else sd_regs.STA=SDMMC_STA_CPSMACT;
  uint32_t before=stalls;CHECK(usb_sd_info_request(&fixture_pcd,&refresh)==1&&stalls==before+1&&!xe_np_usb_sd_info_pending&&board_queries==0);
 }
 for(unsigned fault=0;fault<5;fault++){
  reset_maintenance();query_wrong_cid=fault==0;query_wrong_capacity=fault==1;restore_wrong_cid=fault==2;restore_fail=fault==3;restore_busy=fault==4;
  CHECK(usb_sd_info_request(&fixture_pcd,&refresh)==1&&usb_sd_info_service()==1);
  CHECK(xe_np_usb_sd_info.state==XE_NP_SD_INFO_FAILED);CHECK(usb_sd_info_service()==0&&reinits==1);
 }
 for(unsigned busy=0;busy<8;busy++){
  reset_maintenance();if(busy==0)aux=1;if(busy==1)np2busy=1;if(busy==2)runtime.flags=1;if(busy==3)dma[3].CCR=DMA_CCR_EN;
  if(busy==4)hsd1.Context=SD_CONTEXT_READ_SINGLE_BLOCK;if(busy==5)np_download_burst_armed=1;if(busy==6)raw_sink=1;if(busy==7)sd_regs.IDMACTRL=1;
  uint32_t before=stalls;CHECK(usb_sd_info_request(&fixture_pcd,&refresh)==1&&stalls==before+1&&!xe_np_usb_sd_info_pending&&board_queries==0);
 }
 reset_maintenance();get.wLength=383;CHECK(usb_sd_info_request(&fixture_pcd,&get)==1&&stalls==1);get.wLength=384;get.bRequest=0x4B;CHECK(usb_sd_info_request(&fixture_pcd,&get)==1&&sent_len==384);
}
static void delete_cases(void){
 fresh_complete();XE_NP_UsbSetup get={0xC0,0xA7,0,0,128};CHECK(usb_delete_request_setup(&fixture_pcd,&get)==1&&sent[20]==uid0&&sent[31]==usb_maintenance_crc(sent));
 inspect();CHECK(usb_delete_report[7]&2U);uint32_t q[32];confirmation(q);uint32_t clock=sd_regs.CLKCR,writes=card.writes;
 submit(q);CHECK(usb_delete_queued==2&&xe_np_usb_maintenance_active);probe_enable=1;usb_delete_service();probe_enable=0;
 CHECK(usb_delete_report[3]==3&&usb_delete_report[5]==0&&usb_delete_report[9]==0&&card.writes>writes);
 CHECK(!xe_np_usb_delete_writes_allowed&&!xe_np_usb_maintenance_active&&!xe_np_usb_catalog.running&&sd_regs.CLKCR==clock);
 writes=card.writes;usb_delete_service();submit(q);CHECK(card.writes==writes&&!usb_delete_queued);CHECK(snapshot_checks>0);
 /* Every bound report word is compared, even when the supplied CRC is valid. */
 for(unsigned field=6;field<=24;field++){
  fresh_complete();inspect();confirmation(q);q[field]^=1;q[31]=usb_maintenance_crc(q);uint32_t before=stalls;submit(q);CHECK(stalls==before+1&&!usb_delete_queued&&hal_writes==0);
 }
 for(unsigned stale=0;stale<3;stale++){
  fresh_complete();inspect();confirmation(q);if(stale==0)np_download_epoch++;if(stale==1)hsd1.CID[0]^=1;if(stale==2)hsd1.SdCard.LogBlockNbr--;
  uint32_t before=stalls;submit(q);CHECK(stalls==before+1&&!usb_delete_queued&&hal_writes==0);
 }
 /* A failed journal write is a terminal failed operation, never replayed. */
 fresh_complete();inspect();confirmation(q);submit(q);card.failed_write=card.writes+1;usb_delete_service();CHECK(usb_delete_report[3]==4&&!usb_delete_queued&&!xe_np_usb_delete_writes_allowed);
 writes=card.writes;usb_delete_service();submit(q);CHECK(card.writes==writes&&!usb_delete_queued);
 /* Incomplete tails remain read-only and never acquire a delete lease. */
 (void)fresh_record(8);reset_maintenance();inspect();CHECK(!(usb_delete_report[7]&2U));confirmation(q);uint32_t before=stalls;submit(q);CHECK(stalls==before+1&&!usb_delete_queued&&hal_writes==0);
 /* Canceling queued/partially received work cannot leave a live token. */
 fresh_complete();inspect();confirmation(q);submit(q);usb_maintenance_cancel();writes=card.writes;usb_delete_service();CHECK(!usb_delete_queued&&card.writes==writes&&usb_delete_report[3]==4);
 fresh_complete();inspect();XE_NP_UsbSetup receive={0x40,0xA7,0,0,128};CHECK(usb_delete_request_setup(&fixture_pcd,&receive)==1);rx_count=63;before=stalls;CHECK(usb_delete_out(&fixture_pcd)==1&&stalls==before+1&&!usb_delete_receiving&&!xe_np_usb_maintenance_active);
}
static void seed_idle_cache(void){np_download_prefetch.valid=1;np_download_prefetch.lba=1020;np_download_prefetch.blocks=1020;np_download_prefetch.slot=1;np_download_prefetch.error=0;}
static void idle_cache_cases(void){
 fresh_complete();seed_idle_cache();
 uint32_t epoch=np_download_epoch;inspect();
 CHECK(!np_download_prefetch.valid&&np_download_prefetch.lba==1020&&np_download_prefetch.blocks==1020&&np_download_prefetch.slot==1&&!np_download_prefetch.error&&np_download_epoch==epoch);
 CHECK(usb_delete_report[7]&2U);
 /* An idle cached block is not an active read/USB/SD/capture owner. Every
  * real owner must still reject and leave that cached block untouched. */
 for(unsigned op=0;op<2;op++)for(unsigned busy=0;busy<18;busy++){
  fresh_complete();seed_idle_cache();
  if(busy==0)np_download_state=1;if(busy==1)np_download_burst_armed=1;if(busy==2)np_download_burst_remaining=1;
  if(busy==3)xe_np_usb_state.tx_busy=1;if(busy==4)xe_np_usb_state.tx_pending=1;if(busy==5)hsd1.Context=SD_CONTEXT_READ_SINGLE_BLOCK;
  if(busy==6)sd_regs.IDMACTRL=1;if(busy==7)sd_regs.DCTRL=SDMMC_DCTRL_DTEN;if(busy==8)sd_regs.STA=SDMMC_STA_DPSMACT;
  if(busy==9)sd_regs.STA=SDMMC_STA_CPSMACT;if(busy==10)sd_regs.STA=SDMMC_STA_BUSYD0;if(busy==11)aux=1;
  if(busy==12)np2busy=1;if(busy==13)sourcebusy=1;if(busy==14)sourceready=1;if(busy==15)armed=1;
  if(busy==16)dma[15].CCR=DMA_CCR_EN;if(busy==17)xe_np_usb_catalog.queued=1;
  XE_NP_UsbSetup q={0x40,op?XE_NP_USB_CATALOG_INSPECT:0xA7,1,0,0};uint32_t before=stalls,reads=card.reads,writes=card.writes;epoch=np_download_epoch;
  CHECK((op?xe_np_usb_catalog_request(&fixture_pcd,&q):usb_delete_request_setup(&fixture_pcd,&q))==1&&stalls==before+1&&!usb_delete_queued&&np_download_prefetch.valid==1);
  CHECK(card.reads==reads&&card.writes==writes&&np_download_epoch==epoch);
 }
 /* Read-only A1 is also allowed after a completed list/quality read. Only
  * foreground service retires the cache; SETUP performs no I/O or reset. */
 fresh_complete();seed_idle_cache();uint32_t writes=card.writes;epoch=np_download_epoch;
 request(XE_NP_USB_CATALOG_INSPECT,1);CHECK(!stalls&&xe_np_usb_catalog.queued&&np_download_prefetch.valid==1);
 xe_np_usb_catalog_service();CHECK(!np_download_prefetch.valid&&card.writes==writes&&np_download_epoch==epoch&&xe_np_usb_catalog_report[3]==XE_NP_USB_CATALOG_COMPLETE);
 seed_idle_cache();uint32_t before=stalls,reads=card.reads;request(XE_NP_USB_CATALOG_REPAIR,2);
 CHECK(stalls==before+1&&np_download_prefetch.valid==1&&!xe_np_usb_catalog.queued&&card.reads==reads&&card.writes==writes);
 /* A read may finish after IRQ admission, then publish its cache before the
  * next foreground turn. Both read-only operations recheck/retire it there. */
 for(unsigned op=0;op<2;op++){
  fresh_complete();XE_NP_UsbSetup q={0x40,op?XE_NP_USB_CATALOG_INSPECT:0xA7,1,0,0};
  CHECK((op?xe_np_usb_catalog_request(&fixture_pcd,&q):usb_delete_request_setup(&fixture_pcd,&q))==1&&!stalls);
  seed_idle_cache();writes=card.writes;epoch=np_download_epoch;if(op)xe_np_usb_catalog_service();else usb_delete_service();
  CHECK(!np_download_prefetch.valid&&card.writes==writes&&np_download_epoch==epoch);
  fresh_complete();CHECK((op?xe_np_usb_catalog_request(&fixture_pcd,&q):usb_delete_request_setup(&fixture_pcd,&q))==1&&!stalls);
  seed_idle_cache();sd_regs.IDMACTRL=1;reads=card.reads;writes=card.writes;
  if(op)xe_np_usb_catalog_service();else usb_delete_service();CHECK(np_download_prefetch.valid==1&&card.reads==reads&&card.writes==writes);
 }
 for(unsigned op=0;op<2;op++)for(unsigned bad=0;bad<7;bad++){
  fresh_complete();seed_idle_cache();if(bad==0)np_download_prefetch.valid=2;if(bad==1)np_download_prefetch.error=1;if(bad==2)np_download_prefetch.blocks=0;
  if(bad==3)np_download_prefetch.blocks=1021;if(bad==4)np_download_prefetch.slot=2;if(bad==5)np_download_prefetch.lba=card.capacity;if(bad==6)np_download_prefetch.lba=card.capacity-10;
  XE_NP_UsbSetup q={0x40,op?XE_NP_USB_CATALOG_INSPECT:0xA7,1,0,0};before=stalls;reads=card.reads;writes=card.writes;
  CHECK((op?xe_np_usb_catalog_request(&fixture_pcd,&q):usb_delete_request_setup(&fixture_pcd,&q))==1&&stalls==before+1&&np_download_prefetch.valid!=0&&card.reads==reads&&card.writes==writes);
 }
}
int main(void){prior_adapter_cases();sd_info_cases();delete_cases();idle_cache_cases();printf("PASS %u actual maintenance lifecycle/identity/metadata-only delete checks; %u immutable CRC snapshots; modeled HAL/USB, no hardware\n",maintenance_checks,snapshot_checks);return 0;}
