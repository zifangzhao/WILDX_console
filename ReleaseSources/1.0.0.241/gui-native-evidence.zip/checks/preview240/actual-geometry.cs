using System;namespace CE32_console{internal static class NpSdGeometry{  internal static uint U(byte[] b,int p){return BitConverter.ToUInt32(b,p);}
  internal static int Count(uint mask){return (int)((mask&1)+((mask>>1)&1)+((mask>>2)&1));}
  internal static bool Valid(uint mask,uint hz){return mask>=1 && mask<=7 && (hz==7500 || hz==15000 || hz==30000) && !(mask==7 && hz==30000);}}}