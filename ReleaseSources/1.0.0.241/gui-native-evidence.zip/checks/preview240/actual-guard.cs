using System;using WildNpClosedLoop;namespace USB512_interface{internal static class NpBleForm{        internal static bool CanPreviewHost(bool deviceCanPreview,bool? closedLoop)
        {return deviceCanPreview && closedLoop==false;}
        internal static string PreviewBlockedReason(bool? closedLoop)
        {return closedLoop==true?"BLE preview unavailable while closed-loop is configured or active.":closedLoop==null?"BLE preview unavailable: firmware did not confirm closed-loop state.":String.Empty;}
        internal static bool? ClosedLoopPreviewState(byte[] request,byte[] response)
        {
            var q=NpClosedLoopControl.Parse(request);
            var r=NpClosedLoopControl.ParseReply(response,q.Operation,q.RequestId);
            if(r.Result!=0)return null;
            bool configured=(r.Flags&2U)!=0;
            if(q.Operation==1 && (configured!=(q.Channels.Length!=0) || configured && r.ConfigCrc!=q.ConfigCrc))return null;
            return configured;
        }}}