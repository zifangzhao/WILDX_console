import hashlib,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent
P=Path('C:/Frank/Code/XE_NP/_artifacts/closed_loop_qualification_20261104/V1')
P0=Path('C:/Frank/Code/XE_NP/_artifacts/v1_usb_sensor_media_20261105')
H=Path('C:/Frank/Code/USB_PCconsole/_artifacts/sd_usb_test_host/enabled240-guiops/WILDX_console.exe')
oldhost='F52F9CC2B7CA5231CE7059211501B9CF6B4F9829F441AC0992B3DDC1803F1DD7'
oldsdk='A381FFC3CD91A9CC2007E39AECBEFDABD1BB6023E343B481CAB600E371FDD85F'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
newhost=sha(H);newsdk=sha(H.with_name('NpV2SdDatExport.dll'))
assert newhost=='BD0416D30E53946B65380D8F925AE002C277D9C835D22F6A59598D1675F26ECD'
pair={k:json.loads((T/f'build-{k}/identity.json').read_text()) for k in ('app','usb')}
(T/'matched-test-pair.json').write_text(json.dumps(pair,indent=2)+'\n')
for name in ('bench_hil.py','bench_stop.py','hold-lease.ps1','control.ps1','restore-profile-cross-rate.ps1','bench_final_profile.py'):
 s=(P0/name).read_text(encoding='utf-8-sig').replace(str(P0).replace('\\','/'),str(T).replace('\\','/')).replace(str(P0).replace('/','\\'),str(T).replace('/','\\')).replace('build-r2/candidate.map','build-usb/candidate.map')
 (T/name).write_text(s,encoding='utf-8')
D=T/'sd-harness';D.mkdir(exist_ok=True)
for name in ('NpFirstSyncV1SdCurrent.cs','NpSdDownloadControl.cs','AcceptanceCurrentPins.cs','EnforcedGrid226Evidence.cs'):
 s=(P/'sd-harness'/name).read_text(encoding='utf-8-sig').replace(oldhost,newhost).replace(oldsdk,newsdk).replace('231','240').replace(str(P/'bench'),str(T/'bench'))
 if name=='NpFirstSyncV1SdCurrent.cs':
  s=s.replace('static class NpFirstSyncV1SdCurrent {','static partial class NpFirstSyncV1SdCurrent {')
  s=s.replace('if(U(status,"State")==1U&&U(status,"Chunks")>0&&span==null)span=System.Diagnostics.Stopwatch.StartNew();','if(U(status,"State")==1U&&U(status,"Chunks")>0&&span==null){span=System.Diagnostics.Stopwatch.StartNew();await PreviewBegin(connection,epoch);}')
  s=s.replace('await Task.Delay(500);','await PreviewRenew(connection,epoch);await Task.Delay(500);')
  s=s.replace('Same(form,connection,epoch,peer);stopSent=true;await Await(Call(form,"StopRecording"));','await PreviewEnd(connection,epoch);Same(form,connection,epoch,peer);stopSent=true;await Await(Call(form,"StopRecording"));')
  s=s.replace('if(prepared&&!stopSent&&(bool)Get(connection,"Connected")', 'try{await PreviewEnd(connection,epoch);}catch(Exception ex){Report["preview_cleanup_error"]=ex.ToString();}\n            if(prepared&&!stopSent&&(bool)Get(connection,"Connected")')
 (D/name).write_text(s,encoding='utf-8')
U=T/'usb-harness';U.mkdir(exist_ok=True)
for name in ('Bench.cs',):
 s=(P/'usb-harness'/name).read_text(encoding='utf-8-sig').replace('231','240').replace(oldhost,newhost).replace(oldsdk,newsdk)
 s=s.replace('BoundedSpan(result,55)','BoundedSpan(result,25)')
 (U/name).write_text(s,encoding='utf-8')
(U/'EnforcedGrid226Evidence.cs').write_text((D/'EnforcedGrid226Evidence.cs').read_text(),encoding='utf-8')
(T/'helper-inputs.json').write_text(json.dumps(dict(host=str(H),host_sha256=newhost,sdk_sha256=newsdk,parent_sd=str(P/'sd-harness'),parent_usb=str(P/'usb-harness'),parent_hil=str(P0),pair=pair),indent=2)+'\n')
print(json.dumps(dict(host=newhost,sdk=newsdk,pair={k:v['image_crc32'] for k,v in pair.items()})))
