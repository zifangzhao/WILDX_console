
from pathlib import Path
import json,re,struct,sys
import bench_hil as bench
import ap_snapshot

c=bench.c
ap_snapshot.PHASE=c.PHASE
report=json.loads((c.PHASE/sys.argv[1]/"hil.json").read_text(encoding="utf-8-sig"))
c.require(report.get("capture_completed_idle") is True and
          report.get("original_profile_restored") is True and
          report.get("persistent_preferences_unchanged") is True and
          report["normal_stop_status"]["State"]==3 and report["normal_stop_status"]["Fault"]==0,
          "Expected normal Stop, idle APP and restored profile")
mapping=Path(r'C:/Frank/Code/XE_NP/_artifacts/v1_gui_support_20261105/build-app/candidate.map').read_text()
ranges={"uid":(0x0bfa0700,12),"app":(0x0801e000,128),"usb":(0x0817e000,128),
        "vtor":(0xe000ed08,4),"dma":(0x40020000,2048),"sd":(0x420c8034,36),"core":(0xe000edf0,4)}
for symbol,label,size in (("np_sd_finalized","finalized",1),
                          ("npl_preview_storage","preview_storage",4680),
                          ("np_sd_grid_diag","grid_diag",16),
                          ("np_sd_sensor_queue_diag","sensor_queue",24)):
    match=re.findall(r"^\s*"+symbol+r"\s+0x([0-9a-fA-F]+)\s+Data\s+"+str(size)+r"\b",mapping,re.M)
    c.require(len(match)==1,"Missing exact map symbol "+symbol)
    ranges[label]=(int(match[0],16),size)
folder=c.PHASE/(sys.argv[1]+"_stopped")
if "--check-existing" in sys.argv:
    raw={key:(folder/(key+".bin")).read_bytes() for key in ranges}
else:
    raw=ap_snapshot.collect(folder,ranges,c.SERIAL,0x08020000)
word=lambda key,offset=0:struct.unpack_from("<I",raw[key],offset)[0]
uid=''.join(f'{part:08X}' for part in struct.unpack('<3I',raw['uid']))
c.require(uid==c.UID and word("vtor")==0x08020000,"Exact V1 APP identity required")
c.require(word("app",32)==int(c.PINS["app"][1],16) and word("usb",32)==int(c.PINS["usb"][1],16),"Firmware differs")
c.require(report.get("catalog_preserved") is True and report.get("owned_session_kept") is True and
          report["actual_catalog_record"]["End"] > report["actual_catalog_record"]["Start"],
          "Confirmed completed catalog append required")
c.require(not any(word("dma",0x64+i*0x80)&1 for i in range(16)),"DMA active")
c.require(word("sd",28)&1==0 and word("sd")&0x3000==0,"SD/IDMA active")
c.require(word("core")&1==0,"CPU debug enabled")
proof={"result":"PASS","uid":c.UID,"normal_stop_and_catalog_append_verified":True,
       "recorder_finalized_latch":raw["finalized"][0],"all_16_dma_disabled":True,"sd_data_idma0":True,"read_only":True}
(folder/"proof.json").write_text(json.dumps(proof,indent=2)+"\n")
print(json.dumps(proof))



