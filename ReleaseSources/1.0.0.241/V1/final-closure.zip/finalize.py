import collections,csv,hashlib,json,re,struct,zipfile,zlib
from pathlib import Path
T=Path(__file__).resolve().parent;B=T/'bench'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def kv(p):return dict(x.split('=',1) for x in p.read_text().splitlines() if '=' in x)
def cadence(rows,seq,tick):
 valid=[r for r in rows if r[seq] and r[tick]]
 steps=[(b[seq]-a[seq])&0xffffffff for a,b in zip(valid,valid[1:])];forward=[x for x in steps if 0<x<0x80000000]
 span=(valid[-1][tick]-valid[0][tick])&0xffffffff if len(valid)>1 else 0
 return dict(valid_snapshots=len(valid),rate_hz=sum(forward)*1000/span if span else None,source_span_ms=span,repeats=steps.count(0),backwards=sum(x>=0x80000000 for x in steps),unobserved_sequence_numbers=sum(x-1 for x in forward),scope='Sparse latest-value snapshot observations; skipped observations are not proven conversion loss')
F=B/'sd-preview-verified/export';raw=(F/'sensors.bin').read_bytes();assert len(raw)%164==0
rows=[]
for at in range(0,len(raw),164):
 b=raw[at:at+164];assert b[:8]==b'NPSENS01' and struct.unpack_from('<I',b,16)[0]==140 and zlib.crc32(b[:160])==struct.unpack_from('<I',b,160)[0]
 rows.append(struct.unpack_from('<35I',b,20))
csvrows=list(csv.DictReader((F/'sensors.csv').open(newline='')));assert len(csvrows)==len(rows)
for r,c in zip(rows,csvrows):
 for key,i in [('valid',3),('imu_sequence',5),('mag_sequence',6),('imu_tick_ms',8),('mag_tick_ms',9),('imu_error',26),('env_error',27)]:assert r[i]==int(c[key])
ag=[r for r in rows if r[3]&1 and not r[26]];mag=[r for r in rows if r[3]&2 and not r[26]]
valid=(F/'analogin_validity.dat').read_bytes();analog=(F/'analogin.dat').read_bytes();assert len(analog)==32*len(valid)
counts=collections.Counter();repeat_bad=0;previous=None
for i,f in enumerate(valid):
 vals=struct.unpack_from('<16h',analog,32*i)
 for label,mask in [('observed',1),('ag_valid',2),('mag_valid',4),('ag_repeat',8),('mag_repeat',16),('error',32)]:counts[label]+=bool(f&mask)
 if not f&1:counts['missing']+=1
 if previous is not None and ((f&8 and vals[1:7]!=previous[1:7]) or (f&16 and vals[7:10]!=previous[7:10])):repeat_bad+=1
 previous=vals
 # Exact analog sensor words are documented 1-based words2..10.
assert repeat_bad==0 and counts['error']==0
axes={name:dict(unique=len({int(c[name]) for c in csvrows if int(c['valid'])&mask}),changes=sum(int(a[name])!=int(b[name]) for a,b in zip(csvrows,csvrows[1:]) if int(a['valid'])&mask and int(b['valid'])&mask)) for name,mask in [('accel_x_micro_g',1),('accel_y_micro_g',1),('accel_z_micro_g',1),('gyro_x_milli_dps',1),('gyro_y_milli_dps',1),('gyro_z_milli_dps',1),('mag_x_nano_tesla',2),('mag_y_nano_tesla',2),('mag_z_nano_tesla',2)]}
sensor=dict(status='REVIEWED_VALID_ONLY_NATIVE_CADENCE',records=len(rows),crc_validated=len(rows),invalid_ag_indices=[i for i,r in enumerate(rows) if not r[3]&1],invalid_mag_indices=[i for i,r in enumerate(rows) if not r[3]&2],imu_errors=dict(collections.Counter(str(r[26]) for r in rows)),environment_errors=dict(collections.Counter(str(r[27]) for r in rows)),native_ag=cadence(ag,5,8),native_mag=cadence(mag,6,9),axes=axes,grid=dict(rows=len(valid),counts=dict(counts),repeat_value_mismatches=repeat_bad,source_window_verified=kv(F/'analogin_encoding.txt')['source_window_verified']),limits=['Unavailable native startup snapshots remain invalid; valid-only cadence excludes them.','1250Hz is deterministic cached-copy cadence, not the sensor conversion rate.','source_window=False and unknown terminal tail remain as recorded, not relabeled.'])
(T/'sensor-analysis/sd-preview.json').write_text(json.dumps(sensor,indent=2)+'\n')
print(json.dumps(dict(sd_sensor_records=len(rows),native_ag=sensor['native_ag'],native_mag=sensor['native_mag'],grid=sensor['grid']),indent=2))
