using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;

static partial class NpFirstSyncV1SdCurrent {
    static void PreviewOracle(string path,object record,string priorFolder){
        string[] rows=File.ReadAllLines(Path.Combine(priorFolder,"preview-samples.csv"));Need(rows.Length>1,"Retained preview rows absent");
        int packets=(rows.Length-1)/32;Need(packets>2&&(rows.Length-1)%32==0,"Unexpected two-channel compact packet geometry");
        int[] selected={0,packets/2,packets-1};var blocks=new Dictionary<long,byte[]>();long matches=0,missing=0;uint version=0;var compared=new List<object>();
        string fixture=Path.Combine(output,"preview-oracle");Directory.CreateDirectory(fixture);
        using(var card=(Stream)New("CE32_console.NpDownloadStream",path,false)){
            var header=new byte[512];card.Position=checked((long)L(record,"StartLba")*512+1536);int count=0;while(count<512){int n=card.Read(header,count,512-count);Need(n>0,"Short descriptor");count+=n;}
            Need(header.SequenceEqual(File.ReadAllBytes(Path.Combine(output,"observed_descriptor.bin"))),"Current extent descriptor changed");
            version=BitConverter.ToUInt32(header,8);uint mask=BitConverter.ToUInt32(header,16),start=BitConverter.ToUInt32(header,48);Need((version==6||version==7)&&mask==3,"Unsupported V1 source geometry");
            File.WriteAllBytes(Path.Combine(fixture,"header.bin"),header);
            foreach(int packet in selected)for(int r=0;r<32;r++){
                string[] cells=rows[1+packet*32+r].Split(',');uint probe=UInt32.Parse(cells[1]),channel=UInt32.Parse(cells[2]);ulong tick=UInt64.Parse(cells[4]);if(cells[6]!="1"){missing++;continue;}
                int adc=(int)(channel/24*2+(channel&1)),line=adc<30?adc/5+1:7,value=0;int ticks=version==7?30720:61440;
                for(int bit=0;bit<10;bit++){
                    ulong source=tick+(uint)bit;long chunk=(long)(source/(uint)ticks);int local=(int)(source%(uint)ticks),at;
                    if(version==7)at=(local&3)*15360+(local>>2)*2+(int)probe-1;
                    else{chunk=chunk*2+(long)probe-1;at=(local&3)*15360+(local>>2);}
                    byte[] bytes;if(!blocks.TryGetValue(chunk,out bytes)){
                        bytes=new byte[65536];card.Position=checked((long)L(record,"StartLba")*512+(long)start*512+chunk*65536);int offset=0;while(offset<bytes.Length){int n=card.Read(bytes,offset,bytes.Length-offset);Need(n>0,"Short bounded source block");offset+=n;}blocks.Add(chunk,bytes);
                    }
                    value=(value<<1)|((bytes[at]>>line)&1);
                }
                int expected=Int32.Parse(cells[5]);compared.Add(new {packet,probe,channel,tick,expected,actual=value});Need(value==expected,"Preview source-bit oracle mismatch at tick"+tick);matches++;
            }
        }
        foreach(var b in blocks)File.WriteAllBytes(Path.Combine(fixture,"chunk-"+b.Key+".bin"),b.Value);
        var report=new {result="PASS bounded first/middle/last actual raw10 comparisons",source_format=version,packets_selected=selected,matches,explicit_missing=missing,physical_blocks=blocks.Count,retained_bytes=blocks.Count*65536,rows=compared,scope="Three compact packets; exact source bits, no repaired/rephased data; full recording NP/IMU checked by production export separately"};
        File.WriteAllText(Path.Combine(fixture,"result.json"),Json.Serialize(report));Report["preview_source_oracle"]=report;
    }
}
