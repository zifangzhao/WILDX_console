using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Web.Script.Serialization;

// Helper-only, file-only replay. No device, control, Form, timer or thread API.
// Original NPGRID carriers are not archived by190; do not claim their replay.
internal static class EnforcedGridCurrentEvidence {
    internal static Assembly App;
    const BindingFlags All=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Static|BindingFlags.Instance;
    internal static Type T(string n){return App.GetType("USB512_interface."+n,true);}
    internal static object Get(object o,string n){var f=o.GetType().GetField(n,All);return f!=null?f.GetValue(o):o.GetType().GetProperty(n,All).GetValue(o,null);}
    static void Set(object o,string n,object v){o.GetType().GetField(n,All).SetValue(o,v);}
    internal static object Call(object o,string n,params object[] a){try{return (o as Type??o.GetType()).GetMethods(All).Single(m=>m.Name==n&&m.GetParameters().Length==a.Length).Invoke(o is Type?null:o,a);}catch(TargetInvocationException e){throw e.InnerException??e;}}
    static object New(string n){return Activator.CreateInstance(T(n),true);}
    static uint U(object o,string n){return Convert.ToUInt32(Get(o,n));}
    static ulong Q(object o,string n){return Convert.ToUInt64(Get(o,n));}
    static void Need(bool ok,string why){if(!ok)throw new InvalidDataException(why);}
    static string Hash(string p){using(var s=File.OpenRead(p))using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(s)).Replace("-","");}
    static Dictionary<string,string> Lines(string p){var d=new Dictionary<string,string>();foreach(string line in File.ReadLines(p)){int at=line.IndexOf('=');if(at<1)continue;string k=line.Substring(0,at);Need(!d.ContainsKey(k),"Repeated encoding field "+k);d.Add(k,line.Substring(at+1));}return d;}
    static ulong Number(Dictionary<string,string> d,string k){return UInt64.Parse(d[k],CultureInfo.InvariantCulture);}
    sealed class Span {internal ulong Slot,Count,Row;}
    static List<Span> Csv(string p,bool segments){
        var result=new List<Span>();using(var r=File.OpenText(p)){Need(r.ReadLine()==(segments?"first_slot,row_count,first_file_row":"first_slot,slot_count,reason"),"Grid CSV header");string line;ulong end=0,rowEnd=0;while((line=r.ReadLine())!=null){
            if(String.IsNullOrWhiteSpace(line))continue;var c=line.Split(',');Need(c.Length==3,"Grid CSV row");
            var s=new Span{Slot=UInt64.Parse(c[0],CultureInfo.InvariantCulture),Count=UInt64.Parse(c[1],CultureInfo.InvariantCulture),Row=segments?UInt64.Parse(c[2],CultureInfo.InvariantCulture):0};
            Need(s.Count>0&&s.Slot>=end&&s.Slot<=UInt64.MaxValue-s.Count,"Grid CSV overlap/overflow");
            if(segments){Need(s.Row==rowEnd&&s.Row<=UInt64.MaxValue-s.Count,"Grid file-row mapping");rowEnd=s.Row+s.Count;}
            end=s.Slot+s.Count;result.Add(s);
        }}return result;
    }
    internal static Dictionary<string,object> Assess(string folder,object receipt,string uid,ulong token,object rtcBounds,Action<string,uint,Dictionary<string,string>> selectionProof=null,string expectedCarrier="NSG1"){
        var report=new Dictionary<string,object>{{"imu_data_success",false},{"np_relative_phase_qualified",false},{"rtc_phase_qualified",false},
            {"terminal_tail_qualified",false},{"terminal_tail_reason","No final scheduled-slot/end marker is archived; trailing coverage remains unknown."},
            {"source_window_verified",false},{"enforced_schedule_verified",false},{"raw_control_replay",false},{"sample0_lock",false},{"physical_conversion_phase_locked",false},{"raw_carrier_replay",false},
            {"first_slot_np_phase_qualified",false},{"first_slot_rtc_phase_qualified",false},{"first_slot_phase_scope","start_only; no later-slot or physical conversion-phase claim"}};
        var errors=new List<string>();Dictionary<string,string> enc=null;ulong rows=0,slots=0,observed=0,missing=0,ag=0,mag=0,agRepeat=0,magRepeat=0,errorRows=0;
        ulong? first=null,last=null;ulong agValues=0,magValues=0;byte[] previous=null;ulong previousSlot=0;int previousFlags=0;
        try{
            enc=Lines(Path.Combine(folder,"analogin_encoding.txt"));Need(enc["schema"]=="NP_IMU_NSG1_GRID_V1","Not an actual NSG1 indexed grid");
            rows=Number(enc,"rows");slots=Number(enc,"slot_extent");Need(rows>0&&slots>=rows&&rows<=Int64.MaxValue/32,"Grid extent");
            Need(new FileInfo(Path.Combine(folder,"analogin.dat")).Length==(long)rows*32&&new FileInfo(Path.Combine(folder,"analogin_validity.dat")).Length==(long)rows,"Grid DAT/validity extents");
            var segments=Csv(Path.Combine(folder,"imu_grid_segments.csv"),true);var gaps=Csv(Path.Combine(folder,"imu_grid_gaps.csv"),false);
            Need(segments.Count>0&&segments.Last().Row+segments.Last().Count==rows&&segments.Last().Slot+segments.Last().Count<=slots,"Segment extent");
            ulong gapCount=0;foreach(var g in gaps){Need(g.Slot+g.Count<=slots&&gapCount<=UInt64.MaxValue-g.Count,"Gap extent");gapCount+=g.Count;}
            int si=0,gi=0;using(var input=File.OpenRead(Path.Combine(folder,"analogin_validity.dat")))using(var analog=new BinaryReader(File.OpenRead(Path.Combine(folder,"analogin.dat")))){
                for(ulong row=0;row<rows;row++){
                    while(row>=segments[si].Row+segments[si].Count)si++;
                    ulong slot=segments[si].Slot+row-segments[si].Row;while(gi<gaps.Count&&gaps[gi].Slot+gaps[gi].Count<=slot)gi++;
                    bool gap=gi<gaps.Count&&gaps[gi].Slot<=slot;int f=input.ReadByte();byte[] values=analog.ReadBytes(32);Need(values.Length==32,"Truncated analog row");ValidateAnalog(values,f);
                    Need(f>=0&&(f&~63)==0&&((f&1)!=0||(f&~1)==0)&&((f&8)==0||(f&2)!=0)&&((f&16)==0||(f&4)!=0),"Grid validity/repeat mask");
                    if((f&1)==0){Need(f==0&&gap,"Missing row lacks explicit gap");previous=null;continue;}
                    if(previous!=null&&slot>0&&previousSlot==slot-1){if((f&8)!=0&&(previousFlags&2)!=0)Need(values.Skip(2).Take(12).SequenceEqual(previous.Skip(2).Take(12)),"Repeated AG native values changed");if((f&16)!=0&&(previousFlags&4)!=0)Need(values.Skip(14).Take(6).SequenceEqual(previous.Skip(14).Take(6)),"Repeated MAG native values changed");}
                    if((f&2)!=0&&Enumerable.Range(0,6).Any(a=>BitConverter.ToInt16(values,2+a*2)!=Int16.MinValue))agValues++;
                    if((f&4)!=0&&Enumerable.Range(0,3).Any(a=>BitConverter.ToInt16(values,14+a*2)!=Int16.MinValue))magValues++;
                    previous=values;previousSlot=slot;previousFlags=f;
                    Need(!gap,"Observed row overlaps missing range");if(!first.HasValue)first=slot;last=slot;observed++;
                    if((f&2)!=0)ag++;if((f&4)!=0)mag++;if((f&8)!=0)agRepeat++;if((f&16)!=0)magRepeat++;if((f&32)!=0)errorRows++;
                }
            }
            missing=slots-observed;Need(gapCount==missing&&Number(enc,"observed")==observed&&Number(enc,"missing")==missing&&Number(enc,"ag_repeated")==agRepeat&&Number(enc,"mag_repeated")==magRepeat,"Grid stored counters/gaps disagree");
            Need(first.HasValue&&ag>0&&mag>0&&agValues>0&&magValues>0&&errorRows==0,"No valid non-sentinel AG/MAG rows or sensor errors present");Need(Number(enc,"first_observed_slot")==first.Value,"First observed encoding disagrees with actual validity/segments");
            Need(enc["np_sample_grid_locked"].StartsWith("false",StringComparison.Ordinal),"False sample0 lock");
            var status=Lines(Path.Combine(folder,"imu_grid_status.txt"));Need(status["carrier"]==expectedCarrier&&status["error"]=="none"&&(expectedCarrier!="NSG1"||status["selected"]=="true"),"Runtime carrier/status error");
            report["imu_data_success"]=true;report["runtime_status"]=status;report["encoding"]=enc;
        }catch(Exception e){errors.Add("data: "+e.Message);}
        report["rows"]=rows;report["slot_extent"]=slots;report["observed"]=observed;report["missing"]=missing;report["ag_valid_rows"]=ag;report["mag_valid_rows"]=mag;
        report["ag_repeated"]=agRepeat;report["mag_repeated"]=magRepeat;report["sensor_error_rows"]=errorRows;report["ag_native_value_rows"]=agValues;report["mag_native_value_rows"]=magValues;report["first_stored_observed_slot"]=first;report["last_stored_observed_slot"]=last;
        try{
            Need((bool)report["imu_data_success"],"Stored grid data unavailable");Need(receipt!=null&&token!=0,"Final independently bound source context unavailable");
            var r=Call(T("NpFirstSyncWire"),"Parse",(byte[])Get(receipt,"Raw"));Need((U(r,"Family")==1&&U(r,"Mask")==3||U(r,"Family")==2&&U(r,"Mask")==7)&&U(r,"ApHz")==15000&&(U(r,"Flags")&35)==35,"Final matched V1/V2 15k source context");
            var binding=Call(T("NpImuGridWriter"),"PhaseBinding",uid,token,r);
            byte[] raw=File.ReadAllBytes(Path.Combine(folder,"imu_grid_phase.bin"));var phase=Call(T("NpImuGridPhase"),"Read",raw,binding);
            var aux=((Array)Get(r,"Aux")).GetValue(0);
            Need((U(r,"AuxMask")&1)!=0&&U(aux,"Id")==1&&(U(aux,"Flags")&5)==5&&U(aux,"CounterBits")==64&&
                U(aux,"RateNumerator")==1250&&U(aux,"RateDenominator")==1&&Q(aux,"Counter")==Q(phase,"FirstAcceptedSlot")&&first.Value==Q(phase,"FirstAcceptedSlot"),"Aux1/NSGP/first stored observed slot mismatch");
            bool point=(U(aux,"Flags")&64)!=0&&U(aux,"StampKind")==1;
            bool startupOnlyWithoutPoint=U(phase,"Flags")==1&&U(phase,"MaximumJitter")==UInt32.MaxValue&&(U(aux,"Flags")&64)==0&&U(aux,"StampKind")==0;
            bool enforcedCounterOnly=enc["enforced_schedule_verified"]=="True"&&U(phase,"Flags")==3&&(U(aux,"Flags")&64)==0&&U(aux,"StampKind")==0;Need(point||startupOnlyWithoutPoint||enforcedCounterOnly,"Claimed interval lacks genuine POINT or explicitly enforced counter-only proof");
            report["first_slot_native_point_present"]=point;report["startup_only_without_aux_point"]=startupOnlyWithoutPoint;
            var runtime=Lines(Path.Combine(folder,"imu_grid_status.txt"));
            report["runtime_first_slot_phase_valid"]=runtime.ContainsKey("first_slot_phase_valid")&&runtime["first_slot_phase_valid"]=="True"||U(r,"Family")==2&&runtime.ContainsKey("first_source_verified")&&runtime["first_source_verified"]=="True";
            if((U(phase,"Flags")&1)!=0&&enc.ContainsKey("first_slot_phase_valid")&&enc["first_slot_phase_valid"]=="True"&&(bool)report["runtime_first_slot_phase_valid"]){
                Need(enc["first_slot_phase_scope"].StartsWith("start_only",StringComparison.Ordinal),"First-slot scope was broadened");
                Need(Number(enc,"phase_source_hz")==U(r,"SourceHz")&&Number(enc,"first_accepted_slot")==first.Value&&
                    Int64.Parse(enc["phase_lower_source_tick_numerator"],CultureInfo.InvariantCulture)==Convert.ToInt64(Get(phase,"LowerNumerator"))&&
                    Int64.Parse(enc["phase_upper_source_tick_numerator"],CultureInfo.InvariantCulture)==Convert.ToInt64(Get(phase,"UpperNumerator"))&&Number(enc,"phase_denominator")==U(phase,"Denominator"),"First-slot raw NSGP/encoding mismatch");
                decimal lower=Decimal.Floor(Convert.ToDecimal(Get(phase,"LowerNumerator"))*1000000m/U(phase,"Denominator")/U(r,"SourceHz"));
                decimal upper=Decimal.Ceiling(Convert.ToDecimal(Get(phase,"UpperNumerator"))*1000000m/U(phase,"Denominator")/U(r,"SourceHz"));
                Need(Decimal.Parse(enc["first_slot_offset_lower_us"],CultureInfo.InvariantCulture)==lower&&Decimal.Parse(enc["first_slot_offset_upper_us"],CultureInfo.InvariantCulture)==upper,"First-slot interval rounded inward or changed");
                report["first_slot_np_phase_qualified"]=true;report["first_slot_np_lower_us"]=lower;report["first_slot_np_upper_us"]=upper;
                if(rtcBounds!=null&&(bool)Get(rtcBounds,"Qualified")){report["first_slot_rtc_phase_qualified"]=true;report["first_slot_rtc_lower_us"]=Convert.ToDecimal(Get(rtcBounds,"LowerUs"))+lower;report["first_slot_rtc_upper_us"]=Convert.ToDecimal(Get(rtcBounds,"UpperUs"))+upper;}
            }
            Need((bool)report["first_slot_np_phase_qualified"],"Actual saved first-source/first-slot proof unavailable");
            Need(U(phase,"Flags")==3&&enc["enforced_schedule_verified"]=="True"&&enc["grid_phase_qualified"]=="True","Enforced interval/jitter or runtime phase qualification missing");
            Need(enc["output_grid_hz"].StartsWith("1250; period_us=800;",StringComparison.Ordinal),"1250Hz/800us output cadence changed");
            report["slot_rate_hz"]=1250;report["slot_period_us"]=800;report["native_values_scope"]="Stored scaling/sentinels and adjacent declared repeats independently checked; original NSG physical payloads are not archived";
            report["source_window_verified"]=enc["source_window_verified"]=="True";report["enforced_schedule_verified"]=true;if(selectionProof==null)RequireSelection(folder,U(r,"Family"),runtime);else selectionProof(folder,U(r,"Family"),runtime);
            Need(Number(enc,"phase_source_hz")==U(r,"SourceHz")&&Number(enc,"first_accepted_slot")==first.Value&&
                Int64.Parse(enc["phase_lower_source_tick_numerator"],CultureInfo.InvariantCulture)==Convert.ToInt64(Get(phase,"LowerNumerator"))&&
                Int64.Parse(enc["phase_upper_source_tick_numerator"],CultureInfo.InvariantCulture)==Convert.ToInt64(Get(phase,"UpperNumerator"))&&
                Number(enc,"phase_denominator")==U(phase,"Denominator")&&Number(enc,"maximum_relative_slot_jitter_source_ticks")==U(phase,"MaximumJitter"),"Saved phase fields disagree with original NSGP");
            decimal hz=U(r,"SourceHz"),lo=Convert.ToDecimal(Get(phase,"LowerNumerator"))/U(phase,"Denominator"),hi=Convert.ToDecimal(Get(phase,"UpperNumerator"))/U(phase,"Denominator"),jitter=U(phase,"MaximumJitter");
            decimal delta=(decimal)(last.Value-first.Value)*hz/1250m;
            report["np_relative_phase_qualified"]=true;report["phase_sha256"]=Hash(Path.Combine(folder,"imu_grid_phase.bin"));report["source_uid"]=uid;report["source_token_hex"]=token.ToString("X16");
            report["session"]=U(r,"Session");report["generation"]=U(r,"Generation");report["source_epoch"]=U(r,"SourceEpoch");report["domain"]=U(r,"Domain");report["source_hz"]=U(r,"SourceHz");
            report["first_observed_np_lower_us"]=Decimal.Floor(lo*1000000m/hz);report["first_observed_np_upper_us"]=Decimal.Ceiling(hi*1000000m/hz);
            report["last_observed_np_lower_us"]=Decimal.Floor((lo+delta-jitter)*1000000m/hz);report["last_observed_np_upper_us"]=Decimal.Ceiling((hi+delta+jitter)*1000000m/hz);
            report["relative_jitter_bound_us"]=Decimal.Ceiling(jitter*1000000m/hz);
            if(rtcBounds!=null&&(bool)Get(rtcBounds,"Qualified")){
                report["rtc_phase_qualified"]=true;report["first_observed_rtc_lower_us"]=Convert.ToDecimal(Get(rtcBounds,"LowerUs"))+(decimal)report["first_observed_np_lower_us"];
                report["first_observed_rtc_upper_us"]=Convert.ToDecimal(Get(rtcBounds,"UpperUs"))+(decimal)report["first_observed_np_upper_us"];
                report["last_observed_rtc_lower_us"]=Convert.ToDecimal(Get(rtcBounds,"LowerUs"))+(decimal)report["last_observed_np_lower_us"];
                report["last_observed_rtc_upper_us"]=Convert.ToDecimal(Get(rtcBounds,"UpperUs"))+(decimal)report["last_observed_np_upper_us"];
            }else errors.Add("RTC: independently replayed local RTC T0 unavailable.");
        }catch(Exception e){errors.Add("phase: "+e.Message);}
        report["errors"]=errors.ToArray();report["scope"]="Saved NSGP/validity/segments/gaps plus actual190 runtime CRC/status. Explicit enforced schedule and saved rows only. No independent original control/carrier replay, no terminal tail, no native conversion phase or SAMPLE0_LOCK claim.";
        return report;
    }
    static void ValidateAnalog(byte[] b,int f){
        Need(BitConverter.ToInt16(b,0)==0&&BitConverter.ToInt16(b,20)==Int16.MinValue&&BitConverter.ToInt16(b,22)==-1&&b.Skip(24).Take(4).All(x=>x==0),"Grid row legacy/unavailable words changed");
        for(int a=0;a<9;a++)if((f&(a<6?2:4))==0)Need(BitConverter.ToInt16(b,2+a*2)==Int16.MinValue,"Invalid/missing sensor row contains a fabricated value");
    }
    static void RequireSelection(string folder,uint family,Dictionary<string,string> runtime){
        Need(runtime.ContainsKey("enforced_schedule_verified")&&runtime["enforced_schedule_verified"]=="True","Actual runtime enforcement unavailable");
        Need(!Directory.Exists(Path.Combine(folder,"imu_grid_lab")),"LAB grid owner is not ordinary production acceptance");
        var settings=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(Path.Combine(folder,"recording_settings.json")));
        Need(settings.ContainsKey("imu_grid_selected")&&(bool)settings["imu_grid_selected"],"Grid selection not saved");
        if(family==1){if(settings.ContainsKey("imu_grid_control_version"))Need(Convert.ToUInt32(settings["imu_grid_control_version"])==2&&(bool)settings["imu_grid_enforced_schedule"],"USB actual NSGC version2/enforcement unavailable");
            else{byte[] h=File.ReadAllBytes(Path.Combine(folder,"descriptor.bin")),f=File.ReadAllBytes(Path.Combine(folder,"footer.bin"));foreach(var b in new[]{h,f})Need(b.Length==512&&BitConverter.ToUInt32(b,508)==(uint)Call(T("NpImuGridCarrier"),"Crc",b,0,508),"SD metadata CRC");Need((bool)Call(T("NpImuGridCarrier"),"SdEnforcedSchedule",h,f),"SD declaration revision2 missing");}}
        else Need(runtime["control_version"]=="2"&&runtime["analog_owner"]=="scheduled_grid"&&runtime["lab_only"]=="False"&&settings.ContainsKey("imu_grid_enforced_schedule_verified")&&(bool)settings["imu_grid_enforced_schedule_verified"],"V2 production NSGC2/root analog owner unavailable");
    }
    internal static void BoundedSpan(Dictionary<string,object> result,uint seconds){
        ulong span=result["first_stored_observed_slot"]==null||result["last_stored_observed_slot"]==null?0:Convert.ToUInt64(result["last_stored_observed_slot"])-Convert.ToUInt64(result["first_stored_observed_slot"]);
        result["minimum_observed_span_seconds"]=seconds;result["observed_ordinal_span"]=span;result["observed_span_budget_verified"]=span>=(ulong)seconds*1250;
        result["feature_acceptance_passed"]=(bool)result["imu_data_success"]&&(bool)result["np_relative_phase_qualified"]&&(bool)result["rtc_phase_qualified"]&&(bool)result["observed_span_budget_verified"];
    }
    internal static Dictionary<string,object> Usb(string folder,string uid){
        object receipt=null,bounds=null;ulong token=0;string error=null;
        try{var h=Call(T("NpFirstSyncUsbEvidence"),"Read",folder);Need(h!=null&&(bool)Get(h,"Qualified")&&(bool)Get(h,"FineQualified")&&(string)Get(h,"Uid")==uid,"Final USB NPSTART/kind5 binding unavailable");receipt=Get(h,"Receipt");token=Q(h,"Token");
            var rtc=Call(T("NpRtcUsbArchive"),"Read",folder);Need(rtc!=null&&(bool)Get(rtc,"Qualified"),"USB RTC raw replay unavailable");bounds=Get(rtc,"Bounds");
        }catch(Exception e){error=e.Message;}
        var result=Assess(folder,receipt,uid,token,bounds,(path,family,runtime)=>{
            Need(family==1&&runtime["selected"]=="true"&&runtime["enforced_schedule_verified"]=="True"&&runtime["carrier"]=="NSG1"&&runtime["grid_phase_qualified"]=="True"&&runtime["error"]=="none","Actual runtime NSGC2 selection differs");
        });result["source_replay_error"]=error;BoundedSpan(result,55);return result;
    }
    internal static Dictionary<string,object> Sd(string folder,string uid,ulong token,uint session){
        object receipt=null,bounds=null;string error=null;
        try{var clock=File.ReadAllBytes(Path.Combine(folder,"recorded_clock.bin"));var fine=File.ReadAllBytes(Path.Combine(folder,"first_source_clock_sector6.bin"));
            var source=Call(T("NpFineClockWire"),"ReadCompanion",fine,clock,1,session,15000U,uid,token);Need(source!=null&&(bool)Get(source,"FineCounter64"),"Final SD+5/+6 source binding unavailable");receipt=Get(Get(source,"Bound"),"Receipt");
            var binding=Call(T("NpRtcStartWire"),"BindSd",clock,fine,1,session,15000U,uid,token);var rtc=File.ReadAllBytes(Path.Combine(folder,"device_rtc_start_sector7.bin"));Call(T("NpRtcStartWire"),"ParseSector",rtc,binding);bounds=Call(T("NpRtcStartWire"),"Map",rtc.Take(128).ToArray(),binding);
        }catch(Exception e){error=e.Message;}
        var result=Assess(folder,receipt,uid,token,bounds);result["source_replay_error"]=error;BoundedSpan(result,25);return result;
    }
    static void Put(byte[] b,int at,uint n){Buffer.BlockCopy(BitConverter.GetBytes(n),0,b,at,4);}
    static void Put64(byte[] b,int at,ulong n){Buffer.BlockCopy(BitConverter.GetBytes(n),0,b,at,8);}
    static byte[] Receipt(){
        var b=new byte[328];Encoding.ASCII.GetBytes("NPSTART1").CopyTo(b,0);b[8]=1; b[10]=72;b[11]=1;Put(b,12,0x123);Put(b,16,9);Put(b,20,9);Put(b,24,11);Put(b,28,17);Put(b,32,11700000);Put(b,36,15000);Put(b,40,1000000);Put(b,44,UInt32.MaxValue);b[48]=3;b[49]=1;b[50]=1;b[51]=1;Put64(b,52,780);
        for(int p=0;p<2;p++){int at=64+p*20;Put64(b,at,(ulong)(780+p*37));Put(b,at+8,(uint)(52+p*13));ushort phase=(ushort)(p==0?0:743);Buffer.BlockCopy(BitConverter.GetBytes(phase),0,b,at+12,2);Buffer.BlockCopy(BitConverter.GetBytes((ushort)780),0,b,at+14,2);Put(b,at+16,31);}
        Put(b,124,UInt32.MaxValue);Put(b,128,UInt32.MaxValue);b[132]=1;b[133]=69;b[134]=64;b[135]=1;Put(b,136,UInt32.MaxValue);Put(b,140,UInt32.MaxValue);Put(b,144,1001);Put(b,148,500);Put64(b,152,3);Put(b,160,1250);Put(b,164,1);Put64(b,168,0x8000000000000000UL);Put(b,324,(uint)Call(T("NpFirstSyncWire"),"Crc",b,324));return b;
    }
    static byte[] ReceiptV2(){
        byte[] b=Receipt();Put(b,12,0x223);Put(b,32,31500000);b[48]=7;Put64(b,52,0);
        for(int p=0;p<3;p++){int at=64+p*20;ulong tick=(ulong)(p*37);Put64(b,at,tick);Put(b,at+8,UInt32.MaxValue);Buffer.BlockCopy(BitConverter.GetBytes((ushort)((1600-tick%1600)%1600)),0,b,at+12,2);Buffer.BlockCopy(BitConverter.GetBytes((ushort)1600),0,b,at+14,2);Put(b,at+16,27);}
        Put(b,324,(uint)Call(T("NpFirstSyncWire"),"Crc",b,324));return b;
    }
    internal static void SelfTest(string output){
        Need(!Directory.Exists(output)&&!File.Exists(output),"Fresh offline fixture path required");Directory.CreateDirectory(output);
        string uid="001D00065942500B20313354";const ulong token=123;var receipt=Call(T("NpFirstSyncWire"),"Parse",Receipt());int checks=0;
        foreach(string mode in new[]{"valid","missing_phase","wrong_token","lost_first","missing_jitter","bad_segments","aux_counter","terminal_unknown","known_interval_unknown_jitter","first_source_unverified","first_slot_bounds_mismatch","first_slot_scope_mismatch","startup_only_no_point","full_phase_no_point","legacy_control_v1","not_enforced","outside_source_window","bad_native_sentinel","v2_valid","v2_counter_only","v2_legacy_control"}){
            bool v2=mode.StartsWith("v2_",StringComparison.Ordinal);uint sourceHz=v2?31500000U:11700000U;string caseUid=v2?"001A0004434250062039314E":uid;
            object caseReceipt=v2?Call(T("NpFirstSyncWire"),"Parse",ReceiptV2()):receipt;
            if(mode=="startup_only_no_point"||mode=="full_phase_no_point"||mode=="v2_counter_only"){var source=(byte[])Get(caseReceipt,"Raw");source=(byte[])source.Clone();source[133]=5;source[135]=0;Put(source,144,UInt32.MaxValue);Put(source,148,UInt32.MaxValue);Put(source,324,(uint)Call(T("NpFirstSyncWire"),"Crc",source,324));caseReceipt=Call(T("NpFirstSyncWire"),"Parse",source);}
            string folder=Path.Combine(output,mode);Directory.CreateDirectory(folder);var binding=Call(T("NpImuGridWriter"),"PhaseBinding",caseUid,token,caseReceipt);
            var phase=New("NpImuGridPhaseRecord");foreach(string n in new[]{"Uid","Session","CaptureGeneration","SourceEpoch","CounterDomain","Token"})Set(phase,n,Get(binding,n));
            Set(phase,"FirstAcceptedSlot",3UL);Set(phase,"LowerNumerator",(long)sourceHz/1000);Set(phase,"UpperNumerator",(long)sourceHz/1000+10);Set(phase,"Denominator",1U);Set(phase,"MaximumJitter",10U);Set(phase,"Flags",3U);
            if(mode=="known_interval_unknown_jitter"||mode=="startup_only_no_point"){Set(phase,"Flags",1U);Set(phase,"MaximumJitter",UInt32.MaxValue);}
            var frame=New("NpImuGridBatch");Set(frame,"FirstSlot",3UL);Set(frame,"CaptureGeneration",9U);Set(frame,"SlotCount",(ushort)3);Set(frame,"ObservedMask",(ushort)5);Set(frame,"AgValid",(ushort)5);Set(frame,"MagValid",(ushort)5);Set(frame,"AgRepeat",(ushort)4);Set(frame,"MagRepeat",(ushort)4);Set(frame,"ErrorMask",(ushort)0);Set(frame,"Rows",new[]{new[]{1000000,-1000000,500000,10000,-10000,1000,300,-600,900},new[]{1000000,-1000000,500000,10000,-10000,1000,300,-600,900}});
            var writer=Activator.CreateInstance(T("NpImuGridWriter"),All,null,new object[]{folder,9U,mode!="not_enforced"},CultureInfo.InvariantCulture);
            // Synthetic fixture only. HIL supplies no first-source proof; actual runtime owns it.
            try{Call(writer,"Feed",(byte[])Call(T("NpImuGridWire"),"Pack",frame));Need((bool)Call(writer,"AcceptPhase",(byte[])Call(T("NpImuGridPhase"),"Pack",phase),binding,sourceHz,caseReceipt),"Fixture phase admission");Call(writer,"Complete",mode=="outside_source_window"?1000UL:100000UL,sourceHz,v2?0UL:780UL,true,true);}finally{((IDisposable)writer).Dispose();}
            File.WriteAllText(Path.Combine(folder,"imu_grid_status.txt"),"selected=true\ncarrier=NSG1\nenforced_schedule_verified=True\nfirst_slot_phase_valid=True\nerror=none\n");
            File.WriteAllText(Path.Combine(folder,"recording_settings.json"),"{\"imu_grid_selected\":true,\"imu_grid_control_version\":2,\"imu_grid_enforced_schedule\":true}");
            if(v2){File.WriteAllText(Path.Combine(folder,"recording_settings.json"),"{\"imu_grid_selected\":true,\"imu_grid_enforced_schedule_verified\":true}");File.WriteAllText(Path.Combine(folder,"imu_grid_status.txt"),"lab_only=False\nselected=true\ncarrier=NSG1\nanalog_owner=scheduled_grid\ncontrol_version="+(mode=="v2_legacy_control"?"1":"2")+"\nenforced_schedule_verified=True\nfirst_source_verified=True\nerror=none\n");}
            if(mode=="legacy_control_v1")File.WriteAllText(Path.Combine(folder,"recording_settings.json"),"{\"imu_grid_selected\":true,\"imu_grid_control_version\":1,\"imu_grid_enforced_schedule\":false}");
            if(mode=="bad_native_sentinel"){var b=File.ReadAllBytes(Path.Combine(folder,"analogin.dat"));b[3]=0;File.WriteAllBytes(Path.Combine(folder,"analogin.dat"),b);}
            if(mode=="first_source_unverified"){string p=Path.Combine(folder,"imu_grid_status.txt");File.WriteAllText(p,File.ReadAllText(p).Replace("first_slot_phase_valid=True","first_slot_phase_valid=False"));}
            if(mode=="first_slot_bounds_mismatch"||mode=="first_slot_scope_mismatch"){string p=Path.Combine(folder,"analogin_encoding.txt");string text=File.ReadAllText(p);if(mode=="first_slot_bounds_mismatch")text=text.Replace("first_slot_offset_lower_us=1000","first_slot_offset_lower_us=1001");if(mode=="first_slot_scope_mismatch")text=text.Replace("first_slot_phase_scope=start_only","first_slot_phase_scope=whole_record");File.WriteAllText(p,text);}
            if(mode=="missing_phase")File.Delete(Path.Combine(folder,"imu_grid_phase.bin"));
            if(mode=="wrong_token"||mode=="missing_jitter"||mode=="aux_counter"){if(mode=="wrong_token")Set(phase,"Token",124UL);if(mode=="missing_jitter"){Set(phase,"Flags",1U);Set(phase,"MaximumJitter",UInt32.MaxValue);}if(mode=="aux_counter")Set(phase,"FirstAcceptedSlot",4UL);File.WriteAllBytes(Path.Combine(folder,"imu_grid_phase.bin"),(byte[])Call(T("NpImuGridPhase"),"Pack",phase));}
            if(mode=="lost_first"){var v=File.ReadAllBytes(Path.Combine(folder,"analogin_validity.dat"));v[3]=0;File.WriteAllBytes(Path.Combine(folder,"analogin_validity.dat"),v);}
            if(mode=="bad_segments")File.AppendAllText(Path.Combine(folder,"imu_grid_segments.csv"),"0,1,0\n");
            var before=Directory.GetFiles(folder).ToDictionary(p=>p,Hash);var result=Assess(folder,caseReceipt,caseUid,token,null);
            var encoded=File.ReadAllBytes(Path.Combine(folder,"analogin.dat"));short[] expected={4096,-4096,2048,164,-164,16,1,-2,3};for(int a=0;a<9;a++)Need(BitConverter.ToInt16(encoded,3*32+2+a*2)==expected[a],"Actual compiled scaling mismatch");checks++;
            if(mode=="outside_source_window")Need(!(bool)result["source_window_verified"],"NP overlap invented beyond source end");
            bool good=mode=="valid"||mode=="terminal_unknown"||mode=="full_phase_no_point"||mode=="outside_source_window"||mode=="v2_valid"||mode=="v2_counter_only";Need((bool)result["np_relative_phase_qualified"]==good,"Offline phase verdict "+mode);checks++;
            bool firstGood=mode=="valid"||mode=="terminal_unknown"||mode=="missing_jitter"||mode=="known_interval_unknown_jitter"||mode=="startup_only_no_point"||mode=="full_phase_no_point"||mode=="legacy_control_v1"||mode=="not_enforced"||mode=="outside_source_window"||mode=="v2_valid"||mode=="v2_counter_only"||mode=="v2_legacy_control";
            Need((bool)result["first_slot_np_phase_qualified"]==firstGood&&!(bool)result["first_slot_rtc_phase_qualified"],"Start-only qualification leaked or hid measured interval: "+mode);checks++;
            Need(!(bool)result["rtc_phase_qualified"]&&!(bool)result["terminal_tail_qualified"]&&!(bool)result["sample0_lock"],"Invented RTC/tail/sample lock");checks++;
            Need(before.All(p=>Hash(p.Key)==p.Value)&&before.Count==Directory.GetFiles(folder).Length,"Offline replay changed source files");checks++;
        }
        Console.WriteLine("PASS "+checks+" actual200 enforced saved-grid/NSGP offline checks; no Form/device; prearm and active domains are independent");
    }
}





