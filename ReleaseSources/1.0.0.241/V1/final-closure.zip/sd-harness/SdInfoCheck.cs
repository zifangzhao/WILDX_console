using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Threading;
using System.Web.Script.Serialization;

static class SdInfoCheck {
 const BindingFlags All=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static;
 const string Uid="001D00065942500B20313354";
 static Assembly app;static void Need(bool ok,string why){if(!ok)throw new IOException(why);}
 static object Call(object o,string name,params object[] a){try{return (o as Type??o.GetType()).GetMethods(All).Single(m=>m.Name==name&&m.GetParameters().Length==a.Length).Invoke(o is Type?null:o,a);}catch(TargetInvocationException e){throw e.InnerException??e;}}
 static Type T(string n){return app.GetType(n.Contains(".")?n:"USB512_interface."+n,true);}
 static object Get(object o,string n){var f=o.GetType().GetField(n,All);return f!=null?f.GetValue(o):o.GetType().GetProperty(n,All).GetValue(o,null);}
 static Dictionary<string,object> Fields(object x){return x.GetType().GetFields(All).Where(f=>!f.IsStatic).ToDictionary(f=>f.Name,f=>f.GetValue(x));}
 static string Hash(string p){using(var f=File.OpenRead(p))using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(f)).Replace("-","");}
 static int Main(string[] a){
  if(a.Length!=3)return 2;string report=Path.GetFullPath(a[2]);var j=new JavaScriptSerializer {MaxJsonLength=8*1024*1024};var r=new Dictionary<string,object>();
  try{
   Need(Hash(a[0])=="BD0416D30E53946B65380D8F925AE002C277D9C835D22F6A59598D1675F26ECD","Exact checked240 host required");
   Need(report.StartsWith("C:\\Frank\\Code\\XE_NP\\_artifacts\\v1_gui_support_20261105\\bench\\",StringComparison.OrdinalIgnoreCase)&&!File.Exists(report),"Fresh private report required");
   foreach(string n in new[]{@"Local\WILDX_NP_TIMING_HIL",@"Local\XE_NP_V1_001D00065942500B20313354"})using(var m=Mutex.OpenExisting(n)){bool held=m.WaitOne(0);if(held)m.ReleaseMutex();Need(!held,"Hardware lease owner missing");}
   app=Assembly.LoadFrom(a[0]);string path=((IEnumerable)Call(T("CE32_console.NpDownloadNative"),"EnumerateNpPaths")).Cast<string>().Single(p=>String.Equals((string)Call(T("NpV1Management"),"UidFromPath",p),Uid,StringComparison.OrdinalIgnoreCase));
   r["before_path"]=path;object basic=Call(T("NpSystemInfo"),"Read",path,"NP V1");r["passive_before"]=Fields(basic);
   Need((uint)Get(basic,"DeviceCapabilities")==((uint)Get(basic,"DeviceCapabilities")|0x20000U)&&(bool)Get(basic,"DeviceIdle"),"New idle SDInfo capability required");
   object active=Call(T("NpSystemInfo"),"ReadCard",path,"NP V1");r["active"]=Fields(active);object sd=Get(active,"Sd");Need(sd!=null,"Active SDInfo absent");r["sd_fields"]=Fields(sd);
   Need((bool)Get(active,"CardRefreshed"),"GUI active refresh path not executed");
   Need(Convert.ToUInt32(Get(sd,"Sequence"))!=0,"SDInfo sequence echo absent");
   Need(Convert.ToUInt32(Get(sd,"State"))==2,"Detailed SDInfo refresh did not complete ready");
   Need((Convert.ToUInt32(Get(sd,"Flags"))&1)!=0,"Restored same-card CID/capacity not valid");
   path=((IEnumerable)Call(T("CE32_console.NpDownloadNative"),"EnumerateNpPaths")).Cast<string>().Single(p=>String.Equals((string)Call(T("NpV1Management"),"UidFromPath",p),Uid,StringComparison.OrdinalIgnoreCase));
   r["after_path"]=path;r["passive_after"]=Fields(Call(T("NpSystemInfo"),"Read",path,"NP V1"));
   r["result"]="PASS actual GUI ReadCard queued A6/polled A5 ready and retained cache; post-refresh bulk/capture checked separately";
   File.WriteAllText(report,j.Serialize(r));Console.WriteLine(j.Serialize(r));return 0;
  }catch(Exception ex){r["error"]=ex.ToString();File.WriteAllText(report,j.Serialize(r));Console.Error.WriteLine(ex);return 1;}
 }
}
