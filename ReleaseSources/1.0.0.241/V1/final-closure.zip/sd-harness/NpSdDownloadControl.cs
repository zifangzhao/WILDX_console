using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

// Derived from harness170/NpFirstSyncV1Hardware170.cs reflection/STA pattern.
// Only its sole hardware owner may invoke record-sd/verify-sd. Builder/self-test
// never construct a Form/connection or enumerate/contact any physical device.
static class NpSdDownloadControl {
    const BindingFlags All=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static;
    const int Family=1,Ports=2;const uint Mask=3;const string Uid="001D00065942500B20313354";
    const string HostHash="BD0416D30E53946B65380D8F925AE002C277D9C835D22F6A59598D1675F26ECD";
    const string SdkHash="EBC98EEB84FDE42DEE06B713F1F6246B30B3527732075D9F84C6DF57BCA69EFB";
    static readonly JavaScriptSerializer Json=new JavaScriptSerializer {MaxJsonLength=32*1024*1024};
    static readonly Dictionary<string,object> Report=new Dictionary<string,object>();static Assembly app;static string output;static int exit=1;
    static void Need(bool ok,string why){if(!ok)throw new InvalidDataException(why);}
    static Type T(string name){return app.GetType(name.Contains(".")?name:"USB512_interface."+name,true);}
    static object Get(object o,string name){var t=o.GetType();var f=t.GetField(name,All);return f!=null?f.GetValue(o):t.GetProperty(name,All).GetValue(o,null);}
    static void Set(object o,string name,object value){o.GetType().GetField(name,All).SetValue(o,value);}
    static uint U(object o,string name){return Convert.ToUInt32(Get(o,name),CultureInfo.InvariantCulture);}
    static ulong L(object o,string name){return Convert.ToUInt64(Get(o,name),CultureInfo.InvariantCulture);}
    static object Call(object o,string name,params object[] args){var t=o as Type??o.GetType();var m=t.GetMethods(All).Where(x=>x.Name==name&&x.GetParameters().Length==args.Length).ToArray();Need(m.Length==1,"Ambiguous/missing actual API "+name);try{return m[0].Invoke(o is Type?null:o,args);}catch(TargetInvocationException ex){throw ex.InnerException??ex;}}
    static object New(string name,params object[] args){return T(name).GetConstructors(All).Single(c=>!c.IsStatic&&c.GetParameters().Length==args.Length).Invoke(args);}
    static async Task<object> Await(object task){var t=(Task)task;await t;var p=t.GetType().GetProperty("Result");return p==null?null:p.GetValue(t,null);}
    static string Hex(byte[] b){return BitConverter.ToString(b).Replace("-","");}
    static string Hash(string path){if(!File.Exists(path))return null;using(var s=File.OpenRead(path))using(var h=SHA256.Create())return Hex(h.ComputeHash(s));}
    static Dictionary<string,object> Fields(object o){return o.GetType().GetFields(All).Where(f=>!f.IsStatic).ToDictionary(f=>f.Name,f=>f.GetValue(o));}
    static object Catalog(object c){return new {capacity=Get(c,"Capacity"),records=((IEnumerable)Get(c,"Records")).Cast<object>().Select(Fields).ToArray()};}
    static Dictionary<string,object> Read(string path){return Json.Deserialize<Dictionary<string,object>>(File.ReadAllText(path));}
    static void Save(){if(output!=null)File.WriteAllText(Path.Combine(output,"hil.json"),Json.Serialize(Report));}
    static void Log(string text){Console.Error.WriteLine(DateTime.UtcNow.ToString("O")+" "+text);if(output!=null)File.AppendAllText(Path.Combine(output,"events.jsonl"),Json.Serialize(new {utc=DateTime.UtcNow.ToString("O"),text})+Environment.NewLine);}
    static void Fresh(string path){string target=Path.GetFullPath(path);Need(target.StartsWith(Path.GetFullPath("C:/Frank/Code/XE_NP/_artifacts/v1_gui_support_20261105/bench")+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase),"Outputs must stay under sd_hil");Need(!Directory.Exists(target)&&!File.Exists(target),"Fresh output required");Directory.CreateDirectory(target);output=target;}
    static void Pin(string host){host=Path.GetFullPath(host);Need(Hash(host)==HostHash,"Exact240 host required");Need(Hash(Path.Combine(Path.GetDirectoryName(host),"NpV2SdDatExport.dll"))==SdkHash,"Exact240 SDK required");app=Assembly.LoadFrom(host);EnforcedGridCurrentEvidence.App=app;Need(app.GetName().Version==new Version(1,0,0,240),"Actual240 required");Report["host"]=host;Report["host_sha256"]=HostHash;Report["sdk_sha256"]=SdkHash;Report["uid"]=Uid;Report["family"]=1;Report["all_stream_alignment_verified"]=false;Report["no_delete_format_flash_performed"]=true;}
    static void CheckUid(string value){Need(String.Equals(value,Uid,StringComparison.OrdinalIgnoreCase),"Only exact locked UID "+Uid+" admitted");}
    static ulong Address(string value){ulong n=0;Need(value.Length==12&&UInt64.TryParse(value,NumberStyles.AllowHexSpecifier,CultureInfo.InvariantCulture,out n)&&n!=0,"Explicit12hex BLE address required");return n;}
    static string Settings(){var type=app.GetTypes().SingleOrDefault(t=>t.FullName.EndsWith(".Properties.Settings",StringComparison.Ordinal));if(type==null)return null;var s=(ApplicationSettingsBase)type.GetProperty("Default",All).GetValue(null,null);var d=new SortedDictionary<string,string>();foreach(SettingsProperty p in s.Properties)d[p.Name]=Convert.ToString(s[p.Name],CultureInfo.InvariantCulture);return Json.Serialize(d);}
    static string ClPath {get{return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"WILDX_console",Family==1?"closed_loop_v1.json":"closed_loop_v2.json");}}

    static int detectors;static bool prefStaged,prefExisted;static byte[] prefBefore;
    static ApplicationSettingsBase appPreferences;static Dictionary<string,object> appPreferencesBefore;
    static void SnapshotSettings(){
        var type=app.GetTypes().Single(t=>t.FullName.EndsWith(".Properties.Settings",StringComparison.Ordinal));
        appPreferences=(ApplicationSettingsBase)type.GetProperty("Default",All).GetValue(null,null);
        appPreferencesBefore=new Dictionary<string,object>();foreach(SettingsProperty p in appPreferences.Properties)appPreferencesBefore[p.Name]=appPreferences[p.Name];
    }
    static void RestoreSettings(){
        if(appPreferencesBefore==null)return;bool changed=false;
        foreach(var p in appPreferencesBefore)if(!Object.Equals(appPreferences[p.Key],p.Value)){appPreferences[p.Key]=p.Value;changed=true;}
        if(changed)appPreferences.Save();Report["application_preference_values_restored"]=true;
    }
    static void StageClosedLoop(){
        prefExisted=File.Exists(ClPath);prefBefore=prefExisted?File.ReadAllBytes(ClPath):null;
        if(prefExisted)File.WriteAllBytes(Path.Combine(output,"closed_loop_preference_before.bin"),prefBefore);
        prefStaged=true;object settings=New("NpClosedLoopSettings");
        Set(settings,"Enabled",detectors>0);Set(settings,"MayBeConfigured",true);
        Set(settings,"TrainingStartMs",0U);Set(settings,"TrainingDurationMs",1000U);
        Type channel=settings.GetType().GetField("Channels",All).FieldType.GetElementType();
        Array channels=Array.CreateInstance(channel,Math.Max(detectors,1));
        for(int n=0;n<channels.Length;n++){
            object value=Activator.CreateInstance(channel);Set(value,"Probe",(byte)(n+1));Set(value,"Channel",(ushort)0);
            Set(value,"Filter",(byte)6);Set(value,"Gain",2F);Set(value,"Rectify",true);channels.SetValue(value,n);
        }
        Set(settings,"Channels",channels);Call(settings,"Save",false);
        object loaded=Call(T("NpClosedLoopSettings"),"Load",false);
        Need((bool)Get(loaded,"Enabled")== (detectors>0)&&(bool)Get(loaded,"MayBeConfigured"),"Staged CL preference state differs");
        Array actual=(Array)Get(loaded,"Channels");Need(actual.Length==Math.Max(detectors,1),"Staged CL channel count differs");
        for(int n=0;n<actual.Length;n++)Need(U(actual.GetValue(n),"Probe")==n+1&&U(actual.GetValue(n),"Channel")==0&&
            U(actual.GetValue(n),"Filter")==6&&Convert.ToSingle(Get(actual.GetValue(n),"Gain"))==2F&&(bool)Get(actual.GetValue(n),"Rectify"),"Staged CL channel differs");
        Report["closed_loop_detectors"]=detectors;Report["closed_loop_preference_staged"]=true;
    }
    static void RestorePreference(){
        if(!prefStaged)return;
        if(prefExisted)File.WriteAllBytes(ClPath,prefBefore);else if(File.Exists(ClPath))File.Delete(ClPath);
        Need(File.Exists(ClPath)==prefExisted&&(!prefExisted||File.ReadAllBytes(ClPath).SequenceEqual(prefBefore)),"CL preference restore mismatch");
        Report["closed_loop_preference_restored"]=true;
    }
    static object captureResult;static bool prepared;
    static void Prepared(object status,byte[] request){
        Need(request!=null&&request.Length==64,"Actual prepared request missing");
        Set(captureResult,"CardCapacitySectors",U(status,"Capacity"));Set(captureResult,"StartLba",(long)U(status,"Start"));
        Set(captureResult,"StartRequestId",BitConverter.ToUInt32(request,12));Set(captureResult,"Session",BitConverter.ToUInt32(request,32));
        Set(captureResult,"RequestedEndLba",(long)BitConverter.ToUInt32(request,28));
        Report["actual_start_request_hex"]=Hex(request);Report["actual_prepared_status"]=Fields(status);prepared=true;
    }
    static object Selected(object form,uint mask,uint hz){
        var profiles=(ComboBox)Get(form,"profiles");return profiles.Items.Cast<object>().Single(p=>U(p,"Mask")==mask&&U(p,"Hz")==hz);
    }
    static async Task<object> Continuous(object form,object connection,int epoch,ulong peer,uint seconds,CancellationToken cancel){
        Need(!(bool)Get(form,"busy"),"Normal recording owner is already busy");Set(form,"busy",true);
        var result=New("NpSdTestResult");captureResult=result;prepared=false;bool stopSent=false;
        Set(result,"PathKind","logger");Set(result,"DeviceUid",Uid);Set(result,"LoggerVersion",Family);
        Set(result,"ProbeMask",Mask);Set(result,"SampleHz",15000U);
        Set(result,"Scope","Production continuous Start(0) then one normal Stop. Inputs are actual callback/status/catalog evidence; finite-target counts and physical bytes remain unknown until USB verification.");
        try{
            var start=T("NpBleForm").GetMethods(All).Single(m=>m.Name=="StartRecordingCore"&&m.GetParameters().Length==2);
            var callback=Delegate.CreateDelegate(start.GetParameters()[1].ParameterType,typeof(NpSdDownloadControl).GetMethod("Prepared",All));
            await Await(start.Invoke(form,new object[]{0U,callback}));Need(prepared,"Production continuous Start did not prepare a request");
            var setup=Get(form,"bleClosedLoopSetup");Need(setup!=null,"Production CL setup was not confirmed; neural Start alone does not qualify CL");
            var clRequest=(byte[])Get(setup,"Request");Need(clRequest!=null&&clRequest.Length==64&&BitConverter.ToUInt32(clRequest,32)==detectors,"Actual CL request detector count differs");
            Report["actual_closed_loop_setup"]=Fields(setup);
            var a=Get(form,"LastFirstSyncAttempt");Need(a!=null&&!(bool)Get(a,"OutcomeUnknown")&&!(bool)Get(a,"Rejected")&&
                U(a,"Id")==U(result,"StartRequestId")&&U(a,"Version")==3&&Get(a,"Acknowledgement")!=null&&U(Get(a,"Acknowledgement"),"RecordFeatures")==25,
                "Continuous Start is not independently confirmed as NPSDv3/record25; no replay");
            var startup=System.Diagnostics.Stopwatch.StartNew();System.Diagnostics.Stopwatch span=null;object status=null;
            while(true){
                Same(form,connection,epoch,peer);status=await Await(Call(form,"ReadStatus"));Same(form,connection,epoch,peer);
                Need(U(status,"Capacity")==U(result,"CardCapacitySectors")&&U(status,"Mask")==Mask&&U(status,"Hz")==15000,"Card/profile changed during owned continuous recording");
                Need(U(status,"Fault")==0&&U(status,"Error")==0,"Device reported a recording fault; no success invented");
                if(U(status,"State")==1U&&U(status,"Chunks")>0&&span==null)span=System.Diagnostics.Stopwatch.StartNew();
                if(span!=null&&U(status,"State")!=1U)throw new IOException("Continuous recording ended before explicit Stop");
                if(cancel.IsCancellationRequested||span!=null&&span.Elapsed.TotalSeconds>=seconds)break;
                Need(startup.Elapsed.TotalSeconds<seconds+120,"Continuous START/data confirmation timed out");
                await Task.Delay(500);
            }
            Same(form,connection,epoch,peer);stopSent=true;await Await(Call(form,"StopRecording"));
            status=await Await(Call(form,"ReadStatus"));Same(form,connection,epoch,peer);
            Need((bool)Call(form,"StopConfirmed",status)&&!(bool)Get(status,"Busy")&&U(status,"State")==3U&&U(status,"Fault")==0&&U(status,"Error")==0&&U(status,"Chunks")>0,"Normal Stop is not confirmed complete/idle");
            Need(!cancel.IsCancellationRequested&&span!=null&&span.Elapsed.TotalSeconds>=seconds,"Cancelled or insufficient continuous span; not passed");
            var catalog=await Await(Call(form,"ReadSdTestCatalog"));
            var record=((IEnumerable)Get(catalog,"Records")).Cast<object>().Single(r=>U(r,"Start")==L(result,"StartLba"));
            Need(U(record,"End")>U(record,"Start")&&(U(record,"Session")==0||U(record,"Session")==U(result,"Session")),"Catalog does not bind the actual new session");
            Set(result,"EndLba",(long)U(record,"End"));Set(result,"Chunks",U(status,"Chunks"));
            Set(result,"RecordingSeconds",Convert.ToDouble(Call(T("CE32_console.NpV1BleProtocol"),"RecordedSeconds",status),CultureInfo.InvariantCulture));
            Set(result,"RecordingCompleted",true);Set(result,"Status","Continuous recording normally stopped; USB stored-data verification required");
            Report["continuous_requested_seconds"]=seconds;Report["continuous_observed_wall_seconds"]=span.Elapsed.TotalSeconds;
            Report["normal_stop_request_id"]=U(status,"LastId");Report["normal_stop_status"]=Fields(status);Report["actual_catalog_record"]=Fields(record);
            Report["unknown_verification_inputs"]=new[]{"ExpectedChunks (no finite target)","RequestedBlocks (V1 continuous)","RequestedBytes/WrittenBytes (not inferred physical extent)","loss/source-gap/overflow counters until actual USB verification"};
            return result;
        }finally{
            if(prepared&&!stopSent&&(bool)Get(connection,"Connected")&&Convert.ToInt32(Get(connection,"Epoch"))==epoch){
                try{stopSent=true;await Await(Call(form,"StopRecording"));Report["cleanup_normal_stop_sent_once"]=true;}
                catch(Exception ex){Report["cleanup_stop_error"]=ex.ToString();}
            }
            captureResult=null;Set(form,"busy",false);
        }
    }
    static async Task RestoreProfile(object form,object connection,int epoch,ulong peer,uint mask,uint hz){
        Same(form,connection,epoch,peer);var status=await Await(Call(form,"ReadStatus"));
        Need(!(bool)Get(status,"Busy")&&(bool)Call(form,"StopConfirmed",status),"Profile restore deferred: recording not confirmed stopped");
        if(U(status,"Mask")!=mask||U(status,"Hz")!=hz){
            ((ComboBox)Get(form,"profiles")).SelectedItem=Selected(form,mask,hz);Set(form,"busy",true);
            try{await Await(Call(form,"Apply"));}finally{Set(form,"busy",false);}
            status=await Await(Call(form,"ReadStatus"));Same(form,connection,epoch,peer);
        }
        Need(U(status,"Mask")==mask&&U(status,"Hz")==hz,"Original recording profile not restored");
        Report["original_profile_restored"]=true;Report["restored_profile_status"]=Fields(status);
    }
    static object Attempt(object form){var a=Get(form,"LastFirstSyncAttempt");return a==null?null:new {uid=Get(a,"Uid"),family=Get(a,"Family"),token_hex=L(a,"Token").ToString("X16"),id=U(a,"Id"),connection_epoch=Get(a,"ConnectionEpoch"),version=Get(a,"Version"),request_hex=Hex((byte[])Get(a,"Request")),acknowledgement_hex=Get(a,"AcknowledgementRaw")==null?null:Hex((byte[])Get(a,"AcknowledgementRaw")),outcome_unknown=Get(a,"OutcomeUnknown"),rejected=Get(a,"Rejected"),evidence_path=Get(a,"EvidencePath")};}
    static void Same(object form,object connection,int epoch,ulong peer){Need((bool)Get(connection,"Connected")&&Convert.ToInt32(Get(connection,"Epoch"))==epoch&&(ulong)Get(form,"connectedAddress")==peer&&(string)Get(form,"bleDeviceUid")==Uid,"Original UID/peer/connection changed; no replay or handoff");}
    static uint Seconds(string text){uint seconds;Need(UInt32.TryParse(text,out seconds)&&seconds==30,"Only the explicit bounded30-second candidate test is admitted");return seconds;}
    static object WriteEvidence(Dictionary<string,object> row,string token){
        object value;if(!row.TryGetValue("event",out value)||Convert.ToString(value)!="exchange_finished"||!row.TryGetValue("request_hex",out value)||!Convert.ToString(value).StartsWith("4E505446",StringComparison.Ordinal))return null;
        if(!row.TryGetValue("context",out value)||value==null)return null;var context=Json.ConvertToType<Dictionary<string,object>>(value);
        if(Convert.ToString(context["device_uid"])!=Uid||Convert.ToInt32(context["device_family"])!=Family||Convert.ToString(context["sd_record_token_hex"])!=token)return null;
        if(!row.TryGetValue("transport_boundaries",out value)||value==null)return null;var boundaries=Json.ConvertToType<Dictionary<string,object>>(value);
        var writes=Json.ConvertToType<Dictionary<string,object>[]>(boundaries["write_fragments"]);
        int[] sizes=writes.Select(w=>Convert.ToInt32(w["bytes"])).ToArray(),offsets=writes.Select(w=>Convert.ToInt32(w["offset"])).ToArray();
        string delivery=sizes.SequenceEqual(new[]{67})&&offsets.SequenceEqual(new[]{0})?"whole_67":sizes.SequenceEqual(new[]{20,20,20,7})&&offsets.SequenceEqual(new[]{0,20,40,60})?"fragments_20_20_20_7":"partial_or_other";
        return new {request_id=row["request_id"],outcome=row["outcome"],delivery,write_fragments=writes,
            gatt_write_option=delivery=="whole_67"?"WriteWithResponse_by_pinned-next_policy":null,
            max_pdu=(int?)null,scope="Actual per-exchange journal boundaries; fragmented write option and negotiated MaxPdu are not recorded and are not inferred"};
    }
    static void SummarizeWrites(string folder,string token){
        try{
            if(folder==null||token==null||!Directory.Exists(folder))return;
            var files=new List<object>();var rows=new List<object>();
            foreach(string file in Directory.GetFiles(folder,"ble_clock_*.jsonl",SearchOption.TopDirectoryOnly)){
                files.Add(new {path=file,sha256=Hash(file)});
                foreach(string line in File.ReadLines(file)){if(String.IsNullOrWhiteSpace(line))continue;var evidence=WriteEvidence(Json.Deserialize<Dictionary<string,object>>(line),token);if(evidence!=null)rows.Add(evidence);}
            }
            var summary=new {uid=Uid,family=Family,sd_record_token_hex=token,files,exchanges=rows,scope="Read-only summary of exact bound NPTF requests; no additional device calls"};
            Report["fine_write_evidence"]=summary;File.WriteAllText(Path.Combine(output,"fine-write-summary.json"),Json.Serialize(summary));
        }catch(Exception ex){Report["fine_write_evidence_error"]=ex.Message;}
    }
    // Fixed balanced cycle; explicit lab experiment, never an automatic policy.
    // No active clock hold experiment: actual production TestSdRecording owns all commands.

    static async Task Record(string address,uint seconds){
        SnapshotSettings();string settings=Settings();object form=null,connection=null;bool connected=false,haveProfile=false;
        int epoch=0;ulong peer=Address(address);uint originalMask=0,originalHz=0;
        var cancel=new CancellationTokenSource(TimeSpan.FromSeconds(seconds+240));
        ConsoleCancelEventHandler interrupt=(s,e)=>{e.Cancel=true;cancel.Cancel();};Console.CancelKeyPress+=interrupt;
        try{
            AcceptanceCurrentPins.Current.RequireMainLeases();
            Report["verified_mapping"]=AcceptanceCurrentPins.Current.RequireMapping(address);
            StageClosedLoop();form=New("NpBleForm",false);Need(!((Form)form).IsHandleCreated,"Form must remain hidden");
            ((CheckBox)Get(form,"poll")).Checked=false;((System.Windows.Forms.Timer)Get(form,"timer")).Stop();
            ((System.Windows.Forms.Timer)Get(form,"bleImuTimer")).Stop();Need(Get(form,"preview")==null,"Preview must remain off");
            Set(form,"ChooseBleSessionFolder",new Func<string>(()=>Path.Combine(output,"ble-metadata")));
            ((TextBox)Get(form,"bleDestinationFolder")).Text=Path.Combine(output,"ble-metadata");
            ((TextBox)Get(form,"address")).Text=address;Set(form,"busy",true);
            try{await Await(Call(form,"Connect"));}finally{Set(form,"busy",false);}
            connection=Get(form,"connection");connected=(bool)Get(connection,"Connected");Need(connected,"Production Connect did not establish a link");
            epoch=Convert.ToInt32(Get(connection,"Epoch"));var initial=await Await(Call(form,"ReadStatus"));
            Need(Convert.ToInt32(Get(form,"recorderVersion"))==1&&String.Equals((string)Get(form,"bleDeviceUid"),Uid,StringComparison.OrdinalIgnoreCase),"Connected peer UID/family mismatch; no Start");
            Same(form,connection,epoch,peer);Report["initial_status"]=Fields(initial);Report["actual_connection_parameters"]=Call(connection,"ReadConnectionParametersEvidence");
            AcceptanceCurrentPins.Current.RequireWireIdentity(Get(form,"firmwareIdentity"),Uid,1,false);
            Need(!(bool)Get(initial,"Busy")&&U(initial,"Fault")==0&&U(initial,"Error")==0,"Idle fault-free V1 required");
            originalMask=U(initial,"Mask");originalHz=U(initial,"Hz");haveProfile=true;
            var before=await Await(Call(form,"ReadSdTestCatalog"));Report["catalog_before"]=Catalog(before);
            var client=Get(form,"bleFirstSyncClient");Need(client!=null&&(U(client,"FineCounter64SupportedFeatures")&29U)==29U&&(bool)Get(form,"bleRtcSupported"),"Actual Connect did not confirm current continuous64/RTC capabilities");
            ((ComboBox)Get(form,"profiles")).SelectedItem=Selected(form,Mask,15000U);
            if(originalMask!=Mask||originalHz!=15000U){Set(form,"busy",true);try{await Await(Call(form,"Apply"));}finally{Set(form,"busy",false);}}
            var selectedStatus=await Await(Call(form,"ReadStatus"));Same(form,connection,epoch,peer);
            Need(U(selectedStatus,"Mask")==Mask&&U(selectedStatus,"Hz")==15000U&&U(selectedStatus,"Capacity")==U(initial,"Capacity"),"Requested profile/card not confirmed before Start");
            Call(Get(form,"acknowledgedSdProfiles"),"Add",Tuple.Create(Mask,15000U,U(selectedStatus,"Capacity")));
            AcceptanceCurrentPins.Current.RequireMainLeases();
            var recorded=await Continuous(form,connection,epoch,peer,seconds,cancel.Token);
            Report["recording_result"]=Fields(recorded);File.WriteAllText(Path.Combine(output,"recording-result.json"),Json.Serialize(Fields(recorded)));
            Report["start_attempt"]=Attempt(form);Report["capture_completed_idle"]=true;Report["owned_session_kept"]=true;
            var after=await Await(Call(form,"ReadSdTestCatalog"));Report["catalog_after"]=Catalog(after);
            var prior=((IEnumerable)Get(before,"Records")).Cast<object>().ToArray();var next=((IEnumerable)Get(after,"Records")).Cast<object>().ToArray();
            Need(U(before,"Capacity")==U(after,"Capacity")&&next.Length==prior.Length+1&&prior.Select((r,n)=>U(r,"Start")==U(next[n],"Start")&&U(r,"End")==U(next[n],"End")).All(x=>x),"Prior recording extents changed or append is ambiguous");
            Report["catalog_preserved"]=true;Report["ble_metadata_folder"]=Get(form,"bleMetadataFolder");
            Report["helper_active_clock_queries"]=0;Report["handover_deferred"]=true;Report["download_mode_requested_once"]=false;
            Report["result"]="PASS continuous30s and normal Stop/catalog append confirmed; saved-data/CL/grid integrity still requires USB verification";
        }finally{
            if(form!=null&&connection!=null){
                try{if(haveProfile)await RestoreProfile(form,connection,epoch,peer,originalMask,originalHz);}catch(Exception ex){Report["profile_restore_error"]=ex.ToString();}
                try{await Await(Call(connection,"RetireRecordingClock"));}catch(Exception ex){Report["clock_retirement_error"]=ex.ToString();}
                Report["start_attempt"]=Attempt(form);Report["gui_log"]=((TextBox)Get(form,"log")).Text;
            }
            try{if(connected)Call(connection,"Disconnect");}finally{
                try{if(form!=null)((IDisposable)form).Dispose();}finally{
                    try{RestorePreference();}finally{try{RestoreSettings();}finally{Console.CancelKeyPress-=interrupt;cancel.Dispose();}}
                }
            }
            Report["persistent_preferences_unchanged"]=settings==Settings();Save();
            Need((bool)Report["persistent_preferences_unchanged"]&&(!haveProfile||Report.ContainsKey("original_profile_restored")),"Preferences or original profile restoration not confirmed");
        }
    }
    // File-only assessment of actual exported physical observations. Raw
    // hashes/extents preserve evidence; timing/CRC qualification is separate.
    static Dictionary<string,object> PhysicalImu(string folder){
        var errors=new List<string>();var archives=new List<object>();long rawRecords=0,csvRows=0,validAg=0,advances=0,resets=0;bool haveSequence=false;uint previous=0;
        // V1 fine stamps are a sparse sidecar to the 164B physical core, not
        // additional observations. Fine coverage/framing is assessed separately.
        var specs=Family==1?new[]{Tuple.Create("sensors.bin",164,true),Tuple.Create("sensors_fine.bin",32,false)}:
            new[]{Tuple.Create("imu_sd_records.sns2",132,true),Tuple.Create("imu_sd_fine_records.bin",144,true)};
        foreach(var spec in specs){
            string path=Path.Combine(folder,spec.Item1);bool exists=File.Exists(path);long length=0;string hash=null,error=null;bool framed=false;
            if(exists)try{length=new FileInfo(path).Length;hash=Hash(path);framed=length%spec.Item2==0;if(!framed)error=spec.Item1+" has a partial raw record";else if(spec.Item3)rawRecords+=length/spec.Item2;}
                catch(Exception ex){error=spec.Item1+": "+ex.Message;}
            if(error!=null&&spec.Item3)errors.Add(error);
            archives.Add(new {file=spec.Item1,exists,bytes=length,sha256=hash,record_bytes=spec.Item2,records=framed?(long?)(length/spec.Item2):null,extent_valid=framed,counts_as_physical_snapshot=spec.Item3,optional=!spec.Item3,error});
        }
        string csv=Path.Combine(folder,"sensors.csv"),csvHash=null;
        try{
            csvHash=Hash(csv);using(var input=new StreamReader(csv)){
                string header=input.ReadLine();Need(!String.IsNullOrWhiteSpace(header),"Sensor CSV header is absent");string[] names=header.Split(',');int valid=Array.IndexOf(names,"valid"),seq=Array.IndexOf(names,"imu_sequence");
                Need(valid>=0&&seq>=0,"Sensor CSV valid/imu_sequence columns are absent");string line;
                while((line=input.ReadLine())!=null){if(String.IsNullOrWhiteSpace(line))continue;csvRows++;string[] cells=line.Split(',');uint bits=0,n=0;
                    Need(cells.Length==names.Length&&UInt32.TryParse(cells[valid],NumberStyles.Integer,CultureInfo.InvariantCulture,out bits)&&(bits&~7U)==0&&UInt32.TryParse(cells[seq],NumberStyles.Integer,CultureInfo.InvariantCulture,out n),"Malformed sensor CSV row "+csvRows);
                    if((bits&1U)==0)continue;Need(n!=0,"Valid AG row has no native sequence");validAg++;
                    if(haveSequence){uint delta=unchecked(n-previous);if(delta!=0&&delta<0x80000000U)advances++;else if(delta>=0x80000000U)resets++;}
                    haveSequence=true;previous=n;
                }
            }
        }catch(Exception ex){errors.Add(ex.Message);}
        if(rawRecords==0)errors.Add("No complete native IMU raw records");
        if(csvRows>rawRecords)errors.Add("Physical CSV rows exceed retained raw records");
        if(validAg<2||advances==0)errors.Add("No advancing valid AG observations");
        return new Dictionary<string,object>{{"passed",errors.Count==0},{"csv_file","sensors.csv"},{"csv_sha256",csvHash},{"csv_rows",csvRows},
            {"valid_ag_snapshots",validAg},{"advancing_imu_sequences",advances},{"sequence_reset_segments",resets},{"raw_records",rawRecords},{"archives",archives.ToArray()},
            {"errors",errors.ToArray()},{"fine_timing_assessed",false},{"utc_assessed",false},{"native_conversion_phase_locked",false},
            {"scope","Streamed actual-export CSV validity/advancing sequence plus original raw archive hashes/extents. Physical decoding belongs to production export; no independent raw CRC, fine-coordinate, UTC or native-conversion qualification is claimed."}};
    }
    static object ClosedDat(string folder){
        var numbers=new Dictionary<string,long>();foreach(string line in File.ReadLines(Path.Combine(folder,"capture_status.txt"))){int p=line.IndexOf('=');long n;if(p>0&&Int64.TryParse(line.Substring(p+1),NumberStyles.Integer,CultureInfo.InvariantCulture,out n))numbers.Add(line.Substring(0,p),n);}
        var files=new List<object>();foreach(int probe in new[]{1,2})foreach(string band in new[]{"ap","lfp"}){
            string prefix="np"+probe+"_"+band;long rows;Need(numbers.TryGetValue(prefix+"_rows",out rows)&&rows>0,"Missing actual decoded rows: "+prefix);
            string path=Path.Combine(folder,prefix+".dat");using(var stream=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.None)){
                Need(stream.Length==checked(rows*768),"Closed DAT length disagrees with actual decoded rows: "+prefix);files.Add(new {file=Path.GetFileName(path),rows,channels=384,bytes=stream.Length,closed=true,payload_rescanned=false});
            }
        }return files;
    }
    static bool LocalRtc(string folder,object record,ulong token){
        Report["rtc_local_sub_ms_verified"]=false;Report["timing_context_verified"]=false;
        try{
            byte[] clock=File.ReadAllBytes(Path.Combine(folder,"recorded_clock.bin")),fine=File.ReadAllBytes(Path.Combine(folder,"first_source_clock_sector6.bin")),raw=File.ReadAllBytes(Path.Combine(folder,"device_rtc_start_sector7.bin"));
            var companion=Call(T("NpFineClockWire"),"ReadCompanion",fine,clock,Family,U(record,"Session"),15000U,Uid,token);
            Need(companion!=null&&(bool)Get(companion,"FineCounter64"),"Strict on-card+5/+6 continuous64 binding is unavailable");var receipt=Get(Get(companion,"Bound"),"Receipt");
            Need((U(receipt,"Flags")&35)==35&&U(receipt,"Family")==Family&&U(receipt,"Mask")==Mask&&U(receipt,"ApHz")==15000&&U(receipt,"Reference")==1,"Final/all-port/source-clock STARTBYTE proof missing");
            var binding=Call(T("NpRtcStartWire"),"BindSd",clock,fine,Family,U(record,"Session"),15000U,Uid,token);
            var stamp=Call(T("NpRtcStartWire"),"ParseSector",raw,binding);var bounds=Call(T("NpRtcStartWire"),"Map",raw.Take(128).ToArray(),binding);
            Report["rtc_raw_replay"]=new {clock_sha256=Hash(Path.Combine(folder,"recorded_clock.bin")),fine_sha256=Hash(Path.Combine(folder,"first_source_clock_sector6.bin")),rtc_sha256=Hash(Path.Combine(folder,"device_rtc_start_sector7.bin")),receipt=Fields(receipt),stamp=Fields(stamp),bounds=Fields(bounds),qualified=Get(bounds,"Qualified"),full_width_us=Get(bounds,"WidthUs"),pc_uncertainty_included_in_local_interval=false,native_conversion_phase_locked=false};
            Need((bool)Get(bounds,"Qualified")&&Convert.ToDecimal(Get(bounds,"WidthUs"))<1000,"Device hardware RTC-to-first-NP local interval is unavailable or >=1000us");
            var canonical=Read(Path.Combine(folder,"recording_start_utc.json"));Report["canonical"]=canonical;
            Need((bool)canonical["np_start_byte_sync_confirmed"]&&Convert.ToString(canonical["device_identity"])==Uid&&Convert.ToUInt32(canonical["session_id"])==U(record,"Session")&&Convert.ToUInt32(canonical["capture_generation"])==U(receipt,"Generation")&&Convert.ToUInt32(canonical["source_epoch"])==U(receipt,"SourceEpoch")&&Convert.ToUInt32(canonical["counter_domain"])==U(receipt,"Domain")&&Convert.ToUInt32(canonical["counter_hz"])==U(receipt,"CounterHz")&&Convert.ToUInt64(canonical["reference_source_tick"])==L(receipt,"ReferenceTick")&&Convert.ToUInt32(canonical["reference_probe"])==1,"Canonical STARTBYTE binding mismatch");
            Need(Convert.ToString(canonical["clock_reference"])=="device_hardware_rtc"&&(bool)canonical["utc_valid"]&&(bool)canonical["rtc_local_mapping_qualified"]&&(bool)canonical["local_sub_ms_verified"]&&Convert.ToDecimal(canonical["local_interval_width_us"])==Convert.ToDecimal(Get(bounds,"WidthUs"))&&Convert.ToDecimal(canonical["utc_lower_us"])==Convert.ToDecimal(Get(bounds,"LowerUs"))&&Convert.ToDecimal(canonical["utc_upper_us"])==Convert.ToDecimal(Get(bounds,"UpperUs")),"Canonical RTC bounds differ from independent raw replay");
            var pc=Json.ConvertToType<Dictionary<string,object>>(canonical["pc_epoch_calibration"]);Need(!(bool)pc["included_in_local_interval"],"PC calibration uncertainty was unioned with the device-local interval");
            Need(canonical["native_imu_conversion_phase_locked"]==null&&!Convert.ToBoolean(canonical["hardware_start_locked"]),"Physical conversion phase must remain unknown/unlocked");
            Report["pc_epoch_calibration"]=pc;Report["rtc_local_sub_ms_verified"]=true;Report["timing_context_verified"]=true;return true;
        }catch(Exception ex){Report["timing_error"]=ex.ToString();return false;}
    }

    static void BindObservedReadback(string path,object record){
        using(var card=(IDisposable)New("CE32_console.NpDownloadStream",path,false)){
            long start=Convert.ToInt64(Get(record,"StartLba"),CultureInfo.InvariantCulture);
            byte[] header=(byte[])Call(T("CE32_console.NpDownloadCatalog"),"Sector",card,start+3);
            byte[] footer=(byte[])Call(T("CE32_console.NpDownloadCatalog"),"Sector",card,start+4);
            foreach(byte[] b in new[]{header,footer})Need(b.Length==512&&BitConverter.ToUInt32(b,508)==(uint)Call(T("CE32_console.NpSdControl"),"Crc",b,508),"Actual descriptor CRC failed");
            uint chunks=BitConverter.ToUInt32(footer,68);
            Need(chunks!=0&&chunks==U(record,"Chunks")&&BitConverter.ToUInt32(footer,60)==3U&&BitConverter.ToUInt32(footer,64)==0U,"Actual footer does not match confirmed stopped chunks/state");
            Need(BitConverter.ToUInt32(header,44)==L(record,"RequestedEndLba")&&BitConverter.ToUInt32(footer,44)==L(record,"RequestedEndLba"),"Actual descriptors do not match prepared request bound");
            Set(record,"ExpectedChunks",chunks); // observed independent stored/status agreement, NOT a finite target
            File.WriteAllBytes(Path.Combine(output,"observed_descriptor.bin"),header);File.WriteAllBytes(Path.Combine(output,"observed_footer.bin"),footer);
            Report["expected_chunks_scope"]="Observed complete footer count matched to earlier stopped-status Chunks; not an ex-ante finite target or duration proof";
            Report["observed_expected_chunks"]=chunks;
        }
    }
    static void Verify(string priorFolder){
        var prior=Read(Path.Combine(priorFolder,"hil.json"));Need((string)prior["host_sha256"]==HostHash&&Convert.ToInt32(prior["family"])==Family&&(string)prior["uid"]==Uid&&(bool)prior["capture_completed_idle"],"Exact matched completed idle capture proof required");
        var attempt=Json.ConvertToType<Dictionary<string,object>>(prior["start_attempt"]);Need(!(bool)attempt["outcome_unknown"]&&!(bool)attempt["rejected"]&&(string)attempt["uid"]==Uid,"Start context unconfirmed");ulong token=UInt64.Parse((string)attempt["token_hex"],NumberStyles.AllowHexSpecifier,CultureInfo.InvariantCulture);Need(token!=0,"Owned Start token is absent");
        var values=Read(Path.Combine(priorFolder,"recording-result.json"));var record=New("NpSdTestResult");foreach(var f in record.GetType().GetFields(BindingFlags.Public|BindingFlags.Instance)){object v;if(values.TryGetValue(f.Name,out v)&&v!=null)f.SetValue(record,Json.ConvertToType(v,f.FieldType));}
        Need((bool)Get(record,"RecordingCompleted")&&(string)Get(record,"DeviceUid")==Uid&&U(record,"LoggerVersion")==Family&&U(record,"ProbeMask")==Mask&&U(record,"SampleHz")==15000&&U(record,"Session")!=0,"Owned test result mismatch");
        string path=((IEnumerable)Call(T("CE32_console.NpDownloadNative"),"EnumerateNpPaths")).Cast<string>().Single(p=>String.Equals((string)Call(T("NpV1Management"),"UidFromPath",p),Uid,StringComparison.OrdinalIgnoreCase));
        Report["selected_usb_path"]=path;Report["capture_completed_idle"]=true;Report["owned_session_kept"]=true;
        object target=((IEnumerable)Call(T("NpV1Management"),"Enumerate")).Cast<object>().Single(p=>String.Equals((string)Get(p,"Uid"),Uid,StringComparison.OrdinalIgnoreCase));
        using(var manager=(IDisposable)New("NpV1Management",target)){var mode=Call(manager,"ReadStatus");Report["native_mode_guard"]=Fields(mode);Need(U(mode,"Role")==3&&U(mode,"Busy")==0&&U(mode,"PendingMode")==0,"Owner must hand off exact UID to idle download personality before readback; no automatic mode switch");}
        BindObservedReadback(path,record);
        string export=Path.Combine(output,"export");using(var cancel=new CancellationTokenSource(TimeSpan.FromSeconds(180))){
            ConsoleCancelEventHandler stop=(s,e)=>{e.Cancel=true;cancel.Cancel();};Console.CancelKeyPress+=stop;
            try{Report["readback_cancellation_budget_seconds"]=180;Call(T("NpSdLoggerTest"),"Verify",path,record,export,cancel.Token,new Action<int,string>((p,s)=>Log(p+"% "+s)));}
            finally{Console.CancelKeyPress-=stop;}
        }
        Report["stored_neural_continuity_verified"]=true;Report["np_success"]=true;Report["verified_result"]=Fields(record);Report["closed_dat_extents"]=ClosedDat(export);Save();
        var physical=PhysicalImu(export);Report["imu_evidence"]=physical;Report["physical_imu_verified"]=(bool)physical["passed"];File.WriteAllText(Path.Combine(output,"physical-imu-check.json"),Json.Serialize(physical));
        var grid=EnforcedGridCurrentEvidence.Sd(export,Uid,token,U(record,"Session"));Report["imu_grid_evidence"]=grid;Report["imu_data_success"]=grid["imu_data_success"];Report["imu_phase_qualified"]=grid["rtc_phase_qualified"];File.WriteAllText(Path.Combine(output,"imu-grid-independent-check.json"),Json.Serialize(grid));
        bool rtc=LocalRtc(export,record,token),loss=(bool)Get(record,"LossCountersAvailable");Report["loss_counters_available"]=loss;
        Report["acceptance_passed"]=rtc&&loss&&(bool)physical["passed"]&&(bool)grid["feature_acceptance_passed"];Report["all_stream_alignment_verified"]=false;
        Report["result"]=(bool)Report["acceptance_passed"]?"PASS stored NP framing/loss counters/closed AP+LFP, native and indexed IMU, strict device RTC-to-NP <1ms; retained observed enforced lattice qualified; source overlap and terminal tail are separate":"Stored NN retained; combined acceptance not passed (RTC/loss/IMU details are separate)";Save();
        Need((bool)Report["acceptance_passed"],"Combined acceptance did not pass; do not erase/repair/replay the retained recording");
    }

    static object mappingConnection;
    static async Task<byte[]> MappingExchange(byte command,byte[] request,CancellationToken cancel){return (byte[])await Await(Call(mappingConnection,"ExchangeAsync",command,request,cancel));}
    static async Task MapBle(string address){
        Need(address=="F6D598CA53BA","Only the previously human-mapped V1 radio is admitted");
        AcceptanceCurrentPins.Current.RequireMainLeases();mappingConnection=New("NpBleConnection");
        try{
            await Await(Call(mappingConnection,"ConnectAsync",Address(address)));
            int epoch=Convert.ToInt32(Get(mappingConnection,"Epoch"));
            uint id=4000;var identity=await Await(Call(T("NpBleConnection"),"ReadDevice",
                new Func<byte,byte[],CancellationToken,Task<byte[]>>(MappingExchange),new Func<uint>(()=>++id)));
            Need(Convert.ToInt32(Get(identity,"Item1"))==1,"Radio reports another hardware family");
            Need((bool)Get(mappingConnection,"Connected")&&Convert.ToInt32(Get(mappingConnection,"Epoch"))==epoch,"Mapping connection changed");
            byte[] request=(byte[])Call(T("NpProbePreparation"),"Request",0U,++id,0U,0U,0U,0U);
            byte[] reply;using(var timeout=new CancellationTokenSource(5000))reply=await MappingExchange(0xb8,request,timeout.Token);
            var receipt=Call(T("NpProbePreparation"),"Parse",reply,request);
            Need(String.Equals((string)Get(receipt,"Uid"),Uid,StringComparison.OrdinalIgnoreCase),"Radio/MCU UID mismatch");
            Need(U(receipt,"Result")<=1U,"Read-only preparation identity was rejected");
            Need((bool)Get(mappingConnection,"Connected")&&Convert.ToInt32(Get(mappingConnection,"Epoch"))==epoch,"Mapping connection changed");
            AcceptanceCurrentPins.Current.RequireMainLeases();
            File.WriteAllBytes(Path.Combine(output,"identity_request.bin"),request);File.WriteAllBytes(Path.Combine(output,"identity_reply.bin"),reply);
            var mapping=new Dictionary<string,object>{{"verified",true},{"verified_utc",DateTime.UtcNow.ToString("O")},{"uid",Uid},{"family",1},
                {"ble_address",address},{"device_lease",AcceptanceCurrentPins.Current.Lease},{"global_lease",@"Local\WILDX_NP_TIMING_HIL"},
                {"read_only",true},{"status",Fields(Get(identity,"Item2"))},{"identity_receipt",Fields(receipt)}};
            File.WriteAllText(Path.Combine(output,"mapping.json"),Json.Serialize(mapping));Report["mapping"]=mapping;
        }finally{if(mappingConnection!=null){Call(mappingConnection,"Disconnect");((IDisposable)mappingConnection).Dispose();mappingConnection=null;}}
    }

    static void DownloadArguments(string[] args){
        Need(args.Length==5&&args[0]=="download-mode","Only download-mode <exact240.exe> <UID> <BLE12hex> <fresh-output> is admitted");
        CheckUid(args[2]);Address(args[3]);Need(!String.IsNullOrWhiteSpace(args[4]),"Fresh output required");
    }
    static async Task DownloadMode(string address){
        SnapshotSettings();string settings=Settings();object form=null,connection=null;
        string clBefore=File.Exists(ClPath)?Hash(ClPath):null;int epoch=0;ulong peer=Address(address);
        Report["start_sent"]=false;Report["stop_sent"]=false;Report["profile_apply_sent"]=false;
        Report["format_delete_sent"]=false;Report["download_mode_requested_once"]=false;
        try{
            AcceptanceCurrentPins.Current.RequireMainLeases();
            Report["verified_mapping"]=AcceptanceCurrentPins.Current.RequireMapping(address);
            form=New("NpBleForm",false);Need(!((Form)form).IsHandleCreated,"Form must remain hidden");
            ((CheckBox)Get(form,"poll")).Checked=false;((System.Windows.Forms.Timer)Get(form,"timer")).Stop();
            ((System.Windows.Forms.Timer)Get(form,"bleImuTimer")).Stop();Need(Get(form,"preview")==null,"Preview must remain off");
            Set(form,"ChooseBleSessionFolder",new Func<string>(()=>Path.Combine(output,"ble-metadata")));
            ((TextBox)Get(form,"bleDestinationFolder")).Text=Path.Combine(output,"ble-metadata");
            ((TextBox)Get(form,"address")).Text=address;Set(form,"busy",true);
            try{await Await(Call(form,"Connect"));}finally{Set(form,"busy",false);}
            connection=Get(form,"connection");Need((bool)Get(connection,"Connected"),"Production Connect failed");
            epoch=Convert.ToInt32(Get(connection,"Epoch"));var initial=await Await(Call(form,"ReadStatus"));
            Need(Convert.ToInt32(Get(form,"recorderVersion"))==1&&String.Equals((string)Get(form,"bleDeviceUid"),Uid,StringComparison.OrdinalIgnoreCase),"Connected peer UID/family mismatch");
            Same(form,connection,epoch,peer);AcceptanceCurrentPins.Current.RequireWireIdentity(Get(form,"firmwareIdentity"),Uid,1,false);
            Need((bool)Call(form,"StopConfirmed",initial)&&!(bool)Get(initial,"Busy")&&U(initial,"Fault")==0&&U(initial,"Error")==0,
                "Stopped fault-free APP required; no Stop is sent or replayed");
            Report["initial_status"]=Fields(initial);Report["profile_before"]=new {mask=U(initial,"Mask"),hz=U(initial,"Hz")};
            AcceptanceCurrentPins.Current.RequireMainLeases();AcceptanceCurrentPins.Current.RequireMapping(address);
            Same(form,connection,epoch,peer);Report["download_mode_requested_once"]=true;Report["mode_outcome"]="attempting_once";Save();
            try{
                await Await(Call(form,"SdTestDownloadMode"));
                Report["mode_outcome"]="production_handler_returned_after_correlated_mode_ACK";
                Report["ack_scope"]="Actual Send/SwitchMode matched receipt; raw ACK is not retained after production ResetDevice";
            }catch(Exception ex){Report["mode_outcome"]="unknown_or_rejected_no_replay";Report["mode_handler_error"]=ex.ToString();throw;}
            AcceptanceCurrentPins.Current.RequireMainLeases();
            string path=(string)await Task.Run(()=>Call(T("NpV1Management"),"WaitForUsbMode",Uid,(ushort)3,(Func<bool>)null));
            object target=((IEnumerable)Call(T("NpV1Management"),"Enumerate")).Cast<object>().Single(p=>
                String.Equals((string)Get(p,"Uid"),Uid,StringComparison.OrdinalIgnoreCase)&&
                String.Equals((string)Get(p,"Path"),path,StringComparison.OrdinalIgnoreCase)&&!(bool)Get(p,"Recovery"));
            using(var manager=(IDisposable)New("NpV1Management",target)){
                var status=Call(manager,"ReadStatus");Report["final_usb_status"]=Fields(status);Report["final_usb_path"]=path;
                Need(U(status,"Role")==3U&&U(status,"Busy")==0U&&U(status,"PendingMode")==0U,"Exact UID did not return idle USB download");
            }
            Report["result"]="PASS actual stopped-APP download handler ACK and exact-UID USB role3/busy0/pending0 confirmed";
            Report["scope"]="Mode handoff only; no Start, Stop, profile apply, catalog read, format/delete or saved-data verification";
        }finally{
            if(form!=null)Report["gui_log"]=((TextBox)Get(form,"log")).Text;
            try{if(connection!=null&&(bool)Get(connection,"Connected"))Call(connection,"Disconnect");}
            finally{try{if(form!=null)((IDisposable)form).Dispose();}finally{RestoreSettings();}}
            Report["persistent_preferences_unchanged"]=settings==Settings();
            Report["closed_loop_preferences_unchanged"]=clBefore==(File.Exists(ClPath)?Hash(ClPath):null);Save();
            Need((bool)Report["persistent_preferences_unchanged"]&&(bool)Report["closed_loop_preferences_unchanged"],"Persistent preference preservation failed");
        }
    }

    static void SelfTest(){
        Need(app.GetName().Version==new Version(1,0,0,240),"Actual240 required");
        foreach(string name in new[]{"Connect","ReadStatus","StopConfirmed","SdTestDownloadMode"}){
            var method=T("NpBleForm").GetMethods(All).Single(m=>m.Name==name);
            Need(method.GetParameters().Length==(name=="StopConfirmed"?1:0),"Actual handler signature changed: "+name);
            if(name!="StopConfirmed")Need(typeof(Task).IsAssignableFrom(method.ReturnType),"Async handler required: "+name);
        }
        foreach(string field in new[]{"connection","busy","poll","timer","bleImuTimer","preview","address","bleDeviceUid","recorderVersion","firmwareIdentity","log","ChooseBleSessionFolder","bleDestinationFolder"})
            Need(T("NpBleForm").GetField(field,All)!=null,"Actual form field missing: "+field);
        Need(T("NpV1Management").GetMethods(All).Count(m=>m.Name=="WaitForUsbMode"&&m.GetParameters().Length==3)==1,"Actual readonly USB-mode wait missing");
        foreach(string name in new[]{"Enumerate","ReadStatus"})Need(T("NpV1Management").GetMethods(All).Any(m=>m.Name==name),"Actual manager API missing: "+name);
        DownloadArguments(new[]{"download-mode","host",Uid,"F6D598CA53BA","fresh"});
        foreach(string[] bad in new[]{new[]{"record-sd","host",Uid,"F6D598CA53BA","fresh"},new[]{"download-mode","host","bad","F6D598CA53BA","fresh"},new[]{"download-mode","host",Uid,"bad","fresh"}}){
            bool rejected=false;try{DownloadArguments(bad);}catch(InvalidDataException){rejected=true;}Need(rejected,"Bad offline arguments accepted");
        }
        Report["result"]="PASS actual240 download-only handler/identity/status metadata and pure argument rejection";
        Report["selftest_scope"]="Offline reflection and pure arguments only: no Form/settings constructed, device enumeration, connection or hardware API called";
        Console.WriteLine(Json.Serialize(Report));
    }
    static void Help(){Console.WriteLine("Offline: --self-test <exact240.exe>\n--pins <manifest> --expected-app D05473D6 --expected-usb 71AE291B download-mode <exact240.exe> <UID001D...13354> <freshly verified BLE12hex> <fresh-output>\nMain must hold both leases. One stopped-APP mode request only; no Start/Stop/profile/catalog/format/delete calls or retry.");}
    [STAThread]static int Main(string[] args){
        if(args.Length==0||args[0]=="--help"){Help();return 0;}
        try{
            if(args.Length==2&&args[0]=="--self-test"){Pin(args[1]);SelfTest();return 0;}
            args=AcceptanceCurrentPins.Configure(args);DownloadArguments(args);Pin(args[1]);
            Need(AcceptanceCurrentPins.Current.ExpectedApp=="D05473D6"&&AcceptanceCurrentPins.Current.ExpectedUsb=="71AE291B","Only the exact current owner-pinned pair is admitted");
            Report["firmware_preflight"]=AcceptanceCurrentPins.Current.RequireOwner(AcceptanceCurrentPins.Current.Lease,Uid,1);
            AcceptanceCurrentPins.Current.RequireMainLeases();Fresh(args[4]);
            EventHandler begin=null;begin=async(s,e)=>{Application.Idle-=begin;try{await DownloadMode(args[3]);exit=0;}catch(Exception ex){Report["error"]=ex.ToString();Log(ex.ToString());}finally{Save();Application.ExitThread();}};
            Application.Idle+=begin;Application.Run();return exit;
        }catch(Exception ex){Report["error"]=ex.ToString();Console.Error.WriteLine(ex);Save();return 1;}
    }
}







