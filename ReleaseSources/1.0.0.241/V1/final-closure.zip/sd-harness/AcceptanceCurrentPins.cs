using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Web.Script.Serialization;

// One explicit frozen host/firmware input, never an allow-unknown firmware list.
// The owner installation proof is external evidence, not a wire-reported CRC.
internal sealed class AcceptanceCurrentPins {
    internal static AcceptanceCurrentPins Current;
    internal int HostRevision;bool offlineOnly;
    internal string HostHash,SdkHash,ReceiptHash,BuildReceipt,ExpectedApp,ExpectedUsb,Lease;
    string manifest,proof,proofHash,offline,mapping,mappingHash,globalLease;
    static readonly JavaScriptSerializer Json=new JavaScriptSerializer {MaxJsonLength=4*1024*1024};
    static void Need(bool ok,string why){if(!ok)throw new InvalidDataException(why);}
    static string Hash(string p){using(var f=File.OpenRead(p))using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(f)).Replace("-","");}
    static string Hex(string value,int count){Need(value!=null&&value.Length==count&&value.All(c=>Uri.IsHexDigit(c)),"Exact hexadecimal pin required");value=value.ToUpperInvariant();Need(value.Any(c=>c!='0')&&(count!=8||value!="FFFFFFFF"),"Unknown/empty pin forbidden");return value;}
    static string PathAt(string parent,string p){Need(!String.IsNullOrWhiteSpace(p),"Pinned path missing");return Path.GetFullPath(Path.IsPathRooted(p)?p:Path.Combine(parent,p));}
    static object Get(object x,string n){var t=x.GetType();var f=t.GetField(n,BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic);return f!=null?f.GetValue(x):t.GetProperty(n,BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic).GetValue(x,null);}
    internal static string[] Configure(string[] args){
        if(args.Length==0||args.Length==1&&args[0]=="--help")return args;
        Need(args.Length>=7&&args[0]=="--pins"&&args[2]=="--expected-app"&&args[4]=="--expected-usb","Prefix --pins <manifest> --expected-app <8hex> --expected-usb <8hex> is mandatory");
        var p=new AcceptanceCurrentPins();p.manifest=Path.GetFullPath(args[1]);string dir=Path.GetDirectoryName(p.manifest);var d=Json.Deserialize<Dictionary<string,object>>(File.ReadAllText(p.manifest));
        p.HostRevision=Convert.ToInt32(d["host_version"]);Need(p.HostRevision==240,"Only the pinned actual240 is admitted");p.offlineOnly=d.ContainsKey("offline_only")&&(bool)d["offline_only"];if(p.offlineOnly)Need(args[6].StartsWith("--self-test",StringComparison.Ordinal)||args[6]=="--grid-self-test","Offline-only pin manifest cannot enter a hardware command");
        p.HostHash=Hex((string)d["host_sha256"],64);p.SdkHash=Hex((string)d["sdk_sha256"],64);p.ReceiptHash=Hex((string)d["build_receipt_sha256"],64);p.BuildReceipt=PathAt(dir,(string)d["build_receipt"]);
        p.ExpectedApp=Hex(args[3],8);p.ExpectedUsb=Hex(args[5],8);Need(p.ExpectedApp==Hex((string)d["expected_app_crc32"],8)&&p.ExpectedUsb==Hex((string)d["expected_usb_crc32"],8),"Explicit expected CRC arguments differ from frozen manifest");
        p.Lease=d.ContainsKey("lease")?Convert.ToString(d["lease"]):null;
        Need(p.HostHash=="BD0416D30E53946B65380D8F925AE002C277D9C835D22F6A59598D1675F26ECD"&&p.SdkHash=="EBC98EEB84FDE42DEE06B713F1F6246B30B3527732075D9F84C6DF57BCA69EFB","Manifest must select exact actual240 host/SDK");
        p.globalLease=Convert.ToString(d["global_lease"]);Need(!String.IsNullOrWhiteSpace(p.globalLease),"Main global lease required");
        p.mapping=PathAt(dir,(string)d["verified_mapping"]);p.mappingHash=Hex((string)d["verified_mapping_sha256"],64);
        if(d.ContainsKey("owner_preflight")&&!String.IsNullOrWhiteSpace(Convert.ToString(d["owner_preflight"]))) {p.proof=PathAt(dir,(string)d["owner_preflight"]);p.proofHash=Hex((string)d["owner_preflight_sha256"],64);}
        p.offline=PathAt(dir,(string)d["selftest_output"]);Current=p;return args.Skip(6).ToArray();
    }
    internal string SelfTestOutput(string name){return Path.Combine(offline,name);}
    internal Dictionary<string,object> RequireOwner(string lease,string uid,int family){
        Need(!offlineOnly,"Offline-only inputs cannot authorize hardware");Need(!String.IsNullOrWhiteSpace(Lease)&&lease==Lease,"Exact current owner-held lease required");Need(proof!=null&&Hash(proof)==proofHash,"Pinned owner installation preflight required; no unreported-CRC default");
        var d=Json.Deserialize<Dictionary<string,object>>(File.ReadAllText(proof));Need((bool)d["verified"]&&Convert.ToString(d["uid"])==uid&&Convert.ToInt32(d["family"])==family&&Convert.ToString(d["lease"])==lease,"Owner installation proof UID/family/lease mismatch");
        Need(Convert.ToString(d["global_lease"])==globalLease,"Both owner leases must match installation preflight");
        Need(Hex((string)d["app_crc32"],8)==ExpectedApp&&Hex((string)d["usb_crc32"],8)==ExpectedUsb,"Owner installation proof firmware CRC mismatch");
        var evidence=((IEnumerable)d["evidence"]).Cast<object>().Select(x=>Json.ConvertToType<Dictionary<string,object>>(x)).ToArray();Need(evidence.Length>0&&evidence.Length<=8,"Bound installation evidence required");
        foreach(var row in evidence)Need(Hash(PathAt(Path.GetDirectoryName(proof),(string)row["path"]))==Hex((string)row["sha256"],64),"Owner installation evidence changed");
        return new Dictionary<string,object>{{"source","owner_verified_installation_preflight_not_device_reported"},{"path",proof},{"sha256",proofHash},{"uid",uid},{"family",family},{"expected_app_crc32",ExpectedApp},{"expected_usb_crc32",ExpectedUsb},{"lease",lease}};
    }

    internal void RequireMainLeases(){
        Need(Lease==@"Local\XE_NP_V1_001D00065942500B20313354"&&globalLease==@"Local\WILDX_NP_TIMING_HIL","Exact main-owned lease names required");
        foreach(string name in new[]{globalLease,Lease})using(var mutex=System.Threading.Mutex.OpenExisting(name)){
            bool acquired=false;
            try{try{acquired=mutex.WaitOne(0);}catch(System.Threading.AbandonedMutexException){acquired=true;}}
            finally{if(acquired)mutex.ReleaseMutex();}
            Need(!acquired,"Main no longer holds lease: "+name);
        }
    }
    internal Dictionary<string,object> RequireMapping(string address){
        Need(!offlineOnly&&mapping!=null&&Hash(mapping)==mappingHash,"Pinned current UID/radio mapping required before Connect");
        var d=Json.Deserialize<Dictionary<string,object>>(File.ReadAllText(mapping));
        Need((bool)d["verified"]&&Convert.ToString(d["uid"])=="001D00065942500B20313354"&&Convert.ToInt32(d["family"])==1&&
            String.Equals(Convert.ToString(d["ble_address"]),address,StringComparison.OrdinalIgnoreCase)&&
            Convert.ToString(d["device_lease"])==Lease&&Convert.ToString(d["global_lease"])==globalLease,"Mapping UID/radio/lease mismatch");
        DateTime verified=DateTime.Parse(Convert.ToString(d["verified_utc"]),CultureInfo.InvariantCulture,DateTimeStyles.AdjustToUniversal|DateTimeStyles.AssumeUniversal);
        Need(verified<=DateTime.UtcNow.AddMinutes(1)&&verified>=DateTime.UtcNow.AddMinutes(-15),"Mapping must be verified by main within15minutes before Connect");
        return d;
    }
    internal void RequireWireIdentity(object value,string uid,int family,bool advertised){
        if(value==null){Need(!advertised,"Advertised firmware identity missing; installation proof cannot override");return;}
        Need(Convert.ToString(Get(value,"Uid"))==uid&&Convert.ToInt32(Get(value,"Family"))==family&&Convert.ToString(Get(value,"AppCrc32"))==ExpectedApp&&Convert.ToString(Get(value,"UsbCrc32"))==ExpectedUsb,"Wire firmware identity disagrees with exact expected pair");
    }
}





