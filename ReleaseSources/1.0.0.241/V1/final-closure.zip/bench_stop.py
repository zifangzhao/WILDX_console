
from pathlib import Path
import sys

import bench_hil as bench
import ap_snapshot
ap_snapshot.PHASE=bench.c.PHASE
source = Path(bench.c.__file__).with_name("read_stopped.py")
text = source.read_text(encoding="utf-8-sig")
text = bench.c.once(text,"('np_usb_cl_workspace','workspace',1888)","('np_usb_cl_workspace','workspace',1744)")
text = bench.c.once(text,"(BUILD/'usb/candidate.map')","Path(r'C:/Frank/Code/XE_NP/_artifacts/v1_gui_support_20261105/build-usb/candidate.map')")
sys.argv.append("--ap-only")
exec(compile(text,str(source),"exec"),{"__name__":"__main__","__file__":str(source)})




