import sys,json
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,r"C:/Frank/Code/XE_NP/Tools/V1Capture/ClosedLoopFix")
import hil_current as c
root=Path(__file__).resolve().parent
pair=json.loads((root/"matched-test-pair.json").read_text())
c.OUTPUT=root;c.PHASE=root/"bench";c.BUILD=root/"candidate"
c.COMPONENT_DIRS={r:Path(pair[r]["path"]).parent for r in ("app","usb")}
c.PINS={r:(pair[r]["sha256"],pair[r]["image_crc32"]) for r in ("app","usb")}
if __name__=="__main__":c.main()
current=c
PHASE=c.PHASE
