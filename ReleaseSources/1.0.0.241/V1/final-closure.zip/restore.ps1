$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$phase=Join-Path $root 'bench'
$py='C:/Users/antfe/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$psExe=(Get-Process -Id $PID).Path
$proof=Join-Path $phase 'usb-cl0_stopped/proof.json'
$p=Get-Content -LiteralPath $proof -Raw|ConvertFrom-Json
if($p.result -ne 'PASS' -or !$p.all_16_dma_disabled -or !$p.sd_data_idma0){throw 'Physical quiescence proof required'}
$initial=Get-Content -LiteralPath (Join-Path $phase 'initial_status.json') -Raw|ConvertFrom-Json
if($initial.uid -ne '001D00065942500B20313354' -or !$initial.read_only_preflight -or $initial.final.Role -ne 3){throw 'Fresh original identity/profile required'}
& $psExe -NoProfile -File (Join-Path $root 'restore-profile-cross-rate.ps1') -Action EnterDownload -Report (Join-Path $phase 'restore-idle-download.json')
if($LASTEXITCODE){exit $LASTEXITCODE}
& $psExe -NoProfile -File (Join-Path $root 'control.ps1') -Phase $phase -Action Status -Report (Join-Path $phase 'restore_status.json') | Out-Null
if($LASTEXITCODE){exit $LASTEXITCODE}
& $py -B (Join-Path $root 'bench_hil.py') restore
if($LASTEXITCODE){exit $LASTEXITCODE}
& $psExe -NoProfile -File (Join-Path $root 'restore-profile-cross-rate.ps1') -Action RestoreUsbProfile -Report (Join-Path $phase 'restore-profile.json')
if($LASTEXITCODE){exit $LASTEXITCODE}
& $psExe -NoProfile -File (Join-Path $root 'control.ps1') -Phase $phase -Action Status -Report (Join-Path $phase 'restored-final-status.json') | Out-Null
if($LASTEXITCODE){exit $LASTEXITCODE}
$j=Get-Content -LiteralPath (Join-Path $phase 'restored-final-status.json') -Raw|ConvertFrom-Json
if($j.profile.ActiveMask -ne $initial.profile.ActiveMask -or $j.profile.ApHz -ne $initial.profile.ApHz -or $j.card_sectors -ne $initial.card_sectors -or $j.final.Role -ne 3 -or $j.final.Busy -ne 0 -or $j.final.PendingMode -ne 0){throw 'Fresh original profile/card/idle USB not restored'}
& $py -B (Join-Path $root 'bench_final_profile.py')
if($LASTEXITCODE){exit $LASTEXITCODE}
[ordered]@{result='PASS';uid=$j.uid;original_flash_options_verified=$true;original_profile_verified=$true;card_sectors=$j.card_sectors;usb_mode=3;idle=$true;protected_profile_verified=$true;cpu_debug_enabled=$false}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $phase 'restoration-complete.json')
New-Item -ItemType File -Path (Join-Path $phase 'release_all.request') -ErrorAction Stop|Out-Null
