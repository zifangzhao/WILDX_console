import json
from pathlib import Path
T=Path(__file__).resolve().parent
P=Path('C:/Frank/Code/XE_NP/_artifacts/closed_loop_qualification_20261104/V1')
P0=Path('C:/Frank/Code/XE_NP/_artifacts/v1_usb_sensor_media_20261105')
s=(P/'pins.py').read_text().replace("host_version=231","host_version=240").replace('D:/Code/WILDX_console/WILDX_console/_artifacts/closed-loop-profile-limits/app/WILDX_console.exe','C:/Frank/Code/USB_PCconsole/_artifacts/sd_usb_test_host/enabled240-guiops/WILDX_console.exe')
(T/'pins.py').write_text(s)
s=(P/'bench_sd_stop.py').read_text().replace('(c.BUILD/"app/candidate.map")',"Path(r'C:/Frank/Code/XE_NP/_artifacts/v1_gui_support_20261105/build-app/candidate.map')")
(T/'bench_sd_stop.py').write_text(s)
s=(P0/'restore.ps1').read_text().replace("$proof=Join-Path $phase 'usb-cl2-r2_stopped/proof.json'\nif(!(Test-Path -LiteralPath $proof)){$proof=Join-Path $phase 'usb-cl2_stopped/proof.json'}","$proof=Join-Path $phase 'usb-cl0_stopped/proof.json'")
(T/'restore.ps1').write_text(s)
print('Prepared exact private pins, APP stopped proof, and restore wrapper')
