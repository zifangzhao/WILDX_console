import hashlib,json,re,zipfile
from pathlib import Path
T=Path(__file__).resolve().parent
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
out=T/'source-freeze';out.mkdir(exist_ok=True);assert not (out/'manifest.json').exists()
files={}
def add(p,scope):
 p=p.resolve();assert p.is_file(),p
 if str(p) in files:return
 data=p.read_bytes();key=f'inputs/{len(files):04d}-{p.name}'
 (out/key).parent.mkdir(exist_ok=True);(out/key).write_bytes(data)
 files[str(p)]=dict(original=str(p),archived=key,bytes=len(data),sha256=h(p),scope=scope)
for folder in ('app-source','usb-source','native-preview','native-sdinfo','sd-harness','usb-harness'):
 for p in (T/folder).iterdir():
  if p.suffix.lower() in ('.c','.h','.inc','.cs','.py','.json','.txt','.log'):add(p,'exact changed source or targeted fixture')
for role in ('app','usb'):
 b=T/f'build-{role}'
 for n in ('receipt.json','identity.json','candidate.lnp','candidate.map','compile.log'):add(b/n,'exact build command/object identity/map')
 d=b/('provider.d' if role=='app' else 'stream.d');add(d,'compiler dependency chain')
 # ARM dependency writer emits one literal Windows path per continuation line.
 for line in d.read_text().splitlines()[1:]:
  text=line.strip().removesuffix('\\').rstrip()
  if text:
   dep=Path(text)
   if not dep.is_absolute():dep=Path(json.loads((b/'receipt.json').read_text()).get('compiler_cwd',str(T/'app-source')))/dep
   add(dep,'changed-TU dependency closure captured after checked build; inherited objects referenced separately')
for n in ('prepare_app.py','prepare_usb.py','build_app.py','build_usb.py','seal_app.py','seal_usb.py','app-source-receipt.json','usb-source-receipt.json','helper-inputs.json','matched-test-pair.json','prepare_hil.py','prepare_bench_scripts.py'):
 add(T/n,'exact source staging/build/helper recipe')
parents=[Path('C:/Frank/Code/XE_NP/_artifacts/v1_usb_sensor_media_20261105')/n for n in ('accepted.json','source-freeze-candidate.zip','source-freeze-final.zip')]
manifest=dict(status='CANDIDATE_SOFTWARE_CHECKED_HARDWARE_PENDING',app_crc32='D05473D6',usb_crc32='71AE291B',host_version=240,files=list(files.values()),parents=[dict(path=str(p),bytes=p.stat().st_size,sha256=h(p),scope='unchanged inherited object/source custody; referenced, not duplicated') for p in parents],limits=['No new acceptance is inferred from software checks or inherited qualification.','Compiler .d closure captured immediately after build; inherited objects remain pinned by exact hashes and prior accepted archive.','V1 FS2 DeleteLast intentionally absent; cap0x40000 not advertised.'])
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
z=T/'source-freeze-candidate.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as f:
 for p in sorted(out.rglob('*')):
  if p.is_file():f.write(p,p.relative_to(out))
app=T/'build-app';x=app/'APP_TEST_ONLY.xenp';assert not x.exists();x.write_bytes((app/'APP_manifest.bin').read_bytes()+(app/'APP_body.bin').read_bytes())
receipt=dict(source_zip=str(z),source_zip_bytes=z.stat().st_size,source_zip_sha256=h(z),manifest_sha256=h(out/'manifest.json'),files=len(files),app_xenp=str(x),app_xenp_sha256=h(x),status='PENDING_HARDWARE')
(T/'source-freeze-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
