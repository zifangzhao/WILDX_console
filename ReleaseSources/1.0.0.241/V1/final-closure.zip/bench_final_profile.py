import sys
from pathlib import Path
import bench_hil
source=Path(bench_hil.c.__file__).with_name('final_ap_profile.py')
sys.argv=[sys.argv[0],'bench_hil']
exec(compile(source.read_text(encoding='utf-8-sig'),str(source),'exec'),{'__name__':'__main__','__file__':str(source)})
