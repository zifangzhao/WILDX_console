from pathlib import Path
import hashlib,json,re,zipfile
T=Path(__file__).resolve().parent;B=(T/'bench').resolve();h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper();load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def kv(p):return dict(x.split('=',1) for x in p.read_text().splitlines() if '=' in x)
U=load(B/'usb-cl0/experiment.json');S=load(B/'sd-preview-verified/hil.json');P=load(B/'sd-preview/preview-transport.json');R=load(B/'restoration-complete.json');L=load(T/'owner/lease.json')
assert U['result']=='pass' and U['recording_worker_returned_successfully'] and U['scheduled_imu_grid']['feature_acceptance_passed']
assert S['acceptance_passed'] and S['physical_imu_verified'] and S['preview_source_oracle']['matches']==96
assert P['gap_free'] and P['delivered_hz_per_channel']>=500 and R['result']=='PASS' and L['status']=='CLOSED'
status=kv(B/'sd-preview-verified/export/capture_status.txt');assert status['complete']==status['lossless']==status['download_complete']=='True'
for i in (1,2):
 for k in ('frame_errors','counter_errors','relocks','lfp_phase_errors','missing_ap_rows','missing_lfp_rows'):assert int(status[f'np{i}_{k}'])==0
# Compact only these generated captures; never touch card data, user paths or restore backups.
C=T/'compact';C.mkdir(exist_ok=False);removed=[];kept=[]
roots=[B/'usb-cl0',B/'sd-preview-verified/export']
for root in roots:
 assert root.resolve().is_relative_to(B)
 for p in root.rglob('*.dat'):
  if not (p.name in ('neuropixels_ap.dat','neuropixels_lfp.dat','time.dat') or re.fullmatch(r'np[12]_(ap|lfp)\.dat',p.name) or '.timestamps.calibrated.dat' in p.name):continue
  assert p.resolve().is_relative_to(B) and p.is_file() and not p.is_symlink()
  size=p.stat().st_size;unit=8 if '.timestamps.calibrated.dat' in p.name else 4 if p.name=='time.dat' else 768
  assert size%unit==0
  n=min(size,unit*16)
  with p.open('rb') as f:head=f.read(n);f.seek(max(0,size-n));tail=f.read(n)
  rel=p.relative_to(B);dst=C/rel.parent;dst.mkdir(parents=True,exist_ok=True)
  hp=dst/(p.name+'.head.bin');tp=dst/(p.name+'.tail.bin');hp.write_bytes(head);tp.write_bytes(tail)
  row=dict(path=str(p),bytes=size,rows=size//unit,record_bytes=unit,head=str(hp.relative_to(T)),head_sha256=h(hp),tail=str(tp.relative_to(T)),tail_sha256=h(tp),full_payload_hash='not read solely for cleanup; complete framing/continuity was already verified by the recording/export path')
  kept.append(row);p.unlink();removed.append(size)
cleanup=dict(status='COMPLETE',removed_bytes=sum(removed),files=len(removed),fixture_bytes=sum(x.stat().st_size for x in C.rglob('*.bin')),captures_only=True,restore_backups_preserved=True,user_recordings_untouched=True,fixtures=kept)
(T/'cleanup-complete.json').write_text(json.dumps(cleanup,indent=2)+'\n')
# Separate immutable closure; candidate ZIP remains byte-identical.
paths=set()
for folder in ('sd-harness','usb-harness','sensor-analysis','compact'):
 for p in (T/folder).rglob('*'):
  if p.is_file() and p.suffix in ('.cs','.json','.py','.bin'):paths.add(p)
for p in B.glob('*.json'):paths.add(p)
for p in (T/'owner').glob('*.json'):paths.add(p)
for folder in ('usb-cl0','usb-cl0_stopped','sd-preview','sd-preview_stopped','sd-preview-verified','sd-map','sd-download-mode','final_profile_ap'):
 for p in (B/folder).rglob('*'):
  if p.is_file() and p.suffix.lower() in ('.json','.jsonl','.csv','.txt','.bin','.dat') and p.stat().st_size<=4*1024*1024:paths.add(p)
for n in ('source-freeze-receipt.json','helper-inputs.json','matched-test-pair.json','cleanup-complete.json','finalize.py','complete.py','freeze_source.py','prepare_hil.py','prepare_bench_scripts.py','bench_hil.py','bench_stop.py','bench_sd_stop.py','hold-lease.ps1','control.ps1','restore-profile-cross-rate.ps1','restore.ps1','bench_final_profile.py','pins.py'):paths.add(T/n)
closure=dict(status='CHECKED_SCOPED_HARDWARE_ACCEPTED_RESTORED',base_source_zip=dict(path=str(T/'source-freeze-candidate.zip'),sha256=h(T/'source-freeze-candidate.zip')),files=[dict(path=str(p.relative_to(T)),bytes=p.stat().st_size,sha256=h(p)) for p in sorted(paths)],limits=['This closure supersedes candidate test-helper copies with the actual bounded240 helpers and records initial output-fence/pin corrections before hardware commands.','Firmware sources/binaries did not change after the original single APP and USB incremental builds.','Raw original firmware/options and installed/restored whole-flash proofs remain protected under bench; hashes are recorded, no duplicate payload archive.'])
(T/'closure-manifest.json').write_text(json.dumps(closure,indent=2)+'\n');paths.add(T/'closure-manifest.json')
z=T/'source-freeze-final.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
 for p in sorted(paths):archive.write(p,p.relative_to(T))
usb_sensor=load(T/'sensor-analysis/usb-cl0.json');sd_sensor=load(T/'sensor-analysis/sd-preview.json');pair=load(T/'matched-test-pair.json')
utc=load(B/'sd-preview-verified/export/recording_start_utc.json')
accepted=dict(status='accepted',family=1,uid='001D00065942500B20313354',app_crc32='D05473D6',usb_crc32='71AE291B',pair=pair,host_version=240,host_sha256='BD0416D30E53946B65380D8F925AE002C277D9C835D22F6A59598D1675F26ECD',
 original_restored=True,restore_receipt=dict(path=str(B/'restoration-complete.json'),sha256=h(B/'restoration-complete.json')),lease_receipt=dict(path=str(T/'owner/lease.json'),sha256=h(T/'owner/lease.json')),
 sd_info=dict(status='PASS',scope='Actual GUI ReadCard A6/A5 cold and after ordinary completed bulk read; sameCID/capacity, sequence1/2, Error0, Flags15, idleRole3 restored; post-query30s USB NP/IMU capture passed',capability='0x20000',in_request='0xA5 IN384',refresh_request='0xA6 OUT0',refresh_role=3,delete_last_supported=False,delete_capability_advertised=False),
 preview=P,preview_source_oracle={k:v for k,v in S['preview_source_oracle'].items() if k!='rows'},
 usb_recording=dict(status='PASS_SCOPED',rate_hz=15000,probe_mask=3,detectors=0,minimum_observed_seconds=25,observed_slots=U['scheduled_imu_grid']['observed'],missing_slots=U['scheduled_imu_grid']['missing'],np_relative_phase_qualified=True,source_window_verified=True,native_ag_hz=usb_sensor['native']['ag']['rate_hz'],native_mag_hz=usb_sensor['native']['mag']['rate_hz']),
 sd_recording=dict(status='PASS',rate_hz=15000,probe_mask=3,detectors=0,chunks=int(status['committed_chunks']),lossless=True,firmware_losses=0,sensor_queue_overflow=0,grid_rows=sd_sensor['grid']['rows'],grid_observed=sd_sensor['grid']['counts']['observed'],grid_missing=1,grid_errors=0,source_window_verified=False,rtc_np_local_interval_width_us=utc['local_interval_width_us'],native_ag_hz=sd_sensor['native_ag']['rate_hz'],native_mag_hz=sd_sensor['native_mag']['rate_hz']),
 unchanged_closed_loop_qualification=dict(parent_receipt='C:/Frank/Code/XE_NP/_artifacts/v1_usb_sensor_media_20261105/accepted.json',parent_sha256='08C0E2C7F11120240080998526E832863683EC9C958A52D86A8D30985C9E9201',counts=[1,2],profile='15kHz/two probes',scope='Unchanged CL source/kernel/ownership/buffers; current physical preview test CLoff; host now explicitly prevents preview/CL coexistence. No fresh1/2-detector rerun claimed.'),
 source_zip=dict(path=str(T/'source-freeze-candidate.zip'),sha256=h(T/'source-freeze-candidate.zip')),final_closure=dict(path=str(z),sha256=h(z),bytes=z.stat().st_size),app_xenp=dict(path=str(T/'build-app/APP_TEST_ONLY.xenp'),sha256=h(T/'build-app/APP_TEST_ONLY.xenp')),cleanup=dict(removed_bytes=cleanup['removed_bytes'],fixture_bytes=cleanup['fixture_bytes']),
 limits=['Physical preview qualification is two LFP channels0/24 onP1 at15kHz/two-probe SDrecording for30.27s; other rates have native metadata/parser checks, not this physical run.','V1 USB lossless=False startup label and unequal startup retained extents remain recorded; no midstream NP gap/frame/counter/relock/drop observed.','Both grids retain one unavailable initial slot; SD native startup has5AG/7MAG unavailable snapshots; primary observed slots are valid/errorfree.','SD source_window=False and no final scheduled-slot marker mean terminal tail completeness remains unknown; not relabeled.','RTC-to-NP local bound110us excludes independent PC/network calibration uncertainty; native sensor conversion/filter phase not attested.','V1 FS2 USB DeleteLast remains unavailable; no filesystem-generation semantics changed. No format/delete performed; one bounded completed SD test session remains on card.','No installer, publication or new camera/audio performance claim is part of this work.'])
(T/'accepted.json').write_text(json.dumps(accepted,indent=2)+'\n')
print(json.dumps(dict(status=accepted['status'],accepted_sha256=h(T/'accepted.json'),app=accepted['app_crc32'],usb=accepted['usb_crc32'],source_zip=accepted['source_zip'],closure=accepted['final_closure'],removed_bytes=cleanup['removed_bytes']),indent=2))
