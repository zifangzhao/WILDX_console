from pathlib import Path
import hashlib,json,re,sys
T=Path(__file__).resolve().parent;B=T/'build-usb';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
r=json.loads((B/'pending.json').read_text());assert h(B/'stream.o')==r['stream_object_sha256']
for p,d in r['retained_objects'].items():assert h(Path(p))==d
for p,d in r['staged'].items():assert h(Path(p))==d
sys.dont_write_bytecode=True;sys.path.insert(0,'C:/Frank/Code/XE_NP/Tools/V1Capture/ClosedLoopFix');from build_current import seal
identity=seal('usb',B);(B/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
regions=[(name,int(base,16),int(size,16),int(limit,16)) for name,base,size,limit in re.findall(r'Execution Region (\S+) \(Exec base: (0x\w+).*?Size: (0x\w+), Max: (0x\w+)',(B/'candidate.map').read_text())]
assert regions and all(size<=limit for name,base,size,limit in regions)
r.update(status='SOFTWARE_CHECKED_PENDING_HARDWARE',identity=identity,regions=regions)
(B/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(dict(status=r['status'],usb_crc32=identity['image_crc32'],hex_sha256=identity['sha256'],regions=regions),indent=2))
