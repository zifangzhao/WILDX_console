from pathlib import Path
import hashlib,json,subprocess
N=Path(__file__).resolve().parent;T=N.parent
tools=Path('C:/Frank/Code/XE_NP/Tools/V1Capture/Ble')
vc='C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat'
cmd='call "'+vc+'" >nul && cl /nologo /std:c11 /W4 /WX /TC /O2 /I"'+str(N)+'" /I"'+str(tools)+'" /I"C:/Frank/Code/XE_NP/Firmware/V1/Core/Inc" test_compact_preview.c /Fe:preview.exe'
r=subprocess.run('cmd /d /s /c "'+cmd+'"',cwd=N,capture_output=True,text=True);(N/'compile.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
r=subprocess.run([str(N/'preview.exe'),str(N/'vectors.bin')],cwd=N,capture_output=True,text=True);(N/'result.txt').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
rates=[]
for hz in (7500,15000,20000,30000):
 stride=max(1,hz//6000)*9360;rate=hz*780/stride
 assert rate>=500
 rates.append(dict(ap_hz=hz,source_hz=hz*780,stride=stride,lfp_preview_hz=rate,
                   bytes_per_second_1_or_2_channels=rate*228/16,uart_8N1_bits_per_second=rate*2280/16))
receipt=dict(status='PASS',hardware_access=False,scope='Actual staged preview header + existing legacy/compact tests and synthetic source decoding, CRC, pressure/queue/lease/rollover checks. Only expectedLFPstride adapted. Actual GUI parser compatibility is a separate root task.',
             header_sha256=sha(N/'np_ble_preview.h'),output=r.stdout,rates=rates,
             compiler_command=cmd,fixtures={str(p):sha(p) for p in N.iterdir() if p.suffix in ('.c','.h')},
             vector_file=str(N/'vectors.bin'),vector_sha256=sha(N/'vectors.bin'))
(N/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(dict(status=receipt['status'],output=r.stdout,rates=rates,header_sha256=receipt['header_sha256'],vectors=receipt['vector_file']),indent=2))
