using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

// Bounded observer on the production recording's existing connection; no second radio owner.
static partial class NpFirstSyncV1SdCurrent {
    static readonly object previewGate=new object();
    static readonly List<byte[]> previewPackets=new List<byte[]>();
    static readonly List<double> previewTimes=new List<double>();
    static readonly List<string> previewErrors=new List<string>();
    static Stopwatch previewWall,previewLease;static uint previewId=0x67504001,previewPhase,previewSession;static int previewEpoch,previewRenewals;
    static Action<int,byte[]> previewReceive;static bool previewActive;static object previewLink;
    static readonly uint[] previewChannels={0U,24U};
    static byte[] PreviewRequest(uint id,uint kind,uint phase,uint session,bool compact){
        return (byte[])Call(T("CE32_console.NpV1PreviewBurst"),compact?"CompactRequest":"Request",compact?
            new object[]{id,kind,1U,previewChannels,phase,session,1U}:
            new object[]{id,kind,1U,0U,phase,session,1U});
    }
    static async Task<bool> PreviewWrite(object c,byte[] bytes,int epoch){return (bool)await Await(Call(c,"TryWritePreview",bytes,epoch,CancellationToken.None));}
    static void PreviewListen(object c,Action<int,byte[]> handler,bool add){var e=c.GetType().GetEvent("PreviewReceived",All);Need(e!=null,"Actual PreviewReceived event missing");if(add)e.AddEventHandler(c,handler);else e.RemoveEventHandler(c,handler);}
    static async Task PreviewBegin(object connection,int epoch){
        Need(detectors==0,"Physical preview test requires CL off");previewLink=connection;previewEpoch=epoch;
        object origin=New("CE32_console.NpV1PreviewBurst",previewId);var done=new TaskCompletionSource<object>();var sync=new object();
        Action<int,byte[]> receive=(generation,body)=>{if(generation!=epoch)return;try{lock(sync){if((bool)Call(origin,"Accept",body))done.TrySetResult(origin);}}catch(Exception ex){done.TrySetException(ex);}};
        PreviewListen(connection,receive,true);var lease=Stopwatch.StartNew();
        try{
            Need(await PreviewWrite(connection,PreviewRequest(previewId,0,0,0,false),epoch),"Origin preview write declined");lease.Restart();
            var wait=Stopwatch.StartNew();
            while(!done.Task.IsCompleted){
                Need(wait.ElapsedMilliseconds<5000,"Preview origin timed out");uint session;lock(sync){session=U(origin,"Session");}
                if(session!=0&&lease.ElapsedMilliseconds>=750&&await PreviewWrite(connection,PreviewRequest(previewId,4,0,session,false),epoch))lease.Restart();
                await Task.WhenAny(done.Task,Task.Delay(50));
            }
            await done.Task;Need(U(origin,"Kind")==0&&U(origin,"Probe")==1&&U(origin,"Channel")==0&&U(origin,"Band")==1&&U(origin,"Hz")==15000,"Origin selection changed");
            previewPhase=Convert.ToUInt32(Call(origin,"FindPhase"));previewSession=U(origin,"Session");Need(previewSession!=0,"Preview session missing");
            File.WriteAllBytes(Path.Combine(output,"preview-origin.bin"),(byte[])Get(origin,"Data"));
            Report["preview_origin"]=new {phase=previewPhase,session=previewSession,hz=15000,probe=1,channels=previewChannels,band="lfp"};
        }finally{PreviewListen(connection,receive,false);}
        previewId++;previewWall=Stopwatch.StartNew();previewLease=Stopwatch.StartNew();previewActive=true;
        previewReceive=(generation,body)=>{if(generation!=previewEpoch)return;lock(previewGate){if(!previewActive)return;try{var frame=New("CE32_console.NpV1PreviewBurst",previewId);if(!(bool)Call(frame,"Accept",body))return;
            Need(U(frame,"Kind")==5&&U(frame,"Session")==previewSession&&U(frame,"Band")==1&&U(frame,"Hz")==15000&&U(frame,"Probe")==1,"Stream metadata changed");
            previewPackets.Add((byte[])body.Clone());previewTimes.Add(previewWall.Elapsed.TotalSeconds);
        }catch(Exception ex){previewErrors.Add(ex.ToString());}}};
        PreviewListen(connection,previewReceive,true);Need(await PreviewWrite(connection,PreviewRequest(previewId,5,previewPhase,previewSession,true),epoch),"Compact stream write declined");previewLease.Restart();
    }
    static async Task PreviewRenew(object connection,int epoch){
        if(previewActive&&previewLease.ElapsedMilliseconds>=750){Need(await PreviewWrite(connection,PreviewRequest(previewId,4,previewPhase,previewSession,true),epoch),"Preview lease renewal declined");previewRenewals++;previewLease.Restart();}
    }
    static async Task PreviewEnd(object connection,int epoch){
        if(!previewActive)return;lock(previewGate){previewActive=false;}
        try{await PreviewWrite(connection,PreviewRequest(previewId,3,previewPhase,previewSession,true),epoch);}finally{PreviewListen(connection,previewReceive,false);}
        var invariant=CultureInfo.InvariantCulture;long valid=0,invalid=0;int gaps=0,outOfOrder=0;ulong priorEnd=0,first=0,last=0;uint maxDrops=0;double seconds=previewWall.Elapsed.TotalSeconds;
        using(var wire=File.Create(Path.Combine(output,"preview-packets-224.bin")))using(var csv=new StreamWriter(Path.Combine(output,"preview-samples.csv")))using(var packets=new StreamWriter(Path.Combine(output,"preview-packets.csv"))){
            csv.WriteLine("band,probe,channel,session,source_tick,raw10,valid");packets.WriteLine("packet,host_elapsed,first_tick,stride,dropped,mask0,mask1");
            for(int n=0;n<previewPackets.Count;n++){
                byte[] bytes=previewPackets[n];wire.Write(bytes,0,bytes.Length);var f=New("CE32_console.NpV1PreviewBurst",previewId);Need((bool)Call(f,"Accept",bytes),"Saved packet not accepted");
                var samples=(double[][])Call(f,"DecodeCompact",previewPhase);var channels=(ushort[])Get(f,"Channels");var masks=(ushort[])Get(f,"ValidMasks");var offsets=(uint[])Get(f,"TickOffsets");
                ulong tick=L(f,"FirstTick");uint stride=U(f,"Stride");Need(stride==18720&&channels.Length==2&&channels[0]==0&&channels[1]==24,"Actual compact stride/channel mismatch");
                if(n==0)first=tick;if(priorEnd!=0&&tick!=priorEnd){if(tick<priorEnd)outOfOrder++;else gaps++;}priorEnd=tick+16UL*stride;last=priorEnd;maxDrops=Math.Max(maxDrops,U(f,"Dropped"));
                packets.WriteLine(n+","+previewTimes[n].ToString("R",invariant)+","+tick+","+stride+","+U(f,"Dropped")+","+masks[0]+","+masks[1]);
                for(int c=0;c<2;c++)for(int i=0;i<16;i++){bool ok=!Double.IsNaN(samples[c][i]);if(ok)valid++;else invalid++;csv.WriteLine("1,1,"+channels[c]+","+previewSession+","+(tick+offsets[c]+(ulong)i*stride)+","+(ok?samples[c][i].ToString("R",invariant):"NaN")+","+(ok?"1":"0"));}
            }
        }
        Report["preview_transport"]=new {offered_hz_per_channel=625.0,offered_uart_8n1_bps=89062.5,stream_wall_seconds=seconds,packets=previewPackets.Count,delivered_rows_per_channel=previewPackets.Count*16,delivered_hz_per_channel=previewPackets.Count*16/seconds,source_first_tick=first,source_end_tick=last,source_gaps=gaps,out_of_order=outOfOrder,explicit_valid_samples=valid,explicit_invalid_samples=invalid,device_dropped_max=maxDrops,lease_renewals=previewRenewals,errors=previewErrors.ToArray(),gap_free=gaps==0&&invalid==0&&maxDrops==0&&outOfOrder==0&&previewErrors.Count==0};
        File.WriteAllText(Path.Combine(output,"preview-transport.json"),Json.Serialize(Report["preview_transport"]));
        Need(previewPackets.Count>0&&previewErrors.Count==0,"Preview produced no accepted packets or protocol errors");
    }
}
