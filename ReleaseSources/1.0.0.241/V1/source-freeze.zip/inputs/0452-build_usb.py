from pathlib import Path
import hashlib,json,re,subprocess
T=Path(__file__).resolve().parent;B=T/'build-usb';B.mkdir(exist_ok=True);assert not any(B.iterdir());P=Path('C:/Frank/Code/XE_NP/_artifacts/closed_loop_qualification_20261104/V1')
R=Path('C:/Frank/Code/XE_NP/_artifacts/v1_usb_sensor_media_20261105/build-r2')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
pair=json.loads((P/'matched-test-pair.json').read_text());args=list(pair['stream_compile_args'])
old=[a for a in args if a.endswith('/stream.c') or a.endswith('\\stream.c')];assert len(old)==1
args[args.index(old[0])]=str(T/'usb-source/stream.c');args[args.index('-o')+1]=str(B/'stream.o')
gate='-DNP_USB_SD_JOB_APP_CRC=0x5F90FD3BU';assert args.count(gate)==1;args[args.index(gate)]='-DNP_USB_SD_JOB_APP_CRC=0xD05473D6U'
cwd=Path('C:/Frank/Code/XE_NP/_artifacts/v1_usb_fast_startup_r79r2_20261006/source/MDK-ARM')
r=subprocess.run(args,cwd=cwd,capture_output=True,text=True);(B/'compile.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
lnp=(R/'candidate.lnp').read_text();oldobj=(P/'candidate/usb/stream.o').as_posix();assert lnp.count(oldobj)==1
lnp=lnp.replace(oldobj,(B/'stream.o').as_posix());lnp=re.sub(r'--list\s+"[^"]+"','--list "'+(B/'candidate.map').as_posix()+'"',lnp);lnp=re.sub(r'-o\s+"[^"]+"','-o "'+(B/'candidate.axf').as_posix()+'"',lnp)
(B/'candidate.lnp').write_text(lnp)
objects=[Path(s) for s in re.findall(r'"([^"]+\.o)"',lnp) if Path(s)!=B/'stream.o']
receipt=dict(status='USB_COMPILED_PENDING_LINK',parent_usb_crc32='C91871BD',expected_app_crc32='D05473D6',compiler_command=args,compiler_cwd=str(cwd),
 source=str(T/'usb-source/stream.c'),source_sha256=sha(T/'usb-source/stream.c'),stream_object_sha256=sha(B/'stream.o'),
 staged={str(p):sha(p) for p in (T/'usb-source').iterdir() if p.is_file()},retained_objects={str(p):sha(p) for p in objects},native_receipt_sha256=sha(T/'native-sdinfo/receipt.json'))
(B/'pending.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(dict(status=receipt['status'],object_sha256=receipt['stream_object_sha256'],retained_objects=len(objects)),indent=2))
