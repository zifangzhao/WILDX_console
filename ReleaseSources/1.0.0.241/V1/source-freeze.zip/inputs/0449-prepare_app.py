from pathlib import Path
import hashlib,json,shutil
T=Path(__file__).resolve().parent
A=T/'app-source';N=T/'native-preview'
assert not A.exists();A.mkdir();N.mkdir()
P=Path('D:/Code/WILDX_console/WILDX_console/_artifacts/v1-cl-warm/candidate-corrected')
C=Path('C:/Frank/Code/USB_PCconsole/_artifacts/closed_loop_fix_20261102/V1/source_r1/app')
I=Path('C:/Frank/Code/XE_NP/_artifacts/v1_ble_compact_preview_20261025/app_source/Core/Inc')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
pins={}
def stage(old,name,replace=()):
 p=A/name;b=old.read_bytes();pins[str(old)]=sha(old)
 for a,z in replace:
  assert b.count(a.encode())==1,(old,a);b=b.replace(a.encode(),z.encode())
 p.write_bytes(b);return p
stage(P/'app-provider.c','provider.c',[(str(C/'firmware.inc').replace('\\','/'),(A/'firmware.inc').as_posix())])
stage(C/'firmware.inc','firmware.inc',[(str(C/'control.inc').replace('\\','/'),(A/'control.inc').as_posix())])
stage(C/'control.inc','control.inc',[(str(C/'preview.inc').replace('\\','/'),(A/'preview.inc').as_posix())])
stage(C/'preview.inc','preview.inc',[((I/'np_ble_preview.h').as_posix(),(A/'np_ble_preview.h').as_posix())])
stage(I/'np_ble_preview.h','np_ble_preview.h',[('((hz+5999U)/6000U)*9360U','((hz/6000U)?(hz/6000U):1U)*9360U')])
for name in ('xe_np_online_impl.h','np_sd_fast_crc.h'):stage(I/name,name)
tools=Path('C:/Frank/Code/XE_NP/Tools/V1Capture/Ble')
for name in ('test_compact_preview.c','test_v2_protocols.c'):
 b=(tools/name).read_bytes();pins[str(tools/name)]=sha(tools/name)
 # Expected metadata changes only for the intentionally changed LFP stride.
 b=b.replace(b'((rate+5999U)/6000U)*9360U',b'((rate/6000U)?(rate/6000U):1U)*9360U')
 b=b.replace(b'((hz+5999U)/6000U)*9360U',b'((hz/6000U)?(hz/6000U):1U)*9360U')
 (N/name).write_bytes(b)
for name in ('np_ble_preview.h','xe_np_online_impl.h','np_sd_fast_crc.h'):shutil.copyfile(A/name,N/name)
receipt=dict(status='STAGED_ONLY',parent_app='5F90FD3B',parent_usb='C91871BD',originals=pins,
              staged={str(p):sha(p) for p in A.iterdir()},
              scope='Only semantic change: LFP native decimation floor/AP6000, max1. Includes preserve exact inherited implementation/order; no resampler, NP/IMU buffers or CL exclusion changes.')
(T/'app-source-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('V1 APP source staged; floor LFP rates625/625/555.556/500Hz; no firmware compilation.')
