#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include <limits.h>
#define __attribute__(x)
#include "xe_np_sd_info.h"
typedef struct {uint8_t bmRequest,bRequest;uint16_t wValue,wIndex,wLength;} XE_NP_UsbSetup;
typedef struct {uint32_t unused;} PCD_HandleTypeDef;
static struct {uint32_t STA,IDMACTRL;} sd_regs;
#define SDMMC1 (&sd_regs)
#define SDMMC_STA_DPSMACT 1U
#define SDMMC_STA_CPSMACT 2U
#define SDMMC_IDMA_IDMAEN 1U
#define HAL_SD_STATE_READY 1U
static struct {uint32_t CID[4],State;struct{uint32_t LogBlockNbr;}SdCard;}hsd1;
static struct {uint32_t configured,streaming,real_start_pending,tx_busy,tx_pending;}xe_np_usb_state;
static struct {uint32_t target;}np_v1_mode;
static uint32_t np_usb_sd_prepare_pending,np_download_state,np_download_burst_armed,xe_np_usb_v1_restart_pending,np_usb_sd_ready;
static uint32_t flags[8],mode,ready,stalls,statuses,sends,board_calls,reinit_calls,primask,hw_mutations;
static uint32_t board_error,restore_error,changed,make_busy,cancel_during;
static unsigned checks;
#define CHECK(x) do{checks++;assert(x);}while(0)
static int NP_USB_IsDownload(void){return mode==3;}
static int NP_USB_IsReady(void){return (int)ready;}
static int np_v1_sd_reset_busy(void){return (int)flags[0];}
static int NP_ConfigTransferPending(void){return (int)flags[1];}
static int np_usb_format_owned(void){return (int)flags[2];}
static int np_usb_catalog_owned(void){return (int)flags[3];}
static int NP_V1UsbJob_Owns(void){return (int)flags[4];}
static int NP_V1UsbJob_ModeFence(void){return (int)flags[5];}
static uint32_t HAL_GetTick(void){return 1234;}
static uint32_t __get_PRIMASK(void){return primask;}
static void __disable_irq(void){primask=1;}
static void __set_PRIMASK(uint32_t p){primask=p;}
#define __DMB() ((void)0)
static void XE_NP_UsbStream_Stall(PCD_HandleTypeDef *p){(void)p;stalls++;}
static void XE_NP_UsbStream_CtlStatus(PCD_HandleTypeDef *p){(void)p;statuses++;}
static int XE_NP_UsbStream_CtlSend(PCD_HandleTypeDef *p,const uint8_t *b,uint32_t n,uint32_t z){(void)p;CHECK(n==384&&z==384);CHECK(((const XE_NP_SdInfo*)b)->magic==XE_NP_SD_INFO_MAGIC);sends++;return 0;}
static int NP_USB_ReinitializeSd(void){reinit_calls++;hw_mutations++;if(restore_error)return -1;hsd1.State=HAL_SD_STATE_READY;hsd1.SdCard.LogBlockNbr=100000;if(changed)hsd1.CID[0]++;if(make_busy)sd_regs.STA=1;return 0;}
#include "np_sd_info_v1_service.inc"
void XE_NP_Board_ReadSdInfo(XE_NP_SdInfo *p){board_calls++;hw_mutations++;uint32_t seq=p->sequence;XE_NP_SdInfoInit(p,seq);p->state=board_error?3:2;p->error=board_error;p->flags=1;p->sectors_low=100000;for(unsigned i=0;i<16;i++)p->cid[i]=(uint8_t)(hsd1.CID[i/4]>>(24-8*(i%4)));np_usb_sd_ready=0;if(cancel_during)np_usb_sd_info_cancel();}
static void reset(void){memset(&hsd1,0,sizeof(hsd1));memset(&sd_regs,0,sizeof(sd_regs));memset(flags,0,sizeof(flags));memset(&np_info_cache,0,sizeof(np_info_cache));memset(&np_info_ep0,0,sizeof(np_info_ep0));np_info_initialized=np_info_pending=np_info_cancelled=0;memset(&xe_np_usb_state,0,sizeof(xe_np_usb_state));xe_np_usb_state.configured=ready=1;mode=3;np_v1_mode.target=0;np_usb_sd_prepare_pending=np_download_state=np_download_burst_armed=xe_np_usb_v1_restart_pending=0;hsd1.CID[0]=0x12345678;hsd1.State=1;hsd1.SdCard.LogBlockNbr=100000;np_usb_sd_ready=1;board_error=restore_error=changed=make_busy=cancel_during=0;stalls=statuses=sends=board_calls=reinit_calls=hw_mutations=primask=0;}
static void get(void){XE_NP_UsbSetup q={0xc0,0xa5,0,0,384};CHECK(np_usb_sd_info_request(0,&q)==1);}
static void submit(uint16_t token){XE_NP_UsbSetup q={0x40,0xa6,token,0,0};CHECK(np_usb_sd_info_request(0,&q)==1);}
int main(void){
 reset();get();CHECK(np_info_cache.state==0&&board_calls==0&&hw_mutations==0);CHECK(np_info_cache.checks[2].argument==0xff0ff3);
 submit(17);CHECK(statuses==1&&np_info_cache.state==1&&np_info_cache.sequence==17&&np_info_pending==1&&board_calls==0);
 get();CHECK(np_info_ep0.state==1&&np_info_ep0.sequence==17&&hw_mutations==0);submit(18);CHECK(stalls==1&&np_info_cache.sequence==17);
 CHECK(np_usb_sd_info_service()==1);CHECK(np_info_cache.state==2&&np_info_cache.sequence==17&&np_info_pending==0&&np_usb_sd_ready==1&&reinit_calls==1&&board_calls==1);
 unsigned old=hw_mutations;get();get();CHECK(hw_mutations==old&&np_info_cache.state==2);
 submit(18);CHECK(np_info_cache.state==1&&np_info_cache.flags==0&&np_info_cache.cid[0]==0);board_error=0x44;CHECK(np_usb_sd_info_service()==1);CHECK(np_info_cache.state==3&&np_info_cache.error==0x44&&np_info_cache.sequence==18&&np_usb_sd_ready);
 for(unsigned i=0;i<20;i++){reset();switch(i){case 0:mode=2;break;case 1:ready=0;break;case 2:xe_np_usb_state.configured=0;break;case 3:np_v1_mode.target=1;break;case 4:np_usb_sd_prepare_pending=1;break;case 5:flags[0]=1;break;case 6:flags[1]=1;break;case 7:np_download_state=1;break;case 8:np_download_burst_armed=1;break;case 9:xe_np_usb_state.streaming=1;break;case 10:xe_np_usb_state.real_start_pending=1;break;case 11:xe_np_usb_state.tx_busy=1;break;case 12:xe_np_usb_state.tx_pending=1;break;case 13:xe_np_usb_v1_restart_pending=1;break;case 14:flags[2]=1;break;case 15:flags[3]=1;break;case 16:flags[4]=1;break;case 17:flags[5]=1;break;case 18:sd_regs.STA=1;break;default:sd_regs.IDMACTRL=1;break;}submit(1);CHECK(stalls==1&&statuses==0&&!np_info_pending&&!hw_mutations);get();CHECK(sends==1&&!hw_mutations);}
 reset();submit(0);CHECK(stalls==1&&!np_info_pending);
 reset();submit(7);restore_error=1;np_usb_sd_info_service();CHECK(np_info_cache.state==3&&np_info_cache.error==NP_INFO_ERROR_RESTORE&&!np_info_cache.flags&&!np_usb_sd_ready);
 reset();submit(9);changed=1;np_usb_sd_info_service();CHECK(np_info_cache.state==3&&np_info_cache.error==NP_INFO_ERROR_CARD_CHANGED&&!np_info_cache.flags);
 reset();submit(11);make_busy=1;np_usb_sd_info_service();CHECK(np_info_cache.state==3&&np_info_cache.error==NP_INFO_ERROR_RESTORE&&np_info_pending==2);old=hw_mutations;np_usb_sd_info_service();CHECK(hw_mutations==old&&np_usb_sd_info_owned());get();CHECK(np_info_ep0.state==3);
 reset();submit(12);np_usb_sd_info_cancel();np_usb_sd_info_service();CHECK(np_info_cache.state==3&&np_info_cache.error==NP_INFO_ERROR_CANCELLED&&board_calls==0&&reinit_calls==0&&!np_info_pending);
 reset();submit(13);cancel_during=1;np_usb_sd_info_service();CHECK(np_info_cache.state==3&&np_info_cache.error==NP_INFO_ERROR_CANCELLED&&reinit_calls==1&&!np_info_pending);
 reset();primask=1;submit(14);np_usb_sd_info_service();CHECK(primask==1);
 for(unsigned app=0;app<2;app++)for(unsigned cmd=0;cmd<64;cmd++)for(unsigned size=0;size<=64;size++){
  int wanted=app?(cmd==51&&size==8)||(cmd==13&&size==64):(cmd==6&&size==64);
  CHECK(XE_NP_SdInfoReadAllowed(app,cmd,app?0:0xffffff,size)==wanted);
 }
 CHECK(!XE_NP_SdInfoReadAllowed(0,6,0x80ffffff,64));CHECK(!XE_NP_SdInfoReadAllowed(0,24,0xffffff,64));CHECK(!XE_NP_SdInfoReadAllowed(0,32,0xffffff,64));
 printf("PASS %u checks: passivecache/role3admission/sequence/busy/restoreCID/error/noEP0I/O/cancel/physicalhold/readallowlist\n",checks);
 return 0;
}
