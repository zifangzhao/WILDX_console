from pathlib import Path
import hashlib,json,re,subprocess
T=Path(__file__).resolve().parent;B=T/'build-app';B.mkdir(exist_ok=True);assert not any(B.iterdir());P=Path('D:/Code/WILDX_console/WILDX_console/_artifacts/v1-cl-warm/candidate-corrected/app')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
r=json.loads((P/'provider-compile.json').read_text());args=list(r['args'])
old=P.parent/'app-provider.c';assert args.count(str(old))==1
args[args.index(str(old))]=str(T/'app-source/provider.c');args[args.index('-o')+1]=str(B/'provider.o')
assert not any('../' in arg or '..\\' in arg for arg in args),'Compile requires its original relative cwd'
run=subprocess.run(args,cwd=T/'app-source',capture_output=True,text=True)
(B/'compile.log').write_text(run.stdout+run.stderr);assert run.returncode==0,run.stdout+run.stderr
lnp=(P/'candidate.lnp').read_text();oldobj=(P/'provider.o').as_posix();assert lnp.count(oldobj)==1
lnp=lnp.replace(oldobj,(B/'provider.o').as_posix())
lnp=re.sub(r'--list\s+"[^"]+"','--list "'+(B/'candidate.map').as_posix()+'"',lnp)
lnp=re.sub(r'-o\s+"[^"]+"','-o "'+(B/'candidate.axf').as_posix()+'"',lnp)
(B/'candidate.lnp').write_text(lnp)
objects=[Path(s) for s in re.findall(r'"([^"]+\.o)"',lnp) if Path(s)!=B/'provider.o']
receipt=dict(status='APP_COMPILED_PENDING_LINK',parent_app_crc32='5F90FD3B',compiler_command=args,
 source=str(T/'app-source/provider.c'),source_sha256=sha(T/'app-source/provider.c'),
 changed_header_sha256=sha(T/'app-source/np_ble_preview.h'),provider_object_sha256=sha(B/'provider.o'),
 retained_objects={str(p):sha(p) for p in objects},native_preview_receipt_sha256=sha(T/'native-preview/receipt.json'))
(B/'pending.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(status=receipt['status'],object_sha256=receipt['provider_object_sha256'],retained_objects=len(objects)),indent=2))
