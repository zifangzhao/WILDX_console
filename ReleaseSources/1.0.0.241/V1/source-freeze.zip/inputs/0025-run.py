from pathlib import Path
import hashlib,json,subprocess
N=Path(__file__).resolve().parent;U=N.parent/'usb-source'
vc='C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat'
cmd='call "'+vc+'" >nul && cl /nologo /std:c11 /W4 /WX /TC /O2 /I"'+str(U)+'" fixture.c /Fe:sdinfo.exe'
r=subprocess.run('cmd /d /s /c "'+cmd+'"',cwd=N,capture_output=True,text=True);(N/'compile.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
r=subprocess.run([str(N/'sdinfo.exe')],cwd=N,capture_output=True,text=True);(N/'result.txt').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
receipt=dict(status='PASS',command=cmd,result=r.stdout,source_sha256=sha(U/'np_sd_info_v1_service.inc'),wire_header_sha256=sha(U/'xe_np_sd_info.h'),fixture_sha256=sha(N/'fixture.c'),hardware_access=False,
 scope='Actual cache/admission/service implementation with mocked existingV1host restore and physicalquery; verifies callbacks do noSDwork, restore/card/cancel/undrained guards and pure commandallowlist. LowlevelFIFO I/O stillneedsfocusedHIL.')
(N/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
