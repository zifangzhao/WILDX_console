/* One actual-header regression, including the unchanged legacy preview tests. */
#define _CRT_SECURE_NO_WARNINGS
#define main legacy_main
#include "test_v2_protocols.c"
#undef main
#include <stdlib.h>

static uint32_t compact_phase;
static FILE *vectors;
static unsigned packets,checks;
#define CHECK(x) do {assert(x);checks++;} while(0)

static uint8_t compact_byte(uint64_t tick)
{
    uint64_t shifted=tick+4096ULL*9360U-compact_phase;
    unsigned sf=(unsigned)(shifted/780U%12U),f=(unsigned)(shifted%780U/60U);
    unsigned word=(unsigned)(shifted%60U/10U),bit=9U-(unsigned)(shifted%10U);
    uint8_t value=0;
    for(unsigned adc=0;adc<32;adc++){
        unsigned w=adc<30U?adc%5U:adc-30U,line=adc<30U?adc/5U+1U:7U;
        unsigned code=(adc*12U+(f?f-1U:sf)+(unsigned)(shifted/780U%23U)*17U)&1023U;
        if(w==word && ((code>>bit)&1U))value|=(uint8_t)(1U<<line);
    }
    return value;
}
static void compact_fill(uint64_t first,unsigned ticks,unsigned packed,unsigned probe)
{
    memset(raw,0xcc,sizeof(raw));
    for(unsigned i=0;i<ticks;i++){
        unsigned at=(i&3U)*15360U+(i>>2)*(packed?2U:1U)+(packed?probe-1U:0U);
        raw[at]=compact_byte(first+i);
    }
}
static uint32_t crc220(const uint8_t *p)
{
    uint32_t c=~0U;for(unsigned i=0;i<220;i++){c^=p[i];for(unsigned j=0;j<8;j++)c=(c>>1)^((0U-(c&1U))&0xedb88320U);}return ~c;
}
static unsigned get16(const uint8_t *p){return (unsigned)p[0]|((unsigned)p[1]<<8);}
static void compact_request(unsigned kind,const unsigned channels[4],unsigned count,unsigned band,unsigned probe)
{
    request(kind,channels[0],band,probe);xe_np_online_put(wire+24,compact_phase);
    xe_np_online_put(wire+36,count);for(unsigned i=1;i<count;i++)xe_np_online_put(wire+36U+4U*i,channels[i]);
    xe_np_online_put(wire+60,xe_np_online_crc(wire));
}
static void check_packet(const unsigned channels[4],unsigned count,unsigned band,unsigned probe,unsigned rate)
{
    uint64_t first=xe_np_online_word(body+16)|((uint64_t)xe_np_online_word(body+20)<<32);
    uint32_t stride=xe_np_online_word(body+192),period=band?9360U:780U;
    CHECK(xe_np_online_word(body+24)==((128U<<16)|16U));
    CHECK(xe_np_online_word(body+28)==(probe|(5U<<8)|(band<<12)|(channels[0]<<16)));
    CHECK(xe_np_online_word(body+200)==count && xe_np_online_word(body+204)==1U);
    CHECK(xe_np_online_word(body+208)==0 && xe_np_online_word(body+212)==0 && xe_np_online_word(body+216)==0);
    CHECK(xe_np_online_word(body+220)==crc220(body));
    CHECK(stride==(band?((rate/6000U)?(rate/6000U):1U)*9360U:((rate+499U)/500U)*780U));
    for(unsigned c=0;c<4;c++){
        CHECK(get16(body+160U+c*2U)==(c<count?channels[c]:0U));
        unsigned mask=get16(body+168U+c*2U);uint32_t offset=xe_np_online_word(body+176U+c*4U);
        if(c>=count){CHECK(mask==0 && offset==0);for(unsigned row=0;row<16;row++)CHECK(get16(body+32U+c*32U+row*2U)==0);continue;}
        CHECK(mask==65535U);CHECK(offset<period && (!c?offset==0:1));
        unsigned ch=channels[c],adc=(ch/24U)*2U+(ch&1U),slot=(ch%24U)/2U;
        unsigned off=(band?slot*780U:(slot+1U)*60U)+(adc<30U?adc%5U:adc-30U)*10U;
        CHECK((first+offset)%period==(compact_phase+off)%period);
        for(unsigned row=0;row<16;row++){
            uint64_t tick=first+offset+(uint64_t)row*stride,shifted=tick+4096ULL*9360U-compact_phase;
            unsigned expected=(adc*12U+slot+(unsigned)(shifted/780U%23U)*17U)&1023U;
            CHECK(get16(body+32U+c*32U+row*2U)==expected);
        }
    }
    if(vectors)CHECK(fwrite(body,1,sizeof(body),vectors)==sizeof(body));packets++;
}
int main(int argc,char **argv)
{
    CHECK(legacy_main()==0);
    if(argc==2){vectors=fopen(argv[1],"wb");CHECK(vectors!=NULL);}
    CHECK(sizeof(NpBlePreview)<=1840U); /* APP had240B SRAM margin; new state <=136B. */
    const unsigned selections[3][4]={{0,24,25,383},{383,0,191,192},{25,0,0,0}};
    const unsigned rates[4]={7500,15000,20000,30000};
    for(unsigned packed=0;packed<2;packed++)for(unsigned probe=1;probe<=(packed?2U:3U);probe++)
    for(unsigned band=0;band<2;band++)for(unsigned ri=0;ri<4;ri++)for(unsigned si=0;si<3;si++){
        const unsigned *channels=selections[si];unsigned count=si==2?1U:4U;
        unsigned ticks=packed?30720U:61440U;uint64_t first=ri==3?(1ULL<<40):0;
        compact_phase=(17U+ri*37U)%780U;NpBlePreview p={0};
        compact_request(5,channels,count,band,probe);CHECK(np_ble_preview_request(&p,wire,42,rates[ri],7,1,100)&&p.active);
        for(unsigned chunk=0;!p.ready;chunk++){CHECK(chunk<50U);compact_fill(first,ticks,packed,probe);np_ble_preview_tap(&p,raw,first,ticks,packed,probe,0);first+=ticks;}
        np_ble_preview_fragment(&p,body);check_packet(channels,count,band,probe,rates[ri]);np_ble_preview_retire(&p);
        /* Old zero-tail renew cannot change/extend a compact selection. */
        request(4,channels[0],band,probe);xe_np_online_put(wire+24,compact_phase);xe_np_online_put(wire+60,xe_np_online_crc(wire));
        uint32_t lease=p.lease;CHECK(np_ble_preview_request(&p,wire,42,rates[ri],7,1,800)&&p.lease==lease);
        compact_request(4,channels,count,band,probe);CHECK(np_ble_preview_request(&p,wire,42,rates[ri],7,1,900)&&p.lease==2900U);
        compact_request(3,channels,count,band,probe);CHECK(np_ble_preview_request(&p,wire,42,rates[ri],7,1,950)&&!p.active);
    }
    /* Reject malformed requests without destroying a live or old selection. */
    unsigned channels[4]={0,24,25,383};NpBlePreview p={0};compact_phase=0;
    for(unsigned fault=0;fault<5;fault++){
        compact_request(5,channels,4,0,1);
        if(fault==0)xe_np_online_put(wire+36,5);
        if(fault==1)xe_np_online_put(wire+40,0);
        if(fault==2)xe_np_online_put(wire+44,384);
        if(fault==3)xe_np_online_put(wire+52,1);
        if(fault==4)wire[60]^=1;
        if(fault!=4)xe_np_online_put(wire+60,xe_np_online_crc(wire));
        CHECK(np_ble_preview_request(&p,wire,42,20000,3,1,0)&&!p.active);
    }
    compact_request(5,channels,4,0,1);np_ble_preview_request(&p,wire,42,20000,3,1,0);
    for(unsigned chunk=0;chunk<20;chunk++){compact_fill(chunk*61440ULL,61440,0,1);np_ble_preview_tap(&p,raw,chunk*61440ULL,61440,0,1,1);}
    CHECK(!p.ready && p.dropped); /* pressure cannot invent a zero-valued acquired sample */
    uint64_t first=20ULL*61440;for(unsigned chunk=0;!p.ready;chunk++){
        CHECK(chunk<20);compact_fill(first,61440,0,1);np_ble_preview_tap(&p,raw,first,61440,0,1,0);first+=61440;
    }
    np_ble_preview_fragment(&p,body);CHECK(xe_np_online_word(body+220)==crc220(body));
    for(unsigned c=0;c<4;c++)for(unsigned row=0;row<16;row++)if(!(get16(body+168+c*2)&(1U<<row)))CHECK(get16(body+32+c*32+row*2)==0);
    np_ble_preview_retire(&p);
    /* Full queue drops only preview; discontinuity discards partial words. */
    for(unsigned chunk=0;p.queued<NP1_PREVIEW_SLOTS;chunk++){
        CHECK(chunk<100);compact_fill(first,61440,0,1);np_ble_preview_tap(&p,raw,first,61440,0,1,0);first+=61440;
    }
    unsigned dropped=p.dropped;np_ble_preview_tap(&p,raw,first,61440,0,1,0);CHECK(p.queued==4 && p.dropped>dropped);
    while(p.queued)np_ble_preview_retire(&p);
    first+=61440;for(unsigned chunk=0;!p.ready;chunk++){CHECK(chunk<20);compact_fill(first,61440,0,1);np_ble_preview_tap(&p,raw,first,61440,0,1,0);first+=61440;}
    np_ble_preview_fragment(&p,body);check_packet(channels,4,0,1,20000);
    if(vectors)CHECK(fclose(vectors)==0);
    printf("PASS compact preview: %u checks, %u vector packets; state=%u bytes; legacy unchanged\n",checks,packets,(unsigned)sizeof(NpBlePreview));
    return 0;
}
