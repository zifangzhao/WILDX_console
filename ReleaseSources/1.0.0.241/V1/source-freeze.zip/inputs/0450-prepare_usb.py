from pathlib import Path
import hashlib,json
T=Path(__file__).resolve().parent;U=T/'usb-source'
P=Path('C:/Frank/Code/XE_NP/_artifacts/closed_loop_qualification_20261104/V1/source-freeze/usb-stream.c')
M=Path('C:/Frank/Code/XE_NP/_artifacts/v1_usb_sd_job_20261030/usb_stage_cold_r1/modes.inc')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
s=P.read_text()
def once(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b,1)
prefix='#define NP_USB_SD_INFO_CAPABILITY 0x00020000U\nstatic int np_usb_sd_info_owned(void);\nstatic void np_usb_sd_info_cancel(void);\n'
s=prefix+s
once('#include "'+M.as_posix()+'"','#include "'+(U/'modes.inc').as_posix()+'"')
seam='#include "C:/Frank/Code/XE_NP/Firmware/V1/Core/Src/np_usb_sd_job_platform.inc"'
once(seam,seam+'\n#include "'+(U/'xe_np_sd_info.h').as_posix()+'"\n#include "'+(U/'np_sd_info_v1_port.inc').as_posix()+'"\n#include "'+(U/'np_sd_info_v1_service.inc').as_posix()+'"')
once('    if(np_usb_sd_job_request(hpcd,req))return;','    if(np_usb_sd_info_request(hpcd,req))return;\n    if(np_usb_sd_info_owned()){XE_NP_UsbStream_Stall(hpcd);return;}\n    if(np_usb_sd_job_request(hpcd,req))return;')
seam='    if(hpcd==xe_np_usb_state.hpcd)np_usb_sd_job_cancel();'
assert s.count(seam)==3
s=s.replace(seam,'    if(hpcd==xe_np_usb_state.hpcd){np_usb_sd_info_cancel();np_usb_sd_job_cancel();}')
seam='''    if(NP_USB_IsReady() && NP_USB_IsDownload() && !np_usb_sd_prepare_pending && !np_usb_format_owned()) {
        if(!NP_V1UsbJob_PlatformReady())'''
assert s.count(seam)==2
s=s.replace(seam,'''    if(NP_USB_IsReady() && NP_USB_IsDownload() && !np_usb_sd_prepare_pending && !np_usb_format_owned()) {
        if(np_usb_sd_info_service())return;
        if(!NP_V1UsbJob_PlatformReady())''')
(U/'stream.c').write_text(s)
m=M.read_text();assert m.count('    if(NP_V1UsbJob_ModeFence())return 1;')==1
m=m.replace('    if(NP_V1UsbJob_ModeFence())return 1;','    if(np_usb_sd_info_owned())return 1;\n    if(NP_V1UsbJob_ModeFence())return 1;')
seam='15U|(NP_USB_RomDfuAvailable()?16U:0U)|NP_USB_CATALOG_CAPABILITY|'
assert m.count(seam)==1;m=m.replace(seam,seam+'NP_USB_SD_INFO_CAPABILITY|')
(U/'modes.inc').write_text(m)
h=Path('D:/Code/XE_NP_V2/Core/Inc/xe_np_sd_info.h');(U/'xe_np_sd_info.h').write_bytes(h.read_bytes())
receipt=dict(status='STAGED',parent_usb_crc32='C91871BD',expected_app_crc32='D05473D6',
  originals={str(P):sha(P),str(M):sha(M),str(h):sha(h)},
  staged={str(p):sha(p) for p in U.iterdir() if p.is_file()},
  protocol='A5 IN384 passive bothroles;A6 OUT0 sequence16 idle role3 only;cap0x20000. Legacy4B/4C unchanged. USBdeletecap0x40000 absent.',
  scope='No cardwrites/newNP buffers/stream-clock changes. Existing stopped V1 reinit before/after pure SD info reads; samecard restored proof. Idle-download foreground hook only; pending operation fences vendor/mode ownership and bus cancel.')
(T/'usb-source-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('V1USB maintenance staged; no firmware compilation.')
