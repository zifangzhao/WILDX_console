"""Actual cold geometry, SpiInit, Service, Offer; no firmware build/device I/O."""
from pathlib import Path
import hashlib,json,subprocess,re
BASE=Path(__file__).resolve().parents[1];OUT=Path(__file__).resolve().parent/'restart-geometry';OUT.mkdir(exist_ok=True)
SRC=BASE/'Core/Src/xe_np_np2_cl_selected.c';SPI=BASE/'Core/Src/xe_np_np2_closed_loop_spi.c'
VC=Path('C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def extract(s,signature):
 at=s.index(signature);b=s.index('{',at);end=b+1;depth=1
 while depth:depth+=(s[end]=='{')-(s[end]=='}');end+=1
 return s[at:end]+'\n'
def main():
 s=SRC.read_text();spi=SPI.read_text()
 geometry=s[s.index('    uint32_t lo=UINT32_MAX'):s.index('    cal[0]=5U;')]
 # Actual geometry statement bytes are unchanged; only local inputs and the
 # output observation/ordinary existing error label are fixture wrappers.
 actual='static int actual_geometry(uint32_t phase,int32_t d){\n'+geometry+'\n gframe=frame;gend=end;gprefix=prefix;return 1;bad:return 0;\n}\n'
 actual+=spi[spi.index('static const int32_t coeff[41]'):spi.index('static void reset_filter(')]
 actual+='\n'.join(extract(spi,x) for x in ('static void reset_filter(', 'int XE_NP_Np2ClosedLoopSpi_Init(', 'void XE_NP_Np2ClosedLoopSpi_Gap(', 'uint32_t XE_NP_Np2ClosedLoopSpi_Service('))
 (OUT/'actual.inc').write_text(actual)
 pre=r'''
#include <assert.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <limits.h>
#include "xe_np_np2_closed_loop_spi.h"
#define BOOT_WORDS 3072U
static uint16_t channels[2],offsets[2];static uint8_t count,field_bits[2];
static uint32_t gframe,gend,gprefix;
#include "actual.inc"
static unsigned raw(uint32_t row,uint32_t ch){return 1984U+(row*17U+ch*31U)%128U;}
int main(){
 unsigned long long geometries=0,scalar=0,services=0;
 XE_NP_Np2ClosedLoopSpi state;
 const unsigned picks[4][2]={{0,1},{1,0},{0,0},{1,1}};
 for(unsigned phase=0;phase<1600;phase++)for(unsigned pick=0;pick<4;pick++){
  count=pick<2?2:1;channels[0]=(uint16_t)picks[pick][0];channels[1]=(uint16_t)picks[pick][1];
  unsigned header=(1600-phase)%1600;
  XE_NP_Np2ClosedLoopSpiConfig cfg={0};cfg.phase=(uint16_t)phase;cfg.phase_verified=cfg.origin_valid=1;
  cfg.source_epoch=1;cfg.count=count;cfg.channel[0]=channels[0];cfg.channel[1]=channels[1];cfg.probe=2;cfg.lane=0;cfg.sample_hz=20000;
  assert(!XE_NP_Np2ClosedLoopSpi_Init(&state,&cfg));
  for(unsigned i=0;i<count;i++)assert(state.offset[i]==header+4+channels[i]*12);
  for(int d=-1600;d<1600;d++){
   assert(actual_geometry(phase,d));geometries++;
   assert(gprefix>0 && gprefix<=3200 && !(gprefix&31));assert(gend>=BOOT_WORDS*32+1600);
   for(unsigned i=0;i<count;i++)assert(offsets[i]==state.offset[i]);
   // Every signed delta and phase checked, with independently placed scalar
   // source/header bits at same-row ADC fields. Never a per-field modulo.
   uint64_t chronological=0;unsigned base=gend-64;
   for(unsigned i=0;i<count;i++){
    int64_t at=(int64_t)header+(int64_t)gframe*1600+4+channels[i]*12+d-base;
    assert(at>=0 && at+12<=64);
    unsigned v=raw(gframe,channels[i]);
    for(unsigned b=0;b<12;b++)if(v&(1U<<(11-b)))chronological|=1ULL<<(63-(unsigned)at-b);
   }
   for(unsigned i=0;i<count;i++){
    unsigned got=(unsigned)(chronological>>(52-field_bits[i]))&4095;
    assert(got==raw(gframe,channels[i]));scalar++;
   }
  }
  // Actual Service output metadata must agree with the same DAT header row,
  // including unwrapped end beyond the global1600 boundary.
  assert(actual_geometry(phase,150));
  state.initialized=1;
  for(unsigned base=0;base<512;base+=64){
   for(unsigned row=base;row<base+64;row++){
    XE_NP_Np2ClosedLoopSpiRow *r=&state.input[row%NP2_CL_SPI_INPUT_ROWS];r->frame_tick=(uint64_t)(gframe+row)*1600;
    r->word[0]=(uint16_t)raw(gframe+row,channels[0]);r->word[1]=(uint16_t)raw(gframe+row,channels[1]);
   }
   state.in_head=(uint16_t)(base+64);
   while(state.in_tail!=state.in_head)assert(XE_NP_Np2ClosedLoopSpi_Service(&state,NP2_CL_SPI_SERVICE_ROWS));
   while(state.out_tail!=state.out_head){
    const XE_NP_Np2ClosedLoopSpiOutput *r=&state.output[state.out_tail%NP2_CL_SPI_OUTPUT_ROWS];
    uint64_t tick=r->source_tick+state.delay_source_ticks;
    unsigned max=header+4+12*(count==2?1:channels[0]);
    assert(r->input_end_tick==tick+max+12);assert(r->source_epoch==1);services++;state.out_tail++;
   }
  }
  assert(state.output_rows>0 && !state.queue_overflows && !state.gap_events);
  // Historical P3 software tap is unchanged and retains its modulo mapping.
  cfg.probe=3;cfg.lane=2;cfg.channel[0]+=256;cfg.channel[1]+=256;
  assert(!XE_NP_Np2ClosedLoopSpi_Init(&state,&cfg));
  for(unsigned i=0;i<count;i++)assert(state.offset[i]==(header+4+channels[i]*12)%1600);
 }
 printf("PASS actual geometry %llu phase/delta/count/order cases; %llu independent scalar same-DAT-row ADC words; %llu actual Service input_end/source_tick outputs; all1600phase P2/P3Init mapping\n",geometries,scalar,services);
}
'''
 (OUT/'proof.cpp').write_text(pre)
 command=f'call "{VC}" >nul && cl /nologo /std:c++17 /W4 /WX /O2 /DXE_NP_NP2_CLOSED_LOOP_SPI_ENABLE=0 /I"D:/Code/XE_NP_V2/Core/Inc" "{OUT/"proof.cpp"}" /Fo"{OUT/"proof.obj"}" /Fe"{OUT/"proof.exe"}"'
 b=subprocess.run(f'cmd /d /s /c "{command}"',capture_output=True,text=True,cwd=OUT,timeout=45)
 (OUT/'compile.log').write_text(b.stdout+b.stderr);assert not b.returncode,b.stdout+b.stderr
 r=subprocess.run([str(OUT/'proof.exe')],capture_output=True,text=True,cwd=OUT,timeout=30)
 (OUT/'run.log').write_text(r.stdout+r.stderr);assert not r.returncode,r.stdout+r.stderr
 assert SRC.read_text()==s and SPI.read_text()==spi
 receipt=dict(status='PASS',selected_source_sha256=sha(SRC),spi_source_sha256=sha(SPI),actual_extract_sha256=sha(OUT/'actual.inc'),command=command,output=r.stdout,limits='Native proof of actual extracted geometry/Init/Service with independent scalar source bits; no hardware or firmware build. Existing unchanged Offer/IRQ/HAL/cache evidence reused separately; no restart acceptance claim.')
 (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(r.stdout,end='');print('receiptSHA256 '+sha(OUT/'receipt.json'))
if __name__=='__main__':main()


