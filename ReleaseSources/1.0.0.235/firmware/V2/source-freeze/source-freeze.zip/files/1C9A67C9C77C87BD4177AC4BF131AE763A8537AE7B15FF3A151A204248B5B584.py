"""Bounded independent12KiB SPI bootstrap / first128DAT-row comparison."""
from pathlib import Path
import collections,hashlib,json,struct

BASE=Path(__file__).resolve().parents[2]
RUN=BASE/'sd-r3-cl1';EXPORT=RUN/'export';OUT=Path(__file__).resolve().parent
SYNC=(0xD3,0x6A,0x59,0xC5,0x3E,0xA7,0x1D,0xE4,0xB2,0x4F,0x78,0x96)
def hash_bytes(b):return hashlib.sha256(b).hexdigest().upper()
def expected_sync(frame,bit,lane):
    if bit==0:return int(frame==0)
    if bit==1:return 0
    at=frame*6+lane*2+bit-2
    return (SYNC[at//8]>>(at%8))&1
def main():
    blob=(RUN/'spi1-bootstrap.bin').read_bytes();assert len(blob)==12288
    words=struct.unpack('<3072I',blob)
    streams={'MSB-first32':'','LSB-first32':''}
    streams['MSB-first32']=''.join(f'{w:032b}' for w in words)
    streams['LSB-first32']=''.join(f'{w:032b}'[::-1] for w in words)
    sync=[]
    for order,bits in streams.items():
        for lane in range(3):
            scores=[]
            for phase in range(1600):
                score=0
                for frame in range(16):
                    for bit in range(4):
                        start=(frame*100+bit-phase)%1600
                        for period in range(3):score+=int(bits[start+period*1600])==expected_sync(frame,bit,lane)
                scores.append((score,phase))
            scores.sort(reverse=True)
            sync.append(dict(order=order,lane=lane,best_score=scores[0][0],best_phases=[p for s,p in scores if s==scores[0][0]],runner_score=next((s for s,p in scores if s<scores[0][0]),None)))
    perfect=[(s['order'],s['lane'],phase) for s in sync if s['best_score']==192 for phase in s['best_phases']]
    assert len(perfect)==1,perfect
    order,wire_lane,spi_phase=perfect[0];bits=streams[order]
    metadata=json.loads((EXPORT/'first_sample_timestamps.json').read_text())
    datas={};files=[]
    for probe in range(1,4):
        path=EXPORT/f'neuropixels_probe{probe}_ap.dat'
        with path.open('rb') as f:prefix=f.read(128*384*2)
        assert len(prefix)==128*384*2
        row=next(r for r in metadata['rows'] if r['probe']==probe and r['band']=='ap')
        datas[probe]=(struct.unpack('<49152h',prefix),row['decoder_first_row_source_tick'])
        files.append(dict(path=str(path),read_bytes=len(prefix),prefix_sha256=hash_bytes(prefix),
                          data_transform='raw12 = 2048 - signed_nominal_DAT; calibration=null'))
    def compare(order,probe,lane,delta,shift=0,limit=128):
        bitstream=streams[order];data,first=datas[probe];good=bad=0;rows=set();first_bad=None;channels=set()
        for sample in range(limit):
            for local in range(128):
                pos=(local%32)//2*100+4+((local//32)*2+(local&1))*12
                at=first+sample*1600+pos+delta
                if at<0 or at+12>len(bitstream):continue
                raw=int(bitstream[at:at+12],2)
                expected=2048-data[sample*384+lane*128+(local+shift)%128]
                rows.add(sample);channels.add(local)
                if raw==expected:good+=1
                else:
                    bad+=1
                    if first_bad is None:first_bad=dict(sample=sample,channel=lane*128+local,spi_bit=at,expected=expected,actual=raw)
        return dict(order=order,probe=probe,dat_lane=lane,spi_minus_pssi_bits=delta,wrong_channel_shift=shift,
            compared_words=good+bad,matched_words=good,mismatched_words=bad,rows_compared=len(rows),
            first_row=min(rows) if rows else None,last_row=max(rows) if rows else None,
            channel_count=len(channels),first_mismatch=first_bad)
    candidates=[]
    # Header phase determines bit offset modulo1600; test both signs and
    # whole-frame displacement, then all physical DAT lanes/probes.
    for probe in range(1,4):
        _,first=datas[probe];phase=(-first)%1600;mod=(phase-spi_phase)%1600
        for lane in range(3):
            for delta in sorted({sign*mod+n*1600 for sign in (-1,1) for n in range(-6,7)}):
                candidates.append(compare(order,probe,lane,delta))
    exact=[c for c in candidates if c['compared_words']>=4096 and not c['mismatched_words']]
    assert len(exact)==1,exact
    hit=exact[0];negatives=[compare('LSB-first32',hit['probe'],hit['dat_lane'],hit['spi_minus_pssi_bits']),
        compare(order,hit['probe'],hit['dat_lane'],hit['spi_minus_pssi_bits'],shift=1),
        compare(order,hit['probe'],hit['dat_lane'],hit['spi_minus_pssi_bits']+1600),
        compare(order,hit['probe'],hit['dat_lane'],hit['spi_minus_pssi_bits']-1600),
        compare(order,1,hit['dat_lane'],hit['spi_minus_pssi_bits']),
        compare(order,3,hit['dat_lane'],hit['spi_minus_pssi_bits'])]
    assert all(c['mismatched_words'] for c in negatives)
    result=dict(status='UNIQUE_EXACT_MATCH',bootstrap=dict(path=str(RUN/'spi1-bootstrap.bin'),bytes=len(blob),sha256=hash_bytes(blob)),
        dat_prefixes=files,super_sync=sync,exact_match=hit,candidate_count=len(candidates),
        near_candidates=sorted(candidates,key=lambda c:(c['mismatched_words']/max(c['compared_words'],1),-c['compared_words']))[:12],
        negative_controls=negatives,
        alignment=dict(coordinate='spi_bit_index = pssi_source_tick +146',
            spi_start_relative_to_pssi_source_zero_ticks=-146,offset_us=146/32,
            whole_frame_offset=0,wire_lane=wire_lane,hardware_word_order=order),
        limits=['Only12KiB SPI and first128rows/probe read; bootstrap contains roughly61completeframes so comparison uses only overlapping native words.',
          'Factory calibration null; direct SDK signed nominal transform only. No waveform/time/source relabeling or user data rewrite.',
          'Exact ADC identity and offset do not prove the in-firmware first256bit search saw the same initial PSSI window.',
          'Failure5 aggregates many guards; no first-call CBR1/CDAR/DWT or failure-branch marker was saved. Stopped fallback state cannot prove first-call deadline.',
          'Measured+146 is inside0..1599 currentsearch. Bootstrap deadline3.072ms; exact first-call entry/execution time remains unknown from these saved files.'])
    (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(status=result['status'],exact_match=hit,super_sync=perfect,
        negatives=[dict(order=c['order'],probe=c['probe'],lane=c['dat_lane'],delta=c['spi_minus_pssi_bits'],channel_shift=c['wrong_channel_shift'],matches=c['matched_words'],mismatches=c['mismatched_words']) for c in negatives],
        result_sha256=hash_bytes((OUT/'result.json').read_bytes())),indent=2))
if __name__=='__main__':main()
