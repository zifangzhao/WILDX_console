from pathlib import Path
import hashlib,json,re,subprocess,sys,zlib,struct
R=Path('D:/Code/XE_NP_V2');O=Path(__file__).resolve().parent/(sys.argv[1] if len(sys.argv)>1 else 'build-app');ARM=Path('C:/Keil_v5/ARM/ARMCLANG/bin')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
r=subprocess.run([str(ARM/'fromelf.exe'),'--bin','--output',str(O/'application.bin'),str(O/'application.axf')],capture_output=True,text=True);assert not r.returncode,r.stdout+r.stderr
body=(O/'application.bin').read_bytes();crc=f'{zlib.crc32(body):08X}';sp,rv=struct.unpack_from('<II',body)
assert 0x20000000<sp<=0x20300000 and rv&1 and 0x08020000<=(rv&~1)<0x08020000+len(body)
sys.path.insert(0,str(R/'Tools'));import package_xe_np_firmware as pkg
pkg.LOADER_ABI_VERSION=4;seal=pkg.build_manifest(body,generation=3,image_id=pkg.IMAGE_ID_APPLICATION,usb_auto_app=False)
(O/'application.manifest.bin').write_bytes(seal);hx=O/'V2_APP_SD_QUEUE_CANDIDATE.hex';pkg.write_intel_hex(hx,pkg.sealed_slot_memory(body,seal));hx.write_bytes(hx.read_bytes().replace(b'\r\n',b'\n'))
m=(O/'application.map').read_text(errors='replace');q=json.loads((O/'pending.json').read_text());q.update(status='SOFTWARE_CHECKED_HARDWARE_PENDING',crc32=crc,body_bytes=len(body),body_sha256=sha(O/'application.bin'),manifest_sha256=sha(O/'application.manifest.bin'),hex_sha256=sha(hx),execution_regions=re.findall(r'Execution Region[^\r\n]+',m),stack_vector=hex(sp),reset_vector=hex(rv),imu_queue_slots=512,imu_queue_tolerance_ms=409.6,scope=q.get('scope','SD APP only: cold-selected inactive CL dispatch and private IMU queue stall tolerance; unchanged format and grid schedule'))
(O/'receipt.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:q[k] for k in ['crc32','body_bytes','body_sha256','imu_queue_slots','execution_regions']},indent=2))
