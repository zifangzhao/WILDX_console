"""Bounded model proof of unwrapped P2 ADC0/1 geometry; no device access."""
from pathlib import Path
import hashlib,json,struct,time
BASE=Path(__file__).resolve().parents[2]; OUT=Path(__file__).resolve().parent
BOOT=3072*32

def sha(b): return hashlib.sha256(b).hexdigest().upper()
def geometry(phase,d,chs=(0,1)):
    h=(1600-phase)%1600
    offsets=[h+4+12*c for c in chs]
    lo=min(offsets); hi=max(offsets)+12
    frame=(BOOT-d)//1600+2
    end=((frame*1600+hi+d+31)//32)*32
    prefix=end-BOOT-1600
    adjusted=prefix>3200
    if adjusted: frame-=1;end-=1600;prefix-=1600
    assert 0<prefix<=3200 and not prefix%32
    assert end>=BOOT+1600 and end-64>=BOOT
    assert end-64<=frame*1600+lo+d
    bits=[frame*1600+o+d-(end-64) for o in offsets]
    assert all(0<=b<=52 for b in bits)
    return frame,end,prefix,offsets,bits,adjusted

def value(row,ch): return (row*97+ch*137+199)&4095

def main():
    began=time.monotonic();pairs=adjusted=0; maxprefix=0
    # Exhaustive signed physical receiver offset; phase and delta independently vary.
    for phase in range(1600):
        for d in range(-1600,1600):
            frame,end,prefix,offs,fields,a=geometry(phase,d)
            adjusted+=a;pairs+=1;maxprefix=max(maxprefix,prefix)
    scalar=0
    # Scalar chronological wire bits are formed from DAT/header rows, not the
    # extraction formula. Distinct rows/channels make frame/channel shifts fail.
    for phase in range(1600):
        h=(1600-phase)%1600
        for d in (-1600,-1599,-922,-150,-1,0,1,31,32,146,150,1598,1599):
            for chs in ((0,),(1,),(0,1),(1,0)):
                frame,end,prefix,offs,fields,_=geometry(phase,d,chs)
                for row in range(3):
                    base=end-64+row*1600
                    chronological=[0]*64
                    for ch in chs:
                        # DAT row 'frame+row' begins at global source h+1600*n.
                        wire_at=h+(frame+row)*1600+4+12*ch+d
                        raw=value(frame+row,ch)
                        for bit in range(12):chronological[wire_at-base+bit]=(raw>>(11-bit))&1
                    words=0
                    for bit in chronological:words=(words<<1)|bit
                    for i,ch in enumerate(chs):
                        got=(words>>(52-fields[i]))&4095
                        assert got==value(frame+row,ch)
                        assert got!=value(frame+row+1,ch)
                        assert base+fields[i]-d==h+(frame+row)*1600+4+12*ch
                        assert (frame+row)*1600+max(offs)+12 == h+(frame+row)*1600+max(4+12*c for c in chs)+12
                        scalar+=1
    # Actual saved failed-session bootstrap vs bounded DAT prefix.
    run=BASE/'restart-second'; export=run/'export'
    blob=(run/'spi1-bootstrap.bin').read_bytes(); assert len(blob)==12288
    bits=''.join(f'{w:032b}' for w in struct.unpack('<3072I',blob))
    meta=json.loads((export/'first_sample_timestamps.json').read_text())
    r=next(x for x in meta['rows'] if x['probe']==2 and x['band']=='ap')
    first=r['decoder_first_row_source_tick'];assert first==1591
    dat=export/'neuropixels_probe2_ap.dat'
    with dat.open('rb') as f: prefix=f.read(64*384*2)
    data=struct.unpack('<'+str(len(prefix)//2)+'h',prefix)
    matches=oldwrong=0
    for row in range(60):
        for ch in (0,1):
            at=first+row*1600+4+ch*12+150
            got=int(bits[at:at+12],2);wanted=2048-data[row*384+ch]
            assert got==wanted;matches+=1
            if ch==1:
                bad=int(bits[(row+1)*1600+7+150:(row+1)*1600+19+150],2)
                # This is intentionally the previous DAT row's ADC1.
                if bad!=wanted:oldwrong+=1
    receipt=dict(status='PASS_MODEL_AND_SAVED_PHASE9_ORACLE',model_geometry_pairs=pairs,
        normalized_prefix_cases=adjusted,max_prefix=maxprefix,scalar_native_adc_words=scalar,
        phase_count=1600,signed_delta_range=[-1600,1599],counts_and_order=[[0],[1],[0,1],[1,0]],
        actual_failed_session=dict(phase=9,delta=150,first_DAT_header=first,bootstrap_sha256=sha(blob),
          dat_prefix_bytes=len(prefix),dat_prefix_sha256=sha(prefix),exact_native_words=matches),
        correction='Common h=(1600-phase)%1600; offsets=h+ADC_field_position with no per-field modulo. Decrement initial frame and end by1600 if prefix>3200. P2 Init offsets and Service input_end must use the same unwrapped coordinates.',
        scope='Read-only arithmetic/scalar-source model plus first64 saved DAT rows. Not a compiled actual-source/firmware or hardware acceptance proof.',
        elapsed_seconds=round(time.monotonic()-began,3))
    p=OUT/'restart-geometry-review.json';p.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(dict(status=receipt['status'],pairs=pairs,normalized_prefix_cases=adjusted,
        scalar_native_adc_words=scalar,actual_phase9_words=matches,receipt_sha256=sha(p.read_bytes()),elapsed_seconds=receipt['elapsed_seconds']),indent=2))
if __name__=='__main__':main()
