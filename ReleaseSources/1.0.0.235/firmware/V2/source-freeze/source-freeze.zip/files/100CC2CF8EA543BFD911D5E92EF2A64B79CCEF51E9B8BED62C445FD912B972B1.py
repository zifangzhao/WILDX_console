from pathlib import Path
import hashlib,json,re,subprocess,sys
T=Path(__file__).resolve().parent;B=T/'build';O=T/'build-r2';O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();q=json.loads((B/'receipt.json').read_text())
assert q['crc32']=='9CDB6D44' and sha(B/'application.bin')==q['body_sha256']
src=T/'Core/Src/xe_np_np2_cl_selected.c'
# Retain the exact failed source preimage, reconstructed and hash-checked.
old=src.read_text().replace('#define BOOT_WORDS 3072U','#define BOOT_WORDS 4096U')
old=old.replace('#define DMA_STORAGE __attribute__((aligned(32),section("NP2_CL_SELECTED")))\n','').replace('static DMA_STORAGE uint32_t','static STORAGE uint32_t').replace('aligned(256),section("NP2_CL_SELECTED")','aligned(256),section("NP2_DMA_DESCRIPTORS")')
old=old.replace('STORAGE volatile uint32_t xe_np_np2_cl_selected_guard[16];\n','')
a=old.index('static int noncacheable_dma_memory(void)');b=old.index('static void config_node(',a)
old=old[:a]+'''static int owner_quiet(void)
{
    return !(SPI1->CR1&(SPI_CR1_SPE|SPI_CR1_CSTART)) &&
        !(SPI1->CFG1&(SPI_CFG1_RXDMAEN|SPI_CFG1_TXDMAEN)) &&
        !(GPDMA1_Channel15->CCR&(DMA_CCR_EN|DMA_CCR_SUSP|DMA_CCR_RESET)) &&
        !(DBGMCU->CR&DBGMCU_CR_TRACE_IOEN) &&
        !(NVIC->ISER[((uint32_t)GPDMA1_Channel15_IRQn)>>5U]&(1UL<<((uint32_t)GPDMA1_Channel15_IRQn&31U)));
}
'''+old[b:]
old=old.replace('if(!owner_quiet()){fault(1U);return -1;}','if(!owner_quiet() || SystemCoreClock!=128000000U ||\n       (DCACHE1->CR&DCACHE_CR_EN)){fault(1U);return -1;}')
assert hashlib.sha256(old.encode()).hexdigest().upper()=='F4ED97F3AAF81A45C6BB747A215FB643F193571F9083D8EF86253425BE846236'
F=T/'failed-9C-source';F.mkdir(exist_ok=True);(F/src.name).write_text(old)
for p,h in q['source_pins'].items():
 if Path(p)!=src:assert sha(p)==h,(p,'unrelated source changed')
link=(B/'application.lnp').read_text();objects=re.findall(r'"([^"\r\n]+\.o)"',link);pins={p:sha(p) for p in objects}
oldobj=str(B/'xe_np_np2_cl_selected.o').replace('\\','/');assert oldobj in pins
c=list(q['compiler_commands']['xe_np_np2_cl_selected']);c[c.index('-o')+1]=str(O/'xe_np_np2_cl_selected.o');c[c.index('-MF')+1]=str(O/'xe_np_np2_cl_selected.d')
prior=json.loads((O/'pending.json').read_text()) if (O/'pending.json').exists() else {}
if not (O/'xe_np_np2_cl_selected.o').exists() or prior.get('source_pins',{}).get(str(src))!=sha(src):
 r=subprocess.run(c,cwd='D:/Code/XE_NP_V2',capture_output=True,text=True);(O/'compile.log').write_text(r.stdout+r.stderr);assert not r.returncode,r.stdout+r.stderr
link=link.replace(oldobj,(O/'xe_np_np2_cl_selected.o').as_posix());pins.pop(oldobj)
s=(B/'application.sct').read_text();assert s.count('*(NP_PREVIEW_HISTORY)')==1;s=s.replace('*(NP_PREVIEW_HISTORY)','*(NP_PREVIEW_HISTORY) *(NP2_CL_SELECTED)');(O/'application.sct').write_text(s)
for n in ['application.sct','application.axf','application.map']:link=link.replace((B/n).as_posix(),(O/n).as_posix())
(O/'application.lnp').write_text(link)
(O/'pending.json').write_text(json.dumps(dict(parent_crc32=q['crc32'],compiler_commands={'xe_np_np2_cl_selected':c},source_pins={str(src):sha(src)},retained_objects=pins,scope='LOCAL: keep globalDCACHE enabled; place private SPI DMA arrays/nodes in existing NC tail with runtimeMPU proof,12KiB bootstrap; all originalNP buffers unchanged'),indent=2)+'\n')
if '--compile-only' in sys.argv:print('One changed selected-source object compiled; link pending');sys.exit()
r=subprocess.run(['C:/Keil_v5/ARM/ARMCLANG/bin/armlink.exe','--via',str(O/'application.lnp')],capture_output=True,text=True);(O/'link.log').write_text(r.stdout+r.stderr);assert not r.returncode,(r.stdout+r.stderr)[-5000:]
def symbols(text):
 return {(m[1],m[4]):(int(m[2],16),int(m[3])) for m in re.finditer(r'^\s+(\S+)\s+(0x[\da-fA-F]+)\s+Data\s+(\d+)\s+([^\r\n]+)',text,re.M)}
before=symbols((B/'application.map').read_text());after=symbols((O/'application.map').read_text());unchanged={}
for k,(a,n) in before.items():
 if 0x200d0000<=a<0x2018c800:
  assert after[k]==(a,n),(k,(a,n),after.get(k));unchanged[' | '.join(k)]=dict(address=hex(a),bytes=n)
assert unchanged
private={k[0]:dict(address=hex(a),bytes=n) for k,(a,n) in after.items() if k[0] in ['bootstrap','selected','scratch','node'] and 'xe_np_np2_cl_selected.o' in k[1]}
assert set(private)=={'bootstrap','selected','scratch','node'},private
for v in private.values():assert 0x20188860<=int(v['address'],16) and int(v['address'],16)+v['bytes']<=0x2018c800,v
(O/'memory-proof.json').write_text(json.dumps(dict(status='PASS',unchanged_original_capture_symbols=unchanged,private_dma_objects=private,scope='Existing MPU6 NC span covers appended private DMA tail; no newMPUregion and originalNP capture buffer addresses/sizes exactlyretained'),indent=2)+'\n');print('Linked cache-placement fix; originalNP buffer addresses/sizes retained')
