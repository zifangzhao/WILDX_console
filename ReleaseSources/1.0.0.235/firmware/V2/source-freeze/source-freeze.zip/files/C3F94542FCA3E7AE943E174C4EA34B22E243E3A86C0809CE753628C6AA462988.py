"""Execute unchanged MPU/owner guards using fake typed array addresses only."""
from pathlib import Path
import hashlib,json,re,subprocess
from test_selected_reader import SOURCE,OUT,ROOT,VC,extract,sha

FIXTURE=r'''
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#define BOOT_WORDS 3072U
#define ROWS 256U
#define SPI_CR1_SPE 1U
#define SPI_CR1_CSTART 512U
#define SPI_CFG1_RXDMAEN 16384U
#define SPI_CFG1_TXDMAEN 32768U
#define DMA_CCR_EN 1U
#define DMA_CCR_RESET 2U
#define DMA_CCR_SUSP 4U
#define DBGMCU_CR_TRACE_IOEN 32U
#define GPDMA1_Channel15_IRQn 46U
typedef struct {uint32_t LinkRegisters[8],NodeInfo;} DMA_NodeTypeDef;
static uintptr_t addresses[4];
#define bootstrap (*(uint32_t(*)[BOOT_WORDS])addresses[0])
#define selected (*(uint32_t(*)[ROWS][2])addresses[1])
#define scratch (*(uint32_t(*)[2])addresses[2])
#define node (*(DMA_NodeTypeDef(*)[4])addresses[3])
static uint32_t rnr_reads,rnr_flip;
struct RnrReg {uint32_t value;operator uint32_t() const{rnr_reads++;return rnr_flip && rnr_reads>=rnr_flip?8U:value;}};
static struct {uint32_t CTRL;RnrReg RNR;uint32_t RBAR_A2,RLAR_A2,RBAR_A3,RLAR_A3,MAIR0,MAIR1,TYPE;} mpu;
#define MPU (&mpu)
static struct {uint32_t CR;} dcache,debug;
static struct {uint32_t CR1,CFG1;} spi;
static struct {uint32_t CCR;} dma;
static struct {uint32_t ISER[4];} nvic;
#define DCACHE1 (&dcache)
#define DBGMCU (&debug)
#define SPI1 (&spi)
#define GPDMA1_Channel15 (&dma)
#define NVIC (&nvic)
static uint32_t SystemCoreClock;
static volatile uint32_t xe_np_np2_cl_selected_guard[16];
#include "actual-cache-guard.inc"
static void fresh(void){
 memset(&mpu,0,sizeof(mpu));memset(&dcache,0,sizeof(dcache));memset(&debug,0,sizeof(debug));
 memset(&spi,0,sizeof(spi));memset(&dma,0,sizeof(dma));memset(&nvic,0,sizeof(nvic));
 memset((void*)xe_np_np2_cl_selected_guard,0,sizeof(xe_np_np2_cl_selected_guard));
 addresses[0]=0x20188000U;addresses[1]=0x2018B000U;addresses[2]=0x2018B800U;addresses[3]=0x2018B900U;
 mpu.CTRL=5U;mpu.TYPE=0x800U;mpu.RNR.value=7U;mpu.RBAR_A2=0x200D0003U;mpu.RLAR_A2=0x2024FFEDU;
 mpu.RBAR_A3=0x70000003U;mpu.RLAR_A3=0x707FFFFFU;mpu.MAIR1=0x44440000U;
 dcache.CR=0x101U;SystemCoreClock=128000000U;rnr_reads=rnr_flip=0U;
}
static void readonly_owner(uint32_t expected){
 unsigned char before[sizeof(mpu)+sizeof(dcache)+sizeof(debug)+sizeof(spi)+sizeof(dma)+sizeof(nvic)];
 unsigned char after[sizeof(before)];unsigned at=0U;
#define SNAP(dest,obj) memcpy(dest+at,&obj,sizeof(obj));at+=sizeof(obj)
 SNAP(before,mpu);SNAP(before,dcache);SNAP(before,debug);SNAP(before,spi);SNAP(before,dma);SNAP(before,nvic);
 assert(owner_quiet()==(expected==0U));assert(xe_np_np2_cl_selected_guard[2]==expected);
 at=0U;SNAP(after,mpu);SNAP(after,dcache);SNAP(after,debug);SNAP(after,spi);SNAP(after,dma);SNAP(after,nvic);
 assert(!memcmp(before,after,sizeof(before)));assert(xe_np_np2_cl_selected_guard[4]==dcache.CR);
 assert(xe_np_np2_cl_selected_guard[0]==0x4752504EU);
}
int main(void){
 fresh();readonly_owner(0U); /* GlobalDCACHE enabled; all DMA data proven NC. */
 for(uint32_t rnr=4U;rnr<=7U;rnr++){fresh();mpu.RNR.value=rnr;assert(noncacheable_dma_memory());}
 fresh();mpu.CTRL=0U;assert(!noncacheable_dma_memory());
 fresh();mpu.TYPE=0x1000U;assert(!noncacheable_dma_memory());
 fresh();mpu.RNR.value=0U;assert(!noncacheable_dma_memory());
 fresh();mpu.RNR.value=8U;assert(!noncacheable_dma_memory());
 fresh();mpu.RLAR_A2&=~1U;assert(!noncacheable_dma_memory());
 fresh();mpu.MAIR1=0xFFFF0000U;assert(!noncacheable_dma_memory());
 fresh();mpu.RLAR_A2=(mpu.RLAR_A2&~14U)|6U;mpu.MAIR0=0x44000000U;assert(noncacheable_dma_memory());
 for(unsigned i=0U;i<4U;i++){
  fresh();addresses[i]=0x200CFFC0U;assert(!noncacheable_dma_memory());
  fresh();addresses[i]=0x20250000U;assert(!noncacheable_dma_memory());
  fresh();mpu.RBAR_A3=(uint32_t)addresses[i];mpu.RLAR_A3=((uint32_t)addresses[i]+31U)|1U;assert(!noncacheable_dma_memory());
 }
 fresh();mpu.RBAR_A3=(uint32_t)addresses[0];mpu.RLAR_A3=((uint32_t)addresses[0]+31U)&~1U;assert(noncacheable_dma_memory());
 fresh();addresses[3]=0x2018FFC0U;assert(!noncacheable_dma_memory()); /* Node array crosses64KiB. */
 fresh();rnr_flip=2U;assert(!noncacheable_dma_memory());
 fresh();addresses[0]=0xFFFFFFF0U;assert(!noncacheable_dma_memory());
 fresh();spi.CR1=SPI_CR1_SPE;readonly_owner(1U);
 fresh();spi.CR1=SPI_CR1_CSTART;readonly_owner(1U);
 fresh();spi.CFG1=SPI_CFG1_RXDMAEN;readonly_owner(2U);
 fresh();spi.CFG1=SPI_CFG1_TXDMAEN;readonly_owner(2U);
 const uint32_t bits[]={DMA_CCR_EN,DMA_CCR_SUSP,DMA_CCR_RESET};
 for(unsigned i=0U;i<3U;i++){fresh();dma.CCR=bits[i];readonly_owner(4U);}
 fresh();debug.CR=DBGMCU_CR_TRACE_IOEN;readonly_owner(8U);
 fresh();nvic.ISER[GPDMA1_Channel15_IRQn>>5U]=1U<<(GPDMA1_Channel15_IRQn&31U);readonly_owner(16U);
 fresh();SystemCoreClock=64000000U;readonly_owner(32U);
 fresh();mpu.MAIR1=0U;readonly_owner(64U);
 fresh();spi.CR1=SPI_CR1_SPE;spi.CFG1=SPI_CFG1_RXDMAEN;dma.CCR=DMA_CCR_EN;debug.CR=DBGMCU_CR_TRACE_IOEN;
 nvic.ISER[GPDMA1_Channel15_IRQn>>5U]=1U<<(GPDMA1_Channel15_IRQn&31U);SystemCoreClock=64000000U;mpu.CTRL=0U;readonly_owner(127U);
 puts("PASS actual read-only MPU/owner guards: DCACHE0x101 with NCregion6, aliasgroup/RNRstability, MAIR0/1, allarraybounds, region7overlap, node64KiB, activeownerbits, combineddiagnostics; no peripheral/cache/MPUwrites");return 0;
}
'''
def main():
    source=SOURCE.read_text()
    actual=extract(source,'static int noncacheable_dma_memory(')+extract(source,'static int owner_quiet(')
    (OUT/'actual-cache-guard.inc').write_text(actual)
    (OUT/'cache-guard.cpp').write_text(FIXTURE)
    exe=OUT/'cache-guard.exe'
    command=f'call "{VC}" >nul && cl /nologo /std:c++17 /W4 /WX /O2 "{OUT/"cache-guard.cpp"}" /Fo"{OUT/"cache-guard.obj"}" /Fe"{exe}"'
    built=subprocess.run(f'cmd /d /s /c "{command}"',cwd=OUT,capture_output=True,text=True,timeout=45)
    (OUT/'cache-guard-compile.log').write_text(built.stdout+built.stderr);assert not built.returncode,built.stdout+built.stderr
    ran=subprocess.run([str(exe)],cwd=OUT,capture_output=True,text=True,timeout=10)
    (OUT/'cache-guard-run.log').write_text(ran.stdout+ran.stderr);assert not ran.returncode,ran.stdout+ran.stderr
    assert SOURCE.read_text()==source,'Selected source changed during proof'
    receipt=dict(status='PASS',source_sha256=sha(SOURCE),actual_functions_sha256=sha(OUT/'actual-cache-guard.inc'),
      output=ran.stdout,command=command,scope='Unchanged actual guards; typed fake array addresses preserve sizeof; fake MMIO snapshots on native64bit host. Device32bit end-wrap is rejected here by region bounds, not a proven native32bit wrap execution.',hardware_access=False,firmware_build=False)
    (OUT/'cache-guard-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(ran.stdout,end='');print('receiptSHA256 '+sha(OUT/'cache-guard-receipt.json'))
if __name__=='__main__':main()
