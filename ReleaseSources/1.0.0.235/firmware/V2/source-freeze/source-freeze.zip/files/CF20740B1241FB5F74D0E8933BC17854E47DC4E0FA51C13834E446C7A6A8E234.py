from pathlib import Path
import json,re,hashlib,subprocess
T=Path(__file__).resolve().parent;B=T/'build';P=T/'build-r2';O=T/'build-r3';O.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
q=json.loads((P/'pending.json').read_text());obj=P/'xe_np_np2_cl_selected.o';assert obj.exists()
q['retained_objects'][obj.as_posix()]=sha(obj)
q['parent_crc32']='9CDB6D44';q['compiler_commands']={};q['compiled_component_receipt']=(P/'pending.json').as_posix();q['compiled_component_receipt_sha256']=sha(P/'pending.json')
q['scope']='LOCAL: one selected-source object with existing-MPU6 fixed tail placement; capture buffers unchanged; no cache/MPU policy change'
(P/'MAP_FAILED.json').write_text(json.dumps(dict(status='MAP_FAILED_DO_NOT_INSTALL',reason='armlink reordered new section ahead of NP ring despite scatter selector order; assertion caught ring relocation',image_crc32='37F0E3FA',map_sha256=sha(P/'application.map')),indent=2)+'\n')
s=(B/'application.sct').read_text();s=s.replace('RW_NP_CAPTURE 0x200D0000 0x000BC800','RW_NP_CAPTURE 0x200D0000 0x000B8860')
s=s.replace('  RW_LIVE_RU4','  RW_CL_SELECTED 0x20188900 0x00003F00 { *(NP2_CL_SELECTED) }\n  RW_LIVE_RU4')
(O/'application.sct').write_text(s)
link=(P/'application.lnp').read_text()
for n in ['application.sct','application.axf','application.map']:link=link.replace((P/n).as_posix(),(O/n).as_posix())
(O/'application.lnp').write_text(link);(O/'pending.json').write_text(json.dumps(q,indent=2)+'\n')
r=subprocess.run(['C:/Keil_v5/ARM/ARMCLANG/bin/armlink.exe','--via',str(O/'application.lnp')],capture_output=True,text=True);(O/'link.log').write_text(r.stdout+r.stderr);assert not r.returncode,(r.stdout+r.stderr)[-4000:]
def symbols(text):
 return {(m[1],m[4]):(int(m[2],16),int(m[3])) for m in re.finditer(r'^\s+(\S+)\s+(0x[\da-fA-F]+)\s+Data\s+(\d+)\s+([^\r\n]+)',text,re.M)}
before=symbols((B/'application.map').read_text());after=symbols((O/'application.map').read_text());same={}
for k,(a,n) in before.items():
 if 0x200d0000<=a<0x2018c800:
  assert after[k]==(a,n),(k,(a,n),after.get(k));same[' | '.join(k)]=dict(address=hex(a),bytes=n)
assert same
private={k[0]:dict(address=hex(a),bytes=n) for k,(a,n) in after.items() if k[0] in ['bootstrap','selected','scratch','node'] and 'xe_np_np2_cl_selected.o' in k[1]}
assert set(private)=={'bootstrap','selected','scratch','node'},private
for v in private.values():assert 0x20188900<=int(v['address'],16) and int(v['address'],16)+v['bytes']<=0x2018c800,v
assert ((int(private['node']['address'],16)^((int(private['node']['address'],16)+private['node']['bytes']-1)))&~65535)==0
(O/'memory-proof.json').write_text(json.dumps(dict(status='PASS',unchanged_original_capture_symbols=same,private_dma_objects=private,scope='Fixed previously-unused execution tail; existing MPU6 region/NC attributes unchanged; original NP ring/history/buffer addresses and sizes unchanged'),indent=2)+'\n')
print('Fixed tail linked; original capture address/size proof PASS')
