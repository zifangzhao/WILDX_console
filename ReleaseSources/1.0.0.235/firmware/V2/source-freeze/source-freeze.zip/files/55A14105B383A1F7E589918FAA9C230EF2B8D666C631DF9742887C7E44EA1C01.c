#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "xe_np_np2_closed_loop_carrier.h"
#include "np_cl_control_wire.h"
#undef main
extern int legacy_main(void);
static int proof_valid=1;
int XE_NP_Np2ClSelected_Proof(uint16_t *p){*p=1173U;return proof_valid;}
int XE_NP_Np2ClSelected_Offer(XE_NP_Np2ClosedLoopSpi *s,uint64_t end,int pressure)
{(void)s;(void)end;(void)pressure;return 0;}
static void request(uint8_t b[64],unsigned n,unsigned probe,unsigned ch)
{
    memset(b,0,64);memcpy(b,"NPCC",4);np_cl_wire_u32(b+4,1);np_cl_wire_u32(b+8,1);
    np_cl_wire_u32(b+12,57);np_cl_wire_u32(b+20,20000);np_cl_wire_u32(b+28,1000);
    np_cl_wire_u32(b+32,n);np_cl_wire_u32(b+52,(1U<<n)-1U);
    for(unsigned i=0;i<n;i++){
        np_cl_wire_u32(b+36+i*8,probe|(6U<<8)|((ch+i)<<16));np_cl_wire_u32(b+40+i*8,0x40000000U);
    }
    np_cl_wire_u32(b+60,np_cl_wire_crc(b,60));
}
int main(void)
{
    assert(!legacy_main());
    uint8_t b[64],reply[64],config[2048]={0},restored[64];
    static XE_NP_Np2ClWorkspace w;XE_NP_Np2ClSourceProof p={42U,12U,20000U,7U,37U,123U,1U,1U,1U};
    XE_NP_Np2ClCarrier_PortBind(&w);
    request(b,2,3,256);
    assert(XE_NP_Np2ClCarrier_PortControl(b,reply,0,7,20000,1)==1 && np_cl_control_u32(reply+16)==NP_CL_CONTROL_UNSUPPORTED);
    request(b,2,2,0);
    assert(XE_NP_Np2ClCarrier_PortControl(b,reply,0,7,20000,1)==1 && !np_cl_control_u32(reply+16));
    XE_NP_Np2ClCarrier_PortBeginAttempt();assert(XE_NP_Np2ClCarrier_PortPrepare(42,7,20000,6,57,1));
    assert(XE_NP_Np2ClCarrier_PortConfig(config)==1);
    assert(np_cl_control_u32(config+1888+116)==2U);
    FILE *f=fopen("p2-config.bin","wb");assert(f);assert(fwrite(config,1,2048,f)==2048);fclose(f);
    XE_NP_Np2ClConfigMeta m;assert(XE_NP_Np2ClCarrier_ConfigDecode(config,1,&m,restored)==1 && m.tap==2U);
    assert(!memcmp(b,restored,64));
    proof_valid=0;assert(XE_NP_Np2ClWorkspace_Configure(&w,b,&p)==NP_CL_CONTROL_SOURCE);
    assert(!memcmp(w.carrier.confirmed_config,b,64) && w.prepared && w.carrier.initialized);
    assert(XE_NP_Np2ClCarrier_PortConfig(config)==1 && np_cl_control_u32(config+1888+116)==2U);
    f=fopen("p2-config-failed-admission.bin","wb");assert(f);assert(fwrite(config,1,2048,f)==2048);fclose(f);
    proof_valid=1;assert(XE_NP_Np2ClWorkspace_Configure(&w,b,&p)==0);
    assert(w.source.config.probe==2 && w.source.config.lane==0 && w.source.config.phase==1173);
    assert(w.lane[0].config.probe==2); /* Event source remains true P2. */
    request(b,2,2,1);assert(XE_NP_Np2ClCarrier_PortControl(b,reply,0,7,20000,1)==1 && np_cl_control_u32(reply+16)==NP_CL_CONTROL_UNSUPPORTED);
    request(b,1,3,256);assert(XE_NP_Np2ClCarrier_PortControl(b,reply,0,7,20000,1)==1 && !np_cl_control_u32(reply+16));
    puts("P2 metadata/source guards PASS; historical P3 one-lane carrier regressions PASS");return 0;
}
