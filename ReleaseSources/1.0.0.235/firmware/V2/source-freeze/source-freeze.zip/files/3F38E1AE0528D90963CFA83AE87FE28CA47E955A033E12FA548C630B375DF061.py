"""Incremental r7 source-only freeze; prior r6 remains preserved, no hardware."""
from pathlib import Path
import hashlib,json,re,shutil,zipfile
OUT=Path(__file__).resolve().parent;T=OUT.parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def main():
 oldpath=OUT/'manifest.json';old=json.loads(oldpath.read_text());assert old['app']['crc32']=='7F0C8BD0'
 previous=OUT/'previous-r6';previous.mkdir(exist_ok=True)
 for n in ('manifest.json','filelist.txt','source-freeze.zip','reproduce-freeze.py'):
  p=OUT/n
  if p.is_file():shutil.copyfile(p,previous/n)
 entries={x['stored']:x for x in old['files']};store=OUT/'files'
 def keep(p,cat,expected=None):
  p=Path(p);assert p.is_file(),p;h=sha(p)
  if expected:assert h==expected,(p,h,expected)
  dest=store/(h+p.suffix.lower())
  if not dest.exists():shutil.copyfile(p,dest)
  key=str(dest.relative_to(OUT));r=entries.setdefault(key,dict(stored=key,sha256=h,bytes=p.stat().st_size,origins=[],categories=[]))
  if str(p) not in r['origins']:r['origins'].append(str(p))
  if cat not in r['categories']:r['categories'].append(cat)
  return h
 r7=json.loads((T/'build-r7/receipt.json').read_text());usb=json.loads((T/'usb-paired-r7/receipt.json').read_text())
 assert r7['crc32']=='99CC44F9' and usb['crc32']=='FFC27E5A' and usb['expected_app_crc32']==r7['crc32']
 old['previous_candidate']=dict(app_crc32='7F0C8BD0',usb_crc32='3F20B1F9',status='FAILED_RESTART_CALIBRATION_STAGE4_NOT_RELEASE_ACCEPTED',manifest=str(previous/'manifest.json'),manifest_sha256=sha(previous/'manifest.json'),zip_sha256=sha(previous/'source-freeze.zip'),reason='Phase9 produced modulo-field offsets1595/7. Prior source bytes and proof receipts preserved; corrected common-header offsets1595/1607 with bounded prefix normalization.')
 for directory,receipt in [('build-r7',r7),('usb-paired-r7',usb)]:
  rp=T/directory/'receipt.json';keep(rp,'r7-checked-build-receipt')
  old['source_hash_chain'].append(dict(path=str(rp),sha256=sha(rp),crc32=receipt['crc32'],parent_crc32=receipt.get('parent_crc32')))
  for p,h in receipt['source_pins'].items():
   keep(p,'actual-final-r7-checked-TU',h)
   old['source_preimage_claims'].append(dict(receipt=str(rp),logical_path=p,expected_sha256=h,resolved_from=p,status='exact'))
  for unit,command in receipt['compiler_commands'].items():
   source=next(Path(x) for x in command if Path(x).suffix.lower() in {'.c','.cpp','.s'})
   expected=next(h for p,h in receipt['source_pins'].items() if Path(p)==source)
   old['current_checked_TUs'][unit]=dict(path=str(source),sha256=expected)
   old['compiler_commands'][unit]=dict(receipt=str(rp),command=command,cwd='D:/Code/XE_NP_V2')
   dep=Path(command[command.index('-MF')+1]);keep(dep,'r7-compiler-dependency-file')
   text=dep.read_text().replace('\\\n',' ');text=re.sub(r'^.*?\.o:\s*','',text,count=1,flags=re.S)
   paths=[]
   for value in re.findall(r'(?:[A-Za-z]:[\\/]|\.\.?[\\/])(?:\\ |[^\s])+',text):
    p=Path(value.replace('\\ ',' '))
    if not p.is_absolute():p=Path('D:/Code/XE_NP_V2')/p
    if p.suffix.lower() in {'.c','.h','.inc','.s','.asm'}:paths.append(str(p))
   old['dependency_closure'].append(dict(unit=unit,dependency_file=str(dep),paths=paths,limit='R7 dependency names only; original header-byte limitations and exact reused closure claims remain inherited from preserved prior freeze. No unpinned current canonical snapshot is promoted to compiler-input proof.'))
  for name in ('application.lnp','application.sct','memory-proof.json','pending.json'):
   if (T/directory/name).is_file():keep(T/directory/name,'r7-exact-link-scatter-receipt')
 for name in ('build-probe-frame.py','prepare-production-pair-r7.py','build-matching-usb-r7.py','seal-matching-usb-r7.py','seal-app.py'):
  keep(T/name,'r7-build-recipe-source')
 for name in ('test_restart_geometry.py','test_restart_offer.py'):
  keep(T/'native'/name,'r7-focused-native-reproducer')
 for directory in ('restart-geometry','restart-offer'):
  for p in (T/'native'/directory).iterdir():
   if p.is_file() and p.suffix.lower() in {'.cpp','.inc','.json','.log'}:keep(p,'r7-focused-native-fixture-receipt')
 for name in ('review_restart_geometry.py','restart-geometry-review.json'):
  keep(T/'audit/alignment'/name,'r7-phase9-saved-oracle-and-allphase-model')
 for name in ('stopped-summary.json','bootstrap-dat-proof.json','closed_loop_attempt.json','recording-window.json','qualification-scope.json','xe_np_np2_cl_selected_calibration.bin','xe_np_np2_cl_selected_diag.bin'):
  p=T/'restart-second'/name
  if p.is_file():assert p.stat().st_size<16384;keep(p,'prior-r6-failed-restart-compact-evidence')
 keep(Path(__file__),'r7-incremental-freeze-recipe')
 old['app']={k:r7[k] for k in ('crc32','body_sha256','hex_sha256')}
 old['usb']={k:usb[k] for k in ('crc32','expected_app_crc32','body_sha256','hex_sha256')}
 old['status']='SOURCE_FROZEN_R7_CANDIDATE_ACCEPTANCE_PENDING_RESTART_AND_RESTORE'
 old['link_commands']=[dict(tool='C:/Keil_v5/ARM/ARMCLANG/bin/armlink.exe',arguments=['--via',str(T/x/'application.lnp')]) for x in ('build-r7','usb-paired-r7')]
 old['files']=list(entries.values());old['stored_bytes']=sum(x['bytes'] for x in entries.values())
 old['r7_proof_receipts']=[dict(path=str(T/'native'/x/'receipt.json'),sha256=sha(T/'native'/x/'receipt.json')) for x in ('restart-geometry','restart-offer')]
 old['limits'].append('Prior r6 activation/pressure successes are retained for unchanged hot paths, but r6 restart failed. R7 native phase/source proof passed; actual restart, restored-device and final qualification decisions remain the hardware owner/integrator responsibility.')
 oldpath.write_text(json.dumps(old,indent=2)+'\n')
 files=[oldpath,OUT/'reproduce-freeze.py',Path(__file__),*sorted(store.iterdir())]
 (OUT/'filelist.txt').write_text('\n'.join(str(p.relative_to(OUT))+' '+sha(p) for p in files)+'\n')
 with zipfile.ZipFile(OUT/'source-freeze.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in [*files,OUT/'filelist.txt',previous/'manifest.json',previous/'filelist.txt']:z.write(p,str(p.relative_to(OUT)))
 print(json.dumps(dict(status=old['status'],stored_files=len(entries),stored_bytes=old['stored_bytes'],manifest_sha256=sha(oldpath),zip_bytes=(OUT/'source-freeze.zip').stat().st_size,zip_sha256=sha(OUT/'source-freeze.zip')),indent=2))
if __name__=='__main__':main()
