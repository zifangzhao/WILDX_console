"""Native actual Offer/frontier and HAL encoder plus explicit DMA address model.

No device access or firmware build. The address model states its assumed
hardware rules; actual peripheral ordering still requires the bench check.
"""
import hashlib,json,re,subprocess
from pathlib import Path

ROOT=Path('D:/Code/XE_NP_V2')
BASE=Path(__file__).resolve().parents[1]
OUT=Path(__file__).resolve().parent
SOURCE=BASE/'Core/Src/xe_np_np2_cl_selected.c'
VC=Path('C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def extract(source,signature):
    at=source.index(signature);start=source.index('{',at);depth=1;end=start+1
    while depth:
        depth+=(source[end]=='{')-(source[end]=='}');end+=1
    return source[at:end]+'\n'

PRELUDE=r'''
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include "constants.inc"
#include "xe_np_np2_closed_loop_spi.h"
#define BOOT_WORDS 4096U
#define ROWS 256U
#define HALF 128U
#define ERRORS (DMA_FLAG_DTE|DMA_FLAG_ULE|DMA_FLAG_USE|DMA_FLAG_TO)
typedef struct {uint32_t Request,BlkHWRequest,Direction,SrcInc,DestInc,SrcDataWidth,DestDataWidth,Priority,SrcBurstLength,DestBurstLength,TransferAllocatedPort,TransferEventMode,Mode;} DMA_InitTypeDef;
typedef struct {uint32_t DataExchange,DataAlignment;} DMA_DataHandlingConfTypeDef;
typedef struct {uint32_t TriggerMode,TriggerPolarity,TriggerSelection;} DMA_TriggerConfTypeDef;
typedef struct {uint32_t RepeatCount;int32_t SrcAddrOffset,DestAddrOffset,BlkSrcAddrOffset,BlkDestAddrOffset;} DMA_RepeatBlockConfTypeDef;
typedef struct {uint32_t NodeType;DMA_InitTypeDef Init;DMA_DataHandlingConfTypeDef DataHandlingConfig;DMA_TriggerConfTypeDef TriggerConfig;DMA_RepeatBlockConfTypeDef RepeatBlockConfig;uint32_t SrcAddress,DstAddress,DataSize;} DMA_NodeConfTypeDef;
typedef struct {uint32_t LinkRegisters[8],NodeInfo;} DMA_NodeTypeDef;
static uint32_t selected[ROWS][2];
static __declspec(align(256)) DMA_NodeTypeDef node[4];
static uint16_t channels[2],offsets[2];static uint8_t count;
static uint32_t configured,consumed,first_frame,first_word,phase_value;
static int32_t delta;static uint8_t field_bits[2];
static volatile uint32_t completed,events;
static uint32_t enable_cycles,first_irq_deadline,irq_last,offer_last;
static uint32_t enable_fine,fine_domain,fine_generation,fine_epoch,irq_last_fine,offer_last_fine;
static volatile uint32_t xe_np_np2_cl_selected_clock[10];
typedef struct {uint64_t counter;uint32_t domain,counter_hz,generation,source_epoch;} XE_NP_Np2SdFinePoint64;
#define XE_NP_NP2_SD_FINE_HZ 1000000U
static XE_NP_Np2SdFinePoint64 mock_fine;
static uint32_t fine_read_fails,fine_read_calls;
static uint32_t HAL_GetTick(void){return 123U;}
static int XE_NP_Np2SdFineClock_Read64Irq(uint32_t tick,XE_NP_Np2SdFinePoint64 *p){assert(tick==123U);fine_read_calls++;*p=mock_fine;return !fine_read_fails;}
volatile uint32_t xe_np_np2_cl_selected_diag[32];
static uint32_t cbr_reads,race_completed,barrier_overrun;
static uint32_t read_cbr(uint32_t value){cbr_reads++;if(race_completed){completed+=HALF;race_completed=0U;}return value;}
struct CbrRegister {uint32_t value;operator uint32_t() const{return read_cbr(value);}uint32_t operator=(uint32_t v){value=v;return v;}};
static struct {uint32_t CSR;CbrRegister CBR1;uint32_t CLLR,CCR,CFCR;} dma_regs;
static struct {uint32_t SR,RXDR;} spi_regs;
static struct {uint32_t CYCCNT;} dwt_regs;
#define DWT (&dwt_regs)
#define GPDMA1_Channel15_IRQn 46U
static uint32_t irq_enabled;
static void HAL_NVIC_DisableIRQ(uint32_t irq){assert(irq==GPDMA1_Channel15_IRQn);irq_enabled=0U;}
#define GPDMA1_Channel15 (&dma_regs)
#define SPI1 (&spi_regs)
static void set_frontier(uint32_t end);
static void barrier(void){if(barrier_overrun){set_frontier(consumed+ROWS);barrier_overrun=0U;}}
#define __DMB() barrier()
static uint32_t gap_calls,lose_calls,last_reason;
void XE_NP_Np2ClosedLoopSpi_Gap(XE_NP_Np2ClosedLoopSpi *s,uint64_t a,uint64_t b,uint32_t why){
 (void)a;(void)b;gap_calls++;last_reason=why;s->in_head=s->in_tail=0U;s->initialized=0U;s->gap_events++;
}
void XE_NP_Np2ClosedLoopSpi_LoseOrigin(XE_NP_Np2ClosedLoopSpi *s,uint32_t why){lose_calls++;s->config.origin_valid=0U;last_reason=why;}
#include "actual.inc"
static void set_frontier(uint32_t end){
 completed=end/HALF*HALF;dma_regs.CSR=0U;
 dma_regs.CBR1=((HALF-1U-end%HALF)<<DMA_CBR1_BRC_Pos)|200U;
 dma_regs.CLLR=completed%ROWS?low_link(&node[2]):low_link(&node[3]);
}
static void fresh(XE_NP_Np2ClosedLoopSpi *s){
 memset(s,0,sizeof(*s));memset(selected,0,sizeof(selected));memset((void*)xe_np_np2_cl_selected_diag,0,sizeof(xe_np_np2_cl_selected_diag));
 memset(&dma_regs,0,sizeof(dma_regs));memset(&spi_regs,0,sizeof(spi_regs));
 s->enabled=1U;s->config.origin_valid=1U;configured=1U;consumed=completed=events=0U;
 cbr_reads=race_completed=barrier_overrun=gap_calls=lose_calls=last_reason=0U;
 enable_cycles=first_irq_deadline=irq_last=offer_last=0U;irq_enabled=1U;dwt_regs.CYCCNT=0U;
 enable_fine=irq_last_fine=offer_last_fine=fine_read_fails=fine_read_calls=0U;
 fine_domain=1U;fine_generation=2U;fine_epoch=3U;mock_fine={0U,1U,1000000U,2U,3U};
 count=2U;channels[0]=0U;channels[1]=1U;offsets[0]=4U;offsets[1]=16U;
 field_bits[0]=4U;field_bits[1]=16U;
 first_frame=100U;first_word=first_frame*1600U;phase_value=delta=0U;set_frontier(0U);
}
static uint16_t expected_adc(uint32_t row,uint32_t ch){return (uint16_t)(((first_frame+row)*97U+ch*13U+33U)&4095U);}
static int geometry(uint32_t phase,int32_t d,uint32_t ch0,uint32_t ch1,uint32_t n){
 phase_value=phase;delta=d;count=(uint8_t)n;channels[0]=(uint16_t)ch0;channels[1]=(uint16_t)ch1;
 uint32_t lo=1600U,hi=0U;
 for(unsigned i=0U;i<n;i++){
  uint32_t ch=channels[i],o=(1600U-phase+(ch%32U)/2U*100U+4U+((ch/32U)*2U+(ch&1U))*12U)%1600U;
  offsets[i]=(uint16_t)o;if(o<lo)lo=o;if(o+12U>hi)hi=o+12U;
 }
 uint32_t frame=(BOOT_WORDS*32U-d)/1600U+2U;
 uint32_t end=((frame*1600U+hi+d+31U)/32U)*32U;
 if(end-64U>frame*1600U+lo+d || end<BOOT_WORDS*32U+1600U)return 0;
 uint32_t prefix=end-BOOT_WORDS*32U-1600U;
 if(!prefix || prefix>3200U || prefix%32U)return 0;
 assert((BOOT_WORDS*32U+prefix+1600U)==end);
 first_frame=frame;first_word=end-64U;
 for(unsigned i=0U;i<n;i++){int64_t b=(int64_t)frame*1600+offsets[i]+d-first_word;assert(b>=0 && b<=52);field_bits[i]=(uint8_t)b;}
 return 1;
}
static void fill(uint32_t row){
 /* Build chronological wire bits independently of Offer's modulo extraction. */
 uint64_t bits=0U,base=(uint64_t)first_word+(uint64_t)row*1600U;
 for(unsigned i=0U;i<count;i++){
  uint64_t at=(uint64_t)(first_frame+row)*1600U+offsets[i]+delta;
  assert(at>=base && at+12U<=base+64U);uint16_t value=expected_adc(row,channels[i]);
  for(unsigned b=0U;b<12U;b++)if(value&(1U<<(11U-b)))bits|=1ULL<<(63U-(unsigned)(at-base)-b);
 }
 selected[row%ROWS][0]=(uint32_t)(bits>>32U);selected[row%ROWS][1]=(uint32_t)bits;
}
static void verify_and_drain(XE_NP_Np2ClosedLoopSpi *s,uint32_t start){
 uint32_t row=start;
 while(s->in_tail!=s->in_head){XE_NP_Np2ClosedLoopSpiRow *v=&s->input[s->in_tail%NP2_CL_SPI_INPUT_ROWS];
  assert(v->frame_tick==(uint64_t)(first_frame+row)*1600U);
  for(unsigned ch=0U;ch<count;ch++)assert(v->word[ch]==expected_adc(row,channels[ch]));
  s->in_tail++;row++;
 }
 assert(row==consumed);
}
static void node_encoding(void){
 DMA_NodeConfTypeDef c;DMA_NodeTypeDef n;memset(&n,0,sizeof(n));config_node(&c);
 c.Init.DestBurstLength=2U;c.Init.TransferEventMode=DMA_TCEM_REPEATED_BLOCK_TRANSFER;
 c.DataSize=200U;c.RepeatBlockConfig.RepeatCount=HALF;
 c.RepeatBlockConfig.DestAddrOffset=-8;c.RepeatBlockConfig.BlkDestAddrOffset=8;c.DstAddress=0x20010000U;
 DMA_List_BuildNode(&c,&n);
 assert(n.LinkRegisters[0]&DMA_CTR1_DINC);
 assert(((n.LinkRegisters[0]&DMA_CTR1_DBL_1)>>DMA_CTR1_DBL_1_Pos)==1U);
 assert((n.LinkRegisters[2]&DMA_CBR1_BNDT)==200U);
 assert(((n.LinkRegisters[2]&DMA_CBR1_BRC)>>DMA_CBR1_BRC_Pos)==127U);
 assert(n.LinkRegisters[2]&DMA_CBR1_DDEC);assert(!(n.LinkRegisters[2]&DMA_CBR1_BRDDEC));
 assert(((n.LinkRegisters[5]&DMA_CTR3_DAO)>>DMA_CTR3_DAO_Pos)==8U);
 assert(((n.LinkRegisters[6]&DMA_CBR2_BRDAO)>>DMA_CBR2_BRDAO_Pos)==8U);
 assert(((n.NodeInfo&NODE_CLLR_IDX)>>NODE_CLLR_IDX_POS)==7U);
 assert((n.LinkRegisters[1]&DMA_CTR2_TCEM)==DMA_TCEM_REPEATED_BLOCK_TRANSFER);
}
static void address_model(void){
 /* Explicit rule: DINC advances each word; signed DAO applies after every
  * destination burst including last; BRDAO additionally applies per block.
  * This proves algorithm arithmetic under that rule, not hardware timing. */
 uint32_t ring[ROWS][2];memset(ring,0,sizeof(ring));uint32_t prologue=37U;
 for(unsigned frame=0U;frame<1024U;frame++){
  unsigned slot=frame%ROWS;uint32_t address=slot*8U;
  for(unsigned w=0U;w<50U;w++){
   assert(address==slot*8U+(w%2U)*4U);ring[address/8U][(address%8U)/4U]=prologue+frame*50U+w;
   address+=4U;if(w%2U)address-=8U;
  }
  address+=8U;assert(address==(slot+1U)*8U);
  assert(ring[slot][0]==prologue+frame*50U+48U && ring[slot][1]==prologue+frame*50U+49U);
 }
}
static void irq_deadlines(void){
 XE_NP_Np2ClosedLoopSpi s;const uint32_t period=6400U;
 /* Exact scheduled deadlines advance across unsigned DWT wrap. */
 fresh(&s);enable_fine=0xFFFFE000U;
 first_irq_deadline=enable_fine+(BOOT_WORDS*32U+1600U+HALF*1600U)/32U;
 for(unsigned n=0U;n<8U;n++){
  uint32_t due=first_irq_deadline;mock_fine.counter=due;dma_regs.CSR=DMA_FLAG_TC;
  GPDMA1_Channel15_IRQHandler();
  assert(completed==(n+1U)*HALF && events==n+1U && first_irq_deadline==due+period);
  assert(configured && !xe_np_np2_cl_selected_diag[2] && irq_enabled && dma_regs.CFCR==DMA_FLAG_TC);
 }
 /* The admitted lateness boundary is inclusive; one more cycle fails. */
 fresh(&s);first_irq_deadline=100000U;mock_fine.counter=first_irq_deadline+1000U;dma_regs.CSR=DMA_FLAG_TC;
 GPDMA1_Channel15_IRQHandler();assert(completed==HALF && events==1U && configured);
 fresh(&s);first_irq_deadline=100000U;mock_fine.counter=first_irq_deadline+1001U;dma_regs.CSR=DMA_FLAG_TC;
 GPDMA1_Channel15_IRQHandler();assert(!completed && !events && !configured && !irq_enabled && xe_np_np2_cl_selected_diag[2]==11U);
 /* Two TC events coalesced after a historically delayed previous delivery.
  * Relative interval alone is below9.6ms, absolute scheduled deadline fails. */
 fresh(&s);completed=HALF;events=1U;uint32_t previous_due=1000000U;
 irq_last_fine=previous_due+4000U;first_irq_deadline=previous_due+period;
 mock_fine.counter=previous_due+2U*period;assert(mock_fine.counter-irq_last_fine<9600U);
 dma_regs.CSR=DMA_FLAG_TC;GPDMA1_Channel15_IRQHandler();
 assert(completed==HALF && events==1U && !configured && !irq_enabled && xe_np_np2_cl_selected_diag[2]==11U);
 /* A terminal DMA fault is latched; later/spurious TC cannot advance state. */
 fresh(&s);dma_regs.CSR=DMA_FLAG_DTE|DMA_FLAG_TC;GPDMA1_Channel15_IRQHandler();
 assert(!configured && !completed && !events && !irq_enabled && xe_np_np2_cl_selected_diag[2]==4U);
 dma_regs.CSR=DMA_FLAG_TC;GPDMA1_Channel15_IRQHandler();assert(!completed && !events && !configured);
 fresh(&s);configured=0U;dma_regs.CSR=DMA_FLAG_TC;GPDMA1_Channel15_IRQHandler();assert(!completed && !events && !irq_enabled);
 fresh(&s);dma_regs.CSR=0U;GPDMA1_Channel15_IRQHandler();assert(!completed && !events && configured);
 for(unsigned failure=0U;failure<5U;failure++){
  fresh(&s);switch(failure){case 0:fine_read_fails=1U;break;case 1:mock_fine.domain++;break;
   case 2:mock_fine.counter_hz++;break;case 3:mock_fine.generation++;break;case 4:mock_fine.source_epoch++;break;}
  uint32_t now=0xDEADBEEFU;assert(!read_bound_fine(&now) && now==0xDEADBEEFU);
  dma_regs.CSR=DMA_FLAG_TC;GPDMA1_Channel15_IRQHandler();
  assert(!completed && !events && !configured && !irq_enabled && xe_np_np2_cl_selected_diag[2]==14U);
 }
 fresh(&s);mock_fine.counter=0x12345678FFFFFFFFULL;uint32_t now=0U;
 XE_NP_Np2SdFinePoint64 before=mock_fine;assert(read_bound_fine(&now) && now==0xFFFFFFFFU && !memcmp(&before,&mock_fine,sizeof(before)));
 assert(dwt_regs.CYCCNT==0U); /* All IRQ timing tests advanced fine time only. */
}
int main(void){
 node_encoding();address_model();irq_deadlines();XE_NP_Np2ClosedLoopSpi s;uint32_t cases=0U;
 const uint32_t phases[]={0U,1U,17U,99U,100U,799U,1599U};
 const int32_t deltas[]={-1599,-146,-1,0,31,1599};
 const uint32_t chans[][2]={{0,1},{2,3},{32,33},{126,127},{0,0}};
 for(unsigned p=0;p<7U;p++)for(unsigned d=0;d<6U;d++)for(unsigned ch=0;ch<5U;ch++){
  fresh(&s);if(!geometry(phases[p],deltas[d],chans[ch][0],chans[ch][1],ch==4U?1U:2U))continue;cases++;
  for(uint32_t base=0U;base<768U;base+=16U){
   for(uint32_t r=base;r<base+16U;r++)fill(r);set_frontier(base+16U);
   assert(XE_NP_Np2ClSelected_Offer(&s,UINT64_MAX,0)==1 && consumed==base+16U);
   verify_and_drain(&s,base);assert(!lose_calls && !xe_np_np2_cl_selected_diag[2]);
  }
 }
 assert(cases>100U);
 /* Current overwritten row must never be visible, whatever its word data. */
 fresh(&s);fill(0U);fill(1U);set_frontier(1U);selected[1][0]=selected[1][1]=0xFFFFFFFFU;
 assert(XE_NP_Np2ClSelected_Offer(&s,UINT64_MAX,0)==1 && consumed==1U && s.in_head==1U);verify_and_drain(&s,0U);
 /* Stop at saved NP frontier, then admit same row once NP becomes durable. */
 fresh(&s);for(unsigned i=0;i<10U;i++)fill(i);set_frontier(10U);
 assert(XE_NP_Np2ClSelected_Offer(&s,(uint64_t)first_frame*1600U+offsets[1]+11U,0)==1 && !consumed);
 assert(XE_NP_Np2ClSelected_Offer(&s,(uint64_t)first_frame*1600U+offsets[1]+12U,0)==1 && consumed==1U);verify_and_drain(&s,0U);
 /* A pending TC or torn snapshot conservatively defers without regression. */
 fresh(&s);consumed=100U;set_frontier(110U);dma_regs.CSR=DMA_FLAG_TC;
 assert(XE_NP_Np2ClSelected_Offer(&s,UINT64_MAX,0)==1 && consumed==100U && !lose_calls);
 dma_regs.CSR=0U;race_completed=1U;
 assert(XE_NP_Np2ClSelected_Offer(&s,UINT64_MAX,0)==1 && consumed==100U && !lose_calls);
 fresh(&s);consumed=100U;set_frontier(110U);dma_regs.CLLR^=4U;
 assert(XE_NP_Np2ClSelected_Offer(&s,UINT64_MAX,0)==1 && consumed==100U && !lose_calls);
 fresh(&s);set_frontier(ROWS);assert(XE_NP_Np2ClSelected_Offer(&s,UINT64_MAX,0)==-1 && lose_calls==1U && xe_np_np2_cl_selected_diag[2]==7U);
 fresh(&s);fill(0);set_frontier(1);barrier_overrun=1U;
 assert(XE_NP_Np2ClSelected_Offer(&s,UINT64_MAX,0)==-1 && lose_calls==1U && xe_np_np2_cl_selected_diag[2]==8U);
 fresh(&s);set_frontier(10U);assert(XE_NP_Np2ClSelected_Offer(&s,UINT64_MAX,1)==1 && consumed==10U && gap_calls==10U && !s.in_head);
 fresh(&s);fill(0);set_frontier(1);s.in_head=NP2_CL_SPI_INPUT_ROWS;
 assert(XE_NP_Np2ClSelected_Offer(&s,UINT64_MAX,0)==0 && s.queue_overflows==1U && gap_calls==1U && !consumed);
 fresh(&s);dma_regs.CSR=DMA_FLAG_DTE;assert(XE_NP_Np2ClSelected_Offer(&s,UINT64_MAX,0)==-1 && lose_calls==1U);
 fresh(&s);spi_regs.SR=SPI_FLAG_OVR;assert(XE_NP_Np2ClSelected_Offer(&s,UINT64_MAX,0)==-1 && lose_calls==1U);
 fresh(&s);configured=0U;assert(XE_NP_Np2ClSelected_Offer(&s,UINT64_MAX,0)==-1 && lose_calls==1U);
 assert(XE_NP_Np2ClSelected_Offer(&s,UINT64_MAX,0)==0 && lose_calls==1U && !gap_calls);
 fresh(&s);fine_read_fails=1U;assert(XE_NP_Np2ClSelected_Offer(&s,UINT64_MAX,0)==-1 && lose_calls==1U);
 assert(XE_NP_Np2ClSelected_Offer(&s,UINT64_MAX,0)==0 && lose_calls==1U);
 printf("PASS %u admissible phase/delta/channel geometries x768rows: actualOffer/frontier values/ticks, ringwrap, savedNPfrontier, pendingTC/torn snapshot, lag/overrun, pressure, queue/errors; exactIRQ scheduled/wrap/late/coalescedTC/terminalLatch; actualHAL2D encoding+explicit burst/block address model\n",cases);
 return 0;
}
'''

def main():
    source=SOURCE.read_text();halpath=ROOT/'Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_dma_ex.c'
    hal=halpath.read_text();sig='static void DMA_List_BuildNode(DMA_NodeConfTypeDef const *const pNodeConfig,'
    # Skip its forward declaration and keep the implementation unchanged.
    hal_actual=extract(hal[hal.index(sig,hal.index(sig)+1):],sig)
    actual='\n'.join(extract(source,sig) for sig in ('static uint32_t low_link(', 'static void fault(', 'static void config_node(', 'static uint32_t frontier(', 'static int read_bound_fine(', 'static void note_offer(', 'void GPDMA1_Channel15_IRQHandler(', 'int XE_NP_Np2ClSelected_Offer('))+hal_actual
    (OUT/'actual.inc').write_text(actual)
    definitions={}
    for path in [halpath,ROOT/'Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_dma.h',ROOT/'Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_dma_ex.h',ROOT/'Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_spi.h',ROOT/'Drivers/CMSIS/Device/ST/STM32U5xx/Include/stm32u595xx.h']:
        for line in path.read_text().replace('\\\n',' ').splitlines():
            m=re.match(r'\s*#define\s+(\w+)\s+(.+)',line)
            if m:definitions[m[1]]=m[2].split('/*')[0].strip()
    names=set(re.findall(r'\b(?:DMA|GPDMA\d*|NODE|SPI)_\w+\b',PRELUDE+actual))
    names-=set(re.findall(r'^#define\s+(\w+)',PRELUDE,re.MULTILINE))
    names-={'DMA_InitTypeDef','DMA_DataHandlingConfTypeDef','DMA_TriggerConfTypeDef','DMA_RepeatBlockConfTypeDef','DMA_NodeConfTypeDef','DMA_NodeTypeDef','DMA_List_BuildNode','GPDMA1_Channel15_IRQHandler'}
    pending=list(names)
    while pending:
        n=pending.pop();assert n in definitions,'Missing constant '+n
        for dep in re.findall(r'\b(?:DMA|GPDMA\d*|NODE|SPI)_\w+\b',definitions[n]):
            if dep not in names:names.add(dep);pending.append(dep)
    (OUT/'constants.inc').write_text('\n'.join('#define '+n+' '+definitions[n] for n in sorted(names))+'\n')
    fixture=PRELUDE.replace('#define BOOT_WORDS 4096U',re.search(r'#define BOOT_WORDS \d+U',source)[0])
    (OUT/'selected.cpp').write_text(fixture)
    exe=OUT/'selected.exe'
    command=f'call "{VC}" >nul && cl /nologo /std:c++17 /W4 /WX /O2 /DXE_NP_NP2_CLOSED_LOOP_SPI_ENABLE=0 /I"{ROOT/"Core/Inc"}" "{OUT/"selected.cpp"}" /Fo"{OUT/"selected.obj"}" /Fe"{exe}"'
    built=subprocess.run(f'cmd /d /s /c "{command}"',cwd=OUT,capture_output=True,text=True,timeout=45)
    (OUT/'compile.log').write_text(built.stdout+built.stderr);assert not built.returncode,built.stdout+built.stderr
    ran=subprocess.run([str(exe)],cwd=OUT,capture_output=True,text=True,timeout=20)
    (OUT/'run.log').write_text(ran.stdout+ran.stderr);assert not ran.returncode,ran.stdout+ran.stderr
    assert SOURCE.read_text()==source,'Source changed during actual-function proof'
    receipt=dict(status='PASS',source=str(SOURCE),source_sha256=sha(SOURCE),hal_sha256=sha(halpath),
      actual_functions_sha256=sha(OUT/'actual.inc'),command=command,output=ran.stdout,
      scope='Actual selected Offer/frontier/config_node/read_bound_fine/note_offer/IRQ and actual private HAL node encoder; owned fine-clock API endpoint mocked with independent1MHz time while DWT stays paused; domain/hz/generation/epoch/failure admission tested; MMIO/source bits simulated; DMA address rules modeled explicitly, not hardware proven',
      hardware_access=False,firmware_build=False)
    (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(ran.stdout,end='');print('receiptSHA256 '+sha(OUT/'receipt.json'))
if __name__=='__main__':main()
