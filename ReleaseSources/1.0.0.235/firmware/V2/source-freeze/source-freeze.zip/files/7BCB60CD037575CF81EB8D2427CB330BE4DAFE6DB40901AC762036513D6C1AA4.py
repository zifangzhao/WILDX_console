"""Exact retained IMU interval arithmetic; no file/value rewriting."""
from pathlib import Path
from fractions import Fraction
import csv,hashlib,json,struct,zlib,sys

BASE=Path(__file__).resolve().parents[2];E=BASE/'sd-r6-cl2/export';OUT=Path(__file__).resolve().parent
RUN=sys.argv[1] if len(sys.argv)>1 else 'sd-r6-cl2';E=BASE/RUN/'export'
SDK=Path('C:/Frank/Code/USB_PCconsole/_artifacts/v2_spi_selected_detectors_20261104/sdk/source')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def main():
    phase=(E/'imu_grid_phase.bin').read_bytes();assert len(phase)==84 and zlib.crc32(phase[:80])==struct.unpack_from('<I',phase,80)[0]
    first=struct.unpack_from('<Q',phase,44)[0];lo,hi=struct.unpack_from('<qq',phase,52)
    den,jitter,flags=struct.unpack_from('<III',phase,68)
    utc=json.loads((E/'recording_start_utc.json').read_text());reference=utc['reference_source_tick'];hz=utc['reference_source_hz']
    rows=list(csv.DictReader((E/'imu_grid_segments.csv').open()));assert len(rows)==1
    first_observed=int(rows[0]['first_slot']);count=int(rows[0]['row_count']);last=first_observed+count-1
    neural=list(csv.DictReader((E/'neural_segments.csv').open()));ends={int(r['source_end_tick']) for r in neural};assert len(ends)==1
    extent=ends.pop();assert extent%40960==0 and hz==32000000 and first==first_observed==0
    step=hz//1250
    def interval(slot):
        d=slot-first;j=0 if d==0 else jitter
        lower=Fraction(reference+d*step-j)+Fraction(lo,den)
        upper=Fraction(reference+d*step+j)+Fraction(hi,den)
        return dict(slot=slot,lower_tick=int(lower) if lower.denominator==1 else str(lower),
            upper_tick=int(upper) if upper.denominator==1 else str(upper),
            lower_relative_to_saved_end_us=float((lower-extent)*1000000/hz),
            upper_relative_to_saved_end_us=float((upper-extent)*1000000/hz))
    delta=last-first;remaining=extent-reference-delta*step-jitter
    source_window=remaining>=0 and hi<=remaining*den and lo+(step-jitter)*den>=0
    last_intervals=[interval(last-2),interval(last-1),interval(last)]
    result=dict(status='RETAINED_INTERVALS_WITHIN_SAVED_NP_PREFIX' if source_window else 'FALSE_PRESERVED_LAST_RETAINED_INTERVAL_NOT_PROVEN_WITHIN_SAVED_NP_PREFIX',
        source_extent_ticks=extent,reference_tick=reference,source_hz=hz,step_ticks=step,
        phase=dict(first_accepted_slot=first,lower_numerator=lo,upper_numerator=hi,denominator=den,
                   maximum_relative_jitter_ticks=jitter,flags=flags,crc_validated=True),
        observed=dict(first=first_observed,last=last,count=count,gaps_file_empty=len(list(csv.DictReader((E/'imu_grid_gaps.csv').open())))==0),
        writer_complete=dict(delta=delta,remaining_ticks=remaining,
            required_upper_numerator=hi,available_upper_numerator=remaining*den,
            upper_exceeds_available_by_ticks=float(Fraction(hi,den)-remaining),
            lower_known=lo+(step-jitter)*den>=0,source_window_verified=source_window),
        first_interval=interval(first),last_three_intervals=last_intervals,
        interpretation=[f'All scheduled slots{first_observed}..{last} were retained contiguously; this review does not infer a missing row or sequence gap.',
          *[f"Slot{i['slot']} is "+('wholly outside the saved NP prefix' if i['lower_relative_to_saved_end_us']>0 else 'fully inside the saved NP prefix' if i['upper_relative_to_saved_end_us']<=0 else 'straddling its endpoint under the qualified jitter interval') for i in last_intervals],
          f'SDK-equivalent retained source_window_verified={source_window}; no saved flag is changed.',
          'This does not prove IMU ran after the physical NP source stopped: any terminal partial NP suffix and producer final scheduled ordinal remain unmeasured/unknown.'],
        inputs=[dict(path=str(p),sha256=sha(p)) for p in (E/'imu_grid_phase.bin',E/'imu_grid_segments.csv',E/'imu_grid_gaps.csv',E/'neural_segments.csv',E/'recording_start_utc.json',
          SDK/'USB512_interface/USB512_interface/NpImuGridWriter.cs',SDK/'Neuropixels/SD/NpV2SdGrid.cs')],
        scope='Read-only exact SDK-equivalent interval math; no hardware, neural payload reads, build, trimming, flag override or data rewrite')
    name=RUN.removeprefix('sd-')+'-source-window-review.json'
    (OUT/name).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','source_extent_ticks','reference_tick','phase','observed','writer_complete','last_three_intervals')},indent=2));print('receiptSHA256 '+sha(OUT/name))
if __name__=='__main__':main()
