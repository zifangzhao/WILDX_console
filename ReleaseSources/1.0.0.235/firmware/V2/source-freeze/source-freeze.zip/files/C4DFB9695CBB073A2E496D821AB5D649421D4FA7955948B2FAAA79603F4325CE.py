from pathlib import Path
import json,hashlib,re,subprocess,sys
T=Path(__file__).resolve().parent;B=T/'build-r6';O=T/'build-r7';O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();q=json.loads((B/'receipt.json').read_text());assert q['crc32']=='7F0C8BD0' and sha(B/'application.bin')==q['body_sha256']
link=(B/'application.lnp').read_text();objects=re.findall(r'"([^"\r\n]+\.o)"',link);pins={p:sha(p) for p in objects};expected=dict(q['retained_objects'])
for u,c in q['compiler_commands'].items():expected[Path(c[c.index('-o')+1]).as_posix()]=sha(c[c.index('-o')+1])
for p,h in pins.items():assert expected[p]==h,p
commands={};sources={}
initial=json.loads((T/'build/receipt.json').read_text())
for u in ['xe_np_np2_cl_selected','xe_np_np2_closed_loop_spi']:
 src=T/'Core/Src'/(u+'.c');c=list(q['compiler_commands'][u] if u in q['compiler_commands'] else initial['compiler_commands'][u]);c[c.index('-c')+1]=str(src);c[c.index('-o')+1]=str(O/(u+'.o'));c[c.index('-MF')+1]=str(O/(u+'.d'))
 if not (O/(u+'.o')).exists():
  r=subprocess.run(c,capture_output=True,text=True);(O/(u+'-compile.log')).write_text(r.stdout+r.stderr);assert not r.returncode,r.stdout+r.stderr
 old=[p for p in objects if Path(p).stem==u];assert len(old)==1;link=link.replace(old[0],(O/(u+'.o')).as_posix());pins.pop(old[0]);commands[u]=c;sources[str(src)]=sha(src)
(O/'application.sct').write_bytes((B/'application.sct').read_bytes())
for n in ['application.sct','application.axf','application.map']:link=link.replace((B/n).as_posix(),(O/n).as_posix())
(O/'application.lnp').write_text(link);(O/'pending.json').write_text(json.dumps(dict(parent_crc32=q['crc32'],compiler_commands=commands,source_pins=sources,retained_objects=pins,scope='LOCAL P2-only header-anchored unwrapped ADC offsets in cold calibration+Init, canonical frame normalization for bootstrap prologue; P3 legacy modulo, all WILD filtering/resampler/NP/IMU ownership unchanged'),indent=2)+'\n')
if '--compile-only' in sys.argv:print('Two probe-frame initialization objects compiled');sys.exit()
r=subprocess.run(['C:/Keil_v5/ARM/ARMCLANG/bin/armlink.exe','--via',str(O/'application.lnp')],capture_output=True,text=True);(O/'link.log').write_text(r.stdout+r.stderr);assert not r.returncode,r.stdout+r.stderr
def symbols(text):return {(m[1],m[4]):(int(m[2],16),int(m[3])) for m in re.finditer(r'^\s+(\S+)\s+(0x[\da-fA-F]+)\s+Data\s+(\d+)\s+([^\r\n]+)',text,re.M)}
before=symbols((B/'application.map').read_text());after=symbols((O/'application.map').read_text());same={}
for k,(a,n) in before.items():
 if 0x200d0000<=a<0x2018c800:assert after[k]==(a,n),(k,(a,n),after.get(k));same[' | '.join(k)]=dict(address=hex(a),bytes=n)
(O/'memory-proof.json').write_text(json.dumps(dict(status='PASS',unchanged_np_and_private_dma_addresses_sizes=same),indent=2)+'\n');print('Probe-frame initialization fix linked, DMA/NP buffers unchanged')
