#define main legacy_main
#include "D:/Code/XE_NP_V2/Tools/V2SdLogger/tests/test_np2_closed_loop_carrier.c"
