C:\Frank\Code\XE_NP\_artifacts\v2_spi_selected_detectors_20261104\build-r7\xe_np_np2_closed_loop_spi.o: \
  C:\Frank\Code\XE_NP\_artifacts\v2_spi_selected_detectors_20261104\Core\Src\xe_np_np2_closed_loop_spi.c \
  D:\Code\XE_NP_V2\Core\Inc\xe_np_np2_closed_loop_spi.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\stdint.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\string.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\limits.h \
  D:\Code\XE_NP_V2\Core\Inc\xe_np_np2_closed_loop_perf.h \
  C:\Frank\Code\XE_NP\_artifacts\v2_spi_selected_detectors_20261104\Core\Inc\xe_np_np2_cl_selected.h
