from pathlib import Path
import json,hashlib,re,subprocess,sys
T=Path(__file__).resolve().parent;B=Path('C:/Frank/Code/XE_NP/_artifacts/v2_sd_recording_fix_20261104/build-usb-paired-r2');O=T/'usb-paired-r7';O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
q=json.loads((B/'receipt.json').read_text());assert q['crc32']=='80E18959' and sha(B/'application.bin')==q['body_sha256']
link=(B/'application.lnp').read_text();objects=re.findall(r'"([^"\r\n]+\.o)"',link);pins={p:sha(p) for p in objects};expected=dict(q['retained_objects'])
for u,c in q['compiler_commands'].items():expected[Path(c[c.index('-o')+1]).as_posix()]=sha(c[c.index('-o')+1])
for p,h in pins.items():assert expected[p]==h,p
u='xe_np_usb_sd_test_job';c=list(q['compiler_commands'][u]);source=Path(c[c.index('-c')+1]);assert sha(source)==list(q['source_pins'].values())[0]
dest=O/source.name;dest.write_bytes(source.read_bytes());c[c.index('-c')+1]=str(dest)
c=[x.replace('XE_NP_USB_SD_TEST_APP_CRC32=0x680A1685UL','XE_NP_USB_SD_TEST_APP_CRC32=0x99CC44F9UL') for x in c];assert '-DXE_NP_USB_SD_TEST_APP_CRC32=0x99CC44F9UL' in c
c[c.index('-o')+1]=str(O/(u+'.o'));c[c.index('-MF')+1]=str(O/(u+'.d'))
if not (O/(u+'.o')).exists():
 r=subprocess.run(c,capture_output=True,text=True);(O/'compile.log').write_text(r.stdout+r.stderr);assert not r.returncode,r.stdout+r.stderr
old=[p for p in objects if Path(p).stem==u];assert len(old)==1;link=link.replace(old[0],(O/(u+'.o')).as_posix());pins.pop(old[0])
for n in ['application.axf','application.map']:link=link.replace((B/n).as_posix(),(O/n).as_posix())
(O/'application.lnp').write_text(link);(O/'pending.json').write_text(json.dumps(dict(parent_crc32=q['crc32'],expected_app_crc32='99CC44F9',compiler_commands={u:c},source_pins={str(dest):sha(dest)},changed_object_sha256=sha(O/(u+'.o')),retained_objects=pins,scope='Only optional SD-test expectedAPPCRC680A1685→99CC44F9; corrected no-ticket sentinel source identical; all116 USB streaming/download/NP/IMU objects unchanged'),indent=2)+'\n')
if '--compile-only' in sys.argv:print('One APP-identity pairing object compiled,116 unchanged');sys.exit()
r=subprocess.run(['C:/Keil_v5/ARM/ARMCLANG/bin/armlink.exe','--via',str(O/'application.lnp')],capture_output=True,text=True);(O/'link.log').write_text(r.stdout+r.stderr);assert not r.returncode,r.stdout+r.stderr
seal=Path('C:/Frank/Code/XE_NP/_artifacts/v2_sd_recording_fix_20261104/seal-usb-pair-r2.py').read_text().replace("O=T/'build-usb-paired-r2'","O=T/'usb-paired-r7'")
(T/'seal-matching-usb-r7.py').write_text(seal);print('Matching USB linked; data path object identities unchanged')
