"""Reuse frozen native actual Offer/IRQ/HAL harness with actual new geometry."""
from pathlib import Path
import importlib.util,re,json,hashlib
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('prior',HERE/'test_selected_reader.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.OUT=HERE/'restart-offer';m.OUT.mkdir(exist_ok=True)
s=m.SOURCE.read_text();geometry=s[s.index('    uint32_t lo=UINT32_MAX'):s.index('    cal[0]=5U;')]
start=m.PRELUDE.index('static int geometry(');end=m.PRELUDE.index('static void fill(',start)
replacement='''static int geometry(uint32_t phase,int32_t d,uint32_t ch0,uint32_t ch1,uint32_t n){
 phase_value=phase;delta=d;count=(uint8_t)n;channels[0]=(uint16_t)ch0;channels[1]=(uint16_t)ch1;
'''+geometry+'''
 first_frame=frame;first_word=end-64U;return 1;bad:return 0;
}
'''
m.PRELUDE=m.PRELUDE[:start]+replacement+m.PRELUDE[end:]
m.PRELUDE=m.PRELUDE.replace('for(unsigned p=0;p<7U;p++)','for(unsigned p=0;p<1600U;p++)').replace('geometry(phases[p],deltas[d]','geometry(p,deltas[d]')
m.PRELUDE=m.PRELUDE.replace('const uint32_t phases[]={0U,1U,17U,99U,100U,799U,1599U};','')
m.PRELUDE=m.PRELUDE.replace('base<768U','base<16U').replace('geometries x768rows','geometries x16rows')
# Extra exact saved-end boundary test at the16 wrapped-header cases: incomplete
# selected pair must defer; final required native bit admits exactly one row.
needle=' assert(cases>100U);'
extra=r'''
 assert(cases==1600U*6U*5U);
 for(unsigned p=1U;p<=16U;p++)for(unsigned reverse=0;reverse<2;reverse++){
  fresh(&s);assert(geometry(p,150,reverse?1:0,reverse?0:1,2));fill(0);set_frontier(1);
  unsigned max=offsets[0]>offsets[1]?offsets[0]:offsets[1];
  uint64_t required=(uint64_t)first_frame*1600+max+12;
  assert(XE_NP_Np2ClSelected_Offer(&s,required-1,0)==1 && !consumed);
  assert(XE_NP_Np2ClSelected_Offer(&s,required,0)==1 && consumed==1);verify_and_drain(&s,0);
 }
'''
assert needle in m.PRELUDE;m.PRELUDE=m.PRELUDE.replace(needle,extra)
m.main()
p=m.OUT/'receipt.json';r=json.loads(p.read_text());r['geometry']='Exact current Calibrate geometry statements extracted unchanged, all1600phases x6signeddeltas x5single/adjacent pairs x16rows; phase1..16 pair/reverse saved-end final-bit boundary added. Earlier210geometry x768rows ringwrap proof retained separately for unchanged hot bodies.';r['native_firmware_build']=False;p.write_text(json.dumps(r,indent=2)+'\n');print('finalreceiptSHA256 '+hashlib.sha256(p.read_bytes()).hexdigest().upper())
