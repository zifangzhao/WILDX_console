from pathlib import Path
import hashlib,json,re,subprocess,sys
T=Path(__file__).resolve().parent;R=Path('D:/Code/XE_NP_V2');ARM=Path('C:/Keil_v5/ARM/ARMCLANG/bin')
P=Path('C:/Frank/Code/XE_NP/_artifacts/v2_sd_recording_fix_20261104');B=P/'build-app-metadata';O=T/'build';O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
assert sha(B/'application.bin')=='E92F6A26500B3D07993D48A4F05210483A0BAE28AFDB70791B58E2B0F6780E27'
recipes=[Path('C:/Frank/Code/USB_PCconsole/_artifacts/closed_loop_20261102/V2/build-app'),Path('C:/Frank/Code/USB_PCconsole/_artifacts/closed_loop_fix_20261102/V2/sd-pressure-fix/build-app'),P/'build-app',B]
commands={};expected={}
for p in recipes:
 q=json.loads((p/'receipt.json').read_text(encoding='utf-8-sig'))
 commands.update(q.get('compiler_commands',{}));expected.update(q.get('retained_objects',{}))
 for u in q.get('compiler_commands',{}):
  if (p/(u+'.o')).exists():expected[(p/(u+'.o')).as_posix()]=sha(p/(u+'.o'))
  c=q['compiler_commands'][u]
  if '-o' in c and Path(c[c.index('-o')+1]).exists():expected[Path(c[c.index('-o')+1]).as_posix()]=sha(c[c.index('-o')+1])
link=(B/'application.lnp').read_text();objects=re.findall(r'"([^"\r\n]+\.o)"',link)
pins={p:sha(p) for p in objects}
for p,h in pins.items():assert expected.get(p)==h,(p,'unresolved object identity')
prior=json.loads((O/'pending.json').read_text()) if (O/'pending.json').exists() else {}
units=['xe_np_np2_capture_port','xe_np_np2_closed_loop_spi','xe_np_np2_closed_loop_carrier','xe_np_np2_cl_selected'];cmds={};sources={}
for u in units:
 c=list(commands[u if u in commands else 'xe_np_np2_capture_port'])
 c.insert(1,'-I'+str(T/'Core/Inc'));c.insert(1,'-DXE_NP_IMU_GRID_CAPACITY=512U')
 src=T/'Core/Src'/(u+'.c')
 c=[str(src) if x.lower().endswith('.c') else x for x in c]
 c[c.index('-o')+1]=str(O/(u+'.o'))
 if '-MF' in c:c[c.index('-MF')+1]=str(O/(u+'.d'))
 if not (O/(u+'.o')).exists() or prior.get('source_pins',{}).get(str(src))!=sha(src):
  r=subprocess.run(c,cwd=R,capture_output=True,text=True);(O/(u+'.log')).write_text(r.stdout+r.stderr)
  if r.returncode:raise RuntimeError((u,(r.stdout+r.stderr)[-5000:]))
 old=[p for p in objects if Path(p).stem==u]
 if old:assert len(old)==1;link=link.replace(old[0],(O/(u+'.o')).as_posix());pins.pop(old[0])
 else:link='"'+(O/(u+'.o')).as_posix()+'"\n'+link
 cmds[u]=c;sources[str(src)]=sha(src)
(O/'application.sct').write_bytes((B/'application.sct').read_bytes())
for n in ['application.sct','application.axf','application.map']:link=link.replace((B/n).as_posix(),(O/n).as_posix())
(O/'application.lnp').write_text(link)
(O/'pending.json').write_text(json.dumps(dict(parent_crc32='680A1685',compiler_commands=cmds,source_pins=sources,header_pins={str(p):sha(p) for p in (T/'Core/Inc').glob('*.h')},retained_objects=pins,scope='LOCAL: SPI1/C15 selected native-word P2ADC0/1 tap and empty-work guard; NP/IMU transport unchanged'),indent=2)+'\n')
if '--compile-only' in sys.argv:print('4 changed objects compiled; link pending');sys.exit()
r=subprocess.run([str(ARM/'armlink.exe'),'--via',str(O/'application.lnp')],capture_output=True,text=True);(O/'link.log').write_text(r.stdout+r.stderr)
assert not r.returncode,(r.stdout+r.stderr)[-7000:]
print('Linked isolated selected-SPI candidate')
