#include "xe_np_np2_closed_loop_carrier.h"
#include "np_cl_control_wire.h" /* Canonical root-owned control parser/event packer. */
#include <string.h>
#include <limits.h>
#if XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
#include "xe_np_np2_cl_selected.h"
#endif
#if XE_NP_NP2_CLOSED_LOOP_WORKSPACE_ENABLE
extern void XE_NP_Np2ClRuntime_Ensure(void);
#endif
#include "np_cl_coefficients.h" /* Shared constant bank; no runtime design. */
static uint32_t get32(const uint8_t *p)
{return (uint32_t)p[0]|((uint32_t)p[1]<<8U)|((uint32_t)p[2]<<16U)|((uint32_t)p[3]<<24U);}
static void inc(uint32_t *p){if(*p!=UINT32_MAX)(*p)++;}
static void add(uint32_t *p,uint32_t n){*p=n>UINT32_MAX-*p?UINT32_MAX:*p+n;}
static int copied(const uint8_t *h)
{
    return h && !memcmp(h,"NP2USB03",8U) && get32(h+8U)==3U &&
        get32(h+12U)==512U && !(get32(h+52U)&0x40U) && (get32(h+52U)&32U) &&
        (get32(h+160U)==4U || get32(h+160U)==5U || get32(h+160U)==6U);
}
int XE_NP_Np2ClCarrier_Init(XE_NP_Np2ClCarrier *c,uint32_t session,uint32_t generation,
                           const uint8_t snapshot[64],uint32_t crc)
{
    NpClControlRequest q;
    if(!c || !snapshot || !session || !generation || !np_cl_control_parse(snapshot,64U,&q) ||
       q.op!=NP_CL_CONTROL_CONFIGURE || !q.count || q.config_crc!=crc)return -1;
    uint8_t copy[64];memcpy(copy,snapshot,64U);
    memset(c,0,sizeof(*c));memcpy(c->confirmed_config,copy,64U);
    c->session=session;c->generation=generation;c->config_crc=crc;c->initialized=1U;return 0;
}
int XE_NP_Np2ClCarrier_Push(XE_NP_Np2ClCarrier *c,const NpClEvent *event,uint64_t end,
                           uint32_t epoch,uint32_t reason,uint32_t flags)
{
    if(!c || !c->initialized || !event)return 0;
    inc(&c->attempted);
    if(c->stopped || c->sequence_exhausted){inc(&c->dropped);return 0;}
    uint32_t sequence=++c->next_sequence;
    if(sequence==UINT32_MAX)c->sequence_exhausted=1U;
    if(event->session!=c->session || c->head-c->tail>=NP2_CL_CARRIER_ROWS){
        inc(&c->dropped);if(event->session!=c->session)inc(&c->rejected);return 0;
    }
    uint8_t *out=c->event[c->head%NP2_CL_CARRIER_ROWS];
    if(!np_cl_event_pack(out,event,end,c->config_crc,sequence,epoch,c->dropped,reason,flags)){
        inc(&c->dropped);inc(&c->rejected);return 0;
    }
    c->head++;return 1;
}
int XE_NP_Np2ClCarrier_BindHeader(const XE_NP_Np2ClCarrier *c,uint8_t h[512])
{
    if(!c || !c->initialized || !copied(h))return -1;
    np_cl_wire_u32(h+52U,get32(h+52U)|NP2_CL_CARRIER_FLAG);
    memset(h+NP2_CL_CARRIER_SLOT,0,NP2_CL_CARRIER_BYTES);
    np_cl_wire_u32(h+NP2_CL_CARRIER_DROPS,c->dropped);
    np_cl_wire_u32(h+NP2_CL_CARRIER_CONFIG_CRC,c->config_crc);return 0;
}
int XE_NP_Np2ClCarrier_Claim(XE_NP_Np2ClCarrier *c,uint8_t h[512],XE_NP_Np2ClTicket *ticket)
{
    if(!ticket)return -1;
    memset(ticket,0,sizeof(*ticket));
    if(!c || !c->initialized || !copied(h) || !(get32(h+52U)&NP2_CL_CARRIER_FLAG) )return -1;
    memset(h+NP2_CL_CARRIER_SLOT,0,NP2_CL_CARRIER_BYTES);
    np_cl_wire_u32(h+NP2_CL_CARRIER_DROPS,c->dropped);
    np_cl_wire_u32(h+NP2_CL_CARRIER_CONFIG_CRC,c->config_crc);
    if(c->claimed)return -1;
    if(c->head==c->tail)return 0;
    const uint8_t *event=c->event[c->tail%NP2_CL_CARRIER_ROWS];
    memcpy(h+NP2_CL_CARRIER_SLOT,event,NP2_CL_CARRIER_BYTES);
    ticket->generation=c->generation;ticket->tail=c->tail;ticket->sequence=get32(event+12U);
    c->claim_tail=c->tail;c->claim_sequence=ticket->sequence;c->claimed=1U;return 1;
}
static int matches(const XE_NP_Np2ClCarrier *c,const XE_NP_Np2ClTicket *t)
{
    return c && t && c->initialized && c->claimed && t->sequence &&
        t->generation==c->generation && t->tail==c->claim_tail &&
        t->tail==c->tail && t->sequence==c->claim_sequence;
}
int XE_NP_Np2ClCarrier_Commit(XE_NP_Np2ClCarrier *c,const XE_NP_Np2ClTicket *t)
{
    if(!t)return 0;
    if(!t->sequence)return c && c->initialized && !c->claimed;
    if(!matches(c,t))return 0;
    c->claimed=0U;c->tail++;inc(&c->committed);return 1;
}
void XE_NP_Np2ClCarrier_Abort(XE_NP_Np2ClCarrier *c,const XE_NP_Np2ClTicket *t)
{if(matches(c,t))c->claimed=0U;}
void XE_NP_Np2ClCarrier_Stop(XE_NP_Np2ClCarrier *c)
{
    if(!c || !c->initialized || c->stopped)return;
    uint32_t queued=c->head-c->tail;
    add(&c->dropped,queued);add(&c->tail_dropped,queued);
    c->tail=c->head;c->claimed=0U;c->stopped=1U;
    /* A stopped generation never resumes. Initialization requires its owner
     * to supply a fresh generation before a new session can publish events. */
}
void XE_NP_Np2ClCarrier_Status(const XE_NP_Np2ClCarrier *c,XE_NP_Np2ClCarrierStatus *s)
{
    if(!s)return;
    memset(s,0,sizeof(*s));if(!c || !c->initialized)return;
    s->session=c->session;s->config_crc=c->config_crc;s->generation=c->generation;
    s->queued=c->head-c->tail;s->attempted=c->attempted;s->committed=c->committed;
    s->dropped=c->dropped;s->tail_dropped=c->tail_dropped;s->rejected=c->rejected;
    s->last_sequence=c->next_sequence;s->stopped=c->stopped;
}
int XE_NP_Np2ClCarrier_SummaryUnknown(uint32_t session,uint32_t crc,uint32_t generation,uint8_t p[64])
{
    if(!p || !session || !generation)return -1;
    memset(p,0,64U);memcpy(p,"NPCLEND1",8U);np_cl_wire_u32(p+8U,1U);np_cl_wire_u32(p+12U,64U);
    np_cl_wire_u32(p+16U,session);np_cl_wire_u32(p+20U,crc);np_cl_wire_u32(p+24U,generation);
    np_cl_wire_u32(p+52U,5U);np_cl_wire_u32(p+60U,np_cl_wire_crc(p,60U));return 0;
}
int XE_NP_Np2ClCarrier_SummaryEncode(const XE_NP_Np2ClCarrier *c,int unknown,uint8_t p[64])
{
    if(!c || !c->initialized || !c->stopped || !p || (unknown!=0 && unknown!=1))return -1;
    memset(p,0,64U);memcpy(p,"NPCLEND1",8U);np_cl_wire_u32(p+8U,1U);np_cl_wire_u32(p+12U,64U);
    np_cl_wire_u32(p+16U,c->session);np_cl_wire_u32(p+20U,c->config_crc);np_cl_wire_u32(p+24U,c->generation);
    np_cl_wire_u32(p+28U,c->attempted);np_cl_wire_u32(p+32U,c->committed);np_cl_wire_u32(p+36U,c->dropped);
    np_cl_wire_u32(p+40U,c->tail_dropped);np_cl_wire_u32(p+44U,c->rejected);np_cl_wire_u32(p+48U,c->next_sequence);
    np_cl_wire_u32(p+52U,1U|(c->sequence_exhausted?2U:0U)|((unknown || c->quality_unknown)?4U:0U));
    np_cl_wire_u32(p+60U,np_cl_wire_crc(p,60U));return 0;
}
int XE_NP_Np2ClCarrier_SummaryDecode(const uint8_t p[64],uint32_t session,uint32_t crc,
                                    XE_NP_Np2ClCarrierStatus *s,uint32_t *flags)
{
    if(!p || !s || !flags)return -1;
    memset(s,0,sizeof(*s));*flags=0U;
    if(memcmp(p,"NPCLEND1",8U) || get32(p+8U)!=1U || get32(p+12U)!=64U ||
       !session || get32(p+16U)!=session || get32(p+20U)!=crc || !get32(p+24U) ||
       !(get32(p+52U)&1U) || (get32(p+52U)&~7U) || get32(p+56U) ||
       get32(p+60U)!=np_cl_wire_crc(p,60U) || get32(p+40U)>get32(p+36U) ||
       get32(p+44U)>get32(p+36U) || get32(p+48U)>get32(p+28U) ||
       (get32(p+28U)!=UINT32_MAX && (uint64_t)get32(p+32U)+get32(p+36U)!=get32(p+28U)))return -1;
    s->session=session;s->config_crc=crc;s->generation=get32(p+24U);s->attempted=get32(p+28U);
    s->committed=get32(p+32U);s->dropped=get32(p+36U);s->tail_dropped=get32(p+40U);
    s->rejected=get32(p+44U);s->last_sequence=get32(p+48U);s->stopped=1U;*flags=get32(p+52U);return 0;
}
static uint64_t get64(const uint8_t *p){return get32(p)|((uint64_t)get32(p+4U)<<32U);}
int XE_NP_Np2ClCarrier_PatchPhase(uint8_t h[512],uint32_t phase)
{
    if(phase>=1600U || !copied(h) || !(get32(h+52U)&NP2_CL_CARRIER_FLAG))return 0;
    np_cl_wire_u32(h+172U,phase);return 1;
}
int XE_NP_Np2ClCarrier_ValidateHeader(const XE_NP_Np2ClCarrier *c,const uint8_t h[512])
{
    if(!c || !c->initialized || !copied(h) || !(get32(h+52U)&NP2_CL_CARRIER_FLAG) ||
       get32(h+252U)!=c->config_crc)return -1;
    const uint8_t *p=h+184U;uint32_t nonzero=0U;
    for(unsigned i=0U;i<64U;i++)nonzero|=p[i];
    if(!nonzero)return 0;
    NpClEvent e={0};e.kind=p[5];e.lane=p[6];e.session=get32(p+8U);
    e.probe=p[20];e.channel=(uint32_t)p[22]|((uint32_t)p[23]<<8U);e.source_tick=get64(p+24U);
    uint32_t bits=get32(p+44U);memcpy(&e.envelope,&bits,4U);bits=get32(p+48U);memcpy(&e.threshold,&bits,4U);
    uint8_t canonical[64];
    if(e.session!=c->session || get32(p+16U)!=c->config_crc || get32(p+52U)>get32(h+248U) ||
       !np_cl_event_pack(canonical,&e,get64(p+32U),c->config_crc,get32(p+12U),get32(p+40U),
                         get32(p+52U),get32(p+56U),p[7]) || memcmp(canonical,p,64U))return -1;
    return 1;
}
static int valid_meta(const XE_NP_Np2ClConfigMeta *m,const uint8_t snapshot[64])
{
    NpClControlRequest q;
    if(!np_cl_control_parse(snapshot,64U,&q) || q.op!=NP_CL_CONTROL_CONFIGURE || !q.count)return 0;
    uint32_t probe=q.selector[0]&255U;
    if(probe!=2U && probe!=3U)return 0;
    for(unsigned i=0U;i<q.count;i++)if((q.selector[i]&255U)!=probe ||
        (probe==3U?(q.selector[i]>>16U)<256U:(q.selector[i]>>16U)>1U))return 0;
    uint32_t count=q.count;
    return m && m->session && m->record_mask==7U && m->native_hz==get32(snapshot+20U) &&
        (m->native_hz==7500U || m->native_hz==15000U || m->native_hz==20000U || m->native_hz==30000U) &&
        m->source_hz==m->native_hz*1600U && m->source_step==(m->native_hz/1250U)*1600U &&
        m->delay_ticks==(22U*(m->native_hz/2500U)-2U)*1600U && m->filter_id==1U &&
        m->tap==(probe==2U?2U:0x203U) && !(m->flags&~15U) && (m->flags&1U) &&
        ((m->flags&2U)?m->epoch!=0U:m->epoch==0U) &&
        ((m->flags&4U)?m->phase[0]<1600U:m->phase[0]==0U) &&
        (count==1U?(m->phase[1]==0U && !(m->flags&8U)):
                       (count==2U && ((m->flags&8U)?m->phase[1]<1600U:m->phase[1]==0U)));
}
int XE_NP_Np2ClCarrier_ConfigEncode(const XE_NP_Np2ClCarrier *c,const XE_NP_Np2ClConfigMeta *m,uint8_t config[2048])
{
    if(!c || !c->initialized || !config || !valid_meta(m,c->confirmed_config) || m->session!=c->session)return -1;
    uint8_t *p=config+1888U;memset(p,0,160U);memcpy(p,"NPCLCFG1",8U);
    np_cl_wire_u32(p+8U,1U);np_cl_wire_u32(p+12U,160U);np_cl_wire_u32(p+16U,c->config_crc);
    np_cl_wire_u32(p+20U,m->session);np_cl_wire_u32(p+24U,m->native_hz);np_cl_wire_u32(p+28U,m->source_hz);
    memcpy(p+32U,c->confirmed_config,64U);np_cl_wire_u32(p+96U,1250U);np_cl_wire_u32(p+100U,m->epoch);
    np_cl_wire_u32(p+104U,m->delay_ticks);np_cl_wire_u32(p+108U,m->phase[0]);np_cl_wire_u32(p+112U,m->phase[1]);
    np_cl_wire_u32(p+116U,m->tap);np_cl_wire_u32(p+120U,m->flags);np_cl_wire_u32(p+124U,m->filter_id);
    np_cl_wire_u32(p+128U,m->source_step);np_cl_wire_u32(p+132U,m->record_mask);
    np_cl_wire_u32(p+156U,np_cl_wire_crc(p,156U));return 0;
}
int XE_NP_Np2ClCarrier_ConfigDecode(const uint8_t config[2048],int flag,XE_NP_Np2ClConfigMeta *m,uint8_t snapshot[64])
{
    if(!config || !m || !snapshot || (flag!=0 && flag!=1))return -1;
    const uint8_t *p=config+1888U;uint32_t any=0U;
    for(unsigned i=0U;i<160U;i++)any|=p[i];
    memset(m,0,sizeof(*m));memset(snapshot,0,64U);
    if(!flag)return any?-1:0;
    if(memcmp(p,"NPCLCFG1",8U) || get32(p+8U)!=1U || get32(p+12U)!=160U ||
       get32(p+156U)!=np_cl_wire_crc(p,156U) || get32(p+96U)!=1250U ||
       memcmp(p+32U,"NPCC",4U) || get32(p+36U)!=1U || get32(p+40U)!=1U ||
       get32(p+92U)!=get32(p+16U) || np_cl_wire_crc(p+32U,60U)!=get32(p+16U))return -1;
    for(unsigned i=136U;i<156U;i++)if(p[i])return -1;
    m->session=get32(p+20U);m->native_hz=get32(p+24U);m->source_hz=get32(p+28U);m->epoch=get32(p+100U);
    m->delay_ticks=get32(p+104U);m->phase[0]=get32(p+108U);m->phase[1]=get32(p+112U);
    m->tap=get32(p+116U);m->flags=get32(p+120U);m->filter_id=get32(p+124U);
    m->source_step=get32(p+128U);m->record_mask=get32(p+132U);
    if(!valid_meta(m,p+32U)){memset(m,0,sizeof(*m));return -1;}
    memcpy(snapshot,p+32U,64U);return 1;
}
static int workspace_sink(void *context,const NpClEvent *event)
{
    XE_NP_Np2ClWorkspace *w=(XE_NP_Np2ClWorkspace *)context;
    uint32_t reason=event->kind==NP_CL_EVENT_GAP?w->lane[event->lane].last_gap_reason:0U;
    if(event->kind==NP_CL_EVENT_GAP && !w->event_time_flags)w->carrier.quality_unknown=1U;
#if XE_NP_NP2_CLOSED_LOOP_PERF_ENABLE
    uint32_t began=XE_NP_Np2ClPerf_Begin(&w->perf);
#endif
    int result=XE_NP_Np2ClCarrier_Push(&w->carrier,event,w->input_end,w->epoch,reason,w->event_time_flags);
#if XE_NP_NP2_CLOSED_LOOP_PERF_ENABLE
    XE_NP_Np2ClPerf_End(&w->perf,NP2_CL_PERF_EVENT,began,1U);
#endif
    return result;
}
/* P2 native-word tap is initially qualified only for adjacent ADC0/1.
 * Historical P3 software extraction remains one-lane only. */
static int source_selector(const NpClControlRequest *q)
{
    unsigned probe=q->selector[0]&255U;
    if(probe==3U)return q->count==1U && (q->selector[0]>>16U)>=256U;
    if(probe!=2U)return 0;
    for(unsigned i=0U;i<q->count;i++)
        if((q->selector[i]&255U)!=2U || (q->selector[i]>>16U)>1U)return 0;
    return 1;
}
int XE_NP_Np2ClWorkspace_Configure(XE_NP_Np2ClWorkspace *w,const uint8_t body[64],const XE_NP_Np2ClSourceProof *p)
{
    NpClControlRequest q;
    if(!w)return NP_CL_CONTROL_MEMORY;
    if(!np_cl_control_parse(body,64U,&q) || q.op!=NP_CL_CONTROL_CONFIGURE)return NP_CL_CONTROL_INVALID;
    if(!q.count){w->arm_state=0U;w->source.enabled=0U;XE_NP_Np2ClCarrier_Stop(&w->carrier);return NP_CL_CONTROL_OK;}
    if(!source_selector(&q))return NP_CL_CONTROL_UNSUPPORTED;
    if(!p || !p->session || !p->generation || !p->source_epoch || !p->phase_verified ||
       !p->origin_valid || !p->copied || p->record_mask!=7U || p->native_hz!=q.ap_hz || p->phase>=1600U)
        return NP_CL_CONTROL_SOURCE;
    NpClCoefficients bank[2];NpClRate rate={1250U,1U};
    for(unsigned i=0U;i<q.count;i++){
        if(!np_cl_coefficients_get(rate,(q.selector[i]>>8U)&255U,&bank[i]))return NP_CL_CONTROL_UNSUPPORTED;
    }
    if(q.count==2U && (q.selector[0]>>16U)==(q.selector[1]>>16U))return NP_CL_CONTROL_INVALID;
    uint16_t selected_phase=(uint16_t)p->phase;
#if XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
    /* Physical-source admission must not erase the immutable confirmed
     * recording metadata when this optional receiver cannot attest. */
    if((q.selector[0]&255U)==2U && !XE_NP_Np2ClSelected_Proof(&selected_phase))return NP_CL_CONTROL_SOURCE;
#endif
    /* Admission above is side-effect free. Preserve caller aliases before
     * replacing its workspace; no recorder/DMA owner is touched. */
    XE_NP_Np2ClSourceProof proof=*p;p=&proof;
    uint8_t applied[64];memcpy(applied,body,64U);body=applied;
    memset(w,0,sizeof(*w));
    XE_NP_Np2ClosedLoopSpiConfig c={0};c.sample_hz=q.ap_hz;c.phase=selected_phase;
    c.probe=(uint8_t)(q.selector[0]&255U);c.lane=c.probe==2U?0U:2U;
    c.count=(uint8_t)q.count;c.phase_verified=c.origin_valid=1U;c.source_epoch=p->source_epoch;
    for(unsigned i=0U;i<q.count;i++)c.channel[i]=(uint16_t)(q.selector[i]>>16U);
    if(XE_NP_Np2ClosedLoopSpi_Init(&w->source,&c) ||
       XE_NP_Np2ClCarrier_Init(&w->carrier,p->session,p->generation,body,q.config_crc))return NP_CL_CONTROL_FAULT;
    for(unsigned i=0U;i<q.count;i++){
        NpClConfig k={0};k.sample_rate=rate;k.source_rate.num=q.ap_hz*1600U;k.source_rate.den=1U;
        k.source_step=(uint64_t)(q.ap_hz/1250U)*1600U;k.session=p->session;
        k.probe=c.probe;k.channel=c.channel[i];k.lane=i;k.training_start_ms=q.training_start_ms;
        k.training_duration_ms=q.training_duration_ms;k.threshold_gain=q.gain[i];k.rectify=(q.rectify_mask>>i)&1U;
        if(np_cl_init(&w->lane[i],&k,&bank[i],workspace_sink,w)!=NP_CL_OK){
            w->source.enabled=0U;XE_NP_Np2ClCarrier_Stop(&w->carrier);return NP_CL_CONTROL_FAULT;
        }
    }
    w->staged=w->prepared=1U;w->session_counter=p->generation;w->arm_state=0U;
    return NP_CL_CONTROL_OK;
}
void XE_NP_Np2ClWorkspace_Drain(XE_NP_Np2ClWorkspace *w)
{
    if(!w || !w->source.enabled || w->carrier.stopped ||
       (w->source.out_head==w->source.out_tail && !w->source.notice))return;
#if XE_NP_NP2_CLOSED_LOOP_PERF_ENABLE
    uint32_t began=XE_NP_Np2ClPerf_Begin(&w->perf),inputs=0U;
#endif
    XE_NP_Np2ClosedLoopSpiOutput row;
    for(unsigned n=0U;n<NP2_CL_SPI_OUTPUT_ROWS && XE_NP_Np2ClosedLoopSpi_Pop(&w->source,&row);n++){
        w->input_end=row.input_end_tick;w->epoch=row.source_epoch;
        w->event_time_flags=(row.flags&NP2_CL_SPI_TIME_VALID)?NP_CL_EVENT_TIME_VALID:0U;
        for(unsigned i=0U;i<w->source.config.count;i++){
            NpClInput input={row.source_tick,(float)row.nominal_q3[i]*0.125f,NP_CL_INPUT_VALID};
            if(!(row.flags&NP2_CL_SPI_VALID) || !w->event_time_flags)
                input.flags=!w->event_time_flags?NP_CL_INPUT_FAULT:
                    row.reason==NP2_CL_SPI_REASON_PRESSURE?NP_CL_INPUT_PRESSURE:NP_CL_INPUT_DISCONTINUITY;
            else if((row.flags&NP2_CL_SPI_RESET) && w->lane[i].have_tick)np_cl_reset(&w->lane[i],NP_CL_REASON_RESET);
            (void)np_cl_input(&w->lane[i],&input);
#if XE_NP_NP2_CLOSED_LOOP_PERF_ENABLE
            inputs++;
#endif
        }
        if(!w->event_time_flags){w->failure=NP_CL_CONTROL_SOURCE;w->source.enabled=0U;break;}
    }
#if XE_NP_NP2_CLOSED_LOOP_PERF_ENABLE
    XE_NP_Np2ClPerf_End(&w->perf,NP2_CL_PERF_KERNEL,began,inputs);
#endif
}
#if XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
#if !XE_NP_NP2_CLOSED_LOOP_SPI_ENABLE
#error "Closed-loop carrier requires its explicit SPI source opt-in"
#endif
static XE_NP_Np2ClWorkspace *port;
int XE_NP_Np2ClCarrier_SelectedRequest(uint16_t channel[2],uint8_t *count)
{
    if(!port || !port->prepared || !port->staged || port->failure)return 0;
    NpClControlRequest q;
    if(!np_cl_control_parse(port->carrier.confirmed_config,64U,&q) ||
       !q.count || (q.selector[0]&255U)!=2U || !source_selector(&q))return 0;
    *count=(uint8_t)q.count;
    for(unsigned i=0U;i<q.count;i++)channel[i]=(uint16_t)(q.selector[i]>>16U);
    return 1;
}
void XE_NP_Np2ClCarrier_PortBind(XE_NP_Np2ClWorkspace *w)
{port=w;XE_NP_Np2ClosedLoopSpi_PortBind(w?&w->source:0);}
int XE_NP_Np2ClCarrier_PortControl(const uint8_t body[64],uint8_t reply[64],int busy,uint32_t mask,uint32_t hz,int copied_mode)
{
    if(!body || memcmp(body,"NPCC",4U))return 0;
#if XE_NP_NP2_CLOSED_LOOP_WORKSPACE_ENABLE
    if(!port)XE_NP_Np2ClRuntime_Ensure();
#endif
    NpClControlRequest q={0};NpClControlReply r={0};
    r.op=get32(body+8U);r.id=get32(body+12U);
    if(r.op>2U || !r.id)return -1;
    if(!np_cl_control_parse(body,64U,&q))r.result=NP_CL_CONTROL_INVALID;
    else if(q.op==NP_CL_CONTROL_CONFIGURE){
        if(busy)r.result=NP_CL_CONTROL_BUSY;
        else if(!port)r.result=NP_CL_CONTROL_MEMORY;
        else if(!q.count){
            port->source.enabled=0U;XE_NP_Np2ClCarrier_Stop(&port->carrier);
            port->staged=port->prepared=port->failure=port->arm_state=0U;
        }else if(mask!=7U || q.ap_hz!=hz || !copied_mode)r.result=NP_CL_CONTROL_UNSUPPORTED;
        else{
            NpClRate rate={1250U,1U};NpClCoefficients bank;
            if(!source_selector(&q))r.result=NP_CL_CONTROL_UNSUPPORTED;
            for(unsigned i=0U;i<q.count;i++)if(!np_cl_coefficients_get(rate,(q.selector[i]>>8U)&255U,&bank))r.result=NP_CL_CONTROL_UNSUPPORTED;
            if(q.count==2U && (q.selector[0]>>16U)==(q.selector[1]>>16U))r.result=NP_CL_CONTROL_INVALID;
            if(!r.result){
                port->source.enabled=0U;XE_NP_Np2ClCarrier_Stop(&port->carrier);
                memcpy(port->carrier.confirmed_config,body,64U);port->carrier.initialized=0U;
                port->carrier.config_crc=q.config_crc;port->carrier.session=0U;
                port->staged=1U;port->prepared=port->failure=0U;port->arm_state=1U;
            }
        }
    }
    if(port){
        r.flags=NP_CL_CONTROL_SUPPORTED;r.max_lanes=2U;r.probe_mask=6U;r.filter_mask=1023U;r.channel_groups=264U;
        r.config_crc=port->carrier.config_crc;r.session=port->carrier.session;
        r.ap_hz=port->staged?get32(port->carrier.confirmed_config+20U):0U;
        r.drops=port->carrier.dropped;
        if(port->staged)r.flags|=NP_CL_CONTROL_CONFIGURED;
        if(port->staged && port->arm_state==1U)r.flags|=NP_CL_CONTROL_SNAPSHOT_STAGED;
        if(port->source.enabled && port->prepared){r.flags|=NP_CL_CONTROL_RUNNING;
            if(port->source.config.origin_valid){r.flags|=NP_CL_CONTROL_ORIGIN_VALID;r.source_epoch=port->source.config.source_epoch;}}
        if(q.op!=NP_CL_CONTROL_CONFIGURE && !r.result && port->failure)r.result=port->failure;
    }
    return np_cl_control_reply_pack(reply,&r)?1:-1;
}
void XE_NP_Np2ClCarrier_PortBeginAttempt(void)
{
    if(!port)return;
    port->arm_state=port->arm_state==1U?2U:0U;
    port->prepared=0U;port->source.enabled=0U;port->source.config.origin_valid=0U;
}
int XE_NP_Np2ClCarrier_PortPrepare(uint32_t session,uint32_t mask,uint32_t hz,uint32_t codec,uint32_t flags,int copied_mode)
{
    if(!port || port->arm_state!=2U)return 0;
    port->arm_state=0U; /* Consume even an unsupported/failed preparation. */
    if(!port->staged)return 0;
    if(mask!=7U || codec!=6U || hz!=get32(port->carrier.confirmed_config+20U) ||
       !copied_mode || (flags&0x40U) || !(flags&32U) || port->session_counter==UINT32_MAX){
        port->prepared=0U;port->failure=NP_CL_CONTROL_SOURCE;return 0;
    }
    uint32_t generation=++port->session_counter;
    uint8_t body[64];memcpy(body,port->carrier.confirmed_config,64U);
    if(session){
        if(XE_NP_Np2ClCarrier_Init(&port->carrier,session,generation,body,get32(body+60U))){
            port->failure=NP_CL_CONTROL_FAULT;return 0;
        }
    }else{
        /* Live USB has no confirmed capture session before arm. Prepared
         * headers carry an empty slot/config binding only; no event can run. */
        memset(&port->carrier,0,sizeof(port->carrier));
        memcpy(port->carrier.confirmed_config,body,64U);port->carrier.config_crc=get32(body+60U);
        port->carrier.generation=generation;port->carrier.initialized=1U;
    }
    port->source.enabled=0U;port->source.config.origin_valid=0U;
    port->prepared=1U;port->failure=0U;port->carrier.quality_unknown=1U;return 1;
}
void XE_NP_Np2ClCarrier_PortTiming(uint64_t token)
{if(port && port->prepared && !port->source.enabled)port->timing_token=token;}
int XE_NP_Np2ClCarrier_PortNeedsProof(void)
{return port && port->prepared && port->staged && !port->failure && !port->source.enabled;}
int XE_NP_Np2ClCarrier_PortAdmit(const XE_NP_Np2ClSourceProof *current,uint64_t first,uint32_t published)
{
    if(!XE_NP_Np2ClCarrier_PortNeedsProof())return 0;
    if(!current || first || published){port->failure=NP_CL_CONTROL_SOURCE;return -1;}
    XE_NP_Np2ClSourceProof proof=*current;proof.session=port->carrier.session?port->carrier.session:current->source_epoch;proof.generation=port->carrier.generation;
    uint8_t body[64];memcpy(body,port->carrier.confirmed_config,64U);
    uint64_t token=port->timing_token;
    int result=XE_NP_Np2ClWorkspace_Configure(port,body,&proof);
    port->timing_token=token;
    if(result){port->failure=(uint32_t)result;port->carrier.quality_unknown=1U;return -1;}
    return 1;
}
int XE_NP_Np2ClCarrier_PortAttest(const XE_NP_Np2ClStartupReceipt *r,uint64_t first,uint32_t published)
{
    if(!XE_NP_Np2ClCarrier_PortNeedsProof())return 0;
    XE_NP_Np2ClSourceProof p={0};
    if(!r || (port->carrier.session?
          r->session!=port->carrier.session:
          (!port->timing_token || r->timing_token!=port->timing_token || r->timing_generation!=r->source_epoch)) ||
       (r->anchor_flags&0x205U)!=0x205U || r->origin_lo || r->origin_hi ||
       !r->source_epoch || r->source_hz!=r->native_hz*1600U || r->phase>=1600U ||
       r->matches!=1U || r->error || r->record_mask!=7U || !r->copied)
        return XE_NP_Np2ClCarrier_PortAdmit(0,first,published);
    p.native_hz=r->native_hz;p.record_mask=r->record_mask;p.source_epoch=r->source_epoch;
    /* CopyD8 bytes are ALREADY offset-corrected into PSSI source coordinates.
     * This is PSSI frame phase, never the original SPI DMA bit offset. */
    p.phase=(uint16_t)r->phase;p.phase_verified=p.origin_valid=p.copied=1U;
    int result=XE_NP_Np2ClCarrier_PortAdmit(&p,first,published);
#if XE_NP_NP2_CLOSED_LOOP_PERF_ENABLE
    if(result==1){port->perf.core_hz=r->core_hz;port->perf.cycles_valid=r->core_hz && XE_NP_Np2ClPerf_Available();}
#endif
    return result;
}
const XE_NP_Np2ClCarrier *XE_NP_Np2ClCarrier_PortOwner(void)
{return port && port->prepared && port->carrier.initialized?&port->carrier:0;}
int XE_NP_Np2ClCarrier_PortConfig(uint8_t config[2048])
{
    if(!port || !port->prepared || !port->carrier.initialized)return 0;
    uint32_t hz=get32(port->carrier.confirmed_config+20U);
    XE_NP_Np2ClConfigMeta m={0};m.session=port->carrier.session;m.native_hz=hz;m.source_hz=hz*1600U;
    m.delay_ticks=(22U*(hz/2500U)-2U)*1600U;
    m.tap=(get32(port->carrier.confirmed_config+36U)&255U)==2U?2U:0x203U;
    m.flags=1U;m.filter_id=1U;
    m.source_step=(hz/1250U)*1600U;m.record_mask=7U;
    return XE_NP_Np2ClCarrier_ConfigEncode(&port->carrier,&m,config)?-1:1;
}
uint32_t XE_NP_Np2ClCarrier_PortFlag(uint32_t mask,uint32_t hz,uint32_t codec,uint32_t flags)
{
    return port && port->prepared && port->staged && port->carrier.initialized && mask==7U && codec==6U &&
        hz==get32(port->carrier.confirmed_config+20U) && !(flags&0x40U) && (flags&32U)?NP2_CL_CARRIER_FLAG:0U;
}
int XE_NP_Np2ClCarrier_PortHeader(uint8_t h[512])
{return port && (get32(h+52U)&NP2_CL_CARRIER_FLAG)?XE_NP_Np2ClCarrier_BindHeader(&port->carrier,h):0;}
int XE_NP_Np2ClCarrier_PortClaim(uint8_t h[512],XE_NP_Np2ClTicket *t)
{if(port && (get32(h+52U)&NP2_CL_CARRIER_FLAG))return XE_NP_Np2ClCarrier_Claim(&port->carrier,h,t);memset(t,0,sizeof(*t));return 0;}
int XE_NP_Np2ClCarrier_PortCommit(const XE_NP_Np2ClTicket *t)
{return !t->sequence?1:port?XE_NP_Np2ClCarrier_Commit(&port->carrier,t):0;}
int XE_NP_Np2ClCarrier_PortValidate(const uint8_t h[512])
{return port?XE_NP_Np2ClCarrier_ValidateHeader(&port->carrier,h):-1;}
void XE_NP_Np2ClCarrier_PortFault(void)
{if(port){port->arm_state=0U;port->source.enabled=0U;port->source.config.origin_valid=0U;port->failure=NP_CL_CONTROL_SOURCE;port->carrier.quality_unknown=1U;}}
void XE_NP_Np2ClCarrier_PortStop(void)
{
    if(!port)return;
    port->arm_state=0U;
    /* Source owner has already stopped capture. Finish only the bounded
     * accepted detector backlog before reporting its uncarried tail events.
     * No synthetic input, extra neural block, I/O, or waiting is introduced. */
    XE_NP_Np2ClWorkspace_Drain(port);
    for(unsigned n=0U;n<NP2_CL_SPI_INPUT_ROWS/NP2_CL_SPI_SERVICE_ROWS;n++){
        if(!port->source.enabled || port->source.in_head==port->source.in_tail)break;
        (void)XE_NP_Np2ClosedLoopSpi_Service(&port->source,NP2_CL_SPI_SERVICE_ROWS);
        XE_NP_Np2ClWorkspace_Drain(port);
    }
    port->source.enabled=0U;XE_NP_Np2ClCarrier_Stop(&port->carrier);port->prepared=0U;
}
void XE_NP_Np2ClCarrier_PortDrain(void){XE_NP_Np2ClWorkspace_Drain(port);}
#if XE_NP_NP2_CLOSED_LOOP_PERF_ENABLE
XE_NP_Np2ClPerf *XE_NP_Np2ClCarrier_PortPerf(void){return port?&port->perf:0;}
#endif
#endif
