#include <stdint.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
static inline uint8_t actual_sync(uint32_t position)
{
    static const uint8_t super_sync[12]={0xD3U,0x6AU,0x59U,0xC5U,0x3EU,0xA7U,
                                         0x1DU,0xE4U,0xB2U,0x4FU,0x78U,0x96U};
    uint32_t frame=position/100U,bit=position%100U;
    if(bit==0U)return frame==0U?7U:0U;
    if(bit==1U)return 0U;
    uint8_t wire=0U;
    for(uint32_t line=0U;line<3U;line++) {
        uint32_t at=frame*6U+line*2U+bit-2U;
        wire|=(uint8_t)(((super_sync[at/8U]>>(at&7U))&1U)<<line);
    }
    return wire;
}

static struct {uint32_t CYCCNT;} dwt;
#define DWT (&dwt)
static volatile uint32_t xe_np_np2_cl_selected_diag[32];
static uint32_t calls;
static uint8_t XE_NP_Np2D8ExpectedSync(uint32_t at){calls++;return actual_sync(at);}
typedef struct {uint32_t best,runner,phase,matches;} Result;
static uint32_t sync4_matches(const uint8_t *pssi,uint32_t at,uint32_t wanted)
{
    uint32_t raw;
    if(at<=1596U)memcpy(&raw,pssi+at,sizeof(raw));
    else{
        raw=0U;
        for(unsigned b=0U;b<4U;b++){
            uint32_t p=at+b;if(p>=1600U)p-=1600U;
            raw|=(uint32_t)pssi[p]<<(b*8U);
        }
    }
    uint32_t x=((raw>>3U)&0x07070707U)^wanted;
    uint32_t bad=(x|(x>>1U)|(x>>2U))&0x01010101U;
    return 4U-((bad*0x01010101U)>>24U);
}

static Result old_phase(const uint8_t *pssi){uint32_t began=0U;(void)began;
    uint32_t best=0U,runner=0U,phase=0U,pm=0U;
    for(uint32_t k=0U;k<1600U;k++){
        uint32_t screen=0U;
        for(unsigned f=0U;f<2U;f++)for(unsigned b=0U;b<4U;b++){
            uint32_t at=(f*100U+b+1600U-k)%1600U;
            screen+=((pssi[at]>>3U)&7U)==XE_NP_Np2D8ExpectedSync(f*100U+b);
        }
        if(screen<6U)continue;
        uint32_t score=0U;
        for(unsigned f=0U;f<16U;f++)for(unsigned b=0U;b<4U;b++){
            uint32_t at=(f*100U+b+1600U-k)%1600U;
            uint8_t wanted=XE_NP_Np2D8ExpectedSync(f*100U+b);
            for(;at<4800U;at+=1600U)score+=((pssi[at]>>3U)&7U)==wanted;
        }
        if(score>best){runner=best;best=score;phase=k;pm=1U;}
        else if(score==best){runner=score;pm++;}else if(score>runner)runner=score;
    }
return Result{best,runner,phase,pm};}
static Result new_phase(const uint8_t *pssi){uint32_t began=0U;(void)began;
    uint8_t expected[16][4];
    for(unsigned f=0U;f<16U;f++)for(unsigned b=0U;b<4U;b++)
        expected[f][b]=XE_NP_Np2D8ExpectedSync(f*100U+b);
    uint32_t packed[2]={0U,0U};
    for(unsigned f=0U;f<2U;f++)for(unsigned b=0U;b<4U;b++)
        packed[f]|=(uint32_t)expected[f][b]<<(b*8U);
    uint32_t best=0U,runner=0U,phase=0U,pm=0U;
    for(uint32_t k=0U;k<1600U;k++){
        uint32_t at0=k?1600U-k:0U,at1=at0+100U;
        if(at1>=1600U)at1-=1600U;
        uint32_t screen=sync4_matches(pssi,at0,packed[0])+sync4_matches(pssi,at1,packed[1]);
        if(screen<6U)continue;
        uint32_t score=0U;
        for(unsigned f=0U;f<16U;f++)for(unsigned b=0U;b<4U;b++){
            uint32_t at=f*100U+b+1600U-k;if(at>=1600U)at-=1600U;
            uint8_t wanted=expected[f][b];
            for(;at<4800U;at+=1600U)score+=((pssi[at]>>3U)&7U)==wanted;
        }
        if(score>best){runner=best;best=score;phase=k;pm=1U;}
        else if(score==best){runner=score;pm++;}else if(score>runner)runner=score;
    }
    xe_np_np2_cl_selected_diag[20]=DWT->CYCCNT-began;
return Result{best,runner,phase,pm};}

int main(void){
 uint8_t expected[16][4];for(unsigned f=0;f<16;f++)for(unsigned b=0;b<4;b++)expected[f][b]=actual_sync(f*100+b);
 static const uint8_t values[64]={7,0,5,1,0,0,1,7,0,0,6,1,0,0,6,1,0,0,3,0,0,0,5,7,0,0,5,5,0,0,1,6,0,0,7,2,0,0,4,0,0,0,2,7,0,0,2,6,0,0,3,3,0,0,1,4,0,0,3,5,0,0,3,4};
 for(unsigned f=0;f<16;f++)for(unsigned b=0;b<4;b++)assert(expected[f][b]==values[f*4+b]);
 uint32_t screens=0U;
 for(unsigned at=0;at<1600U;at++)for(unsigned mask=0;mask<16U;mask++)for(unsigned flip=1;flip<=7;flip++){
  uint8_t data[1600];memset(data,0x87,sizeof(data));uint32_t wanted=0U,scalar=0U;
  for(unsigned b=0;b<4;b++){uint32_t p=(at+b)%1600U;uint8_t v=expected[at%16U][b];
   wanted|=(uint32_t)v<<(b*8U);data[p]=(uint8_t)((data[p]&~56U)|((v^((mask&(1U<<b))?flip:0U))<<3U));}
  for(unsigned b=0;b<4;b++)scalar+=((data[(at+b)%1600U]>>3U)&7U)==((wanted>>(b*8U))&7U);
  assert(sync4_matches(data,at,wanted)==scalar);screens++;
 }
 uint32_t tested=0,minold=0xFFFFFFFFU,maxold=0;
 const uint32_t phases[]={0,1,2,3,4,19,97,98,99,100,101,253,1473,1596,1597,1598,1599};
 for(unsigned p=0;p<17;p++)for(unsigned noise=0;noise<4;noise++){
  uint8_t data[4800];uint32_t rng=0x13579BDFU;
  for(unsigned i=0;i<4800;i++){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;data[i]=(uint8_t)rng;}
  unsigned index=0;
  for(unsigned f=0;f<16;f++)for(unsigned b=0;b<4;b++){
   unsigned at=(f*100+b+1600-phases[p])%1600;
   for(;at<4800;at+=1600){uint8_t v=expected[f][b];if(noise && ++index%(noise==1?17:noise==2?7:2)==0)v^=1U;
    data[at]=(uint8_t)((data[at]&~56U)|(v<<3));}
  }
  calls=0;Result a=old_phase(data);uint32_t oldcalls=calls;
  calls=0;Result c=new_phase(data);assert(calls==64U && !memcmp(&a,&c,sizeof(a)));
  if(!noise)assert(c.phase==phases[p] && c.best==192U && c.matches==1U);
  if(oldcalls<minold)minold=oldcalls;if(oldcalls>maxold)maxold=oldcalls;tested++;
 }
 for(unsigned pattern=0;pattern<2;pattern++){
  uint8_t data[4800];memset(data,pattern?255:0,sizeof(data));calls=0;Result a=old_phase(data);
  calls=0;Result b=new_phase(data);assert(calls==64U && !memcmp(&a,&b,sizeof(a)));tested++;
 }
 printf("PASS64lookup values, %u actualpacked4byte screens(all1600starts/wrap/masks/3bitflips), %u actualold/new coldphase cases: identical best/runner/phase/ties; expectedSync calls old%u..%u/new64. No Cortex runtime/deadline claim\n",screens,tested,minold,maxold);
 return 0;
}
