from pathlib import Path
import subprocess,hashlib,json
T=Path(__file__).resolve().parent;R=Path('D:/Code/XE_NP_V2');N=T.parent
K=Path('C:/Frank/Code/XE_NP/Firmware/V1/Core');S=Path('D:/Code/WILDX_console/WILDX_console/Neuropixels/ClosedLoop')
vc='C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat'
defs=['XE_NP_NP2_CLOSED_LOOP_SPI_ENABLE=1','XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE=1','XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE=1','XE_NP_NP2_SD_APPEND_ORDER_TEST=1','XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES=1','XE_NP_NP2_USB_V3_ENABLE=1','XE_NP_NP2_USB_V3_PROBE_MASK=7','_CRT_SECURE_NO_WARNINGS']
(T/'legacy.c').write_text('#define main legacy_main\n#include "'+(R/'Tools/V2SdLogger/tests/test_np2_closed_loop_carrier.c').as_posix()+'"\n')
src=[N/'Core/Src/xe_np_np2_closed_loop_spi.c',N/'Core/Src/xe_np_np2_closed_loop_carrier.c',T/'legacy.c']
src += [R/'Core/Src'/(u+'.c') for u in ['xe_np_np2_closed_loop_sd','xe_np_np2_dual_sd_meta','xe_np_np2_dual_sd_run','xe_np_np2_dual_sd_catalog']]
src += [R/'Tools/V2SdLogger/tests'/n for n in ['test_np2_closed_loop_sd.c','test_np2_closed_loop_catalog.c']]+[K/'Src/np_cl_kernel.c',T/'extension.c']
q=lambda p:'"'+str(p)+'"'
cmd='call '+q(vc)+' >nul && cl /nologo /std:c11 /W4 /WX /O2 '+ ' '.join('/D'+d for d in defs)+' '+ ' '.join('/I'+q(p) for p in [N/'Core/Inc',R/'Core/Inc',K/'Inc',S])+' '+' '.join(map(q,src))+' /Fo'+q(str(T)+'/')+' /Fe'+q(T/'carrier.exe')
(T/'build.cmd').write_text('@echo off\n'+cmd+'\n')
r=subprocess.run(['cmd','/d','/c',str(T/'build.cmd')],cwd=T,capture_output=True,text=True);(T/'compile.log').write_text(r.stdout+r.stderr)
assert not r.returncode,(r.stdout+r.stderr)[-6000:]
r=subprocess.run([str(T/'carrier.exe')],cwd=T,capture_output=True,text=True);(T/'run.log').write_text(r.stdout+r.stderr)
assert not r.returncode,(r.returncode,r.stdout+r.stderr)
(T/'result.json').write_text(json.dumps(dict(status='PASS',source_pins={str(p):hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in src},output=r.stdout),indent=2)+'\n');print(r.stdout)
