"""Reconstruct one retained P2 wire interval; no recording payload scan."""
from pathlib import Path
import json,struct,hashlib
from match_bootstrap import RUN,EXPORT,OUT,expected_sync,hash_bytes

def main():
    blob=(RUN/'spi1-bootstrap.bin').read_bytes();words=struct.unpack('<3072I',blob)
    spi=''.join(f'{w:032b}' for w in words)
    meta=json.loads((EXPORT/'first_sample_timestamps.json').read_text())
    first=next(r['decoder_first_row_source_tick'] for r in meta['rows'] if r['probe']==2 and r['band']=='ap')
    with (EXPORT/'neuropixels_probe2_ap.dat').open('rb') as f:prefix=f.read(128*384*2)
    data=struct.unpack('<49152h',prefix)
    def bit(tick,lane=0):
        row,pos=divmod(tick-first,1600);assert 0<=row<128
        sub,within=divmod(pos,100)
        if within<4:return expected_sync(sub,within,lane)
        word,at=divmod(within-4,12)
        ch=sub*2+(word%2)+(word//2)*32+lane*128
        raw=2048-data[row*384+ch]
        return (raw>>(11-at))&1
    anchor=1600;signature=''.join(str(bit(t)) for t in range(anchor,anchor+256))
    hits=[d for d in range(-1600,1600) if spi[anchor+d:anchor+d+256]==signature]
    assert hits==[146],hits
    wrong=''.join(str(bit(t,1)) for t in range(anchor,anchor+256))
    wrong_hits=[d for d in range(-1600,1600) if spi[anchor+d:anchor+d+256]==wrong]
    assert not wrong_hits
    result=dict(status='UNIQUE_EXACT_RETAINED_COMMON_INTERVAL',anchor_pssi_tick=anchor,bits=256,
      reconstructed_from='P2 first128DATrows + documented SuperSync, calibration=null',
      decoder_first_full_header_tick=first,exact_signed_spi_minus_pssi_ticks=hits,
      searched_offsets=[-1600,1599],wrong_P2_lane1_signature_hits=wrong_hits,
      signature_sha256=hash_bytes(signature.encode()),bootstrap_sha256=hash_bytes(blob),
      dat_prefix_sha256=hash_bytes(prefix),
      interpretation='SPI[1746:2002] equals retained P2lane0 PSSI ticks1600..1855 bit-for-bit; bootstrap physicalroute/order/coordinate validated without touching the recording.',
      limits=['PSSI ticks0..255 precede the firstcompleteP2DATrow at1581; they cannot be reconstructed from this export.',
        'A first256bit strict startup match can reject if initial receiver bits are unqualified, but saved evidence does not prove any early bit was wrong.',
        'No saved first-call CBR1/CDAR/DWT/failure branch. Cannot distinguish initial-match rejection, sync-screen failure or publication deadline from fault5 alone.',
        'Later256bit window fixes startup exposure only; it does not establish the cold calibration completes within the3.072ms bootstrap budget.'])
    (OUT/'common-window.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2));print('resultSHA256 '+hash_bytes((OUT/'common-window.json').read_bytes()))
if __name__=='__main__':main()
