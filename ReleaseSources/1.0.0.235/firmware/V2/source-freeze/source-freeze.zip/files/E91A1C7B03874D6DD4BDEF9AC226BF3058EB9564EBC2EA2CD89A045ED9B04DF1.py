from pathlib import Path
import json,hashlib,struct
T=Path(__file__).resolve().parent;O=T/'final-pair-r7';D=O/'deployment';D.mkdir(parents=True,exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest().upper()
base=(T/'final-pair/deployment/after-full.bin').read_bytes();r=json.loads((T/'final-pair/deployment/receipt.json').read_text());assert sha(base)==r['after_full_sha256'] and struct.unpack_from('<I',base,0x1e020)[0]==0x7F0C8BD0
new=bytearray(base);pages=[]
for label,at,size,p in [('app-body',0x20000,376832,T/'build-r7/application.bin'),('app-manifest',0x1e000,8192,T/'build-r7/application.manifest.bin'),('usb-body',0x180000,335872,T/'usb-paired-r7/application.bin'),('usb-manifest',0x17e000,8192,T/'usb-paired-r7/application.manifest.bin')]:
 payload=p.read_bytes();assert len(payload)<=size;new[at:at+len(payload)]=payload;b=bytes(new[at:at+size]);(D/(label+'.bin')).write_bytes(b);pages.append(dict(name=label,address=0x08000000+at,bytes=size,sha256=sha(b)))
(D/'expected-full.bin').write_bytes(new);(D/'receipt.json').write_text(json.dumps(dict(before_full_sha256=sha(base),after_full_sha256=sha(new),crc32='APP99CC44F9_USBFFC27E5A',pages=pages,scope='Final production APP without diagnostic hold plus matching identity-only USB job; original restore pages preserved'),indent=2)+'\n')
s=(T/'build-r6/install.ps1').read_text().replace("'build-r6/deployment'","'final-pair-r7/deployment'").replace('Cache-fixed APP installed and fully verified; USB service unchanged.','Final production APP99CC44F9/USBFFC27E5A exact flash/options verified; diagnostic hold absent.')
(O/'install.ps1').write_text(s);print(sha(new))
