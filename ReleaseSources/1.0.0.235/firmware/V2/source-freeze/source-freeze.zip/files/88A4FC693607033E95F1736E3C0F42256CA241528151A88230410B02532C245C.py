"""Actual old/new cold phase loops; source-equivalence and bounded native cases."""
from pathlib import Path
import hashlib,json,subprocess
from test_selected_reader import SOURCE,OUT,ROOT,VC,extract,sha

def main():
    oldpath=next((SOURCE.parents[2]/'checked-71FC').rglob('xe_np_np2_cl_selected.c'))
    old=oldpath.read_text();new=SOURCE.read_text()
    oldcal=extract(old,'int XE_NP_Np2ClSelected_Calibrate(')
    newcal=extract(new,'int XE_NP_Np2ClSelected_Calibrate(')
    packed=extract(new,'static uint32_t sync4_matches(')
    import re
    assert re.sub(r'\s+','',old.replace(oldcal,'CALIBRATE'))==re.sub(r'\s+','',new.replace(newcal,'CALIBRATE').replace(packed,'')), 'Only cold Calibrate/helper changes allowed'
    unchanged={}
    for sig in ('int XE_NP_Np2ClSelected_Offer(', 'static uint32_t frontier(', 'void GPDMA1_Channel15_IRQHandler(',
      'static int read_bound_fine(', 'static void note_offer(', 'static int noncacheable_dma_memory(',
      'static int owner_quiet(', 'static void config_node('):
        before=extract(old,sig);assert before==extract(new,sig)
        unchanged[sig]=hashlib.sha256(before.encode()).hexdigest().upper()
    def loop(s):
        a=s.index('    cal[0]=3U;')+len('    cal[0]=3U;\n');b=s.index('    cal[5]=best;',a)
        return s[a:b]
    header=(ROOT/'Core/Inc/xe_np_np2_d8_calibration.h').read_text()
    sync=extract(header,'static inline uint8_t XE_NP_Np2D8ExpectedSync(').replace('XE_NP_Np2D8ExpectedSync(','actual_sync(')
    fixture='''#include <stdint.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
'''+sync+'''
static struct {uint32_t CYCCNT;} dwt;
#define DWT (&dwt)
static volatile uint32_t xe_np_np2_cl_selected_diag[32];
static uint32_t calls;
static uint8_t XE_NP_Np2D8ExpectedSync(uint32_t at){calls++;return actual_sync(at);}
typedef struct {uint32_t best,runner,phase,matches;} Result;
'''+packed+'\n'
    for name,text in [('old_phase',loop(old)),('new_phase',loop(new))]:
        fixture+='static Result '+name+'(const uint8_t *pssi){uint32_t began=0U;(void)began;\n'+text+'return Result{best,runner,phase,pm};}\n'
    fixture+=r'''
int main(void){
 uint8_t expected[16][4];for(unsigned f=0;f<16;f++)for(unsigned b=0;b<4;b++)expected[f][b]=actual_sync(f*100+b);
 static const uint8_t values[64]={'''
    raw=(0xD3,0x6A,0x59,0xC5,0x3E,0xA7,0x1D,0xE4,0xB2,0x4F,0x78,0x96)
    def wanted(f,b):
        if b<2:return 7 if f==0 and b==0 else 0
        return sum(((raw[(f*6+l*2+b-2)//8]>>((f*6+l*2+b-2)%8))&1)<<l for l in range(3))
    fixture+=','.join(str(wanted(f,b)) for f in range(16) for b in range(4))+r'''};
 for(unsigned f=0;f<16;f++)for(unsigned b=0;b<4;b++)assert(expected[f][b]==values[f*4+b]);
 uint32_t screens=0U;
 for(unsigned at=0;at<1600U;at++)for(unsigned mask=0;mask<16U;mask++)for(unsigned flip=1;flip<=7;flip++){
  uint8_t data[1600];memset(data,0x87,sizeof(data));uint32_t wanted=0U,scalar=0U;
  for(unsigned b=0;b<4;b++){uint32_t p=(at+b)%1600U;uint8_t v=expected[at%16U][b];
   wanted|=(uint32_t)v<<(b*8U);data[p]=(uint8_t)((data[p]&~56U)|((v^((mask&(1U<<b))?flip:0U))<<3U));}
  for(unsigned b=0;b<4;b++)scalar+=((data[(at+b)%1600U]>>3U)&7U)==((wanted>>(b*8U))&7U);
  assert(sync4_matches(data,at,wanted)==scalar);screens++;
 }
 uint32_t tested=0,minold=0xFFFFFFFFU,maxold=0;
 const uint32_t phases[]={0,1,2,3,4,19,97,98,99,100,101,253,1473,1596,1597,1598,1599};
 for(unsigned p=0;p<17;p++)for(unsigned noise=0;noise<4;noise++){
  uint8_t data[4800];uint32_t rng=0x13579BDFU;
  for(unsigned i=0;i<4800;i++){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;data[i]=(uint8_t)rng;}
  unsigned index=0;
  for(unsigned f=0;f<16;f++)for(unsigned b=0;b<4;b++){
   unsigned at=(f*100+b+1600-phases[p])%1600;
   for(;at<4800;at+=1600){uint8_t v=expected[f][b];if(noise && ++index%(noise==1?17:noise==2?7:2)==0)v^=1U;
    data[at]=(uint8_t)((data[at]&~56U)|(v<<3));}
  }
  calls=0;Result a=old_phase(data);uint32_t oldcalls=calls;
  calls=0;Result c=new_phase(data);assert(calls==64U && !memcmp(&a,&c,sizeof(a)));
  if(!noise)assert(c.phase==phases[p] && c.best==192U && c.matches==1U);
  if(oldcalls<minold)minold=oldcalls;if(oldcalls>maxold)maxold=oldcalls;tested++;
 }
 for(unsigned pattern=0;pattern<2;pattern++){
  uint8_t data[4800];memset(data,pattern?255:0,sizeof(data));calls=0;Result a=old_phase(data);
  calls=0;Result b=new_phase(data);assert(calls==64U && !memcmp(&a,&b,sizeof(a)));tested++;
 }
 printf("PASS64lookup values, %u actualpacked4byte screens(all1600starts/wrap/masks/3bitflips), %u actualold/new coldphase cases: identical best/runner/phase/ties; expectedSync calls old%u..%u/new64. No Cortex runtime/deadline claim\n",screens,tested,minold,maxold);
 return 0;
}
'''
    (OUT/'phase-table.cpp').write_text(fixture);exe=OUT/'phase-table.exe'
    command=f'call "{VC}" >nul && cl /nologo /std:c++17 /W4 /WX /O2 "{OUT/"phase-table.cpp"}" /Fo"{OUT/"phase-table.obj"}" /Fe"{exe}"'
    built=subprocess.run(f'cmd /d /s /c "{command}"',cwd=OUT,capture_output=True,text=True,timeout=40)
    (OUT/'phase-table-compile.log').write_text(built.stdout+built.stderr);assert not built.returncode,built.stdout+built.stderr
    ran=subprocess.run([str(exe)],cwd=OUT,capture_output=True,text=True,timeout=10)
    (OUT/'phase-table-run.log').write_text(ran.stdout+ran.stderr);assert not ran.returncode,ran.stdout+ran.stderr
    assert SOURCE.read_text()==new,'Source changed during proof'
    r=dict(status='PASS',old_source=str(oldpath),old_sha256=sha(oldpath),new_sha256=sha(SOURCE),
      non_calibration_source_whitespace_identical=True,unchanged_function_sha256=unchanged,
      command=command,output=ran.stdout,limits='Actual loop equivalence and call count only; targetCPU cold runtime/deadline still needs next bounded capture.',hardware_access=False,firmware_build=False)
    (OUT/'phase-table-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
    print(ran.stdout,end='');print('sourceSHA256 '+sha(SOURCE));print('receiptSHA256 '+sha(OUT/'phase-table-receipt.json'))
if __name__=='__main__':main()
