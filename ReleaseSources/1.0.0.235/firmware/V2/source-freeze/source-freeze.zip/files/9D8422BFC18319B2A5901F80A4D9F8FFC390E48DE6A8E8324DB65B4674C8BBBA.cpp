
#include <assert.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <limits.h>
#include "xe_np_np2_closed_loop_spi.h"
#define BOOT_WORDS 3072U
static uint16_t channels[2],offsets[2];static uint8_t count,field_bits[2];
static uint32_t gframe,gend,gprefix;
#include "actual.inc"
static unsigned raw(uint32_t row,uint32_t ch){return 1984U+(row*17U+ch*31U)%128U;}
int main(){
 unsigned long long geometries=0,scalar=0,services=0;
 XE_NP_Np2ClosedLoopSpi state;
 const unsigned picks[4][2]={{0,1},{1,0},{0,0},{1,1}};
 for(unsigned phase=0;phase<1600;phase++)for(unsigned pick=0;pick<4;pick++){
  count=pick<2?2:1;channels[0]=(uint16_t)picks[pick][0];channels[1]=(uint16_t)picks[pick][1];
  unsigned header=(1600-phase)%1600;
  XE_NP_Np2ClosedLoopSpiConfig cfg={0};cfg.phase=(uint16_t)phase;cfg.phase_verified=cfg.origin_valid=1;
  cfg.source_epoch=1;cfg.count=count;cfg.channel[0]=channels[0];cfg.channel[1]=channels[1];cfg.probe=2;cfg.lane=0;cfg.sample_hz=20000;
  assert(!XE_NP_Np2ClosedLoopSpi_Init(&state,&cfg));
  for(unsigned i=0;i<count;i++)assert(state.offset[i]==header+4+channels[i]*12);
  for(int d=-1600;d<1600;d++){
   assert(actual_geometry(phase,d));geometries++;
   assert(gprefix>0 && gprefix<=3200 && !(gprefix&31));assert(gend>=BOOT_WORDS*32+1600);
   for(unsigned i=0;i<count;i++)assert(offsets[i]==state.offset[i]);
   // Every signed delta and phase checked, with independently placed scalar
   // source/header bits at same-row ADC fields. Never a per-field modulo.
   uint64_t chronological=0;unsigned base=gend-64;
   for(unsigned i=0;i<count;i++){
    int64_t at=(int64_t)header+(int64_t)gframe*1600+4+channels[i]*12+d-base;
    assert(at>=0 && at+12<=64);
    unsigned v=raw(gframe,channels[i]);
    for(unsigned b=0;b<12;b++)if(v&(1U<<(11-b)))chronological|=1ULL<<(63-(unsigned)at-b);
   }
   for(unsigned i=0;i<count;i++){
    unsigned got=(unsigned)(chronological>>(52-field_bits[i]))&4095;
    assert(got==raw(gframe,channels[i]));scalar++;
   }
  }
  // Actual Service output metadata must agree with the same DAT header row,
  // including unwrapped end beyond the global1600 boundary.
  assert(actual_geometry(phase,150));
  state.initialized=1;
  for(unsigned base=0;base<512;base+=64){
   for(unsigned row=base;row<base+64;row++){
    XE_NP_Np2ClosedLoopSpiRow *r=&state.input[row%NP2_CL_SPI_INPUT_ROWS];r->frame_tick=(uint64_t)(gframe+row)*1600;
    r->word[0]=(uint16_t)raw(gframe+row,channels[0]);r->word[1]=(uint16_t)raw(gframe+row,channels[1]);
   }
   state.in_head=(uint16_t)(base+64);
   while(state.in_tail!=state.in_head)assert(XE_NP_Np2ClosedLoopSpi_Service(&state,NP2_CL_SPI_SERVICE_ROWS));
   while(state.out_tail!=state.out_head){
    const XE_NP_Np2ClosedLoopSpiOutput *r=&state.output[state.out_tail%NP2_CL_SPI_OUTPUT_ROWS];
    uint64_t tick=r->source_tick+state.delay_source_ticks;
    unsigned max=header+4+12*(count==2?1:channels[0]);
    assert(r->input_end_tick==tick+max+12);assert(r->source_epoch==1);services++;state.out_tail++;
   }
  }
  assert(state.output_rows>0 && !state.queue_overflows && !state.gap_events);
  // Historical P3 software tap is unchanged and retains its modulo mapping.
  cfg.probe=3;cfg.lane=2;cfg.channel[0]+=256;cfg.channel[1]+=256;
  assert(!XE_NP_Np2ClosedLoopSpi_Init(&state,&cfg));
  for(unsigned i=0;i<count;i++)assert(state.offset[i]==(header+4+channels[i]*12)%1600);
 }
 printf("PASS actual geometry %llu phase/delta/count/order cases; %llu independent scalar same-DAT-row ADC words; %llu actual Service input_end/source_tick outputs; all1600phase P2/P3Init mapping\n",geometries,scalar,services);
}
