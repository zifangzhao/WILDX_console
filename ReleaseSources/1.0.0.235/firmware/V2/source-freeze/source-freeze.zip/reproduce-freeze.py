"""Compact candidate-source freeze, not acceptance or a firmware rebuild."""
from pathlib import Path
import hashlib,json,re,shutil,zipfile

T=Path(__file__).resolve().parents[1];OUT=Path(__file__).resolve().parent
P=Path('C:/Frank/Code/XE_NP/_artifacts/v2_sd_recording_fix_20261104/input-freeze')
EXT={'.c','.h','.inc','.cpp','.hpp','.s','.asm'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def main():
    store=OUT/'files';store.mkdir(exist_ok=True)
    recovered=[]
    # Recreate the two locally superseded text preimages only by the exact
    # recorded inverse substitutions, and accept solely their old checked SHA.
    s40=next((T/'checked-40B').glob('**/xe_np_np2_cl_selected.c'))
    nine=s40.read_text().replace('#define BOOT_WORDS 3072U','#define BOOT_WORDS 4096U')
    nine=nine.replace('#define DMA_STORAGE __attribute__((aligned(32),section("NP2_CL_SELECTED")))\n','').replace('static DMA_STORAGE uint32_t','static STORAGE uint32_t').replace('aligned(256),section("NP2_CL_SELECTED")','aligned(256),section("NP2_DMA_DESCRIPTORS")')
    nine=nine.replace('STORAGE volatile uint32_t xe_np_np2_cl_selected_guard[16];\n','')
    a=nine.index('static int noncacheable_dma_memory(void)');b=nine.index('static void config_node(',a)
    nine=nine[:a]+'''static int owner_quiet(void)
{
    return !(SPI1->CR1&(SPI_CR1_SPE|SPI_CR1_CSTART)) &&
        !(SPI1->CFG1&(SPI_CFG1_RXDMAEN|SPI_CFG1_TXDMAEN)) &&
        !(GPDMA1_Channel15->CCR&(DMA_CCR_EN|DMA_CCR_SUSP|DMA_CCR_RESET)) &&
        !(DBGMCU->CR&DBGMCU_CR_TRACE_IOEN) &&
        !(NVIC->ISER[((uint32_t)GPDMA1_Channel15_IRQn)>>5U]&(1UL<<((uint32_t)GPDMA1_Channel15_IRQn&31U)));
}
'''+nine[b:]
    nine=nine.replace('if(!owner_quiet()){fault(1U);return -1;}','if(!owner_quiet() || SystemCoreClock!=128000000U ||\n       (DCACHE1->CR&DCACHE_CR_EN)){fault(1U);return -1;}')
    s71=next((T/'checked-71FC').glob('**/xe_np_np2_cl_selected.c'));table=s71.read_text()
    pre='''    uint8_t expected[16][4];
    for(unsigned f=0U;f<16U;f++)for(unsigned b=0U;b<4U;b++)
        expected[f][b]=XE_NP_Np2D8ExpectedSync(f*100U+b);
'''
    table=table.replace('    uint32_t best=0U,runner=0U,phase=0U,pm=0U;',pre+'    uint32_t best=0U,runner=0U,phase=0U,pm=0U;')
    table=table.replace('==XE_NP_Np2D8ExpectedSync(f*100U+b)','==expected[f][b]').replace('wanted=XE_NP_Np2D8ExpectedSync(f*100U+b)','wanted=expected[f][b]')
    for text,h,parent,recipe in [(nine,'F4ED97F3AAF81A45C6BB747A215FB643F193571F9083D8EF86253425BE846236',s40,'Inverse recorded cache-placement text substitutions'),(table,'9FAD78EED30CED32A0051C51B1DAFC46FA433D509BC84B3CFCD1627C60AF362C',s71,'Exact64table insertion and two pure lookup substitutions')]:
        assert hashlib.sha256(text.encode()).hexdigest().upper()==h,'Historical text reconstruction did not recover old checked bytes'
        dest=OUT/'recovered-historical'/h/'xe_np_np2_cl_selected.c';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(text.encode())
        recovered.append(dict(path=str(dest),sha256=h,parent=str(parent),parent_sha256=sha(parent),method=recipe,custody='Reconstructed exact previously checked bytes; not misrepresented as an original preserved file.'))
    prior=json.loads((P/'manifest.json').read_text());index={f['sha256']:f for f in prior['files']}
    entries={};refs={};pins=[];unresolved=[];receipts=[];commands={};dependencies=[]
    def keep(p,category,expected=None,force=False):
        p=Path(p)
        if not p.is_file():unresolved.append(dict(path=str(p),reason='missing',category=category));return
        h=sha(p)
        if expected and h!=expected:
            unresolved.append(dict(path=str(p),expected=expected,actual=h,reason='checked-preimage-differs',category=category));return
        if h in index and not force:
            refs[str(p)]=dict(sha256=h,prior_entry=index[h]['stored'],category=category,
                provenance='Reuse exact prior stored bytes; inherit its original checked/unproven claims, not a fresh compiler-input assertion.')
            return
        key=h+p.suffix.lower();dest=store/key
        if not dest.exists():shutil.copyfile(p,dest)
        r=entries.setdefault(key,dict(stored=str(dest.relative_to(OUT)),sha256=h,bytes=p.stat().st_size,origins=[],categories=[]))
        if str(p) not in r['origins']:r['origins'].append(str(p))
        if category not in r['categories']:r['categories'].append(category)
    chain=[T/'build/receipt.json',*[T/f'build-r{i}/receipt.json' for i in range(2,7)],T/'usb-paired/receipt.json']
    for path in chain:
        r=json.loads(path.read_text());receipts.append(dict(path=str(path),sha256=sha(path),crc32=r.get('crc32'),parent_crc32=r.get('parent_crc32')))
        keep(path,'build-source-hash-chain',force=True)
        for name,c in r.get('compiler_commands',{}).items():commands[name]=dict(receipt=str(path),command=c,cwd='D:/Code/XE_NP_V2')
        for p,h in r.get('source_pins',{}).items():
            found=None
            candidates=[Path(p)]
            # Bounded explicitly retained failed-source originals only.
            for directory in ('checked-40B','checked-71FC','failed-9C-source'):
                candidates.extend((T/directory).glob('**/'+Path(p).name))
            candidates.extend((OUT/'recovered-historical').glob('**/'+Path(p).name))
            for candidate in candidates:
                if candidate.is_file() and sha(candidate)==h:found=candidate;break
            claim=dict(receipt=str(path),logical_path=p,expected_sha256=h)
            if found:claim['resolved_from']=str(found);claim['status']='exact';keep(found,'checked-source-preimage',h,force=True)
            else:claim['status']='historical-source-preimage-unresolved';unresolved.append(claim)
            pins.append(claim)
    app=json.loads((T/'build-r6/receipt.json').read_text());usb=json.loads((T/'usb-paired/receipt.json').read_text())
    assert app['crc32']=='7F0C8BD0' and usb['crc32']=='3F20B1F9' and usb['expected_app_crc32']==app['crc32']
    # Actual current five changed source bodies: APP four TUs plus USB pair job.
    current={}
    for name,record in commands.items():
        c=record['command'];sources=[Path(x) for x in c if Path(x).suffix.lower() in {'.c','.cpp','.s'}]
        assert len(sources)==1,(name,sources)
        source=sources[0];expected=next(x['expected_sha256'] for x in reversed(pins) if Path(x['logical_path'])==source)
        assert sha(source)==expected,(source,'Current checked source changed')
        keep(source,'actual-final-checked-TU',expected,force=True);current[name]=dict(path=str(source),sha256=expected)
        assert '-MF' in c;dep=Path(c[c.index('-MF')+1]);keep(dep,'compiler-dependency-file',force=True)
        text=dep.read_text().replace('\\\n',' ');text=re.sub(r'^.*?\.o:\s*','',text,count=1,flags=re.S)
        paths=[]
        for value in re.findall(r'(?:[A-Za-z]:[\\/]|\.\.?[\\/])(?:\\ |[^\s])+',text):
            p=Path(value.replace('\\ ',' '))
            if not p.is_absolute():p=Path(record['cwd'])/p
            if p.suffix.lower() not in EXT:continue
            paths.append(str(p));keep(p,'dependency-current-snapshot-unless-prior-checked')
        dependencies.append(dict(unit=name,dependency_file=str(dep),paths=paths,
            limit='The .d establishes dependency names. Header original hashes are not recorded by these receipts; current snapshots do not prove original compiler bytes unless separately pinned.'))
    header=T/'Core/Inc/xe_np_np2_cl_selected.h';keep(header,'new-selected-reader-header',force=True)
    # Exact link/scatter files and the small build/native source evidence only.
    for directory in (T/'build',*[T/f'build-r{i}' for i in range(2,7)],T/'usb-paired'):
        for name in ('application.lnp','application.sct','memory-proof.json','pending.json'):
            if (directory/name).is_file():keep(directory/name,'exact-link-scatter-or-input-receipt',force=True)
    for name in ('build.py','build-cache-fix.py','link-fixed-tail.py','seal-app.py'):
        keep(T/name,'build-recipe-source',force=True)
    allowed={'.py','.cpp','.c','.h','.inc','.json','.log'}
    for p in (T/'native').iterdir():
        if p.is_file() and p.suffix.lower() in allowed:keep(p,'native-source-fixture-or-receipt',force=True)
    for p in (T/'audit/alignment').iterdir():
        if p.is_file() and p.suffix.lower() in {'.py','.json'}:keep(p,'bounded-offline-alignment-sensor-evidence',force=True)
    total=sum(r['bytes'] for r in entries.values())
    manifest=dict(status='SOURCE_FROZEN_CANDIDATE_ACCEPTANCE_PENDING_RESTART_AND_RESTORE',
        app=dict(crc32=app['crc32'],body_sha256=app['body_sha256'],hex_sha256=app['hex_sha256']),
        usb=dict(crc32=usb['crc32'],expected_app_crc32=usb['expected_app_crc32'],body_sha256=usb['body_sha256'],hex_sha256=usb['hex_sha256']),
        scope='Prototype SD Neuropixels APP profile only; MEDIA=0/AUX=0 required so SPI1/C15 camera ownership and IRQ cannot collide. No support or qualification claim for media/aux profiles.',
        current_checked_TUs=current,new_header=dict(path=str(header),sha256=sha(header)),
        compiler_commands=commands,
        link_commands=[dict(tool='C:/Keil_v5/ARM/ARMCLANG/bin/armlink.exe',arguments=['--via',str(T/'build-r6/application.lnp')]),
                       dict(tool='C:/Keil_v5/ARM/ARMCLANG/bin/armlink.exe',arguments=['--via',str(T/'usb-paired/application.lnp')])],
        source_hash_chain=receipts,source_preimage_claims=pins,reconstructed_historical_preimages=recovered,dependency_closure=dependencies,
        prior_freeze=dict(path=str(P/'manifest.json'),sha256=sha(P/'manifest.json'),files=prior['counts']['files'],
          stored_bytes=prior['bytes'],reference_only_not_duplicated=True,inherited_limits=prior['limits']),
        prior_blob_references=refs,files=list(entries.values()),stored_bytes=total,unresolved=unresolved,
        limits=['No hardware acceptance is asserted by this source receipt; final restart and restore are pending at freeze time.',
          'No build or full source recompilation equivalence was run. Retained object identities and commands come from checked build receipts.',
          'Prior inherited-source/header gaps and unpinned dependency snapshot limitations remain; historical source preimage gaps are explicit.',
          'Source-only package omits firmware binaries/archives, toolchain binaries and all neural DAT payloads/hashes.'],
        no_hardware=True,no_firmware_build=True,no_canonical_edits=True)
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    shutil.copyfile(Path(__file__),OUT/'reproduce-freeze.py')
    files=[OUT/'manifest.json',OUT/'reproduce-freeze.py',*sorted(store.iterdir())]
    (OUT/'filelist.txt').write_text('\n'.join(str(p.relative_to(OUT))+' '+sha(p) for p in files)+'\n')
    with zipfile.ZipFile(OUT/'source-freeze.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in [*files,OUT/'filelist.txt']:z.write(p,str(p.relative_to(OUT)))
    print(json.dumps(dict(status=manifest['status'],current_units=list(current),stored_files=len(entries),stored_bytes=total,
      prior_refs=len(refs),unresolved_claims=len(unresolved),manifest_sha256=sha(OUT/'manifest.json'),
      zip_bytes=(OUT/'source-freeze.zip').stat().st_size,zip_sha256=sha(OUT/'source-freeze.zip')),indent=2))
if __name__=='__main__':main()
