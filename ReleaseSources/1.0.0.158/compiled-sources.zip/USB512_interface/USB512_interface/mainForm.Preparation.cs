using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using WildNpConfiguration;

namespace USB512_interface
{
    public partial class Form1
    {
        volatile bool npSettingsApplying,npPreparationStopRequested;
        NpProbePreparation.Receipt npUsbPreparation;
        NpProbePreparation.Attempt npUsbPreparationAttempt;
        string npUsbPreparationPath;
        DeviceKind npUsbPreparationKind;
        readonly System.Windows.Forms.Timer npPreparationTimer=new System.Windows.Forms.Timer{Interval=1500};
        bool npPreparationTimerInitialized;
        bool HasUsbProbePreparation {get{return npUsbPreparation!=null||npUsbPreparationAttempt!=null;}}

        void ClearUsbProbePreparation()
        {
            npPreparationTimer.Stop();npUsbPreparation=null;npUsbPreparationAttempt=null;npUsbPreparationPath=null;
        }
        async Task RetirePassiveUsbReads()
        {
            // The UI lease prevents new readers. Existing callbacks must retire
            // their physical handles before settings or cancellation take EP0.
            var wait=System.Diagnostics.Stopwatch.StartNew();
            while(systemInfoActive!=0||deviceRefreshActive!=0){
                if(wait.ElapsedMilliseconds>=10000)throw new IOException("Device information is still being read. Wait before changing settings.");
                await Task.Delay(20);
            }
        }
        void CheckUsbPreparationContext(string uid,DeviceKind kind,bool observeStop=true)
        {
            if(IsDisposed||Disposing||selectedDeviceKind!=kind||
                !String.Equals(uid,kind==DeviceKind.NpV2?NpV2FirmwareForm.Uid(devicePath):NpV1Management.UidFromPath(devicePath),StringComparison.OrdinalIgnoreCase))
                throw new IOException("Selected logger changed during probe preparation.");
            if(observeStop&&npPreparationStopRequested)throw new OperationCanceledException("Probe preparation canceled by Stop.");
        }
        async Task RetireUsbProbePreparationForSettings()
        {
            if(!HasUsbProbePreparation)return;
            await RetireUsbProbePreparation(false);
        }
        async Task RetireUsbProbePreparation(bool explicitStop)
        {
            var expected=npUsbPreparation;var attempt=npUsbPreparationAttempt;
            string path=npUsbPreparationPath,uid=expected==null?attempt==null?null:attempt.Uid:expected.Uid;
            DeviceKind kind=npUsbPreparationKind;
            if(uid==null){ClearUsbProbePreparation();return;}
            CheckUsbPreparationContext(uid,kind,false);
            Action check=()=>CheckUsbPreparationContext(uid,kind,false);
            await Task.Run(()=>{
                Func<Func<byte[],CancellationToken,Task<byte[]>>,Action,Task> retire=async(exchange,stop)=>{
                    if(expected!=null){await NpProbePreparation.CancelPrepared(exchange,expected,check,CancellationToken.None,idleSafe:true);return;}
                    if(attempt!=null&&attempt.Unknown&&explicitStop){
                        // A lost PREPARE ACK permits one ordinary explicit Stop,
                        // never a guessed-generation CANCEL or PREPARE replay.
                        if(!attempt.StopIssued){check();attempt.StopIssued=true;stop();}
                        await NpProbePreparation.WaitEmpty(exchange,uid,check,CancellationToken.None);return;
                    }
                    var current=await NpProbePreparation.Query(exchange,CancellationToken.None);check();NpProbePreparation.RequireUid(current,uid);
                    if(current.Result!=0)throw new IOException("Probe preparation status is unconfirmed; no command was sent.");
                    if(current.State==NpProbePreparation.Empty)return;
                    if(attempt==null||!attempt.Unknown)throw new IOException("Probe preparation ownership is unconfirmed. Read status before changing settings.");
                    throw new IOException("Previous probe preparation is unconfirmed. Press Stop before changing settings.");
                };
                if(kind==DeviceKind.NpV2)using(var device=NpV2UsbDevice.Open(path)){
                    var service=device.GetServiceStatus();service.RequireDeviceUid(uid,NpV2FirmwareForm.Uid(path));
                    if(service.Mode!=2U)throw new IOException("The selected V2 USB mode changed; no Stop was sent.");
                    var capture=device.GetCaptureStatus();
                    if(service.Busy!=0U || (capture.State!=0U&&capture.State!=4U&&capture.State!=255U))
                        throw new IOException("The V2 capture owner is still active; no preparation cancellation was sent.");
                    retire((q,c)=>Task.FromResult(device.ExchangeProbePreparation(q,c)),device.Cancel).GetAwaiter().GetResult();
                }else using(var device=XeNpWinUsbDevice.OpenForControl(path)){
                    var service=device.ReadV1ServiceStatus();
                    if(service==null||service.Role!=2||service.Recovery)throw new IOException("The original V1 logger streaming service is unavailable; no Stop was sent.");
                    if(service.Busy!=0 || device.GetStatus().Streaming)throw new IOException("The V1 capture owner is still active; no preparation cancellation was sent.");
                    retire((q,c)=>Task.FromResult(device.ExchangeProbePreparation(q,c)),device.StopPreparation).GetAwaiter().GetResult();
                }
            });
            ClearUsbProbePreparation();lblRecInfo.Text="Probe preparation stopped. Start remains available.";
        }
        async Task StopUsbProbePreparation()
        {
            npPreparationStopRequested=true;
            if(npSettingsApplying)return; // The current owner retires its request first.
            npSettingsApplying=true;npPreparationTimer.Stop();UpdateStartEnabled();
            try{await RetirePassiveUsbReads();await RetireUsbProbePreparation(true);}
            catch(Exception ex){lblRecInfo.Text="Probe preparation Stop is unconfirmed. Read status before changing settings. "+ex.Message;}
            finally{npSettingsApplying=false;npPreparationStopRequested=false;if(!IsDisposed&&!Disposing)UpdateStartEnabled();}
        }
        async Task PrepareUsbProbeSettings()
        {
            bool np2=selectedDeviceKind==DeviceKind.NpV2;DeviceKind kind=selectedDeviceKind;
            string selectedPath=devicePath,uid=np2?NpV2FirmwareForm.Uid(selectedPath):NpV1Management.UidFromPath(selectedPath);
            Action check=()=>CheckUsbPreparationContext(uid,kind);
            var v1=NpRequestsForDevice(selectedPath);
            var v1Requests=v1==null?new List<NpConfigRequest>():v1.Values.ToList();
            var v2Requests=new List<Np2ConfigRequest>();
            if(np2){
                var apply=NpV2ApplyRequestsForDevice(selectedPath);var requests=NpV2RequestsForDevice(selectedPath);
                if(apply!=null)foreach(int port in apply){string json;if(!requests.TryGetValue(port,out json))throw new IOException("A requested probe map is missing for connector "+port+".");v2Requests.Add(NpConfigurationDialog.PrepareV2Request(json,port));}
            }
            npPreparationTimer.Stop();lblRecInfo.Text="Applying recording settings…";
            var receipt=await Task.Run(()=>{
                check();
                if(np2){
                    string path=NpV2EnsureIdleStreamMode();check();
                    using(var device=NpV2UsbDevice.Open(path)){
                        var caps=device.GetProfileCapabilities();uint mask=npV2RequestedProbeMask==0?caps.SelectedProbeMask:npV2RequestedProbeMask;
                        check();caps=device.ConfigureProfile(mask,npV2RequestedSampleHz);check();
                        foreach(var request in v2Requests)if((caps.SelectedProbeMask&(1U<<request.Port))!=0){check();Np2ConfigurationUsb.StageForCapture(device,request);}
                        var client=new Np2ConfigClient(new Np2ConfigurationUsb(device));
                        var status=client.StatusAsync(0,CancellationToken.None).GetAwaiter().GetResult();check();
                        if((status.GlobalState!=0&&status.GlobalState!=2)||status.Received!=0)return null;
                        npUsbPreparationPath=path;npUsbPreparationKind=kind;
                        return NpProbePreparation.Begin((q,c)=>Task.FromResult(device.ExchangeProbePreparation(q,c)),NpProbePreparation.Usb,
                            caps.SelectedProbeMask,caps.SampleHz,uid,check,CancellationToken.None,r=>npUsbPreparation=r,a=>npUsbPreparationAttempt=a).GetAwaiter().GetResult();
                    }
                }
                string streaming=NpV1Management.EnsureStreaming(selectedPath);check();
                NpModeCapabilities mode;NpCaptureMode resolved;string resolution,reconnect;
                using(var device=XeNpWinUsbDevice.OpenForControl(streaming))mode=device.SelectCaptureMode(npRequestedMode,out resolved,out resolution,out reconnect);
                if(reconnect!=null)streaming=NpV1Management.WaitForStreaming(reconnect);
                devicePath=streaming;check();
                using(var device=XeNpWinUsbDevice.OpenForControl(streaming)){
                    mode=device.GetModeCapabilities();
                    if(mode==null||mode.ActiveMask==0)return null;
                    if(resolved!=null&&(mode.ActiveMask!=resolved.ProbeMask||mode.ApHz!=resolved.ApHz))throw new IOException("The device did not confirm the selected recording profile.");
                    var selected=v1Requests.Where(r=>(mode.ActiveMask&(1<<r.Port))!=0).ToList();
                    check();NpConfigurationUsb.StageForCapture(device,selected,mode.ActiveMask);check();
                    var client=new NpConfigClient(new PreparationV1Transport(device));
                    var status=client.StatusAsync(0,CancellationToken.None).GetAwaiter().GetResult();check();
                    if(status.Error!=0||(status.TransferState!=0&&status.TransferState!=2)||status.Received!=0)return null;
                    npUsbPreparationPath=streaming;npUsbPreparationKind=kind;
                    return NpProbePreparation.Begin((q,c)=>Task.FromResult(device.ExchangeProbePreparation(q,c)),NpProbePreparation.Usb,
                        (uint)mode.ActiveMask,(uint)mode.ApHz,uid,check,CancellationToken.None,r=>npUsbPreparation=r,a=>npUsbPreparationAttempt=a).GetAwaiter().GetResult();
                }
            });
            if(IsDisposed||Disposing)return;
            npUsbPreparation=receipt;
            if(receipt==null){ClearUsbProbePreparation();lblRecInfo.Text="Settings saved. This firmware prepares probes at Start.";return;}
            lblRecInfo.Text=receipt.Text;
            if(receipt.State==NpProbePreparation.Preparing){
                if(!npPreparationTimerInitialized){npPreparationTimer.Tick+=async(sender,e)=>await ObserveUsbProbePreparation();npPreparationTimerInitialized=true;}
                npPreparationTimer.Start();
            }
        }
        sealed class PreparationV1Transport:INpConfigTransport
        {
            readonly XeNpWinUsbDevice device;
            internal PreparationV1Transport(XeNpWinUsbDevice device){this.device=device;}
            public Task<byte[]> ExchangeAsync(byte[] request,CancellationToken cancel){return Task.FromResult(device.ExchangeNpConfiguration(request,cancel));}
        }
        async Task ObserveUsbProbePreparation()
        {
            var expected=npUsbPreparation;
            if(expected==null||running||IsDisposed||Disposing){npPreparationTimer.Stop();return;}
            if(devicePath!=npUsbPreparationPath||selectedDeviceKind!=npUsbPreparationKind){ClearUsbProbePreparation();lblRecInfo.Text="Probe preparation not confirmed. Start remains available.";return;}
            if(!NpControlsAvailable)return;
            string path=devicePath;bool np2=selectedDeviceKind==DeviceKind.NpV2;
            npSettingsApplying=true;UpdateStartEnabled();
            try{
                var receipt=await Task.Run(()=>{
                    if(np2)using(var device=NpV2UsbDevice.Open(path))return NpProbePreparation.Query((q,c)=>Task.FromResult(device.ExchangeProbePreparation(q,c)),CancellationToken.None).GetAwaiter().GetResult();
                    using(var device=XeNpWinUsbDevice.OpenForControl(path))return NpProbePreparation.Query((q,c)=>Task.FromResult(device.ExchangeProbePreparation(q,c)),CancellationToken.None).GetAwaiter().GetResult();
                });
                if(devicePath!=path||npUsbPreparation!=expected)return;
                NpProbePreparation.RequireUid(receipt,expected.Uid);
                if(receipt.Result!=0)throw new IOException("Probe preparation status is unconfirmed.");
                if(receipt.Generation!=expected.Generation||receipt.Mode!=expected.Mode||receipt.Mask!=expected.Mask||receipt.Hz!=expected.Hz){ClearUsbProbePreparation();lblRecInfo.Text="Probe preparation changed. Start remains available.";return;}
                // Retain the original exact-generation cancellation token.
                receipt.CancelIssued=expected.CancelIssued;npUsbPreparation=receipt;lblRecInfo.Text=receipt.Text;
                if(receipt.State!=NpProbePreparation.Preparing&&receipt.State!=NpProbePreparation.Canceling)npPreparationTimer.Stop();
            }catch(Exception){npPreparationTimer.Stop();lblRecInfo.Text="Probe preparation not confirmed. Start remains available.";}
            finally{npSettingsApplying=false;if(!IsDisposed&&!Disposing){UpdateStartEnabled();if(npPreparationStopRequested)await StopUsbProbePreparation();}}
        }
    }
}
