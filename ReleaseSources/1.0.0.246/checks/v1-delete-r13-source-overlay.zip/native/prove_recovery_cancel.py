from datetime import datetime,timezone
import hashlib,json,re,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent;t=Path('C:/Frank/Code/XE_NP/_artifacts/v1_delete_last_20261105');out=root/'recovery-cancel1';assert not out.exists()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
stream=t/'usb-source/stream.c';delete=t/'usb-source/delete.inc';assert sha(delete)=='5BBFE4889A61DCCA8D3799EA33456B8A3F2716B7DF3FD1AEBA61175C92571151'
def function(text,name):
 m=re.search(r'(?m)^(?:(?:__attribute__\(\(noinline\)\)|__declspec\(noinline\)) )?(?:static )?(?:int|void|uint32_t) '+name+r'\(',text);assert m,name
 start=m.start();at=text.index('{',m.end())+1;depth=1
 while depth:depth+=(text[at]=='{')-(text[at]=='}');at+=1
 return text[start:at].replace('__attribute__((noinline))','__declspec(noinline)')
text=delete.read_text();st=stream.read_text();prior=(root/'retire2/actual_retirement.inc').read_text();helpers=['np_usb_delete_physical_quiet','np_usb_delete_quiet','np_usb_delete_retire','np_usb_delete_read','np_usb_delete_write','np_usb_delete_clock_begin','np_usb_delete_clock_end']
for name in helpers:
 if(name!='np_usb_delete_write'):assert function(text,name)==function(prior,name)
assert '(np_usb_delete.cancelled&&!np_usb_delete_recovering)' in function(text,'np_usb_delete_write')
hooks={n:function(st,n) for n in ['HAL_PCD_ResetCallback','HAL_PCD_DisconnectCallback','HAL_PCD_SuspendCallback']}
for body in hooks.values():assert 'if(np_usb_delete_owned()){++np_download_epoch;np_usb_delete_cancel();}else NP_SD_UsbCancel();' in body
globals_text=text[:text.index('static int np_usb_delete_owned')];globals_text=re.sub(r' __attribute__\(\(section\("NP_USB_DMA"\),aligned\(32\)\)\)','',globals_text);globals_text=re.sub(r'#include "[^"]*np_store_v2_delete_wire.h"','#include "np_store_v2_delete_wire.h"',globals_text)
info=t/'usb-source/np_sd_info_v1_service.inc';infotext=info.read_text();infoglobals=infotext[:infotext.index('static int np_usb_sd_info_owned')];infoglobals=re.sub(r' __attribute__\(\(section\("NP_USB_DMA"\),aligned\(32\)\)\)','',infoglobals)
actual=globals_text+'\n\n'+'\n\n'.join(function(text,n) for n in ['np_usb_delete_owned',*helpers,'np_usb_delete_cancel'])+'\n'+function(st,'np_usb_sd_initialize_owned')+'\n#define NP_USB_ReinitializeSd np_usb_sd_initialize_owned\n'+function(text,'np_usb_delete_service')+'\n'+infoglobals
out.mkdir();(out/'actual_recovery_cancel.inc').write_text(actual);(out/'actual_bus_hooks.txt').write_text('\n\n'.join(hooks.values()));(out/'fixture.c').write_bytes((root/'recovery_cancel_fixture.c').read_bytes())
for name in ['np_store_v2.h','np_store_v2_delete.h','np_store_v2_delete_wire.h','np_sd_fast_crc.h']:(out/name).write_bytes((t/'core'/name).read_bytes())
(out/'xe_np_sd_info.h').write_bytes((t/'usb-source/xe_np_sd_info.h').read_bytes())
vc='C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat';cmd=f'call "{vc}" >nul && cl /nologo /std:c11 /W4 /WX /TC /O2 /I"{out}" "{out}/fixture.c" /Fo"{out}/fixture.obj" /Fe"{out}/fixture.exe"';started=datetime.now(timezone.utc).isoformat();watch=time.perf_counter();(out/'command.txt').write_text(cmd+'\n');build=subprocess.run('cmd /d /s /c "'+cmd+'"',cwd=out,capture_output=True,text=True,timeout=60);(out/'compile.log').write_text(build.stdout+build.stderr);assert build.returncode==0,build.stdout+build.stderr
run=subprocess.run([str(out/'fixture.exe')],cwd=out,capture_output=True,text=True,timeout=60);(out/'result.txt').write_text(run.stdout+run.stderr);print(run.stdout+run.stderr,end='');assert run.returncode==0
receipt={'status':'PASS','started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),'seconds':time.perf_counter()-watch,'stream_sha256':sha(stream),'delete_port_sha256':sha(delete),'actual_functions_sha256':sha(out/'actual_recovery_cancel.inc'),'actual_bus_hooks_sha256':sha(out/'actual_bus_hooks.txt'),'result_sha256':sha(out/'result.txt'),'scope':'Actual automatic recovery/client service/cancel and realstorage with modeled bus-event common-hook calls betweenwrites; actual3USBbus hook wiring checkedsource-only; no firmware/appbuild/hardware or unchangedcore/parser suite'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('receipt',out/'receipt.json',sha(out/'receipt.json'))
