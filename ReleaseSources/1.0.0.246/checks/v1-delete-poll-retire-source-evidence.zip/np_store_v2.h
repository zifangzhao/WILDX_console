#ifndef NP_STORE_V2_H
#define NP_STORE_V2_H
#include <stdint.h>
#include <string.h>
#include "np_sd_fast_crc.h"

/* Explicitly initialized V1 layout; never adopted from a legacy catalog.
 * Allocation authority is independent of the optional record directory.
 * Both checkpoint copies are verified BEFORE any newly granted payload may
 * be written. A mount never writes, repairs or guesses free space.
 * Grants only grow; STOP/failed records/deletion do not reclaim their tails.
 * Live integration must extend bounded grants before issuing SD writes beyond
 * them; support here does not itself implement that acquisition scheduler. */
#define NPS2_IDENT0 16U
#define NPS2_IDENT1 24U
#define NPS2_CHECK0 112U
#define NPS2_CHECK1 113U
#define NPS2_RECORD_BASE 128U
#define NPS2_DATA 8192U
#define NPS2_RECORDS ((NPS2_DATA-NPS2_RECORD_BASE)/2U)
#define NPS2_ALIGN 8192U
#define NPS2_RECORD_OPEN 1U
#define NPS2_RECORD_COMPLETE 2U
#define NPS2_RECORD_FAILED 3U
/* Native94 read-only directory projection, distinct from legacy end-only pages.
 * 0 magic S2PG,4 page,8 epoch64,16 generation64,24 entries,28 total,
 * 32 durable frontier,36 more,40 start/end pairs,504 reserved0,508 CRC32.
 * Missing descriptors are a zero pair; allocation never comes from this page. */
#define NPS2_PAGE_MAGIC 0x47503253U
#define NPS2_PAGE_ENTRIES 58U

typedef int (*Nps2Read)(uint32_t,uint8_t *);
typedef int (*Nps2Write)(uint32_t,const uint8_t *);
typedef struct {
    uint64_t epoch,generation;
    uint32_t capacity,frontier,count,start,end,session,open,ready,live;
} Nps2State;
typedef struct {
    uint64_t generation;
    uint32_t index,start,reserved_end,committed_end,session,state;
} Nps2Record;
enum {NPS2_OK=0,NPS2_INVALID=-1,NPS2_IO=-2,NPS2_MISSING=-3};

static inline uint32_t nps2_get(const uint8_t *p)
{return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static inline uint64_t nps2_get64(const uint8_t *p)
{return (uint64_t)nps2_get(p)|((uint64_t)nps2_get(p+4)<<32);}
static inline void nps2_put(uint8_t *p,uint32_t v)
{p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);p[2]=(uint8_t)(v>>16);p[3]=(uint8_t)(v>>24);}
static inline void nps2_put64(uint8_t *p,uint64_t v)
{nps2_put(p,(uint32_t)v);nps2_put(p+4,(uint32_t)(v>>32));}
static inline uint32_t nps2_crc(const uint8_t *p,uint32_t n)
{return np_sd_metadata_crc_fast(p,n);}
static inline void nps2_seal(uint8_t b[512])
{nps2_put(b+508,nps2_crc(b,508));}
static inline int nps2_valid_crc(const uint8_t b[512])
{return nps2_get(b+508)==nps2_crc(b,508);}
static inline int nps2_aligned(uint32_t lba)
{return lba>=NPS2_DATA && !(lba&(NPS2_ALIGN-1U));}
static inline int nps2_write_verified(uint32_t lba,const uint8_t b[512],Nps2Read read,Nps2Write write)
{
    uint8_t check[512];
    if(!read || !write || !((lba==NPS2_IDENT0 || lba==NPS2_IDENT1 || lba==114U || lba==115U ||
        lba==NPS2_CHECK0 || lba==NPS2_CHECK1) ||
        (lba>=NPS2_RECORD_BASE && lba<NPS2_DATA)))return NPS2_INVALID;
    return write(lba,b) || read(lba,check) || memcmp(b,check,512)?NPS2_IO:NPS2_OK;
}
static inline void nps2_identity(uint8_t b[512],uint32_t capacity,uint64_t epoch)
{
    memset(b,0,512);memcpy(b,"NP_FILESYSTEM_V2",16);memcpy(b+32,"NP_CE64_2",9);
    nps2_put(b+48,2U);nps2_put(b+52,capacity);nps2_put64(b+56,epoch);
    nps2_put(b+64,NPS2_DATA);nps2_put(b+68,NPS2_RECORDS);nps2_seal(b);
}
static inline int nps2_identity_valid(const uint8_t b[512],uint32_t capacity)
{
    return !memcmp(b,"NP_FILESYSTEM_V2",16) && !memcmp(b+32,"NP_CE64_2",9) &&
        nps2_get(b+48)==2U && nps2_get(b+52)==capacity && nps2_get64(b+56) &&
        nps2_get(b+64)==NPS2_DATA && nps2_get(b+68)==NPS2_RECORDS && nps2_valid_crc(b);
}
static inline void nps2_checkpoint(uint8_t b[512],const Nps2State *s)
{
    memset(b,0,512);memcpy(b,"NPS2CP01",8);nps2_put(b+8,2U);
    nps2_put(b+12,s->capacity);nps2_put64(b+16,s->epoch);nps2_put64(b+24,s->generation);
    nps2_put(b+32,s->frontier);nps2_put(b+36,s->count);nps2_put(b+40,s->start);
    nps2_put(b+44,s->end);nps2_put(b+48,s->session);nps2_put(b+52,s->open);nps2_seal(b);
}
static inline int nps2_checkpoint_valid(const uint8_t b[512],uint32_t capacity,uint64_t epoch)
{
    uint32_t frontier=nps2_get(b+32),count=nps2_get(b+36),start=nps2_get(b+40),end=nps2_get(b+44);
    if(memcmp(b,"NPS2CP01",8) || nps2_get(b+8)!=2U || nps2_get(b+12)!=capacity ||
       nps2_get64(b+16)!=epoch || !nps2_get64(b+24) || !nps2_valid_crc(b) ||
       !nps2_aligned(frontier) || frontier>capacity || count>NPS2_RECORDS || nps2_get(b+52)>1U)return 0;
    if(!count)return frontier==NPS2_DATA && !start && !end && !nps2_get(b+48) && !nps2_get(b+52);
    return nps2_aligned(start) && nps2_aligned(end) && start<end && end==frontier && nps2_get(b+48);
}
static inline void nps2_decode_checkpoint(Nps2State *s,const uint8_t b[512])
{
    memset(s,0,sizeof(*s));s->capacity=nps2_get(b+12);s->epoch=nps2_get64(b+16);
    s->generation=nps2_get64(b+24);s->frontier=nps2_get(b+32);s->count=nps2_get(b+36);
    s->start=nps2_get(b+40);s->end=nps2_get(b+44);s->session=nps2_get(b+48);s->open=nps2_get(b+52);
    s->ready=1U; /* live remains0 after boot, including an interrupted record. */
}
static inline int nps2_mount_raw(Nps2State *s,uint32_t capacity,Nps2Read read)
{
    uint8_t a[512],b[512];uint64_t epoch;int va,vb;
    memset(s,0,sizeof(*s));if(!read || capacity<=NPS2_DATA)return NPS2_INVALID;
    va=!read(NPS2_IDENT0,a) && nps2_identity_valid(a,capacity);
    vb=!read(NPS2_IDENT1,b) && nps2_identity_valid(b,capacity);
    if((!va && !vb) || (va && vb && memcmp(a,b,512)))return NPS2_INVALID;
    epoch=nps2_get64((va?a:b)+56);
    va=!read(NPS2_CHECK0,a) && nps2_checkpoint_valid(a,capacity,epoch);
    vb=!read(NPS2_CHECK1,b) && nps2_checkpoint_valid(b,capacity,epoch);
    if(!va && !vb)return NPS2_INVALID;
    if(va && vb){
        uint64_t ga=nps2_get64(a+24),gb=nps2_get64(b+24);
        const uint8_t *hi=ga>=gb?a:b,*lo=ga>=gb?b:a;
        if((ga==gb && memcmp(a,b,512)) ||
           (ga!=gb && (nps2_get64(hi+24)-nps2_get64(lo+24)!=1U ||
            nps2_get(hi+32)<nps2_get(lo+32) || nps2_get(hi+36)<nps2_get(lo+36) ||
            nps2_get(hi+36)-nps2_get(lo+36)>1U)))return NPS2_INVALID;
        nps2_decode_checkpoint(s,hi);
    }else nps2_decode_checkpoint(s,va?a:b);
    return NPS2_OK;
}
static inline int nps2_publish_checkpoint(Nps2State *s,const Nps2State *next,Nps2Read read,Nps2Write write)
{
    uint8_t b[512];nps2_checkpoint(b,next);
    if(!nps2_checkpoint_valid(b,next->capacity,next->epoch))return NPS2_INVALID;
    if(nps2_write_verified(NPS2_CHECK0,b,read,write) || nps2_write_verified(NPS2_CHECK1,b,read,write)){
        s->ready=s->live=0U;return NPS2_IO;
    }
    *s=*next;return NPS2_OK;
}
static inline int nps2_format(Nps2State *s,uint32_t capacity,uint64_t epoch,Nps2Read read,Nps2Write write)
{
    uint8_t b[512]={0},old_identity[512];Nps2State next={0};
    memset(s,0,sizeof(*s));
    if(!epoch || capacity<=NPS2_DATA || !read || !write)return NPS2_INVALID;
    /* A fresh host-supplied nonzero64-bit format nonce is mandatory. */
    if(read(NPS2_IDENT0,old_identity))return NPS2_IO;
    if(nps2_identity_valid(old_identity,capacity) && nps2_get64(old_identity+56)==epoch)return NPS2_INVALID;
    if(read(NPS2_IDENT1,old_identity))return NPS2_IO;
    if(nps2_identity_valid(old_identity,capacity) && nps2_get64(old_identity+56)==epoch)return NPS2_INVALID;
    if(nps2_write_verified(NPS2_IDENT0,b,read,write) || nps2_write_verified(NPS2_IDENT1,b,read,write))return NPS2_IO;
    if(nps2_write_verified(114U,b,read,write) || nps2_write_verified(115U,b,read,write))return NPS2_IO;
    next.epoch=epoch;next.generation=1U;next.capacity=capacity;next.frontier=NPS2_DATA;
    if(nps2_publish_checkpoint(s,&next,read,write))return NPS2_IO;
    nps2_identity(b,capacity,epoch);
    if(nps2_write_verified(NPS2_IDENT0,b,read,write) || nps2_write_verified(NPS2_IDENT1,b,read,write)){
        s->ready=0U;return NPS2_IO;
    }
    s->ready=1U;return NPS2_OK;
}
static inline void nps2_record_sector(uint8_t b[512],const Nps2State *s,const Nps2Record *r)
{
    memset(b,0,512);memcpy(b,"NPS2REC1",8);nps2_put(b+8,2U);nps2_put(b+12,s->capacity);
    nps2_put64(b+16,s->epoch);nps2_put64(b+24,r->generation);nps2_put(b+32,r->index);
    nps2_put(b+36,r->start);nps2_put(b+40,r->reserved_end);nps2_put(b+44,r->committed_end);
    nps2_put(b+48,r->session);nps2_put(b+52,r->state);nps2_seal(b);
}
static inline int nps2_record_valid(const uint8_t b[512],const Nps2State *s,uint32_t index)
{
    uint32_t start=nps2_get(b+36),end=nps2_get(b+40),committed=nps2_get(b+44),state=nps2_get(b+52);
    return !memcmp(b,"NPS2REC1",8) && nps2_get(b+8)==2U && nps2_get(b+12)==s->capacity &&
        nps2_get64(b+16)==s->epoch && nps2_get64(b+24) && nps2_get(b+32)==index &&
        nps2_valid_crc(b) && nps2_aligned(start) && nps2_aligned(end) && start<end &&
        end<=s->frontier && committed>=start && committed<=end && nps2_get(b+48) &&
        state>=NPS2_RECORD_OPEN && state<=NPS2_RECORD_FAILED;
}
static inline void nps2_decode_record(Nps2Record *r,const uint8_t b[512])
{
    r->generation=nps2_get64(b+24);r->index=nps2_get(b+32);r->start=nps2_get(b+36);
    r->reserved_end=nps2_get(b+40);r->committed_end=nps2_get(b+44);r->session=nps2_get(b+48);r->state=nps2_get(b+52);
}
static inline int nps2_read_record(const Nps2State *s,uint32_t index,Nps2Record *r,Nps2Read read)
{
    uint8_t a[512],b[512];int va,vb;uint32_t lba=NPS2_RECORD_BASE+2U*index;
    memset(r,0,sizeof(*r));if(!s->ready || index>=s->count || !read)return NPS2_INVALID;
    va=!read(lba,a) && nps2_record_valid(a,s,index);
    vb=!read(lba+1U,b) && nps2_record_valid(b,s,index);
    if(!va && !vb)return NPS2_MISSING;
    if(va && vb && nps2_get64(a+24)==nps2_get64(b+24) && memcmp(a,b,512))return NPS2_INVALID;
    if(va && vb && nps2_get64(a+24)!=nps2_get64(b+24)){
        const uint8_t *hi=nps2_get64(a+24)>nps2_get64(b+24)?a:b,*lo=hi==a?b:a;
        if(nps2_get(hi+36)!=nps2_get(lo+36) || nps2_get(hi+48)!=nps2_get(lo+48) ||
           nps2_get(hi+40)<nps2_get(lo+40) || nps2_get(hi+44)<nps2_get(lo+44) ||
           nps2_get(lo+52)!=NPS2_RECORD_OPEN)return NPS2_INVALID;
    }
    nps2_decode_record(r,va && (!vb || nps2_get64(a+24)>=nps2_get64(b+24))?a:b);
    return NPS2_OK;
}
static inline int nps2_write_record(Nps2State *s,const Nps2Record *r,Nps2Read read,Nps2Write write)
{
    uint8_t b[512];uint32_t lba;
    if(!s->ready || r->index>=s->count || r->index>=NPS2_RECORDS)return NPS2_INVALID;
    lba=NPS2_RECORD_BASE+2U*r->index;
    nps2_record_sector(b,s,r);
    if(!nps2_record_valid(b,s,r->index))return NPS2_INVALID;
    if(nps2_write_verified(lba,b,read,write) || nps2_write_verified(lba+1U,b,read,write)){
        s->ready=s->live=0U;return NPS2_IO;
    }
    return NPS2_OK;
}
static inline int nps2_delete_clean_for_state(const Nps2State *s,Nps2Read read);
static inline int nps2_begin(Nps2State *s,uint32_t end,uint32_t session,Nps2Read read,Nps2Write write)
{
    Nps2State next=*s;Nps2Record r;
    if(!s->ready || s->live || !nps2_delete_clean_for_state(s,read) || !session || s->count>=NPS2_RECORDS || s->generation==UINT64_MAX ||
       !nps2_aligned(end) || end<=s->frontier || end>s->capacity)return NPS2_INVALID;
    next.generation++;next.start=s->frontier;next.end=next.frontier=end;
    next.count++;next.session=session;next.open=next.live=1U;
    if(nps2_publish_checkpoint(s,&next,read,write))return NPS2_IO;
    r.generation=s->generation;r.index=s->count-1U;r.start=s->start;r.reserved_end=end;
    r.committed_end=s->start;r.session=session;r.state=NPS2_RECORD_OPEN;
    return nps2_write_record(s,&r,read,write);
}
static inline int nps2_extend(Nps2State *s,uint32_t end,Nps2Read read,Nps2Write write)
{
    Nps2State next=*s;Nps2Record r;
    if(!s->ready || !s->live || !s->open || s->generation==UINT64_MAX ||
       !nps2_aligned(end) || end<=s->frontier || end>s->capacity)return NPS2_INVALID;
    if(nps2_read_record(s,s->count-1U,&r,read)){
        s->ready=s->live=0U;return NPS2_INVALID;
    }
    next.generation++;next.end=next.frontier=end;
    if(nps2_publish_checkpoint(s,&next,read,write))return NPS2_IO;
    r.generation=s->generation;r.reserved_end=end;
    return nps2_write_record(s,&r,read,write);
}
static inline int nps2_finish(Nps2State *s,uint32_t committed_end,int complete,Nps2Read read,Nps2Write write)
{
    Nps2State next=*s;Nps2Record r;
    if(!s->ready || !s->live || !s->open || s->generation==UINT64_MAX ||
       committed_end<s->start || committed_end>s->end)return NPS2_INVALID;
    if(nps2_read_record(s,s->count-1U,&r,read)){
        s->ready=s->live=0U;return NPS2_INVALID;
    }
    next.generation++;next.open=next.live=0U;
    r.generation=next.generation;r.committed_end=committed_end;
    r.state=complete?NPS2_RECORD_COMPLETE:NPS2_RECORD_FAILED;
    if(nps2_write_record(s,&r,read,write))return NPS2_IO;
    return nps2_publish_checkpoint(s,&next,read,write);
}
#include "np_store_v2_delete.h"
#endif
