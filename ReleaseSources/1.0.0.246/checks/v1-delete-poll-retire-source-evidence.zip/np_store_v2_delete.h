#ifndef NP_STORE_V2_DELETE_H
#define NP_STORE_V2_DELETE_H
/* Stopped, same-card redo transaction. No payload/descriptor writes or scans. */
#include "np_store_v2.h"
#define NPS2_DELETE_PENDING (-4)
#define NPS2_DELETE_JOURNAL0 114U
#define NPS2_DELETE_JOURNAL1 115U
#define NPS2_DELETE_FLAG_OPEN 1U
#define NPS2_DELETE_FLAG_FAILED 2U
#if defined(__clang__) && defined(__arm__)
#define NPS2_DELETE_COLD __attribute__((noinline))
#else
#define NPS2_DELETE_COLD inline
#endif
typedef struct {
    Nps2State before[2],after,state;
    Nps2Record last,previous;
    uint64_t nonce;
    uint32_t before_mask,last_crc,previous_crc,cp_crc[2],flags,pending,needs_clear;
    uint8_t cid[16];
} Nps2Delete;
static inline void nps2_delete_pack_state(uint8_t *p,const Nps2State *s)
{nps2_put64(p,s->generation);nps2_put(p+8,s->frontier);nps2_put(p+12,s->count);nps2_put(p+16,s->start);nps2_put(p+20,s->end);nps2_put(p+24,s->session);nps2_put(p+28,s->open);}
static inline void nps2_delete_unpack_state(Nps2State *s,const uint8_t *p,uint32_t capacity,uint64_t epoch)
{memset(s,0,sizeof(*s));s->capacity=capacity;s->epoch=epoch;s->generation=nps2_get64(p);s->frontier=nps2_get(p+8);s->count=nps2_get(p+12);s->start=nps2_get(p+16);s->end=nps2_get(p+20);s->session=nps2_get(p+24);s->open=nps2_get(p+28);s->ready=1U;}
static inline void nps2_delete_pack_record(uint8_t *p,const Nps2Record *r)
{nps2_put64(p,r->generation);nps2_put(p+8,r->index);nps2_put(p+12,r->start);nps2_put(p+16,r->reserved_end);nps2_put(p+20,r->committed_end);nps2_put(p+24,r->session);nps2_put(p+28,r->state);}
static inline void nps2_delete_unpack_record(Nps2Record *r,const uint8_t *p)
{r->generation=nps2_get64(p);r->index=nps2_get(p+8);r->start=nps2_get(p+12);r->reserved_end=nps2_get(p+16);r->committed_end=nps2_get(p+20);r->session=nps2_get(p+24);r->state=nps2_get(p+28);}
static inline int nps2_delete_same_state(const Nps2State *a,const Nps2State *b)
{uint8_t x[32],y[32];nps2_delete_pack_state(x,a);nps2_delete_pack_state(y,b);return a->capacity==b->capacity && a->epoch==b->epoch && !memcmp(x,y,32);}
static inline int nps2_delete_same_record(const Nps2Record *a,const Nps2Record *b)
{uint8_t x[32],y[32];nps2_delete_pack_record(x,a);nps2_delete_pack_record(y,b);return !memcmp(x,y,32);}
static inline const Nps2State *nps2_delete_high(const Nps2Delete *d)
{return !(d->before_mask&1U)?&d->before[1]:!(d->before_mask&2U)?&d->before[0]:d->before[0].generation>=d->before[1].generation?&d->before[0]:&d->before[1];}
static inline int nps2_delete_canonical_cp(const uint8_t *b,uint32_t capacity,uint64_t epoch,Nps2State *s)
{uint8_t expected[512];if(!nps2_checkpoint_valid(b,capacity,epoch))return 0;nps2_decode_checkpoint(s,b);nps2_checkpoint(expected,s);return !memcmp(expected,b,512);}
static inline uint32_t nps2_delete_record_crc(const Nps2State *s,const Nps2Record *r)
{uint8_t b[512];nps2_record_sector(b,s,r);return nps2_get(b+508);}
static inline int nps2_delete_shape(const Nps2Delete *d)
{
    uint8_t b[512];const Nps2State *s=nps2_delete_high(d);uint32_t expected_flags;
    if(!d->nonce || !d->before_mask || (d->before_mask&~3U) || !s->count || s->generation==UINT64_MAX || s->live)return 0;
    for(unsigned i=0;i<2U;i++){
        if(d->before_mask&(1U<<i)){nps2_checkpoint(b,&d->before[i]);if(!nps2_checkpoint_valid(b,s->capacity,s->epoch)||nps2_get(b+508)!=d->cp_crc[i])return 0;}
        else {uint8_t zero[32]={0},state[32];nps2_delete_pack_state(state,&d->before[i]);if(memcmp(state,zero,32)||d->cp_crc[i])return 0;}
    }
    if(d->before_mask==3U){const Nps2State *lo=s==&d->before[0]?&d->before[1]:&d->before[0];
        if(s->generation==lo->generation?!nps2_delete_same_state(s,lo):s->generation-lo->generation!=1U||s->frontier<lo->frontier||s->count<lo->count||s->count-lo->count>1U)return 0;}
    if(d->last.index!=s->count-1U || d->last.start!=s->start || d->last.reserved_end>s->frontier || d->last.session!=s->session || d->last.generation>s->generation+1U)return 0;
    nps2_record_sector(b,s,&d->last);if(!nps2_record_valid(b,s,d->last.index)||nps2_get(b+508)!=d->last_crc)return 0;
    if(d->after.capacity!=s->capacity||d->after.epoch!=s->epoch||d->after.generation!=s->generation+1U||d->after.count+1U!=s->count||d->after.frontier!=s->start||d->after.live)return 0;
    nps2_checkpoint(b,&d->after);if(!nps2_checkpoint_valid(b,s->capacity,s->epoch))return 0;
    if(s->count>1U){
        if(d->previous.index+1U!=d->last.index || d->previous.reserved_end!=s->start || d->previous.generation>s->generation || d->after.start!=d->previous.start || d->after.end!=s->start || d->after.session!=d->previous.session || d->after.open!=(uint32_t)(d->previous.state==NPS2_RECORD_OPEN))return 0;
        nps2_record_sector(b,s,&d->previous);if(!nps2_record_valid(b,s,d->previous.index)||nps2_get(b+508)!=d->previous_crc)return 0;
    }else {uint8_t zero[32]={0},record[32];nps2_delete_pack_record(record,&d->previous);if(memcmp(record,zero,32)||d->previous_crc)return 0;}
    expected_flags=d->last.state==NPS2_RECORD_OPEN?NPS2_DELETE_FLAG_OPEN:d->last.state==NPS2_RECORD_FAILED?NPS2_DELETE_FLAG_FAILED:0U;
    return d->flags==expected_flags;
}
static inline void nps2_delete_encode(uint8_t b[512],const Nps2Delete *d)
{
    const Nps2State *s=nps2_delete_high(d);memset(b,0,512);memcpy(b,"NPS2DL01",8);nps2_put(b+8,1U);nps2_put(b+12,1U);nps2_put(b+16,s->capacity);nps2_put(b+20,d->before_mask);nps2_put64(b+24,s->epoch);nps2_put64(b+32,d->nonce);memcpy(b+40,d->cid,16);
    nps2_delete_pack_state(b+56,&d->before[0]);nps2_delete_pack_state(b+88,&d->before[1]);nps2_delete_pack_state(b+120,&d->after);nps2_delete_pack_record(b+152,&d->last);nps2_delete_pack_record(b+184,&d->previous);
    nps2_put(b+216,d->last_crc);nps2_put(b+220,d->previous_crc);nps2_put(b+224,d->cp_crc[0]);nps2_put(b+228,d->cp_crc[1]);nps2_put(b+232,d->flags);nps2_seal(b);
}
static inline int nps2_delete_decode(Nps2Delete *d,const uint8_t b[512])
{
    memset(d,0,sizeof(*d));if(memcmp(b,"NPS2DL01",8)||nps2_get(b+8)!=1U||nps2_get(b+12)!=1U||!nps2_valid_crc(b))return 0;
    for(unsigned i=236;i<508;i++)if(b[i])return 0;
    uint32_t capacity=nps2_get(b+16);uint64_t epoch=nps2_get64(b+24);d->before_mask=nps2_get(b+20);d->nonce=nps2_get64(b+32);memcpy(d->cid,b+40,16);
    nps2_delete_unpack_state(&d->before[0],b+56,capacity,epoch);nps2_delete_unpack_state(&d->before[1],b+88,capacity,epoch);nps2_delete_unpack_state(&d->after,b+120,capacity,epoch);nps2_delete_unpack_record(&d->last,b+152);nps2_delete_unpack_record(&d->previous,b+184);
    d->last_crc=nps2_get(b+216);d->previous_crc=nps2_get(b+220);d->cp_crc[0]=nps2_get(b+224);d->cp_crc[1]=nps2_get(b+228);d->flags=nps2_get(b+232);return nps2_delete_shape(d);
}
static inline int nps2_delete_envelope(const uint8_t b[512])
{return !memcmp(b,"NPS2DL01",8)&&nps2_get(b+8)==1U&&nps2_get(b+12)==1U&&nps2_valid_crc(b);}
/* Exact identity/descriptor checks are independent of optional payload/footer validation. */
static inline int nps2_delete_read_record(const Nps2State *s,uint32_t index,Nps2Record *r,Nps2Read read);
static inline int nps2_delete_records_match(const Nps2Delete *d,Nps2Read read)
{
    const Nps2State *s=nps2_delete_high(d);Nps2Record r;
    if(nps2_delete_read_record(s,d->last.index,&r,read)||!nps2_delete_same_record(&r,&d->last))return 0;
    return s->count==1U || (!nps2_delete_read_record(s,d->previous.index,&r,read)&&nps2_delete_same_record(&r,&d->previous));
}
static inline int nps2_delete_read_record(const Nps2State *s,uint32_t index,Nps2Record *r,Nps2Read read)
{
    uint8_t raw[512];int result=nps2_read_record(s,index,r,read);if(result)return result;
    for(unsigned i=0;i<2;i++){
        if(read(NPS2_RECORD_BASE+2U*index+i,raw))return NPS2_IO;
        if(!nps2_record_valid(raw,s,index))continue;
        /* Valid fields0..55 already have the canonical layout; only the
         * reserved tail can differ. Avoid three redundant sector buffers. */
        for(unsigned j=56U;j<508U;j++)if(raw[j])return NPS2_INVALID;
    }
    return NPS2_OK;
}
static inline int nps2_delete_inspect(Nps2Delete *d,uint32_t capacity,const uint8_t cid[16],Nps2Read read)
{
    uint8_t a[512],b[512];Nps2Delete other;Nps2State normal;uint64_t epoch;int va,vb,ja,jb;
    memset(d,0,sizeof(*d));if(!read||!cid||capacity<=NPS2_DATA)return NPS2_INVALID;
    if(read(NPS2_IDENT0,a)||read(NPS2_IDENT1,b))return NPS2_IO;
    va=nps2_identity_valid(a,capacity);vb=nps2_identity_valid(b,capacity);if((!va&&!vb)||(va&&vb&&memcmp(a,b,512)))return NPS2_INVALID;epoch=nps2_get64((va?a:b)+56);
    if(read(NPS2_DELETE_JOURNAL0,a)||read(NPS2_DELETE_JOURNAL1,b))return NPS2_IO;
    ja=nps2_delete_decode(d,a);jb=nps2_delete_decode(&other,b);
    if((nps2_delete_envelope(a)&&nps2_get64(a+24)==epoch&&!ja) ||
       (nps2_delete_envelope(b)&&nps2_get64(b+24)==epoch&&!jb))return NPS2_INVALID;
    if((ja&&d->after.epoch==epoch)||(jb&&other.after.epoch==epoch)){
        if(ja&&jb&&memcmp(a,b,512))return NPS2_INVALID;if(!ja)*d=other;
        if(d->after.capacity!=capacity||memcmp(d->cid,cid,16))return NPS2_INVALID;
        unsigned proven=0;
        for(unsigned i=0;i<2;i++){
            Nps2State current;if(read(i?NPS2_CHECK1:NPS2_CHECK0,a))return NPS2_IO;
            if(!nps2_checkpoint_valid(a,capacity,epoch))continue;
            if(!nps2_delete_canonical_cp(a,capacity,epoch,&current))return NPS2_INVALID;
            if(!nps2_delete_same_state(&current,&d->after)&&(!(d->before_mask&(1U<<i))||!nps2_delete_same_state(&current,&d->before[i])))return NPS2_INVALID;
            proven++;
        }
        if(!proven||!nps2_delete_records_match(d,read))return NPS2_INVALID;
        d->state=d->after;d->pending=1U;d->needs_clear=1U;return NPS2_OK;
    }
    /* Foreign-format residue and torn/orphan intent confer no rollback authority. */
    uint32_t clear=ja||jb||!memcmp(a,"NPS2DL01",8)||!memcmp(b,"NPS2DL01",8);
    if(nps2_mount_raw(&normal,capacity,read))return NPS2_INVALID;
    memset(d,0,sizeof(*d));d->state=normal;d->needs_clear=clear;memcpy(d->cid,cid,16);
    if(!normal.count)return NPS2_OK;
    if(read(NPS2_CHECK0,a)||read(NPS2_CHECK1,b))return NPS2_IO;
    for(unsigned i=0;i<2;i++){
        const uint8_t *raw=i?b:a;
        if(nps2_checkpoint_valid(raw,capacity,epoch)){
            if(!nps2_delete_canonical_cp(raw,capacity,epoch,&d->before[i]))return NPS2_INVALID;
            d->before_mask|=1U<<i;d->cp_crc[i]=nps2_get(raw+508);
        }
    }
    if(nps2_delete_read_record(&normal,normal.count-1U,&d->last,read))return NPS2_MISSING;
    if(normal.count>1U&&nps2_delete_read_record(&normal,normal.count-2U,&d->previous,read))return NPS2_MISSING;
    d->last_crc=nps2_delete_record_crc(&normal,&d->last);if(normal.count>1U)d->previous_crc=nps2_delete_record_crc(&normal,&d->previous);
    d->after=normal;d->after.generation++;d->after.count--;d->after.frontier=normal.start;d->after.live=0U;
    if(d->after.count){d->after.start=d->previous.start;d->after.end=d->after.frontier;d->after.session=d->previous.session;d->after.open=d->previous.state==NPS2_RECORD_OPEN;}
    else d->after.start=d->after.end=d->after.session=d->after.open=0U;
    d->flags=d->last.state==NPS2_RECORD_OPEN?NPS2_DELETE_FLAG_OPEN:d->last.state==NPS2_RECORD_FAILED?NPS2_DELETE_FLAG_FAILED:0U;
    return NPS2_OK;
}
static inline int nps2_delete_clear(Nps2Read read,Nps2Write write)
{uint8_t zero[512]={0};return nps2_write_verified(NPS2_DELETE_JOURNAL0,zero,read,write)||nps2_write_verified(NPS2_DELETE_JOURNAL1,zero,read,write)?NPS2_IO:NPS2_OK;}
static inline int nps2_delete_recover(Nps2State *s,uint32_t capacity,const uint8_t cid[16],Nps2Read read,Nps2Write write)
{
    Nps2Delete d;uint8_t desired[512],current[512];int result=nps2_delete_inspect(&d,capacity,cid,read);memset(s,0,sizeof(*s));
    /* Missing optional records cannot revoke otherwise valid allocation authority. */
    if(result==NPS2_MISSING && d.state.ready && !d.pending){if(d.needs_clear&&nps2_delete_clear(read,write))return NPS2_IO;*s=d.state;return NPS2_OK;}
    if(result)return result;
    if(d.pending){
        nps2_checkpoint(desired,&d.after);
        for(unsigned i=0;i<2;i++){
            uint32_t lba=i?NPS2_CHECK1:NPS2_CHECK0;if(read(lba,current))return NPS2_IO;
            if(memcmp(current,desired,512)&&nps2_write_verified(lba,desired,read,write))return NPS2_IO;
        }
    }
    if(d.needs_clear&&nps2_delete_clear(read,write))return NPS2_IO;
    return nps2_mount_raw(s,capacity,read);
}
static inline uint32_t nps2_delete_token(const Nps2Delete *d,uint32_t nonce)
{uint8_t raw[512];Nps2Delete x=*d;x.nonce=nonce?nonce:1U;nps2_delete_encode(raw,&x);return nps2_crc(raw,236);}
static NPS2_DELETE_COLD int nps2_delete_commit_intent(Nps2State *s,const Nps2Delete *confirmed,uint64_t nonce,uint32_t capacity,const uint8_t cid[16],Nps2Read read,Nps2Write write)
{
    Nps2Delete now;uint8_t intent[512],previous[512];memset(s,0,sizeof(*s));int result=nps2_delete_inspect(&now,capacity,cid,read);if(result)return result;
    if(now.pending||now.needs_clear||!nonce||!now.state.count)return NPS2_INVALID;
    now.nonce=confirmed->nonce;Nps2Delete expected=*confirmed;
    if(!nps2_delete_shape(&now)||!nps2_delete_shape(&expected))return NPS2_INVALID;
    nps2_delete_encode(intent,&now);nps2_delete_encode(previous,&expected);if(memcmp(intent,previous,512))return NPS2_INVALID;
    now.nonce=nonce;nps2_delete_encode(intent,&now);
    if(nps2_write_verified(NPS2_DELETE_JOURNAL0,intent,read,write)||nps2_write_verified(NPS2_DELETE_JOURNAL1,intent,read,write))return NPS2_IO;
    return NPS2_OK;
}
static inline int nps2_delete_confirmed(Nps2State *s,const Nps2Delete *confirmed,uint64_t nonce,uint32_t capacity,const uint8_t cid[16],Nps2Read read,Nps2Write write)
{
    /* End the large preimage frame before entering recovery: cold maintenance
     * must fit the existing8KiB stack without borrowing capture buffers. */
    int result=nps2_delete_commit_intent(s,confirmed,nonce,capacity,cid,read,write);
    return result?result:nps2_delete_recover(s,capacity,cid,read,write);
}
static inline int nps2_delete_clean_for_state(const Nps2State *s,Nps2Read read)
{uint8_t b[512];for(unsigned i=0;i<2;i++){if(read(i?NPS2_DELETE_JOURNAL1:NPS2_DELETE_JOURNAL0,b))return 0;if(nps2_delete_envelope(b)&&nps2_get64(b+24)==s->epoch)return 0;}return 1;}
static inline int nps2_mount(Nps2State *s,uint32_t capacity,Nps2Read read)
{int result=nps2_mount_raw(s,capacity,read);if(!result&&!nps2_delete_clean_for_state(s,read)){memset(s,0,sizeof(*s));return NPS2_DELETE_PENDING;}return result;}
#endif
