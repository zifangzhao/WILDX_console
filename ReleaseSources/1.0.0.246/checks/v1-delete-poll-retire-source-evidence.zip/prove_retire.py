import argparse,hashlib,json,re,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--pin',required=True);p.add_argument('--output',default='retire1');a=p.parse_args()
root=Path(__file__).resolve().parent;t=Path('C:/Frank/Code/XE_NP/_artifacts/v1_delete_last_20261105');port=t/'usb-source/delete.inc';out=root/a.output
assert not out.exists(),'Preserve previous evidence'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
assert sha(port)==a.pin.upper(),'Frozen owner port changed'
pins={'np_store_v2.h':'703A07BFBA2A2D6BE766266D53885B2F18E78943BBF263304E99F5FFC7B225DA','np_store_v2_delete.h':'DF05B9DCBDAAB476B7B12D1B85E3076F4E3121DEBA885A175BCF719B98CEBA71','np_store_v2_delete_wire.h':'507BCC48738E08DB772F03A1311C4E1E362DE64C487D3E467711EF91523A0D18'}
for name,digest in pins.items():assert sha(t/'core'/name)==digest
text=port.read_text();pre=text[:text.index('static void np_usb_delete_cancel')]
def function(name):
 m=re.search(r'(?m)^[^\n;]*\b'+name+r'\(',pre);assert m,name
 start=m.start();at=pre.index('{',m.end());depth=1;at+=1
 while depth:depth+=(pre[at]=='{')-(pre[at]=='}');at+=1
 return pre[start:at]
names=re.findall(r'(?m)^(?:__attribute__\(\(noinline\)\) )?static [^\n;]*\b(np_usb_delete_\w+)\([^;\n]*\)\s*\n?\{',pre)
names=[n for n in names if n not in ['np_usb_delete_owned','np_usb_delete_publish','np_usb_delete_card']]
assert all(n in names for n in ['np_usb_delete_quiet','np_usb_delete_retire','np_usb_delete_read','np_usb_delete_write','np_usb_delete_clock_begin','np_usb_delete_clock_end'])
globals_text=pre[:pre.index('static int np_usb_delete_owned')]
globals_text=re.sub(r' __attribute__\(\(section\("NP_USB_DMA"\),aligned\(32\)\)\)','',globals_text)
globals_text=re.sub(r'#include "[^"]*np_store_v2_delete_wire.h"','#include "np_store_v2_delete_wire.h"',globals_text)
actual=globals_text+'\n\n'+'\n\n'.join(function(n) for n in names)
actual=actual.replace('__attribute__((noinline))','__declspec(noinline)')
assert '__attribute__' not in actual,'Only native declaration syntax may be adapted'
out.mkdir();(out/'actual_retirement.inc').write_text(actual+'\n')
for name in (*pins,'np_sd_fast_crc.h'):(out/name).write_bytes((t/'core'/name).read_bytes())
(out/'fixture.c').write_bytes((root/'retire_fixture.c').read_bytes())
vc='C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat';cmd=f'call "{vc}" >nul && cl /nologo /std:c11 /W4 /WX /TC /O2 /I"{out}" "{out}/fixture.c" /Fo"{out}/fixture.obj" /Fe"{out}/fixture.exe"'
started=datetime.now(timezone.utc).isoformat();watch=time.perf_counter();(out/'command.txt').write_text(cmd+'\n')
build=subprocess.run('cmd /d /s /c "'+cmd+'"',cwd=out,capture_output=True,text=True,timeout=60);(out/'compile.log').write_text(build.stdout+build.stderr);assert build.returncode==0,build.stdout+build.stderr
run=subprocess.run([str(out/'fixture.exe')],cwd=out,capture_output=True,text=True,timeout=60);(out/'result.txt').write_text(run.stdout+run.stderr);print(run.stdout+run.stderr,end='');assert run.returncode==0,'Actual port guard failed'
assert sha(port)==a.pin.upper()
receipt={'status':'PASS','started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),'seconds':time.perf_counter()-watch,'port_sha256':a.pin.upper(),'actual_functions':names,'actual_functions_sha256':sha(out/'actual_retirement.inc'),'headers':pins,'result_sha256':sha(out/'result.txt'),'scope':'Actual extracted USB metadata retirement/read/write/clock functions with modeled HAL polling residual context and physical quiet flags; no actual HAL command, firmware/app build or hardware'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('receipt',out/'receipt.json',sha(out/'receipt.json'))
