#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "np_store_v2_delete_wire.h"
static unsigned checks;
#define CHECK(x) do{checks++;if(!(x)){fprintf(stderr,"FAIL line%d: %s\n",__LINE__,#x);exit(1);}}while(0)
typedef struct {uint32_t STA,DCTRL,IDMACTRL,CLKCR;} Registers;
typedef struct {Registers *Instance;uint32_t State,Context,ErrorCode;struct{uint32_t LogBlockNbr;}SdCard;} SD_HandleTypeDef;
static Registers registers;
#define SDMMC1 (&registers)
#define HAL_SD_STATE_READY 1U
#define HAL_SD_CARD_TRANSFER 4U
#define SD_CONTEXT_NONE 0U
#define SD_CONTEXT_READ_SINGLE_BLOCK 1U
#define SD_CONTEXT_WRITE_SINGLE_BLOCK 16U
#define SDMMC_STA_DPSMACT 1U
#define SDMMC_STA_CPSMACT 2U
#define SDMMC_STA_BUSYD0 4U
#define SDMMC_DCTRL_DTEN 1U
#define SDMMC_IDMA_IDMAEN 1U
#define SDMMC_CLKCR_CLKDIV 1023U
#define HAL_OK 0
#define CARD_CAPACITY 262144U
#define __DSB() ((void)0)
#pragma warning(disable:4459) /* Actual port parameter vs mock register names. */
static SD_HandleTypeDef hsd1;
static unsigned idle=1U,ticks,read_calls,write_calls,status_calls,cleans,hal_failed;
static uint32_t context_after_read=SD_CONTEXT_READ_SINGLE_BLOCK,context_after_write=SD_CONTEXT_WRITE_SINGLE_BLOCK,physical_after,card_state=HAL_SD_CARD_TRANSFER;
static int np_info_idle(void){return idle;}
static uint32_t HAL_GetTick(void){return ticks++;}
static uint32_t HAL_SD_GetCardState(SD_HandleTypeDef *s){CHECK(s==&hsd1);status_calls++;return card_state;}
static int HAL_SD_ReadBlocks(SD_HandleTypeDef *s,uint8_t *p,uint32_t lba,uint32_t n,uint32_t timeout){CHECK(s==&hsd1&&p&&lba<CARD_CAPACITY&&n==1U&&timeout==1000U);read_calls++;memset(p,0x5a,512);s->Context=context_after_read;registers.STA=physical_after;return hal_failed?-1:HAL_OK;}
static int HAL_SD_WriteBlocks(SD_HandleTypeDef *s,const uint8_t *p,uint32_t lba,uint32_t n,uint32_t timeout){CHECK(s==&hsd1&&p&&lba<CARD_CAPACITY&&n==1U&&timeout==1000U);write_calls++;s->Context=context_after_write;registers.STA=physical_after;return hal_failed?-1:HAL_OK;}
static void XE_NP_UsbStream_DCacheCleanTx(const void *p,uint32_t n){CHECK(p&&n==512U);cleans++;}
#include "actual_retirement.inc"
static void reset(void){
 memset(&registers,0,sizeof(registers));memset(&hsd1,0,sizeof(hsd1));hsd1.Instance=SDMMC1;hsd1.State=HAL_SD_STATE_READY;hsd1.SdCard.LogBlockNbr=CARD_CAPACITY;registers.CLKCR=0x1400U;
 memset(&np_usb_delete,0,sizeof(np_usb_delete));np_usb_delete_clock_held=np_usb_delete_port_error=0U;np_usb_delete_clock=0U;
 ticks=read_calls=write_calls=status_calls=cleans=hal_failed=physical_after=0U;idle=1U;context_after_read=SD_CONTEXT_READ_SINGLE_BLOCK;context_after_write=SD_CONTEXT_WRITE_SINGLE_BLOCK;card_state=HAL_SD_CARD_TRANSFER;
}
static void begin(void){CHECK(np_usb_delete_clock_begin()==0 && np_usb_delete_clock_held && (registers.CLKCR&SDMMC_CLKCR_CLKDIV)==8U);}
int main(void){
 uint8_t bytes[512];
 reset();begin();CHECK(np_usb_delete_read(16U,bytes)==0 && read_calls==1U && bytes[0]==0x5a && hsd1.Context==SD_CONTEXT_NONE&&!np_usb_delete_port_error);np_usb_delete_clock_end();CHECK(!np_usb_delete_clock_held&&registers.CLKCR==0x1400U);
 reset();begin();CHECK(np_usb_delete_write(112U,bytes)==0 && write_calls==1U && cleans==1U && hsd1.Context==SD_CONTEXT_NONE&&!np_usb_delete_port_error);np_usb_delete_clock_end();CHECK(!np_usb_delete_clock_held&&registers.CLKCR==0x1400U);
 reset();begin();context_after_read=SD_CONTEXT_NONE;CHECK(np_usb_delete_read(16U,bytes)==0);np_usb_delete_clock_end();CHECK(!np_usb_delete_clock_held);
 for(unsigned write=0U;write<2U;write++){
  reset();begin();if(write)context_after_write=SD_CONTEXT_READ_SINGLE_BLOCK;else context_after_read=SD_CONTEXT_WRITE_SINGLE_BLOCK;
  CHECK((write?np_usb_delete_write(112U,bytes):np_usb_delete_read(16U,bytes))!=0 && np_usb_delete_port_error && hsd1.Context!=SD_CONTEXT_NONE);np_usb_delete_clock_end();CHECK(np_usb_delete_clock_held && (registers.CLKCR&SDMMC_CLKCR_CLKDIV)==8U);
  reset();begin();hal_failed=1U;CHECK((write?np_usb_delete_write(112U,bytes):np_usb_delete_read(16U,bytes))!=0 && np_usb_delete_port_error && hsd1.Context!=SD_CONTEXT_NONE);np_usb_delete_clock_end();CHECK(np_usb_delete_clock_held);
  reset();begin();card_state=3U;CHECK((write?np_usb_delete_write(112U,bytes):np_usb_delete_read(16U,bytes))!=0 && np_usb_delete_port_error);np_usb_delete_clock_end();CHECK(np_usb_delete_clock_held);
  for(unsigned busy=1U;busy<=4U;busy<<=1U){reset();begin();physical_after=busy;CHECK((write?np_usb_delete_write(112U,bytes):np_usb_delete_read(16U,bytes))!=0 && np_usb_delete_port_error);np_usb_delete_clock_end();CHECK(np_usb_delete_clock_held);}
 }
 reset();hsd1.Context=0x100U;CHECK(np_usb_delete_clock_begin()!=0 && !np_usb_delete_clock_held);
 reset();hsd1.ErrorCode=1U;CHECK(np_usb_delete_clock_begin()!=0 && !np_usb_delete_clock_held);
 reset();idle=0U;CHECK(np_usb_delete_clock_begin()!=0 && !np_usb_delete_clock_held);
 reset();begin();hsd1.ErrorCode=1U;np_usb_delete_clock_end();CHECK(np_usb_delete_clock_held && hsd1.ErrorCode==1U);
 reset();begin();np_usb_delete.cancelled=1U;CHECK(np_usb_delete_write(112U,bytes)!=0 && !write_calls);
 reset();begin();CHECK(np_usb_delete_write(8192U,bytes)!=0 && !write_calls);CHECK(np_usb_delete_read(CARD_CAPACITY,bytes)!=0 && !read_calls);
 printf("PASS actual owned polling retirement checks%u; read/write ContextNONE/owned, foreign/error/busy/CMD13 pins, clockrestore, noabort\n",checks);return 0;
}
