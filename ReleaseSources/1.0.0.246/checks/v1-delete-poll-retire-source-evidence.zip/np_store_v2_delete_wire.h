#ifndef NP_STORE_V2_DELETE_WIRE_H
#define NP_STORE_V2_DELETE_WIRE_H
#include "np_store_v2_delete.h"
#define NPS2_DELETE_WIRE_MAGIC 0x3155444EU
typedef struct {uint32_t uid[3],cid[4],capacity,epoch,clock_hz;} Nps2DeleteCard;
typedef struct {
    uint32_t report[32],confirmed[32],request[32];
    Nps2Delete confirmed_store;
    uint32_t last_nonce,queued,running,cancelled;
} Nps2DeleteWire;
static inline void nps2_delete_wire_seal(uint32_t *p){p[31]=nps2_crc((const uint8_t *)p,124U);}
static inline int nps2_delete_wire_identity(const uint32_t *p,const Nps2DeleteCard *c)
{return p[6]==c->epoch&&p[8]==c->capacity&&!memcmp(p+16,c->cid,16)&&!memcmp(p+20,c->uid,12);}
static inline void nps2_delete_wire_init(Nps2DeleteWire *w,const Nps2DeleteCard *c)
{
    if(w->report[0])return;
    memset(w,0,sizeof(*w));w->report[0]=NPS2_DELETE_WIRE_MAGIC;w->report[1]=1U;memcpy(w->report+20,c->uid,12);nps2_delete_wire_seal(w->report);
}
static inline int nps2_delete_wire_inspect_submit(Nps2DeleteWire *w,uint32_t nonce,const Nps2DeleteCard *c)
{
    nps2_delete_wire_init(w,c);if(w->queued||w->running||!nonce||nonce!=w->last_nonce+1U)return 0;
    memset(w->report,0,128);w->report[0]=NPS2_DELETE_WIRE_MAGIC;w->report[1]=1U;w->report[2]=1U;w->report[3]=1U;w->report[4]=nonce;
    w->report[6]=c->epoch;w->report[8]=c->capacity;memcpy(w->report+16,c->cid,16);memcpy(w->report+20,c->uid,12);w->report[23]=c->clock_hz;
    memset(w->confirmed,0,128);memset(&w->confirmed_store,0,sizeof(w->confirmed_store));w->last_nonce=nonce;w->cancelled=0U;nps2_delete_wire_seal(w->report);w->queued=1U;return 1;
}
static inline int nps2_delete_wire_confirm_submit(Nps2DeleteWire *w,const uint8_t request[128],const Nps2DeleteCard *c)
{
    uint32_t expected[32];if(w->queued||w->running||w->confirmed[3]!=3U||!(w->confirmed[7]&2U))return 0;
    memcpy(expected,w->confirmed,128);expected[2]=2U;expected[4]=w->last_nonce+1U;expected[24]=w->last_nonce;nps2_delete_wire_seal(expected);
    if(!expected[4]||memcmp(expected,request,128)||!nps2_delete_wire_identity(expected,c))return 0;
    memcpy(w->request,expected,128);memcpy(w->report,expected,128);w->last_nonce=expected[4];w->report[3]=1U;nps2_delete_wire_seal(w->report);w->cancelled=0U;w->queued=2U;return 1;
}
static NPS2_DELETE_COLD int nps2_delete_wire_service(Nps2DeleteWire *w,const Nps2DeleteCard *c,Nps2Read read,Nps2Write write,void (*publish)(uint32_t *,const uint32_t *))
{
    uint32_t op=w->queued,work[32];Nps2Delete inspected;Nps2State after;int result=NPS2_INVALID;
    if(!op)return 0;w->queued=0U;w->running=1U;memcpy(work,w->report,128);work[3]=2U;nps2_delete_wire_seal(work);if(publish)publish(w->report,work);else memcpy(w->report,work,128);
    if(!w->cancelled&&nps2_delete_wire_identity(work,c)){
        if(op==1U){
            result=nps2_delete_inspect(&inspected,c->capacity,(const uint8_t *)c->cid,read);
            if(!result){
                inspected.nonce=work[4];int allowed=inspected.state.count&&!inspected.pending&&!inspected.needs_clear&&nps2_delete_shape(&inspected);
                work[7]=1U|(allowed?2U:0U)|(inspected.last.state==NPS2_RECORD_OPEN?4U:inspected.last.state==NPS2_RECORD_FAILED?8U:0U);
                work[9]=inspected.state.count;work[10]=inspected.state.frontier;work[11]=inspected.state.count?inspected.state.count-1U:0U;
                work[12]=inspected.last.start;work[13]=inspected.state.count?inspected.state.frontier:0U;work[14]=inspected.last_crc;work[15]=inspected.state.count?nps2_delete_token(&inspected,work[4]):0U;work[24]=work[4];
                w->confirmed_store=inspected;
            }
        }else if(op==2U){
            result=nps2_delete_confirmed(&after,&w->confirmed_store,((uint64_t)c->epoch<<32)|work[4],c->capacity,(const uint8_t *)c->cid,read,write);
            if(!result){work[7]=1U;work[9]=after.count;work[10]=after.frontier;}
        }
    }
    if(w->cancelled||!nps2_delete_wire_identity(work,c))result=NPS2_INVALID;
    work[5]=result?0xE2D00001U:0U;work[3]=result?4U:3U;nps2_delete_wire_seal(work);if(publish)publish(w->report,work);else memcpy(w->report,work,128);
    if(!result&&op==1U)memcpy(w->confirmed,work,128);else memset(w->confirmed,0,128);
    w->running=0U;return 1;
}
static inline void nps2_delete_wire_cancel(Nps2DeleteWire *w)
{w->cancelled=1U;memset(w->confirmed,0,128);if(w->queued&&!w->running){w->queued=0U;w->report[3]=4U;w->report[5]=0xE2D00002U;nps2_delete_wire_seal(w->report);}}
#endif
