from datetime import datetime,timezone
import hashlib,json,re,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent;t=Path('C:/Frank/Code/XE_NP/_artifacts/v1_delete_last_20261105');out=root/'initializer2';assert not out.exists()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
stream=t/'usb-source/stream.c';delete=t/'usb-source/delete.inc';assert sha(stream)=='C82F218CB428A42DA2CED393FE095E139BAFF34D68D95A8224689FBD37EFE674';assert sha(delete)=='8D6D48E48B5B48DB840714FA3732B5D5252790045A17EE0466DE3172888BBBB9'
def function(text,name):
 m=re.search(r'(?m)^(?:(?:__attribute__\(\(noinline\)\)|__declspec\(noinline\)) )?(?:static )?(?:int|void|uint32_t) '+name+r'\(',text);assert m,name
 start=m.start();at=text.index('{',m.end())+1;depth=1
 while depth:depth+=(text[at]=='{')-(text[at]=='}');at+=1
 return text[start:at].replace('__attribute__((noinline))','__declspec(noinline)')
text=delete.read_text();prior=(root/'retire2/actual_retirement.inc').read_text();helpers=['np_usb_delete_physical_quiet','np_usb_delete_quiet','np_usb_delete_retire','np_usb_delete_read','np_usb_delete_write','np_usb_delete_clock_begin','np_usb_delete_clock_end']
for name in helpers:assert function(text,name)==function(prior,name)
globals_text=text[:text.index('static int np_usb_delete_owned')];globals_text=re.sub(r' __attribute__\(\(section\("NP_USB_DMA"\),aligned\(32\)\)\)','',globals_text);globals_text=re.sub(r'#include "[^"]*np_store_v2_delete_wire.h"','#include "np_store_v2_delete_wire.h"',globals_text)
backend=Path('C:/Frank/Code/XE_NP/_artifacts/v1_rtc_20261029/usb_source/frozen/_artifacts/v1_usb_uhs200_restore_20261020/retained-r2/source/np_usb_backend.inc');reset=Path('C:/Frank/Code/XE_NP/_artifacts/v1_usb_fast_startup_r79r2_20261006/source/Core/Src/np_usb_sd_reset.inc');info=t/'usb-source/np_sd_info_v1_service.inc'
st=stream.read_text();assert st.index('#define NP_USB_ReinitializeSd np_usb_sd_initialize_owned')<st.index(str(backend).replace('\\','/'))
actual=globals_text+'\n\n'+'\n\n'.join(function(text,n) for n in ['np_usb_delete_owned',*helpers])+'\n'+function(st,'np_usb_sd_initialize_owned')+'\n#define NP_USB_ReinitializeSd np_usb_sd_initialize_owned\n'+function(text,'np_usb_delete_service')+'\n'+function(backend.read_text(),'NP_USB_PrepareDownload')+'\n'+function(reset.read_text(),'np_v1_sd_reset_service')+'\n'
infotext=info.read_text();infoglobals=infotext[:infotext.index('static int np_usb_sd_info_owned')];infoglobals=re.sub(r' __attribute__\(\(section\("NP_USB_DMA"\),aligned\(32\)\)\)','',infoglobals);actual+=infoglobals+'\n'+function(infotext,'np_usb_sd_info_service')+'\n'
out.mkdir();(out/'actual_initializer.inc').write_text(actual);(out/'fixture.c').write_bytes((root/'initializer_fixture.c').read_bytes())
for name in ['np_store_v2.h','np_store_v2_delete.h','np_store_v2_delete_wire.h','np_sd_fast_crc.h']:(out/name).write_bytes((t/'core'/name).read_bytes())
(out/'xe_np_sd_info.h').write_bytes((t/'usb-source/xe_np_sd_info.h').read_bytes())
vc='C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat';cmd=f'call "{vc}" >nul && cl /nologo /std:c11 /W4 /WX /TC /O2 /I"{out}" "{out}/fixture.c" /Fo"{out}/fixture.obj" /Fe"{out}/fixture.exe"';started=datetime.now(timezone.utc).isoformat();watch=time.perf_counter();(out/'command.txt').write_text(cmd+'\n');build=subprocess.run('cmd /d /s /c "'+cmd+'"',cwd=out,capture_output=True,text=True,timeout=60);(out/'compile.log').write_text(build.stdout+build.stderr);assert build.returncode==0,build.stdout+build.stderr
run=subprocess.run([str(out/'fixture.exe')],cwd=out,capture_output=True,text=True,timeout=60);(out/'result.txt').write_text(run.stdout+run.stderr);print(run.stdout+run.stderr,end='');assert run.returncode==0
receipt={'status':'PASS','started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),'seconds':time.perf_counter()-watch,'stream_sha256':sha(stream),'delete_port_sha256':sha(delete),'actual_functions_sha256':sha(out/'actual_initializer.inc'),'caller_source_pins':{str(p):sha(p) for p in [backend,reset,info]},'retire85_helpers_byte_identical':True,'result_sha256':sha(out/'result.txt'),'scope':'Actual shared wrapper, PrepareDownload, SDInfo restore,0x68service and queued A7 with real store/wire and mocked initializer/pollingHAL; no firmware/app build, hardware or broad core rerun'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('receipt',out/'receipt.json',sha(out/'receipt.json'))
