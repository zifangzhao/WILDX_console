#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "np_store_v2_delete_wire.h"
#include "xe_np_sd_info.h"
static unsigned checks;
#define CHECK(x) do{checks++;if(!(x)){fprintf(stderr,"FAIL line%d: %s\n",__LINE__,#x);exit(1);}}while(0)
typedef struct {uint32_t STA,DCTRL,IDMACTRL,CLKCR;} Registers;
typedef struct {Registers *Instance;uint32_t State,Context,ErrorCode,CID[4];struct{uint32_t LogBlockNbr;}SdCard;} SD_HandleTypeDef;
static Registers registers;
#define SDMMC1 (&registers)
#define HAL_SD_STATE_READY 1U
#define HAL_SD_CARD_TRANSFER 4U
#define SD_CONTEXT_NONE 0U
#define SD_CONTEXT_READ_SINGLE_BLOCK 1U
#define SD_CONTEXT_WRITE_SINGLE_BLOCK 16U
#define SDMMC_STA_DPSMACT 1U
#define SDMMC_STA_CPSMACT 2U
#define SDMMC_STA_BUSYD0 4U
#define SDMMC_DCTRL_DTEN 1U
#define SDMMC_IDMA_IDMAEN 1U
#define SDMMC_CLKCR_CLKDIV 1023U
#define SDMMC1_IRQn 1U
#define HAL_OK 0
#define __DSB() ((void)0)
#define CARD_CAPACITY 262144U
#pragma warning(disable:4459)
static SD_HandleTypeDef hsd1;
static unsigned idle=1U,ticks,read_calls,write_calls,status_calls,hal_failed,admission_probes,reinit_calls,allow_writes,queued_test;
static int init_result;static uint32_t init_context=1U,init_error,cid_change;
static uint32_t card_state=HAL_SD_CARD_TRANSFER,np_v1_job_refresh,np_usb_sd_ready;
static uint8_t sectors[256][512];
static int np_info_idle(void);
static void np_usb_delete_card(Nps2DeleteCard *);
static void np_usb_delete_publish(uint32_t *,const uint32_t *);
static uint32_t HAL_GetTick(void){return ticks++;}
static uint32_t HAL_SD_GetCardState(SD_HandleTypeDef *s){CHECK(s==&hsd1);status_calls++;return card_state;}
static int HAL_SD_ReadBlocks(SD_HandleTypeDef *s,uint8_t *p,uint32_t lba,uint32_t n,uint32_t timeout){CHECK(s==&hsd1&&p&&lba<256U&&n==1U&&timeout==1000U);read_calls++;memcpy(p,sectors[lba],512);s->Context=SD_CONTEXT_READ_SINGLE_BLOCK;return hal_failed?-1:HAL_OK;}
static int HAL_SD_WriteBlocks(SD_HandleTypeDef *s,const uint8_t *p,uint32_t lba,uint32_t n,uint32_t timeout){CHECK(s==&hsd1&&p&&n==1U&&timeout==1000U&&(lba==112U||lba==113U||lba==114U||lba==115U));write_calls++;if(!allow_writes)return -1;memcpy(sectors[lba],p,512);s->Context=SD_CONTEXT_WRITE_SINGLE_BLOCK;return HAL_OK;}
static void XE_NP_UsbStream_DCacheCleanTx(const void *p,uint32_t n){CHECK(p&&n==512U);}
static int NP_USB_ReinitializeSd(void){reinit_calls++;hsd1.Context=init_context;hsd1.ErrorCode=init_error;if(cid_change)hsd1.CID[0]^=1U;return init_result;}
static void HAL_NVIC_DisableIRQ(unsigned irq){CHECK(irq==SDMMC1_IRQn);}
#define RCC_MCO1 0U
#define RCC_MCO1SOURCE_NOCLOCK 0U
#define RCC_MCODIV_1 0U
#define __HAL_RCC_SRAM5_CLK_ENABLE() ((void)0)
#define __DMB() ((void)0)
static void HAL_RCC_MCOConfig(unsigned a,unsigned b,unsigned c){(void)a;(void)b;(void)c;}
static int NP_USB_IsDownload(void){return 1;}
static uint32_t np_usb_sd_prepare_pending,np_usb_sd_reset_receipt[8],primask;
static void NP_SD_UsbReset(void){}
static uint32_t __get_PRIMASK(void){return primask;}
static void __disable_irq(void){primask=1U;}
static void __set_PRIMASK(uint32_t p){primask=p;}
void XE_NP_Board_ReadSdInfo(XE_NP_SdInfo *info){info->state=XE_NP_SD_INFO_READY;info->flags=XE_NP_SD_INFO_IDENTIFIED;info->sectors_low=hsd1.SdCard.LogBlockNbr;for(unsigned i=0;i<16U;i++)info->cid[i]=(uint8_t)(hsd1.CID[i/4U]>>(24U-8U*(i%4U)));}
#include "actual_initializer.inc"
static int np_info_idle(void){admission_probes++;if(!queued_test)CHECK(!np_usb_delete_auto_running);return idle;}
static void np_usb_delete_card(Nps2DeleteCard *c){memset(c,0,sizeof(*c));c->uid[0]=1U;c->uid[1]=2U;c->uid[2]=3U;c->epoch=5U;c->capacity=hsd1.SdCard.LogBlockNbr;memcpy(c->cid,hsd1.CID,16);}
static void np_usb_delete_publish(uint32_t *to,const uint32_t *from){memcpy(to,from,128);}
static int ram_read(uint32_t lba,uint8_t *p){CHECK(lba<256U);memcpy(p,sectors[lba],512);return 0;}
static int ram_write(uint32_t lba,const uint8_t *p){CHECK(lba<256U);memcpy(sectors[lba],p,512);return 0;}
static void reset(void){
 memset(&registers,0,sizeof(registers));memset(&hsd1,0,sizeof(hsd1));hsd1.Instance=SDMMC1;hsd1.State=HAL_SD_STATE_READY;hsd1.SdCard.LogBlockNbr=CARD_CAPACITY;registers.CLKCR=0x1400U;for(unsigned i=0;i<4U;i++)hsd1.CID[i]=0x10203040U+i;
 memset(&np_usb_delete,0,sizeof(np_usb_delete));np_usb_delete_receiving=np_usb_delete_auto_checked=np_usb_delete_auto_running=np_usb_delete_clock_held=np_usb_delete_port_error=np_usb_delete_clock=0U;
 ticks=read_calls=write_calls=status_calls=hal_failed=admission_probes=reinit_calls=np_v1_job_refresh=allow_writes=queued_test=0U;idle=1U;np_usb_sd_ready=1U;card_state=HAL_SD_CARD_TRANSFER;init_result=0;init_context=1U;init_error=cid_change=0U;primask=np_info_pending=np_info_cancelled=0U;memset(&np_info_cache,0,sizeof(np_info_cache));memset(np_usb_sd_reset_receipt,0,sizeof(np_usb_sd_reset_receipt));
 memset(sectors,0,sizeof(sectors));Nps2State s;CHECK(nps2_format(&s,CARD_CAPACITY,UINT64_C(0x1234567887654321),ram_read,ram_write)==NPS2_OK);
 CHECK(nps2_begin(&s,2U*NPS2_ALIGN,101U,ram_read,ram_write)==NPS2_OK);CHECK(nps2_finish(&s,s.start+99U,1,ram_read,ram_write)==NPS2_OK);
}
int main(void){
 reset();np_usb_sd_prepare_pending=1U;NP_USB_PrepareDownload();CHECK(!np_usb_sd_prepare_pending&&np_usb_sd_ready&&hsd1.Context==SD_CONTEXT_NONE&&reinit_calls==1U);CHECK(np_usb_delete_service()==0&&np_usb_delete_auto_checked&&!np_usb_delete_owned()&&!write_calls&&registers.CLKCR==0x1400U);
 reset();np_info_pending=1U;np_info_cache.sequence=7U;CHECK(np_usb_sd_info_service()==1&&np_info_cache.state==XE_NP_SD_INFO_READY&&!np_info_pending&&hsd1.Context==SD_CONTEXT_NONE&&reinit_calls==1U&&!write_calls);
 reset();np_usb_sd_reset_receipt[1]=1U;CHECK(np_v1_sd_reset_service()==1&&np_usb_sd_reset_receipt[1]==3U&&np_usb_sd_ready&&hsd1.Context==SD_CONTEXT_NONE&&reinit_calls==1U&&!write_calls);
 for(unsigned fail=0U;fail<4U;fail++){reset();if(fail==0U)init_result=-3;else if(fail==1U)init_context=SD_CONTEXT_WRITE_SINGLE_BLOCK;else if(fail==2U)init_error=1U;else card_state=3U;CHECK(np_usb_sd_initialize_owned()!=0&&hsd1.Context!=SD_CONTEXT_NONE&&!write_calls);}
 for(unsigned op=1U;op<=2U;op++)for(unsigned fail=0U;fail<4U;fail++){
  reset();queued_test=1U;np_usb_delete_auto_checked=1U;Nps2DeleteCard c;np_usb_delete_card(&c);CHECK(nps2_delete_wire_inspect_submit(&np_usb_delete,1U,&c));
  if(op==2U){CHECK(nps2_delete_wire_service(&np_usb_delete,&c,ram_read,ram_write,NULL));uint32_t request[32];memcpy(request,np_usb_delete.confirmed,128);request[2]=2U;request[4]=2U;request[24]=1U;nps2_delete_wire_seal(request);CHECK(nps2_delete_wire_confirm_submit(&np_usb_delete,(const uint8_t *)request,&c));}
  if(fail==1U)init_result=-3;else if(fail==2U)cid_change=1U;else if(fail==3U)init_context=0x100U;
  allow_writes=op==2U;CHECK(np_usb_delete_service()==0 && !np_usb_delete_owned());
  if(!fail)CHECK(np_usb_delete.report[3]==3U&&!np_usb_delete.report[5]&&hsd1.Context==SD_CONTEXT_NONE&&write_calls==(op==2U?6U:0U));
  else CHECK(np_usb_delete.report[3]==4U&&np_usb_delete.report[5]&&!write_calls&&!read_calls);
 }
 printf("PASS actual shared initializer checks%u; coldNoJob/SDInfo/0x68/queued1_2, failedInit/foreignCID/unknownContext no mutation\n",checks);return 0;
}
