#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "np_store_v2_delete_wire.h"
static unsigned checks;
#define CHECK(x) do{checks++;if(!(x)){fprintf(stderr,"FAIL line%d: %s\n",__LINE__,#x);exit(1);}}while(0)
typedef struct {uint32_t STA,DCTRL,IDMACTRL,CLKCR;} Registers;
typedef struct {Registers *Instance;uint32_t State,Context,ErrorCode,CID[4];struct{uint32_t LogBlockNbr;}SdCard;} SD_HandleTypeDef;
static Registers registers;
#define SDMMC1 (&registers)
#define HAL_SD_STATE_READY 1U
#define HAL_SD_CARD_TRANSFER 4U
#define SD_CONTEXT_NONE 0U
#define SD_CONTEXT_READ_SINGLE_BLOCK 1U
#define SD_CONTEXT_WRITE_SINGLE_BLOCK 16U
#define SDMMC_STA_DPSMACT 1U
#define SDMMC_STA_CPSMACT 2U
#define SDMMC_STA_BUSYD0 4U
#define SDMMC_DCTRL_DTEN 1U
#define SDMMC_IDMA_IDMAEN 1U
#define SDMMC_CLKCR_CLKDIV 1023U
#define SDMMC1_IRQn 1U
#define HAL_OK 0
#define __DSB() ((void)0)
#define CARD_CAPACITY 262144U
#pragma warning(disable:4459)
static SD_HandleTypeDef hsd1;
static unsigned idle=1U,ticks,read_calls,write_calls,status_calls,hal_failed,admission_probes,reinit_calls;
static uint32_t card_state=HAL_SD_CARD_TRANSFER,np_v1_job_refresh,np_usb_sd_ready;
static uint8_t sectors[256][512];
static int np_info_idle(void);
static void np_usb_delete_card(Nps2DeleteCard *);
static void np_usb_delete_publish(uint32_t *,const uint32_t *);
static uint32_t HAL_GetTick(void){return ticks++;}
static uint32_t HAL_SD_GetCardState(SD_HandleTypeDef *s){CHECK(s==&hsd1);status_calls++;return card_state;}
static int HAL_SD_ReadBlocks(SD_HandleTypeDef *s,uint8_t *p,uint32_t lba,uint32_t n,uint32_t timeout){CHECK(s==&hsd1&&p&&lba<256U&&n==1U&&timeout==1000U);read_calls++;memcpy(p,sectors[lba],512);s->Context=SD_CONTEXT_READ_SINGLE_BLOCK;return hal_failed?-1:HAL_OK;}
static int HAL_SD_WriteBlocks(SD_HandleTypeDef *s,const uint8_t *p,uint32_t lba,uint32_t n,uint32_t timeout){(void)s;(void)p;(void)lba;(void)n;(void)timeout;write_calls++;return -1;}
static void XE_NP_UsbStream_DCacheCleanTx(const void *p,uint32_t n){CHECK(p&&n==512U);}
static int NP_USB_ReinitializeSd(void){reinit_calls++;return 0;}
static void HAL_NVIC_DisableIRQ(unsigned irq){CHECK(irq==SDMMC1_IRQn);}
#include "actual_cold.inc"
static int np_info_idle(void){admission_probes++;CHECK(!np_usb_delete_auto_running);return idle;}
static void np_usb_delete_card(Nps2DeleteCard *c){memset(c,0,sizeof(*c));c->uid[0]=1U;c->uid[1]=2U;c->uid[2]=3U;c->epoch=5U;c->capacity=hsd1.SdCard.LogBlockNbr;memcpy(c->cid,hsd1.CID,16);}
static void np_usb_delete_publish(uint32_t *to,const uint32_t *from){memcpy(to,from,128);}
static int ram_read(uint32_t lba,uint8_t *p){CHECK(lba<256U);memcpy(p,sectors[lba],512);return 0;}
static int ram_write(uint32_t lba,const uint8_t *p){CHECK(lba<256U);memcpy(sectors[lba],p,512);return 0;}
static void reset(void){
 memset(&registers,0,sizeof(registers));memset(&hsd1,0,sizeof(hsd1));hsd1.Instance=SDMMC1;hsd1.State=HAL_SD_STATE_READY;hsd1.SdCard.LogBlockNbr=CARD_CAPACITY;registers.CLKCR=0x1400U;for(unsigned i=0;i<4U;i++)hsd1.CID[i]=0x10203040U+i;
 memset(&np_usb_delete,0,sizeof(np_usb_delete));np_usb_delete_receiving=np_usb_delete_auto_checked=np_usb_delete_auto_running=np_usb_delete_clock_held=np_usb_delete_port_error=np_usb_delete_clock=0U;
 ticks=read_calls=write_calls=status_calls=hal_failed=admission_probes=reinit_calls=np_v1_job_refresh=0U;idle=1U;np_usb_sd_ready=1U;card_state=HAL_SD_CARD_TRANSFER;
 memset(sectors,0,sizeof(sectors));Nps2State s;CHECK(nps2_format(&s,CARD_CAPACITY,UINT64_C(0x1234567887654321),ram_read,ram_write)==NPS2_OK);
 CHECK(nps2_begin(&s,2U*NPS2_ALIGN,101U,ram_read,ram_write)==NPS2_OK);CHECK(nps2_finish(&s,s.start+99U,1,ram_read,ram_write)==NPS2_OK);
}
int main(void){
 uint8_t data[512];reset();CHECK(np_usb_format_read(NULL,115U,data)==0 && hsd1.Context==SD_CONTEXT_NONE && status_calls==1U && !np_usb_delete_owned());
 CHECK(np_usb_delete_service()==0 && np_usb_delete_auto_checked && !np_usb_delete_auto_running && !np_usb_delete_clock_held && !np_usb_delete_port_error && !write_calls && !reinit_calls && np_v1_job_refresh && registers.CLKCR==0x1400U);
 for(unsigned again=0;again<3U;again++){CHECK(np_usb_format_read(NULL,115U,data)==0&&hsd1.Context==SD_CONTEXT_NONE);unsigned read_before=read_calls;CHECK(np_usb_delete_service()==0 && read_calls==read_before && !np_usb_delete_owned());}
 reset();hal_failed=1U;CHECK(np_usb_format_read(NULL,115U,data)!=0 && hsd1.Context==SD_CONTEXT_READ_SINGLE_BLOCK && !status_calls);CHECK(np_usb_delete_service()==0 && !np_usb_delete_auto_checked&&!np_usb_delete_auto_running&&!np_usb_delete_owned()&&!write_calls&&registers.CLKCR==0x1400U);
 reset();card_state=3U;CHECK(np_usb_format_read(NULL,115U,data)!=0&&hsd1.Context==SD_CONTEXT_READ_SINGLE_BLOCK);unsigned read_before=read_calls;CHECK(np_usb_delete_service()==0 && read_calls==read_before&&!np_usb_delete_owned()&&!np_usb_delete_auto_checked);
 for(unsigned why=0U;why<3U;why++){
  reset();if(why==0U)hsd1.Context=SD_CONTEXT_READ_SINGLE_BLOCK;else if(why==1U)hsd1.ErrorCode=1U;else idle=0U;
  CHECK(np_usb_delete_service()==0 && !np_usb_delete_auto_running&&!np_usb_delete_clock_held&&!np_usb_delete_auto_checked&&!np_usb_delete_owned()&&!read_calls&&!write_calls);
 }
 printf("PASS actual cold caller checks%u; successful reader retires context, cold auto once/noWrites, failed admission never owns, no core rerun\n",checks);return 0;
}
