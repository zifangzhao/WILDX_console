from datetime import datetime,timezone
import hashlib,json,re,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent;t=Path('C:/Frank/Code/XE_NP/_artifacts/v1_delete_last_20261105');out=root/'cold2';assert not out.exists()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
delete=t/'usb-source/delete.inc';format_port=t/'usb-source/format.inc'
assert sha(delete)=='8D6D48E48B5B48DB840714FA3732B5D5252790045A17EE0466DE3172888BBBB9'
assert sha(format_port)=='5B537C770096BBD7785B36AA8441BC3D177997180327098461A987D15AB122C5'
def function(text,name):
 m=re.search(r'(?m)^(?:(?:__attribute__\(\(noinline\)\)|__declspec\(noinline\)) )?static [^\n;]*\b'+name+r'\(',text);assert m,name
 start=m.start();at=text.index('{',m.end())+1;depth=1
 while depth:depth+=(text[at]=='{')-(text[at]=='}');at+=1
 return text[start:at].replace('__attribute__((noinline))','__declspec(noinline)')
text=delete.read_text();prior=(root/'retire2/actual_retirement.inc').read_text()
helpers=['np_usb_delete_physical_quiet','np_usb_delete_quiet','np_usb_delete_retire','np_usb_delete_read','np_usb_delete_write','np_usb_delete_clock_begin','np_usb_delete_clock_end']
for name in helpers:assert function(text,name)==function(prior,name),(name,'85-check helper proof cannot be silently reused')
globals_text=text[:text.index('static int np_usb_delete_owned')]
globals_text=re.sub(r' __attribute__\(\(section\("NP_USB_DMA"\),aligned\(32\)\)\)','',globals_text);globals_text=re.sub(r'#include "[^"]*np_store_v2_delete_wire.h"','#include "np_store_v2_delete_wire.h"',globals_text)
names=['np_usb_delete_owned',*helpers,'np_usb_delete_service']
actual=globals_text+'\n\n'+'\n\n'.join(function(text,n) for n in names)+'\n\n'+function(format_port.read_text(),'np_usb_format_read')+'\n'
out.mkdir();(out/'actual_cold.inc').write_text(actual);(out/'fixture.c').write_bytes((root/'cold_fixture.c').read_bytes())
for name in ['np_store_v2.h','np_store_v2_delete.h','np_store_v2_delete_wire.h','np_sd_fast_crc.h']:(out/name).write_bytes((t/'core'/name).read_bytes())
vc='C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat';cmd=f'call "{vc}" >nul && cl /nologo /std:c11 /W4 /WX /TC /O2 /I"{out}" "{out}/fixture.c" /Fo"{out}/fixture.obj" /Fe"{out}/fixture.exe"'
started=datetime.now(timezone.utc).isoformat();watch=time.perf_counter();(out/'command.txt').write_text(cmd+'\n');build=subprocess.run('cmd /d /s /c "'+cmd+'"',cwd=out,capture_output=True,text=True,timeout=60);(out/'compile.log').write_text(build.stdout+build.stderr);assert build.returncode==0,build.stdout+build.stderr
run=subprocess.run([str(out/'fixture.exe')],cwd=out,capture_output=True,text=True,timeout=60);(out/'result.txt').write_text(run.stdout+run.stderr);print(run.stdout+run.stderr,end='');assert run.returncode==0
assert sha(delete)=='8D6D48E48B5B48DB840714FA3732B5D5252790045A17EE0466DE3172888BBBB9' and sha(format_port)=='5B537C770096BBD7785B36AA8441BC3D177997180327098461A987D15AB122C5'
receipt={'status':'PASS','started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),'seconds':time.perf_counter()-watch,'delete_port_sha256':sha(delete),'format_port_sha256':sha(format_port),'actual_functions_sha256':sha(out/'actual_cold.inc'),'reused_retire_proof_sha256':sha(root/'retire2/receipt.json'),'reused_helpers_byte_identical':helpers,'result_sha256':sha(out/'result.txt'),'scope':'Actual metadata-reader and cold foreground service with real store/wire and modeled successful polling HAL residue; no firmware/app build, hardware, broad suite or physical power-loss claim'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('receipt',out/'receipt.json',sha(out/'receipt.json'))
