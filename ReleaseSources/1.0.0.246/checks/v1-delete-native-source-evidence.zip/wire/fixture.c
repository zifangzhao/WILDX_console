#include "np_store_v2.h"
#include "card_fixture.inc"
#include "np_store_v2_delete_wire.h"
static Nps2DeleteWire wire;
static Nps2DeleteCard identity;
static unsigned atomic_publish,publishes,io_calls,cancel_publish,cancel_after_write;
static void sealed(const uint32_t p[32]){CHECK(p[0]==NPS2_DELETE_WIRE_MAGIC && p[31]==nps2_crc((const uint8_t *)p,124U));}
static void publish(uint32_t *to,const uint32_t *from){
 CHECK(!atomic_publish);atomic_publish=1U;sealed(from);memcpy(to,from,128);sealed(to);atomic_publish=0U;publishes++;
 if(cancel_publish && from[3]==2U){cancel_publish=0U;nps2_delete_wire_cancel(&wire);}
}
static void io_probe(void){CHECK(!atomic_publish && wire.running && !wire.queued);sealed(wire.report);CHECK(wire.report[3]==2U);io_calls++;}
static int wire_read(uint32_t lba,uint8_t *b){io_probe();return card_read(lba,b);}
static int wire_write(uint32_t lba,const uint8_t *b){io_probe();int result=card_write(lba,b);if(cancel_after_write && writes==cancel_after_write){cancel_after_write=0U;nps2_delete_wire_cancel(&wire);}return result;}
static void setup(unsigned count){
 Nps2State s;setup_records(&s,count,0);memset(&wire,0,sizeof(wire));memset(&identity,0,sizeof(identity));
 identity.uid[0]=0x12345678U;identity.uid[1]=0x87654321U;identity.uid[2]=0xabcdef01U;
 for(unsigned i=0;i<4U;i++)identity.cid[i]=0x10325476U+i;
 identity.capacity=CARD_CAPACITY;identity.epoch=12U;identity.clock_hz=160000000U;
 atomic_publish=publishes=io_calls=cancel_publish=cancel_after_write=0U;io_reset();nps2_delete_wire_init(&wire,&identity);sealed(wire.report);CHECK(!reads&&!writes);
}
static void inspect(void){
 CHECK(nps2_delete_wire_inspect_submit(&wire,1U,&identity));CHECK(wire.queued==1U && !wire.running && !reads&&!writes);sealed(wire.report);
 CHECK(nps2_delete_wire_service(&wire,&identity,wire_read,wire_write,publish));sealed(wire.report);CHECK(wire.report[3]==3U && !wire.report[5] && !wire.queued&&!wire.running&&!writes && publishes==2U);
 CHECK(!memcmp(wire.confirmed,wire.report,128));
}
static void request(uint32_t p[32]){memcpy(p,wire.confirmed,128);p[2]=2U;p[4]=wire.last_nonce+1U;p[24]=wire.last_nonce;nps2_delete_wire_seal(p);}
static void guard_cases(void){
 uint32_t p[32],saved[32];setup(3U);
 CHECK(!nps2_delete_wire_inspect_submit(&wire,0U,&identity));CHECK(!nps2_delete_wire_inspect_submit(&wire,2U,&identity));CHECK(!reads&&!writes);
 CHECK(nps2_delete_wire_inspect_submit(&wire,1U,&identity));memcpy(saved,wire.report,128);
 CHECK(!nps2_delete_wire_inspect_submit(&wire,2U,&identity));CHECK(!memcmp(saved,wire.report,128));
 wire.running=1U;CHECK(!nps2_delete_wire_inspect_submit(&wire,2U,&identity));wire.running=0U;
 CHECK(nps2_delete_wire_service(&wire,&identity,wire_read,wire_write,publish));request(p);Nps2DeleteWire confirmed=wire;
 for(unsigned byte=0U;byte<128U;byte++){
  wire=confirmed;uint32_t bad[32];memcpy(bad,p,128);((uint8_t *)bad)[byte]^=1U;if(byte<124U)nps2_delete_wire_seal(bad);
  CHECK(!nps2_delete_wire_confirm_submit(&wire,(const uint8_t *)bad,&identity));CHECK(!memcmp(&wire,&confirmed,sizeof(wire)));
 }
 for(unsigned field=0U;field<4U;field++){
  wire=confirmed;Nps2DeleteCard other=identity;
  if(field==0U)other.uid[0]^=1U;else if(field==1U)other.cid[0]^=1U;else if(field==2U)other.capacity++;else other.epoch++;
  CHECK(!nps2_delete_wire_confirm_submit(&wire,(const uint8_t *)p,&other));CHECK(!memcmp(&wire,&confirmed,sizeof(wire)));
 }
 wire=confirmed;wire.running=1U;CHECK(!nps2_delete_wire_confirm_submit(&wire,(const uint8_t *)p,&identity));
 wire=confirmed;wire.queued=1U;CHECK(!nps2_delete_wire_confirm_submit(&wire,(const uint8_t *)p,&identity));
 wire=confirmed;wire.last_nonce=UINT32_MAX;CHECK(!nps2_delete_wire_confirm_submit(&wire,(const uint8_t *)p,&identity));CHECK(!nps2_delete_wire_inspect_submit(&wire,0U,&identity));
}
static void normal_case(void){
 uint32_t p[32];setup(3U);inspect();CHECK(wire.report[7]==3U && wire.report[9]==3U);request(p);io_reset();publishes=io_calls=0U;
 CHECK(nps2_delete_wire_confirm_submit(&wire,(const uint8_t *)p,&identity));sealed(wire.report);CHECK(wire.queued==2U && !reads&&!writes);
 CHECK(nps2_delete_wire_service(&wire,&identity,wire_read,wire_write,publish));sealed(wire.report);CHECK(wire.report[3]==3U && !wire.report[5] && wire.report[7]==1U && wire.report[9]==2U && wire.report[10]==3U*NPS2_ALIGN && writes==6U && publishes==2U);
 CHECK(!wire.running&&!wire.queued&&!wire.confirmed[0]);preserved_prefix(3U);
 unsigned completed_io=io_calls;CHECK(!nps2_delete_wire_service(&wire,&identity,wire_read,wire_write,publish) && io_calls==completed_io);
 CHECK(!nps2_delete_wire_confirm_submit(&wire,(const uint8_t *)p,&identity));
}
static void cancel_failure_cases(void){
 uint32_t p[32];setup(3U);CHECK(nps2_delete_wire_inspect_submit(&wire,1U,&identity));nps2_delete_wire_cancel(&wire);sealed(wire.report);CHECK(wire.report[3]==4U && wire.report[5]==0xE2D00002U && !nps2_delete_wire_service(&wire,&identity,wire_read,wire_write,publish)&&!reads&&!writes);
 setup(3U);CHECK(nps2_delete_wire_inspect_submit(&wire,1U,&identity));cancel_publish=1U;CHECK(nps2_delete_wire_service(&wire,&identity,wire_read,wire_write,publish));CHECK(wire.report[3]==4U && !reads&&!writes&&!wire.confirmed[0]);sealed(wire.report);
 setup(3U);CHECK(nps2_delete_wire_inspect_submit(&wire,1U,&identity));identity.uid[0]^=1U;CHECK(nps2_delete_wire_service(&wire,&identity,wire_read,wire_write,publish));CHECK(wire.report[3]==4U && !reads&&!writes&&!wire.confirmed[0]);sealed(wire.report);
 for(unsigned failure=0U;failure<2U;failure++){
  setup(3U);inspect();request(p);CHECK(nps2_delete_wire_confirm_submit(&wire,(const uint8_t *)p,&identity));io_reset();
  if(!failure)cancel_after_write=1U;else corrupt_at=3U;
  CHECK(nps2_delete_wire_service(&wire,&identity,wire_read,wire_write,publish));sealed(wire.report);CHECK(wire.report[3]==4U && wire.report[5] && !wire.running&&!wire.queued&&!wire.confirmed[0]);preserved_prefix(3U);
  unsigned completed=io_calls;CHECK(!nps2_delete_wire_service(&wire,&identity,wire_read,wire_write,publish)&&io_calls==completed);CHECK(!nps2_delete_wire_confirm_submit(&wire,(const uint8_t *)p,&identity));
  Nps2State recovered;io_reset();CHECK(nps2_delete_recover(&recovered,CARD_CAPACITY,(const uint8_t *)identity.cid,card_read,card_write)==NPS2_OK && recovered.count==2U);preserved_prefix(3U);
 }
}
static void profile_cases(void){
 uint32_t p[32];setup(0U);inspect();CHECK(wire.report[7]==1U && !wire.report[9] && !wire.report[13]);request(p);CHECK(!nps2_delete_wire_confirm_submit(&wire,(const uint8_t *)p,&identity));
 for(unsigned state=1U;state<=3U;state++){
  setup(2U);Nps2State s;metadata_only=0U;io_reset();CHECK(nps2_mount_raw(&s,CARD_CAPACITY,card_read)==NPS2_OK);CHECK(nps2_begin(&s,s.frontier+NPS2_ALIGN,401U,card_read,card_write)==NPS2_OK);
  if(state!=NPS2_RECORD_OPEN){io_reset();CHECK(nps2_finish(&s,s.start+99U,state==NPS2_RECORD_COMPLETE,card_read,card_write)==NPS2_OK);}
  save_card();metadata_only=1U;io_reset();inspect();CHECK(wire.report[7]==(3U|(state==NPS2_RECORD_OPEN?4U:state==NPS2_RECORD_FAILED?8U:0U)));
 }
 setup(3U);card[132][400]^=1U;card[133][400]^=1U;CHECK(nps2_delete_wire_inspect_submit(&wire,1U,&identity));CHECK(nps2_delete_wire_service(&wire,&identity,wire_read,wire_write,publish));sealed(wire.report);CHECK(wire.report[3]==4U && wire.report[5] && !wire.confirmed[0] && !writes);request(p);CHECK(!nps2_delete_wire_confirm_submit(&wire,(const uint8_t *)p,&identity));
}
static void stale_grant_wire(void){
 setup(2U);Nps2State s;metadata_only=0U;io_reset();CHECK(nps2_mount_raw(&s,CARD_CAPACITY,card_read)==NPS2_OK);CHECK(nps2_begin(&s,s.frontier+NPS2_ALIGN,402U,card_read,card_write)==NPS2_OK);io_reset();cut_at=2U;cut_prefix=512U;
 if(!setjmp(power_lost)){(void)nps2_extend(&s,s.frontier+NPS2_ALIGN,card_read,card_write);CHECK(0);}
 metadata_only=1U;save_card();io_reset();inspect();CHECK(wire.report[7]==7U && wire.report[13]==5U*NPS2_ALIGN && wire.report[10]==5U*NPS2_ALIGN);
 uint32_t p[32];request(p);CHECK(nps2_delete_wire_confirm_submit(&wire,(const uint8_t *)p,&identity));CHECK(nps2_delete_wire_service(&wire,&identity,wire_read,wire_write,publish));CHECK(wire.report[3]==3U && wire.report[9]==2U && wire.report[10]==3U*NPS2_ALIGN);preserved_prefix(3U);
}
int main(void){guard_cases();normal_case();cancel_failure_cases();profile_cases();stale_grant_wire();printf("PASS actual wire engine checks%u; queued/running/128byteCAS/identity/nonce/OPEN_FAILED/cancel/failure/noReplay; no hardware\n",checks);return 0;}
