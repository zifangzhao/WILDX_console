from datetime import datetime, timezone
import hashlib, json
from pathlib import Path
import subprocess, time
root=Path(__file__).resolve().parent
source=Path('C:/Frank/Code/XE_NP/_artifacts/v1_delete_last_20261105/core')
out=root/'wire3'
assert not out.exists(), 'Preserve prior wire proof; use explicit fresh output after any actual change'
pins={'np_store_v2.h':'703A07BFBA2A2D6BE766266D53885B2F18E78943BBF263304E99F5FFC7B225DA','np_store_v2_delete.h':'DF05B9DCBDAAB476B7B12D1B85E3076F4E3121DEBA885A175BCF719B98CEBA71','np_store_v2_delete_wire.h':'507BCC48738E08DB772F03A1311C4E1E362DE64C487D3E467711EF91523A0D18'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
for name,digest in pins.items():assert sha(source/name)==digest,(name,'owner pin changed')
out.mkdir()
inputs={**{name:source/name for name in (*pins,'np_sd_fast_crc.h')},'fixture.c':root/'wire_fixture.c','card_fixture.inc':root/'card_fixture.inc'}
for name,path in inputs.items():(out/name).write_bytes(path.read_bytes())
vc='C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat'
command=f'call "{vc}" >nul && cl /nologo /std:c11 /W4 /WX /TC /O2 /I"{out}" "{out}/fixture.c" /Fo"{out}/fixture.obj" /Fe"{out}/fixture.exe"'
started=datetime.now(timezone.utc).isoformat();watch=time.perf_counter()
(out/'command.txt').write_text(command+'\n')
build=subprocess.run('cmd /d /s /c "'+command+'"',cwd=out,capture_output=True,text=True,timeout=60)
(out/'compile.log').write_text(build.stdout+build.stderr)
assert build.returncode==0,build.stdout+build.stderr
run=subprocess.run([str(out/'fixture.exe')],cwd=out,capture_output=True,text=True,timeout=60)
(out/'result.txt').write_text(run.stdout+run.stderr);print(run.stdout+run.stderr,end='')
assert run.returncode==0,'Actual wire fixture failed; preserve source/logs'
for name,digest in pins.items():assert sha(source/name)==digest
receipt={'status':'PASS','started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),'seconds':time.perf_counter()-watch,'scope':'Actual frozen wire engine and storage headers with RAM sector I/O; no firmware/app build or hardware','source_inputs':[{'path':name,'source':str(path),'sha256':sha(path)} for name,path in inputs.items()],'result_sha256':sha(out/'result.txt')}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('receipt',out/'receipt.json',sha(out/'receipt.json'))
