"""Compile one RAM-only fixture against the exact frozen V1 storage header."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('--header', type=Path, required=True)
p.add_argument('--sha256', required=True)
p.add_argument('--delete-sha256', required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--api', type=Path, required=True)
p.add_argument('--crc-header', type=Path, default=Path('C:/Frank/Code/XE_NP/Firmware/V1/Core/Inc/np_sd_fast_crc.h'))
a = p.parse_args()
root = Path(__file__).resolve().parent
out = a.output.resolve()
assert not out.exists(), 'Use a fresh output directory and preserve failed evidence'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest().upper()

assert sha(a.header) == a.sha256.upper(), 'Owner header pin changed'
delete_header = a.header.parent/'np_store_v2_delete.h'
assert sha(delete_header) == a.delete_sha256.upper(), 'Owner delete-header pin changed'
inputs = [a.header, delete_header, a.crc_header, a.api, root/'fixture.c', root/'card_fixture.inc', Path(__file__)]
pins = [{'source': str(x.resolve()), 'bytes': x.stat().st_size, 'sha256': sha(x)} for x in inputs]
out.mkdir(parents=True)
for src, name in [(a.header, 'np_store_v2.h'), (delete_header, 'np_store_v2_delete.h'), (a.crc_header, 'np_sd_fast_crc.h'), (a.api, 'actual_api.inc'), (root/'fixture.c', 'fixture.c'), (root/'card_fixture.inc', 'card_fixture.inc')]:
    shutil.copyfile(src, out/name)
vc = Path('C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat')
assert vc.exists(), 'Use the installed checked compiler; do not install another'
command = f'call "{vc}" >nul && cl /nologo /std:c11 /W4 /WX /TC /O2 /I"{out}" "{out}/fixture.c" /Fo"{out}/fixture.obj" /Fe"{out}/fixture.exe"'
(out/'command.txt').write_text(command+'\n', encoding='utf-8')
started = datetime.now(timezone.utc).isoformat()
watch = time.perf_counter()
build = subprocess.run('cmd /d /s /c "'+command+'"', cwd=out, capture_output=True, text=True, timeout=60)
(out/'compile.log').write_text(build.stdout+build.stderr, encoding='utf-8')
assert build.returncode == 0, build.stdout+build.stderr
run = subprocess.run([str(out/'fixture.exe')], cwd=out, capture_output=True, text=True, timeout=120)
(out/'result.txt').write_text(run.stdout+run.stderr, encoding='utf-8')
print(run.stdout+run.stderr, end='')
assert run.returncode == 0, 'Actual-header fixture failed; preserve exact source and logs'
for item in pins:
    assert sha(item['source']) == item['sha256'], 'Fixture input changed during run'
counts = re.search(r'checks(\d+) delete_cuts(\d+) recovery_cuts(\d+) corruptions(\d+) append_cases(\d+)', run.stdout)
assert counts, 'Explicit case summary missing'
receipt = {'status': 'PASS', 'started_utc': started, 'finished_utc': datetime.now(timezone.utc).isoformat(), 'seconds': time.perf_counter()-watch,
           'scope': 'Actual frozen storage header with sector persistence/power-cut callbacks; no firmware/app build, hardware, SD controller atomicity or physical power-cut claim',
           'checks': dict(zip(['checks', 'delete_cuts', 'recovery_cuts', 'corruptions', 'append_cases'], map(int, counts.groups()))),
           'source_inputs': pins, 'result_sha256': sha(out/'result.txt'), 'command_sha256': sha(out/'command.txt')}
(out/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
print('receipt', out/'receipt.json', sha(out/'receipt.json'))
