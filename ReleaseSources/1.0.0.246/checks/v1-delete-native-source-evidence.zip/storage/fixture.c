/* Actual frozen header + card fault adapter. actual_api.inc contains only
 * thin calls to the pinned API; no storage algorithm is reimplemented. */
#include "np_store_v2.h"
#include "card_fixture.inc"
#include "actual_api.inc"
static Nps2State before;
static unsigned expected_after_open;
static unsigned delete_cuts,recovery_cuts,corruption_cases,append_cases;
static uint64_t nonce=UINT64_C(0x7a6b5c4d3e2f1908);
static unsigned char intent_seed[2][512];

static void expected_state(const Nps2State *s){
 CHECK(s->ready && !s->live && s->epoch==before.epoch && s->capacity==before.capacity);
 CHECK(s->count==before.count || s->count+1U==before.count);
 if(s->count==before.count)CHECK(s->frontier==before.frontier && s->generation==before.generation && s->start==before.start && s->end==before.end && s->session==before.session);
 else CHECK(s->frontier==before.start && s->generation==before.generation+1U && s->open==expected_after_open);
 preserved_prefix(before.count);
}
static void stable_recovery(Nps2State *s){
 Nps2State settled=*s;unsigned char stable[CARD_META][512];memcpy(stable,card,sizeof(stable));
 for(unsigned repeat=0;repeat<2U;repeat++){
  io_reset();CHECK(actual_recover(s)==NPS2_OK);expected_state(s);
  CHECK(!writes && !memcmp(stable,card,sizeof(stable)) && !memcmp(&settled,s,sizeof(settled)));
 }
}
static void append_after(Nps2State *s){
 uint32_t count=s->count,frontier=s->frontier;metadata_only=0U;io_reset();
 CHECK(nps2_begin(s,frontier+NPS2_ALIGN,901U,card_read,card_write)==NPS2_OK);
 CHECK(s->count==count+1U && s->start==frontier && s->frontier==frontier+NPS2_ALIGN);
 io_reset();CHECK(nps2_finish(s,frontier+200U,1,card_read,card_write)==NPS2_OK);
 Nps2Record record;CHECK(nps2_read_record(s,count,&record,card_read)==NPS2_OK);
 CHECK(record.session==901U && record.index==count && record.start==frontier && record.state==NPS2_RECORD_COMPLETE);
 CHECK(!memcmp(card[NPS2_RECORD_BASE],baseline[NPS2_RECORD_BASE],count*1024U));
 CHECK(!memcmp(payload,saved_payload,sizeof(payload)));append_cases++;metadata_only=1U;
}
static void recover_uncut(void){
 Nps2State recovered;io_reset();CHECK(actual_recover(&recovered)==NPS2_OK);expected_state(&recovered);stable_recovery(&recovered);
}
static unsigned delete_normal(unsigned records,int extended){
 Nps2State s;setup_records(&s,records,extended);before=s;
 CHECK(actual_delete(&s,nonce)==NPS2_OK);CHECK(writes==6U);
 CHECK(written[0]==114U && written[1]==115U && written[2]==NPS2_CHECK0 && written[3]==NPS2_CHECK1 && written[4]==114U && written[5]==115U);
 expected_state(&s);CHECK(s.count+1U==before.count);stable_recovery(&s);append_after(&s);return 6U;
}
static void deletion_matrix(unsigned records,int extended){
 unsigned operations=delete_normal(records,extended);Nps2State s;
 setup_records(&s,records,extended);before=s;
 for(unsigned at=1U;at<=operations;at++)for(unsigned prefix=0U;prefix<=512U;prefix++){
  case_id++;restore_card();s=before;cut_at=at;cut_prefix=prefix;
  if(!setjmp(power_lost)){(void)actual_delete(&s,nonce);CHECK(0);}
  CHECK(cut_happened && writes==at);preserved_prefix(records);delete_cuts++;recover_uncut();
 }
}
static void recovery_matrix(void){
 Nps2State s;static unsigned char seed[CARD_META][512];
 /* Four durable states: both intents; one rewound CP; both new CPs; one clear.
  * Each recovery write gets its own complete0..512 prefix matrix. */
 for(unsigned boundary=2U;boundary<=5U;boundary++){
  setup_records(&s,3U,1);before=s;cut_at=boundary;cut_prefix=512U;
  if(!setjmp(power_lost)){(void)actual_delete(&s,nonce);CHECK(0);}
  memcpy(seed,card,sizeof(seed));io_reset();CHECK(actual_recover(&s)==NPS2_OK);unsigned operations=writes;
  for(unsigned at=1U;at<=operations;at++)for(unsigned prefix=0U;prefix<=512U;prefix++){
   case_id++;memcpy(card,seed,sizeof(seed));io_reset();cut_at=at;cut_prefix=prefix;
   if(!setjmp(power_lost)){(void)actual_recover(&s);CHECK(0);}
   CHECK(cut_happened && writes==at);preserved_prefix(before.count);recovery_cuts++;recover_uncut();
  }
 }
}
static void seed_intent(void){
 Nps2State s;setup_records(&s,3U,1);before=s;cut_at=2U;cut_prefix=512U;
 if(!setjmp(power_lost)){(void)actual_delete(&s,nonce);CHECK(0);}
 memcpy(intent_seed,card[114],sizeof(intent_seed));io_reset();
}
static void refuse_recovery(void){
 Nps2State s;io_reset();CHECK(actual_recover(&s)!=NPS2_OK);CHECK(!writes);preserved_prefix(before.count);corruption_cases++;
}
static void invalid_intents(void){
 seed_intent();
 for(unsigned which=0U;which<2U;which++){
  for(unsigned byte=0U;byte<512U;byte++){
   case_id++;restore_card();memcpy(card[114],intent_seed,sizeof(intent_seed));card[114U+which][byte]^=1U;
   recover_uncut();corruption_cases++;
  }
 }
 /* Valid CRC but foreign card identity/epoch/capacity, noncanonical compact
  * checkpoint/record preimages, zero nonce and reserved extension bytes. */
 static const unsigned changed[]={16U,40U,120U,152U,216U,224U,232U,236U};
 for(unsigned i=0U;i<sizeof(changed)/sizeof(changed[0]);i++){
  restore_card();memcpy(card[114],intent_seed,sizeof(intent_seed));card[114][changed[i]]^=0x80U;nps2_seal(card[114]);memcpy(card[115],card[114],512);refuse_recovery();
 }
 restore_card();memcpy(card[114],intent_seed,sizeof(intent_seed));memset(card[114]+32,0,8);nps2_seal(card[114]);memcpy(card[115],card[114],512);refuse_recovery();
 restore_card();memcpy(card[114],intent_seed,sizeof(intent_seed));card[115][32]^=1U;nps2_seal(card[115]);refuse_recovery();
 /* A valid old intent must never delete a newer appended session. */
 restore_card();memcpy(card[114],intent_seed,sizeof(intent_seed));Nps2State s;CHECK(actual_recover(&s)==NPS2_OK);append_after(&s);
 memcpy(card[114],intent_seed,sizeof(intent_seed));io_reset();CHECK(actual_recover(&s)!=NPS2_OK && !writes);corruption_cases++;
}
static void io_failures(void){
 Nps2State s;setup_records(&s,3U,1);before=s;
 for(unsigned at=1U;at<=6U;at++){
  restore_card();s=before;corrupt_at=at;CHECK(actual_delete(&s,nonce)!=NPS2_OK);recover_uncut();corruption_cases++;
  restore_card();s=before;verify_fail_at=at;CHECK(actual_delete(&s,nonce)!=NPS2_OK);recover_uncut();corruption_cases++;
 }
 restore_card();s=before;CHECK(actual_delete(&s,0U)!=NPS2_OK && !writes);
}
static void incomplete_and_refusal(void){
 Nps2State s;Nps2Delete d;
 for(unsigned kind=0U;kind<3U;kind++){
  setup_records(&s,kind==2U?1U:2U,0);metadata_only=0U;io_reset();
  CHECK(nps2_begin(&s,s.frontier+NPS2_ALIGN,701U,card_read,card_write)==NPS2_OK);
  if(kind==1U){io_reset();CHECK(nps2_finish(&s,s.start+99U,0,card_read,card_write)==NPS2_OK);}
  else if(kind==2U){
   io_reset();CHECK(nps2_mount_raw(&s,CARD_CAPACITY,card_read)==NPS2_OK && s.open && !s.live);
   io_reset();CHECK(nps2_begin(&s,s.frontier+NPS2_ALIGN,702U,card_read,card_write)==NPS2_OK);
   io_reset();CHECK(nps2_finish(&s,s.start+99U,1,card_read,card_write)==NPS2_OK);
  }
  io_reset();CHECK(nps2_mount_raw(&s,CARD_CAPACITY,card_read)==NPS2_OK);before=s;expected_after_open=kind==2U;save_card();metadata_only=1U;
  CHECK(nps2_delete_inspect(&d,CARD_CAPACITY,fixture_cid,card_read)==NPS2_OK && !writes);
  CHECK(d.flags==(kind==0U?NPS2_DELETE_FLAG_OPEN:kind==1U?NPS2_DELETE_FLAG_FAILED:0U));
  io_reset();CHECK(actual_delete(&s,nonce)==NPS2_OK);expected_state(&s);CHECK(s.count+1U==before.count);stable_recovery(&s);append_after(&s);
 }
 expected_after_open=0U;
 setup_records(&s,3U,0);before=s;
 for(unsigned index=1U;index<3U;index++){
  restore_card();card[NPS2_RECORD_BASE+index*2U][400]^=1U;card[NPS2_RECORD_BASE+index*2U+1U][400]^=1U;
  CHECK(actual_delete(&s,nonce)!=NPS2_OK && !writes);
  io_reset();CHECK(actual_recover(&s)==NPS2_OK && s.count==before.count && s.frontier==before.frontier && !writes);
 }
 setup_records(&s,3U,0);before=s;
 CHECK(nps2_delete_inspect(&d,CARD_CAPACITY,fixture_cid,card_read)==NPS2_OK);d.nonce=1234U;
 metadata_only=0U;io_reset();CHECK(nps2_begin(&s,s.frontier+NPS2_ALIGN,801U,card_read,card_write)==NPS2_OK);io_reset();CHECK(nps2_finish(&s,s.start+77U,1,card_read,card_write)==NPS2_OK);
 metadata_only=1U;io_reset();CHECK(nps2_delete_confirmed(&s,&d,nonce,CARD_CAPACITY,fixture_cid,card_read,card_write)!=NPS2_OK && !writes);
 seed_intent();io_reset();CHECK(nps2_mount_raw(&s,CARD_CAPACITY,card_read)==NPS2_OK);io_reset();CHECK(nps2_begin(&s,s.frontier+NPS2_ALIGN,802U,card_read,card_write)!=NPS2_OK && !writes);
 /* Every metadata read boundary: an unavailable redundant copy may fall back,
  * but no failure can grant new space or change unrelated metadata. */
 setup_records(&s,3U,0);before=s;CHECK(actual_delete(&s,nonce)==NPS2_OK);unsigned count_reads=reads;
 for(unsigned at=1U;at<=count_reads;at++){
  restore_card();s=before;read_fail_at=at;(void)actual_delete(&s,nonce);io_reset();CHECK(actual_recover(&s)==NPS2_OK);expected_state(&s);corruption_cases++;
 }
 setup_records(&s,0U,0);io_reset();CHECK(actual_delete(&s,nonce)!=NPS2_OK && !writes);
}
static void metadata_vectors(void){
 static const uint32_t sectors[]={16U,24U,112U,113U,114U,115U,128U,129U,130U,131U,132U,133U};
 FILE *f=NULL;CHECK(!fopen_s(&f,"metadata-vectors.bin","wb") && f);
 uint32_t value=1U;CHECK(fwrite("NPS2CUT1",8,1,f)==1);CHECK(fwrite(&value,4,1,f)==1);
 value=CARD_CAPACITY;CHECK(fwrite(&value,4,1,f)==1);value=7U;CHECK(fwrite(&value,4,1,f)==1);value=12U;CHECK(fwrite(&value,4,1,f)==1);
 Nps2State s;setup_records(&s,3U,1);before=s;
 for(unsigned boundary=0U;boundary<=6U;boundary++){
  restore_card();s=before;
  if(boundary){cut_at=boundary;cut_prefix=512U;if(!setjmp(power_lost)){(void)actual_delete(&s,nonce);CHECK(0);}}
  io_reset();Nps2Delete inspected;CHECK(nps2_delete_inspect(&inspected,CARD_CAPACITY,fixture_cid,card_read)==NPS2_OK && !writes);
  printf("VECTOR %u pending%u needs_clear%u count%u frontier%u generation%llu\n",boundary,inspected.pending,inspected.needs_clear,inspected.state.count,inspected.state.frontier,(unsigned long long)inspected.state.generation);
  value=boundary;CHECK(fwrite(&value,4,1,f)==1);
  for(unsigned i=0U;i<12U;i++){CHECK(fwrite(&sectors[i],4,1,f)==1);CHECK(fwrite(card[sectors[i]],512,1,f)==1);}
 }
 CHECK(!fclose(f));
}
static void stale_grant_case(void){
 Nps2State s;Nps2Delete inspected;setup_records(&s,2U,0);metadata_only=0U;io_reset();
 CHECK(nps2_begin(&s,s.frontier+NPS2_ALIGN,601U,card_read,card_write)==NPS2_OK);io_reset();cut_at=2U;cut_prefix=512U;
 /* Actual extend: both enlarged CPs are durable; descriptor update never runs. */
 if(!setjmp(power_lost)){(void)nps2_extend(&s,s.frontier+NPS2_ALIGN,card_read,card_write);CHECK(0);}
 io_reset();CHECK(nps2_mount_raw(&s,CARD_CAPACITY,card_read)==NPS2_OK);CHECK(s.open&&!s.live);before=s;save_card();metadata_only=1U;
 CHECK(nps2_delete_inspect(&inspected,CARD_CAPACITY,fixture_cid,card_read)==NPS2_OK && inspected.last.reserved_end<inspected.state.frontier && inspected.flags==NPS2_DELETE_FLAG_OPEN);
 io_reset();CHECK(actual_delete(&s,nonce)==NPS2_OK);expected_state(&s);CHECK(s.count+1U==before.count);stable_recovery(&s);
 restore_card();s=before;cut_at=3U;cut_prefix=512U;
 if(!setjmp(power_lost)){(void)actual_delete(&s,nonce);CHECK(0);}
 io_reset();CHECK(nps2_delete_inspect(&inspected,CARD_CAPACITY,fixture_cid,card_read)==NPS2_OK && inspected.pending && inspected.state.count==2U && inspected.state.frontier==3U*NPS2_ALIGN);
 FILE *f=NULL;CHECK(!fopen_s(&f,"stale-grant-vector.bin","wb") && f);
 static const uint32_t sectors[]={16U,24U,112U,113U,114U,115U,128U,129U,130U,131U,132U,133U};
 uint32_t value=1U;CHECK(fwrite("NPS2CUT1",8,1,f)==1);CHECK(fwrite(&value,4,1,f)==1);value=CARD_CAPACITY;CHECK(fwrite(&value,4,1,f)==1);value=1U;CHECK(fwrite(&value,4,1,f)==1);value=12U;CHECK(fwrite(&value,4,1,f)==1);value=0U;CHECK(fwrite(&value,4,1,f)==1);
 for(unsigned i=0U;i<12U;i++){CHECK(fwrite(&sectors[i],4,1,f)==1);CHECK(fwrite(card[sectors[i]],512,1,f)==1);}CHECK(!fclose(f));
 recover_uncut();printf("STALE_GRANT pending1 count%u frontier%u generation%llu descriptor_end%u authoritative_end%u\n",inspected.state.count,inspected.state.frontier,(unsigned long long)inspected.state.generation,inspected.last.reserved_end,before.frontier);
}
int main(void){
 deletion_matrix(1U,0);deletion_matrix(3U,1);recovery_matrix();invalid_intents();io_failures();incomplete_and_refusal();stale_grant_case();metadata_vectors();
 printf("PASS actual-header delete/recovery checks%u delete_cuts%u recovery_cuts%u corruptions%u append_cases%u; metadata-only/no hardware\n",checks,delete_cuts,recovery_cuts,corruption_cases,append_cases);
 return 0;
}
