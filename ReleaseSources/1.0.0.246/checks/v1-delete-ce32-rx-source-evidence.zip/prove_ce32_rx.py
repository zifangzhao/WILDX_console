from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,subprocess,time
root=Path(__file__).resolve().parent;stage=root/'ce32-rx';out=stage/'native3';assert not out.exists();out.mkdir()
src=stage/'CE32_UART_INTERCOM.c';old=stage/'CE32_UART_INTERCOM.preimage.c';queue=Path('C:/Frank/Code/XE_NP/Firmware/V1/Core/Src/CE32_COMMAND.c');inc=Path('C:/Frank/Code/XE_NP/Firmware/V1/Core/Inc')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
assert sha(src)=='38107F899C4079A5251C705C9F3ADD436092FCF9F3D9EBCD03E313D0A265EFD0'
def function(text,name):
 m=re.search(r'(?m)^(?:static )?(?:int|void|uint8_t|uint32_t) '+name+r'\(',text);assert m,name
 start=m.start();at=text.index('{',m.end())+1;depth=1
 while depth:depth+=(text[at]=='{')-(text[at]=='}');at+=1
 return text[start:at]
text=src.read_text();pre=old.read_text();length=function(text[text.index('#else\nint CE32_INTERCOM_Incoming_CMD_Len'):],'CE32_INTERCOM_Incoming_CMD_Len');prior_length=function(pre[pre.index('#else\nint CE32_INTERCOM_Incoming_CMD_Len'):],'CE32_INTERCOM_Incoming_CMD_Len')
q=queue.read_text();names=['CE32_COMMAND_EnterCritical','CE32_COMMAND_ExitCritical','CE32_COMMAND_Init','CE32_COMMAND_Enqueue_Allocate','CE32_COMMAND_Enqueue_Byte','CE32_COMMAND_Enqueue_BytesLeft','CE32_COMMAND_Enqueue_Byte_Abort','CE32_COMMAND_EnqueueCmd_buffered','CE32_COMMAND_DequeueCmd']
(out/'actual_queue.inc').write_text('\n\n'.join(function(q,n) for n in names)+'\n')
types=(inc/'CE32_COMMAND.h').read_text();types=types[types.index('#define CMD_SEQ'):types.index('void CE32_COMMAND_SetRtcHandle')];types+='\n'+(inc/'CE32_COMMAND.h').read_text().split('#define CMD_ADD_CHK',1)[1].split('\n',1)[0].join(['#define CMD_ADD_CHK',''])+'\n'
handle=(inc/'CE32_UART_INTERCOM.h').read_text();handle=handle[handle.index('typedef struct'):handle.index('typedef struct',handle.index('} CE32_INTERCOM_Handle;'))];(out/'actual_types.inc').write_text(types+'\n'+handle)
parts=['static XE_NP_BleRescue v1_ble_rescue;static uint8_t v1_ble_rescue_a7_long;static uint32_t ce32_a7_rx_ms;',length,prior_length.replace('CE32_INTERCOM_Incoming_CMD_Len','Legacy_Incoming_CMD_Len')]
for n in ['NP_BleUartRescueByte','CE32_INTERCOM_RX_Enqueue_Byte','CE32_INTERCOM_RX_EnqueueCmd','CE32_INTERCOM_A7Abort','CE32_INTERCOM_A7Timeout','CE32_INTERCOM_A7Length','CE32_INTERCOM_RX_Feed','CE32_INTERCOM_RX_ProcBuffer']:parts.append(function(text,n))
parts.append(function(pre,'CE32_INTERCOM_RX_Feed').replace('CE32_INTERCOM_RX_Feed','Legacy_RX_Feed').replace('CE32_INTERCOM_Incoming_CMD_Len','Legacy_Incoming_CMD_Len'))
(out/'actual_rx.inc').write_text('\n\n'.join(parts)+'\n');(out/'fixture.c').write_bytes((root/'ce32_rx_fixture.c').read_bytes());(out/'xe_np_ble_rescue.h').write_bytes((inc/'xe_np_ble_rescue.h').read_bytes())
vc='C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat';cmd=f'call "{vc}" >nul && cl /nologo /std:c11 /W4 /WX /TC /O2 /J /I"{out}" "{out}/fixture.c" /Fo"{out}/fixture.obj" /Fe"{out}/fixture.exe"'
started=datetime.now(timezone.utc).isoformat();watch=time.perf_counter();(out/'command.txt').write_text(cmd+'\n');build=subprocess.run('cmd /d /s /c "'+cmd+'"',cwd=out,capture_output=True,text=True,timeout=60);(out/'compile.log').write_text(build.stdout+build.stderr);assert build.returncode==0,build.stdout+build.stderr
run=subprocess.run([str(out/'fixture.exe')],cwd=out,capture_output=True,text=True,timeout=60);(out/'result.txt').write_text(run.stdout+run.stderr);print(run.stdout+run.stderr,end='');assert run.returncode==0
receipt={'status':'PASS','started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),'seconds':time.perf_counter()-watch,'source_sha256':sha(src),'preimage_sha256':sha(old),'queue_source_sha256':sha(queue),'actual_rx_sha256':sha(out/'actual_rx.inc'),'actual_queue_sha256':sha(out/'actual_queue.inc'),'result_sha256':sha(out/'result.txt'),'scope':'Actual CE32 length/rescue/feed/buffered parser and actual queue functions; modeled UART/clock and unused legacy size types; no firmware/app build, hardware or ABI-size claim'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('receipt',out/'receipt.json',sha(out/'receipt.json'))
