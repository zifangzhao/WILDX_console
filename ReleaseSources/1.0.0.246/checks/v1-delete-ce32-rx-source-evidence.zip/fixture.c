#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "xe_np_ble_rescue.h"
#pragma warning(disable:4459) /* Mock globals vs actual parser/queue locals. */
#define MAX_NCH_GROUP 16U
static unsigned checks,frames[2],reset_requests,resets;
static uint8_t last[2][1024];static uint32_t last_len[2],now;
#define CHECK(x) do{checks++;if(!(x)){fprintf(stderr,"FAIL line%d %s\n",__LINE__,#x);exit(1);}}while(0)
#define __IO volatile
typedef struct {uint32_t Seconds,SubSeconds;} CE32_SyncTypeDef;
typedef struct {uint8_t bytes[16];} CE32_StimControl;
typedef struct {uint8_t bytes[4];} RTC_DateTypeDef;
typedef struct {uint8_t bytes[20];} RTC_TimeTypeDef;
typedef struct {unsigned unused;} RTC_HandleTypeDef;
typedef struct {unsigned unused;} USART_TypeDef;
typedef struct {unsigned unused;} UART_HandleTypeDef;
static USART_TypeDef uart1;
#define USART1 (&uart1)
typedef struct {uint8_t bytes[2048];unsigned at,end;} dataMGR;
static int dataMGR_deQueue_byte_safe(dataMGR *m,int unused,char *byte){(void)unused;if(m->at==m->end)return -1;*byte=(char)m->bytes[m->at++];return 0;}
#include "actual_types.inc"
#define INTERCOM_STATE_RECIVING 0x0200U
#define INTERCOM_RX_IS_ON(h) (((h)->state&INTERCOM_STATE_RECIVING)!=0U)
#define INTERCOM_STATE_START_RX_RECEIVE(h) ((h)->state|=INTERCOM_STATE_RECIVING)
#define INTERCOM_STATE_END_RX_RECEIVE(h) ((h)->state&=~INTERCOM_STATE_RECIVING)
#define INTERCOM_PKG_HEAD 0x3cU
#define INTERCOM_PKG_TAIL 0x3eU
static uint32_t primask;
static uint32_t __get_PRIMASK(void){return primask;}
static void __disable_irq(void){primask=1U;}
static void __set_PRIMASK(uint32_t p){primask=p;}
#define __DMB() ((void)0)
static uint32_t HAL_GetTick(void){return now;}
static void CE32_RTC_GetTime(RTC_HandleTypeDef *r,CE32_SyncTypeDef *s){(void)r;memset(s,0,sizeof(*s));}
static RTC_HandleTypeDef *ce32_command_rtc;
static void CE32_INTERCOM_RX_Byte_Act(CE32_INTERCOM_Handle *h,uint8_t b){(void)h;(void)b;}
static void CE32_INTERCOM_RX_FrameComplete_Act(CE32_INTERCOM_Handle *h,const uint8_t *b,uint32_t n){CHECK(h->id>=0&&h->id<2&&n<=1024U);memcpy(last[h->id],b,n);last_len[h->id]=n;frames[h->id]++;}
static void NP_SD_BleOnlineRxAt(const uint8_t *p,uint32_t n,uint32_t t){(void)p;(void)n;(void)t;}
static void NP_SD_BleOnlineRx(const uint8_t *p,uint32_t n){(void)p;(void)n;}
static void XE_NP_Boot_RequestUsbUpdate(void){reset_requests++;}
static void NVIC_SystemReset(void){resets++;}
#include "actual_queue.inc"
#include "actual_rx.inc"
static void init(CE32_INTERCOM_Handle *h,int id){memset(h,0,sizeof(*h));h->id=id;h->UART=USART1;CHECK(!CE32_COMMAND_Init(&h->CMD_RX));frames[id]=last_len[id]=0U;memset(&v1_ble_rescue,0,sizeof(v1_ble_rescue));v1_ble_rescue_a7_long=0U;ce32_a7_rx_ms=0U;reset_requests=resets=0U;now=1U;}
static void byte(CE32_INTERCOM_Handle *h,uint8_t b){NP_BleUartRescueByte(b,now);(void)CE32_INTERCOM_RX_Feed(h,b,now++);}
static void bytes(CE32_INTERCOM_Handle *h,const uint8_t *p,unsigned n){for(unsigned i=0;i<n;i++)byte(h,p[i]);}
static void take(CE32_INTERCOM_Handle *h,const uint8_t *expected,uint32_t n){uint8_t *p=NULL;uint32_t len=0;CHECK(!CE32_COMMAND_DequeueCmd(&h->CMD_RX,&p,&len));CHECK(len==n&&!memcmp(p,expected,n));}
static unsigned frame(uint8_t *p,const uint8_t *body,unsigned n){p[0]=0x3cU;p[1]=0xA7U;memcpy(p+2,body,n);p[n+2]=0x3eU;return n+3U;}
static void valid_cases(void){
 CE32_INTERCOM_Handle h;uint8_t body[128]={0},p[132];
 for(unsigned op=0;op<2;op++){init(&h,0);body[0]=(uint8_t)op;memset(body+1,0,7);body[4]=0x3c;body[5]=0xab;body[6]=0xba;body[7]=0x3e;unsigned n=frame(p,body,8);bytes(&h,p,n);CHECK(frames[0]==1U&&last_len[0]==9U&&!resets);take(&h,p+1,9);CHECK(h.CMD_RX.free_buffer==CMD_BUFSIZE);}
 init(&h,0);memset(body,0x55,sizeof(body));memcpy(body,"NDU1",4);body[120]=0x4eU;for(unsigned at=12U;at<112U;at+=33U){body[at]=0x3c;body[at+1]=0xab;body[at+2]=0xba;body[at+3]=0x3e;}
 unsigned n=frame(p,body,128);bytes(&h,p,n);CHECK(frames[0]==1U&&last_len[0]==129U&&!resets);take(&h,p+1,129);CHECK(h.CMD_RX.free_buffer==CMD_BUFSIZE);
 uint8_t rescue[]={0x3c,0xab,0xba,0x3e};bytes(&h,rescue,sizeof(rescue));CHECK(resets==1U&&reset_requests==1U);
 init(&h,0);h.CMD_RX.cmd_ptr_in=CMD_BUFSIZE-20U;bytes(&h,p,n);take(&h,p+1,129);CHECK(h.CMD_RX.free_buffer==CMD_BUFSIZE);
 init(&h,0);h.CMD_RX.free_buffer=128U;bytes(&h,p,n);CHECK((!frames[0]||last[0][0]!=0xA7U)&&!resets); /* Existing parser may rescan after allocation refusal. */
}
static void malformed_timeout_cases(void){
 CE32_INTERCOM_Handle h;uint8_t body[128],p[132];memset(body,0x55,sizeof(body));memcpy(body,"NDU1",4);unsigned n=frame(p,body,128);uint8_t status[]={0x3c,0x90,0x3e};
 for(unsigned bad=0U;bad<4U;bad++){init(&h,0);uint8_t malformed[132];memcpy(malformed,p,n);malformed[2U+bad]^=1U;bytes(&h,malformed,n);CHECK(!frames[0]);bytes(&h,status,3);CHECK(frames[0]==1U&&last[0][0]==0x90U&&!resets);}
 for(unsigned prefix=2U;prefix<n;prefix++){init(&h,0);bytes(&h,p,prefix);now+=251U;bytes(&h,status,3);CHECK(frames[0]==1U&&last_len[0]==1U&&last[0][0]==0x90U&&!resets);}
 init(&h,0);bytes(&h,p,12);now+=249U;bytes(&h,p+12,n-12);CHECK(frames[0]==1U&&last_len[0]==129U&&!resets);
 init(&h,0);byte(&h,0x3c);now+=251U;bytes(&h,p+1,n-1);CHECK(!frames[0]);bytes(&h,status,3);CHECK(frames[0]==1U&&last[0][0]==0x90U);
}
static void legacy_cases(void){
 CE32_INTERCOM_Handle a,b;uint8_t p[1024];
 for(int op=0;op<256;op++)if(op!=0xA7)CHECK(CE32_INTERCOM_Incoming_CMD_Len(op)==Legacy_Incoming_CMD_Len(op));
 static const uint8_t commands[]={0x30,0x31,0x80,0x82,0x90,0x94,0x95,0x9e,0xab,0xb8};
 for(unsigned k=0;k<sizeof(commands);k++){
  init(&a,0);init(&b,1);int len=Legacy_Incoming_CMD_Len(commands[k]);CHECK(len>0&&len<1022);p[0]=0x3c;p[1]=commands[k];memset(p+2,0x55,(size_t)len-1U);p[len+1]=0x3e;
  for(int at=0;at<len+2;at++){(void)Legacy_RX_Feed(&a,p[at],now);(void)CE32_INTERCOM_RX_Feed(&b,p[at],now++);}
  CHECK(frames[0]==frames[1]&&last_len[0]==last_len[1]&&!memcmp(last[0],last[1],last_len[0]));take(&a,p+1,(uint32_t)len);take(&b,p+1,(uint32_t)len);
 }
}
static void buffered_case(void){
 CE32_INTERCOM_Handle h;uint8_t body[128],p[132];memset(body,0x55,128);memcpy(body,"NDU1",4);unsigned n=frame(p,body,128);init(&h,0);memcpy(h.MGR_RX.bytes,p,n);h.MGR_RX.end=n;CHECK(!CE32_INTERCOM_RX_ProcBuffer(&h));CHECK(frames[0]==1U&&last_len[0]==129U);take(&h,p+1,129);
}
int main(void){valid_cases();malformed_timeout_cases();legacy_cases();buffered_case();printf("PASS actual A7 RX checks%u; short8/long128/prefix/deadline/rescue/queueWrap/legacy/buffered; no hardware\n",checks);return 0;}
