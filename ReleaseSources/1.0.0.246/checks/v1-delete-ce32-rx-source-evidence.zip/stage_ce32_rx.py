from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent;out=root/'ce32-rx';out.mkdir(exist_ok=True)
source=Path('C:/Frank/Code/XE_NP/Firmware/V1/Core/Src/CE32_UART_INTERCOM.c')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
assert sha(source)=='3F3270F24B584C2A0D9CFE8ED76F56CD690EBF742E0509FD28454344B0F0330D'
raw=source.read_bytes();text=raw.decode('utf-8').replace('\r\n','\n');(out/'CE32_UART_INTERCOM.preimage.c').write_bytes(raw)
text=text.replace('static XE_NP_BleRescue v1_ble_rescue;','static XE_NP_BleRescue v1_ble_rescue;\nstatic uint8_t v1_ble_rescue_a7_long;\nstatic uint32_t ce32_a7_rx_ms;')
needle='    if(XE_NP_BleRescue_Feed(&v1_ble_rescue,byte,tick,v1_ble_rescue.at==1U ?'
rescue='''    /* A7 alone has two body lengths. Keep confirmed binary bytes masked from
     * the independent rescue scanner, including literal < AB BA > payload. */
    if(v1_ble_rescue.at==1U)v1_ble_rescue_a7_long=0U;
    if(v1_ble_rescue.at==2U && v1_ble_rescue.command==0xA7U){
        uint32_t left=v1_ble_rescue.remaining;int valid=1;
        if(!v1_ble_rescue_a7_long && left==8U){
            if(byte==0x4eU){v1_ble_rescue_a7_long=1U;v1_ble_rescue.remaining=128U;}
            else if(byte!=0U && byte!=1U)valid=0;
        }else if(v1_ble_rescue_a7_long && left>=125U && left<=127U){
            const uint8_t suffix[3]={0x44U,0x55U,0x31U};valid=byte==suffix[127U-left];
        }else if(!v1_ble_rescue_a7_long && left>=5U && left<=7U)valid=byte==0U;
        if(!valid)v1_ble_rescue.at=0U;
    }
'''
assert text.count(needle)==1;text=text.replace(needle,rescue+needle)
marker='\tcase 0xA0:  //Signaling deep sleep'
assert text.count(marker)==1;text=text.replace(marker,'\tcase 0xA7: // stopped FS2 management: command + GET/inspect body8\n\t\tresp=9;\n\t\tbreak;\n'+marker)
helpers='''/* A7 reserves the maximum in the existing queue, then selects its logical
 * length from the first payload byte. No second packet buffer or queue ABI. */
static void CE32_INTERCOM_A7Abort(CE32_INTERCOM_Handle *comm)
{CE32_COMMAND_Enqueue_Byte_Abort(&comm->CMD_RX);INTERCOM_STATE_END_RX_RECEIVE(comm);}
static void CE32_INTERCOM_A7Timeout(CE32_INTERCOM_Handle *comm,uint32_t now)
{
    CE32_command *q=&comm->CMD_RX;
    if(comm->UART==USART1 && q->stream_in.logging && q->stream_in.idx &&
       q->stream_in.addr[0]==0xA7U && now-ce32_a7_rx_ms>250U)CE32_INTERCOM_A7Abort(comm);
}
static int CE32_INTERCOM_A7Length(CE32_INTERCOM_Handle *comm,uint8_t byte,uint32_t now)
{
    CE32_command *q=&comm->CMD_RX;uint32_t at=q->stream_in.idx;
    if(!q->stream_in.logging || (!at?byte!=0xA7U:q->stream_in.addr[0]!=0xA7U))return 1;
    if(!at){
        if(comm->UART==USART1 && now-ce32_a7_rx_ms>250U){CE32_INTERCOM_A7Abort(comm);return 0;}
        q->stream_in.len=9U;
    }else if(at==1U){
        if(byte==0x4eU)q->stream_in.len=129U;
        else if(byte!=0U && byte!=1U){CE32_INTERCOM_A7Abort(comm);return 0;}
    }else if(at<=4U){
        const uint8_t magic[4]={0x4eU,0x44U,0x55U,0x31U};
        if(byte!=(q->stream_in.addr[1]==0x4eU?magic[at-1U]:0U)){CE32_INTERCOM_A7Abort(comm);return 0;}
    }
    if(comm->UART==USART1)ce32_a7_rx_ms=now;
    return 1;
}

'''
start=text.index('int CE32_INTERCOM_RX_Feed(');text=text[:start]+helpers+text[start:]
def patch_function(text,name,buffered):
 start=text.index('int '+name+'(');brace=text.index('{',start);at=brace+1;depth=1
 while depth:depth+=(text[at]=='{')-(text[at]=='}');at+=1
 body=text[start:at]
 old='CE32_COMMAND_Enqueue_Allocate(handle,CE32_INTERCOM_Incoming_CMD_Len(data_temp),&ptr)'
 assert body.count(old)==1;body=body.replace(old,'CE32_COMMAND_Enqueue_Allocate(handle,data_temp==0xA7U?129:CE32_INTERCOM_Incoming_CMD_Len(data_temp),&ptr)')
 if buffered:
  needle='while(dataMGR_deQueue_byte_safe(&handle_IC->MGR_RX,0,&data_temp)==0)\n\t{'
  assert body.count(needle)==1;body=body.replace(needle,needle+'\n        uint32_t received_ms=HAL_GetTick();\n        CE32_INTERCOM_A7Timeout(handle_IC,received_ms);')
 else:
  needle='CE32_command* handle=&handle_IC->CMD_RX;';assert body.count(needle)==1;body=body.replace(needle,needle+'\n            CE32_INTERCOM_A7Timeout(handle_IC,received_ms);')
 needle='if(CE32_COMMAND_Enqueue_BytesLeft(handle)>0)';assert body.count(needle)==1
 action='continue;' if buffered else 'return -1;'
 body=body.replace(needle,'if(!CE32_INTERCOM_A7Length(handle_IC,data_temp,received_ms)){'+action+'}\n\t\t\t\t'+needle)
 needle='INTERCOM_STATE_START_RX_RECEIVE(handle_IC);';assert body.count(needle)==1;body=body.replace(needle,needle+'\n                    if(handle_IC->UART==USART1)ce32_a7_rx_ms=received_ms;')
 return text[:start]+body+text[at:]
text=patch_function(text,'CE32_INTERCOM_RX_Feed',False);text=patch_function(text,'CE32_INTERCOM_RX_ProcBuffer',True)
target=out/'CE32_UART_INTERCOM.c';target.write_bytes(text.replace('\n','\r\n').encode())
receipt={'status':'SOURCE_STAGED_NATIVE_PENDING','source':str(target),'source_sha256':sha(target),'preimage_sha256':sha(source),'retained_object':'C:/Frank/Code/XE_NP/_artifacts/v1_storage_hardening_20261017/app_r1/ce32_uart_intercom_npconfig.o','retained_object_sha256':'16B59D8860E5B7EF1B31A616E425E5E9B177C5B19C35E4FF3A2D21A67984139D','compile_lineage_receipt':'C:/Frank/Code/XE_NP/_artifacts/v1_storage_hardening_20261017/app_r1/build_receipt.json','scope':'Isolated CE32 A7 RX source only; no canonical edit, firmware build or hardware'}
(out/'source-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
