#include "np_store_v2.h"
#include "card_fixture.inc"
#include "np_store_v2_delete_wire.h"
#pragma warning(disable:4459) /* Mock globals vs actual port local names. */
static uint32_t primask;
static uint32_t __get_PRIMASK(void){return primask;}
static void __disable_irq(void){primask=1U;}
static void __set_PRIMASK(uint32_t value){primask=value;}
typedef struct {struct {unsigned dma_enable;} Init;unsigned id;} PCD_HandleTypeDef;
typedef struct {uint8_t bmRequest,bRequest;uint16_t wValue,wIndex,wLength;} XE_NP_UsbSetup;
static PCD_HandleTypeDef pcd,foreign;
static struct {PCD_HandleTypeDef *hpcd;} xe_np_usb_state;
static Nps2DeleteWire np_usb_delete;
static Nps2DeleteCard card_identity;
static uint8_t np_usb_delete_rx[128],snapshot[128];static uint32_t np_usb_delete_ep0[32];
static uint32_t np_usb_delete_receiving,np_usb_delete_rx_bytes,np_usb_delete_auto_running,np_usb_delete_clock_held;
static unsigned idle=1U,receives,sends,statuses,stalls,invalidates,rx_count;
static uint8_t *received;static uint32_t receive_length;
#define HAL_OK 0
static void np_usb_delete_card(Nps2DeleteCard *c){*c=card_identity;}
static int np_info_idle(void){return idle;}
static void XE_NP_UsbStream_Stall(PCD_HandleTypeDef *p){CHECK(p==&pcd||p==&foreign);stalls++;}
static void XE_NP_UsbStream_CtlStatus(PCD_HandleTypeDef *p){CHECK(p==&pcd);statuses++;}
static int XE_NP_UsbStream_CtlSend(PCD_HandleTypeDef *p,const uint8_t *b,uint32_t n,uint32_t requested){CHECK(p==&pcd&&n==128U&&requested==128U);memcpy(snapshot,b,128);sends++;return 0;}
static void XE_NP_Capture_DCacheInvalidate(const void *b,uint32_t n){CHECK(b&&n);invalidates++;}
static int HAL_PCD_EP_Receive(PCD_HandleTypeDef *p,uint32_t ep,uint8_t *b,uint32_t n){CHECK(p==&pcd&&!ep&&n==64U);received=b;receive_length=n;receives++;return HAL_OK;}
static uint32_t HAL_PCD_EP_GetRxCount(PCD_HandleTypeDef *p,uint32_t ep){CHECK((p==&pcd||p==&foreign)&&!ep);return rx_count;}
#include "actual_front.inc"
static void init(unsigned dma){
 Nps2State s;setup_records(&s,3U,0);memset(&np_usb_delete,0,sizeof(np_usb_delete));memset(&card_identity,0,sizeof(card_identity));card_identity.capacity=CARD_CAPACITY;card_identity.epoch=12U;card_identity.uid[0]=1U;card_identity.uid[1]=2U;card_identity.uid[2]=3U;for(unsigned i=0;i<4U;i++)card_identity.cid[i]=0x12345678U+i;
 pcd.Init.dma_enable=dma;pcd.id=1U;foreign.id=2U;xe_np_usb_state.hpcd=&pcd;idle=1U;
 CHECK(nps2_delete_wire_inspect_submit(&np_usb_delete,1U,&card_identity));CHECK(nps2_delete_wire_service(&np_usb_delete,&card_identity,card_read,card_write,NULL));CHECK(np_usb_delete.report[3]==3U && np_usb_delete.report[7]==3U);
 np_usb_delete_receiving=np_usb_delete_rx_bytes=np_usb_delete_auto_running=np_usb_delete_clock_held=0U;receives=sends=statuses=stalls=invalidates=0U;io_reset();
}
static XE_NP_UsbSetup output(void){XE_NP_UsbSetup r={0x40U,0xA7U,0U,0U,128U};return r;}
static void confirm(uint32_t p[32]){memcpy(p,np_usb_delete.confirmed,128);p[2]=2U;p[4]=2U;p[24]=1U;nps2_delete_wire_seal(p);}
static void first_half(const uint32_t p[32]){XE_NP_UsbSetup r=output();CHECK(np_usb_delete_request(&pcd,&r));CHECK(np_usb_delete_receiving&&np_usb_delete_rx_bytes==0U&&receive_length==64U);memcpy(received,p,64);rx_count=64U;CHECK(np_usb_delete_out(&pcd));CHECK(np_usb_delete_receiving&&np_usb_delete_rx_bytes==64U&&received==np_usb_delete_rx+64U&&!np_usb_delete.queued&&!reads&&!writes);}
static void cases(unsigned dma){
 uint32_t p[32];init(dma);confirm(p);first_half(p);Nps2DeleteWire saved=np_usb_delete;np_usb_delete_setup();CHECK(!np_usb_delete_receiving&&!np_usb_delete_rx_bytes&&!memcmp(&saved,&np_usb_delete,sizeof(saved)));
 XE_NP_UsbSetup get={0xC0U,0xA7U,0U,0U,128U};CHECK(np_usb_delete_request(&pcd,&get)&&sends==1U&&!memcmp(snapshot,np_usb_delete.report,128)&&!reads&&!writes);
 XE_NP_UsbSetup inspect={0x40U,0xA7U,2U,0U,0U};CHECK(np_usb_delete_request(&pcd,&inspect)&&np_usb_delete.queued==1U&&!reads&&!writes);saved=np_usb_delete;np_usb_delete_setup();CHECK(!memcmp(&saved,&np_usb_delete,sizeof(saved)));
 np_usb_delete.queued=0U;np_usb_delete.running=1U;saved=np_usb_delete;np_usb_delete_setup();CHECK(!memcmp(&saved,&np_usb_delete,sizeof(saved)));
 init(dma);confirm(p);first_half(p);memcpy(received,(const uint8_t *)p+64U,64U);rx_count=64U;CHECK(np_usb_delete_out(&pcd)&&!np_usb_delete_receiving&&np_usb_delete.queued==2U&&!reads&&!writes);saved=np_usb_delete;np_usb_delete_setup();CHECK(!memcmp(&saved,&np_usb_delete,sizeof(saved)));
 init(dma);confirm(p);first_half(p);rx_count=63U;CHECK(np_usb_delete_out(&pcd)&&!np_usb_delete_receiving&&!np_usb_delete.queued&&stalls==1U&&!reads&&!writes);
 init(dma);XE_NP_UsbSetup r=output();CHECK(np_usb_delete_request(&foreign,&r)&&stalls==1U&&!receives&&!np_usb_delete_receiving&&!reads&&!writes);
 init(dma);confirm(p);first_half(p);rx_count=64U;CHECK(np_usb_delete_out(&foreign)&&stalls==1U&&!np_usb_delete_receiving&&!np_usb_delete.queued&&!reads&&!writes);
 init(dma);idle=0U;r=output();CHECK(np_usb_delete_request(&pcd,&r)&&stalls==1U&&!receives&&!reads&&!writes);
}
int main(void){cases(0U);cases(1U);printf("PASS actual EP0 front checks%u; partial64/setup/passiveGET/freshInspect/acceptedPreserved/two64/foreign/wrongCount/noSDIO\n",checks);return 0;}
