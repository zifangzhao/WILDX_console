from datetime import datetime,timezone
import hashlib,json,re,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
t=Path('C:/Frank/Code/XE_NP/_artifacts/v1_delete_last_20261105')
out=root/'front2';assert not out.exists();out.mkdir()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
pins={'np_store_v2.h':'703A07BFBA2A2D6BE766266D53885B2F18E78943BBF263304E99F5FFC7B225DA','np_store_v2_delete.h':'DF05B9DCBDAAB476B7B12D1B85E3076F4E3121DEBA885A175BCF719B98CEBA71','np_store_v2_delete_wire.h':'507BCC48738E08DB772F03A1311C4E1E362DE64C487D3E467711EF91523A0D18'}
for name,digest in pins.items():assert sha(t/'core'/name)==digest,(name,'pin changed')
def function(text,name):
 m=re.search(r'(?m)^[^\n;]*\b'+name+r'\(',text);assert m,name
 start=m.start();brace=text.index('{',m.end());depth=1;at=brace+1
 while depth:
  depth+=(text[at]=='{')-(text[at]=='}');at+=1
 return text[start:at]
port=t/'usb-source/delete.inc';stream=t/'usb-source/stream.c';text=port.read_text();setup=function(stream.read_text(),'HAL_PCD_SetupStageCallback')
assert setup.count('np_usb_delete_setup();')==1,'New SETUP partial-receive hook missing/duplicated'
assert setup.index('np_usb_delete_setup();')<setup.index('XE_NP_UsbStream_HandleVendorRequest'), 'Cleanup must precede fresh request dispatch'
(out/'actual_front.inc').write_text('\n\n'.join(function(text,n) for n in ['np_usb_delete_owned','np_usb_delete_setup','np_usb_delete_request','np_usb_delete_out'])+'\n')
(out/'actual_setup_hook.txt').write_text(setup+'\n')
inputs={**{name:t/'core'/name for name in (*pins,'np_sd_fast_crc.h')},'fixture.c':root/'front_fixture.c','card_fixture.inc':root/'card_fixture.inc'}
for name,p in inputs.items():(out/name).write_bytes(p.read_bytes())
vc='C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat'
cmd=f'call "{vc}" >nul && cl /nologo /std:c11 /W4 /WX /TC /O2 /I"{out}" "{out}/fixture.c" /Fo"{out}/fixture.obj" /Fe"{out}/fixture.exe"'
started=datetime.now(timezone.utc).isoformat();watch=time.perf_counter();(out/'command.txt').write_text(cmd+'\n')
build=subprocess.run('cmd /d /s /c "'+cmd+'"',cwd=out,capture_output=True,text=True,timeout=60);(out/'compile.log').write_text(build.stdout+build.stderr);assert build.returncode==0,build.stdout+build.stderr
run=subprocess.run([str(out/'fixture.exe')],cwd=out,capture_output=True,text=True,timeout=60);(out/'result.txt').write_text(run.stdout+run.stderr);print(run.stdout+run.stderr,end='');assert run.returncode==0
receipt={'status':'PASS','started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),'seconds':time.perf_counter()-watch,'scope':'Actual extracted EP0 setup/request/out/owned with real wire/storage headers, mocked PCD and RAM sectors; no firmware/app build or hardware','port_sha256':sha(port),'stream_sha256':sha(stream),'actual_functions_sha256':sha(out/'actual_front.inc'),'setup_hook_sha256':sha(out/'actual_setup_hook.txt'),'headers':pins,'source_inputs':[{'path':n,'sha256':sha(p)} for n,p in inputs.items()],'result_sha256':sha(out/'result.txt')}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('receipt',out/'receipt.json',sha(out/'receipt.json'))
