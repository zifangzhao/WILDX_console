from pathlib import Path
import hashlib,json,re,zipfile
T=Path(__file__).resolve().parent;P=T/'bench';N=Path('C:/Frank/Code/USB_PCconsole/_artifacts/v1_delete_last_native_20261105')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper();read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
rest=read(P/'restoration-complete.json');lease=read(T/'owner/lease.json');assert rest['result']=='PASS' and lease['status'].lower()=='closed'
card=read(P/'final-card-preservation/result.json');cold=read(P/'final-cold-readiness/result.json');sd=read(P/'sd-post-recovery-verified/hil.json');usb=read(P/'usb-cl0/experiment.json');cut=read(P/'checkpoint-cut-acceptance.json');ble=read(P/'ble-delete-post-recovery/result.json')
assert card['earlier_recordings_preserved'] and card['store']['Count']==card['protected_count']==74
assert cold['result'].startswith('PASS') and not cold['destructive_confirmation_sent']
assert sd['acceptance_passed'] and sd['stored_neural_continuity_verified'] and usb['result']=='pass' and cut['result']=='PASS' and ble['result'].startswith('PASS')
overlay=N/'packaging/overlay-r13/source-overlay.zip'
with zipfile.ZipFile(overlay) as z:
 old=next(z.read(n) for n in z.namelist() if n.endswith('delete.inc') and hashlib.sha256(z.read(n)).hexdigest().upper()=='5BBFE4889A61DCCA8D3799EA33456B8A3F2716B7DF3FD1AEBA61175C92571151').decode()
new=(T/'usb-source/delete.inc').read_text()
def body(source,name):
 m=re.search(r'\b'+name+r'\s*\([^)]*\)\s*\{',source);assert m,name
 at=source.index('{',m.start());depth=1;i=at+1
 while depth:depth+=(source[i]=='{')-(source[i]=='}');i+=1
 return source[at:i]
unchanged={n:hashlib.sha256(body(new,n).encode()).hexdigest().upper() for n in ('np_usb_delete_write','np_usb_delete_read','np_usb_delete_cancel','np_usb_delete_service','np_usb_delete_retire','np_usb_delete_clock_begin','np_usb_delete_clock_end') if body(old,n)==body(new,n)}
assert len(unchanged)==7
proofs={
 'storage':N/'run4/receipt.json','wire':N/'wire3/receipt.json','ep0':N/'front2/receipt.json','polling_retirement':N/'retire2/receipt.json','cold_reader':N/'cold2/receipt.json','ce32_actual_rx':N/'ce32-rx/native3/receipt.json','owned_initializer':N/'initializer2/receipt.json','durable_recovery_cancellation':N/'recovery-cancel1/receipt.json','cold_readiness':N/'readiness1/receipt.json',
 'usb_recording':P/'usb-cl0/experiment.json','sd_recording':P/'sd-post-recovery/hil.json','sd_full_readback':P/'sd-post-recovery-verified/hil.json','ble_delete':P/'ble-delete-post-recovery/result.json','usb_delete':P/'usb-delete-own-predecessor-settled/result.json','checkpoint_interruption':P/'checkpoint-cut-acceptance.json','cold_inspect':P/'final-cold-readiness/result.json','protected_card':P/'final-card-preservation/result.json','original_restore':P/'restoration-complete.json','closed_lease':T/'owner/lease.json'}
components={}
for role,suffix in [('app','r6'),('usb','r14')]:
 b=T/f'build-{role}-{suffix}';i=read(b/'identity.json');items={n:dict(path=str(b/n),sha256=h(b/n),bytes=(b/n).stat().st_size) for n in (role.upper()+'_TEST_ONLY.hex',role.upper()+'_body.bin',role.upper()+'_manifest.bin','receipt.json','identity.json')}
 if role=='app':items['APP_TEST_ONLY.xenp']=dict(path=str(b/'APP_TEST_ONLY.xenp'),sha256=h(b/'APP_TEST_ONLY.xenp'),bytes=(b/'APP_TEST_ONLY.xenp').stat().st_size)
 components[role]=dict(crc32=i['image_crc32'],files=items)
zips=[T/'source-freeze-final.zip',N/'packaging/overlay-r13/source-overlay.zip',N/'packaging/overlay-r14/source-overlay.zip']
r=dict(status='accepted',uid='001D00065942500B20313354',app_crc32='4A677F83',usb_crc32='11646986',host_version=246,original_restored=True,original_flash_sha256='01CC90B06C44B2B52962DD214AB82C4F9600F06F13BB11D4BCCE7F21F2B66A75',original_options_sha256='4A4541ADDDBC566412A1000C87E5A1F0212B3F00AA3393BA0B44D468D80A4225',protected_recordings=74,card_preserved=True,usb_delete_last=True,ble_fs2_delete_last=True,components=components,proofs={k:dict(path=str(v),sha256=h(v)) for k,v in proofs.items()},source_archives=[dict(path=str(p),sha256=h(p)) for p in zips],source_manifest=dict(path=str(N/'packaging/overlay-r14/source-manifest.json'),sha256=h(N/'packaging/overlay-r14/source-manifest.json')),readiness_delta_reuses_usb03_cut_and_recording_evidence=dict(storage_port_body_hashes_unchanged=unchanged,scope='Final1164 changes only cold prepare Busy lifetime and A7 admission; actual cold mode cycle/Inspect passed;03C durability/cancellation and recording proofs reused by exact source delta.'),recording_scope='USB and BLE-controlled SD:2probes15kHz,CLoff,bounded30s; no widened closed-loop or all-profile claim.',imu_scope='Retained observed1250Hz lattice and valid AG/MAG values passed; pre-existing unavailable initialslot0 and unknown terminal tail/source-window remain explicit.',power_interruption_scope=cut['scope'],cleanup=read(T/'cleanup-complete.json'))
(T/'accepted.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(dict(status=r['status'],app_crc32=r['app_crc32'],usb_crc32=r['usb_crc32'],accepted_sha256=h(T/'accepted.json'),original_restored=True,protected_recordings=74)))
