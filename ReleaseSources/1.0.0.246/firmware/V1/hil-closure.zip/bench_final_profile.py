import sys
from pathlib import Path
import bench_hil
source=Path(bench_hil.c.__file__).with_name('final_ap_profile.py')
sys.argv=[sys.argv[0],'bench_hil']
text=source.read_text(encoding='utf-8-sig');assert text.count("'restore_verified.json'")==1
text=text.replace("'restore_verified.json'","'restore_2_verified.json'")
exec(compile(text,str(source),'exec'),{'__name__':'__main__','__file__':str(source)})
