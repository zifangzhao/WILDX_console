init
targets stm32u5.cpu
set u [read_memory 0x0bfa0700 32 3]
if {[format "%08X%08X%08X" [lindex $u 0] [lindex $u 1] [lindex $u 2]] ne "001D00065942500B20313354"} {error "WrongUID"}
if {[lindex [read_memory 0xe000ed08 32 1] 0] != 0x08180000 || [lindex [read_memory 0x0817e020 32 1] 0] != 0x03C0FADD} {error "WrongUSB"}
if {[lindex [read_memory 0x420c8034 32 1] 0]&0x3000 || [lindex [read_memory 0x420c8058 32 1] 0]&1} {error "SDactiveBeforeArm"}
for {set i 0} {$i<16} {incr i} {if {[lindex [read_memory [expr {0x40020064+$i*0x80}] 32 1] 0]&1} {error "DMAactiveBeforeArm"}}
halt
wait_halt 3000
bp 0x81c7450 2 hw
resume
set f [open {C:/Frank/Code/XE_NP/_artifacts/v1_delete_last_20261105/bench/delete-checkpoint-rail-cut-r13/armed.ready} w];puts $f "real production write breakpoint armed";close $f
echo "V1_DELETE_WRITE_BREAKPOINT_ARMED"
set found 0
for {set i 0} {$i<36000} {incr i} {
 sleep 5
 poll
 if {[stm32u5.cpu curstate] eq "halted"} {
  set p [get_reg {pc r0 r1 sp lr}]
  set lba [dict get $p r0]
  if {$lba==113} {
   if {[lindex [read_memory 0x420c8034 32 1] 0]&0x3000 || [lindex [read_memory 0x420c8058 32 1] 0]&1 || [lindex [read_memory 0x420c802c 32 1] 0]&1} {error "SDnotquietAtCP1"}
   dump_image {C:/Frank/Code/XE_NP/_artifacts/v1_delete_last_20261105/bench/delete-checkpoint-rail-cut-r13/verified-cp0-readback.bin} 0x2001d4c0 512
   dump_image {C:/Frank/Code/XE_NP/_artifacts/v1_delete_last_20261105/bench/delete-checkpoint-rail-cut-r13/engine.bin} 0x2001cb40 744
   dump_image {C:/Frank/Code/XE_NP/_artifacts/v1_delete_last_20261105/bench/delete-checkpoint-rail-cut-r13/sdmmc.bin} 0x420c8000 96
   set f [open {C:/Frank/Code/XE_NP/_artifacts/v1_delete_last_20261105/bench/delete-checkpoint-rail-cut-r13/boundary-registers.txt} w];puts $f $p;close $f
   set f [open {C:/Frank/Code/XE_NP/_artifacts/v1_delete_last_20261105/bench/delete-checkpoint-rail-cut-r13/cut.ready} w];puts $f "CP1 pending: production intent and CP0 already verified; CPU halted before second CP write";close $f
   echo "V1_REAL_DELETE_CP0_DURABLE_CP1_NOT_WRITTEN_SD_QUIET"
   if {([lindex [read_memory 0x42021400 32 1] 0]>>4&3)!=1 || !([lindex [read_memory 0x42021414 32 1] 0]&4)} {error "VEEnotownedoutputhigh"}
   write_memory 0x42021418 32 {262144}
   if {[lindex [read_memory 0x42021414 32 1] 0]&4} {error "VEEoffreadbackfailed"}
   dump_image {C:/Frank/Code/XE_NP/_artifacts/v1_delete_last_20261105/bench/delete-checkpoint-rail-cut-r13/vee-off-gpio.bin} 0x42021400 40
   dump_image {C:/Frank/Code/XE_NP/_artifacts/v1_delete_last_20261105/bench/delete-checkpoint-rail-cut-r13/vee-off-core.bin} 0xe000edf0 4
   echo "V1_DELETE_SD_RAIL_OFF_READBACK_HOLD5SECONDS"
   sleep 5000
   rbp 0x81c7450
   reset run
   sleep 500
   poll off
   mww 0xe000edf0 0xa05f0000
   set f [open {C:/Frank/Code/XE_NP/_artifacts/v1_delete_last_20261105/bench/delete-checkpoint-rail-cut-r13/reset-performed.txt} w];puts $f "PF2off readback held5seconds then MCUreset; no measured VDD0 or whole-devicecut claim";close $f
   set found 1
   break
  }
  step
  resume
 }
}
if {!$found} {rbp 0x81c7450;resume;error "NoCP1BoundaryReached"}
shutdown
