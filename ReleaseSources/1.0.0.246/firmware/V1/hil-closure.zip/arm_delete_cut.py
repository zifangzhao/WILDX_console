"""Interrupt SD rail before real CP1, then fresh MCU reset; no firmware hooks."""
from pathlib import Path
import json,re,subprocess,sys
sys.dont_write_bytecode=True
import bench_hil as b
sys.path.insert(0,'C:/Frank/Code/XE_NP/Tools/V1Capture/ClosedLoopFix')
import ap_snapshot as a
T=Path(__file__).resolve().parent;mapdir,outname=sys.argv[1:]
mapping=(T/mapdir/'candidate.map').read_text();pair=json.loads((T/'matched-test-pair.json').read_text())
def sym(n,kind='Data'):
 m=re.search(r'^\s*'+n+r'\s+0x([0-9a-fA-F]+)\s+'+kind+r'\s+(\d+)\b',mapping,re.M);assert m,n
 return int(m[1],16),int(m[2])
write,_=sym('np_usb_delete_write','Thumb Code');write&=~1
sector,_=sym('np_usb_delete_sector');engine,esize=sym('np_usb_delete')
held,_,_=b.c.setup();lease=held.prior.held(b.c.PHASE)
folder=b.c.PHASE/outname;assert not folder.exists();folder.mkdir()
source=f'''init
targets stm32u5.cpu
set u [read_memory 0x0bfa0700 32 3]
if {{[format "%08X%08X%08X" [lindex $u 0] [lindex $u 1] [lindex $u 2]] ne "{b.c.UID}"}} {{error "WrongUID"}}
if {{[lindex [read_memory 0xe000ed08 32 1] 0] != 0x08180000 || [lindex [read_memory 0x0817e020 32 1] 0] != 0x{pair['usb']['image_crc32']}}} {{error "WrongUSB"}}
if {{[lindex [read_memory 0x420c8034 32 1] 0]&0x3000 || [lindex [read_memory 0x420c8058 32 1] 0]&1}} {{error "SDactiveBeforeArm"}}
for {{set i 0}} {{$i<16}} {{incr i}} {{if {{[lindex [read_memory [expr {{0x40020064+$i*0x80}}] 32 1] 0]&1}} {{error "DMAactiveBeforeArm"}}}}
halt
wait_halt 3000
bp {hex(write)} 2 hw
resume
set f [open {{{(folder/'armed.ready').as_posix()}}} w];puts $f "real production write breakpoint armed";close $f
echo "V1_DELETE_WRITE_BREAKPOINT_ARMED"
set found 0
for {{set i 0}} {{$i<36000}} {{incr i}} {{
 sleep 5
 poll
 if {{[stm32u5.cpu curstate] eq "halted"}} {{
  set p [get_reg {{pc r0 r1 sp lr}}]
  set lba [dict get $p r0]
  if {{$lba==113}} {{
   if {{[lindex [read_memory 0x420c8034 32 1] 0]&0x3000 || [lindex [read_memory 0x420c8058 32 1] 0]&1 || [lindex [read_memory 0x420c802c 32 1] 0]&1}} {{error "SDnotquietAtCP1"}}
   dump_image {{{(folder/'verified-cp0-readback.bin').as_posix()}}} {hex(sector)} 512
   dump_image {{{(folder/'engine.bin').as_posix()}}} {hex(engine)} {esize}
   dump_image {{{(folder/'sdmmc.bin').as_posix()}}} 0x420c8000 96
   set f [open {{{(folder/'boundary-registers.txt').as_posix()}}} w];puts $f $p;close $f
   set f [open {{{(folder/'cut.ready').as_posix()}}} w];puts $f "CP1 pending: production intent and CP0 already verified; CPU halted before second CP write";close $f
   echo "V1_REAL_DELETE_CP0_DURABLE_CP1_NOT_WRITTEN_SD_QUIET"
   if {{([lindex [read_memory 0x42021400 32 1] 0]>>4&3)!=1 || !([lindex [read_memory 0x42021414 32 1] 0]&4)}} {{error "VEEnotownedoutputhigh"}}
   write_memory 0x42021418 32 {{262144}}
   if {{[lindex [read_memory 0x42021414 32 1] 0]&4}} {{error "VEEoffreadbackfailed"}}
   dump_image {{{(folder/'vee-off-gpio.bin').as_posix()}}} 0x42021400 40
   dump_image {{{(folder/'vee-off-core.bin').as_posix()}}} 0xe000edf0 4
   echo "V1_DELETE_SD_RAIL_OFF_READBACK_HOLD5SECONDS"
   sleep 5000
   rbp {hex(write)}
   reset run
   sleep 500
   poll off
   mww 0xe000edf0 0xa05f0000
   set f [open {{{(folder/'reset-performed.txt').as_posix()}}} w];puts $f "PF2off readback held5seconds then MCUreset; no measured VDD0 or whole-devicecut claim";close $f
   set found 1
   break
  }}
  step
  resume
 }}
}}
if {{!$found}} {{rbp {hex(write)};resume;error "NoCP1BoundaryReached"}}
shutdown
'''
tcl=folder/'arm.tcl';tcl.write_text(source)
command=[str(a.OPENOCD),'-s',str(a.SCRIPTS),'-f','interface/stlink-dap.cfg','-c','adapter serial '+b.c.SERIAL,'-c','transport select dapdirect_swd','-f','target/stm32u5x.cfg','-c','adapter speed 1000','-c','stm32u5.cpu configure -event examine-end {}','-c','gdb_port disabled','-c','tcl_port disabled','-c','telnet_port disabled','-f',str(tcl)]
(folder/'plan.json').write_text(json.dumps(dict(command=command,uid=b.c.UID,usb_crc32=pair['usb']['image_crc32'],write_address=write,scope='Production durability boundary; PF2 storage-rail off request/readback for5s then freshMCUreset. No measuredVDD0 or whole-devicepowercut claim.',holder=lease),indent=2)+'\n')
p=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
with (folder/'openocd.log').open('w') as log:
 for line in p.stdout:log.write(line);log.flush();print(line,end='',flush=True)
code=p.wait();assert code==0 and (folder/'cut.ready').exists(),f'Boundary arm failed {code}; inspect target before further action'
print('SD_RAIL_REQUEST_READBACK_INTERRUPTION_AND_FRESH_MCU_RESET_DONE',flush=True)
