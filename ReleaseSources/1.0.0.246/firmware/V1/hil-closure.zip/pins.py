from pathlib import Path
import json,hashlib,sys
root=Path(__file__).resolve().parent
phase=root/'bench'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
lease=json.loads((phase/'lease_held.json').read_text(encoding='utf-8-sig'))
pair=json.loads((root/'matched-test-pair.json').read_text())
proof=phase/'owner-sd-preflight-v7.json'
if not proof.exists():
    data=dict(verified=True,uid=lease['uid'],family=1,lease='Local\\XE_NP_V1_'+lease['uid'],global_lease='Local\\WILDX_NP_TIMING_HIL',app_crc32=pair['app']['image_crc32'],usb_crc32=pair['usb']['image_crc32'],holder_pid=lease['holder_pid'])
    data['evidence']=[dict(path=str(phase/n),sha256=sha(phase/n)) for n in ('usb-readiness-fix/verified.json','usb-readiness-fix/flash_after.bin','usb-readiness-fix/options_after.bin','lease_held.json','initial_status.json')]
    proof.write_text(json.dumps(data,indent=2)+'\n')
host=Path('C:/Frank/Code/USB_PCconsole/_artifacts/sd_usb_test_host/enabled246-v1catalog/WILDX_console.exe')
fresh='--fresh' in sys.argv
mapping=phase/'sd-map-postcut/mapping.json' if fresh else Path('C:/Frank/Code/USB_PCconsole/_artifacts/closed_loop_fix_20261102/V1/sd_hil/map_h10/mapping.json')
pins=dict(host_version=246,host_sha256=sha(host),sdk_sha256=sha(host.with_name('NpV2SdDatExport.dll')),build_receipt=str(root/'matched-test-pair.json'),build_receipt_sha256=sha(root/'matched-test-pair.json'),expected_app_crc32=pair['app']['image_crc32'],expected_usb_crc32=pair['usb']['image_crc32'],lease='Local\\XE_NP_V1_'+lease['uid'],global_lease='Local\\WILDX_NP_TIMING_HIL',verified_mapping=str(mapping),verified_mapping_sha256=sha(mapping),owner_preflight=str(proof),owner_preflight_sha256=sha(proof),selftest_output=str(phase/'sd-offline'))
out=phase/('sd-pins.json' if fresh else 'sd-pins-map.json')
out.write_text(json.dumps(pins,indent=2)+'\n')
print(out)
