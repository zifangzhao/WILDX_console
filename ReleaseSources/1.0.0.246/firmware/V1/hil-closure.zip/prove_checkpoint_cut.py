from pathlib import Path
import hashlib,json,re,struct,zlib
T=Path(__file__).resolve().parent;P=T/'bench';cut=P/'delete-checkpoint-rail-cut-r13';after=P/'after-delete-cut-recovery';before=P/'owned-open-before-cut-ready'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper();u=lambda b,o:struct.unpack_from('<I',b,o)[0]
allowed=json.loads((before/'allowed-last.json').read_text());snapshot=json.loads((after/'result.json').read_text());prior=json.loads((before/'result.json').read_text());captured=(cut/'verified-cp0-readback.bin').read_bytes();sd=(cut/'sdmmc.bin').read_bytes();gpio=(cut/'vee-off-gpio.bin').read_bytes()
assert captured==(before/'lba113.bin').read_bytes() # Core reads old CP1 before entering its write port.
cp=bytearray(prior['store']['Checkpoint']);prev=prior['fingerprints'][-2]['entry']
struct.pack_into('<Q',cp,24,allowed['generation']+1)
for offset,value in [(32,allowed['start']),(36,allowed['count']-1),(40,prev['Start']),(44,allowed['start']),(48,prev['Session']),(52,int(prev['State']==1))]:struct.pack_into('<I',cp,offset,value)
struct.pack_into('<I',cp,508,zlib.crc32(cp[:508]));cp=bytes(cp)
assert cp[:8]==b'NPS2CP01' and zlib.crc32(cp[:508])==u(cp,508)
assert u(cp,36)==allowed['count']-1 and u(cp,32)==allowed['start']
assert not u(sd,0x34)&0x103000 and not u(sd,0x58)&1 and not u(sd,0x2c)&1
assert not u(gpio,0x14)&4
regs=(cut/'boundary-registers.txt').read_text();assert 'r0 0x00000071' in regs and 'pc 0x081c7450' in regs
assert (after/'lba112.bin').read_bytes()==(after/'lba113.bin').read_bytes()==cp
assert not any((after/'lba114.bin').read_bytes()) and not any((after/'lba115.bin').read_bytes())
assert snapshot['earlier_recordings_preserved'] and snapshot['protected_count']==74
diag=json.loads((P/'post-delete-cut-final-map/decoded.json').read_text());assert diag['np_usb_delete_auto_checked']==[1] and not diag['np_usb_delete_clock_held'][0] and not diag['np_usb_delete_port_error'][0] and not diag['core'][0]&1
proof=dict(result='PASS',uid=allowed['uid'],app_crc32='4A677F83',usb_crc32='03C0FADD',before_count=allowed['count'],after_count=u(cp,36),reclaimed_frontier=u(cp,32),cp0_verified_before_cp1_by_actual_production_control_flow=True,expected_after_crc32=f'{u(cp,508):08X}',captured_ram_sector_is_old_cp1=True,both_recovered_checkpoints_equal_independently_reconstructed_after=True,both_journals_cleared=True,protected_earlier_recordings=74,earlier_fingerprints_unchanged=True,cpu_debug_disabled=True,automatic_recovery_completed=True,scope='Production delete interrupted after verified intent+CP0 before CP1. Captured RAM sector is the just-read oldCP1 (legacy filename sayscp0readback). PF2 storage rail off request/readback held5s with CPU halted, then fresh MCUreset/RAMdiscard. No measuredVDD0/whole-device/in-flight-controller/tornwrite claim; torn persistence covered separately by native fault injection.',files={str(p.relative_to(P)):h(p) for p in [cut/'verified-cp0-readback.bin',cut/'boundary-registers.txt',cut/'sdmmc.bin',cut/'vee-off-gpio.bin',cut/'reset-performed.txt',after/'result.json',after/'lba112.bin',after/'lba113.bin',after/'lba114.bin',after/'lba115.bin',P/'post-delete-cut-final-map/receipt.json']})
(P/'checkpoint-cut-acceptance.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
