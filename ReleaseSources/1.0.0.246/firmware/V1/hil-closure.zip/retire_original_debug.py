from pathlib import Path
import json,subprocess,sys
sys.dont_write_bytecode=True
import bench_hil as b
sys.path.insert(0,'C:/Frank/Code/XE_NP/Tools/V1Capture/ClosedLoopFix')
import ap_snapshot as a
a.PHASE=b.c.PHASE;P=b.c.PHASE;proof=json.loads((P/'restore_2_verified.json').read_text());assert proof['full_physical_flash_options_verified'] and proof['flash_sha256']=='01CC90B06C44B2B52962DD214AB82C4F9600F06F13BB11D4BCCE7F21F2B66A75'
status=json.loads((P/'restored-final-status.json').read_text(encoding='utf-8-sig'));assert status['final']['Role']==3 and not status['final']['Busy'] and status['profile']['ActiveMask']==7 and status['profile']['ApHz']==7500
p,_,_=b.c.setup();lease=p.prior.held(P);folder=P/'original-debug-retired';assert not folder.exists()
ranges={'uid':(0x0bfa0700,12),'vtor':(0xe000ed08,4),'core':(0xe000edf0,4),'fpb':(0xe0002000,40)}
_,_,source,command=a.prepare(folder,ranges,b.c.SERIAL)
guard='''
if {[lindex [read_memory 0x0801e020 32 1] 0]!=0x82e51dea || [lindex [read_memory 0x0817e020 32 1] 0]!=0x4f7b521a} {error "OriginalPairNotRestored"}
if {([lindex [read_memory 0x420c8034 32 1] 0]&0x103000) || ([lindex [read_memory 0x420c8058 32 1] 0]&1)} {error "SDactive"}
for {set i 0} {$i<16} {incr i} {if {[lindex [read_memory [expr {0x40020064+$i*0x80}] 32 1] 0]&1} {error "DMAactive"}}
foreach c [read_memory 0xe0002008 32 8] {if {$c} {error "UnexpectedBreakpoint"}}
write_memory 0xe000edf0 32 {0xa05f0000}
if {[lindex [read_memory 0xe000edf0 32 1] 0]&1} {error "DebugStillEnabled"}
'''
source=source.replace('dump_image ',guard+'dump_image ',1).replace(a.COMPLETE,'V1_ORIGINAL_FIRMWARE_DEBUG_RETIRED');folder.mkdir();tcl=folder/'retire.tcl';tcl.write_text(source);command[-1]=str(tcl)
r=subprocess.run(command,capture_output=True,text=True,timeout=20);log=r.stdout+r.stderr;(folder/'log.txt').write_text(log);assert r.returncode==0 and 'V1_ORIGINAL_FIRMWARE_DEBUG_RETIRED' in log,log
for n in ranges:(folder/(n+'.bin.partial')).rename(folder/(n+'.bin'))
(folder/'receipt.json').write_text(json.dumps(dict(result='PASS',uid=b.c.UID,original_pair_verified=True,cpu_debug_disabled=True,all_breakpoints_absent=True,halt=False,reset=False,card_io=False,holder=lease),indent=2)+'\n');print('Original pair, idle hardware and debug retirement verified')
