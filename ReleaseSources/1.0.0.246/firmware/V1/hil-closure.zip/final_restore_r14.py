"""Use reviewed restoration controller with the final exact component plan."""
from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
import bench_hil as b
p,f,c=b.c.setup()
if sys.argv[1]=='prepare':
 p.emit(b.c.PHASE,b.c.PHASE/'plan-final',False)
 print('Final exact-component restore plan prepared offline; no hardware accessed')
elif sys.argv[1]=='restore':
 # Preserve the controller already patched by hil_current.setup(), including
 # its reviewed unavailable/gated-BKP policy. Only bind its plan directory.
 code=f.run.__code__;assert code.co_consts.count('plan')==1
 constants=tuple('plan-final' if x=='plan' else x for x in code.co_consts)
 rebound=code.replace(co_consts=constants);assert rebound.co_code==code.co_code
 f.run.__code__=rebound
 (b.c.PHASE/'restore-controller-binding.json').write_text(json.dumps(dict(only_constant_change=['plan','plan-final'],controller_bytecode_sha256=hashlib.sha256(code.co_code).hexdigest().upper(),reviewed_runtime_patches_preserved=True),indent=2)+'\n')
 f.run('restore',b.c.PHASE,int(sys.argv[2]) if len(sys.argv)>2 else 1)
else:raise SystemExit('prepare|restore')
