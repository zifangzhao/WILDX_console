using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

// Explicit HIL: selected UID only; production recording workers, no flash or SD writes.
static class NpTimeHardware
{
    const BindingFlags All=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Static|BindingFlags.Instance;
    static int detectors; static string pref; static byte[] prefBefore; static bool prefExisted, prefStaged;
    static Assembly app; static string root,uid; static bool v1; static int seconds,rate=20000,probeMask=3;
    static long firstData; static volatile bool activeCapture; static Stopwatch wall; static Dictionary<string,object> report=new Dictionary<string,object>();
    static Type T(string name){return app.GetType(name.Contains(".")?name:"USB512_interface."+name,true);}
    static object Get(object o,string name){var f=o.GetType().GetField(name,All);return f!=null?f.GetValue(o):o.GetType().GetProperty(name,All).GetValue(o,null);}
    static void Set(object o,string name,object value){o.GetType().GetField(name,All).SetValue(o,value);}
    static object Call(object o,string name,params object[] args){try{return (o as Type??o.GetType()).GetMethods(All).Single(m=>m.Name==name&&m.GetParameters().Length==args.Length).Invoke(o is Type?null:o,args);}catch(TargetInvocationException e){throw e.InnerException??e;}}
    static object New(string name,params object[] args){try{return T(name).GetConstructors(All).Single(c=>!c.IsStatic&&c.GetParameters().Length==args.Length).Invoke(args);}catch(TargetInvocationException e){throw e.InnerException??e;}}
    static long N(object o,string name){return Convert.ToInt64(Get(o,name));}
    static void Need(bool value,string why){if(!value)throw new IOException(why);}
    static object Fields(object o){return o.GetType().GetFields(All).Where(f=>!f.IsStatic).ToDictionary(f=>f.Name,f=>f.GetValue(o));}
    static void Log(string s){Console.WriteLine(DateTimeOffset.Now.ToString("O")+" "+s);}
    static string PathNow(){return ((IEnumerable)Call(T("CE32_console.NpDownloadNative"),"EnumerateNpPaths")).Cast<string>().Single(p=>p.IndexOf(uid,StringComparison.OrdinalIgnoreCase)>=0);}
    static object Service(string path){
        if(!v1)return Call(T("NpV2FirmwareForm"),"DownloadStatus",path,uid);
        object target=((IEnumerable)Call(T("NpV1Management"),"Enumerate")).Cast<object>().Single(p=>String.Equals((string)Get(p,"Uid"),uid,StringComparison.OrdinalIgnoreCase));
        using(var manager=(IDisposable)New("NpV1Management",target))return Call(manager,"ReadStatus");
    }
    [DllImport("winusb.dll",SetLastError=true)] [return:MarshalAs(UnmanagedType.Bool)]
    static extern bool WinUsb_QueryDeviceInformation(IntPtr handle,uint type,ref uint length,byte[] bytes);
    static void HighSpeed(object device){
        uint length=1;var speed=new byte[1];
        Need(WinUsb_QueryDeviceInformation((IntPtr)Get(device,"winUsb"),1,ref length,speed)&&length==1&&speed[0]==3,"High-speed USB required; full-speed capture refused");
        report["usb_speed"]="high-speed";
    }
    static string Switch(string path,int mode){
        if(N(Service(path),v1?"Role":"Mode")==mode)return path;
        if(v1)return (string)(mode==2?Call(T("NpV1Management"),"EnsureStreaming",path):Call(T("NpV1Management"),"EnsureDownload",path,null));
        ((Task<string>)Call(T("NpV2FirmwareForm"),"SwitchUsbMode",path,(ushort)mode)).GetAwaiter().GetResult();
        var wait=Stopwatch.StartNew();while(wait.Elapsed.TotalSeconds<30){
            Thread.Sleep(250);string[] matches=((IEnumerable)Call(T("CE32_console.NpDownloadNative"),"EnumerateNpPaths")).Cast<string>().Where(p=>p.IndexOf(uid,StringComparison.OrdinalIgnoreCase)>=0).ToArray();
            Need(matches.Length<=1,"Ambiguous selected UID after mode transition");if(matches.Length==0)continue;
            try{var state=Service(matches[0]);if(N(state,"Mode")==mode&&N(state,"Busy")==0&&N(state,"Target")==0)return matches[0];}
            catch(System.ComponentModel.Win32Exception){}
        }
        throw new TimeoutException("Same V2 UID did not re-enumerate in requested mode; no command replayed");
    }
    static bool Cancel(){long first=Interlocked.Read(ref firstData);return first!=0?(Stopwatch.GetTimestamp()-first)/(double)Stopwatch.Frequency>=seconds:wall.Elapsed.TotalSeconds>=246;}
    static void Progress(object p){
        if(N(p,"ReceivedBlocks")>0&&Interlocked.CompareExchange(ref firstData,Stopwatch.GetTimestamp(),0)==0)Log("First received data");
        Log((string)Get(p,"Text")+" received="+N(p,"ReceivedBlocks"));
    }
    static void V2(string path){
        using(var device=(IDisposable)Call(T("NpV2UsbDevice"),"Open",path)){
            // V2 Open verifies the 512-byte high-speed endpoint itself.
            report["usb_speed"]="high-speed (512-byte endpoint admitted by production Open)";
            object service=Call(device,"GetServiceStatus");Need(N(service,"Mode")==2&&N(service,"Busy")==0,"V2 not idle stream mode");
            report["initial_capture"]=Fields(Call(device,"GetCaptureStatus"));
            report["profile"]=Fields(Call(device,"ConfigureProfile",7U,20000U));
        }
        var method=T("NpV2Recording").GetMethods(All).Single(m=>m.Name=="RunContinuousInFolder"&&m.GetParameters().Length==10);
        var callback=Delegate.CreateDelegate(method.GetParameters()[3].ParameterType,typeof(NpTimeHardware).GetMethod("Progress",All));
        object result;try{result=method.Invoke(null,new object[]{path,root,(Func<bool>)Cancel,callback,null,null,null,true,false,false});}catch(TargetInvocationException e){throw e.InnerException??e;}
        report["recording_result"]=Fields(result);
        Need((bool)Get(result,"Complete"),"V2 recording incomplete: "+Get(result,"Error"));
    }
    static void StageClosedLoop(){
        pref=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"WILDX_console","closed_loop_v1.json");
        prefExisted=File.Exists(pref);prefBefore=prefExisted?File.ReadAllBytes(pref):null;
        if(prefExisted)File.WriteAllBytes(Path.Combine(root,"closed_loop_preference_before.bin"),prefBefore);
        report["closed_loop_preference_existed"]=prefExisted;prefStaged=true;
        object settings=New("NpClosedLoopSettings");Set(settings,"Enabled",detectors>0);Set(settings,"MayBeConfigured",true);
        Set(settings,"TrainingStartMs",0U);Set(settings,"TrainingDurationMs",1000U);
        Type channel=settings.GetType().GetField("Channels",All).FieldType.GetElementType();
        Array channels=Array.CreateInstance(channel,Math.Max(detectors,1));
        for(int i=0;i<channels.Length;i++){
            object value=Activator.CreateInstance(channel);byte probe=(byte)((probeMask&1)!=0?(i==1&&(probeMask&2)!=0?2:1):2);
            ushort index=(ushort)(i==1&&probeMask!=3?1:0);
            Set(value,"Probe",probe);Set(value,"Channel",index);Set(value,"Filter",(byte)6);Set(value,"Gain",2F);Set(value,"Rectify",true);channels.SetValue(value,i);
        }
        Set(settings,"Channels",channels);Call(settings,"Save",false);
        report["closed_loop_detectors"]=detectors;report["closed_loop_training_ms"]=1000;
    }
    static void RestorePreference(){
        if(!prefStaged)return;
        if(prefExisted)File.WriteAllBytes(pref,prefBefore);else if(File.Exists(pref))File.Delete(pref);
        Need(File.Exists(pref)==prefExisted&&(!prefExisted||File.ReadAllBytes(pref).SequenceEqual(prefBefore)),"CL preference restore mismatch");
        report["closed_loop_preference_restored"]=true;
    }
    static void V1(string path){
        using(var device=(IDisposable)Call(T("XeNpWinUsbDevice"),"OpenForControl",path)){
            HighSpeed(device);object status=Call(device,"GetStatus");report["initial_capture"]=Fields(status);
            Need(!(bool)Get(status,"Streaming"),"V1 already streaming; no START/STOP sent");
            object caps=Call(device,"GetModeCapabilities");report["initial_profile"]=Fields(caps);
            Need(!(bool)Get(caps,"CameraOnlyActive")&&((int)Get(caps,"AvailableMask")&probeMask)==probeMask,"Requested V1 neural ports unavailable");
            Need((bool)Call(caps,"Supports",New("NpCaptureMode",probeMask,rate)),"Requested V1 profile unsupported");
        }
        // Constructor only: no Load, discovery, GUI handle, preview, network or GPIO start.
        using(var form=(Form)New("Form1")){
            Need(!form.IsHandleCreated,"Unexpected GUI handle");
            Set(form,"devicePath",path);Set(form,"runFolder",root);Set(form,"saveFolder",root);
            Set(form,"selectedDeviceKind",Enum.Parse(form.GetType().GetField("selectedDeviceKind",All).FieldType,"XeNp"));
            Set(form,"npRequestedMode",New("NpCaptureRequest",probeMask,rate));
            Set(form,"npMergeProbeDat",false);Set(form,"npUpsampleAp15To20",false);Set(form,"npRecordMiscSignals",true);
            Set(form,"captureCameraEnabled",false);Set(form,"running",true);
            Exception error=null;activeCapture=true;var worker=new Thread(()=>{try{Call(form,"XeNpCaptureLoop");}catch(Exception e){error=e;}finally{activeCapture=false;}});
            worker.IsBackground=true;worker.Name="V1 production timing capture";
            // Match Form1's production capture thread; the decoder is AboveNormal.
            worker.Priority=ThreadPriority.Highest;report["v1_reader_priority"]=worker.Priority.ToString();
            worker.Start();double next=0;
            while(worker.IsAlive){
                if(N(form,"neuropixelsApRows")>0&&Interlocked.CompareExchange(ref firstData,Stopwatch.GetTimestamp(),0)==0)Log("First decoded data");
                if(Cancel()){Set(form,"ce64StopRequested",true);Set(form,"running",false);}
                if(wall.Elapsed.TotalSeconds>=next){Log("V1 decoded AP rows="+N(form,"neuropixelsApRows"));next=wall.Elapsed.TotalSeconds+15;}
                if(wall.Elapsed.TotalSeconds>seconds+360)throw new TimeoutException("V1 worker did not drain; hardware not reset");
                worker.Join(200);
            }
            if(error!=null)throw error;
        }
        var statusLines=File.ReadAllLines(Path.Combine(root,"neuropixels_capture_status.txt"));
        report["v1_recording_status"]=statusLines;
        // V1's lossless flag also rejects startup trimming, which precedes saved row zero.
        // Preserve that flag; qualify only a complete saved span with no reported mid-stream loss.
        Need(statusLines.Contains("complete=True"),"V1 capture not complete; see retained status");
        foreach(string field in new[]{"usb_sequence_gaps","frame_errors","counter_errors","raw_pool_dropped_wire_bytes"})
            Need(statusLines.Contains(field+"=0"),"V1 reported discontinuity: "+field);
        Need(statusLines.Contains("resolved_probe_mask="+probeMask)&&statusLines.Contains("resolved_ap_sample_rate_hz="+rate),"V1 changed requested timing profile");
        foreach(string line in File.ReadAllLines(Path.Combine(root,"neuropixels_probes.txt")))
            if(new[]{"missing_ap_rows=","missing_lfp_rows=","gap_events=","host_dropped_lane_bytes="}.Any(key=>line.Contains("."+key)))
                Need(line.EndsWith("=0"),"V1 probe discontinuity: "+line);
    }
    static void CheckOptionalStreams(){
        EnforcedGridCurrentEvidence.App=app;
        var grid=EnforcedGridCurrentEvidence.Usb(root,uid);report["scheduled_imu_grid"]=grid;
        Need((bool)grid["imu_data_success"],"Scheduled IMU data invalid; see detailed replay");
        Need(Convert.ToUInt64(grid["sensor_error_rows"])==0,"Scheduled IMU sensor error");
        Need((bool)grid["observed_span_budget_verified"],"Scheduled IMU span too short");
        // Phase and final-tail qualifications remain independent result fields.
        report["scheduled_grid_phase_passed"]=(bool)grid["feature_acceptance_passed"];Need((bool)grid["feature_acceptance_passed"],"Scheduled IMU phase unqualified");
    }
    [STAThread]static int Main(string[] args){
        if(args.Length==2 && args[1]=="--self-test"){
            app=Assembly.LoadFrom(Path.GetFullPath(args[0]));
            Need(app.GetName().Version==new Version(1,0,0,246),"Checked246 required");
            foreach(string n in new[]{"devicePath","runFolder","saveFolder","selectedDeviceKind","npRequestedMode",
                "npMergeProbeDat","npUpsampleAp15To20","npRecordMiscSignals","captureCameraEnabled","running",
                "ce64StopRequested","neuropixelsApRows"})Need(T("Form1").GetField(n,All)!=null,"Missing field "+n);
            Need(T("Form1").GetMethod("XeNpCaptureLoop",All)!=null,"Missing actual capture worker");
            Need(T("NpClosedLoopSettings").GetMethod("Save",All)!=null,"Missing actual CL settings");
            Console.WriteLine("PASS host246 actual fields/worker/settings inspection; no device or settings access");return 0;
        }

        if(args.Length!=8)return 2;root=Path.GetFullPath(args[1]);uid=args[2].ToUpperInvariant();seconds=Int32.Parse(args[3]);
        if(args.Length>=5)rate=Int32.Parse(args[4]);Need(rate==15000||rate==20000||rate==30000,"Explicit15k/20k/30k profile required");
        if(args.Length>=6){Need(args[5]=="v1"||args[5]=="v2","Explicit family v1/v2 required");v1=args[5]=="v1";
            Need(uid.Length==24&&uid.All(Uri.IsHexDigit)&&uid!=new string('0',24)&&uid!=new string('F',24),"Exact verified MCU UID required");}
        else{Need(uid=="001D00065942500B20313354"||uid=="001A0004434250062039314E","Exact reserved UID required");v1=uid=="001D00065942500B20313354";}
        probeMask=Int32.Parse(args[6]);detectors=Int32.Parse(args[7]);Need(v1&&detectors>=0&&detectors<=2,"Exact V1 CL0/1/2 required");
        if(v1)Need(probeMask>=1&&probeMask<=3,"V1 probe mask1/2/3 required");
        else{Need(rate==20000,"V2 HIL requires triple20k profile");probeMask=7;}
        Need(seconds==30||seconds==60,"Bounded30/60-second HIL only");Need(!Directory.Exists(root),"Fresh output required");Directory.CreateDirectory(root);
        app=Assembly.LoadFrom(Path.GetFullPath(args[0]));int original=0,result=1;bool finished=false;
        report["version"]=app.GetName().Version.ToString();report["uid"]=uid;report["requested_seconds"]=seconds;report["requested_sample_rate_hz"]=rate;report["requested_probe_mask"]=probeMask;report["generation"]=v1?1:2;
        try{
            string path=PathNow();object service=Service(path);report["initial_service"]=Fields(service);
            Need(N(service,"Busy")==0&&N(service,v1?"PendingMode":"Target")==0,"Device operation active");
            original=(int)N(service,v1?"Role":"Mode");Need(original==2||original==3,"Idle stream/download personality required");
            Need(new DriveInfo(Path.GetPathRoot(root)).AvailableFreeSpace>=4L*1024*1024*1024,"4 GiB free required before each capture");
            path=Switch(path,2);Log("Same UID admitted in streaming mode");wall=Stopwatch.StartNew();
            StageClosedLoop();V1(path);finished=true;
            Need(firstData!=0,"No data received");report["automatic_time_fit_present"]=File.Exists(Path.Combine(root,"timestamp_calibration.json"));
            report["automatic_time_fit_error"]=File.Exists(Path.Combine(root,"timestamp_calibration_error.txt"));
            CheckOptionalStreams();
            report["result"]="pass";result=0;
        }catch(Exception e){report["result"]="fail";report["error"]=e.ToString();Log(e.ToString());}
        finally{
            try{
                // Never switch/reset away from a still active capture on a failed worker.
                Need(!activeCapture,"Worker still owns USB; no second handle or restore attempted");
                string path=PathNow();object service=Service(path);report["stopped_service"]=Fields(service);
                Need(N(service,"Busy")==0&&N(service,v1?"PendingMode":"Target")==0,"Device remains busy; no restore attempted");
                // HIL: keep stopped stream personality until external post-Stop stats read; no reset here.
                report["final_service"]=Fields(Service(path));report["original_mode_restored"]=original==N(Service(path),v1?"Role":"Mode");
            }catch(Exception e){report["restore_error"]=e.ToString();result=1;}
            try{RestorePreference();}catch(Exception e){report["preference_restore_error"]=e.ToString();result=1;}
            report["recording_worker_returned_successfully"]=finished;
            File.WriteAllText(Path.Combine(root,"experiment.json"),new JavaScriptSerializer{MaxJsonLength=16*1024*1024}.Serialize(report));
        }
        return result;
    }
}



