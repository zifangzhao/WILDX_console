from pathlib import Path
import hashlib,json,re,sys
T=Path(__file__).resolve().parent;role=sys.argv[1];assert role in ('app','usb');suffix=sys.argv[2] if len(sys.argv)>2 else '';assert suffix in ('','-r2','-r3','-r4','-r5','-r6','-r7','-r8','-r8a','-r9','-r11','-r12','-r13','-r14');B=T/f'build-{role}{suffix}';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
r=json.loads((B/'pending.json').read_text());assert h(Path(r['object']))==r['object_sha256']
for p,digest in r['retained_objects'].items():assert h(Path(p))==digest
sys.dont_write_bytecode=True;sys.path.insert(0,'C:/Frank/Code/XE_NP/Tools/V1Capture/ClosedLoopFix');from build_current import seal
identity=seal(role,B);(B/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
regions=[(name,int(base,16),int(size,16),int(limit,16)) for name,base,size,limit in re.findall(r'Execution Region (\S+) \(Exec base: (0x\w+).*?Size: (0x\w+), Max: (0x\w+)',(B/'candidate.map').read_text())]
assert regions and all(size<=limit for name,base,size,limit in regions)
r.update(status='SOFTWARE_CHECKED_PENDING_HARDWARE',identity=identity,regions=regions);(B/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(dict(role=role,crc32=identity['image_crc32'],hex_sha256=identity['sha256'],regions=regions)))
