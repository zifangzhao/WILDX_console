#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "np_store_v2_delete_wire.h"
#pragma warning(disable:4459)
static unsigned checks;
#define CHECK(x) do { checks++; if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);exit(1);} } while(0)
typedef struct {struct {unsigned dma_enable;} Init;} PCD_HandleTypeDef;
typedef struct {uint8_t bmRequest,bRequest;uint16_t wValue,wIndex,wLength;} XE_NP_UsbSetup;
static PCD_HandleTypeDef pcd;
static struct {PCD_HandleTypeDef *hpcd;unsigned configured,streaming,real_start_pending,tx_busy,tx_pending;} xe_np_usb_state;
static struct {uint32_t State;struct {uint32_t LogBlockNbr;} SdCard;uint32_t CID[4];} hsd1;
static struct {uint32_t STA,IDMACTRL,CLKCR;} sdregs;
#define SDMMC1 (&sdregs)
#define SDMMC_STA_DPSMACT 1U
#define SDMMC_STA_CPSMACT 2U
#define SDMMC_IDMA_IDMAEN 1U
#define SDMMC_CLKCR_CLKDIV 1023U
#define HAL_SD_STATE_READY 1U
#define HAL_OK 0
#define RCC_PERIPHCLK_SDMMC 0U
#define RCC_MCO1 0U
#define RCC_MCO1SOURCE_NOCLOCK 0U
#define RCC_MCODIV_1 0U
#define SDMMC1_IRQn 0U
#define __DMB() ((void)0)
#define __HAL_RCC_SRAM5_CLK_ENABLE() ((void)0)
static uint32_t np_usb_sd_prepare_pending,np_usb_sd_ready,np_download_epoch,np_download_state,np_download_burst_armed;
static uint32_t xe_np_usb_v1_restart_pending;
static struct {unsigned target;} np_v1_mode;
static Nps2DeleteWire np_usb_delete;
static uint8_t np_usb_delete_rx[128];static uint32_t np_usb_delete_ep0[32];
static uint32_t np_usb_delete_receiving,np_usb_delete_rx_bytes,np_usb_delete_auto_running,np_usb_delete_clock_held;
static unsigned is_download,ready,other_owner,init_failure,callbacks,statuses,stalls,receives,init_calls,irq_calls;
static uint32_t __get_PRIMASK(void){return 0U;}
static void __disable_irq(void){}
static void __set_PRIMASK(uint32_t p){(void)p;}
static uint32_t HAL_GetUIDw0(void){return 1U;}
static uint32_t HAL_GetUIDw1(void){return 2U;}
static uint32_t HAL_GetUIDw2(void){return 3U;}
static uint32_t HAL_RCCEx_GetPeriphCLKFreq(uint32_t p){(void)p;return 100000000U;}
static void HAL_RCC_MCOConfig(unsigned a,unsigned b,unsigned c){CHECK(!a&&!b&&!c);}
static int NP_USB_IsDownload(void){return is_download!=0U;}
static int NP_USB_IsReady(void){return ready!=0U;}
static int NP_ConfigTransferPending(void){return 0;}
static int NP_USB20_SelectionPending(void){return 0;}
static int np_v1_sd_reset_busy(void){return 0;}
static int np_usb_sd_info_owned(void){return 0;}
static int np_usb_catalog_owned(void){return other_owner!=0U;}
static int np_usb_format_owned(void){return 0;}
static int NP_V1UsbJob_Owns(void){return 0;}
static int NP_V1UsbJob_ModeFence(void){return 0;}
static void XE_NP_UsbStream_Stall(PCD_HandleTypeDef *p){CHECK(p==&pcd);stalls++;}
static void XE_NP_UsbStream_CtlStatus(PCD_HandleTypeDef *p){CHECK(p==&pcd);statuses++;}
static int XE_NP_UsbStream_CtlSend(PCD_HandleTypeDef *p,const uint8_t *b,uint32_t n,uint32_t r){CHECK(p==&pcd&&b&&n==128U&&r==128U);return 0;}
static void XE_NP_Capture_DCacheInvalidate(const void *p,uint32_t n){CHECK(p&&n==128U);}
static int HAL_PCD_EP_Receive(PCD_HandleTypeDef *p,uint32_t ep,uint8_t *b,uint32_t n){CHECK(p==&pcd&&!ep&&b&&n==64U);receives++;return HAL_OK;}
static int NP_USB_ReinitializeSd(void);
static void HAL_NVIC_DisableIRQ(unsigned irq);
#include "actual_readiness.inc"
static void inspect(unsigned expect_accept){
 XE_NP_UsbSetup r={0x40U,0xA7U,1U,0U,0U};unsigned before=stalls;
 CHECK(np_usb_delete_request(&pcd,&r));
 if(expect_accept){CHECK(statuses==1U&&stalls==before&&np_usb_delete.queued==1U&&np_usb_delete.last_nonce==1U);CHECK(np_usb_delete.report[8]==262144U&&np_usb_delete.report[3]==1U);}
 else {CHECK(stalls==before+1U&&!statuses&&!np_usb_delete.queued&&!np_usb_delete.last_nonce);CHECK(np_usb_delete.report[3]!=1U);}
}
static void during_prepare(void){
 CHECK(np_usb_sd_prepare_pending==1U&&np_v1_mode_busy());
 inspect(0U);CHECK(!np_usb_delete.queued);callbacks++;
}
static int NP_USB_ReinitializeSd(void){
 init_calls++;CHECK(np_usb_sd_prepare_pending==1U);during_prepare();
 hsd1.State=HAL_SD_STATE_READY;hsd1.SdCard.LogBlockNbr=262144U;
 for(unsigned i=0;i<4U;i++)hsd1.CID[i]=10U+i;
 during_prepare();return init_failure?-1:0;
}
static void HAL_NVIC_DisableIRQ(unsigned irq){CHECK(!irq);during_prepare();irq_calls++;}
static void reset(void){
 memset(&np_usb_delete,0,sizeof(np_usb_delete));memset(&hsd1,0,sizeof(hsd1));memset(&sdregs,0,sizeof(sdregs));
 xe_np_usb_state.hpcd=&pcd;xe_np_usb_state.configured=1U;ready=is_download=1U;
 np_usb_sd_prepare_pending=1U;np_usb_sd_ready=0U;np_download_epoch=7U;
 np_usb_delete_receiving=np_usb_delete_rx_bytes=np_usb_delete_auto_running=np_usb_delete_clock_held=0U;
 callbacks=statuses=stalls=receives=init_calls=irq_calls=init_failure=other_owner=0U;
}
int main(void){
 reset();NP_USB_PrepareDownload();CHECK(callbacks==3U&&init_calls==1U&&irq_calls==1U&&np_usb_sd_ready&&!np_usb_sd_prepare_pending);CHECK(!np_v1_mode_busy());inspect(1U);CHECK(np_v1_mode_busy()&&!receives);
 reset();init_failure=1U;NP_USB_PrepareDownload();CHECK(!np_usb_sd_ready&&!np_usb_sd_prepare_pending&&hsd1.State==HAL_SD_STATE_READY);inspect(0U);CHECK(!np_usb_delete.queued);
 reset();np_usb_sd_prepare_pending=0U;hsd1.State=HAL_SD_STATE_READY;inspect(0U);
 reset();np_usb_sd_prepare_pending=0U;np_usb_sd_ready=1U;hsd1.State=2U;inspect(0U);
 reset();np_usb_sd_prepare_pending=0U;np_usb_sd_ready=1U;hsd1.State=HAL_SD_STATE_READY;other_owner=1U;inspect(0U);
 printf("PASS actual readiness checks %u; initializer+post-ready-before-IRQ callbacks Busy/refuse A7; no zero-capacity queue; READY Inspect admitted; failed init/unready/active owner refused; SDInfo predicate unchanged\n",checks);
 return 0;
}
