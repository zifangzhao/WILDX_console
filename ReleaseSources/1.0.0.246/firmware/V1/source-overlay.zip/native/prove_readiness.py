from datetime import datetime, timezone
import hashlib, json, re, subprocess, time
from pathlib import Path

root = Path(__file__).resolve().parent
t = Path('C:/Frank/Code/XE_NP/_artifacts/v1_delete_last_20261105')
out = root / 'readiness1'
assert not out.exists()
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
def function(text, name):
    m = re.search(r'(?m)^(?:static )?(?:int|void|uint32_t) '+name+r'\(', text)
    assert m, name
    at = text.index('{', m.end())+1; depth = 1
    while depth:
        depth += (text[at] == '{') - (text[at] == '}'); at += 1
    return text[m.start():at]
backend=t/'usb-source/backend.inc'; delete=t/'usb-source/delete.inc'
modes=t/'usb-source/modes.inc'; info=t/'usb-source/np_sd_info_v1_service.inc'
assert sha(backend)=='045FE1100A82A83DF8E675BC493AC4A8287A710CD192B90439055864BFF566D7'
assert sha(delete)=='61F83308562B98986662B666001FC534619DA0CC9121738BBE3134936391F7F1'
old=json.loads((root/'initializer2/receipt.json').read_text())
assert sha(info)==old['caller_source_pins'][str(info).replace('/', '\\')]
bt,dt,mt,it=[p.read_text() for p in [backend,delete,modes,info]]
actual='\n\n'.join([
    function(dt,'np_usb_delete_owned'),function(it,'np_info_idle'),
    function(dt,'np_usb_delete_admit'),function(dt,'np_usb_delete_card'),
    function(dt,'np_usb_delete_setup'),function(dt,'np_usb_delete_request'),
    function(mt,'np_v1_mode_busy'),function(bt,'NP_USB_PrepareDownload')])+'\n'
out.mkdir();(out/'actual_readiness.inc').write_text(actual)
for name in ['np_store_v2.h','np_store_v2_delete.h','np_store_v2_delete_wire.h','np_sd_fast_crc.h']:
    (out/name).write_bytes((t/'core'/name).read_bytes())
(out/'fixture.c').write_bytes((root/'readiness_fixture.c').read_bytes())
vc='C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat'
cmd=f'call "{vc}" >nul && cl /nologo /std:c11 /W4 /WX /wd4505 /TC /O2 /I"{out}" "{out}/fixture.c" /Fo"{out}/fixture.obj" /Fe"{out}/fixture.exe"'
started=datetime.now(timezone.utc).isoformat(); watch=time.perf_counter()
(out/'command.txt').write_text(cmd+'\n')
build=subprocess.run('cmd /d /s /c "'+cmd+'"',cwd=out,capture_output=True,text=True,timeout=60)
(out/'compile.log').write_text(build.stdout+build.stderr)
assert build.returncode==0,build.stdout+build.stderr
run=subprocess.run([str(out/'fixture.exe')],cwd=out,capture_output=True,text=True,timeout=30)
(out/'result.txt').write_text(run.stdout+run.stderr);print(run.stdout+run.stderr,end='');assert run.returncode==0
receipt={'status':'PASS','started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),
 'seconds':time.perf_counter()-watch,'source_pins':{str(p):sha(p) for p in [backend,delete,modes,info,t/'usb-source/stream.c']},
 'actual_functions_sha256':sha(out/'actual_readiness.inc'),'result_sha256':sha(out/'result.txt'),
 'sdinfo_source_unchanged_from_initializer889':True,
 'scope':'Actual PrepareDownload, A7 request/admission/card/owned, mode Busy and unchanged SDInfo idle predicate; callbacks inside mocked initializer and IRQ-disable; real unchanged store/wire headers. No hardware, firmware/app build, broad suite rerun or shared product edits.'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('receipt',out/'receipt.json',sha(out/'receipt.json'))
