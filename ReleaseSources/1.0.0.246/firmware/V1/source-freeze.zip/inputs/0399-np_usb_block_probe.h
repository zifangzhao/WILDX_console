#ifndef NP_USB_BLOCK_PROBE_H
#define NP_USB_BLOCK_PROBE_H
/* Diagnostic only: no clock/payload/register writes. Define=1 only in the
 * staged candidate. Counter spans are unsigned32 and must be <one DWT wrap.
 * Short masked max-record publication is excluded from measured spans. */
#ifndef NP_USB_BLOCK_PROBE
#define NP_USB_BLOCK_PROBE 0
#endif
#if NP_USB_BLOCK_PROBE
#include <stdint.h>
#include <string.h>

enum {
    NP_UB_NONE, NP_UB_ORIGINAL, NP_UB_BUILDER, NP_UB_SENSORS, NP_UB_RTC,
    NP_UB_CONFIG, NP_UB_QUEUE, NP_UB_CLEAN, NP_UB_INVALIDATE, NP_UB_SERVICE,
    NP_UB_OUTSIDE, NP_UB_MODE, NP_UB_FORMAT, NP_UB_FIRST_SOURCE_FAILURE, NP_UB_SITES
};
#define NP_UB_UNKNOWN_RESULT UINT32_C(0x80000000)
#define NP_UB_NO_RESULT UINT32_C(0xffffffff)
typedef struct {
    uint32_t cycles, hal_ms, site, parent, address, size, sr_before, sr_after;
    uint32_t result, context_enter, context_exit, start_hal;
} NpUsbBlockRecord;
typedef struct {
    uint32_t magic, version, bytes, generation, active, parent, inside_service;
    uint32_t outside_cycle, outside_hal, outside_context, outside_valid, cache_errors;
    uint32_t max_cycles[NP_UB_SITES];
    NpUsbBlockRecord inside, outside, cache;
} NpUsbBlockProbe;
typedef struct {
    uint32_t cycle, hal, site, parent, address, size, sr, context, generation, enabled;
} NpUsbBlockStamp;
_Static_assert(sizeof(NpUsbBlockProbe) == 248U, "USB block diagnostic layout");
/* context bit0=PRIMASK; bits1..9=IPSR. Cache result is exact HAL status for
 * CleanTx. Invalidate is frozen external void: bit31 marks UNKNOWN HAL return,
 * low bits retain handle.ErrorCode AFTER the call (possibly pre-existing).
 * cache keeps maximum cache span until the FIRST observed error, then freezes
 * that error tuple; max_cycles still advances. No success is invented. */
void NP_UsbBlockPrelaunchZero(uint32_t reason);
void NP_UsbBlockSourceFailure(uint32_t fault,uint32_t lane,uint32_t available,uint32_t requested,uint32_t head,
    uint32_t previous,uint32_t hal_gap,uint32_t now,uint32_t claimed);
extern volatile NpUsbBlockProbe np_usb_block_probe;
extern NpUsbBlockStamp (*np_usb_block_begin)(uint32_t,uint32_t,uint32_t,uint32_t);
extern void (*np_usb_block_end)(NpUsbBlockStamp,uint32_t,uint32_t);
static inline NpUsbBlockStamp NP_UsbBlockBegin(uint32_t s,uint32_t a,uint32_t n,uint32_t sr)
{ return np_usb_block_begin(s,a,n,sr); }
static inline void NP_UsbBlockEnd(NpUsbBlockStamp s,uint32_t result,uint32_t sr)
{ np_usb_block_end(s,result,sr); }

#ifdef NP_USB_BLOCK_PROBE_OWNER
volatile NpUsbBlockProbe np_usb_block_probe;
static uint32_t NP_UsbBlockContext(void)
{ return (__get_PRIMASK() & 1U) | ((__get_IPSR() & 511U) << 1U); }
static NpUsbBlockStamp NP_UsbBlockBeginNone(uint32_t s,uint32_t a,uint32_t n,uint32_t sr)
{ NpUsbBlockStamp t={0};(void)s;(void)a;(void)n;(void)sr;return t; }
static void NP_UsbBlockEndNone(NpUsbBlockStamp t,uint32_t result,uint32_t sr)
{ (void)t;(void)result;(void)sr; }
static NpUsbBlockStamp NP_UsbBlockBeginActive(uint32_t site,uint32_t address,uint32_t size,uint32_t sr)
{
    NpUsbBlockStamp t={0};uint32_t context=NP_UsbBlockContext();
    uint32_t mask=__get_PRIMASK();__disable_irq();
    if(np_usb_block_probe.active && site<NP_UB_SITES){
        t.site=site;t.parent=np_usb_block_probe.parent;t.generation=np_usb_block_probe.generation;
        t.address=address;t.size=size;t.sr=sr;t.context=context;t.enabled=1U;
        np_usb_block_probe.parent=site;
    }
    __set_PRIMASK(mask);
    t.hal=HAL_GetTick();t.cycle=DWT->CYCCNT;
    return t;
}
static void NP_UsbBlockEndActive(NpUsbBlockStamp t,uint32_t result,uint32_t sr)
{
    if(!t.enabled)return;
    uint32_t cycle=DWT->CYCCNT,hal=HAL_GetTick(),context=NP_UsbBlockContext();
    NpUsbBlockRecord r={cycle-t.cycle,hal-t.hal,t.site,t.parent,t.address,t.size,t.sr,sr,
                        result,t.context,context,t.hal};
    uint32_t mask=__get_PRIMASK();__disable_irq();
    if(np_usb_block_probe.active && np_usb_block_probe.generation==t.generation){
        if(t.site!=NP_UB_NONE && t.site!=NP_UB_FIRST_SOURCE_FAILURE && r.cycles>np_usb_block_probe.max_cycles[t.site])np_usb_block_probe.max_cycles[t.site]=r.cycles;
        if(t.site==NP_UB_OUTSIDE){
            if(np_usb_block_probe.outside.site!=NP_UB_FIRST_SOURCE_FAILURE && r.cycles>np_usb_block_probe.outside.cycles)np_usb_block_probe.outside=r;
        }else if(t.site!=NP_UB_SERVICE && t.site!=NP_UB_ORIGINAL && r.cycles>np_usb_block_probe.inside.cycles)
            np_usb_block_probe.inside=r;
        if(t.site==NP_UB_CLEAN || t.site==NP_UB_INVALIDATE){
            uint32_t error=(sr&4U) || (result!=NP_UB_NO_RESULT && (result&~NP_UB_UNKNOWN_RESULT));
            if(error){
                if(!np_usb_block_probe.cache_errors)np_usb_block_probe.cache=r;
                if(np_usb_block_probe.cache_errors!=UINT32_MAX)++np_usb_block_probe.cache_errors;
            }else if(!np_usb_block_probe.cache_errors && r.cycles>np_usb_block_probe.cache.cycles)
                np_usb_block_probe.cache=r;
        }
        np_usb_block_probe.parent=t.parent;
    }
    __set_PRIMASK(mask);
}
NpUsbBlockStamp (*np_usb_block_begin)(uint32_t,uint32_t,uint32_t,uint32_t)=NP_UsbBlockBeginNone;
void (*np_usb_block_end)(NpUsbBlockStamp,uint32_t,uint32_t)=NP_UsbBlockEndNone;
static void NP_UsbBlockSelect(uint32_t active,uint32_t generation)
{
    uint32_t mask=__get_PRIMASK();__disable_irq();
    np_usb_block_begin=NP_UsbBlockBeginNone;np_usb_block_end=NP_UsbBlockEndNone;
    if(active){
        memset((void *)&np_usb_block_probe,0,sizeof(np_usb_block_probe));
        np_usb_block_probe.magic=0x314b4255U;np_usb_block_probe.version=4U;
        np_usb_block_probe.bytes=sizeof(np_usb_block_probe);np_usb_block_probe.generation=generation;
        np_usb_block_probe.active=1U;
        np_usb_block_begin=NP_UsbBlockBeginActive;np_usb_block_end=NP_UsbBlockEndActive;
    }else np_usb_block_probe.active=0U; /* Keep completed maxima frozen. */
    __set_PRIMASK(mask);
}
static NpUsbBlockStamp NP_UsbBlockServiceEnter(void)
{
    if(np_usb_block_probe.active){
        if(np_usb_block_probe.outside_valid){
            NpUsbBlockStamp t={np_usb_block_probe.outside_cycle,np_usb_block_probe.outside_hal,
                NP_UB_OUTSIDE,0U,0U,0U,0U,np_usb_block_probe.outside_context,np_usb_block_probe.generation,1U};
            NP_UsbBlockEnd(t,NP_UB_NO_RESULT,0U);
        }
        np_usb_block_probe.outside_valid=0U;np_usb_block_probe.inside_service=1U;
    }
    return NP_UsbBlockBegin(NP_UB_SERVICE,0U,0U,0U);
}
static void NP_UsbBlockServiceLeave(NpUsbBlockStamp t)
{
    NP_UsbBlockEnd(t,NP_UB_NO_RESULT,0U);
    uint32_t context=NP_UsbBlockContext();
    uint32_t mask=__get_PRIMASK();__disable_irq();
    if(t.enabled && np_usb_block_probe.active && np_usb_block_probe.generation==t.generation){
        np_usb_block_probe.inside_service=0U;np_usb_block_probe.outside_cycle=DWT->CYCCNT;
        np_usb_block_probe.outside_hal=HAL_GetTick();np_usb_block_probe.outside_context=context;
        np_usb_block_probe.outside_valid=1U;
    }
    __set_PRIMASK(mask);
}
#endif /* OWNER */
#endif /* NP_USB_BLOCK_PROBE */
#endif
