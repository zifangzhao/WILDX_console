#include <assert.h>
#include <stdio.h>
#include "np_store_v2.h"
static unsigned char card[8192][512];
static int rd(uint32_t l,uint8_t *b){if(l>=8192)return -1;memcpy(b,card[l],512);return 0;}
static int wr(uint32_t l,const uint8_t *b){if(l>=8192)return -1;memcpy(card[l],b,512);return 0;}
int main(void){
 Nps2State s;Nps2Delete d,q;uint8_t cid[16]={1},journal[512];
 assert(!nps2_format(&s,1048576,123,rd,wr));
 for(unsigned i=0;i<3;i++){assert(!nps2_begin(&s,s.frontier+16384,100+i,rd,wr));assert(!nps2_finish(&s,s.end-10,1,rd,wr));}
 assert(s.count==3);assert(!nps2_delete_inspect(&d,s.capacity,cid,rd));d.nonce=1;
 assert(nps2_delete_shape(&d));nps2_delete_encode(journal,&d);assert(nps2_delete_decode(&q,journal));assert(nps2_delete_shape(&q));
 assert(!nps2_delete_confirmed(&s,&d,2,1048576,cid,rd,wr));assert(s.count==2&&s.frontier==40960);
 assert(!nps2_mount(&s,1048576,rd));assert(s.count==2);
 assert(!nps2_begin(&s,s.frontier+16384,400,rd,wr));assert(!nps2_finish(&s,s.end-10,1,rd,wr));
 puts("PASS three-record delete, journal encode/decode, old strict mount and append");return 0;
}
