"""One guarded USB-only replacement after the diagnosed completed-read pin."""
from pathlib import Path
import hashlib,importlib.util,json,re,struct,subprocess,sys
sys.dont_write_bytecode=True
import bench_hil as b
sys.path.insert(0,'C:/Frank/Code/XE_NP/Tools/V1Capture/ClosedLoopFix')
import ap_snapshot as a
a.PHASE=b.c.PHASE;T=Path(__file__).resolve().parent;F=b.c.PHASE/'pair-r6-r12';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper();word=lambda x,o=0:x[0] if len(x)==1 and o==0 else struct.unpack_from('<I',x,o)[0]
mapping=(T/'build-usb-r10/candidate.map').read_text()
def symbol(n):
 m=re.search(r'^\s*'+n+r'\s+0x([0-9a-fA-F]+)\s+Data\s+(\d+)\b',mapping,re.M);assert m,n;return int(m[1],16),int(m[2])
def held():
 p,_,_=b.c.setup();return p.prior.held(b.c.PHASE)
if sys.argv[1]=='prepare':
 held();ranges={'uid':(0x0bfa0700,12),'vtor':(0xe000ed08,4),'flash':(0x08000000,0x200000),'options':(0x40022040,48),'bkp':(0x46007d00,128),'sdmmc':(0x420c8000,160),'dma':(0x40020000,2048),'core':(0xe000edf0,4),'hsd':symbol('hsd1'),'delete':symbol('np_usb_delete'),'clockheld':symbol('np_usb_delete_clock_held'),'porterror':symbol('np_usb_delete_port_error'),'npstate':symbol('np_download_state')}
 if (F/'receipt.json').exists():
  receipt=json.loads((F/'receipt.json').read_text());assert receipt['result']=='PASS' and receipt['holder_pid']==held()['holder_pid'];raw={n:(F/(n+'.bin')).read_bytes() for n in ranges}
 else:raw=a.collect(F,ranges,b.c.SERIAL)
 assert raw['flash']==(b.c.PHASE/'usb-stack-fix/flash_after.bin').read_bytes()
 assert h(F/'flash.bin')=='F4660B878C6A6D480B36E72B9F8E1561CEC05BB02105253F95C30934A9A91BE4'
 assert raw['options']==(b.c.PHASE/'original_options.bin').read_bytes()
 assert word(raw['core'])&1==0 and word(raw['clockheld'])==0 and word(raw['porterror'])==0 and word(raw['npstate'])==0
 assert not word(raw['delete'],len(raw['delete'])-12) and not word(raw['delete'],len(raw['delete'])-8) and word(raw['hsd'],48)==1 and word(raw['hsd'],52)==1 and word(raw['hsd'],56)==0
 assert word(raw['sdmmc'],0x34)==0 and word(raw['sdmmc'],0x58)==0 and word(raw['sdmmc'],0x30)==0 and not word(raw['sdmmc'],0x2c)&1
 assert word(raw['sdmmc'],8)==65536 and word(raw['sdmmc'],0x10)==13 and word(raw['sdmmc'],0x14)==0x900
 assert all(not word(raw['dma'],0x64+i*0x80)&1 for i in range(16))
 assert b.c.nonzero_profile(raw['bkp'])==b.c.nonzero_profile((b.c.PHASE/'backup_registers.bin').read_bytes())
 spec=importlib.util.spec_from_file_location('usb_delta','C:/Frank/Code/XE_NP/Tools/V1Capture/Timing/prepare_anchor_hil.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 usb=T/'build-usb-r12/USB_TEST_ONLY.hex';app=T/'build-app-r6/APP_TEST_ONLY.hex';plan=m.plan(F/'flash.bin',[app,usb],F/'plan')
 assert all(0x0801e000<=int(p,16)<0x08200000 for p in plan['pages'])
 after=(F/'plan/expected_flash.bin').read_bytes();assert after[:0x1e000]==raw['flash'][:0x1e000]
 source='''init
targets stm32u5.cpu
set u [read_memory 0x0BFA0700 32 3]
if {[format "%08X%08X%08X" [lindex $u 0] [lindex $u 1] [lindex $u 2]] ne "001D00065942500B20313354"} {error "WrongUID"}
if {[lindex [read_memory 0xe000ed08 32 1] 0] != 0x08180000} {error "WrongRole"}
if {[lindex [read_memory 0x420c8034 32 1] 0] != 0 || [lindex [read_memory 0x420c8058 32 1] 0] != 0 || [lindex [read_memory 0x420c8030 32 1] 0] != 0} {error "SDactive"}
for {set i 0} {$i<16} {incr i} {if {[lindex [read_memory [expr {0x40020064+$i*0x80}] 32 1] 0]&1} {error "DMAactive"}}
set options [read_memory 0x40022040 32 12]
halt
wait_halt 3000
verify_image {BEFORE} 0x08000000 bin
flash write_image erase {PATCH}
verify_image {AFTER} 0x08000000 bin
dump_image {POSTFLASH} 0x08000000 0x200000
dump_image {POSTOPTIONS} 0x40022040 48
if {[read_memory 0x40022040 32 12] ne $options} {error "Optionschanged"}
reset run
sleep 500
poll off
mww 0xe000edf0 0xa05f0000
echo "V1_MATCHED_DELETE_PAIR_VERIFIED"
shutdown
'''
 for key,path in {'BEFORE':F/'flash.bin','PATCH':F/'plan/install_pages.hex','AFTER':F/'plan/expected_flash.bin','POSTFLASH':F/'flash_after.bin','POSTOPTIONS':F/'options_after.bin'}.items():source=source.replace(key,path.as_posix())
 (F/'replace.tcl').write_text(source)
 command=[str(a.OPENOCD),'-s',str(a.SCRIPTS),'-f','interface/stlink-dap.cfg','-c','adapter serial '+b.c.SERIAL,'-c','transport select dapdirect_swd','-f','target/stm32u5x.cfg','-c','adapter speed 1000','-c','stm32u5.cpu configure -event examine-end {}','-c','gdb_port disabled','-c','tcl_port disabled','-c','telnet_port disabled','-f',str(F/'replace.tcl')]
 (F/'replacement.json').write_text(json.dumps(dict(command=command,preimage_sha256=h(F/'flash.bin'),expected_sha256=h(F/'plan/expected_flash.bin'),usb_sha256=h(usb),app_unchanged=False,boot_config_unchanged=True,no_sd_writes=True,scope='Known completed read-only polling context pin; every SD/DMA engine idle before halt/flash'),indent=2)+'\n');print(json.dumps(plan))
elif sys.argv[1]=='install':
 held();r=json.loads((F/'replacement.json').read_text());assert not (F/'replace-started.json').exists();(F/'replace-started.json').write_text(json.dumps(dict(holder=held(),usb_crc32='019438C8')))
 run=subprocess.run(r['command'],capture_output=True,text=True,timeout=180);log=run.stdout+run.stderr;(F/'replace.log').write_text(log)
 assert run.returncode==0 and 'V1_MATCHED_DELETE_PAIR_VERIFIED' in log,log
 assert (F/'flash_after.bin').read_bytes()==(F/'plan/expected_flash.bin').read_bytes() and (F/'options_after.bin').read_bytes()==(F/'options.bin').read_bytes()
 result=dict(verified=True,uid=b.c.UID,app_crc32='4A677F83',usb_crc32='019438C8',whole_flash_sha256=h(F/'flash_after.bin'),options_sha256=h(F/'options_after.bin'),boot_config_unchanged=True,sd_writes=False)
 (F/'verified.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
else:raise SystemExit('prepare|install')
