from pathlib import Path
import hashlib,json
T=Path(__file__).resolve().parent;h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
pair={r:json.loads((T/f"build-{r}-{'r6' if r=='app' else 'r12'}/identity.json").read_text()) for r in ('app','usb')}
v=T/'bench/pair-r6-r12/verified.json';r=json.loads(v.read_text());assert r['verified'] and r['app_crc32']==pair['app']['image_crc32'] and r['usb_crc32']==pair['usb']['image_crc32']
(T/'matched-test-pair.json').write_text(json.dumps(pair,indent=2)+'\n')
i=json.loads((T/'helper-inputs.json').read_text());i.update(pair=pair,final_matched_installation_sha256=h(v));(T/'helper-inputs.json').write_text(json.dumps(i,indent=2)+'\n')
p=T/'pins.py';s=p.read_text().replace('owner-sd-preflight-v4','owner-sd-preflight-v5').replace('usb-stack-fix','pair-r6-r12').replace('sd-map/mapping.json','sd-map-r6/mapping.json');p.write_text(s)
for n in ('bench_stop.py','diag_usb.py'):
 p=T/n;s=p.read_text();s=s.replace('build-usb-r10/candidate.map','build-usb-r12/candidate.map').replace('build-usb-r9/candidate.map','build-usb-r12/candidate.map');p.write_text(s)
for n in ('bench_sd_stop.py','diag_app.py'):
 p=T/n;p.write_text(p.read_text().replace('build-app-r4/candidate.map','build-app-r6/candidate.map'))
p=T/'sd-harness/NpSdDownloadControl.cs';p.write_text(p.read_text().replace('38B15A11','4A677F83').replace('C9DF45FE','019438C8'))
print(json.dumps({r:pair[r]['image_crc32'] for r in pair}))
