"""Replace only the exact retained CE32 UART object; provider38B unchanged."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;source=Path(sys.argv[1]);B=T/'build-app-r6';assert not B.exists();B.mkdir()
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
r=json.loads((T/'build-app-r4/receipt.json').read_text());args=list(r['compiler_command'])
args[args.index(r['source'])]=str(source);args[args.index('-o')+1]=str(B/'ce32_uart_intercom_npconfig.o')
args.insert(1,'-IC:/Frank/Code/XE_NP/Firmware/V1/Core/Inc');args.insert(1,'-IC:/Frank/Code/XE_NP/Firmware/V1/Core/Src')
run=subprocess.run(args,cwd=r['compiler_cwd'],capture_output=True,text=True);(B/'compile.log').write_text(run.stdout+run.stderr);assert run.returncode==0,run.stdout+run.stderr
old=next(p for p in r['retained_objects'] if Path(p).name=='ce32_uart_intercom_npconfig.o');assert h(old)=='16B59D8860E5B7EF1B31A616E425E5E9B177C5B19C35E4FF3A2D21A67984139D'
lnp=(T/'build-app-r4/candidate.lnp').read_text().replace(Path(old).as_posix(),(B/'ce32_uart_intercom_npconfig.o').as_posix())
for n in ('candidate.map','candidate.axf','candidate.sct'):lnp=lnp.replace((T/'build-app-r4'/n).as_posix(),(B/n).as_posix())
(B/'candidate.lnp').write_text(lnp);(B/'candidate.sct').write_bytes((T/'build-app-r4/candidate.sct').read_bytes())
objects={str(Path(p)):h(p) for p in re.findall(r'"([^"]+\.o)"',lnp) if Path(p)!=B/'ce32_uart_intercom_npconfig.o'}
receipt=dict(status='COMPILED_PENDING_LINK',role='app',parent_crc32='38B15A11',compiler_command=args,compiler_cwd=r['compiler_cwd'],source=str(source),source_sha256=h(source),object=str(B/'ce32_uart_intercom_npconfig.o'),object_sha256=h(B/'ce32_uart_intercom_npconfig.o'),retained_objects=objects,scatter=str(B/'candidate.sct'),scatter_sha256=h(B/'candidate.sct'),replaced_preimage_object=old,replaced_preimage_sha256=h(old),unchanged_provider_sha256=r['object_sha256'])
(B/'pending.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(dict(status=receipt['status'],source_sha256=h(source),object_sha256=receipt['object_sha256'])))
