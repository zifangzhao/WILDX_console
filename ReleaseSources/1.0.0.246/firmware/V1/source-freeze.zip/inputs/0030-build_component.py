import hashlib,json,re,subprocess,sys
from pathlib import Path
T=Path(__file__).resolve().parent;P=Path('C:/Frank/Code/XE_NP/_artifacts/v1_gui_support_20261105')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
role=sys.argv[1];assert role in ('app','usb');suffix=sys.argv[2] if len(sys.argv)>2 else '';assert suffix in ('','-r2','-r3','-r4','-r5','-r6','-r7','-r8','-r8a','-r9','-r11','-r12');B=T/f'build-{role}{suffix}';B.mkdir(exist_ok=False)
old=P/f'build-{role}';parent=json.loads((old/'receipt.json').read_text());args=list(parent['compiler_command']);source=T/('app-source/provider.c' if role=='app' else 'usb-source/stream.c');obj=B/('provider.o' if role=='app' else 'stream.o')
args[args.index(parent['source'])]=str(source);args[args.index('-o')+1]=str(obj)
if role=='usb':
 app_suffix='-r6' if suffix in ('-r11','-r12') else '-r4' if suffix in ('-r5','-r6','-r7','-r8','-r8a','-r9','-r11','-r12') else suffix
 crc=json.loads((T/f'build-app{app_suffix}/identity.json').read_text())['image_crc32'];gate='-DNP_USB_SD_JOB_APP_CRC=0xD05473D6U';assert args.count(gate)==1;args[args.index(gate)]=f'-DNP_USB_SD_JOB_APP_CRC=0x{crc}U'
cwd=Path(parent.get('compiler_cwd',str(T/'app-source')))
r=subprocess.run(args,cwd=cwd,capture_output=True,text=True);(B/'compile.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
lnp=(old/'candidate.lnp').read_text();oldobj=(old/obj.name).as_posix();assert lnp.count(oldobj)==1;lnp=lnp.replace(oldobj,obj.as_posix())
lnp=re.sub(r'--list\s+"[^"]+"','--list "'+(B/'candidate.map').as_posix()+'"',lnp);lnp=re.sub(r'-o\s+"[^"]+"','-o "'+(B/'candidate.axf').as_posix()+'"',lnp)
scatter=Path(re.search(r'--scatter\s+"([^"]+)"',lnp)[1]);text=scatter.read_text();target=B/'candidate.sct'
if role=='app':
 assert text.count('{ *(NP_SD_TRACE) }')==1;text=text.replace('{ *(NP_SD_TRACE) }','{ *(NP_SD_TRACE) *(NP_DELETE_STATE) }')
target.write_text(text);lnp=lnp.replace(scatter.as_posix(),target.as_posix());(B/'candidate.lnp').write_text(lnp)
if role=='usb' and suffix in ('-r11','-r12'):
 lnp=lnp.replace('C:/Frank/Code/XE_NP/_artifacts/v1_usb_auto_sd_r78_20261005/source/MDK-ARM/USB384_NP_BGA_MMC/startup_stm32u595xx.o',(T/'build-usb-r10/startup_stm32u595xx.o').as_posix());(B/'candidate.lnp').write_text(lnp)
objects=[Path(s) for s in re.findall(r'"([^"]+\.o)"',lnp) if Path(s)!=obj]
receipt=dict(status='COMPILED_PENDING_LINK',role=role,parent_crc32='D05473D6' if role=='app' else '71AE291B',compiler_command=args,compiler_cwd=str(cwd),source=str(source),source_sha256=h(source),object=str(obj),object_sha256=h(obj),retained_objects={str(p):h(p) for p in objects},scatter=str(target),scatter_sha256=h(target))
if role=='usb':receipt['expected_app_crc32']=crc
(B/'pending.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k] for k in ('status','role','object_sha256')}))
