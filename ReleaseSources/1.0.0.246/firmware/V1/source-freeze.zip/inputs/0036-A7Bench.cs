using System;using System.Collections;using System.Collections.Generic;using System.Configuration;using System.Globalization;using System.IO;using System.Linq;using System.Reflection;using System.Security.Cryptography;using System.Threading;using System.Threading.Tasks;using System.Web.Script.Serialization;using System.Windows.Forms;
static class A7Bench {
 const BindingFlags All=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static;
 const string Uid="001D00065942500B20313354",HostHash="FA744968A3DE0AC9A87F6FD77F8F3ED40BFAB3FBD062ABD9B33BEE3E233E8953";
 static Assembly app;static string output;static int exit=1;static readonly JavaScriptSerializer J=new JavaScriptSerializer{MaxJsonLength=32*1024*1024};static readonly Dictionary<string,object> R=new Dictionary<string,object>();
 static object form,connection;static int epoch;static ulong address;static ApplicationSettingsBase settings;static Dictionary<string,object> oldSettings;
 static void Need(bool ok,string why){if(!ok)throw new IOException(why);}static Type T(string n){return app.GetType(n.Contains(".")?n:"USB512_interface."+n,true);}
 static object Get(object x,string n){var f=x.GetType().GetField(n,All);return f!=null?f.GetValue(x):x.GetType().GetProperty(n,All).GetValue(x,null);}static uint U(object x,string n){return Convert.ToUInt32(Get(x,n));}static void Set(object x,string n,object v){x.GetType().GetField(n,All).SetValue(x,v);}
 static object Call(object x,string n,params object[] a){try{return (x as Type??x.GetType()).GetMethods(All).Single(m=>m.Name==n&&m.GetParameters().Length==a.Length).Invoke(x is Type?null:x,a);}catch(TargetInvocationException e){throw e.InnerException??e;}}
 static object New(string n,params object[] a){return T(n).GetConstructors(All).Single(c=>!c.IsStatic&&c.GetParameters().Length==a.Length).Invoke(a);}static async Task<object> Await(object o){var t=(Task)o;await t;var p=t.GetType().GetProperty("Result");return p==null?null:p.GetValue(t,null);}
 static Dictionary<string,object> Fields(object x){return x.GetType().GetFields(All).Where(f=>!f.IsStatic).ToDictionary(f=>f.Name,f=>f.GetValue(x));}static Dictionary<string,object> Read(string p){return J.Deserialize<Dictionary<string,object>>(File.ReadAllText(p));}
 static string Hash(byte[] b){using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(b)).Replace("-","");}static string HashFile(string p){return Hash(File.ReadAllBytes(p));}static void Save(){if(output!=null)File.WriteAllText(Path.Combine(output,"result.json"),J.Serialize(R));}
 static void Target(){Need((bool)Get(connection,"Connected")&&Convert.ToInt32(Get(connection,"Epoch"))==epoch&&(ulong)Get(form,"connectedAddress")==address,"Connection identity/epoch changed; no replay");string actual=(string)Get(form,"bleDeviceUid");Need(actual==null||actual==Uid,"BLE UID changed");AcceptanceCurrentPins.Current.RequireMainLeases();}
 static async Task<byte[]> Exchange(byte[] q){Target();using(var c=new CancellationTokenSource(10000))return (byte[])await Await(Call(connection,"ExchangeAsync",(byte)0xA7,q,c.Token));}
 static async Task<X> Status<X>(){Target();return (X)await Await(Call(form,"ReadStatus"));}
 static void CaptureSettings(){var type=app.GetTypes().Single(t=>t.FullName.EndsWith(".Properties.Settings",StringComparison.Ordinal));settings=(ApplicationSettingsBase)type.GetProperty("Default",All).GetValue(null,null);oldSettings=new Dictionary<string,object>();foreach(SettingsProperty p in settings.Properties)oldSettings[p.Name]=settings[p.Name];}
 static void RestoreSettings(){if(oldSettings==null)return;bool changed=false;foreach(var x in oldSettings)if(!Object.Equals(settings[x.Key],x.Value)){settings[x.Key]=x.Value;changed=true;}if(changed)settings.Save();R["preferences_restored"]=true;}
 static object Expected(string p){var d=Read(p);Need((string)d["uid"]==Uid&&(bool)d["owned"],"Only the explicitly owned test tail is authorized");return d;}
 static void Check(object receipt,object expected){var d=(Dictionary<string,object>)expected;foreach(var p in new[]{Tuple.Create("Count","count"),Tuple.Create("Ordinal","index"),Tuple.Create("Start","start"),Tuple.Create("End","end"),Tuple.Create("Capacity","capacity")})Need(U(receipt,p.Item1)==Convert.ToUInt32(d[p.Item2]),"Owned tail changed: "+p.Item1);Need(BitConverter.ToUInt32((byte[])Get(receipt,"Bytes"),56)==Convert.ToUInt32(d["cookie"]),"Owned descriptor cookie changed");}
 static async Task BleDelete(string radio,string expected){
  CaptureSettings();try{
   R["mapping"]=AcceptanceCurrentPins.Current.RequireMapping(radio);address=UInt64.Parse(radio,NumberStyles.HexNumber);form=New("NpBleForm",false);((CheckBox)Get(form,"poll")).Checked=false;((System.Windows.Forms.Timer)Get(form,"timer")).Stop();((System.Windows.Forms.Timer)Get(form,"bleImuTimer")).Stop();
   ((TextBox)Get(form,"address")).Text=radio;Set(form,"busy",true);try{await Await(Call(form,"Connect"));}finally{Set(form,"busy",false);}connection=Get(form,"connection");epoch=Convert.ToInt32(Get(connection,"Epoch"));Target();
   var initial=await Await(Call(form,"ReadStatus"));R["initial_status"]=Fields(initial);Need((bool)Call(form,"StopConfirmed",initial)&&!(bool)Get(initial,"Busy"),"Stopped V1 required");
   Type statusType=initial.GetType(),delegateType=typeof(Func<>).MakeGenericType(typeof(Task<>).MakeGenericType(statusType));var status=Delegate.CreateDelegate(delegateType,typeof(A7Bench).GetMethod("Status",All).MakeGenericMethod(statusType));
   var client=New("NpBleDeleteLast",Uid,new Func<byte[],Task<byte[]>>(Exchange),status,new Action(Target));var before=await Await(Call(form,"ReadSdTestCatalog"));R["catalog_before"]=((IEnumerable)Get(before,"Records")).Cast<object>().Select(Fields).ToArray();
   var receipt=await Await(Call(client,"Inspect"));R["inspect"]=Fields(receipt);Check(receipt,Expected(expected));Save();await Await(Call(client,"Delete",receipt));
   var after=await Await(Call(form,"ReadSdTestCatalog"));var records=((IEnumerable)Get(after,"Records")).Cast<object>().ToArray();R["catalog_after"]=records.Select(Fields).ToArray();Need(records.Length+1==U(receipt,"Count"),"Immediate BLE catalog did not shrink by one");
   R["result"]="PASS actual production BLE A7 inspected/confirmed only the verified owned tail; immediate catalog shrank once";
  }finally{if(form!=null)R["gui_log"]=((TextBox)Get(form,"log")).Text;try{if(connection!=null)Call(connection,"Disconnect");}finally{try{if(form!=null)((IDisposable)form).Dispose();}finally{RestoreSettings();}}}
 }
 static string PathNow(){return ((IEnumerable)Call(T("CE32_console.NpDownloadNative"),"EnumerateNpPaths")).Cast<string>().Single(p=>String.Equals((string)Call(T("NpV1Management"),"UidFromPath",p),Uid,StringComparison.OrdinalIgnoreCase));}
 static byte[] Sector(Stream card,uint lba){return (byte[])Call(T("CE32_console.NpDownloadCatalog"),"Sector",card,(long)lba);}
 static object Window(Stream card,long offset,int length){Need(offset>=0&&length>0&&offset<=card.Length-length,"Bounded card read escaped capacity");var b=new byte[length];card.Position=offset;int at=0;while(at<length){int n=card.Read(b,at,length-at);Need(n>0,"Short bounded card read");at+=n;}return new {offset,bytes=length,sha256=Hash(b)};}
 static void Snapshot(string ownedSessionText,string expectedStartText,string compare){
  string path=PathNow();uint owned=UInt32.Parse(ownedSessionText),wantedStart=UInt32.Parse(expectedStartText);var fingerprints=new List<Dictionary<string,object>>();
  using(var card=(Stream)New("CE32_console.NpDownloadStream",path,false)){
   var store=Call(T("CE32_console.NpV1StoreV2"),"Read",card,null);R["store"]=Fields(store);uint count=U(store,"Count");Need(count>0,"Fixture card unexpectedly empty");var entries=((IEnumerable)Get(store,"Entries")).Cast<object>().ToArray();Need(entries.Length==count,"Incomplete descriptor inventory");
   foreach(uint lba in new[]{16U,24U,112U,113U,114U,115U})File.WriteAllBytes(Path.Combine(output,"lba"+lba+".bin"),Sector(card,lba));
   for(uint i=0;i<count;i++){
    var e=entries[i];var d=Fields(e);var row=new Dictionary<string,object>{{"index",i},{"entry",d},{"copy0_sha256",Hash(Sector(card,128U+2*i))},{"copy1_sha256",Hash(Sector(card,129U+2*i))}};
    if(Convert.ToInt32(Get(e,"Result"))==0){uint start=U(e,"Start"),end=U(e,"ReservedEnd"),commit=U(e,"CommittedEnd");Need(start>=8192&&end>start&&end<=card.Length/512,"Invalid descriptor extent");byte[] header=Sector(card,start+3),footer=Sector(card,start+4);row["header_sha256"]=Hash(header);row["footer_sha256"]=Hash(footer);
     uint hs=BitConverter.ToUInt32(header,48);if(hs>=8&&hs<end-start){long begin=((long)start+hs)*512;if(begin+4096<=(long)end*512)row["payload_head"]=Window(card,begin,4096);}
     if(commit>start+8&&commit<=end)row["payload_tail"]=Window(card,(long)commit*512-4096,4096);
    }
    fingerprints.Add(row);
   }
   var last=entries.Last();R["fingerprints"]=fingerprints;
   if(owned!=0){Need(U(last,"Session")==owned&&U(last,"Start")==wantedStart,"Current last is not the expected owned session; no delete authorization emitted");byte[] selected=(byte[])Get(last,"Raw");var allowed=new {uid=Uid,owned=true,count,index=count-1,start=U(store,"Start"),end=U(store,"Frontier"),capacity=U(store,"Capacity"),session=owned,cookie=BitConverter.ToUInt32(selected,508),epoch=Get(store,"Epoch"),generation=Get(store,"Generation")};File.WriteAllText(Path.Combine(output,"allowed-last.json"),J.Serialize(allowed));R["owned_tail"]=allowed;}
   if(compare!="-"){
    var prior=Read(compare);var before=J.ConvertToType<Dictionary<string,object>[]>(prior["fingerprints"]);uint protectedCount=Convert.ToUInt32(prior.ContainsKey("protected_count")?prior["protected_count"]:before.Length-1);Need(count>=protectedCount,"Earlier recording count decreased");
    for(int i=0;i<protectedCount;i++)Need(J.Serialize(before[i])==J.Serialize(fingerprints[i]),"Earlier recording metadata/bounded payload changed at index"+i);
    R["protected_count"]=protectedCount;R["earlier_recordings_preserved"]=true;
   }else R["protected_count"]=count-1;
   R["result"]="PASS read-only FS2 catalog/descriptor/header/footer/bounded payload snapshot";
  }
 }
 static void UsbDelete(string expected,bool cut){
  using(var client=(IDisposable)New("NpUsbDeleteLast",PathNow(),new Func<bool>(()=>true))){
   object receipt=Call(client,"Inspect");R["inspect"]=Fields(receipt);Check(receipt,Expected(expected));Save();File.WriteAllText(Path.Combine(output,"inspected.json"),J.Serialize(Fields(receipt)));
   if(cut){var wait=System.Diagnostics.Stopwatch.StartNew();while(!File.Exists(Path.Combine(output,"commit.request"))){Need(wait.Elapsed.TotalSeconds<180,"Owner did not arm a physical power-cut boundary");Thread.Sleep(100);}}
   try{R["delete_result"]=Fields(Call(client,"Delete",receipt));Need(!cut,"Expected physical cut did not happen; normal completion must not be mislabeled a power-loss test");R["result"]="PASS production USB A7 exact owned-tail deletion";}
   catch(Exception ex){if(!cut)throw;R["result"]="OUTCOME_UNKNOWN_EXPECTED_SD_RAIL_INTERRUPTION_REQUIRES_INDEPENDENT_GPIO_AND_RECOVERY_PROOF";R["error"]=ex.ToString();}
  }
 }
 [STAThread]static int Main(string[] args){try{
  args=AcceptanceCurrentPins.Configure(args);Need(args.Length>=4,"mode host arguments output required");Need(HashFile(args[1])==HostHash,"Exact246 required");app=Assembly.LoadFrom(args[1]);Need(app.GetName().Version==new Version(1,0,0,246),"Actual246 required");AcceptanceCurrentPins.Current.RequireMainLeases();R["owner"]=AcceptanceCurrentPins.Current.RequireOwner(AcceptanceCurrentPins.Current.Lease,Uid,1);
  output=Path.GetFullPath(args.Last());Need(output.StartsWith(@"C:\Frank\Code\XE_NP\_artifacts\v1_delete_last_20261105\bench\",StringComparison.OrdinalIgnoreCase)&&!Directory.Exists(output),"Fresh owned output required");Directory.CreateDirectory(output);R["host_sha256"]=HostHash;R["mode"]=args[0];
  if(args[0]=="snapshot"){Need(args.Length==6,"snapshot host ownedSession expectedStart compare-or-dash output");Snapshot(args[2],args[3],args[4]);Save();return 0;}
  if(args[0]=="usb-delete"||args[0]=="usb-cut"){Need(args.Length==4,"usb-delete host expectedOwned output");UsbDelete(args[2],args[0]=="usb-cut");Save();return 0;}
  Need(args[0]=="ble-delete"&&args.Length==5,"ble-delete host radio expectedOwned output");EventHandler begin=null;begin=async(s,e)=>{Application.Idle-=begin;try{await BleDelete(args[2],args[3]);exit=0;}catch(Exception ex){R["error"]=ex.ToString();Console.Error.WriteLine(ex);}finally{Save();Application.ExitThread();}};Application.Idle+=begin;Application.Run();return exit;
 }catch(Exception ex){R["error"]=ex.ToString();Console.Error.WriteLine(ex);Save();return 1;}}
}
