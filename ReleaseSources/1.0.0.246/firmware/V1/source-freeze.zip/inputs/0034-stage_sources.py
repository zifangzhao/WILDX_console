from pathlib import Path
import hashlib,json,shutil
T=Path(__file__).resolve().parent;P=Path('C:/Frank/Code/XE_NP/_artifacts/v1_gui_support_20261105')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
receipt=[]
for name in ('app-source','usb-source'):
 dst=T/name;dst.mkdir(exist_ok=False)
 for p in (P/name).iterdir():
  if p.is_file():
   target=dst/p.name;shutil.copyfile(p,target);receipt.append(dict(source=str(p),target=str(target),sha256=h(p)))
for name in ('provider.c','firmware.inc','control.inc','preview.inc'):
 p=T/'app-source'/name;s=p.read_text(encoding='utf-8-sig').replace(str(P/'app-source').replace('\\','/'),str(T/'app-source').replace('\\','/'));p.write_text(s)
for name in ('stream.c','modes.inc','np_sd_info_v1_service.inc'):
 p=T/'usb-source'/name;s=p.read_text(encoding='utf-8-sig').replace(str(P/'usb-source').replace('\\','/'),str(T/'usb-source').replace('\\','/'));p.write_text(s)
frozen=Path('C:/Frank/Code/XE_NP/_artifacts/v1_ble_compact_preview_20261025/app_source/Core/Src')
for name in ('np_store_v2_adapter.inc',):
 shutil.copyfile(frozen/name,T/'app-source'/name)
p=T/'app-source/firmware.inc';s=p.read_text();s=s.replace(str(frozen/'np_store_v2_adapter.inc').replace('\\','/'),str(T/'app-source/np_store_v2_adapter.inc').replace('\\','/'));p.write_text(s)
for folder,file in [('app-source','np_store_v2_adapter.inc'),('usb-source','stream.c')]:
 p=T/folder/file;s=p.read_text();header=str(T/'core/np_store_v2.h').replace('\\','/');s=(s.replace('#include "np_store_v2.h"',f'#include "{header}"') if file.endswith('.inc') else f'#include "{header}"\n'+s);p.write_text(s)
(T/'source-preimages.json').write_text(json.dumps(dict(parent_acceptance_sha256=h(P/'accepted.json'),inputs=receipt),indent=2)+'\n')
print('Staged exact accepted V1 source lineage into disjoint outputs')
