#ifndef NP_CL_FIRST_BRIDGE_H
#define NP_CL_FIRST_BRIDGE_H
#include "np_first_sync_record.h"
/* Once per optional detector recording, at the first retention-owned claim.
 * Copy the acquisition owner's already-checked reset/source state, not its
 * startup scanner. USB's private reset token is deliberately not its session. */
static inline int np_cl_first_bootstrap(NpClSourceState *dst,NpClSourceReceipt *out,
    const NpClSourceReceipt *claim,const NpFirstV1Record *r,const uint32_t binding[4],
    uint32_t mask,uint32_t ap)
{
    if(!dst || !out || !claim || !r || !binding || dst->seeded || dst->lost)return 0;
    const NpFirstSyncReceipt *q=&r->receipt;const NpClSourceState *s=&r->source;
    if(!q->session || !q->source_epoch || !(q->flags&NP_FIRST_FINAL) ||
       binding[0]!=q->session || binding[2]!=q->source_epoch || binding[3]!=q->profile_crc ||
       (binding[1] && binding[1]!=q->generation) || dst->source_epoch!=q->source_epoch ||
       !q->generation || r->final_generation!=q->generation || s->capture_generation!=q->generation ||
       q->mask!=mask || q->ap_hz!=ap || (uint64_t)ap*780U!=q->source_hz ||
       s->source_hz!=q->source_hz || s->source_epoch!=q->source_epoch ||
       !s->valid || !s->seeded || s->lost || !s->pending_mask ||
       claim->flags!=3U || claim->first_source_tick || !claim->source_tick_count ||
       claim->source_epoch!=q->source_epoch || claim->capture_generation!=q->generation ||
       !claim->probe_mask || (claim->probe_mask&~mask) || claim->probe_mask!=s->pending_mask ||
       claim->first_source_tick!=s->pending_first || claim->source_tick_count!=s->pending_ticks ||
       claim->flags!=s->pending_flags || !s->reset.token || s->reset.stage!=NP_CL_RESET_BOUND ||
       s->reset.capture_generation!=q->generation || s->reset.ap_hz!=ap ||
       s->reset.probe_mask!=mask || s->reset.window_closed ||
       !np_cl_reset_window(&s->reset,s->reset.last_ms))return 0;
    for(unsigned p=0U;p<3U;p++)if((mask&(1U<<p)) && s->next_tick[p])return 0;
    *dst=*s;*out=*claim;return 1;
}
#endif
