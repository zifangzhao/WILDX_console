#ifndef NP_BLE_PREVIEW_H
#define NP_BLE_PREVIEW_H
#include "xe_np_online_impl.h"
#include "np_sd_fast_crc.h"
#define NP1_PREVIEW_MAGIC 0x3156504eU
#define NP1_PREVIEW_FRAGMENT 160U
#define NP1_PREVIEW_SLOTS 4U
/* V1-only wire identity. One raw 10-bit serial ADC word/sample, 16 samples
 * per packet, <=500 Hz AP or decimated LFP. All decoding stays on the PC.
 * Kind 0 snapshots 1560 chronological bytes for PC sync/counter alignment;
 * kind 2 streams a selected channel; 3 stops; 4 renews the 2 s lease.
 * Request words: magic,1,kind,id,probe,channel,ultraframe_phase,session,band.
 * phase is the first session superframe offset, never counter %156 (which
 * changes across the 20-bit counter rollover). Band 0 AP, 1 LFP.
 * No new DMA/channel, live-ring reads, ownership pinning, or cache operations. */
typedef struct {
    uint8_t data[1560];
    uint32_t id,session,hz,kind,probe,channel,phase,band;
    uint32_t active,ready,lease,total,used,offset,stride,word_bytes;
    uint32_t read_slot,write_slot,queued,armed,dropped,bad_word;
    uint32_t masks[NP1_PREVIEW_SLOTS];
    uint64_t origins[NP1_PREVIEW_SLOTS],first,next,expected;
    /* Kind5 only: four compact channels share the existing packet/ring budget. */
    uint32_t channel_count,relative_ticks[4];
    uint64_t channel_next[4];
    uint16_t channels[4],valid[NP1_PREVIEW_SLOTS][4],code[4];
    uint8_t rows[4],bits[4],bad[4];
} NpBlePreview;
static inline void np_ble_preview_stop(NpBlePreview *p)
{p->active=p->ready=p->queued=p->used=p->word_bytes=p->armed=0;}
static inline int np_ble_preview_request(NpBlePreview *p,const uint8_t *b,
    uint32_t session,uint32_t hz,uint32_t mask,int recording,uint32_t now)
{
    if(xe_np_online_word(b)!=NP1_PREVIEW_MAGIC)return 0;
    if(xe_np_online_word(b+4)!=1 || !xe_np_online_word(b+12) ||
       xe_np_online_word(b+60)!=xe_np_online_crc(b))return 1;
    uint32_t w[15];for(unsigned i=0;i<15;i++)w[i]=xe_np_online_word(b+i*4);
    unsigned compact=w[2]==5U || ((w[2]==3U || w[2]==4U) && p->kind==5U);
    uint32_t channels[4]={w[5],w[10],w[11],w[12]};
    if(compact){
        if(w[9]<1U || w[9]>4U || w[13] || w[14])return 1;
        for(unsigned i=0;i<4;i++){
            if(i>=w[9]){if(channels[i])return 1;continue;}
            if(channels[i]>=384U)return 1;
            for(unsigned j=0;j<i;j++)if(channels[i]==channels[j])return 1;
        }
    }else for(unsigned i=9;i<15;i++)if(w[i])return 1;
    if(w[2]==3 || w[2]==4){
        if(w[3]==p->id && w[7]==p->session && w[4]==p->probe &&
           w[5]==p->channel && w[6]==p->phase && w[8]==p->band){
            if(compact){
                if(w[9]!=p->channel_count)return 1;
                for(unsigned i=0;i<w[9];i++)if(channels[i]!=p->channels[i])return 1;
            }
            if(w[2]==3)np_ble_preview_stop(p);
            else if(recording && session==p->session)p->lease=now+2000U;
        }
        return 1;
    }
    if(p->active || p->ready || !recording || !session || (w[2]!=0 && w[2]!=2 && w[2]!=5) ||
       w[4]<1 || w[4]>3 || !(mask&(1U<<(w[4]-1U))) || w[5]>=384 ||
       w[6]>=9360 || w[8]>1 || (w[2] && w[7]!=session) || hz<500)return 1;
    memset(p,0,sizeof(*p));p->id=w[3];p->session=session;p->hz=hz;p->kind=w[2];
    p->probe=w[4];p->channel=w[5];p->phase=w[6];p->band=w[8];
    p->total=p->kind?160U:1560U;p->lease=now+2000U;p->active=1;
    p->stride=p->band?((hz/6000U)?(hz/6000U):1U)*9360U:((hz+499U)/500U)*780U;
    if(compact){p->channel_count=w[9];for(unsigned i=0;i<w[9];i++)p->channels[i]=(uint16_t)channels[i];}
    return 1;
}
/* Read only a private staging-complete chunk. Four 15,360-byte time lanes.
 * Packed GPIOE halfwords contain simultaneous probe 1/2 values. */
static inline uint8_t np_ble_preview_byte(const uint8_t *raw,uint32_t at,
    unsigned packed,unsigned probe)
{
    return packed?raw[(at&3U)*15360U+(at>>2)*2U+probe-1U]:
                  raw[(at&3U)*15360U+(at>>2)];
}
static inline uint32_t np_ble_preview_sample_offset(uint32_t channel,uint32_t band)
{
    uint32_t adc=(channel/24U)*2U+(channel&1U),sample=(channel%24U)/2U;
    return (band?sample*780U:(sample+1U)*60U)+(adc<30U?adc%5U:adc-30U)*10U;
}
static inline void np_ble_preview_compact_clear(NpBlePreview *p)
{
    memset(p->data+p->write_slot*160U,0,160U);
    memset(p->valid[p->write_slot],0,sizeof(p->valid[0]));
    memset(p->rows,0,sizeof(p->rows));memset(p->bits,0,sizeof(p->bits));
    memset(p->bad,0,sizeof(p->bad));memset(p->code,0,sizeof(p->code));
    p->origins[p->write_slot]=p->channel_next[0];
}
/* Foreground only, from the same private completed chunk as legacy preview.
 * Decode just the selected10-bit words; never read or pin the live DMA ring. */
static inline void np_ble_preview_compact_tap(NpBlePreview *p,const uint8_t *raw,
    uint64_t first,uint32_t ticks,unsigned packed,unsigned probe,int pressure)
{
    uint64_t end=first+ticks;
    if(p->queued==NP1_PREVIEW_SLOTS){p->armed=0;if(p->dropped!=~0U)p->dropped++;return;}
    if(!p->armed || (p->expected && p->expected!=first)){
        uint32_t period=p->band?9360U:780U;
        uint32_t off=np_ble_preview_sample_offset(p->channel,p->band);
        uint32_t phase=(p->phase+off)%period;
        uint64_t base=first+(phase+period-(uint32_t)(first%period))%period;
        for(unsigned c=0;c<p->channel_count;c++){
            p->relative_ticks[c]=(np_ble_preview_sample_offset(p->channels[c],p->band)+period-off)%period;
            p->channel_next[c]=base+p->relative_ticks[c];
        }
        np_ble_preview_compact_clear(p);p->armed=1;
    }
    p->expected=end;
    for(;;){
        unsigned c=p->channel_count;uint64_t next=~(uint64_t)0;
        for(unsigned i=0;i<p->channel_count;i++)if(p->rows[i]<16U && p->channel_next[i]<next){c=i;next=p->channel_next[i];}
        if(c==p->channel_count){
            unsigned any=0;for(unsigned i=0;i<p->channel_count;i++)any|=p->valid[p->write_slot][i];
            if(any){
                p->write_slot=(p->write_slot+1U)%NP1_PREVIEW_SLOTS;p->queued++;p->ready=1;
                if(p->queued==NP1_PREVIEW_SLOTS){p->armed=0;return;}
            }
            np_ble_preview_compact_clear(p);continue;
        }
        if(next>=end)return;
        uint32_t n=10U-p->bits[c];if(next+n>end)n=(uint32_t)(end-next);
        uint32_t adc=(p->channels[c]/24U)*2U+(p->channels[c]&1U),line=adc<30U?adc/5U+1U:7U;
        if(pressure)p->bad[c]=1;
        else if(!p->bad[c])for(unsigned i=0;i<n;i++)p->code[c]=(uint16_t)((p->code[c]<<1)|
            ((np_ble_preview_byte(raw,(uint32_t)(next-first)+i,packed,probe)>>line)&1U));
        p->bits[c]=(uint8_t)(p->bits[c]+n);p->channel_next[c]+=n;
        if(p->bits[c]==10U){
            unsigned row=p->rows[c]++,at=p->write_slot*160U+c*32U+row*2U;
            if(!p->bad[c]){
                p->data[at]=(uint8_t)p->code[c];p->data[at+1U]=(uint8_t)(p->code[c]>>8);
                p->valid[p->write_slot][c]|=(uint16_t)(1U<<row);
            }else if(p->dropped!=~0U)p->dropped++;
            p->bits[c]=p->bad[c]=0;p->code[c]=0;p->channel_next[c]+=p->stride-10U;
        }
    }
}
static inline void np_ble_preview_tap(NpBlePreview *p,const uint8_t *raw,
    uint64_t first,uint32_t ticks,unsigned packed,unsigned probe,int pressure)
{
    if(!p->active || (packed?p->probe>2:p->probe!=probe))return;
    if(p->kind==5U){np_ble_preview_compact_tap(p,raw,first,ticks,packed,probe,pressure);return;}
    uint64_t end=first+ticks;
    if(!p->armed || (p->expected && p->expected!=first)){
        p->used=p->word_bytes=p->bad_word=0;
        if(!p->kind){p->first=first;p->next=first;}
        else {
            uint32_t adc=(p->channel/24U)*2U+(p->channel&1U);
            uint32_t sample=(p->channel%24U)/2U;
            uint32_t word=adc<30?adc%5U:adc-30U;
            uint32_t period=p->band?9360U:780U;
            uint32_t offset=p->phase+(p->band?sample*780U:(sample+1U)*60U)+word*10U;
            p->next=first+(offset%period+period-(uint32_t)(first%period))%period;
        }
        p->armed=1;
    }
    p->expected=end;
    if(!p->kind){
        if(pressure){np_ble_preview_stop(p);p->dropped++;return;}
        uint32_t n=p->total-p->used;if(n>ticks)n=ticks;
        for(uint32_t i=0;i<n;i++)p->data[p->used+i]=np_ble_preview_byte(raw,i,packed,p->probe);
        p->used+=n;
        if(p->used==p->total){p->active=0;p->ready=1;}return;
    }
    if(p->queued==NP1_PREVIEW_SLOTS){p->armed=0;p->dropped++;return;}
    while(p->next<end){
        if(!p->used){p->origins[p->write_slot]=p->next;p->masks[p->write_slot]=0;}
        uint32_t n=10U-p->word_bytes;if(p->next+n>end)n=(uint32_t)(end-p->next);
        if(pressure)p->bad_word=1;
        else if(!p->bad_word)for(uint32_t i=0;i<n;i++)
            p->data[p->write_slot*160U+p->used+i]=np_ble_preview_byte(raw,(uint32_t)(p->next-first)+i,packed,p->probe);
        p->next+=n;p->used+=n;p->word_bytes+=n;
        if(p->word_bytes==10U){
            if(!p->bad_word)p->masks[p->write_slot]|=1U<<(p->used/10U-1U);
            else p->dropped++;
            p->word_bytes=p->bad_word=0;p->next+=p->stride-10U;
        }
        if(p->used==160U){
            if(!p->masks[p->write_slot]){p->used=0;continue;}
            p->write_slot=(p->write_slot+1U)%NP1_PREVIEW_SLOTS;
            p->queued++;p->ready=1;p->used=0;
            if(p->queued==NP1_PREVIEW_SLOTS)return;
        }
    }
}
/* Fixed 224-byte body, same CE32 AD BA .. DA DA envelope as V2. */
static inline void np_ble_preview_fragment(const NpBlePreview *p,uint8_t *b)
{
    memset(b,0,224);uint64_t first=p->kind?p->origins[p->read_slot]:p->first;
    uint32_t w[8]={NP1_PREVIEW_MAGIC,p->id,p->session,p->hz,(uint32_t)first,
        (uint32_t)(first>>32),p->kind?(160U<<16)|p->masks[p->read_slot]:p->offset|(p->total<<16),
        p->probe|(p->kind<<8)|(p->band<<12)|(p->channel<<16)};
    for(unsigned i=0;i<8;i++)xe_np_online_put(b+4*i,w[i]);
    uint32_t n=p->kind?160U:p->total-p->offset;if(n>160U)n=160U;
    memcpy(b+32,p->data+(p->kind?p->read_slot*160U:p->offset),n);
    xe_np_online_put(b+192,p->stride);xe_np_online_put(b+196,p->dropped);
    if(p->kind==5U){
        xe_np_online_put(b+24,(128U<<16)|16U);
        memset(b+160,0,32U);
        for(unsigned i=0;i<p->channel_count;i++){
            uint16_t ch=p->channels[i],mask=p->valid[p->read_slot][i];
            b[160U+2U*i]=(uint8_t)ch;b[161U+2U*i]=(uint8_t)(ch>>8);
            b[168U+2U*i]=(uint8_t)mask;b[169U+2U*i]=(uint8_t)(mask>>8);
            xe_np_online_put(b+176U+4U*i,p->relative_ticks[i]);
        }
        xe_np_online_put(b+200,p->channel_count);xe_np_online_put(b+204,1U);
        xe_np_online_put(b+220,np_sd_metadata_crc_fast(b,220U));
    }
}
static inline void np_ble_preview_retire(NpBlePreview *p)
{
    if(p->kind){p->read_slot=(p->read_slot+1U)%NP1_PREVIEW_SLOTS;p->queued--;p->ready=p->queued!=0;}
    else {p->offset+=160U;if(p->offset>=p->total)p->ready=0;}
}
#endif
