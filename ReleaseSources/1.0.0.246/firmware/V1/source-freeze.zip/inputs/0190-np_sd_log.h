#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/app_grid_r7_source/xe_np_app/Inc/np_sd_control.h"
#ifndef NP_SD_LOG_H
#define NP_SD_LOG_H
#include <stdint.h>
#include <string.h>
#ifndef NP_SD_VSC
#define NP_SD_VSC 0
#endif
#ifndef NP_SD_CE64
#define NP_SD_CE64 0
#endif
#ifndef NP_SD_SENSORS
#define NP_SD_SENSORS 0
#endif
#ifndef NP_SD_BEST_EFFORT
#define NP_SD_BEST_EFFORT 0
#endif
#if NP_SD_SENSORS && !NP_SD_CE64
#error Sensor recording requires the CE64 container
#endif

/* CE32-style raw-sector recording, with an explicit, versioned NP extension.
 * Like CE32 DATA_INFO_HEADER_SIZE, HEADER_SECTORS is in SECTORS, not bytes.
 * This is not FAT/exFAT and must only be used in an explicitly reserved extent. */
#if NP_SD_VSC
#define NP_SD_HEADER_SECTORS 16384U
#define NP_SD_WRITE_CHUNKS 8U
#else
#define NP_SD_HEADER_SECTORS 8192U
#define NP_SD_WRITE_CHUNKS 1U
#endif
#if NP_SD_CE64
#define NP_SD_PAYLOAD_OFFSET 0U
#else
#define NP_SD_PAYLOAD_OFFSET 512U
#endif
#define NP_SD_LANE_BYTES 15360U
#define NP_SD_PAYLOAD_BYTES (4U * NP_SD_LANE_BYTES)
#if NP_SD_VSC
#define NP_SD_CHUNK_BYTES 65536U
#else
#define NP_SD_CHUNK_BYTES (512U + NP_SD_PAYLOAD_BYTES)
#endif
#define NP_SD_CHUNK_SECTORS (NP_SD_CHUNK_BYTES / 512U)
#define NP_SD_NONE 255U
#ifndef NP_SD_SLOTS
#define NP_SD_SLOTS 2U
#endif
#define NP_SD_ELASTIC (NP_SD_SLOTS==128U)
#ifndef NP_SD_DIRECT_PSRAM
#define NP_SD_DIRECT_PSRAM 0
#endif
_Static_assert(NP_SD_SLOTS==2U || NP_SD_SLOTS==4U || (NP_SD_VSC && (NP_SD_SLOTS==16U || NP_SD_SLOTS==128U)),"Invalid bounded queue geometry");
enum { NP_SD_IDLE, NP_SD_RUNNING, NP_SD_DRAINING, NP_SD_COMPLETE, NP_SD_FAILED };
enum { NP_SD_FREE, NP_SD_STAGING, NP_SD_READY, NP_SD_WRITING };
enum { NP_SD_CONFIG=1, NP_SD_SOURCE, NP_SD_STAGE, NP_SD_WRITE, NP_SD_TIMEOUT,
       NP_SD_RANGE, NP_SD_PROTOCOL };
typedef struct {
    uint32_t start_lba, end_lba, session, probe_mask, sample_bytes, ap_hz;
    uint32_t stage_timeout_ms, write_timeout_ms;
} NpSdConfig;
static inline uint32_t np_sd_header_sectors(const NpSdConfig *c)
{
#if NP_SD_CE64
    /* CE64 record starts follow4 MiB directory alignment. NP Video data must
     * start on8 MiB AUs; persist the real header length in the NP descriptor. */
    return 8192U+((0U-(c->start_lba+8192U))&16383U);
#else
    (void)c;return NP_SD_HEADER_SECTORS;
#endif
}
typedef struct { uint32_t state, lba, sequence, started_ms, fixed_word; } NpSdSlot;
typedef struct {
    NpSdConfig config;
    NpSdSlot slots[NP_SD_SLOTS];
    uint32_t state, fault, next_lba, next_sequence, committed_chunks;
    uint32_t max_stage_ms, max_write_ms, total_write_ms;
    uint32_t stop_requested, drain_sequence;
    uint8_t head, count, staging, writing;
} NpSdLog;

static inline void np_put32(uint8_t *p, uint32_t v)
{ p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); p[2]=(uint8_t)(v>>16); p[3]=(uint8_t)(v>>24); }
#include "C:/Frank/Code/XE_NP/_artifacts/v1_ble_compact_preview_20261025/app_source/Core/Inc/np_sd_fast_crc.h"
static inline uint32_t np_crc32(const uint8_t *p,uint32_t n)
{return np_sd_metadata_crc_fast(p,n);}
static inline int np_sd_fail(NpSdLog *s, uint32_t fault)
{ if(!s->fault)s->fault=fault; s->state=NP_SD_FAILED; return -1; }
static inline int np_sd_init(NpSdLog *s, const NpSdConfig *c, uint32_t card_blocks)
{
    memset(s,0,sizeof(*s)); s->staging=s->writing=NP_SD_NONE;
    if(!c)return np_sd_fail(s,NP_SD_CONFIG);
    s->config=*c;
    if(c->start_lba<8192U || c->end_lba>card_blocks || c->end_lba<=c->start_lba ||
       c->end_lba-c->start_lba<np_sd_header_sectors(c)+NP_SD_WRITE_CHUNKS*NP_SD_CHUNK_SECTORS || !c->session ||
#if NP_SD_VSC
       ((c->end_lba-c->start_lba-np_sd_header_sectors(c)) % 1024U) ||
       ((c->start_lba+np_sd_header_sectors(c)) % 1024U) ||
#endif
       (!np_mode_valid(c->probe_mask,c->ap_hz) || c->sample_bytes!=1U) ||
       !c->stage_timeout_ms || c->stage_timeout_ms>1000U ||
       !c->write_timeout_ms || c->write_timeout_ms>1000U)
        return np_sd_fail(s,NP_SD_CONFIG);
    s->next_lba=c->start_lba+np_sd_header_sectors(c); s->state=NP_SD_RUNNING;
    return 0;
}
/* Calls are foreground-owned. Mark ownership BEFORE starting either DMA. */
static inline int np_sd_reserve(NpSdLog *s, uint32_t now)
{
    if(s->state!=NP_SD_RUNNING || s->count==NP_SD_SLOTS || s->staging!=NP_SD_NONE)return -1;
    if(s->next_lba>s->config.end_lba || s->config.end_lba-s->next_lba<NP_SD_CHUNK_SECTORS) {
        s->state=s->count?NP_SD_DRAINING:NP_SD_COMPLETE; return -1;
    }
    uint8_t i=(uint8_t)((s->head+s->count)&(NP_SD_SLOTS-1U)); NpSdSlot *p=&s->slots[i];
    if(p->state!=NP_SD_FREE)return np_sd_fail(s,NP_SD_PROTOCOL);
    p->state=NP_SD_STAGING; p->lba=s->next_lba; p->sequence=s->next_sequence++;
    p->started_ms=now; s->next_lba+=NP_SD_CHUNK_SECTORS;
    s->count++; s->staging=i;
    if(s->next_lba==s->config.end_lba ||
       (s->stop_requested && s->next_sequence>=s->drain_sequence && (s->next_sequence%NP_SD_WRITE_CHUNKS)==0U))s->state=NP_SD_DRAINING;
    return i;
}
static inline int np_sd_stage_done(NpSdLog *s, int ok, uint32_t now)
{
    if(s->fault)return -1;
    if(s->staging>=NP_SD_SLOTS || s->slots[s->staging].state!=NP_SD_STAGING)return np_sd_fail(s,NP_SD_PROTOCOL);
    if(!ok)return np_sd_fail(s,NP_SD_STAGE);
    uint32_t dt=now-s->slots[s->staging].started_ms;
    if(dt>s->max_stage_ms)s->max_stage_ms=dt;
    /* A retired, source-validated private copy is usable even if foreground
     * service was late. The live-stage watchdog remains in check_deadlines. */
#if !NP_SD_BEST_EFFORT
    if(dt>=s->config.stage_timeout_ms)return np_sd_fail(s,NP_SD_TIMEOUT);
#endif
#if NP_FIRST_SYNC_ENABLE
    s->slots[s->staging].state=NP_SD_READY;
    unsigned completed_slot=s->staging;
    s->staging=NP_SD_NONE;
#if NP_CL_ENABLE
    NP_SD_CL_STAGE_COMMIT(completed_slot);
#endif
    NP_SD_FIRST_STAGE_COMMIT(completed_slot);
    return 0;
#else
    s->slots[s->staging].state=NP_SD_READY; s->staging=NP_SD_NONE; return 0;
#endif
}
static inline int np_sd_begin_write(NpSdLog *s, uint32_t now)
{
    if(s->fault || s->writing!=NP_SD_NONE || s->count<NP_SD_WRITE_CHUNKS)return -1;
    for(unsigned n=0;n<NP_SD_WRITE_CHUNKS;n++)
        if(s->slots[(s->head+n)&(NP_SD_SLOTS-1U)].state!=NP_SD_READY)return -1;
    s->writing=s->head;
    for(unsigned n=0;n<NP_SD_WRITE_CHUNKS;n++)s->slots[(s->head+n)&(NP_SD_SLOTS-1U)].state=NP_SD_WRITING;
    s->slots[s->head].started_ms=now; return s->head;
}
static inline int np_sd_write_ready(const NpSdLog *s)
{
    if(s->fault || s->writing!=NP_SD_NONE || s->count<NP_SD_WRITE_CHUNKS)return 0;
    for(unsigned n=0;n<NP_SD_WRITE_CHUNKS;n++)
        if(s->slots[(s->head+n)&(NP_SD_SLOTS-1U)].state!=NP_SD_READY)return 0;
    return 1;
}
/* ok means SD IDMA completed AND card returned to TRANSFER, not just DMA TC. */
static inline int np_sd_write_done(NpSdLog *s, int ok, uint32_t now)
{
    if(s->fault)return -1;
    if(s->writing>=NP_SD_SLOTS || s->writing!=s->head || s->slots[s->head].state!=NP_SD_WRITING)
        return np_sd_fail(s,NP_SD_PROTOCOL);
    if(!ok)return np_sd_fail(s,NP_SD_WRITE);
    uint32_t dt=now-s->slots[s->head].started_ms;
    if(dt>s->max_write_ms)s->max_write_ms=dt;
    if(dt>=s->config.write_timeout_ms)return np_sd_fail(s,NP_SD_TIMEOUT);
    s->total_write_ms+=dt;
    for(unsigned n=0;n<NP_SD_WRITE_CHUNKS;n++)s->slots[(s->head+n)&(NP_SD_SLOTS-1U)].state=NP_SD_FREE;
    s->head=(uint8_t)((s->head+NP_SD_WRITE_CHUNKS)&(NP_SD_SLOTS-1U)); s->count-=NP_SD_WRITE_CHUNKS;
    s->writing=NP_SD_NONE; s->committed_chunks+=NP_SD_WRITE_CHUNKS;
    if(s->state==NP_SD_DRAINING && !s->count)s->state=NP_SD_COMPLETE;
    return 0;
}
static inline void np_sd_stop(NpSdLog *s)
{
    if(s->state!=NP_SD_RUNNING)return;
    s->stop_requested=1U;
    if(s->next_sequence>=s->drain_sequence && (s->next_sequence%NP_SD_WRITE_CHUNKS)==0U)
        s->state=(s->count || s->writing!=NP_SD_NONE)?NP_SD_DRAINING:NP_SD_COMPLETE;
}
static inline int np_sd_check_deadlines(NpSdLog *s, uint32_t now)
{
    if(s->fault)return -1;
    if((s->staging<NP_SD_SLOTS && now-s->slots[s->staging].started_ms>=s->config.stage_timeout_ms) ||
       (s->writing<NP_SD_SLOTS && now-s->slots[s->writing].started_ms>=s->config.write_timeout_ms))
        return np_sd_fail(s,NP_SD_TIMEOUT);
    return 0;
}
/* Sector CRC protects metadata, not the ADC payload. Offline NP frame/counter
 * validation is mandatory; ADC samples have no source checksum. */
uint32_t NP_SD_MicrophoneRate(void);
uint32_t NP_SD_CameraRate(void);
#if NP_SD_MEDIA_METADATA
void NP_SD_MediaMetadata(uint8_t sector[512],uint32_t kind);
#endif
uint32_t NP_SD_CameraSequence(unsigned slot);
static inline void np_sd_header(uint8_t *b, const NpSdLog *s, uint32_t kind, uint32_t slot)
{
    memset(b,0,512); memcpy(b,kind==1?"NPSDLOG1":kind==2?"NPSDBLK1":"NPSDEND1",8);
    np_put32(b+8,NP_SD_MicrophoneRate()?8U:NP_SD_CameraRate()?7U:6U); np_put32(b+12,s->config.session); np_put32(b+16,s->config.probe_mask);
    np_put32(b+20,s->config.sample_bytes); np_put32(b+24,s->config.ap_hz);
    np_put32(b+28,s->config.ap_hz/12U); np_put32(b+32,NP_SD_LANE_BYTES);
    np_put32(b+36,NP_SD_CHUNK_SECTORS); np_put32(b+40,s->config.start_lba);
    np_put32(b+44,s->config.end_lba); np_put32(b+48,np_sd_header_sectors(&s->config));
    if(kind==2 && slot<NP_SD_SLOTS) {
        np_put32(b+52,s->slots[slot].sequence); np_put32(b+56,s->slots[slot].lba);
    }
    np_put32(b+60,s->state); np_put32(b+64,s->fault); np_put32(b+68,s->committed_chunks);
    np_put32(b+72,s->max_stage_ms); np_put32(b+76,s->max_write_ms);
    np_put32(b+80,2U); /* four physical time lanes; interleave sample_bytes, not bytes */
    np_put32(b+84,s->total_write_ms);
    np_put32(b+96,61632U);
    if(kind==2 && slot<NP_SD_SLOTS) {
        np_put32(b+88,npl_probe(s->config.probe_mask,NP_SD_CameraSequence(slot)));
        np_put32(b+92,(s->config.probe_mask?NP_SD_CameraSequence(slot)/npl_count(s->config.probe_mask):0U));
        np_put32(b+100,s->slots[slot].fixed_word);
    }
    np_put32(b+112,NP_SD_CameraRate());
    np_put32(b+116,NP_SD_MicrophoneRate());
    np_put32(b+120,NP_SD_MicrophoneRate()?1U:0U);
#if NP_SD_MEDIA_METADATA
    if(kind!=2U)NP_SD_MediaMetadata(b,kind);
#endif
#ifdef NP_SD_RECORD_HEALTH
    NP_SD_RECORD_HEALTH(b,s);
#endif
#ifdef NP_SD_PAYLOAD_BINDING
    NP_SD_PAYLOAD_BINDING(b);
#endif
#if NP_CL_ENABLE
    NP_SD_CL_HEADER(b,kind);
#endif
    np_put32(b+508,np_crc32(b,508));
}
#endif
