"""Explicit owned-record PF2 storage-rail interruption; never a full-device cut."""
from pathlib import Path
import hashlib,json,re,struct,subprocess,sys
sys.dont_write_bytecode=True
import bench_hil as b
sys.path.insert(0,'C:/Frank/Code/XE_NP/Tools/V1Capture/ClosedLoopFix')
import ap_snapshot as a
T=Path(__file__).resolve().parent;mode,record,dirname,mapname=sys.argv[1:]
assert mode in ('off','on')
record=Path(record);live=json.loads((record/'data-live.json').read_text());assert live['uid']==b.c.UID and live['session'] and live['start']>=8192
mapping=(T/mapname/'candidate.map').read_text();pair=json.loads((T/'matched-test-pair.json').read_text())
m=re.search(r'^\s*np_store_state\s+0x([0-9a-fA-F]+)\s+Data\s+56\b',mapping,re.M);assert m
store=int(m[1],16);folder=b.c.PHASE/dirname;assert not folder.exists()
plan,_,_=b.c.setup();lease=plan.prior.held(b.c.PHASE)
ranges={'uid':(0x0bfa0700,12),'vtor':(0xe000ed08,4),'gpiof':(0x42021400,40),'store':(store,56),'sd':(0x420c8000,96),'dma':(0x40020000,2048),'core':(0xe000edf0,4)}
_,_,source,command=a.prepare(folder,ranges,b.c.SERIAL,0x08020000)
checks=f'''
if {{[lindex [read_memory 0x0801e020 32 1] 0] != 0x{pair['app']['image_crc32']}}} {{error "WrongAPP"}}
if {{([lindex [read_memory 0x42021400 32 1] 0] >> 4 & 3) != 1}} {{error "PF2notOutput"}}
set st [read_memory {hex(store)} 32 14]
if {{[lindex $st 9] != {live['session']} || [lindex $st 7] != {live['start']}}} {{error "Ownedrecordchanged"}}
'''
if mode=='off':
 checks+='if {![lindex $st 12] || !([lindex [read_memory 0x42021414 32 1] 0]&4)} {error "Ownedrecordnotliveorrailnoton"}\n'
else:
 checks+='''
for {set i 0} {$i<16} {incr i} {if {[lindex [read_memory [expr {0x40020064+$i*0x80}] 32 1] 0]&1} {error "DMAactive"}}
if {([lindex [read_memory 0x420c8034 32 1] 0]&0x3000) || ([lindex [read_memory 0x420c8058 32 1] 0]&1) || ([lindex [read_memory 0x420c802c 32 1] 0]&1)} {error "SDdatapathnotretired"}
if {[lindex [read_memory 0x42021414 32 1] 0]&4} {error "Railalreadyon"}
'''
value=0x40000 if mode=='off' else 4
checks+=f'write_memory 0x42021418 32 {{{value}}}\nset after [lindex [read_memory 0x42021414 32 1] 0]\n'
checks+=f'if {{($after&4) != {0 if mode=="off" else 4}}} {{error "PF2readbackfailed"}}\n'
source=source.replace('dump_image ',checks+'dump_image ',1).replace(a.COMPLETE,'V1_OWNED_VEE_'+mode.upper()+'_READBACK')
folder.mkdir();tcl=folder/'vee-explicit.tcl';tcl.write_text(source);command[-1]=str(tcl)
result=subprocess.run(command,capture_output=True,text=True,timeout=30);log=result.stdout+result.stderr;(folder/'openocd.log').write_text(log)
assert result.returncode==0 and 'V1_OWNED_VEE_'+mode.upper()+'_READBACK' in log,log
for n in ranges:(folder/(n+'.bin.partial')).rename(folder/(n+'.bin'))
assert plan.prior.held(b.c.PHASE)['holder_pid']==lease['holder_pid']
receipt=dict(result='PASS_GPIO_REQUEST_READBACK',mode=mode,uid=b.c.UID,session=live['session'],start=live['start'],app_crc32=pair['app']['image_crc32'],write_address='0x42021418',write_value=value,cpu_examine=False,halt=False,reset=False,scope='PF2 VEE_EN storage rail requested/readback; MCU powered through USB. No electrical VDD0 or whole-device power-loss claim.',command=command,source_sha256=hashlib.sha256(source.encode()).hexdigest().upper())
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
