from pathlib import Path
import hashlib,json,re,sys
sys.dont_write_bytecode=True
T=Path(__file__).resolve().parent;B=T/'build-usb-r10'
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
r=json.loads((T/'build-usb-r9/pending.json').read_text())
old='C:/Frank/Code/XE_NP/_artifacts/v1_usb_auto_sd_r78_20261005/source/MDK-ARM/USB384_NP_BGA_MMC/startup_stm32u595xx.o'
key=next(p for p in r['retained_objects'] if Path(p).as_posix()==old);oldhash=r['retained_objects'].pop(key)
r['retained_objects'][str(B/'startup_stm32u595xx.o')]=h(B/'startup_stm32u595xx.o')
r['stack_change']=dict(parent_object=old,parent_sha256=oldhash,source=str(T/'usb-source/startup_stm32u595xx.s'),source_sha256=h(T/'usb-source/startup_stm32u595xx.s'),assembler_command=['C:/Keil_v5/ARM/ARMCLANG/bin/armasm.exe','--cpu','Cortex-M33','--fpu','FPv5-SP','--littleend','-g','-o',str(B/'startup_stm32u595xx.o'),str(T/'usb-source/startup_stm32u595xx.s')],old_bytes=4096,new_bytes=8192)
r['scatter']=str(B/'candidate.sct');r['scatter_sha256']=h(B/'candidate.sct')
for p,d in r['retained_objects'].items():assert h(p)==d
assert h(r['object'])==r['object_sha256']
sys.path.insert(0,'C:/Frank/Code/XE_NP/Tools/V1Capture/ClosedLoopFix')
from build_current import seal
i=seal('usb',B);(B/'identity.json').write_text(json.dumps(i,indent=2)+'\n')
mapping=(B/'candidate.map').read_text()
regions=[(n,int(a,16),int(s,16),int(l,16)) for n,a,s,l in re.findall(r'Execution Region (\S+) \(Exec base: (0x\w+).*?Size: (0x\w+), Max: (0x\w+)',mapping)]
assert all(s<=l for n,a,s,l in regions)
assert re.search(r'Stack_Mem\s+0x[0-9a-f]+\s+Data\s+8192\b',mapping)
r.update(status='SOFTWARE_CHECKED_PENDING_HARDWARE',identity=i,regions=regions)
(B/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(dict(crc32=i['image_crc32'],sha256=i['sha256'],regions=regions)))
