from pathlib import Path
import sys,time,socket,re,json
out=Path(sys.argv[1]);marker=Path(sys.argv[2]);out.mkdir(exist_ok=False)
started=time.monotonic()
while not marker.exists():
    if time.monotonic()-started>200:raise RuntimeError("No active preview marker; no performance read attempted")
    time.sleep(.1)
sock=socket.create_connection(("127.0.0.1",6666),timeout=3);sock.settimeout(10)
log=[]
def rpc(cmd):
    sock.sendall(cmd.encode()+b"\x1a");reply=b""
    while not reply.endswith(b"\x1a"):
        block=sock.recv(65536)
        if not block:raise RuntimeError("Debug connection closed")
        reply+=block
    text=reply[:-1].decode();log.append([cmd,text])
    if re.search(r"error:|failed|invalid command",text,re.I):raise RuntimeError(text)
    return text
def words(address,count):
    vals=[int(x,16) for x in re.findall(r"0x[0-9a-fA-F]+",rpc(f"read_memory {address:#x} 32 {count}"))]
    assert len(vals)==count;return vals
def sample():
    t=time.monotonic();perf=words(0x200ba1e8,7);dwt=words(0xe0001000,2)
    return {"time":t,"perf":perf,"dwt":dwt}
try:
    uid="".join(f"{x:08X}" for x in words(0x0bfa0700,3));assert uid=="001A0004434250062039314E",uid
    assert words(0xe000ed08,1)[0]==0x08020000,"APP must be running"
    a=sample();assert a["dwt"][0]&1,"DWT is not enabled; no write attempted"
    time.sleep(5);b=sample();delta=[(y-x)&0xffffffff for x,y in zip(a["perf"],b["perf"])];cycles=(b["dwt"][1]-a["dwt"][1])&0xffffffff
    assert delta[0]>0 and cycles>0,"No active Tap/cycle observations"
    result={"result":"pass","uid":uid,"before":a,"after":b,"seconds":b["time"]-a["time"],"delta":delta,"cycle_delta":cycles,"tap_cycle_fraction":delta[1]/cycles,"mean_tap_cycles":delta[1]/delta[0],"maximum_tap_cycles_since_boot":b["perf"][2],"scope":"Native preview Tap extraction/filter only; excludes foreground CRC/TX and all other firmware work. Non-halting read-only SWD; not whole-system CPU usage."}
    (out/"perf.json").write_text(json.dumps(result,indent=2),encoding="utf-8");print(json.dumps(result))
finally:
    try:rpc("shutdown")
    finally:sock.close();(out/"read-log.json").write_text(json.dumps(log,indent=2),encoding="utf-8")
