using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.Script.Serialization;
using Windows.Devices.Bluetooth;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Storage.Streams;

// Test observer only. All normal SD commands and waveform UI use the shipped assembly.
class BleSuite {
 const BindingFlags F=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Static|BindingFlags.Instance;
 static Assembly app; static object connection,current; static bool controlBusy; static int version; static uint sequence;
 static string output,action,uid; static StreamWriter writer; static Form root,preview; static int exitCode=1;
 static uint savedMask,savedHz; static bool startSent,stopSent;
 static Type T(string name){return app.GetType(name,true);}
 static object Get(object o,string name){var f=o.GetType().GetField(name,F);return f!=null?f.GetValue(o):o.GetType().GetProperty(name,F).GetValue(o,null);}
 static object Call(object o,string name,params object[] args){var type=o as Type??o.GetType();var m=type.GetMethods(F).Single(x=>x.Name==name&&x.IsStatic==(o is Type)&&x.GetParameters().Length==args.Length&&x.GetParameters().Select((p,i)=>args[i]==null||p.ParameterType.IsInstanceOfType(args[i])).All(x=>x));try{return m.Invoke(o is Type?null:o,args);}catch(TargetInvocationException e){throw e.InnerException??e;}}
 static object New(Type t,params object[] args){var c=t.GetConstructors(F).Single(x=>!x.IsStatic&&x.GetParameters().Length==args.Length&&x.GetParameters().Select((p,i)=>args[i]==null||p.ParameterType.IsInstanceOfType(args[i])).All(x=>x));return c.Invoke(args);}
 static uint U(object o,string name){return Convert.ToUInt32(Get(o,name));}
 static void Need(bool b,string s){if(!b)throw new IOException(s);}
 static void Log(string s){lock(writer){writer.WriteLine(DateTime.UtcNow.ToString("O")+" "+s);writer.Flush();}if(!s.StartsWith("request=")&&!s.StartsWith("reply="))Console.WriteLine(s);}
 static async Task<object> Await(object o){var t=(Task)o;await t;var p=t.GetType().GetProperty("Result");return p==null?null:p.GetValue(t,null);}
 static uint Next(){sequence=unchecked(sequence+1);if(sequence==0)sequence=1;return sequence;}
 static object Fields(object o){return o.GetType().GetFields(F).Where(x=>!x.IsStatic).ToDictionary(x=>x.Name,x=>x.GetValue(o));}
 static void Save(string name,object o){File.WriteAllText(Path.Combine(output,name+".json"),new JavaScriptSerializer{MaxJsonLength=Int32.MaxValue}.Serialize(o));}
 static async Task<byte[]> Exchange(byte[] b){return (byte[])await Await(Call(connection,"ExchangeAsync",(byte)0xb9,b,CancellationToken.None));}
 static byte[] Request(uint op,uint mask=0,uint hz=0,uint end=0,uint session=0,uint flags=0){return version==2?(byte[])Call(T("CE32_console.NpV2SdControl"),"Request",op,Next(),hz,end,0UL,mask==0?3U:mask):(byte[])Call(T("CE32_console.NpSdControl"),"Request",op,Next(),mask,hz,op==2?U(current,"Start"):0U,end,session,flags,0U);}
 static async Task<object> Send(byte[] b){controlBusy=true;try {Log("request="+BitConverter.ToString(b));var r=await Exchange(b);Log("reply="+BitConverter.ToString(r));var s=Call(T(version==2?"CE32_console.NpV2SdControl":"CE32_console.NpSdControl"),"Parse",r,BitConverter.ToUInt32(b,8),BitConverter.ToUInt32(b,12));current=s;sequence=U(s,"LastId")>sequence?U(s,"LastId"):sequence;Need(U(s,"Error")==0,"Device command error "+U(s,"Error")+"; fault "+U(s,"Fault"));return s;}finally{controlBusy=false;}}
 static async Task<object> Status(){return await Send(Request(0));}
 static void StatusLog(string label){Log(label+"="+new JavaScriptSerializer().Serialize(Fields(current)));}
 static Func<TStatus> StatusGetter<TStatus>(){return ()=> (TStatus)current;}
 static Func<Task<TStatus>> StatusReader<TStatus>(){return async()=> (TStatus)await Status();}
 static Func<byte[],Task<TStatus>> Sender<TStatus>(){return async b=>(TStatus)await Send(b);}
 static object Delegate(string method){return typeof(BleSuite).GetMethod(method,F).MakeGenericMethod(T("CE32_console.NpSdStatus")).Invoke(null,null);}
 static async Task Identify(){
  if(version==2){var transport=New(T("USB512_interface.NpBleForm+ConfigTransport"),connection,null);var client=New(T("USB512_interface.Np2ConfigClient"),transport);var caps=await Await(Call(client,"CapsAsync",(byte)0,CancellationToken.None));
   string found=U(caps,"Uid0").ToString("X8")+U(caps,"Uid1").ToString("X8")+U(caps,"Uid2").ToString("X8");Save("caps",Fields(caps));Need(found==uid,"V2 MCU UID mismatch");Need((U(caps,"AvailableMask")&7)==7,"Three physical ports not available");Log("uid_verified="+found);
  }else{
   var rx=(GattCharacteristic)Get(connection,"rx");var pending=new List<byte>();var done=new TaskCompletionSource<string>();
   Windows.Foundation.TypedEventHandler<GattCharacteristic,GattValueChangedEventArgs> receive=(s,e)=>{var data=new byte[e.CharacteristicValue.Length];using(var read=DataReader.FromBuffer(e.CharacteristicValue))read.ReadBytes(data);lock(pending){pending.AddRange(data);for(int at=0;at+22<=pending.Count;at++)if(pending[at]==0xad&&pending[at+1]==0xda&&pending[at+20]==0xda&&pending[at+21]==0xda){var bytes=pending.Skip(at).Take(22).ToArray();done.TrySetResult(BitConverter.ToUInt32(bytes,2).ToString("X8")+BitConverter.ToUInt32(bytes,6).ToString("X8")+BitConverter.ToUInt32(bytes,10).ToString("X8"));}}};
   var transaction=(SemaphoreSlim)Get(connection,"transaction");await transaction.WaitAsync();rx.ValueChanged+=receive;try{await Await(Call(connection,"WriteFrame",new byte[]{0x3c,0xad,0xda,0x3e},(int)Get(connection,"Epoch"),CancellationToken.None));Need(await Task.WhenAny(done.Task,Task.Delay(5000))==done.Task,"V1 native full UID did not respond");Need(await done.Task==uid,"V1 MCU UID mismatch");Log("uid_verified="+await done.Task);}finally{rx.ValueChanged-=receive;transaction.Release();}
  }
 }
 static async Task<object> Catalog(string label){try{
  object c;if(version==1){Func<ushort,Task<byte[]>> read=async page=>(byte[])await Await(Call(connection,"ExchangeV1Storage",page,false));c=await Await(Call(T("USB512_interface.NpBleCatalog"),"ReadV1",current,read));}
  else{var reader=New(T("USB512_interface.NpV2BleCatalog"),Delegate("StatusReader"),(Func<byte[],Task<byte[]>>)Exchange,Delegate("Sender"),(Action)(()=>Need((bool)Get(connection,"Connected"),"Disconnected during catalog")));c=await Await(Call(reader,"Read"));}
  var records=((IEnumerable)Get(c,"Records")).Cast<object>().ToList();Save(label,records.Select(Fields).ToList());Log(label+"_count="+records.Count);return c;
 }catch(Exception e){Log(label+"_FAILED="+e);Save(label+"-failure",e.ToString());return null;}}
 static void OpenPreview(){preview=(Form)New(T(version==2?"USB512_interface.NpBlePreviewForm":"USB512_interface.NpV1BlePreviewForm"),connection,Delegate("StatusGetter"),(Func<bool>)(()=>controlBusy),null);preview.Show(root);}
 static Dictionary<string,object> PreviewSnapshot(string label){
  var rx=Get(preview,"multiReceiver");var value=new Dictionary<string,object>{{"label",label},{"checked",((CheckBox)Get(preview,"enabled")).Checked},{"info",((Label)Get(preview,"info")).Text},{"support",Get(preview,"multiSupport")},{"packets",rx==null?0:Get(rx,"Packets")},{"samples",rx==null?0:Get(rx,"Samples")},{"acknowledged",rx==null?0:Get(rx,"Acknowledged")},{"missing",rx==null?0:Get(rx,"Missing")},{"checksum_failures",rx==null?0:Get(rx,"ChecksumFailures")},{"channel",((NumericUpDown)Get(preview,"channel")).Value},{"probe",((NumericUpDown)Get(preview,"probe")).Value},{"channel2",((NumericUpDown)Get(preview,"channel2")).Value},{"probe2",((NumericUpDown)Get(preview,"probe2")).Value},{"session",Get(preview,"multiSession")},{"hz",Get(preview,"multiRate")}};
  Save(label,value);Log("preview="+new JavaScriptSerializer().Serialize(value));using(var bmp=new Bitmap(preview.Width,preview.Height)){preview.DrawToBitmap(bmp,new Rectangle(Point.Empty,bmp.Size));bmp.Save(Path.Combine(output,label+".png"));}return value;
 }
 static Action<int,byte[]> originalReceiver,lossReceiver,wireObserver;static object lossTarget;static uint lostSequence;static int droppedOnce;static BinaryWriter wireFile;static readonly object wireGate=new object();
 static void BeginWire(){wireFile=new BinaryWriter(File.Create(Path.Combine(output,"preview-wire.bin")));wireObserver=(generation,body)=>{if(body!=null&&body.Length==224&&BitConverter.ToUInt32(body,0)==0x3256504e&&((BitConverter.ToUInt32(body,28)>>8)&255)==6)lock(wireGate)wireFile.Write(body);};T("USB512_interface.NpBleConnection").GetEvent("PreviewReceived",F).GetAddMethod(true).Invoke(connection,new object[]{wireObserver});}
 static void EndWire(){if(wireObserver!=null)T("USB512_interface.NpBleConnection").GetEvent("PreviewReceived",F).GetRemoveMethod(true).Invoke(connection,new object[]{wireObserver});wireObserver=null;lock(wireGate){if(wireFile!=null)wireFile.Dispose();wireFile=null;}}
 static void EnableLoss(){
  lossTarget=Get(preview,"multiReceiver");Need(lossTarget!=null,"No receiver for loss test");lostSequence=U(lossTarget,"Expected")+2;originalReceiver=(Action<int,byte[]>)Get(preview,"multiReceive");uint id=U(lossTarget,"id");
  lossReceiver=(generation,body)=>{if(body!=null&&body.Length==224&&BitConverter.ToUInt32(body,4)==id&&BitConverter.ToUInt32(body,32)==lostSequence&&Interlocked.CompareExchange(ref droppedOnce,1,0)==0)return;originalReceiver(generation,body);};
  var ev=T("USB512_interface.NpBleConnection").GetEvent("PreviewReceived",F);ev.GetRemoveMethod(true).Invoke(connection,new object[]{originalReceiver});ev.GetAddMethod(true).Invoke(connection,new object[]{lossReceiver});Log("drop_one_host_packet_seq="+lostSequence);
 }
 static void DisableLoss(){if(lossReceiver==null)return;var ev=T("USB512_interface.NpBleConnection").GetEvent("PreviewReceived",F);ev.GetRemoveMethod(true).Invoke(connection,new object[]{lossReceiver});if(preview!=null&&Get(preview,"multiReceiver")==lossTarget)ev.GetAddMethod(true).Invoke(connection,new object[]{originalReceiver});lossReceiver=originalReceiver=null;lossTarget=null;}
 static async Task Stop(){DisableLoss();if(stopSent)return;stopSent=true;if(preview!=null){preview.Close();preview.Dispose();preview=null;await Task.Delay(2500);}await Send(Request(3));Log("stop_sent_once=true");await WaitStopped();}
 static async Task WaitStopped(){var wait=Stopwatch.StartNew();while(wait.Elapsed.TotalSeconds<180){await Task.Delay(1000);await Status();StatusLog("stop_poll");if(!(bool)Get(current,"Busy")&&U(current,"State")== (version==2?5U:3U)){Need(U(current,"Fault")==0,"Stopped with fault");Log("stop_confirmed=true; drain_ms="+wait.ElapsedMilliseconds);return;}Need(U(current,"Fault")==0,"Recording fault during Stop");}throw new TimeoutException("Stop not confirmed; no replay");}
 static object imuSession;static int imuValid,imuSkipped,imuErrors;static readonly HashSet<uint> imuTicks=new HashSet<uint>();
 static async Task Imu(){
  using(var cancel=new CancellationTokenSource(900))try{
   var view=await (Task<byte[]>)Call(connection,"ReadImuSnapshot",cancel.Token);
   if(view==null){imuSkipped++;return;}
   File.WriteAllBytes(Path.Combine(output,"imu-"+imuValid.ToString("D3")+".bin"),view);
   var display=Call(imuSession,"Accept",view);uint valid=Convert.ToUInt32(Get(display,"Valid"));
   Need((valid&3)==3,"IMU must retain fresh AG and magnetic data");if((valid&3)==3){imuValid++;imuTicks.Add(Convert.ToUInt32(Get(display,"DeviceMs")));}
  }catch(Exception e){imuErrors++;Log("imu_disposable_error="+e);}
 }
 static async Task WaitProfile(uint mask,uint hz){var wait=Stopwatch.StartNew();while(wait.Elapsed.TotalSeconds<30){await Status();Need(U(current,"Fault")==0,"Profile fault");if(!(bool)Get(current,"Busy")&&U(current,"Mask")==mask&&U(current,"Hz")==hz)return;await Task.Delay(500);}throw new TimeoutException("Profile not confirmed; no replay");}
 static async Task Phase(string label,int seconds){
  var watch=Stopwatch.StartNew();uint first=U(current,"Chunks");var latency=new List<long>();int imuBefore=imuValid;
  while(watch.Elapsed.TotalSeconds<seconds){await Task.Delay(1000);var poll=Stopwatch.StartNew();await Status();latency.Add(poll.ElapsedMilliseconds);Need(U(current,"State")==3&&U(current,"Fault")==0,"Recording changed during "+label);await Imu();}
  var snapshot=PreviewSnapshot(label);Need((bool)snapshot["checked"]&&Convert.ToInt32(snapshot["packets"])>0,"Preview failed during "+label);
  Need(U(current,"Chunks")>first,"No committed progress during "+label);
  Save(label+"-status",new {seconds=watch.Elapsed.TotalSeconds,first_chunks=first,last_chunks=U(current,"Chunks"),status_ms=latency,imu_views=imuValid-imuBefore});
 }
 static async Task WaitPreview(string label){
  var wait=Stopwatch.StartNew();while(wait.Elapsed.TotalSeconds<20){
   await Task.Delay(1000);await Status();Need(U(current,"State")==3&&U(current,"Fault")==0,"Recording changed while awaiting "+label);
   var rx=Get(preview,"multiReceiver");Log("preview_wait="+label+"; elapsed="+wait.ElapsedMilliseconds+"; packets="+(rx==null?0:Get(rx,"Packets"))+"; info="+((Label)Get(preview,"info")).Text);
   if(rx!=null&&Convert.ToInt64(Get(rx,"Packets"))>=3)return;Need(((CheckBox)Get(preview,"enabled")).Checked,"Preview disabled while awaiting "+label);
  }PreviewSnapshot(label+"-timeout");throw new TimeoutException("No preview data within20s for "+label);
 }
 static async Task Record(){
  Need(version==2&&U(current,"Fault")==0&&!(bool)Get(current,"Busy"),"Exact idle V2 required");Need((U(current,"Mask")==3||U(current,"Mask")==7)&&U(current,"Hz")==20000,"Known P12/P12320k profile required");savedMask=3;savedHz=20000;Save("initial-status",Fields(current));
  var before=await Catalog("catalog-before");Need(before!=null,"Initial catalog unavailable");var json=new JavaScriptSerializer();var prior=((IEnumerable)Get(before,"Records")).Cast<object>().Select(x=>json.Serialize(new[]{U(x,"Id"),U(x,"Start"),U(x,"End"),U(x,"Cookie"),U(x,"Session"),U(x,"Hz"),U(x,"Mask"),U(x,"Flags")&~0x30000U})).ToList();
  await Status();await Send(Request(1,7,20000));await WaitProfile(7,20000);
  uint blocks=(uint)Call(T("USB512_interface.NpSdLoggerTest"),"Blocks",7U,20000U,90U);Need((ulong)blocks*49152<6UL*1024*1024*1024,"Reservation exceeds6GiB");
  var clock=New(T("USB512_interface.NpBleClock"));await Await(Call(clock,"Initialize",current,(Func<byte[],Task<byte[]>>)Exchange,(Func<uint>)Next));Need((bool)Get(clock,"Synchronized"),"PC clock not initialized");Log("pc_clock_initialized=true; generation="+Get(clock,"Generation"));
  imuSession=New(T("USB512_interface.NpBleImuSession"),output,uid);
  try{
   startSent=true;await Send(Request(2,7,20000,blocks));var wait=Stopwatch.StartNew();bool recording=false;
   while(wait.Elapsed.TotalSeconds<65){await Task.Delay(500);await Status();Need(U(current,"Fault")==0,"Start fault");if(U(current,"State")==3&&U(current,"Chunks")>0){recording=true;break;}}
   Need(recording,"Recording not confirmed");Save("recording-status",Fields(current));OpenPreview();
   ((NumericUpDown)Get(preview,"probe")).Value=1;((NumericUpDown)Get(preview,"channel")).Value=0;await WaitPreview("initial-two500");File.WriteAllText(Path.Combine(output,"preview-active.flag"),"two500");await Phase("two500-p1ch0-p2ch1",8);
   EnableLoss();await Phase("two500-recovered-original",7);var rx=Get(preview,"multiReceiver");Need(droppedOnce==1&&U(rx,"Acknowledged")>lostSequence+2&&U(rx,"Missing")==0,"Dropped packet did not recover contiguously");Save("replay-result",new{dropped=1,sequence=lostSequence,acknowledged=U(rx,"Acknowledged"),missing=U(rx,"Missing")});DisableLoss();
   ((NumericUpDown)Get(preview,"probe")).Value=2;((NumericUpDown)Get(preview,"channel")).Value=383;((NumericUpDown)Get(preview,"probe2")).Value=1;((NumericUpDown)Get(preview,"channel2")).Value=128;
   Need(((CheckBox)Get(preview,"enabled")).Checked,"Selection change unchecked Preview");((NumericUpDown)Get(preview,"windowSeconds")).Value=1;((NumericUpDown)Get(preview,"gainBox")).Value=2;
   await WaitPreview("two500-selection-change");await Phase("two500-p2ch383-p1ch128",8);
   await Stop();Save("stopped-status",Fields(current));var after=await Catalog("catalog-after");Need(after!=null,"Final catalog unavailable");
   var now=((IEnumerable)Get(after,"Records")).Cast<object>().Select(x=>json.Serialize(new[]{U(x,"Id"),U(x,"Start"),U(x,"End"),U(x,"Cookie"),U(x,"Session"),U(x,"Hz"),U(x,"Mask"),U(x,"Flags")&~0x30000U})).ToList();Need(now.Count==prior.Count+1&&prior.SequenceEqual(now.Take(prior.Count)),"Prior catalog changed or recording missing");
   Need(imuValid>=3&&imuTicks.Count>=3,"Fewer than three changing valid IMU observations");Save("imu-summary",new{valid=imuValid,distinct_native_ticks=imuTicks.Count,skipped=imuSkipped,errors=imuErrors});
   if(savedMask!=7||savedHz!=20000){await Status();await Send(Request(1,savedMask,savedHz));await WaitProfile(savedMask,savedHz);}
   Save("final-status",Fields(current));Log("preview_start_stop_catalog_imu_pass=true; new_recording_readback_pending=true");
  }finally{if(imuSession!=null){((IDisposable)imuSession).Dispose();imuSession=null;}}
 }

 static async Task Run(string[] args){Need(args.Length==5&&args[1]=="F5D68A6BCC7C"&&args[2]=="2"&&(args[3]=="record"||args[3]=="return"),"Exact V2 address/family/action required");output=Path.GetFullPath(args[4]);Directory.CreateDirectory(output);Need(!File.Exists(Path.Combine(output,"events.log")),"Fresh output required");writer=new StreamWriter(Path.Combine(output,"events.log"));action=args[3];version=int.Parse(args[2]);uid=version==1?"001D00065942500B20313354":"001A0004434250062039314E";app=Assembly.LoadFrom(Path.GetFullPath(args[0]));
  AppDomain.CurrentDomain.AssemblyResolve+=(s,e)=>{string p=Path.Combine(Path.GetDirectoryName(Path.GetFullPath(args[0])),new AssemblyName(e.Name).Name+".dll");return File.Exists(p)?Assembly.LoadFrom(p):null;};connection=New(T("USB512_interface.NpBleConnection"));sequence=unchecked((uint)Environment.TickCount);
  using(var hash=SHA256.Create())using(var file=File.OpenRead(args[0]))Need(app.GetName().Version.ToString()=="1.0.0.143"&&BitConverter.ToString(hash.ComputeHash(file)).Replace("-","")=="A762E8C20986481999EF4D9714CB537B93BA68DC92A55AA7AB4347311BB17830","Exact compiled143 required");
  try{Log("version="+FileVersionInfo.GetVersionInfo(args[0]).FileVersion+"; uid="+uid+"; action="+action);await Await(Call(connection,"ConnectAsync",Convert.ToUInt64(args[1],16),(BluetoothAddressType?)BluetoothAddressType.Random));Log("connect="+Get(connection,"LastConnectDiagnostic"));
   Func<byte,byte[],CancellationToken,Task<byte[]>> exchange=(command,b,ct)=>(Task<byte[]>)Call(connection,"ExchangeAsync",command,b,ct);var tuple=await Await(Call(T("USB512_interface.NpBleConnection"),"ReadDevice",exchange,(Func<uint>)Next));Need((int)Get(tuple,"Item1")==version,"Wrong protocol generation");current=Get(tuple,"Item2");sequence=U(current,"LastId");StatusLog("initial");await Identify();
   if(action=="mount"){Need(version==2&&U(current,"State")==1&&!(bool)Get(current,"Busy"),"Mount requires idle V2");await Send((byte[])Call(T("CE32_console.NpV2SdControl"),"StorageRequest",Next(),false));for(int i=0;i<30;i++){await Task.Delay(250);await Status();if(!(bool)Get(current,"Busy")&&U(current,"Fault")==0)break;}Need(U(current,"Fault")==0&&!(bool)Get(current,"Busy"),"Mount not complete");await Send(Request(1,3,20000));await Status();StatusLog("mounted-restored");}else if(action=="record"){BeginWire();await Record();}else if(action=="catalog")await Catalog("catalog");else if(action=="return"){if(version==2&&U(current,"Mask")!=3){Need(!(bool)Get(current,"Busy")&&U(current,"Fault")==0,"Profile restore requires idle");await Send(Request(1,3,20000));await Status();Need(U(current,"Mask")==3&&U(current,"Hz")==20000,"Original profile not restored");Log("original_profile_restored=true");}Need(!(bool)Get(current,"Busy")&&U(current,"Fault")==0,"Return requires idle fault-zero");var b=version==2?(byte[])Call(T("CE32_console.NpV2SdControl"),"ModeRequest",Next(),2U):(byte[])Call(T("CE32_console.NpV1BleProtocol"),"Mode",current,Next(),4U);await Send(b);Log("USB_return_ack=true");}
   Log("observer_completed=true");exitCode=0;
  }catch(Exception e){Log("FAIL="+e);Save("failure",e.ToString());if(startSent&&!stopSent)try{await Status();if((bool)Get(current,"Busy")&&U(current,"Fault")==0)await Stop();}catch(Exception cleanup){Log("cleanup="+cleanup);}}
  finally{DisableLoss();EndWire();if(preview!=null){preview.Close();preview.Dispose();}Call(connection,"Disconnect");Call(connection,"Dispose");writer.Dispose();root.Close();}
 }
 [STAThread]static int Main(string[] args){Application.EnableVisualStyles();root=new Form{Text="WILD-X BLE hardware validation",Width=400,Height=100,ShowInTaskbar=false,StartPosition=FormStartPosition.Manual,Location=new Point(-20000,-20000)};root.Shown+=async(s,e)=>{try{await Run(args);}catch(Exception error){Console.Error.WriteLine(error);if(writer!=null){writer.WriteLine(error);writer.Flush();}root.Close();}};Application.Run(root);return exitCode;}
}
