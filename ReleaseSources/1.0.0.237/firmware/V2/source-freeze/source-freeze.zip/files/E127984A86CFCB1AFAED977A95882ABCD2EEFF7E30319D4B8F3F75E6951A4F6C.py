from pathlib import Path
import json,re,hashlib,subprocess,sys
T=Path(__file__).resolve().parent;B=Path('C:/Frank/Code/XE_NP/_artifacts/v2_spi_selected_detectors_20261104/usb-paired-r7');Q=Path('C:/Frank/Code/XE_NP/_artifacts/closed_loop_qualification_20261104/V2/build-usb');O=T/'build';O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();parent=json.loads((B/'receipt.json').read_text());assert parent['crc32']=='FFC27E5A' and sha(B/'application.bin')==parent['body_sha256']
link=(B/'application.lnp').read_text();objects=re.findall(r'"([^"\r\n]+\.o)"',link);pins={p:sha(p) for p in objects};expected=dict(parent['retained_objects'])
for u,c in parent['compiler_commands'].items():expected[Path(c[c.index('-o')+1]).as_posix()]=sha(c[c.index('-o')+1])
for p,h in pins.items():assert expected[p]==h,p
base=json.loads((Q/'receipt.json').read_text())['compile']['xe_np_usb_stream']['command'];commands={};sources={};newobjects=[]
for u in ['xe_np_usb_stream','xe_np_np2_capture_port','stm32u5xx_it','xe_np_np2_closed_loop_spi','xe_np_np2_closed_loop_carrier','xe_np_np2_cl_selected']:
 c=list(base);c[1:1]=['-I',str(T/'Core/Inc'),'-iquote',str(T/'Core/Src')];c=[a.replace('XE_NP_USB_SD_TEST_APP_CRC32=0x997160AFUL','XE_NP_USB_SD_TEST_APP_CRC32=0x99CC44F9UL') for a in c]
 src=T/'Core/Src'/(u+'.c');c[c.index('-c')+1]=str(src);c[c.index('-o')+1]=str(O/(u+'.o'));c[c.index('-MF')+1]=str(O/(u+'.d'))
 prior=json.loads((O/'pending.json').read_text()) if (O/'pending.json').exists() else {}
 if not (O/(u+'.o')).exists() or prior.get('source_pins',{}).get(str(src))!=sha(src):
  r=subprocess.run(c,cwd='D:/Code/XE_NP_V2',capture_output=True,text=True);(O/(u+'-compile.log')).write_text(r.stdout+r.stderr);assert not r.returncode,r.stdout+r.stderr
 old=[p for p in objects if Path(p).stem==u]
 if old:assert len(old)==1;link=link.replace(old[0],(O/(u+'.o')).as_posix());pins.pop(old[0])
 else:newobjects.append((O/(u+'.o')).as_posix())
 commands[u]=c;sources[str(src)]=sha(src)
link=''.join('"'+p+'"\n' for p in newobjects)+link
# Preserve exact existing PSSI/SPI2 data layout. Append the private14.5KiB
# reader to unused region6 memory; no MPU region, queue or camera arena moves.
oldscatter=Path(re.search(r'--scatter "([^"\r\n]+)"',link)[1]);scatter=oldscatter.read_text();at=' RW_NP_CAPTURE 0x200D0000 0x000D0000 { *(NP_CAPTURE) }';assert scatter.count(at)==1
scatter=scatter.replace(at,' RW_NP_CAPTURE 0x200D0000 0x000CB5F0 { *(NP_CAPTURE) }\n RW_CL_SELECTED 0x2019B600 0x00004A00 { *(NP2_CL_SELECTED) }');(O/'application.sct').write_text(scatter);link=link.replace(oldscatter.as_posix(),(O/'application.sct').as_posix())
for n in ['application.axf','application.map']:link=link.replace((B/n).as_posix(),(O/n).as_posix())
(O/'application.lnp').write_text(link)
deps={str(p):sha(p) for p in list((T/'Core/Src').glob('*'))+list((T/'Core/Inc').glob('*'))}
(O/'pending.json').write_text(json.dumps(dict(parent_crc32=parent['crc32'],expected_app_crc32='99CC44F9',compiler_commands=commands,source_pins=sources,overlay_dependency_pins=deps,retained_objects=pins,scope='USB-only passive P2 selected-word1/2detectors; explicit camera/privateC15 IRQ ownership, pure existing counter64, separate root-session/sourceepoch; SDAPP99 unchanged'),indent=2)+'\n')
if '--compile-only' in sys.argv:print('Six targeted USB objects compiled');sys.exit()
if '--map-only' not in sys.argv:
 r=subprocess.run(['C:/Keil_v5/ARM/ARMCLANG/bin/armlink.exe','--via',str(O/'application.lnp')],capture_output=True,text=True);(O/'link.log').write_text(r.stdout+r.stderr);assert not r.returncode,r.stdout+r.stderr
def symbols(text):return {(m[1],m[4]):(int(m[2],16),int(m[3])) for m in re.finditer(r'^\s+(\S+)\s+(0x[\da-fA-F]+)\s+Data\s+(\d+)\s+([^\r\n]+)',text,re.M)}
before=symbols((B/'application.map').read_text());after=symbols((O/'application.map').read_text());same={}
for k,(a,n) in before.items():
 if k[1].endswith('(NP_CAPTURE)'):assert after[k]==(a,n),(k,(a,n),after.get(k));same[' | '.join(k)]=dict(address=hex(a),bytes=n)
assert same
new={k[0]:dict(address=hex(a),bytes=n) for k,(a,n) in after.items() if k[1].endswith('(NP2_CL_SELECTED)')};assert new and all(0x2019b600<=int(v['address'],16) and int(v['address'],16)+v['bytes']<=0x201a0000 for v in new.values())
(O/'memory-proof.json').write_text(json.dumps(dict(status='PASS',unchanged_np_capture_symbols=same,private_selected_nc_symbols=new,claim='Existing region6 only; USB22slot queue arenas/camera/SD download memory selectors unchanged'),indent=2)+'\n');print('USB selected build linked; capture buffers unchanged')
