#ifndef XE_NP_NP2_CONFIG_H
#define XE_NP_NP2_CONFIG_H
#include <stdint.h>

/* V2-only, foreground configuration. No work is added to capture/SD ISRs. */
#define N2C_FRAME 64U
#define N2C_BYTES 876U
#define N2C_CHUNK 32U
enum {N2C_USB=1U,N2C_BLE=2U};
enum {N2C_STATUS=0U,N2C_BEGIN=1U,N2C_WRITE=2U,N2C_COMMIT=3U,N2C_ABORT=4U,N2C_CAPS=5U};
enum {N2C_OK=0U,N2C_BAD_FRAME=1U,N2C_BUSY=2U,N2C_OWNER=3U,N2C_RANGE=4U,
      N2C_ORDER=5U,N2C_CRC=6U,N2C_INVALID=7U,N2C_UNSUPPORTED=8U,
      N2C_APPLY_FAILED=9U,N2C_EXPIRED=10U};
enum {N2C_NONE=0U,N2C_RECEIVING=1U,N2C_STAGED=2U,N2C_APPLIED=3U,N2C_FAILED=4U};
/* Verified means all six double-shift comparators and fixed control reads
 * passed. It is not an analog-quality or electrode-routing measurement. */
#define N2C_VERIFY_CHAIN_CONTROL 1U
/* Partial-probe receipt: bit1 means selected electrode/reference shanks and
 * both base/control chains passed; bits4..7 identify failed UNUSED shanks.
 * Bit0 stays clear: do not claim that all six chains passed. */
#define N2C_VERIFY_SELECTED_CHAIN_CONTROL 2U
/* Best-effort receipt: base/control passed but at least one selected shank
 * did not compare. Low nibble3 is NOT full/selected verification; upper
 * nibble records failed shanks1..15. Requested mapping stays unverified. */
#define N2C_VERIFY_UNVERIFIED_SHANKS 3U
#define N2C_VERIFY_FAILED_SHANK_SHIFT 4U
uint32_t XE_NP_Np2Config_Crc(const uint8_t *p,uint32_t n);
#if defined(XE_NP_NP2_PREPARATION_ENABLE) && XE_NP_NP2_PREPARATION_ENABLE
uint32_t XE_NP_Np2Config_Revision(void);
uint32_t XE_NP_Np2Config_Receiving(void);
uint32_t XE_NP_Np2Config_Fingerprint(uint32_t mask,uint32_t hz);
#endif
void XE_NP_Np2Config_Exchange(uint32_t owner,const uint8_t q[N2C_FRAME],uint32_t now,
                            uint32_t busy,uint32_t available_mask,const uint32_t uid[3],
                            uint8_t r[N2C_FRAME]);
void XE_NP_Np2Config_Disconnected(uint32_t owner);
/* Physical chain numbering: shanks 0..3, base-even 4, base-odd 5. */
const uint8_t *XE_NP_Np2Config_Chain(uint32_t port,uint32_t chain);
void XE_NP_Np2Config_BeginApply(uint32_t mask);
void XE_NP_Np2Config_Applied(uint32_t port);
void XE_NP_Np2Config_AppliedWithShankFailures(uint32_t port,uint32_t failed_shanks);
void XE_NP_Np2Config_AppliedWithUnverifiedShanks(uint32_t port,uint32_t failed_shanks);
void XE_NP_Np2Config_Failed(uint32_t mask);
/* Setup-time catalog provenance only; returns0 when the fixed default is used. */
const uint8_t *XE_NP_Np2Config_Selection(uint32_t port);
#endif
