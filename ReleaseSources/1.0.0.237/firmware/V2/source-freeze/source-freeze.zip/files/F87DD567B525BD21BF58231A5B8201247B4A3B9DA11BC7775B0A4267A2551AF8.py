"""Compact exact USB overlay freeze; no device access or firmware build."""
from pathlib import Path
import hashlib,json,re,shutil,zipfile
T=Path(__file__).resolve().parents[1];OUT=Path(__file__).resolve().parent
P=Path('C:/Frank/Code/XE_NP/_artifacts/v2_spi_selected_detectors_20261104/final-source-freeze')
Q=Path('C:/Frank/Code/XE_NP/_artifacts/v2_sd_recording_fix_20261104/input-freeze')
sha=lambda b:hashlib.sha256(b).hexdigest().upper()
def main():
 manifests={};index={}
 for parent in (P,Q):
  b=(parent/'manifest.json').read_bytes();r=json.loads(b);manifests[str(parent)]=dict(path=str(parent/'manifest.json'),sha256=sha(b),status=r.get('status'),inherited_limits=r.get('limits',[]))
  for f in r['files']:index[f['sha256']]=dict(manifest=str(parent/'manifest.json'),stored=f['stored'],sha256=f['sha256'])
 store=OUT/'files';store.mkdir(exist_ok=True);entries={};refs={};unresolved=[];cache={}
 def keep(p,category,expected=None,force=False):
  p=Path(p)
  if not p.is_file():unresolved.append(dict(path=str(p),category=category,reason='missing'));return
  if p not in cache:cache[p]=p.read_bytes()
  b=cache[p];h=sha(b)
  if expected:assert h==expected,(p,h,expected)
  if h in index and not force:refs[str(p)]=dict(**index[h],category=category);return h
  dest=store/(h+p.suffix.lower())
  if not dest.exists():dest.write_bytes(b)
  row=entries.setdefault(dest.name,dict(stored=str(dest.relative_to(OUT)),sha256=h,bytes=len(b),origins=[],categories=[]))
  if str(p) not in row['origins']:row['origins'].append(str(p))
  if category not in row['categories']:row['categories'].append(category)
  return h
 receipt_path=T/'build/receipt.json';build=json.loads(receipt_path.read_text());assert build['crc32']=='112066CE' and build['expected_app_crc32']=='99CC44F9'
 keep(receipt_path,'checked-incremental-build-receipt',force=True)
 for p,h in {**build['source_pins'],**build['overlay_dependency_pins']}.items():keep(p,'checked-overlay-source-or-header',h,force=True)
 custody=[]
 for p,h in json.loads((T/'source-preimages.json').read_text()).items():
  if Path(p).is_file() and sha(Path(p).read_bytes())==h:keep(p,'exact-preimage',h);custody.append(dict(path=p,sha256=h,status='exact-bytes-available'))
  elif h in index:custody.append(dict(path=p,sha256=h,status='exact-prior-blob-reference',reference=index[h]))
  else:unresolved.append(dict(path=p,sha256=h,reason='preimage-not-current-and-not-prior-index'))
 closure=[]
 for unit,command in build['compiler_commands'].items():
  dep=Path(command[command.index('-MF')+1]);keep(dep,'checked-compiler-dependency-file',force=True)
  text=dep.read_text().replace('\\\n',' ');text=re.sub(r'^.*?\.o:\s*','',text,count=1,flags=re.S);paths=[]
  for value in re.findall(r'(?:[A-Za-z]:[\\/]|\.\.?[\\/])(?:\\ |[^\s])+',text):
   p=Path(value.replace('\\ ',' '))
   if not p.is_absolute():p=Path('D:/Code/XE_NP_V2')/p
   if p.suffix.lower() not in {'.c','.h','.inc','.s','.asm'}:continue
   paths.append(str(p));keep(p,'dependency-snapshot-unless-separately-prebuild-pinned')
  closure.append(dict(unit=unit,dependency=str(dep),paths=paths,limit='Dependency names from actual compiler .d. Overlay hashes were pinned at build; other source/header current snapshots or prior matching blobs are preserved without inventing missing original compiler-time hash evidence.'))
 for n in ('application.lnp','application.sct','memory-proof.json','pending.json'):keep(T/'build'/n,'exact-link-scatter-input-or-memory-proof',force=True)
 for n in ('stage-source.py','source-preimages.json','source-overlay.json','build-usb.py','seal-usb.py','prepare-deployment.py','runtime-receipt.json','helper-receipt.json','validate_selected_native.py'):
  keep(T/n,'exact-recipe-or-host-helper-identity',force=True)
 keep(T/'NpV2ClUsbHil.cs','actual-hardware-capture-helper-source',force=True)
 for p in (T/'native').iterdir():
  if p.is_file() and p.suffix.lower() in {'.py','.cpp','.inc','.json','.log'}:keep(p,'focused-actual-native-proof',force=True)
 for p in (T/'audit').iterdir():
  if p.is_file() and p.suffix.lower() in {'.py','.md','.json','.c'}:keep(p,'bounded-audit-and-reconstructed-preimage-custody',force=True)
 for p in (T/'audit/sensors').iterdir():
  if p.is_file() and p.suffix.lower() in {'.py','.json'}:keep(p,'bounded-sensor-value-phase-proof',force=True)
 for run in ('usb-cl0','usb-cl1','usb-cl2','usb-cl2-restart'):
  for n in ('usb-report.json','stopped-summary.json','selected-native-proof.json','neuropixels_np2usb_status.txt','closed_loop_status.txt','imu_grid_status.txt','imu_observation_status.txt','imu_native_samples_status.json','analogin_encoding.txt','imu_grid_phase.bin','imu_grid_terminal.bin','imu_grid_segments.csv','imu_grid_gaps.csv'):
   p=T/run/n
   if p.is_file():assert p.stat().st_size<262144,(p,'unbounded evidence');keep(p,'completed-capture-compact-evidence',force=True)
 keep(Path(__file__),'freeze-reproducer',force=True)
 manifest=dict(status='USB112066CE_SOURCE_FROZEN_CANDIDATE_PENDING_RESTART_AND_RESTORE',usb=dict(crc32=build['crc32'],expected_app_crc32=build['expected_app_crc32'],body_sha256=build['body_sha256'],hex_sha256=build['hex_sha256']),unchanged_app_crc32='99CC44F9',scope='V2USB3probe20kHz P2ADC0/1 event-only Ripple6 selected reader; ordinary camera/AUX retained with CL disabled; runtime camera request rejected for optional CL. No V1 or SD APP bytes changed.',compiler_commands=build['compiler_commands'],link_command=dict(tool='C:/Keil_v5/ARM/ARMCLANG/bin/armlink.exe',arguments=['--via',str(T/'build/application.lnp')]),checked_source_pins=build['source_pins'],checked_overlay_pins=build['overlay_dependency_pins'],retained_object_identities=build['retained_objects'],preimage_custody=custody,dependency_closure=closure,prior_freezes=manifests,prior_blob_references=refs,files=list(entries.values()),unresolved=unresolved,stored_bytes=sum(x['bytes'] for x in entries.values()),limits=['Source/evidence freeze is not hardware acceptance. Final restart and exact original restoration remain pending at freeze time.','No firmware rebuild was performed. Reproduction depends on recorded retained objects and toolchain; inherited original-source/header gaps remain explicit in prior manifests.','Non-overlay dependencies have actual compiler dependency names and preserved current/prior matching source bytes, not invented absent prebuild hashes.','No neural DAT, analogin payload, full original capture, firmware archive or toolchain binary is copied/read/hashed here. Sensor review sidecar hashes are retained in their compact receipts.','Sensor journal20Hz sampling gaps are not primary1250Hz row loss; actualUSB MAG observed25Hz, not100Hz. Terminal source-window false and unknown final ordinal are preserved.'],no_hardware=True,no_firmware_build=True,no_canonical_edits=True)
 manifest['status']='USB112066CE_SOURCE_FROZEN_CANDIDATE_PENDING_RESTORATION'
 manifest['limits'][0]='Source/evidence freeze is not final hardware acceptance. Recorded short restart evidence is included; exact original restoration and final qualification decision remain pending at freeze time.'
 (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files=[OUT/'manifest.json',Path(__file__),*[OUT/x['stored'] for x in sorted(entries.values(),key=lambda x:x['stored'])]]
 (OUT/'filelist.txt').write_text('\n'.join(str(p.relative_to(OUT))+' '+sha(p.read_bytes()) for p in files)+'\n')
 with zipfile.ZipFile(OUT/'source-freeze.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in [*files,OUT/'filelist.txt']:z.write(p,str(p.relative_to(OUT)))
 with zipfile.ZipFile(OUT/'source-freeze.zip') as z:
  assert z.testzip() is None
  for f in manifest['files']:assert sha(z.read(f['stored'].replace('\\','/')))==f['sha256']
 print(json.dumps(dict(status=manifest['status'],files=len(entries),stored_bytes=manifest['stored_bytes'],prior_refs=len(refs),unresolved=len(unresolved),manifest_sha256=sha((OUT/'manifest.json').read_bytes()),zip_bytes=(OUT/'source-freeze.zip').stat().st_size,zip_sha256=sha((OUT/'source-freeze.zip').read_bytes())),indent=2))
if __name__=='__main__':main()
