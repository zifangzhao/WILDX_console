"""Focused exact USB optional-reader lifecycle + carrier admission native test."""
from pathlib import Path
import hashlib,json,re,subprocess
T=Path(__file__).resolve().parents[1];OUT=Path(__file__).resolve().parent
R=Path('D:/Code/XE_NP_V2');P=Path('C:/Frank/Code/XE_NP/_artifacts/v2_spi_selected_detectors_20261104')
VC=Path('C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def ex(s,sig):
 a=s.index(sig);b=s.index('{',a);n=1;e=b+1
 while n:n+=(s[e]=='{')-(s[e]=='}');e+=1
 return s[a:e]+'\n'
PRE=r'''
#include <stdint.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <limits.h>
#include "constants.inc"
#include "xe_np_np2_closed_loop_carrier.h"
#include "np_cl_control_wire.h"
#include "np_cl_coefficients.h"
#define BOOT_WORDS 3072U
#define ROWS 256U
#define HALF 128U
#define ERRORS (DMA_FLAG_DTE|DMA_FLAG_ULE|DMA_FLAG_USE|DMA_FLAG_TO)
typedef struct {uint32_t Request,BlkHWRequest,Direction,SrcInc,DestInc,SrcDataWidth,DestDataWidth,Priority,SrcBurstLength,DestBurstLength,TransferAllocatedPort,TransferEventMode,Mode;} DMA_InitTypeDef;
typedef struct {uint32_t DataExchange,DataAlignment;} DMA_DataHandlingConfTypeDef;
typedef struct {uint32_t TriggerMode,TriggerPolarity,TriggerSelection;} DMA_TriggerConfTypeDef;
typedef struct {uint32_t RepeatCount;int32_t SrcAddrOffset,DestAddrOffset,BlkSrcAddrOffset,BlkDestAddrOffset;} DMA_RepeatBlockConfTypeDef;
typedef struct {uint32_t NodeType;DMA_InitTypeDef Init;DMA_DataHandlingConfTypeDef DataHandlingConfig;DMA_TriggerConfTypeDef TriggerConfig;DMA_RepeatBlockConfTypeDef RepeatBlockConfig;uint32_t SrcAddress,DstAddress,DataSize;} DMA_NodeConfTypeDef;
typedef struct {uint32_t LinkRegisters[8],NodeInfo;} DMA_NodeTypeDef;
static uint32_t bootstrap[BOOT_WORDS],selected[ROWS][2],scratch[2];static DMA_NodeTypeDef node[4];
struct DMARegs {uint32_t CCR,CSR,CFCR,CBR1,CLLR,CDAR;};static DMARegs dm;
struct SPIRegs {uint32_t CR1,CR2,CFG1,CFG2,IER,IFCR,SR,RXDR;};static SPIRegs sp;
static struct {uint32_t CR;} dc,dbg;static struct {uint32_t CTRL,RNR;} mp;
static struct {uint32_t ISER[8],ISPR[8];} nv;static struct {uint32_t CYCCNT;} dw;
#define GPDMA1_Channel15 (&dm)
#define SPI1 (&sp)
#define DCACHE1 (&dc)
#define DBGMCU (&dbg)
#define MPU (&mp)
#define NVIC (&nv)
#define DWT (&dw)
#define GPDMA1_Channel15_IRQn 46U
#define SPI1_IRQn 35U
#define GPIOB ((void*)1)
static uint32_t SystemCoreClock,enabled,configured,consumed,first_frame,first_word,phase_value;
static uint32_t completed,events,enable_cycles,first_irq_deadline,irq_last,offer_last;
static uint32_t enable_fine,fine_domain,fine_generation,fine_epoch,irq_last_fine,offer_last_fine;
static int32_t delta;static uint16_t channels[2],offsets[2];static uint8_t count,field_bits[2];
static volatile uint32_t xe_np_np2_cl_selected_diag[32],xe_np_np2_cl_selected_guard[16],xe_np_np2_cl_selected_clock[10],xe_np_np2_cl_selected_calibration[10];
static uint32_t writes,halstep,failstep,ncokay,camera_calls,irq_pending,hold_suspend,hold_reset,partial_start,readfail;
static uint32_t primary_timer[8]={11,22,33,44,55,66,77,88};
static uint32_t HAL_GetTick(void){return 123;}
static int noncacheable_dma_memory(void){return (int)ncokay;}
static void XE_NP_MediaCamera_DmaIrq(void){camera_calls++;}
static void selected_dma_irq(void);
static void (*dma_irq_owner)(void)=XE_NP_MediaCamera_DmaIrq;
static void mutset(uint32_t &reg,uint32_t b){writes++;reg|=b;if(&reg==&dm.CCR){if((b&DMA_CCR_SUSP)&&!hold_suspend)dm.CSR|=DMA_FLAG_SUSP;if((b&DMA_CCR_RESET)&&!hold_reset){dm.CCR=0;dm.CSR=0;}}}
#define SET_BIT(r,b) mutset((r),(b))
#define CLEAR_BIT(r,b) do{writes++;(r)&=~(b);}while(0)
#define __DMB() ((void)0)
#define __DSB() ((void)0)
#define __NOP() ((void)0)
static void HAL_NVIC_DisableIRQ(uint32_t){writes++;nv.ISER[1]&=~(1U<<(46-32));}
static void HAL_NVIC_ClearPendingIRQ(uint32_t){writes++;irq_pending=0;nv.ISPR[1]&=~(1U<<14);}
#define __HAL_RCC_GPIOB_CLK_ENABLE() (++writes)
#define __HAL_RCC_SPI1_CONFIG(x) (++writes)
#define __HAL_RCC_SPI1_CLK_ENABLE() (++writes)
#define __HAL_RCC_SPI1_FORCE_RESET() (++writes)
#define __HAL_RCC_SPI1_RELEASE_RESET() (++writes)
typedef struct {uint32_t Pin,Mode,Pull,Speed,Alternate;} GPIO_InitTypeDef;
static void HAL_GPIO_Init(void*,GPIO_InitTypeDef*){writes++;}
typedef struct {DMARegs *Instance;struct {uint32_t Priority,LinkStepMode,LinkAllocatedPort,TransferEventMode,LinkedListMode;} InitLinkedList;} DMA_HandleTypeDef;
typedef struct {uint32_t dummy;} DMA_QListTypeDef;static DMA_HandleTypeDef rx;static DMA_QListTypeDef list;
static int next(){return ++halstep==failstep?1:0;}
static int HAL_DMAEx_List_Init(DMA_HandleTypeDef*){return next();}
static int HAL_DMAEx_List_BuildNode(DMA_NodeConfTypeDef*,DMA_NodeTypeDef*){return next();}
static int HAL_DMAEx_List_InsertNode_Tail(DMA_QListTypeDef*,DMA_NodeTypeDef*){return next();}
static int HAL_DMAEx_List_SetCircularModeConfig(DMA_QListTypeDef*,DMA_NodeTypeDef*){return next();}
static int HAL_DMAEx_List_LinkQ(DMA_HandleTypeDef*,DMA_QListTypeDef*){return next();}
static int HAL_DMAEx_List_Start(DMA_HandleTypeDef*){int r=next();if(!r||partial_start)dm.CCR|=DMA_CCR_EN;return r;}
#define HAL_OK 0
#define XE_NP_NP2_SD_FINE_HZ 1000000U
typedef struct {uint32_t counter,domain,counter_hz,generation,source_epoch;} XE_NP_Np2SdFinePoint;
typedef struct {uint64_t counter;uint32_t domain,counter_hz,generation,source_epoch;} XE_NP_Np2SdFinePoint64;
static XE_NP_Np2SdFinePoint64 fine;
static int XE_NP_Np2SdFineClock_ReadIrq(uint32_t,XE_NP_Np2SdFinePoint*p){p->counter=(uint32_t)fine.counter;p->domain=fine.domain;p->counter_hz=fine.counter_hz;p->generation=fine.generation;p->source_epoch=fine.source_epoch;return !readfail;}
static int XE_NP_Np2SdFineClock_Read64Irq(uint32_t,XE_NP_Np2SdFinePoint64*p){*p=fine;return !readfail;}
static uint32_t frontier(void){return completed;}
static XE_NP_Np2ClWorkspace *port;
#define XE_NP_USB_AUX_CAMERA 1U
static struct {uint32_t flags;} xe_np_aux;
static XE_NP_Np2ClSourceProof gotproof;static uint32_t configure_calls;
void XE_NP_Np2ClRuntime_Ensure(void){}
int XE_NP_Np2ClWorkspace_Configure(XE_NP_Np2ClWorkspace*w,const uint8_t*,const XE_NP_Np2ClSourceProof*p){gotproof=*p;configure_calls++;w->carrier.session=p->session;w->source.config.source_epoch=p->source_epoch;w->source.enabled=1;return 0;}
static void selected_dma_irq(void);
void XE_NP_Np2ClSelected_Stop(void);
#include "actual.inc"
static void makebody(uint8_t*b,uint32_t op,uint32_t n,uint32_t hz=20000,uint32_t probe=2,uint32_t filter=6,uint32_t ch=0){
 memset(b,0,64);memcpy(b,"NPCC",4);np_cl_wire_u32(b+4,1);np_cl_wire_u32(b+8,op);np_cl_wire_u32(b+12,123);
 if(op==1&&n){np_cl_wire_u32(b+20,hz);np_cl_wire_u32(b+28,1000);np_cl_wire_u32(b+32,n);
  float gain=3;uint32_t g;memcpy(&g,&gain,4);for(unsigned i=0;i<n;i++){np_cl_wire_u32(b+36+i*8,probe|(filter<<8)|((ch+i)<<16));np_cl_wire_u32(b+40+i*8,g);}}
 np_cl_wire_u32(b+60,np_cl_wire_crc(b,60));
}
static XE_NP_Np2ClWorkspace workspace;
static void fresh(){
 memset(&dm,0,sizeof(dm));memset(&sp,0,sizeof(sp));memset(&nv,0,sizeof(nv));memset(&workspace,0,sizeof(workspace));
 writes=halstep=failstep=camera_calls=irq_pending=hold_suspend=hold_reset=partial_start=readfail=0;
 ncokay=1;SystemCoreClock=128000000;dc.CR=0x101;dbg.CR=0;mp.CTRL=5;mp.RNR=7;
 enabled=configured=completed=events=0;dma_irq_owner=XE_NP_MediaCamera_DmaIrq;port=&workspace;configure_calls=0;
 uint8_t body[64];makebody(body,1,2);memcpy(port->carrier.confirmed_config,body,64);port->staged=port->prepared=1;
 fine={100000,3,1000000,9,11};fine_domain=3;fine_generation=9;fine_epoch=11;
}
static void carrier_test(){
 uint8_t body[64],reply[64];fresh();makebody(body,0,0);
 assert(XE_NP_Np2ClCarrier_PortControl(body,reply,0,7,20000,1)==1);
 assert(get32(reply+40)==2 && get32(reply+44)==2 && get32(reply+48)==64 && get32(reply+52)==8);
 for(unsigned n=1;n<=2;n++){
  makebody(body,1,n);assert(XE_NP_Np2ClCarrier_PortControl(body,reply,0,7,20000,1)==1 && !get32(reply+16));
  XE_NP_Np2ClCarrier_PortBeginAttempt();assert(XE_NP_Np2ClCarrier_PortPrepare(0,7,20000,6,32,1));XE_NP_Np2ClCarrier_PortTiming(0x12345678);
  XE_NP_Np2ClStartupReceipt r={0};r.timing_token=0x12345678;r.timing_generation=9;r.source_epoch=11;r.native_hz=20000;r.source_hz=32000000;r.anchor_flags=0x205;r.matches=1;r.record_mask=7;r.copied=1;
  assert(XE_NP_Np2ClCarrier_PortAttest(&r,0,0)==1 && gotproof.session==9 && gotproof.source_epoch==11);
 }
 for(unsigned bad=0;bad<5;bad++){
  fresh();port->carrier.generation=4;port->carrier.session=0;port->timing_token=123;
  XE_NP_Np2ClStartupReceipt r={0};r.timing_token=123;r.timing_generation=9;r.source_epoch=11;r.native_hz=20000;r.source_hz=32000000;r.anchor_flags=0x205;r.matches=1;r.record_mask=7;r.copied=1;
  if(bad==0)r.timing_token++;if(bad==1)r.timing_generation=0;if(bad==2)r.source_epoch=0;
  assert(XE_NP_Np2ClCarrier_PortAttest(&r,bad==3?1:0,bad==4?1:0)==-1 && !configure_calls);
 }
 for(unsigned bad=0;bad<6;bad++){
  fresh();makebody(body,1,1,bad==0?15000:20000,bad==1?3:2,bad==2?5:6,bad==3?2:0);
  assert(XE_NP_Np2ClCarrier_PortControl(body,reply,0,7,20000,bad==4?0:1)==1);
  if(bad<5)assert(get32(reply+16)!=0);
 }
}
int main(){
 fresh();XE_NP_Np2ClSelected_DmaDispatch();assert(camera_calls==1 && !writes);
 fresh();port->prepared=0;assert(XE_NP_Np2ClSelected_Prepare()==0 && !writes && !enabled && dma_irq_owner==XE_NP_MediaCamera_DmaIrq);
 for(unsigned k=0;k<13;k++){
  fresh();if(k==0)sp.CR1=SPI_CR1_SPE;if(k==1)sp.CR1=SPI_CR1_CSTART;if(k==2)sp.CFG1=SPI_CFG1_RXDMAEN;if(k==3)sp.CFG1=SPI_CFG1_TXDMAEN;
  if(k==4)dm.CCR=DMA_CCR_EN;if(k==5)dbg.CR=DBGMCU_CR_TRACE_IOEN;if(k==6)nv.ISER[1]=1U<<14;if(k==7)SystemCoreClock=96000000;if(k==8)ncokay=0;if(k==9)nv.ISER[1]=1U<<3;if(k==10)nv.ISPR[1]=1U<<3;if(k==11)nv.ISPR[1]=1U<<14;if(k==12)sp.IER=1;
  DMARegs olddm=dm;SPIRegs oldsp=sp;assert(XE_NP_Np2ClSelected_Prepare()==-1 && !writes && !enabled && dma_irq_owner==XE_NP_MediaCamera_DmaIrq);
  assert(!memcmp(&olddm,&dm,sizeof(dm))&&!memcmp(&oldsp,&sp,sizeof(sp)));XE_NP_Np2ClSelected_DmaDispatch();assert(camera_calls==1);
 }
 for(unsigned f=1;f<=8;f++){
  fresh();failstep=f;partial_start=1;assert(XE_NP_Np2ClSelected_Prepare()==-1 && !enabled && !(dm.CCR&DMA_CCR_EN) && dma_irq_owner==XE_NP_MediaCamera_DmaIrq);
 }
 fresh();assert(XE_NP_Np2ClSelected_Prepare()==1 && enabled && dma_irq_owner==selected_dma_irq);
 uint32_t timer_before[8];memcpy(timer_before,primary_timer,sizeof(primary_timer));readfail=1;XE_NP_Np2ClSelected_Enable();
 assert(xe_np_np2_cl_selected_diag[2]==13 && !(sp.CR1&SPI_CR1_SPE) && !memcmp(timer_before,primary_timer,sizeof(primary_timer)));
 readfail=0;configured=1;xe_np_np2_cl_selected_diag[2]=0;fine_domain=3;fine_generation=9;fine_epoch=11;
 uint32_t now;assert(read_bound_fine(&now)&&now==100000);fine.source_epoch=12;assert(!read_bound_fine(&now));fine.source_epoch=11;fine.generation=8;assert(!read_bound_fine(&now));
 assert(!memcmp(timer_before,primary_timer,sizeof(primary_timer)));
 // Failed retirement keeps the selected owner and prevents a fresh Prepare.
 fresh();assert(XE_NP_Np2ClSelected_Prepare()==1);hold_suspend=hold_reset=1;irq_pending=1;nv.ISPR[1]=1U<<14;XE_NP_Np2ClSelected_Stop();
 assert(enabled && dma_irq_owner==selected_dma_irq && xe_np_np2_cl_selected_diag[2]==10 && irq_pending && nv.ISPR[1]);unsigned before=writes;
 assert(XE_NP_Np2ClSelected_Prepare()==-1 && writes==before && enabled && dma_irq_owner==selected_dma_irq);
 hold_suspend=hold_reset=0;XE_NP_Np2ClSelected_Stop();assert(!enabled&&dma_irq_owner==XE_NP_MediaCamera_DmaIrq);
 // Stale optional IRQ must be retired before restoring the camera dispatcher.
 fresh();assert(XE_NP_Np2ClSelected_Prepare()==1);irq_pending=1;nv.ISPR[1]=1U<<14;XE_NP_Np2ClSelected_Stop();assert(!enabled && !irq_pending && !nv.ISPR[1] && dma_irq_owner==XE_NP_MediaCamera_DmaIrq);
 xe_np_aux.flags=0;assert(np2_usb_cl_camera_free());xe_np_aux.flags=XE_NP_USB_AUX_CAMERA;assert(!np2_usb_cl_camera_free());xe_np_aux.flags=4;assert(np2_usb_cl_camera_free());
 carrier_test();puts("PASS actual USB Prepare/Enable/Stop/dispatch with13quiet guards,8HALfailures,partial-start cleanup,terminalhold/pendinghandoff,purefineclock; actualcarrier independent9session/11epoch+freshadmission+P2Ripple6caps/profile limits");
}
'''
def main():
 selected=T/'Core/Src/xe_np_np2_cl_selected.c';carrier=T/'Core/Src/xe_np_np2_closed_loop_carrier.c';s=selected.read_text();c=carrier.read_text()
 actual='\n'.join(ex(s,x) for x in ('static uint32_t low_link(', 'static void fault(', 'static int owner_quiet(', 'static void config_node(', 'void XE_NP_Np2ClSelected_DmaDispatch(', 'int XE_NP_Np2ClSelected_Prepare(', 'void XE_NP_Np2ClSelected_Enable(', 'static int read_bound_fine(', 'static void selected_dma_irq(void)\n{', 'void XE_NP_Np2ClSelected_Stop('))
 funcs=('static uint32_t get32(', 'static void add(', 'int XE_NP_Np2ClCarrier_Init(', 'void XE_NP_Np2ClCarrier_Stop(', 'static int source_selector(', 'int XE_NP_Np2ClCarrier_SelectedRequest(', 'int XE_NP_Np2ClCarrier_PortControl(', 'void XE_NP_Np2ClCarrier_PortBeginAttempt(', 'int XE_NP_Np2ClCarrier_PortPrepare(', 'void XE_NP_Np2ClCarrier_PortTiming(', 'int XE_NP_Np2ClCarrier_PortNeedsProof(', 'int XE_NP_Np2ClCarrier_PortAdmit(', 'int XE_NP_Np2ClCarrier_PortAttest(')
 actual+='\n'+'\n'.join(ex(c,x) for x in funcs)
 # The selected request implementation is later in actual.inc; declaration first.
 actual='int XE_NP_Np2ClCarrier_SelectedRequest(uint16_t*,uint8_t*);\n'+actual
 actual+=ex((T/'Core/Src/xe_np_usb_stream.c').read_text(),'static int np2_usb_cl_camera_free(void)')
 (OUT/'actual.inc').write_text(actual)
 definitions={}
 for p in [R/'Drivers/STM32U5xx_HAL_Driver/Inc'/x for x in ('stm32u5xx_hal_dma.h','stm32u5xx_hal_dma_ex.h','stm32u5xx_hal_spi.h','stm32u5xx_hal_gpio.h','stm32u5xx_hal_gpio_ex.h','stm32u5xx_hal_rcc_ex.h')]+[R/'Drivers/CMSIS/Device/ST/STM32U5xx/Include/stm32u595xx.h',R/'Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_dma_ex.c']:
  for line in p.read_text().replace('\\\n',' ').splitlines():
   z=re.match(r'\s*#define\s+(\w+)\s+(.+)',line)
   if z:definitions[z[1]]=z[2].split('/*')[0].strip()
 names=set(re.findall(r'\b(?:DMA|GPDMA\d*|NODE|SPI|GPIO|RCC|DBGMCU)_\w+\b',actual+PRE));names-={'DMA_InitTypeDef','DMA_DataHandlingConfTypeDef','DMA_TriggerConfTypeDef','DMA_RepeatBlockConfTypeDef','DMA_NodeConfTypeDef','DMA_NodeTypeDef','DMA_HandleTypeDef','DMA_QListTypeDef','GPIO_InitTypeDef'}
 names-=set(re.findall(r'^#define\s+(\w+)',PRE,re.MULTILINE))
 pending=list(names)
 while pending:
  n=pending.pop();assert n in definitions,'missingconstant '+n
  for dep in re.findall(r'\b(?:DMA|GPDMA\d*|NODE|SPI|GPIO|RCC|DBGMCU)_\w+\b',definitions[n]):
   if dep not in names:names.add(dep);pending.append(dep)
 (OUT/'constants.inc').write_text('\n'.join('#define '+n+' '+definitions[n] for n in sorted(names))+'\n')
 (OUT/'lifecycle.cpp').write_text(PRE)
 cmd=f'call "{VC}" >nul && cl /nologo /std:c++17 /W3 /O2 /DXE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE=1 /DXE_NP_NP2_CLOSED_LOOP_WORKSPACE_ENABLE=0 /DXE_NP_NP2_CLOSED_LOOP_PERF_ENABLE=0 /I"{R/"Core/Inc"}" /I"D:/Code/WILDX_console/WILDX_console/Neuropixels/ClosedLoop" /I"C:/Frank/Code/XE_NP/Firmware/V1/Core/Inc" "{OUT/"lifecycle.cpp"}" /Fo"{OUT/"lifecycle.obj"}" /Fe"{OUT/"lifecycle.exe"}"'
 b=subprocess.run(f'cmd /d /s /c "{cmd}"',cwd=OUT,capture_output=True,text=True,timeout=45);(OUT/'compile.log').write_text(b.stdout+b.stderr);assert not b.returncode,b.stdout+b.stderr
 r=subprocess.run([str(OUT/'lifecycle.exe')],cwd=OUT,capture_output=True,text=True,timeout=15);(OUT/'run.log').write_text(r.stdout+r.stderr);assert not r.returncode,r.stdout+r.stderr
 assert selected.read_text()==s and carrier.read_text()==c,'stagedsourcechanged'
 old_selected=(P/'Core/Src/xe_np_np2_cl_selected.c').read_text();reuse={}
 for sig in ('int XE_NP_Np2ClSelected_Calibrate(', 'int XE_NP_Np2ClSelected_Offer(', 'static uint32_t frontier(', 'static int read_bound_fine(', 'static void config_node(', 'static int noncacheable_dma_memory('):
  before=ex(old_selected,sig);after=ex(s,sig);assert before==after,('reusedfunctionchanged',sig);reuse[sig]=hashlib.sha256(after.encode()).hexdigest().upper()
 before=ex(old_selected,'void GPDMA1_Channel15_IRQHandler(').split('{',1)[1];after=ex(s,'static void selected_dma_irq(void)\n{').split('{',1)[1];assert before==after;reuse['IRQ_body_only_renamed_leaf']=hashlib.sha256(after.encode()).hexdigest().upper()
 spi=T/'Core/Src/xe_np_np2_closed_loop_spi.c';assert sha(spi)==sha(P/'Core/Src/xe_np_np2_closed_loop_spi.c')
 stream=T/'Core/Src/xe_np_np2_usb_stream.inc';text=stream.read_text()
 calls=[m.start() for m in re.finditer(r'np2_usb_first_stop\(\);',text)];assert len(calls)==2
 assert all(text[max(0,p-100):p].rstrip().endswith('XE_NP_Np2ClSelected_Stop();') for p in calls)
 assert text.count('&& np2_usb_cl_camera_free()')==2
 it=T/'Core/Src/stm32u5xx_it.c';assert it.read_text().count('void GPDMA1_Channel15_IRQHandler(void) { XE_NP_Np2ClSelected_DmaDispatch(); }')==1
 reuse['entire_resampler_source_sha256']=sha(spi)
 receipt=dict(status='PASS',selected_source_sha256=sha(selected),carrier_source_sha256=sha(carrier),stream_source_sha256=sha(stream),it_source_sha256=sha(it),fixture_cpp_sha256=sha(OUT/'lifecycle.cpp'),reproducer_sha256=sha(Path(__file__)),unchanged_SD99_proof_reuse=reuse,actual_extract_sha256=sha(OUT/'actual.inc'),command=cmd,output=r.stdout,limits='Actual lifecycle/admission functions extracted unchanged; MMIO/HAL/fineclock replies are simulated. Workspace_Configure endpoint is a proof-recording stub; full unchanged DSP/kernel/MPU/hotpath covered by reused exact-source receipts. No firmware build/hardware claim.')
 (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(r.stdout,end='');print('receiptSHA256 '+sha(OUT/'receipt.json'))
if __name__=='__main__':main()






