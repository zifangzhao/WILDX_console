#ifndef XE_NP_USB_AUX_H
#define XE_NP_USB_AUX_H
#include "xe_np_hal.h"
#ifndef XE_NP_V2_AUX_ENABLE
#define XE_NP_V2_AUX_ENABLE 0U
#endif
#ifndef XE_NP_NP2_FIRST_SYNC_ENABLE
#define XE_NP_NP2_FIRST_SYNC_ENABLE 0U
#endif
#if XE_NP_NP2_FIRST_SYNC_ENABLE
#include "xe_np_np2_first_sync_gate.h"
#else
typedef struct XE_NP_Np2FirstSyncGate XE_NP_Np2FirstSyncGate;
#endif
#if XE_NP_V2_AUX_ENABLE
/* Optional second IN endpoint on the same WinUSB interface. NP2 EP81 and
 * its packet/retention contract are unchanged. Foreground owns all work;
 * callbacks only deliver completion or cancellation tokens. */
#define XE_NP_USB_AUX_EP 0x82U
#define XE_NP_USB_AUX_CAMERA 1U
#define XE_NP_USB_AUX_ADC 2U
#define XE_NP_USB_AUX_IMU 4U
#define XE_NP_USB_AUX_SAFE 256U
#define XE_NP_USB_AUX_AV_ONLY 512U
/* Optional foreground provider, bound only while AUX is stopped. next copies
 * one serialized record into staging and returns 1 (claimed), 0 (not ready),
 * 2 (ended without a terminal) or -1 (fault). It must never block. The
 * matching completion is delivered exactly once after USB completion or an
 * AUX-only abort; compiling this API does not advertise grid capability. */
typedef int (*XE_NP_UsbAuxGridNext)(void *context,uint8_t *staging,uint32_t capacity,
    uint32_t *type,uint32_t *bytes,uint64_t *source,uint32_t draining);
typedef void (*XE_NP_UsbAuxGridComplete)(void *context,uint32_t type,uint32_t delivered);
int XE_NP_UsbAux_BindGrid(XE_NP_UsbAuxGridNext next,XE_NP_UsbAuxGridComplete complete,
                          void *context);
int XE_NP_UsbAux_Request(PCD_HandleTypeDef *,uint8_t request,uint8_t direction,
                        uint16_t value,uint16_t index,uint16_t length);
int XE_NP_UsbAux_PrepareCombined(void);
void XE_NP_UsbAux_RequestStop(void);
void XE_NP_UsbAux_Service(void);
void XE_NP_UsbAux_Complete(void);
void XE_NP_UsbAux_Interrupted(void);
uint32_t XE_NP_UsbAux_IsBusy(void);
uint32_t XE_NP_UsbAux_IsRunning(void);
uint32_t XE_NP_UsbAux_HoldsVcc(void);
int XE_NP_UsbAux_InitAdc(void);
int XE_NP_Board_SetAvCoreClock(void);
/* Core AUX IDs: IMU=1, ADC=2, camera=4. These are deliberately distinct
 * from the USB request flag bits. */
uint32_t XE_NP_UsbAux_FirstSyncMask(void);
void XE_NP_UsbAux_FirstSyncWait(void);
/* Returns the optional core-source mask withheld by the first-sync boundary. */
uint32_t XE_NP_UsbAux_FirstSyncRelease(XE_NP_Np2FirstSyncGate *gate);
void XE_NP_UsbAux_FirstSyncLegacy(void);
#else
#define XE_NP_UsbAux_PrepareCombined() 0
#define XE_NP_UsbAux_RequestStop() ((void)0)
#define XE_NP_UsbAux_Service() ((void)0)
#define XE_NP_UsbAux_IsBusy() 0U
#define XE_NP_UsbAux_IsRunning() 0U
#define XE_NP_UsbAux_HoldsVcc() 0U
#define XE_NP_UsbAux_FirstSyncMask() 0U
#define XE_NP_UsbAux_FirstSyncWait() ((void)0)
#define XE_NP_UsbAux_FirstSyncRelease(gate) ((void)(gate),0U)
#define XE_NP_UsbAux_FirstSyncLegacy() ((void)0)
#endif
#endif
