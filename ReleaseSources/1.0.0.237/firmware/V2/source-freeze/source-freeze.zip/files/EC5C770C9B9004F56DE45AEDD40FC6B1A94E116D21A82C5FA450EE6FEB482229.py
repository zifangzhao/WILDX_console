#!/usr/bin/env python3
"""Offline proof that retained P2 SPI native ADC words equal canonical P2 DAT."""
import argparse, hashlib, json, os, struct, sys, tempfile

ROWS, ROW_BYTES, DAT_ROW_BYTES = 64, 16, 768

def refuse(s): raise ValueError(s)
def u16(b,o): return struct.unpack_from('<H',b,o)[0]
def u32(b,o): return struct.unpack_from('<I',b,o)[0]
def u64(b,o): return struct.unpack_from('<Q',b,o)[0]
def digest(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for x in iter(lambda:f.read(1048576),b''):h.update(x)
    return h.hexdigest().upper()

def parse_workspace(path, layout):
    data=open(path,'rb').read()
    if len(data)!=layout['workspace_bytes']: refuse('workspace length differs from declared layout')
    if layout['native_row_bytes']!=ROW_BYTES or layout['native_rows']!=ROWS: refuse('unsupported native-row layout')
    base=layout['native_input_offset']
    if base+ROWS*ROW_BYTES>len(data): refuse('native rows exceed workspace')
    hz=u32(data,layout['native_hz_offset']);phase=u16(data,layout['phase_offset'])
    channels=(u16(data,layout['channels_offset']),u16(data,layout['channels_offset']+2))
    probe,lane,count=data[layout['probe_offset']],data[layout['lane_offset']],data[layout['count_offset']]
    valid=(data[layout['phase_valid_offset']],data[layout['origin_valid_offset']])
    epoch=u32(data,layout['source_epoch_offset'])
    if (hz,probe,lane,count,valid)!=(20000,2,0,count,(1,1)) or count not in (1,2) or not epoch:
        refuse('workspace is not an active P2/lane0/count1-or2/20k/phase+origin-valid source')
    wanted=(0,) if count==1 else (0,1)
    if phase>=1600 or channels[:count]!=wanted or any(channels[i] for i in range(count,2)):
        refuse('workspace does not declare the exact requested ADC0[/1] source')
    rows=[]
    for n in range(ROWS):
        tick,a,b=struct.unpack_from('<QHH',data,base+n*ROW_BYTES)
        if tick%1600: refuse('native frame_tick is not a superframe boundary')
        if a>4095 or (count==2 and b>4095): refuse('native raw word is outside 12-bit ADC range')
        rows.append((n,tick,(a,) if count==1 else (a,b)))
    if len({r[1] for r in rows})!=ROWS: refuse('retained native rows are duplicate/ambiguous')
    return phase,epoch,count,sorted(rows,key=lambda r:r[1])

def first_row(meta,epoch):
    a=meta.get('anchor',{})
    if a.get('generation')!=epoch or a.get('exported_source_origin')!=0 or a.get('source_hz')!=32000000:
        refuse('metadata anchor does not bind this native source epoch/origin')
    for r in meta.get('rows',[]):
        if r.get('probe')==2 and r.get('band')=='ap':
            if (r.get('rate_numerator'),r.get('rate_denominator'),r.get('source_hz'))!=(20000,1,32000000): refuse('P2 DAT metadata is not 20 kHz/32 MHz')
            if not isinstance(r.get('decoder_first_row_source_tick'),int): refuse('P2 first-row source tick unavailable')
            return r['decoder_first_row_source_tick']
    refuse('P2 AP row metadata absent')

def validate(workspace,layout_path,dat,metadata_path,output):
    layout=json.load(open(layout_path,encoding='utf-8'));meta=json.load(open(metadata_path,encoding='utf-8'))
    dirs=(os.path.dirname(os.path.abspath(dat)),os.path.dirname(os.path.dirname(os.path.abspath(dat))))
    if any(os.path.exists(os.path.join(d,'adc_calibration.json')) for d in dirs): refuse('factory-calibrated DAT is not comparable without exact correction')
    phase,epoch,count,rows=parse_workspace(workspace,layout);first=first_row(meta,epoch)
    if first!=(1600-phase)%1600: refuse('P2 DAT first row differs from declared native phase')
    size=os.path.getsize(dat)
    if size%DAT_ROW_BYTES: refuse('P2 DAT is not complete 384-channel int16 rows')
    evidence=[];excluded=[]
    with open(dat,'rb',buffering=0) as f:
        for slot,tick,raw in rows:
            row_tick=tick+first; row=(row_tick-first)//1600
            if row<0 or row>=size//DAT_ROW_BYTES:
                # The 64-row observer can retain a source frame whose canonical
                # decoder row was not completed before Stop.  It is evidence of
                # a boundary only, never compared or silently discarded.
                if row!=size//DAT_ROW_BYTES or excluded:
                    refuse('native row is not the single declared one-past completed-DAT boundary')
                excluded.append({'workspace_slot':slot,'frame_tick':tick,'dat_row':row,'reason':'one_past_completed_dat_boundary'})
                continue
            f.seek(row*DAT_ROW_BYTES);actual=struct.unpack('<'+'h'*count,f.read(count*2)); expected=tuple(2048-x for x in raw)
            if actual!=expected: refuse('P2 DAT mismatch at source tick %d / row %d'%(tick,row))
            evidence.append({'workspace_slot':slot,'frame_tick':tick,'dat_row':row,'raw12':list(raw),'dat_signed':list(actual)})
    if len(evidence)<32: refuse('fewer than 32 unambiguous retained rows map to completed P2 DAT')
    compact=json.dumps(evidence,sort_keys=True,separators=(',',':')).encode()
    result={'schema':1,'result':'PASS','scope':'retained configured P2 lane-0 raw ADC equality only; no gain/sensitivity/event/training claim','count':count,'channels':([0] if count==1 else [0,1]),'phase':phase,'source_epoch':epoch,'first_row_source_tick':first,'native_rows_retained':ROWS,'native_rows_checked':len(evidence),'native_rows_excluded_outside_completed_dat':excluded,'dat_rows':size//DAT_ROW_BYTES,'dat_bytes':size,'workspace_sha256':digest(workspace),'selected_reference_sha256':hashlib.sha256(compact).hexdigest().upper(),'samples':evidence}
    with open(output,'x',encoding='utf-8',newline='\n') as f: json.dump(result,f,indent=2,sort_keys=True);f.write('\n')

def fixture(count,boundary=False):
    with tempfile.TemporaryDirectory() as d:
        l={'workspace_bytes':3640,'native_row_bytes':16,'native_rows':64,'native_input_offset':24,'native_hz_offset':0,'phase_offset':4,'channels_offset':6,'probe_offset':10,'lane_offset':11,'count_offset':12,'phase_valid_offset':13,'origin_valid_offset':14,'source_epoch_offset':16}
        w=bytearray(3640);struct.pack_into('<IHH',w,0,20000,100,0);struct.pack_into('<H',w,8,1 if count==2 else 0);w[10:15]=bytes((2,0,count,1,1));struct.pack_into('<I',w,16,7)
        for i in range(ROWS):struct.pack_into('<QHH',w,24+i*16,i*1600,1000+i,2000+i)
        wp,lp,dp,mp,op=[os.path.join(d,x) for x in ('w','l','p2','m','o')];open(wp,'wb').write(w);json.dump(l,open(lp,'w'))
        dat_rows=ROWS-1 if boundary else ROWS;dat=bytearray(dat_rows*DAT_ROW_BYTES)
        for i in range(dat_rows):struct.pack_into('<'+'h'*count,dat,i*DAT_ROW_BYTES,*([1048-i]+([48-i] if count==2 else [])))
        open(dp,'wb').write(dat);json.dump({'anchor':{'generation':7,'exported_source_origin':0,'source_hz':32000000},'rows':[{'probe':2,'band':'ap','rate_numerator':20000,'rate_denominator':1,'source_hz':32000000,'decoder_first_row_source_tick':1500}]},open(mp,'w'));validate(wp,lp,dp,mp,op)
        if boundary:
            r=json.load(open(op));assert r['native_rows_checked']==63 and r['native_rows_excluded_outside_completed_dat']==[{'workspace_slot':63,'frame_tick':100800,'dat_row':63,'reason':'one_past_completed_dat_boundary'}]

def main():
    p=argparse.ArgumentParser();p.add_argument('--workspace');p.add_argument('--layout');p.add_argument('--p2-dat');p.add_argument('--metadata');p.add_argument('--output');p.add_argument('--self-test',action='store_true');a=p.parse_args()
    if a.self_test: fixture(1);fixture(2);fixture(1,True);fixture(2,True);print('PASS selected-native count1/count2 and completed-DAT-boundary self-test');return
    if not all((a.workspace,a.layout,a.p2_dat,a.metadata,a.output)):p.error('--workspace --layout --p2-dat --metadata --output required')
    validate(a.workspace,a.layout,a.p2_dat,a.metadata,a.output)
if __name__=='__main__':
    try:main()
    except (OSError,ValueError,struct.error,json.JSONDecodeError) as e:print('REFUSED: '+str(e),file=sys.stderr);sys.exit(2)
