from pathlib import Path
import hashlib,json
OUT=Path(__file__).resolve().parent
p=Path('D:/Code/XE_NP_V2/Core/Src/xe_np_np2_capture_port.c');before=p.read_bytes()
expected_current='3B4BFBE55529017ABEF6A7AED7240B8B88879176C6CFDBA6495E455AC54F357E'
expected_pre='3BCABD150A8527909A2869992ACE24B074E2DB9F69BBE2600153E52E882E0223'
sha=lambda b:hashlib.sha256(b).hexdigest().upper()
assert sha(before)==expected_current
lines=before.decode().splitlines(True);out=[];removed=[];depth=0
for i,line in enumerate(lines):
 if not depth and line.strip() in ('#if XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE','#if XE_NP_IMAGE_ROLE==1U && XE_NP_NP2_CLOSED_LOOP_SPI_ENABLE'):
  depth=1;removed.append(dict(start_line=i+1,condition=line.strip(),lines=[line]));continue
 if depth:
  removed[-1]['lines'].append(line)
  if line.lstrip().startswith(('#if ','#ifdef ','#ifndef ')):depth+=1
  elif line.lstrip().startswith('#endif'):depth-=1
  continue
 out.append(line)
assert not depth
blob=''.join(out).encode();assert sha(blob)==expected_pre
q=OUT/'reconstructed-FFC27E5A-usb-capture-port.c';q.write_bytes(blob)
r=dict(status='EXACT_EXPECTED_PREIMAGE_RECOVERED_BY_REVERSAL',source=str(p),source_sha256=expected_current,
 reconstructed_path=str(q),reconstructed_sha256=expected_pre,bytes=len(blob),removed_conditional_blocks=removed,
 reference='D:/Code/XE_NP_V2/_artifacts/v2_grid_source_20261029/usb-grid-rtc-first-r2/result.json',
 custody='Recovered exact bytes by removing10 explicitly CL-conditional source additions from saved current3B4BF source. Full recovered SHA matches recorded USB preimage3BCABD. Not an originally preserved file; no firmware build/equivalence claim.',hardware_access=False,canonical_edits=False)
(OUT/'usb-capture-preimage-recovery.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(dict(status=r['status'],bytes=len(blob),sha256=sha(blob),path=str(q),receipt_sha256=sha((OUT/'usb-capture-preimage-recovery.json').read_bytes())),indent=2))
