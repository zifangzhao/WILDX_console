from pathlib import Path
import hashlib,json
T=Path(__file__).resolve().parent;P=Path('C:/Frank/Code/XE_NP/_artifacts/v2_spi_selected_detectors_20261104');U=Path('C:/Frank/Code/XE_NP/_artifacts/closed_loop_qualification_20261104/V2');R=Path('D:/Code/XE_NP_V2')
S=T/'Core/Src';I=T/'Core/Inc';S.mkdir(parents=True,exist_ok=True);I.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();pins={}
def copy(p,d,expected=None):
 if expected:assert sha(p)==expected,(p,sha(p),expected)
 d.write_bytes(p.read_bytes());pins[str(p)]=sha(p)
for n in ['xe_np_np2_cl_selected.c','xe_np_np2_closed_loop_spi.c','xe_np_np2_closed_loop_carrier.c']:copy(P/'Core/Src'/n,S/n)
copy(P/'Core/Inc/xe_np_np2_cl_selected.h',I/'xe_np_np2_cl_selected.h')
copy(T/'audit/reconstructed-FFC27E5A-usb-capture-port.c',S/'xe_np_np2_capture_port.c','3BCABD150A8527909A2869992ACE24B074E2DB9F69BBE2600153E52E882E0223')
copy(R/'Core/Src/stm32u5xx_it.c',S/'stm32u5xx_it.c','CC9F035763EEC6D1A6C343BEE9A05913EF73F18363559A29BE682147A6B2D2A7')
for n in ['xe_np_usb_stream.c','xe_np_np2_usb_stream.inc','xe_np_usb_unified.inc']:copy(U/'Core/Src'/n,S/n)
for n in ['xe_np_np2_usb_wire.h','xe_np_usb_unified.h']:copy(U/'Core/Inc'/n,I/n)
# Freeze the actual stream include used by current checked USB. No edits here.
copy(R/'Core/Src/xe_np_usb_aux.inc',S/'xe_np_usb_aux.inc')
(T/'source-preimages.json').write_text(json.dumps(pins,indent=2)+'\n')
# Passive receiver lifecycle only; retain the exact USB capture implementation.
p=S/'xe_np_np2_capture_port.c';s=p.read_text();s='#include "xe_np_np2_cl_selected.h"\n'+s
at='''        spi2_d8_stop();''';assert s.count(at)==1;s=s.replace(at,'        XE_NP_Np2ClSelected_Stop();\n'+at)
at='''    int result=XE_NP_Np2D8Calibration_Find(pssi,spi2_d8_ring,''';assert s.count(at)==1;s=s.replace(at,'    (void)XE_NP_Np2ClSelected_Calibrate(pssi,ticks);\n'+at)
at='''    acquisition_anchor.counter_hz=XE_NP_Board_GetRuntimeCoreClockHz();''';assert s.count(at)==1;s=s.replace(at,'    (void)XE_NP_Np2ClSelected_Prepare();\n'+at)
at='''    XE_NP_CycleClock_Anchor(&cycle_clock,acquisition_anchor.generation,''';assert s.count(at)==1;s=s.replace(at,'    XE_NP_Np2ClSelected_Enable();\n'+at);p.write_text(s)
# One ISR remains owned by the existing USB camera TU. Select its leaf cold.
p=I/'xe_np_np2_cl_selected.h';s=p.read_text().replace('#endif','void XE_NP_Np2ClSelected_DmaDispatch(void);\n#endif');p.write_text(s)
p=S/'xe_np_np2_cl_selected.c';s=p.read_text();at='static uint32_t enable_fine,fine_domain,fine_generation,fine_epoch,irq_last_fine,offer_last_fine;';assert s.count(at)==1
s=s.replace(at,at+'''\nextern void XE_NP_MediaCamera_DmaIrq(void);
static void selected_dma_irq(void);
static void (*dma_irq_owner)(void)=XE_NP_MediaCamera_DmaIrq;
void XE_NP_Np2ClSelected_DmaDispatch(void){dma_irq_owner();}
''')
s=s.replace('void GPDMA1_Channel15_IRQHandler(void)','static void selected_dma_irq(void)')
at='''    if(!owner_quiet()){fault(1U);return -1;}''';assert s.count(at)==1;s=s.replace(at,at+'''\n    /* IRQ and both physical owners are quiet. Claim before fallible setup so
     * even a partially prepared private receiver can be retired at Stop. */
    dma_irq_owner=selected_dma_irq;enabled=1U;''')
s=s.replace('if(HAL_DMAEx_List_Init(&rx)!=HAL_OK){fault(2U);return -1;}','if(HAL_DMAEx_List_Init(&rx)!=HAL_OK){fault(2U);goto bad;}')
s=s.replace('bad:fault(3U);return -1;','bad:if(!xe_np_np2_cl_selected_diag[2])fault(3U);XE_NP_Np2ClSelected_Stop();return -1;')
s=s.replace('else enabled=0U;','else{enabled=0U;dma_irq_owner=XE_NP_MediaCamera_DmaIrq;}');p.write_text(s)
p=S/'stm32u5xx_it.c';s=p.read_text();s='#include "xe_np_np2_cl_selected.h"\n'+s;at='void GPDMA1_Channel15_IRQHandler(void) { XE_NP_MediaCamera_DmaIrq(); }';assert s.count(at)==1;s=s.replace(at,'void GPDMA1_Channel15_IRQHandler(void) { XE_NP_Np2ClSelected_DmaDispatch(); }');p.write_text(s)
# USB source/profile constraints. SD APP99 is neither rebuilt nor altered.
p=S/'xe_np_np2_closed_loop_carrier.c';s=p.read_text();at='''    unsigned probe=q->selector[0]&255U;''';assert s.count(at)==1;s=s.replace(at,at+'''\n    if(q->ap_hz!=20000U)return 0;
    for(unsigned i=0U;i<q->count;i++)if(((q->selector[i]>>8U)&255U)!=6U)return 0;''')
s=s.replace('if(probe==3U)return q->count==1U && (q->selector[0]>>16U)>=256U;','if(probe==3U)return 0;')
s=s.replace('r.max_lanes=2U;r.probe_mask=6U;r.filter_mask=1023U;r.channel_groups=264U;','r.max_lanes=2U;r.probe_mask=2U;r.filter_mask=64U;r.channel_groups=8U;')
at='''proof.session=port->carrier.session?port->carrier.session:current->source_epoch;''';assert s.count(at)==1;s=s.replace(at,'''proof.session=port->carrier.session?port->carrier.session:current->session;
    if(!proof.session){port->failure=NP_CL_CONTROL_SOURCE;return -1;}''')
s=s.replace('r->timing_generation!=r->source_epoch','!r->timing_generation')
at='''    p.native_hz=r->native_hz;p.record_mask=r->record_mask;p.source_epoch=r->source_epoch;''';assert s.count(at)==1;s=s.replace(at,'    p.session=port->carrier.session?port->carrier.session:r->timing_generation;\n'+at);p.write_text(s)
# Existing accepted CopyD8 frontier feeds the same source/filter pipeline.
p=S/'xe_np_np2_usb_stream.inc';s=p.read_text();s='#include "xe_np_np2_cl_selected.h"\n'+s
at='''xe_np_usb_selftest_busy(),np2_usb.probe_mask,np2_usb.sample_hz,!XE_NP_NP2_CAPTURE_16BIT_PSSI);''';assert s.count(at)==1;s=s.replace(at,'''xe_np_usb_selftest_busy(),np2_usb.probe_mask,np2_usb.sample_hz,
        !XE_NP_NP2_CAPTURE_16BIT_PSSI && !(xe_np_aux.flags&XE_NP_USB_AUX_CAMERA));''')
at='''!XE_NP_NP2_CAPTURE_16BIT_PSSI && cl_token!=0U);''';assert s.count(at)==1;s=s.replace(at,'''!XE_NP_NP2_CAPTURE_16BIT_PSSI && cl_token!=0U && !(xe_np_aux.flags&XE_NP_USB_AUX_CAMERA));''')
# Retire private C15 before the existing timing owner invalidates its clock.
s=s.replace('    np2_usb_first_stop();','    XE_NP_Np2ClSelected_Stop();\n    np2_usb_first_stop();')
p.write_text(s)
(T/'source-overlay.json').write_text(json.dumps(dict(parent_app='99CC44F9 unchanged',parent_usb='FFC27E5A',source_hashes={str(p):sha(p) for p in list(S.glob('*'))+list(I.glob('*'))},scope='USB-only P2 selected-reader lifecycle/IRQ owner routing, cold profile constraints and separate root-session/source-epoch binding; no new data-processing path'),indent=2)+'\n');print('USB source overlays staged')
