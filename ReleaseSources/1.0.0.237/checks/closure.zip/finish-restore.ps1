$ErrorActionPreference='Stop'
$taskRoot=$PSScriptRoot
$taskLease=Get-Content -LiteralPath (Join-Path $taskRoot 'owner/lease.json') -Raw|ConvertFrom-Json
if($taskLease.status -ne 'active' -or $taskLease.uid -ne '001A0004434250062039314E'){throw 'Exact live lease required'}
$taskOriginal=Get-Content -LiteralPath (Join-Path $taskRoot 'original/receipt.json') -Raw|ConvertFrom-Json
$taskRestored=Get-Content -LiteralPath (Join-Path $taskRoot 'deployment/Restore-verified.json') -Raw|ConvertFrom-Json
if($taskRestored.whole_flash_sha256 -ne $taskOriginal.full_sha256 -or $taskRestored.options_sha256 -ne $taskOriginal.options_sha256){throw 'Exact restoration identity proof required'}
$taskA=[Reflection.Assembly]::LoadFrom((Join-Path $taskRoot 'runtime/WILDX_console.exe'))
$taskF=[Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
$taskT=$taskA.GetType('USB512_interface.NpV2UsbDevice',$true)
$taskPath='\\?\usb#vid_1209&pid_b386#001a0004434250062039314e#{8f5a4a7b-0aa6-4f8e-a14f-a2f7b3c6aa4e}'
function V($taskObject,$taskName){$taskObject.GetType().GetField($taskName,$taskF).GetValue($taskObject)}
$taskDevice=$taskT.GetMethod('Open',$taskF).Invoke($null,@($taskPath))
try {
 $taskStatus=$taskT.GetMethod('GetServiceStatus',$taskF).Invoke($taskDevice,@())
 if((V $taskStatus 'Mode') -notin @(2,3) -or (V $taskStatus 'Busy') -ne 0 -or (V $taskStatus 'Target') -ne 0){throw 'Restored device not idle'}
 $taskMode=V $taskStatus 'Mode'
} finally {$taskDevice.Dispose()}
$taskPreferences=Join-Path $env:LOCALAPPDATA 'WILDX_console/closed_loop_v2.json'
if($taskOriginal.preferences.existed){throw 'This task only backed up absent preferences'}
if(Test-Path -LiteralPath $taskPreferences){
 $taskText=[IO.File]::ReadAllText($taskPreferences)
 $taskExpected='{"Enabled":true,"MayBeConfigured":true,"TrainingStartMs":0,"TrainingDurationMs":1000,"Channels":[{"Probe":2,"Filter":6,"Channel":0,"Gain":2,"Rectify":true},{"Probe":2,"Filter":6,"Channel":1,"Gain":2,"Rectify":true}]}'
 if($taskText -ne $taskExpected){throw 'Preferences changed outside exact generated test settings; no deletion'}
 $taskHash=(Get-FileHash -LiteralPath $taskPreferences -Algorithm SHA256).Hash
 Copy-Item -LiteralPath $taskPreferences -Destination (Join-Path $taskRoot 'original/generated-preferences-final.json')
 if((Get-FileHash -LiteralPath $taskPreferences -Algorithm SHA256).Hash -ne $taskHash){throw 'Preferences changed before restore'}
 Remove-Item -LiteralPath $taskPreferences
}
if(Test-Path -LiteralPath $taskPreferences){throw 'Original absent preference not restored'}
$taskReceipt=[ordered]@{status='EXACT_ORIGINAL_FLASH_OPTIONS_AND_PREFERENCES_RESTORED_IDLE';uid=$taskLease.uid;app_crc32='7F238587';usb_crc32='74FC7104';flash_sha256=$taskOriginal.full_sha256;options_sha256=$taskOriginal.options_sha256;mode=$taskMode;busy=0;target=0;preference_absent=$true;card_writes_in_this_task=$false;card_format_or_delete=$false;utc=[DateTime]::UtcNow.ToString('o')}
$taskReceipt|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $taskRoot 'restoration-complete.json') -Encoding utf8
[IO.File]::WriteAllText((Join-Path $taskRoot 'owner/release.flag'),'Exact originals verified and idle')
$taskReceipt|ConvertTo-Json -Compress
