from pathlib import Path
import json,hashlib,datetime,struct
T=Path(__file__).resolve().parent.resolve();O=T/'compact';O.mkdir(exist_ok=True)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest().upper()
assert load(T/'accepted.json')['status']=='ACCEPTED' and load(T/'owner/lease.json')['status']=='closed'
runs=['usb-cl0','usb-cl1','usb-cl2','usb-cl2-restart'];entries=[];oracles=[]
for name in runs:
 r=T/name;q=load(r/'quality.json');assert q['status']=='PASS'
 for probe in (1,2,3):
  p=(r/f'probe{probe}/neuropixels_ap.dat').resolve();assert p.is_relative_to(T)
  size=p.stat().st_size;assert size>0 and size%768==0
  rows=size//768;dest=O/name/f'probe{probe}';dest.mkdir(parents=True,exist_ok=True);fragments=[]
  with p.open('rb') as f:
   for label,first,count in [('head',0,min(128,rows)),('tail',max(0,rows-128),min(128,rows))]:
    f.seek(first*768);b=f.read(count*768);assert len(b)==count*768
    target=dest/('neuropixels_ap.dat.'+label);target.write_bytes(b);assert sha(target.read_bytes())==sha(b)
    fragments.append(dict(file=str(target.relative_to(T)),first_dat_row=first,rows=count,bytes=len(b),sha256=sha(b)))
   if probe==2 and name!='usb-cl0':
    proof=load(r/'selected-native-proof.json');assert proof['result']=='PASS'
    oracle=bytearray()
    for sample in proof['samples']:
     f.seek(sample['dat_row']*768);row=f.read(768);assert len(row)==768
     actual=struct.unpack_from('<'+'h'*proof['count'],row)
     assert list(actual)==sample['dat_signed'] and list(actual)==[2048-x for x in sample['raw12']]
     oracle.extend(row)
    op=dest/'selected-native-complete-rows.dat';op.write_bytes(oracle)
    oracles.append(dict(run=name,file=str(op.relative_to(T)),rows=[s['dat_row'] for s in proof['samples']],row_bytes=768,sha256=sha(oracle),source_proof=str((r/'selected-native-proof.json').relative_to(T))))
  entries.append(dict(original=str(p.relative_to(T)),bytes=size,row_bytes=768,rows=rows,full_sha256=None,full_hash_scope='Not computed; every input block sequence/ticks/SuperSync was verified by the retained production worker report.',fragments=fragments))
  ts=p.with_name(p.name+'.timestamps.calibrated.dat')
  if ts.exists():
   ts_size=ts.stat().st_size;assert ts_size==rows*8,(ts,ts_size,rows)
   ts_fragments=[]
   with ts.open('rb') as f:
    for label,first,count in [('head',0,min(128,rows)),('tail',max(0,rows-128),min(128,rows))]:
     f.seek(first*8);b=f.read(count*8);target=dest/('timestamps.calibrated.dat.'+label);target.write_bytes(b);assert sha(target.read_bytes())==sha(b)
     ts_fragments.append(dict(file=str(target.relative_to(T)),first_dat_row=first,rows=count,bytes=len(b),sha256=sha(b)))
   entries.append(dict(original=str(ts.relative_to(T)),bytes=ts_size,row_bytes=8,rows=rows,full_sha256=None,fragments=ts_fragments))
manifest=dict(status='BOUNDED_FIXTURES_SECURED_BEFORE_PAYLOAD_REMOVAL',files=entries,selected_oracles=oracles,scope='Only owned generated per-probe USB neural DAT and calibrated timestamp arrays; head/tail128 rows and complete64-row selected-source oracles retained. Metadata, raw native workspace/bootstrap, primary IMU/sensor observations and firmware backups preserved. No user or on-device recording changed.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for e in entries:
 p=(T/e['original']).resolve();assert p.is_relative_to(T) and p.stat().st_size==e['bytes'];p.unlink()
assert all(not (T/e['original']).exists() for e in entries)
rest=load(T/'original/receipt.json')
assert sha((T/'original/full.bin').read_bytes())==rest['full_sha256'] and sha((T/'original/options.bin').read_bytes())==rest['options_sha256']
out=dict(status='COMPLETE',removed_generated_payload_bytes=sum(e['bytes'] for e in entries),retained_neural_fragment_bytes=sum(f['bytes'] for e in entries for f in e['fragments'])+sum((T/o['file']).stat().st_size for o in oracles),files_removed=len(entries),fixture_manifest=str(O/'manifest.json'),fixture_manifest_sha256=sha((O/'manifest.json').read_bytes()),original_restore_backups_preserved=True,scope=manifest['scope'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(T/'cleanup-complete.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
