#include <assert.h>
#include <stdint.h>
#include "np_sd_usb_job_reset.h"

static void fence(void) { }
int main(void)
{
    volatile uint32_t words[5] = {0U,0x55667788U,0x11223344U,0x12345678U,0xEDCBA987U};
    const uint64_t ticket = UINT64_C(0x1122334455667788);
    assert(!np_v1_job_reset_seal(words, 0U, fence));
    assert(np_v1_job_reset_seal(words, ticket, fence));
    assert(words[1]==(uint32_t)ticket && words[2]==(uint32_t)(ticket>>32U));
    assert(words[3]==0x12345678U && words[4]==0xEDCBA987U);
    assert(np_v1_job_reset_consume(words, ticket, 1U, 1U, 0xFEU, fence));
    assert(words[3]==0x12345678U && words[4]==0xEDCBA987U);
    assert(!np_v1_job_reset_consume(words, ticket, 1U, 1U, 0xFEU, fence));
    assert(np_v1_job_reset_seal(words, ticket, fence));
    assert(!np_v1_job_reset_consume(words, ticket + 1U, 1U, 1U, 0xFEU, fence));
    assert(np_v1_job_reset_seal(words, ticket, fence));
    assert(!np_v1_job_reset_consume(words, ticket, 3U, 1U, 0xFEU, fence));
    assert(np_v1_job_reset_seal(words, ticket, fence));
    words[1] ^= 1U;
    assert(!np_v1_job_reset_consume(words, ticket, 1U, 1U, 0xFEU, fence));
    assert(!np_v1_job_reset_seal(words, ticket, fence));
    assert(!words[0] && words[1]==0x55667789U && words[2]==0x11223344U &&
           words[3]==0x12345678U && words[4]==0xEDCBA987U);
    words[1] ^= 1U;
    assert(np_v1_job_reset_seal(words, ticket, fence));
    assert(!np_v1_job_reset_consume(words, ticket, 0U, 1U, 0xFEU, fence));
    return 0;
}
