#include <assert.h>
#include <stdint.h>
#include <string.h>
#include "np_sd_usb_job_plan.h"
#include "np_sd_usb_job_reconcile.h"
#if defined(_MSC_VER)
#define __attribute__(x)
#endif

typedef struct { uint32_t AHB3ENR, APB3ENR, AHB1ENR, CSR; } MockRcc;
typedef struct { uint32_t DBPR; } MockPwr;
typedef struct { uint32_t OPTR; } MockFlash;
typedef struct { volatile uint32_t BKP9R, BKP10R, BKP11R, BKP12R, BKP13R, BKP14R, BKP15R;
    uint32_t BKP16R, BKP17R, spare[2], BKP20R, BKP21R, BKP22R, BKP23R;
    uint32_t BKP24R, BKP25R, BKP26R, BKP27R, spare2[2], BKP30R, BKP31R; } MockTamp;
static MockRcc rcc; static MockPwr pwr; static MockFlash flash; static MockTamp tamp;
static volatile uint32_t ram[128]; static uintptr_t ram_base;
volatile uint32_t xe_np_hw_startup_rcc_csr;
static uint8_t np_v1_job_plan[128];
static int busy, no_card, bad_catalog, fs2, reset_called, irq_disabled;
static uint8_t fs2_id[512], fs2_check[512];
#define RCC (&rcc)
#define PWR (&pwr)
#define FLASH (&flash)
#define TAMP (&tamp)
#define BKPSRAM_BASE (ram_base)
#define RCC_AHB3ENR_PWREN 1U
#define RCC_APB3ENR_RTCAPBEN 1U
#define RCC_AHB1ENR_BKPSRAMEN 1U
#define PWR_DBPR_DBP 1U
#define FLASH_OPTR_TZEN 1U
#define RCC_CSR_SFTRSTF (1U << 0)
#define RCC_CSR_OBLRSTF (1U << 1)
#define RCC_CSR_PINRSTF (1U << 2)
#define RCC_CSR_BORRSTF (1U << 3)
#define RCC_CSR_IWDGRSTF (1U << 4)
#define RCC_CSR_WWDGRSTF (1U << 5)
#define RCC_CSR_LPWRRSTF (1U << 6)
#define RCC_CSR_RMVF (1U << 7)
#define NP_USB_SD_JOB_REGION_VERIFIED 1U
#define NP_USB_SD_JOB_APP_CRC 123U
#define __DSB() ((void)0)
static uint32_t HAL_GetUIDw0(void) { return 1U; }
static uint32_t HAL_GetUIDw1(void) { return 2U; }
static uint32_t HAL_GetUIDw2(void) { return 3U; }
static uint32_t __get_PRIMASK(void) { return (uint32_t)irq_disabled; }
static void __disable_irq(void) { irq_disabled = 1; }
static void __set_PRIMASK(uint32_t value) { irq_disabled = (int)value; }
static void NVIC_SystemReset(void) { ++reset_called; }
static void XE_NP_Boot_RequestApplication(void) { tamp.BKP30R = 77U; tamp.BKP31R = ~77U; }
typedef struct { uint32_t image_crc32; } XE_NP_BootManifest;
static XE_NP_BootManifest fixture_manifest = {123U};
#define XE_NP_BOOT_MANIFEST_BASE ((uintptr_t)&fixture_manifest)
#define XE_NP_BOOT_IMAGE_ID_APPLICATION 1U
static int XE_NP_Boot_ManifestIsValidForImage(const XE_NP_BootManifest *m, uint32_t id, int crc)
{ return m == &fixture_manifest && id == 1U && crc == 1; }
static int NP_USB_IsDownload(void) { return 1; }
static int NP_V1UsbJob_Owns(void) { return 0; }
static int np_usb_format_busy(void *p) { (void)p; return busy; }
typedef struct { uint32_t capacity, uid[3], cid[4]; } NpUsbSdFormatIdentity;
static int np_usb_format_identify(void *p, NpUsbSdFormatIdentity *id)
{ (void)p; if (no_card) return -1; id->capacity = 500695040U; for (unsigned i=0;i<4U;++i) id->cid[i]=i+4U; return 0; }
static int np_usb_format_read(void *p, uint32_t lba, uint8_t *b)
{
    (void)p; memset(b,0,512U);
    if (fs2 && (lba == 16U || lba == 24U)) memcpy(b,fs2_id,512U);
    else if (fs2 && (lba == 112U || lba == 113U)) memcpy(b,fs2_check,512U);
    else if (!fs2 && lba == 16U) { memcpy(b,"CE_FILESYSTEM_V1",16U); memcpy(b+32U,"NP_CE64_1",9U); }
    return 0;
}
#define NP_CE64_H
typedef struct { uint32_t start; } NpCe64Directory;
static int np_ce64_journal(int (*read)(uint32_t,uint8_t *),uint32_t *target,uint8_t *shadow)
{ (void)read; (void)shadow; *target=0U; return bad_catalog ? -1 : 0; }
static int np_ce64_mount(NpCe64Directory *d, uint32_t capacity, int (*read)(uint32_t,uint8_t *),
                         int (*write)(uint32_t,const uint8_t *))
{ (void)capacity; (void)read; (void)write; d->start=8192U; return 0; }
#include "../../../Firmware/V1/Core/Src/np_usb_sd_job_platform.inc"

static void terminal_reset_test(uint32_t flags, int seal, uint32_t phase, int expected)
{
    uint8_t plan_wire[128], report_wire[256];
    NpUsbSdTestPlan plan = {0}; NpUsbSdTestReport report;
    memset(&tamp, 0, sizeof(tamp)); memset((void *)ram, 0, sizeof(ram));
    np_v1_job_platform_ready = 0U; xe_np_hw_startup_rcc_csr = flags;
    plan.ticket = 42U; plan.seconds = 10U;
    assert(np_usb_sd_plan_encode(plan_wire, sizeof(plan_wire), &plan));
    np_usb_sd_report_init(&report); report.words[4] = phase; report.words[8] = 42U;
    report.words[9] = 0U; report.words[10] = np_usb_sd_u32(plan_wire + 60U); report.words[12] = 1U;
    report.words[17] = report.words[18] = report.words[19] = 0U;
    report.words[6] = NP_USB_SD_VALID_TERMINAL;
    assert(np_usb_sd_report_encode(report_wire, sizeof(report_wire), &report));
    assert(np_v1_job_storage_initialize(&tamp.BKP9R, ram, np_v1_job_platform_barrier));
    assert(np_v1_job_journal_write(ram, plan_wire, report_wire, np_v1_job_platform_barrier));
    if (seal) { tamp.BKP12R=42U;tamp.BKP13R=0U;
        assert(np_v1_job_reset_seal(&tamp.BKP11R, 42U, np_v1_job_platform_barrier)); }
    NP_V1UsbJob_PlatformInit();
    assert(NP_V1UsbJob_PlatformReady() && !tamp.BKP11R);
    assert((int)np_v1_job_storage_ready(&tamp.BKP9R, 1) == expected);
}

int main(void)
{
    NpV1UsbSdJobIdentity card = {0}; NpUsbSdTestReport live; uint32_t proof = 0;
    uint8_t plan[128] = {0}, report[256] = {0};
    ram_base = (uintptr_t)ram;
    xe_np_hw_startup_rcc_csr = RCC_CSR_BORRSTF;
    tamp.BKP9R = NP_V1_JOB_STORAGE_MAGIC; tamp.BKP10R = ~NP_V1_JOB_STORAGE_MAGIC;
    NP_V1UsbJob_PlatformInit();
    assert(NP_V1UsbJob_PlatformReady() && tamp.BKP9R == 0U);
    assert(NP_V1UsbJob_PlatformRead(plan, report) == 0);
    np_usb_sd_report_init(&live);
    assert(NP_V1UsbJob_PlatformObserve(&card, &live, &proof));
    assert(card.capacity == 500695040U && card.frontier == 8192U && card.writable);
    assert((proof & NP_JOB_FRESH_PROOF) == NP_JOB_FRESH_PROOF);
    assert((live.words[6] & NP_USB_SD_VALID_CATALOG) && live.words[26] == 0U);
    bad_catalog = 1; memset(&card,0,sizeof(card)); np_usb_sd_report_init(&live);
    assert(NP_V1UsbJob_PlatformObserve(&card,&live,&proof));
    assert(!(live.words[6] & NP_USB_SD_VALID_CATALOG) && !card.writable);
    bad_catalog = 0; fs2 = 1;
    Nps2State store = {0}; store.capacity = 500695040U; store.epoch = 9U;
    store.generation = 1U; store.frontier = 8192U;
    nps2_identity(fs2_id, store.capacity, store.epoch); nps2_checkpoint(fs2_check, &store);
    memset(&card,0,sizeof(card)); np_usb_sd_report_init(&live);
    assert(NP_V1UsbJob_PlatformObserve(&card,&live,&proof));
    assert(card.frontier == 8192U && card.writable && (live.words[6] & NP_USB_SD_VALID_CATALOG));
    fs2_check[508] ^= 1U; memset(&card,0,sizeof(card)); np_usb_sd_report_init(&live);
    assert(NP_V1UsbJob_PlatformObserve(&card,&live,&proof));
    assert(!card.writable && !(live.words[6] & NP_USB_SD_VALID_CATALOG));
    assert(!NP_V1UsbJob_PlatformWrite(plan,report));
    NpUsbSdTestPlan submitted = {0}; uint8_t legacy[64] = {0};
    uint32_t uid[3] = {1U, 2U, 3U};
    submitted.ticket=42U; submitted.seconds=10U; memcpy(submitted.uid,uid,sizeof(uid));
    np_first_put32(legacy,UINT32_C(0x31444c4e)); np_first_put32(legacy+4U,1U);
    np_first_put32(legacy+8U,2U); np_first_put32(legacy+12U,1U);
    np_first_put32(legacy+16U,3U); np_first_put32(legacy+20U,20000U);
    np_first_put32(legacy+24U,8192U); np_first_put32(legacy+28U,100000U);
    np_first_put32(legacy+32U,1U); np_first_put32(legacy+36U,1U);
    np_first_put32(legacy+60U,np_first_crc(legacy,60U));
    assert(np_first_sd_fine_counter64_wrap(submitted.npsd,legacy,1U,uid,42U,0U));
    assert(np_usb_sd_plan_encode(np_v1_job_plan,sizeof(np_v1_job_plan),&submitted));
    np_usb_sd_report_init(&live); live.words[4]=NP_USB_SD_PHASE_ACCEPTED;
    live.words[8]=42U; live.words[9]=0U; live.words[10]=np_usb_sd_u32(np_v1_job_plan+60U);
    live.words[12]=1U; live.words[17]=1U; live.words[18]=2U; live.words[19]=3U;
    assert(np_usb_sd_report_encode(report,sizeof(report),&live));
    assert(np_v1_job_storage_initialize(&tamp.BKP9R,ram,np_v1_job_platform_barrier));
    assert(np_v1_job_journal_write(ram,np_v1_job_plan,report,np_v1_job_platform_barrier));
    tamp.BKP24R=7U;tamp.BKP25R=7500U;tamp.BKP26R=np_sd_rate_cookie(7U,7500U);tamp.BKP27R=~tamp.BKP26R;
    tamp.BKP20R=7U; tamp.BKP21R=7500U; tamp.BKP22R=np_sd_rate_cookie(7U,7500U);tamp.BKP23R=~tamp.BKP22R;
    assert(!NP_V1UsbJob_PlatformHandoff(42U));
    assert(reset_called == 1 && !irq_disabled && !tamp.BKP11R && !tamp.BKP30R && !tamp.BKP31R);
    assert(!tamp.BKP16R && tamp.BKP20R==7U && tamp.BKP21R==7500U &&
           np_sd_rate_cookie_valid(tamp.BKP20R,tamp.BKP21R,tamp.BKP22R,tamp.BKP23R));
    assert(tamp.BKP24R==7U && tamp.BKP25R==7500U &&
           np_sd_rate_cookie_valid(tamp.BKP24R,tamp.BKP25R,tamp.BKP26R,tamp.BKP27R));
    terminal_reset_test(RCC_CSR_SFTRSTF|RCC_CSR_PINRSTF, 1, NP_USB_SD_PHASE_FINISHED, 1);
    terminal_reset_test(RCC_CSR_PINRSTF, 1, NP_USB_SD_PHASE_FINISHED, 0);
    terminal_reset_test(RCC_CSR_SFTRSTF|RCC_CSR_PINRSTF|RCC_CSR_BORRSTF, 1, NP_USB_SD_PHASE_FINISHED, 0);
    terminal_reset_test(RCC_CSR_SFTRSTF|RCC_CSR_PINRSTF, 0, NP_USB_SD_PHASE_FINISHED, 0);
    terminal_reset_test(RCC_CSR_SFTRSTF|RCC_CSR_PINRSTF, 1, NP_USB_SD_PHASE_ACCEPTED, 0);
    /* A cold reset with a valid armed backup restores the prior profile
     * without dereferencing possibly uninitialized ECC RAM. */
    memset(&tamp,0,sizeof(tamp)); ram_base=0U; xe_np_hw_startup_rcc_csr=RCC_CSR_BORRSTF;
    tamp.BKP9R=NP_V1_JOB_STORAGE_MAGIC;tamp.BKP10R=~NP_V1_JOB_STORAGE_MAGIC;
    tamp.BKP20R=7U;tamp.BKP21R=7500U;tamp.BKP22R=np_sd_rate_cookie(7U,7500U);tamp.BKP23R=~tamp.BKP22R;
    assert(np_v1_job_profile_stage(&tamp.BKP16R,&tamp.BKP12R,&tamp.BKP20R,3U,20000U,42U,np_v1_job_platform_barrier));
    assert(np_v1_job_reset_seal(&tamp.BKP11R,42U,np_v1_job_platform_barrier));
    assert(NP_V1UsbJob_PlatformRecoverProfile());
    assert(!tamp.BKP11R && !tamp.BKP16R && tamp.BKP20R==7U && tamp.BKP21R==7500U);
    assert(np_sd_rate_cookie_valid(tamp.BKP20R,tamp.BKP21R,tamp.BKP22R,tamp.BKP23R));
    np_v1_job_platform_ready=0U;NP_V1UsbJob_PlatformInit();assert(!tamp.BKP9R);
    /* A torn backup must not silently use the temporary profile. */
    memset(&tamp,0,sizeof(tamp));
    tamp.BKP20R=7U;tamp.BKP21R=7500U;tamp.BKP22R=np_sd_rate_cookie(7U,7500U);tamp.BKP23R=~tamp.BKP22R;
    assert(np_v1_job_profile_stage(&tamp.BKP16R,&tamp.BKP12R,&tamp.BKP20R,3U,20000U,42U,np_v1_job_platform_barrier));
    tamp.BKP15R^=1U;
    assert(!NP_V1UsbJob_PlatformRecoverProfile());
    assert(tamp.BKP16R && !tamp.BKP11R && NP_V1UsbJob_ModeFence());
    return 0;
}
