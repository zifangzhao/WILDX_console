#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "np_sd_usb_job_storage.h"
#include "np_sd_usb_job_reset.h"
#include "np_sd_usb_job_profile.h"

static volatile uint32_t retained[NP_V1_JOB_JOURNAL_WORDS];
static uintptr_t retained_base;
static struct {volatile uint32_t BKP9R,BKP10R,BKP11R,BKP12R,BKP13R,BKP14R,BKP15R,
    BKP16R,BKP17R,BKP18R,BKP19R,BKP20R,BKP21R,BKP22R,BKP23R,
    BKP24R,BKP25R,BKP26R,BKP27R;} fake_tamp;
static struct {volatile uint32_t CSR,AHB1ENR,AHB3ENR,APB3ENR;} fake_rcc;
static struct {volatile uint32_t DBPR;} fake_pwr;
static struct {uint32_t state;} np_v1_usb_job_owner;
static uint32_t np_v1_usb_job_boot_owned, fake_uid[3]={1U,2U,3U};
static int fake_retention_proven;
#define TAMP (&fake_tamp)
#define RCC (&fake_rcc)
#define PWR (&fake_pwr)
#define BKPSRAM_BASE (retained_base)
#define NP_V1_USB_JOB_RETENTION_PROVEN fake_retention_proven
#define RCC_CSR_SFTRSTF 0x01U
#define RCC_CSR_PINRSTF 0x02U
#define RCC_CSR_OBLRSTF 0x04U
#define RCC_CSR_BORRSTF 0x08U
#define RCC_CSR_IWDGRSTF 0x10U
#define RCC_CSR_WWDGRSTF 0x20U
#define RCC_CSR_LPWRRSTF 0x40U
#define RCC_AHB3ENR_PWREN 0x01U
#define RCC_APB3ENR_RTCAPBEN 0x02U
#define RCC_AHB1ENR_BKPSRAMEN 0x04U
#define PWR_DBPR_DBP 0x08U
#define __DSB() ((void)0)
static uint32_t HAL_GetUIDw0(void){return fake_uid[0];}
static uint32_t HAL_GetUIDw1(void){return fake_uid[1];}
static uint32_t HAL_GetUIDw2(void){return fake_uid[2];}
static void np_v1_usb_job_app_barrier(void){}
#include "../../../Firmware/V1/Core/Src/np_sd_usb_job_early.inc"

static uint32_t prior[4],usb[4];
static void assert_usb_unchanged(void)
{assert(fake_tamp.BKP18R==0x18a5a5a5U && fake_tamp.BKP19R==0x195a5a5aU &&
        fake_tamp.BKP24R==usb[0] && fake_tamp.BKP25R==usb[1] && fake_tamp.BKP26R==usb[2] && fake_tamp.BKP27R==usb[3]);}
static void assert_prior(void)
{assert(fake_tamp.BKP20R==prior[0] && fake_tamp.BKP21R==prior[1] && fake_tamp.BKP22R==prior[2] && fake_tamp.BKP23R==prior[3]);}
static void fixture(void)
{
    uint8_t plan[128],wire[256],legacy[64]={0};NpUsbSdTestPlan p={0};NpUsbSdTestReport r;
    memset((void*)retained,0,sizeof(retained));memset(&fake_tamp,0,sizeof(fake_tamp));
    memset(&fake_rcc,0,sizeof(fake_rcc));memset(&fake_pwr,0,sizeof(fake_pwr));
    retained_base=(uintptr_t)retained;fake_retention_proven=1;
    np_v1_usb_job_early_done=np_v1_usb_job_early_outcome=0;
    np_v1_usb_job_boot_owned=np_v1_usb_job_owner.state=0U;
    fake_uid[0]=1U;fake_uid[1]=2U;fake_uid[2]=3U;fake_rcc.CSR=RCC_CSR_SFTRSTF|RCC_CSR_PINRSTF;
    usb[0]=0x12345678U;usb[1]=0x9abcdef0U;usb[2]=0x24681357U;usb[3]=0xfedcba98U;
    fake_tamp.BKP18R=0x18a5a5a5U;fake_tamp.BKP19R=0x195a5a5aU;
    fake_tamp.BKP24R=usb[0];fake_tamp.BKP25R=usb[1];fake_tamp.BKP26R=usb[2];fake_tamp.BKP27R=usb[3];
    assert(np_v1_job_storage_initialize(&fake_tamp.BKP9R,retained,np_v1_usb_job_app_barrier));
    p.ticket=42U;p.uid[0]=1U;p.uid[1]=2U;p.uid[2]=3U;p.seconds=10U;
    np_first_put32(legacy,UINT32_C(0x31444c4e));np_first_put32(legacy+4,1U);
    np_first_put32(legacy+8,2U);np_first_put32(legacy+12,1U);
    np_first_put32(legacy+16,3U);np_first_put32(legacy+20,20000U);
    np_first_put32(legacy+24,8192U);np_first_put32(legacy+28,32768U);
    np_first_put32(legacy+32,1U);np_first_put32(legacy+36,1U);
    np_first_put32(legacy+60,np_first_crc(legacy,60U));
    assert(np_first_sd_fine_counter64_wrap(p.npsd,legacy,1U,p.uid,p.ticket,0U));
    assert(np_usb_sd_plan_encode(plan,sizeof(plan),&p));
    np_usb_sd_report_init(&r);r.words[4]=NP_USB_SD_PHASE_ACCEPTED;
    r.words[8]=42U;r.words[9]=0U;r.words[10]=np_usb_sd_u32(plan+60U);
    r.words[12]=1U;r.words[17]=1U;r.words[18]=2U;r.words[19]=3U;
    assert(np_usb_sd_report_encode(wire,sizeof(wire),&r));
    assert(np_v1_job_journal_write(retained,plan,wire,np_v1_usb_job_app_barrier));
    prior[0]=7U;prior[1]=15000U;prior[2]=np_sd_rate_cookie(prior[0],prior[1]);prior[3]=~prior[2];
    fake_tamp.BKP20R=prior[0];fake_tamp.BKP21R=prior[1];fake_tamp.BKP22R=prior[2];fake_tamp.BKP23R=prior[3];
    assert(np_v1_job_profile_stage(&fake_tamp.BKP16R,&fake_tamp.BKP12R,
        &fake_tamp.BKP20R,3U,20000U,p.ticket,np_v1_usb_job_app_barrier));
    assert(np_v1_job_reset_seal(&fake_tamp.BKP11R,p.ticket,np_v1_usb_job_app_barrier));
}
static void replace_journal_ticket(uint64_t ticket)
{
    uint8_t plan[128],wire[256];NpUsbSdTestPlan p;NpUsbSdTestReport r;
    assert(np_v1_job_journal_read(retained,plan,wire));
    assert(np_usb_sd_plan_decode(&p,plan,sizeof(plan)) && np_usb_sd_report_decode(&r,wire,sizeof(wire)));
    p.ticket=ticket;assert(np_usb_sd_plan_encode(plan,sizeof(plan),&p));
    r.words[8]=(uint32_t)ticket;r.words[9]=(uint32_t)(ticket>>32U);r.words[10]=np_usb_sd_u32(plan+60U);
    assert(np_usb_sd_report_encode(wire,sizeof(wire),&r));
    assert(np_v1_job_journal_write(retained,plan,wire,np_v1_usb_job_app_barrier));
}
int main(void)
{
    fixture();assert(NP_V1UsbJobPreClock()==NP_V1_JOB_EARLY_HANDOFF);
    assert(fake_tamp.BKP20R==3U && fake_tamp.BKP21R==20000U &&
           fake_tamp.BKP11R==NP_V1_JOB_RESET_MAGIC && fake_tamp.BKP16R==NP_V1_JOB_PROFILE_MAGIC);
    assert(!np_v1_usb_job_boot_owned && !np_v1_usb_job_owner.state);assert_usb_unchanged();
    assert(NP_V1UsbJobPreClock()==NP_V1_JOB_EARLY_HANDOFF); /* no cookie consumption */

    fixture();retained[127]^=1U;
    assert(NP_V1UsbJobPreClock()==NP_V1_JOB_EARLY_UNKNOWN_RESTORED);
    assert_prior();assert(!fake_tamp.BKP11R && !fake_tamp.BKP16R && np_v1_usb_job_owner.state==4U);assert_usb_unchanged();
    fixture();replace_journal_ticket(43U);
    assert(NP_V1UsbJobPreClock()==NP_V1_JOB_EARLY_UNKNOWN_RESTORED);assert_prior();assert_usb_unchanged();
    fixture();
    assert(np_v1_job_profile_restore(&fake_tamp.BKP16R,&fake_tamp.BKP12R,&fake_tamp.BKP20R,np_v1_usb_job_app_barrier));
    for(unsigned i=0;i<4U;++i)prior[i]=0U;
    fake_tamp.BKP20R=fake_tamp.BKP21R=fake_tamp.BKP22R=fake_tamp.BKP23R=0U;
    assert(np_v1_job_profile_stage(&fake_tamp.BKP16R,&fake_tamp.BKP12R,&fake_tamp.BKP20R,
                                   3U,20000U,42U,np_v1_usb_job_app_barrier));
    replace_journal_ticket(43U);
    assert(NP_V1UsbJobPreClock()==NP_V1_JOB_EARLY_UNKNOWN_RESTORED);assert_prior();assert_usb_unchanged();
    fixture();fake_uid[0]^=1U;
    assert(NP_V1UsbJobPreClock()==NP_V1_JOB_EARLY_UNKNOWN_RESTORED);assert_prior();assert_usb_unchanged();
    fixture();fake_tamp.BKP21R=15000U;
    assert(NP_V1UsbJobPreClock()==NP_V1_JOB_EARLY_UNKNOWN_RESTORED);assert_prior();assert_usb_unchanged();
    fixture();fake_tamp.BKP17R^=1U;
    assert(NP_V1UsbJobPreClock()==NP_V1_JOB_EARLY_FENCE);
    assert(np_v1_usb_job_boot_owned && np_v1_usb_job_owner.state==3U && !fake_tamp.BKP11R);assert_usb_unchanged();
    fixture();fake_tamp.BKP12R^=1U;
    assert(NP_V1UsbJobPreClock()==NP_V1_JOB_EARLY_FENCE);
    assert(np_v1_usb_job_boot_owned && np_v1_usb_job_owner.state==3U && !fake_tamp.BKP11R);assert_usb_unchanged();
    fixture();fake_retention_proven=0;retained_base=0U;
    assert(NP_V1UsbJobPreClock()==NP_V1_JOB_EARLY_UNKNOWN_RESTORED);
    assert(!fake_tamp.BKP11R && !fake_tamp.BKP16R && np_v1_usb_job_boot_owned && np_v1_usb_job_owner.state==4U);
    assert_prior();assert_usb_unchanged();
    fixture();fake_tamp.BKP9R=0U;retained_base=0U;
    assert(NP_V1UsbJobPreClock()==NP_V1_JOB_EARLY_UNKNOWN_RESTORED);
    assert(!fake_tamp.BKP11R && !fake_tamp.BKP16R && np_v1_usb_job_boot_owned && np_v1_usb_job_owner.state==4U);
    assert_prior();assert_usb_unchanged();
    fixture();fake_retention_proven=0;retained_base=0U;fake_tamp.BKP15R^=1U;
    assert(NP_V1UsbJobPreClock()==NP_V1_JOB_EARLY_FENCE);
    assert(!fake_tamp.BKP11R && fake_tamp.BKP16R && np_v1_usb_job_boot_owned && np_v1_usb_job_owner.state==3U);
    assert_usb_unchanged();

    fixture();fake_rcc.CSR=RCC_CSR_BORRSTF;retained_base=0U;
    assert(NP_V1UsbJobPreClock()==NP_V1_JOB_EARLY_UNTRUSTED_CONTINUE);
    assert(!fake_tamp.BKP9R && !fake_tamp.BKP11R && !fake_tamp.BKP16R &&
           !np_v1_usb_job_boot_owned && !np_v1_usb_job_owner.state);assert_usb_unchanged();
    assert_prior();
    fixture();fake_rcc.CSR=RCC_CSR_SFTRSTF|RCC_CSR_IWDGRSTF;retained_base=0U;
    assert(NP_V1UsbJobPreClock()==NP_V1_JOB_EARLY_UNTRUSTED_CONTINUE);assert_prior();assert_usb_unchanged();
    fixture();fake_rcc.CSR=RCC_CSR_BORRSTF;retained_base=0U;fake_tamp.BKP14R^=1U;
    assert(NP_V1UsbJobPreClock()==NP_V1_JOB_EARLY_FENCE);
    assert(!fake_tamp.BKP11R && fake_tamp.BKP16R && np_v1_usb_job_owner.state==3U);
    fixture();fake_rcc.CSR=RCC_CSR_BORRSTF;retained_base=0U;fake_tamp.BKP16R^=1U;
    assert(NP_V1UsbJobPreClock()==NP_V1_JOB_EARLY_FENCE);
    assert(!fake_tamp.BKP11R && fake_tamp.BKP16R && np_v1_usb_job_owner.state==3U);
    fixture();fake_rcc.CSR=RCC_CSR_BORRSTF;fake_tamp.BKP16R=fake_tamp.BKP11R=0U;retained_base=0U;
    assert(NP_V1UsbJobPreClock()==NP_V1_JOB_EARLY_NORMAL && !fake_tamp.BKP9R);assert_usb_unchanged();
    puts("PASS pre-clock handoff, restore, reset fence and USB-profile preservation");
    return 0;
}
