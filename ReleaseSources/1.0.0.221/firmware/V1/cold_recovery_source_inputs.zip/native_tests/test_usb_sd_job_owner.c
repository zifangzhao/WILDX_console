#include <assert.h>
#include <setjmp.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "np_sd_usb_job_guard.h"
#include "np_sd_usb_job_storage.h"
#if defined(_MSC_VER)
#define __attribute__(x)
#endif

static volatile uint32_t retained[NP_V1_JOB_JOURNAL_WORDS];
static uintptr_t retained_base;
static struct { volatile uint32_t BKP6R,BKP7R,BKP8R,BKP9R,BKP10R,BKP11R,BKP12R,BKP13R,BKP14R,BKP15R,
    BKP16R,BKP17R,BKP18R,BKP19R,BKP20R,BKP21R,BKP22R,BKP23R,
    BKP24R,BKP25R,BKP26R,BKP27R,BKP28R,BKP29R,BKP30R,BKP31R; } fake_tamp;
static struct {volatile uint32_t AHB1ENR,CSR;} fake_rcc;
#define RCC (&fake_rcc)
#define RCC_AHB1ENR_BKPSRAMEN 0x100U
#define RCC_CSR_SFTRSTF 0x01U
#define RCC_CSR_OBLRSTF 0x02U
#define RCC_CSR_PINRSTF 0x04U
#define RCC_CSR_BORRSTF 0x08U
#define RCC_CSR_IWDGRSTF 0x10U
#define RCC_CSR_WWDGRSTF 0x20U
#define RCC_CSR_LPWRRSTF 0x40U
#define RCC_CSR_RMVF 0x80U
volatile uint32_t xe_np_hw_startup_rcc_csr;
#define TAMP (&fake_tamp)
#define BKPSRAM_BASE (retained_base)
#define __DSB() ((void)0)
static uint32_t now_ms, np_sd_initialized, begins, polls, resets, downloads;
static uint32_t prior_profile[4];
static uint32_t expected_prior_mask,expected_prior_hz;
typedef struct { uint32_t State,ErrorCode; } SD_HandleTypeDef;
static SD_HandleTypeDef hsd1;
static struct {SD_HandleTypeDef *hsd_card;} xe_np_runtime={&hsd1};
static struct {uint32_t command;} np_sd_mailbox,np_sd_readback;
static struct {uint32_t active;} np_ce64_dir,np_sd_transaction;
enum {NP_SD_IDLE,NP_SD_RUNNING,NP_SD_DRAINING,NP_SD_COMPLETE,NP_SD_FAILED};
static struct {uint32_t state;} np_sd_log;
static uint32_t np_sd_finalized;
static struct {uint32_t target;} np_v1_mode_mailbox;
static struct {uint32_t enabled;} np_sd_camera;
static struct {uint32_t STA,IDMACTRL;} sd_regs;
#define SDMMC1 (&sd_regs)
#define SDMMC_STA_DPSMACT 1U
#define SDMMC_STA_CPSMACT 2U
#define SDMMC_IDMA_IDMAEN 1U
#define HAL_SD_STATE_READY 0U
#define HAL_SD_CARD_TRANSFER 4U
static uint32_t xe_np_sd_init_failed,npl_pending,npl_mode_target,npl_delete_phase,npl_online_pending;
static uint32_t npl_reply_ready,npl_ce32_start_receipt;
static struct {uint32_t active,waiting;} npl_schedule;
static uint32_t np_stream_active,xe_np_quad_dma_active;
static int config_pending;
static int idle=1;
static int npl_idle(void){return idle;}
static int NP_ConfigTransferPending(void){return config_pending;}
static uint32_t HAL_SD_GetCardState(SD_HandleTypeDef *sd){assert(sd==&hsd1);return HAL_SD_CARD_TRANSFER;}
static int begin_result, poll_result, poll_commit, break_commit, omit_rejected_flag;
static uint32_t HAL_GetTick(void){return now_ms;}
static void XE_NP_Boot_RequestDownload(void){++downloads;}
static void NVIC_SystemReset(void){++resets;}
enum { NP_USB_APP_HOLD=0,NP_USB_APP_ACTIVE=1,NP_USB_APP_TERMINAL=2,NP_USB_APP_UNKNOWN=-1 };
typedef int (*MockCommit)(const uint8_t plan[128],const NpUsbSdTestReport *report);

static int NP_UsbSdJobAppBegin(const uint8_t plan[128],NpUsbSdTestReport *r,uint32_t proof,MockCommit commit)
{
    ++begins;assert(proof==NP_USB_JOB_PROOF_ALL);
    assert(fake_tamp.BKP20R==prior_profile[0] && fake_tamp.BKP21R==prior_profile[1] &&
           fake_tamp.BKP22R==prior_profile[2] && fake_tamp.BKP23R==prior_profile[3]);
    assert(!fake_tamp.BKP16R && !fake_tamp.BKP11R &&
           r->words[30]==expected_prior_mask && r->words[31]==expected_prior_hz);
    if(begin_result==NP_USB_APP_TERMINAL){
        r->words[4]=NP_USB_SD_PHASE_REJECTED;r->words[5]=NP_USB_SD_OUTCOME_CATALOG;
        if(!omit_rejected_flag)r->words[6]|=NP_USB_SD_VALID_REJECTED_UNMUTATED;
        return commit(plan,r)==0?NP_USB_APP_TERMINAL:NP_USB_APP_UNKNOWN;
    }
    if(begin_result!=NP_USB_APP_ACTIVE)return begin_result;
    r->words[4]=NP_USB_SD_PHASE_RUNNING;
    return commit(plan,r)==0?NP_USB_APP_ACTIVE:NP_USB_APP_UNKNOWN;
}
static int NP_UsbSdJobAppPoll(const uint8_t plan[128],NpUsbSdTestReport *r,MockCommit commit)
{
    ++polls;
    if(poll_result!=NP_USB_APP_TERMINAL)return poll_result;
    r->words[4]=NP_USB_SD_PHASE_FINISHED;r->words[5]=NP_USB_SD_OUTCOME_CANDIDATE;
    r->words[6]|=NP_USB_SD_VALID_TERMINAL;
    np_sd_log.state=NP_SD_COMPLETE;np_sd_finalized=1U;
    if(break_commit)fake_tamp.BKP9R=0U;
    if(poll_commit && commit(plan,r)!=0)return NP_USB_APP_UNKNOWN;
    return NP_USB_APP_TERMINAL;
}
#include "../../../Firmware/V1/Core/Src/np_sd_usb_job_owner.inc"

static unsigned barrier_count,barrier_cut;
static jmp_buf reset_jump;
static void barrier(void){if(++barrier_count==barrier_cut)longjmp(reset_jump,1);}
static void reset_fixture(void)
{
    uint8_t plan[128],wire[256];NpUsbSdTestPlan p={0};NpUsbSdTestReport r;
    memset((void*)retained,0,sizeof(retained));memset(&fake_tamp,0,sizeof(fake_tamp));
    retained_base=(uintptr_t)retained;barrier_count=barrier_cut=0U;
    memset(&np_v1_usb_job_owner,0,sizeof(np_v1_usb_job_owner));
    np_v1_usb_job_app_claimed=np_v1_usb_job_boot_owned=0U;fake_rcc.AHB1ENR=0U;
    now_ms=begins=polls=resets=downloads=0U;np_sd_initialized=1U;
    xe_np_hw_startup_rcc_csr=RCC_CSR_SFTRSTF;
    hsd1.State=hsd1.ErrorCode=xe_np_sd_init_failed=0U;
    np_sd_mailbox.command=np_sd_readback.command=np_ce64_dir.active=np_sd_transaction.active=0U;
    np_sd_log.state=NP_SD_IDLE;np_sd_finalized=0U;
    np_v1_mode_mailbox.target=np_sd_camera.enabled=sd_regs.STA=sd_regs.IDMACTRL=0U;
    npl_pending=npl_mode_target=npl_delete_phase=npl_online_pending=np_stream_active=xe_np_quad_dma_active=0U;
    npl_reply_ready=npl_ce32_start_receipt=npl_schedule.active=npl_schedule.waiting=0U;
    config_pending=0;idle=1;
    begin_result=NP_USB_APP_ACTIVE;poll_result=NP_USB_APP_ACTIVE;poll_commit=break_commit=omit_rejected_flag=0;
    assert(np_v1_job_storage_initialize(&fake_tamp.BKP9R,retained,barrier));
    p.ticket=42U;p.uid[0]=1U;p.uid[1]=2U;p.uid[2]=3U;p.seconds=10U;
    assert(np_usb_sd_plan_encode(plan,sizeof(plan),&p));
    np_usb_sd_report_init(&r);r.words[4]=NP_USB_SD_PHASE_ACCEPTED;
    r.words[8]=42U;r.words[9]=0U;r.words[10]=np_usb_sd_u32(plan+60U);
    r.words[12]=1U;r.words[17]=1U;r.words[18]=2U;r.words[19]=3U;
    assert(np_usb_sd_report_encode(wire,sizeof(wire),&r));
    assert(np_v1_job_journal_write(retained,plan,wire,barrier));
    prior_profile[0]=7U;prior_profile[1]=15000U;
    expected_prior_mask=7U;expected_prior_hz=15000U;
    prior_profile[2]=np_sd_rate_cookie(prior_profile[0],prior_profile[1]);
    prior_profile[3]=~prior_profile[2];
    fake_tamp.BKP24R=7U;fake_tamp.BKP25R=7500U;
    fake_tamp.BKP26R=np_sd_rate_cookie(7U,7500U);fake_tamp.BKP27R=~fake_tamp.BKP26R;
    fake_tamp.BKP20R=prior_profile[0];fake_tamp.BKP21R=prior_profile[1];
    fake_tamp.BKP22R=prior_profile[2];fake_tamp.BKP23R=prior_profile[3];
    assert(np_v1_job_profile_stage(&fake_tamp.BKP16R,&fake_tamp.BKP12R,&fake_tamp.BKP20R,3U,20000U,p.ticket,barrier));
    assert(np_v1_job_reset_seal(&fake_tamp.BKP11R,p.ticket,barrier));
}
static void owner_start(void)
{now_ms=10U;NP_V1UsbJobAppService();assert(begins==1U && np_v1_usb_job_owner.state==1U);
 assert(fake_tamp.BKP24R==7U && fake_tamp.BKP25R==7500U &&
        np_sd_rate_cookie_valid(fake_tamp.BKP24R,fake_tamp.BKP25R,fake_tamp.BKP26R,fake_tamp.BKP27R));}
static void normal_tests(void)
{
    uint8_t p[128],w[256];NpUsbSdTestReport report;
    uint32_t *busy[] = {&np_sd_mailbox.command,&np_sd_readback.command,&np_ce64_dir.active,
        &np_sd_transaction.active,&np_v1_mode_mailbox.target,&np_sd_camera.enabled,
        &npl_pending,&npl_mode_target,&npl_delete_phase,&npl_online_pending,
        &npl_reply_ready,&npl_ce32_start_receipt,&npl_schedule.active,&npl_schedule.waiting,
        &np_stream_active,&xe_np_quad_dma_active,&sd_regs.STA,&sd_regs.IDMACTRL,
        &xe_np_sd_init_failed,&hsd1.State,&hsd1.ErrorCode};
    reset_fixture();fake_tamp.BKP16R=fake_tamp.BKP11R=0U;NP_V1UsbJobAppService();
    assert(!begins && !polls && !downloads && !resets);
    reset_fixture();np_sd_initialized=0U;NP_V1UsbJobAppService();
    assert(!begins && !polls && !downloads && !resets);
    reset_fixture();retained[127]^=1U;NP_V1UsbJobAppService();
    assert(!begins && !polls && !downloads && !resets && np_v1_usb_job_owner.state==4U);
    assert(fake_tamp.BKP20R==prior_profile[0] && fake_tamp.BKP21R==prior_profile[1] &&
           fake_tamp.BKP22R==prior_profile[2] && fake_tamp.BKP23R==prior_profile[3] &&
           !fake_tamp.BKP11R && !fake_tamp.BKP16R);
    now_ms=11U;idle=0;NP_V1UsbJobAppService();assert(!downloads && !resets);
    now_ms=12U;idle=1;NP_V1UsbJobAppService();
    assert(!begins && downloads==1U && resets==1U && !fake_tamp.BKP9R);
    /* Power/reset ambiguity and ticket mismatch restore the old profile but
     * never dispatch; no SRAM read or replay is permitted on a power event. */
    reset_fixture();xe_np_hw_startup_rcc_csr=RCC_CSR_BORRSTF;
    retained_base=0U;NP_V1UsbJobAppService();
    assert(!begins && !downloads && !resets && fake_tamp.BKP16R && fake_tamp.BKP11R);
    reset_fixture();xe_np_hw_startup_rcc_csr=RCC_CSR_PINRSTF;
    NP_V1UsbJobAppService();assert(!begins && !downloads && !resets && fake_tamp.BKP16R);
    reset_fixture();xe_np_hw_startup_rcc_csr=RCC_CSR_SFTRSTF|RCC_CSR_PINRSTF;
    owner_start();assert(!fake_tamp.BKP11R && fake_tamp.BKP20R==prior_profile[0]);
    reset_fixture();xe_np_hw_startup_rcc_csr=RCC_CSR_SFTRSTF|RCC_CSR_PINRSTF|RCC_CSR_BORRSTF;
    NP_V1UsbJobAppService();assert(!begins && !downloads && !resets && fake_tamp.BKP16R);
    reset_fixture();fake_tamp.BKP11R^=1U;NP_V1UsbJobAppService();
    assert(!begins && !downloads && !resets && fake_tamp.BKP20R==prior_profile[0] && !fake_tamp.BKP11R);
    reset_fixture();fake_tamp.BKP12R^=1U;NP_V1UsbJobAppService();
    assert(!begins && !downloads && !resets && np_v1_usb_job_owner.state==3U && fake_tamp.BKP16R);
    reset_fixture();fake_tamp.BKP17R^=1U;NP_V1UsbJobAppService();
    assert(!begins && !downloads && !resets && np_v1_usb_job_owner.state==3U && fake_tamp.BKP16R);
    /* The all-zero saved profile restores verbatim, while the reported prior
     * runtime profile follows the original main object's 3/15k default. */
    reset_fixture();assert(np_v1_job_profile_restore(&fake_tamp.BKP16R,&fake_tamp.BKP12R,&fake_tamp.BKP20R,barrier));
    prior_profile[0]=prior_profile[1]=prior_profile[2]=prior_profile[3]=0U;
    fake_tamp.BKP20R=fake_tamp.BKP21R=fake_tamp.BKP22R=fake_tamp.BKP23R=0U;
    expected_prior_mask=3U;expected_prior_hz=15000U;
    assert(np_v1_job_profile_stage(&fake_tamp.BKP16R,&fake_tamp.BKP12R,&fake_tamp.BKP20R,3U,20000U,42U,barrier));
    owner_start();assert(!fake_tamp.BKP20R && !fake_tamp.BKP21R && !fake_tamp.BKP22R && !fake_tamp.BKP23R);
    reset_fixture();owner_start();
    NP_V1UsbJobAppService();NP_V1UsbJobAppService();assert(!polls);
    now_ms=11U;NP_V1UsbJobAppService();NP_V1UsbJobAppService();assert(polls==1U);
    now_ms=12U;NP_V1UsbJobAppService();NP_V1UsbJobAppService();assert(polls==2U);
    now_ms=13U;poll_result=NP_USB_APP_TERMINAL;poll_commit=1;NP_V1UsbJobAppService();
    assert(downloads==1U && resets==1U && np_v1_job_journal_read(retained,p,w));
    assert(np_usb_sd_report_decode(&report,w,sizeof(w)) && report.words[4]==NP_USB_SD_PHASE_FINISHED);
    assert(!(report.words[6]&NP_USB_SD_VALID_PROFILE_RESTORED));
    reset_fixture();owner_start();now_ms=11U;poll_result=NP_USB_APP_TERMINAL;
    poll_commit=1;break_commit=1;NP_V1UsbJobAppService();
    assert(polls==1U && !downloads && !resets && np_v1_usb_job_owner.state==3U);
    reset_fixture();begin_result=NP_USB_APP_TERMINAL;idle=0;NP_V1UsbJobAppService();
    assert(begins==1U && !downloads && !resets);
    reset_fixture();begin_result=NP_USB_APP_TERMINAL;np_sd_log.state=NP_SD_RUNNING;NP_V1UsbJobAppService();
    assert(begins==1U && !downloads && !resets);
    reset_fixture();begin_result=NP_USB_APP_TERMINAL;np_stream_active=1U;NP_V1UsbJobAppService();
    assert(begins==1U && !downloads && !resets);
    for(unsigned i=0;i<sizeof(busy)/sizeof(busy[0]);++i){
        reset_fixture();begin_result=NP_USB_APP_TERMINAL;*busy[i]=1U;NP_V1UsbJobAppService();
        assert(begins==1U && !downloads && !resets);
    }
    reset_fixture();begin_result=NP_USB_APP_TERMINAL;config_pending=1;NP_V1UsbJobAppService();
    assert(begins==1U && !downloads && !resets);
    reset_fixture();begin_result=NP_USB_APP_TERMINAL;omit_rejected_flag=1;NP_V1UsbJobAppService();
    assert(begins==1U && !downloads && !resets);
    reset_fixture();begin_result=NP_USB_APP_TERMINAL;NP_V1UsbJobAppService();
    assert(begins==1U && downloads==1U && resets==1U);
}
static void interrupted_profile_tests(void)
{
    for(unsigned cut=1U;cut<=8U;++cut){
        reset_fixture();fake_tamp.BKP16R=0U;
        fake_tamp.BKP20R=prior_profile[0];fake_tamp.BKP21R=prior_profile[1];
        fake_tamp.BKP22R=prior_profile[2];fake_tamp.BKP23R=prior_profile[3];
        barrier_count=0U;barrier_cut=cut;
        if(!setjmp(reset_jump))(void)np_v1_job_profile_stage(&fake_tamp.BKP16R,&fake_tamp.BKP12R,&fake_tamp.BKP20R,3U,20000U,42U,barrier);
        barrier_cut=0U;
        if(np_v1_job_profile_pending(&fake_tamp.BKP16R,&fake_tamp.BKP12R))
            assert(np_v1_job_profile_restore(&fake_tamp.BKP16R,&fake_tamp.BKP12R,&fake_tamp.BKP20R,barrier));
        assert(fake_tamp.BKP20R==prior_profile[0] && fake_tamp.BKP21R==prior_profile[1] &&
               fake_tamp.BKP22R==prior_profile[2] && fake_tamp.BKP23R==prior_profile[3]);
    }
    for(unsigned cut=1U;cut<=4U;++cut){
        reset_fixture();barrier_count=0U;barrier_cut=cut;
        if(!setjmp(reset_jump))(void)np_v1_job_profile_restore(&fake_tamp.BKP16R,&fake_tamp.BKP12R,&fake_tamp.BKP20R,barrier);
        barrier_cut=0U;
        if(np_v1_job_profile_pending(&fake_tamp.BKP16R,&fake_tamp.BKP12R))
            assert(np_v1_job_profile_restore(&fake_tamp.BKP16R,&fake_tamp.BKP12R,&fake_tamp.BKP20R,barrier));
        assert(!fake_tamp.BKP16R && fake_tamp.BKP20R==prior_profile[0] &&
               fake_tamp.BKP21R==prior_profile[1] && fake_tamp.BKP22R==prior_profile[2] &&
               fake_tamp.BKP23R==prior_profile[3]);
    }
}
static int defensive_test(void)
{
    reset_fixture();owner_start();now_ms=11U;poll_result=NP_USB_APP_TERMINAL;poll_commit=0;
    NP_V1UsbJobAppService();
    if(downloads || resets){fprintf(stderr,"FAIL: terminal return without persisted journal triggers Download/reset\n");return 1;}
    return 0;
}
int main(int argc,char **argv)
{(void)argv;if(argc>1)return defensive_test();normal_tests();interrupted_profile_tests();puts("PASS owner, reset provenance and interrupted profile handoff");return 0;}
