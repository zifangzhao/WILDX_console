#include <assert.h>
#include <setjmp.h>
#include <stdint.h>
#include <string.h>
#include "np_sd_usb_job_profile.h"

static jmp_buf interrupted;
static unsigned barriers, stop_at;
static void fence(void) { if (++barriers == stop_at) longjmp(interrupted, 1); }
static void normal(void) { barriers = stop_at = 0U; }
static void fixture(volatile uint32_t *marker, volatile uint32_t *saved, volatile uint32_t *profile,
                    uint32_t mask, uint32_t hz)
{
    marker[0]=marker[1]=0U;
    for (unsigned i=0;i<4U;++i) saved[i]=0U;
    profile[0]=mask; profile[1]=hz; profile[2]=np_sd_rate_cookie(mask,hz); profile[3]=~profile[2];
}
static void unchanged(const volatile uint32_t *profile, const uint32_t *expected)
{ for(unsigned i=0;i<4U;++i)assert(profile[i]==expected[i]); }
int main(void)
{
    volatile uint32_t marker[2], saved[4], profile[4]; uint32_t original[4];
    const uint64_t ticket=UINT64_C(0x1122334455667788);
    const uint32_t rates[]={7500U,15000U,20000U,30000U};
    /* Every admissible original profile, including camera-only, is exactly
     * restored from backup registers; no ECC SRAM is involved. */
    for(unsigned m=0;m<=7U;++m) for(unsigned j=0;j<4U;++j) {
        uint32_t hz=m?rates[j]:0U, decoded_mask=99U,decoded_hz=99U;
        if(!np_sd_rate_valid(m,hz)) continue;
        fixture(marker,saved,profile,m,hz); for(unsigned i=0;i<4U;++i)original[i]=profile[i];
        normal();assert(np_v1_job_profile_stage(marker,saved,profile,3U,20000U,ticket,fence));
        assert(np_v1_job_profile_pending(marker,saved));
        assert(np_v1_job_profile_decode(saved,&decoded_mask,&decoded_hz));
        assert(decoded_mask==m && decoded_hz==hz);
        assert(np_v1_job_profile_restore(marker,saved,profile,fence));
        unchanged(profile,original);assert(!marker[0] && !np_v1_job_profile_pending(marker,saved));
    }
    /* An untouched all-zero boot profile is restored bit for bit, while its
     * effective default is P1+P2/15 kHz. */
    fixture(marker,saved,profile,7U,7500U);
    for(unsigned i=0;i<4U;++i)original[i]=profile[i]=0U;
    normal();assert(np_v1_job_profile_stage(marker,saved,profile,3U,20000U,ticket,fence));
    uint32_t mask=0U,hz=0U;assert(np_v1_job_profile_decode(saved,&mask,&hz));
    assert(mask==3U && hz==15000U);
    assert(np_v1_job_profile_restore(marker,saved,profile,fence));
    unchanged(profile,original);
    fixture(marker,saved,profile,7U,7500U);profile[2]^=1U;
    for(unsigned i=0;i<4U;++i)original[i]=profile[i];
    normal();assert(!np_v1_job_profile_stage(marker,saved,profile,3U,20000U,ticket,fence));
    assert(!marker[0]);unchanged(profile,original);
    /* Every torn/corrupt independently protected word blocks restoration. */
    for(unsigned word=0U;word<5U;++word) for(unsigned bit=0U;bit<32U;++bit){
        fixture(marker,saved,profile,7U,7500U);
        normal();assert(np_v1_job_profile_stage(marker,saved,profile,3U,20000U,ticket,fence));
        for(unsigned i=0;i<4U;++i)original[i]=profile[i];
        if(word<4U)saved[word]^=UINT32_C(1)<<bit;else marker[1]^=UINT32_C(1)<<bit;
        assert(!np_v1_job_profile_pending(marker,saved));
        assert(!np_v1_job_profile_restore(marker,saved,profile,fence));unchanged(profile,original);
    }
    /* Reset at each publication barrier: either the old profile was never
     * touched, or the durable snapshot permits exact repeated recovery. */
    for(unsigned cut=1U;cut<=12U;++cut) {
        fixture(marker,saved,profile,7U,7500U);for(unsigned i=0;i<4U;++i)original[i]=profile[i];
        barriers=0U;stop_at=cut;
        if(!setjmp(interrupted)) (void)np_v1_job_profile_stage(marker,saved,profile,3U,20000U,ticket,fence);
        normal();
        if(np_v1_job_profile_pending(marker,saved))assert(np_v1_job_profile_restore(marker,saved,profile,fence));
        unchanged(profile,original);
    }
    for(unsigned cut=1U;cut<=8U;++cut) {
        fixture(marker,saved,profile,7U,7500U);for(unsigned i=0;i<4U;++i)original[i]=profile[i];
        normal();assert(np_v1_job_profile_stage(marker,saved,profile,3U,20000U,ticket,fence));
        barriers=0U;stop_at=cut;
        if(!setjmp(interrupted)) (void)np_v1_job_profile_restore(marker,saved,profile,fence);
        normal();
        if(np_v1_job_profile_pending(marker,saved))assert(np_v1_job_profile_restore(marker,saved,profile,fence));
        assert(!marker[0]);unchanged(profile,original);
    }
    return 0;
}
