#ifndef XE_NP_PSRAM_PADS_H
#define XE_NP_PSRAM_PADS_H

#include "stm32u5xx_hal.h"

/* Shared startup operation; the board supplies only its fitted pin masks.
 * Caller enables the selected GPIO clocks first and establishes a <=2.7 V
 * pad supply. The option bit is a prerequisite, not a voltage measurement.
 * No option-byte programming; preserve every unselected peripheral pin. */
static inline uint32_t XE_NP_Psram_EnablePadHslv(uint32_t pins_a,
                                               uint32_t pins_c,
                                               uint32_t pins_d)
{
    if((FLASH->OPTR & FLASH_OPTR_IO_VDD_HSLV) == 0U) return 0U;
    if(pins_d) HAL_GPIO_EnableHighSPeedLowVoltage(GPIOD, (uint16_t)pins_d);
    if(pins_c) HAL_GPIO_EnableHighSPeedLowVoltage(GPIOC, (uint16_t)pins_c);
    if(pins_a) HAL_GPIO_EnableHighSPeedLowVoltage(GPIOA, (uint16_t)pins_a);
    __DSB();
    return (!pins_a || (GPIOA->HSLVR & pins_a) == pins_a) &&
           (!pins_c || (GPIOC->HSLVR & pins_c) == pins_c) &&
           (!pins_d || (GPIOD->HSLVR & pins_d) == pins_d);
}
#endif
