#ifndef __CE32_SUBMOD
#define __CE32_SUBMOD

#include "stm32f4xx_hal.h"
#include "dataMGR.h"
#include "CE32_UART_INTERCOM.h"
#include <string.h>

#define CE32_SUBMOD_MODE_NORMAL 0U
#define CE32_SUBMOD_MODE_MASTER 1U
#define CE32_SUBMOD_MODE_SLAVE 2U

typedef struct
{
    CE32_INTERCOM_Handle COMM;
    uint16_t mode;
    CE32_systemParam *sysParam;
} CE32_SUBMOD;

extern CE32_SUBMOD SUBMOD_handle;

void CE32_SUBMOD_INIT(CE32_SUBMOD *handle, UART_HandleTypeDef *huart, CE32_systemParam *sysParam);
void CE32_SUBMOD_Enable(CE32_SUBMOD *handle);
void CE32_SUBMOD_Disable(CE32_SUBMOD *handle);
void CE32_SUBMOD_Transmit(CE32_SUBMOD *handle, uint8_t *cmd, uint16_t len);
void CE32_SUBMOD_Handshake(CE32_SUBMOD *handle);
void CE32_SUBMOD_SyncParam(CE32_SUBMOD *handle);
void CE32_SUBMOD_Trig(CE32_SUBMOD *handle, uint8_t id);
void CE32_SUBMOD_SetIntensity(CE32_SUBMOD *handle, uint16_t lvl, uint8_t id);

void CE32_SUBMOD_PreInitAct(CE32_SUBMOD *handle);
void CE32_SUBMOD_PreEnableAct(CE32_SUBMOD *handle);
void CE32_SUBMOD_PreTXAct(CE32_SUBMOD *handle);
void CE32_SUBMOD_PostTXAct(CE32_SUBMOD *handle);

#endif
