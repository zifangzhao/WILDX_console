#ifndef NP_CATALOG_FS2_H
#define NP_CATALOG_FS2_H
#include "np_catalog_preserve.h"
#include "np_store_v2.h"

/* Pure redundancy repair plan. The caller owns card identity and execution;
 * descriptors/payload never supply allocation authority and are not read here. */
static int np_catalog_fs2_inspect(const NpcrReadIo *io,uint32_t capacity,NpcrPlan *p)
{
    uint8_t identity[2][512],checkpoint[2][512];
    uint64_t epoch;int vi[2],vc[2],result;unsigned ident,check;
    Nps2State selected;
    if(!io || !io->read || !p)return NPCR_BAD_REQUEST;
    p->layout=NPCR_FS2;p->flags|=NPCR_FS2;
    if(capacity<=NPS2_DATA)return NPCR_CATALOG;
    /* No repair may be proposed when either redundant copy is unreadable. */
    result=npcr_read(io,p,NPS2_IDENT0,identity[0]);if(result)return result;
    result=npcr_read(io,p,NPS2_IDENT1,identity[1]);if(result)return result;
    result=npcr_read(io,p,NPS2_CHECK0,checkpoint[0]);if(result)return result;
    result=npcr_read(io,p,NPS2_CHECK1,checkpoint[1]);if(result)return result;

    vi[0]=nps2_identity_valid(identity[0],capacity);
    vi[1]=nps2_identity_valid(identity[1],capacity);
    if((!vi[0] && !vi[1]) || (vi[0] && vi[1] && memcmp(identity[0],identity[1],512)))return NPCR_CATALOG;
    ident=vi[0]?0U:1U;epoch=nps2_get64(identity[ident]+56);
    vc[0]=nps2_checkpoint_valid(checkpoint[0],capacity,epoch);
    vc[1]=nps2_checkpoint_valid(checkpoint[1],capacity,epoch);
    if(!vc[0] && !vc[1])return NPCR_CATALOG;
    check=vc[0]?0U:1U;
    if(vc[0] && vc[1]){
        uint64_t ga=nps2_get64(checkpoint[0]+24),gb=nps2_get64(checkpoint[1]+24);
        const uint8_t *hi=ga>=gb?checkpoint[0]:checkpoint[1];
        const uint8_t *lo=ga>=gb?checkpoint[1]:checkpoint[0];
        /* Exactly nps2_mount's consistency policy, including equal-generation
         * byte equality and only one monotonic adjacent-generation transition. */
        if((ga==gb && memcmp(checkpoint[0],checkpoint[1],512)) ||
           (ga!=gb && (nps2_get64(hi+24)-nps2_get64(lo+24)!=1U ||
            nps2_get(hi+32)<nps2_get(lo+32) || nps2_get(hi+36)<nps2_get(lo+36) ||
            nps2_get(hi+36)-nps2_get(lo+36)>1U)))return NPCR_CATALOG;
        check=ga>=gb?0U:1U;
    }
    nps2_decode_checkpoint(&selected,checkpoint[check]);
    p->next_lba=selected.frontier;p->count=selected.count;
    p->format_epoch=selected.epoch;p->generation=selected.generation;
    if(capacity-selected.frontier<NPS2_ALIGN || selected.count==NPS2_RECORDS)p->flags|=NPCR_FULL;

    /* Authority was established before planning either change. Copy its exact
     * sector bytes; never synthesize a checkpoint or reclaim an open grant. */
    result=npcr_change(p,ident?NPS2_IDENT0:NPS2_IDENT1,identity[ident^1U],identity[ident]);
    if(result)return result;
    result=npcr_change(p,check?NPS2_CHECK0:NPS2_CHECK1,checkpoint[check^1U],checkpoint[check]);
    if(result)return result;
    if(p->writes)p->flags|=NPCR_DEGRADED;
    return NPCR_OK;
}
#endif
