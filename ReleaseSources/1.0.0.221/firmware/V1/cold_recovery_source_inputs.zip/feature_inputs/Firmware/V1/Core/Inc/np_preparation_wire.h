#ifndef NP_PREPARATION_WIRE_H
#define NP_PREPARATION_WIRE_H
#include <stdint.h>
#include <string.h>

/* Optional foreground control on existing configuration mailboxes. Version 1
 * prepares probes/clock only: no recording, acquisition epoch, DMA arm, SD
 * reservation/preerase or recording timestamp. A READY receipt is not START. */
#define NP_PREP_REQUEST_MAGIC UINT32_C(0x4350504e) /* NPPC */
#define NP_PREP_REPLY_MAGIC UINT32_C(0x5250504e) /* NPPR */
#define NP_PREP_WIRE_BYTES 64U
enum { NP_PREP_STATUS=0U, NP_PREP_PREPARE=1U, NP_PREP_CANCEL=2U };
enum { NP_PREP_OK=0U, NP_PREP_UNSUPPORTED=1U, NP_PREP_INVALID=2U,
       NP_PREP_BUSY=3U, NP_PREP_STALE=4U, NP_PREP_ERROR=5U };
enum { NP_PREP_EMPTY=0U, NP_PREP_PREPARING=1U, NP_PREP_READY=2U,
       NP_PREP_CONSUMED=3U, NP_PREP_FAILED=4U, NP_PREP_CANCELING=5U };
enum { NP_PREP_USB=1U, NP_PREP_SD=2U };
typedef struct {
    uint32_t op,id,mode,mask,hz,generation;
} NpPreparationRequest;
typedef struct {
    uint32_t result,state,generation,mode,mask,hz,fingerprint,detail,uid[3];
} NpPreparationReply;
static inline uint32_t np_prep_get(const uint8_t *b)
{return (uint32_t)b[0]|((uint32_t)b[1]<<8)|((uint32_t)b[2]<<16)|((uint32_t)b[3]<<24);}
static inline void np_prep_put(uint8_t *b,uint32_t v)
{unsigned i;for(i=0;i<4U;i++)b[i]=(uint8_t)(v>>(8U*i));}
static inline uint32_t np_prep_crc(const uint8_t *b,uint32_t n)
{uint32_t c=~0U,i,j;for(i=0;i<n;i++){c^=b[i];for(j=0;j<8U;j++)c=(c>>1)^((c&1U)?0xedb88320U:0U);}return ~c;}
static inline int np_prep_profile(uint32_t mask,uint32_t hz)
{return mask && !(mask&~7U) && (hz==7500U || hz==15000U || hz==20000U || hz==30000U);}
static inline int np_preparation_parse(const uint8_t b[64],NpPreparationRequest *q)
{
    uint32_t i;if(!b || !q || np_prep_get(b)!=NP_PREP_REQUEST_MAGIC ||
        np_prep_get(b+4)!=1U || np_prep_get(b+60)!=np_prep_crc(b,60U))return 0;
    for(i=32U;i<60U;i++)if(b[i])return 0;
    q->op=np_prep_get(b+8);q->id=np_prep_get(b+12);q->mode=np_prep_get(b+16);
    q->mask=np_prep_get(b+20);q->hz=np_prep_get(b+24);q->generation=np_prep_get(b+28);
    if(!q->id || q->op>NP_PREP_CANCEL)return 0;
    if(q->op==NP_PREP_STATUS)return !(q->mode|q->mask|q->hz|q->generation);
    if(q->mode!=NP_PREP_USB && q->mode!=NP_PREP_SD)return 0;
    if(q->op==NP_PREP_CANCEL)return q->generation && !(q->mask|q->hz);
    /* generation0 means current actual confirmed settings, not permission to
     * adopt host mask/rate. Nonzero must match the current prep generation. */
    return np_prep_profile(q->mask,q->hz);
}
static inline void np_preparation_pack(uint8_t b[64],const NpPreparationRequest *q,
                                       const NpPreparationReply *r)
{
    memset(b,0,64U);np_prep_put(b,NP_PREP_REPLY_MAGIC);np_prep_put(b+4,1U);
    np_prep_put(b+8,q->op);np_prep_put(b+12,q->id);np_prep_put(b+16,r->result);
    np_prep_put(b+20,r->state);np_prep_put(b+24,r->generation);np_prep_put(b+28,r->mode);
    np_prep_put(b+32,r->mask);np_prep_put(b+36,r->hz);np_prep_put(b+40,r->fingerprint);
    np_prep_put(b+44,r->detail);np_prep_put(b+48,r->uid[0]);np_prep_put(b+52,r->uid[1]);
    np_prep_put(b+56,r->uid[2]);np_prep_put(b+60,np_prep_crc(b,60U));
}
#endif
