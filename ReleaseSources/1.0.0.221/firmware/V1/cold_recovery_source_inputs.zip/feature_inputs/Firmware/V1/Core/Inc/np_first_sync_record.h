#ifndef NP_FIRST_SYNC_RECORD_H
#define NP_FIRST_SYNC_RECORD_H
#include "np_first_sync_v1.h"
#include "np_cl_source.h" /* Independent acquisition state; no CL workspace. */

typedef struct NpFirstV1Record NpFirstV1Record;
typedef void (*NpFirstV1FinalReject)(const NpFirstV1Record *,const NpClAnchorReceipt *);
/* Caller owns the completed private views until this foreground call returns.
 * The source ledger MUST already have committed after DMA retention/deadline
 * acceptance. No live ring pointer or view survives this call. */
typedef struct {
    NpClSourceReceipt source;
    const void *view[3];
    uint32_t now_ms,cycles;
} NpFirstV1Private;
struct NpFirstV1Record {
    NpFirstSyncReceipt receipt;
    NpClSourceState source;
    NpFirstV1Byte read[3];
    void (*observe)(NpFirstV1Record *,const NpFirstV1Private *);
    uint32_t final_generation,reads,discovered_ms,release_ms;
    uint8_t live,sealed,released;
};
static inline void np_first_record_ignore(NpFirstV1Record *r,const NpFirstV1Private *v)
{(void)r;(void)v;}
static inline void np_first_record_close(NpFirstV1Record *r)
{
    r->live=0U;r->observe=np_first_record_ignore;
    np_cl_source_loss(&r->source);
    /* Historical receipt stays bound to its original recording/generation. */
}
static inline void np_first_record_observe(NpFirstV1Record *r,const NpFirstV1Private *v)
{
    NpFirstSyncReceipt *q=&r->receipt;const NpClSourceReceipt *s=&v->source;
    const uint32_t need=NP_CL_SOURCE_VALID|NP_CL_SOURCE_RESET_VALID;
    /* RESET_VALID is assigned at source claim, inside the half-epoch window.
     * The committed private copy may be inspected later; keep checking the
     * bound witness and its claim-time, not the observer's scheduling delay. */
    if(!r->final_generation || !(q->flags&NP_FIRST_FINAL) || !r->source.valid ||
       r->source.pending_mask || s->flags!=need || !s->probe_mask ||
       (s->probe_mask&~q->mask) || s->capture_generation!=q->generation ||
       s->source_epoch!=q->source_epoch || s->source_tick_count<2339U ||
       s->first_source_tick>UINT64_MAX-s->source_tick_count ||
       r->source.reset.stage!=NP_CL_RESET_BOUND ||
       r->source.reset.capture_generation!=q->generation ||
       r->source.reset.probe_mask!=q->mask || r->source.reset.ap_hz!=q->ap_hz ||
       v->now_ms<r->source.reset.last_ms ||
       !np_cl_reset_window(&r->source.reset,r->source.reset.last_ms)){
        np_first_record_close(r);return;
    }
    for(unsigned p=0U;p<3U;p++)if(s->probe_mask&(1U<<p)){
        if(r->source.next_tick[p]!=s->first_source_tick+s->source_tick_count){
            np_first_record_close(r);return;
        }
        if(q->probes[p].flags!=NP_FIRST_PROBE_SELECTED)continue;
        uint32_t reads=0U;
        if(!v->view[p] || !np_first_v1_scan(r->read[p],v->view[p],s->source_tick_count,
            s->first_source_tick,4096U,1,&q->probes[p],&reads)){
            r->reads+=reads;np_first_record_close(r);return;
        }
        r->reads+=reads;
        if(p+1U==q->reference)q->reference_tick=q->probes[p].first_tick;
    }
    for(unsigned p=0U;p<3U;p++)
        if((q->mask&(1U<<p)) && q->probes[p].flags!=31U)return;
    q->flags|=NP_FIRST_ALL_PORTS;q->reference_tick=q->probes[q->reference-1U].first_tick;
    r->discovered_ms=v->now_ms;
    if(q->domain){q->flags|=NP_FIRST_DISCOVERY;q->discovery_ms=v->now_ms;q->discovery_cycles=v->cycles;}
    NpFirstSyncBinding b={q->session,q->generation,q->source_epoch,q->domain,
        q->counter_hz,q->profile_crc,1U,q->mask,q->ap_hz};
    uint8_t wire[NP_FIRST_SYNC_BYTES];
    r->live=(uint8_t)(np_first_sync_pack(wire,q) && np_first_sync_gate_match(wire,sizeof(wire),&b));
    r->observe=np_first_record_ignore; /* No more scans/CRC in subsequent batches. */
}
static inline int np_first_record_begin(NpFirstV1Record *r,const NpFirstSyncBinding *b,
    uint32_t aux_mask,const NpFirstV1Byte readers[3])
{
    memset(r,0,sizeof(*r));r->observe=np_first_record_ignore;
    if(!b || !readers || b->family!=1U || !b->session || !b->source_epoch ||
       !b->mask || (b->mask&~7U) || !np_first_profile(b->ap_hz) || (aux_mask&~15U) ||
       ((!b->domain)!=(!b->counter_hz)) || b->counter_hz>1000000000U)return 0;
    NpFirstSyncReceipt *q=&r->receipt;
    q->flags=1U<<8;q->session=b->session;q->source_epoch=b->source_epoch;
    q->domain=b->domain;q->counter_hz=b->counter_hz;q->profile_crc=b->profile_crc;
    if(b->profile_crc!=UINT32_MAX)q->flags|=NP_FIRST_PROFILE;
    q->ap_hz=b->ap_hz;q->source_hz=b->ap_hz*780U;q->mask=(uint8_t)b->mask;
    q->reference=1U;while(!(q->mask&(1U<<(q->reference-1U))))q->reference++;
    q->reference_tick=UINT64_MAX;q->discovery_ms=q->discovery_cycles=UINT32_MAX;
    q->aux_mask=(uint8_t)aux_mask;q->policy=aux_mask?1U:0U;
    for(unsigned p=0U;p<3U;p++)if(q->mask&(1U<<p)){
        if(!readers[p])return 0;
        r->read[p]=readers[p];q->probes[p]=(NpFirstSyncProbe){UINT64_MAX,UINT32_MAX,1U,UINT16_MAX,780U};
    }
    for(unsigned a=0U;a<4U;a++)if(aux_mask&(1U<<a)){
        NpFirstSyncAux *s=&q->aux[a];s->id=(uint8_t)(a+1U);s->flags=NP_FIRST_AUX_ENABLED;
        s->release_ms=s->release_cycles=s->first_ms=s->first_cycles=UINT32_MAX;
        s->counter=UINT64_MAX;s->offset_num=INT64_MIN;
    }
    np_cl_source_reset(&r->source,b->source_epoch);
    return np_cl_reset_arm(&r->source.reset,b->session,b->ap_hz,b->mask);
}
/* Feed actual pin readbacks/root arms; do not feed initialized/READY flags.
 * An initial warm-up arm cannot become a final exported-generation proof. */
static inline void np_first_record_arm_observed(NpFirstV1Record *r,uint32_t generation,NpClResetReject reject)
{
    uint32_t admission=r->source.reset.admission;
    np_cl_reset_capture_arm_observed(&r->source.reset,generation,r->source.seeded,reject);
    r->final_generation=admission && r->source.reset.capture_generation==generation?generation:0U;
}
static inline void np_first_record_arm(NpFirstV1Record *r,uint32_t generation)
{np_first_record_arm_observed(r,generation,np_cl_reset_ignore);}
static inline void np_first_record_final_ignore(const NpFirstV1Record *r,const NpClAnchorReceipt *a)
{(void)r;(void)a;}
/* Always pass a valid observer/no-op handle. Failure-only notification precedes
 * destructive close; it must not alter acquisition or the acceptance predicate. */
static inline int np_first_record_final(NpFirstV1Record *r,const NpClAnchorReceipt *a,
                                        NpFirstV1FinalReject reject)
{
    if(!a || r->sealed || !r->final_generation || a->generation!=r->final_generation ||
       a->source_hz!=r->receipt.source_hz || r->source.reset.stage!=NP_CL_RESET_RELEASED ||
       !np_cl_source_seed(&r->source,a)){reject(r,a);np_first_record_close(r);return 0;}
    r->receipt.generation=a->generation;r->receipt.flags|=NP_FIRST_FINAL;
    r->observe=np_first_record_observe;return 1;
}
/* Actual gate release and first observations happen AFTER discovery, never
 * retroactively at the NP byte. Unknown physical conversion phase stays unknown. */
static inline void np_first_record_release(NpFirstV1Record *r,uint32_t ms,uint32_t cycles)
{
    if(!r->live || r->sealed || r->released || ms-r->discovered_ms>=1000U)return;
    r->released=1U;r->release_ms=ms;
    if(!r->receipt.domain)return;
    for(unsigned a=0U;a<4U;a++)if(r->receipt.aux_mask&(1U<<a)){
        NpFirstSyncAux *s=&r->receipt.aux[a];
        if(!(s->flags&NP_FIRST_AUX_RELEASE)){
            s->flags|=NP_FIRST_AUX_RELEASE;s->release_ms=ms;s->release_cycles=cycles;
        }
    }
}
static inline int np_first_record_aux(NpFirstV1Record *r,unsigned id,uint64_t counter,
    uint8_t bits,uint32_t ms,uint32_t cycles,uint32_t rate,int64_t offset,uint32_t denominator)
{
    if(!r->live || r->sealed || !r->released || ms-r->discovered_ms>=1000U ||
       ms-r->release_ms>=0x80000000U || id<1U || id>4U || !(r->receipt.aux_mask&(1U<<(id-1U))) ||
       !bits || bits>64U || (bits<64U && counter>=(UINT64_C(1)<<bits)) ||
       (offset==INT64_MIN?denominator!=0U:
         (offset<0 || !denominator || np_first_gcd((uint64_t)offset,denominator)!=1U)))return 0;
    NpFirstSyncAux *s=&r->receipt.aux[id-1U];
    if(s->flags&NP_FIRST_AUX_COUNTER)return 0;
    s->flags|=NP_FIRST_AUX_COUNTER;s->counter=counter;s->counter_bits=bits;
    s->rate_num=rate;s->rate_den=rate?1U:0U;
    if(r->receipt.domain){s->flags|=NP_FIRST_AUX_POINT;s->stamp_kind=NP_FIRST_STAMP_FOREGROUND;
        s->first_ms=ms;s->first_cycles=cycles;}
    /* A known offset is supplied ONLY with producer-owned pre-origin exclusion
     * proof. Never derive it from foreground arrival or assume physical lock. */
    if(offset!=INT64_MIN){s->offset_num=offset;s->offset_den=denominator;
        s->flags|=NP_FIRST_AUX_OFFSET|NP_FIRST_AUX_EXCLUDED;}
    uint32_t excluded=r->receipt.aux_mask;
    for(unsigned a=0U;a<4U;a++)if(r->receipt.aux[a].flags&NP_FIRST_AUX_EXCLUDED)excluded&=~(1U<<a);
    if(!excluded)r->receipt.flags|=NP_FIRST_AUX_GATED;
    return 1;
}
/* Call only after the first real grid slot is retained in the private queue.
 * This does not assert transport/storage delivery; the host must match the
 * first observed slot. The ISR point is in the existing counter domain; its
 * relative offset remains unknown until the separate bound is qualified. */
static inline int np_first_record_grid_aux(NpFirstV1Record *r,uint64_t ordinal,
    uint32_t ms,uint32_t cycles,uint32_t domain,uint32_t hz,uint32_t generation)
{
    if(!r || !domain || domain!=r->receipt.domain || hz!=r->receipt.counter_hz ||
       !generation || generation!=r->receipt.generation || ordinal==UINT64_MAX)return 0;
    if(!np_first_record_aux(r,NP_FIRST_AUX_IMU,ordinal,64U,ms,cycles,1250U,INT64_MIN,0U))return 0;
    r->receipt.aux[0].stamp_kind=NP_FIRST_STAMP_SOURCE;return 1;
}
/* A retained slot remains useful when its one-time clock point is unknown. */
static inline int np_first_record_grid_unknown(NpFirstV1Record *r,uint64_t ordinal,uint32_t now)
{
    if(!r || !r->live || r->sealed || !r->released || ordinal==UINT64_MAX ||
       now-r->discovered_ms>=1000U || now-r->release_ms>=0x80000000U ||
       !(r->receipt.aux_mask&1U) || (r->receipt.aux[0].flags&NP_FIRST_AUX_COUNTER))return 0;
    NpFirstSyncAux *s=&r->receipt.aux[0];s->flags|=NP_FIRST_AUX_COUNTER;
    s->counter=ordinal;s->counter_bits=64U;s->rate_num=1250U;s->rate_den=1U;
    /* Existing initialized unknown point and offset sentinels remain intact. */
    return 1;
}
/* Off the sample path: call at metadata service, never delay NP publication.
 * Freeze once all enabled first observations are known, or after 1000ms.
 * Stop seals immediately. The transport caches the single packed result. */
static inline int np_first_record_freeze(NpFirstV1Record *r,uint32_t now)
{
    if(r->sealed)return 1;
    if(!r->live)return 0;
    uint32_t pending=r->receipt.aux_mask;
    for(unsigned a=0U;a<4U;a++)if(r->receipt.aux[a].flags&NP_FIRST_AUX_COUNTER)pending&=~(1U<<a);
    if(pending && now-r->discovered_ms<1000U)return 0;
    r->sealed=1U;return 1;
}
static inline void np_first_record_stop(NpFirstV1Record *r)
{np_first_record_close(r);r->sealed=1U;}
static inline int np_first_record_footer(const NpFirstV1Record *r,uint8_t out[NP_FIRST_SYNC_BYTES])
{return r->sealed && np_first_sync_pack(out,&r->receipt);}
#endif
