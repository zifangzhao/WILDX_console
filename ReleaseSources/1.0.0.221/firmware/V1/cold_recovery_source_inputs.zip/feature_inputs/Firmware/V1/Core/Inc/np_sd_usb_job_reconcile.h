#ifndef NP_SD_USB_JOB_RECONCILE_H
#define NP_SD_USB_JOB_RECONCILE_H

#include <stdint.h>
#include "np_sd_usb_job_guard.h"

/* The adapter computes these from fresh, same-card observations; no receipt
 * bit supplied by the host may substitute for them. This policy is called
 * only for a newly submitted ticket, never while acquisition is running. */
enum {
    NP_JOB_FRESH_IDENTITY = 1U << 0,
    NP_JOB_FRESH_WRITABLE_CATALOG = 1U << 1,
    NP_JOB_APPEND_FITS = 1U << 2,
    NP_JOB_SOURCE_QUIET = 1U << 3,
    NP_JOB_SD_QUIET = 1U << 4,
    NP_JOB_CATALOG_CLEAN = 1U << 5,
    NP_JOB_CURRENT_PROFILE = 1U << 6,
    NP_JOB_FRESH_PROOF = (1U << 6) - 1U
};

/* flags=1 is explicit initial user submission; flags=0 is a continuation.
 * terminal_restored_and_lower is true only after device-proven terminal,
 * profile restore and explicit throughput/source-loss evidence. The host
 * separately requires full readback; no unreported host proof is invented.
 * An invalid prior journal is never interpreted as a successful result. */
static inline int np_v1_usb_job_may_replace(unsigned journal_valid,
                                            unsigned phase, uint64_t old_ticket,
                                            uint64_t new_ticket, unsigned flags,
                                            unsigned proof,
                                            unsigned terminal_restored_and_lower)
{
    if (!new_ticket || flags > 1U || (proof & NP_JOB_FRESH_PROOF) != NP_JOB_FRESH_PROOF ||
        (journal_valid && old_ticket && old_ticket == new_ticket)) return 0;
    if (journal_valid && (phase == NP_USB_JOB_QUEUED ||
        phase == NP_USB_JOB_ACCEPTED || phase == NP_USB_JOB_RUNNING)) return 0;
    if (flags == 1U)
        return !journal_valid || phase == NP_USB_JOB_EMPTY || phase == NP_USB_JOB_UNKNOWN;
    return journal_valid && phase == NP_USB_JOB_COMPLETE && terminal_restored_and_lower == 1U;
}
#endif
