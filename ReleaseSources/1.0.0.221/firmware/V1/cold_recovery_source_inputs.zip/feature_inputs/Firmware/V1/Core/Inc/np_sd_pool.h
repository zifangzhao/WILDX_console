#ifndef NP_SD_POOL_H
#define NP_SD_POOL_H
#include <stdint.h>
#include <string.h>
/* Logical FIFO order is independent of physical PSRAM placement. The two
 * internal RUs are separately owned SD bounce buffers, never pool members.
 * overflow is a legacy diagnostic counting allocations beyond physical RU1. */
typedef struct {uint32_t used,peak,overflow;uint8_t physical[16];} NpSdPool;
static inline void np_pool_init(NpSdPool *p){memset(p,0,sizeof(*p));memset(p->physical,255,16);}
static inline int np_pool_acquire_mask(NpSdPool *p,unsigned logical,uint32_t allowed)
{
    if(logical>=16 || p->physical[logical]!=255)return -1;
    for(unsigned i=0;i<16;i++)if((allowed&(1U<<i)) && !(p->used&(1U<<i))) {
        p->used|=1U<<i;p->physical[logical]=(uint8_t)i;if(i>=2)p->overflow++;
        unsigned count=0;for(unsigned n=0;n<16;n++)count+=(p->used>>n)&1U;
        if(count>p->peak)p->peak=count;return (int)i;
    }
    return -1;
}
static inline int np_pool_acquire(NpSdPool *p,unsigned logical)
{return np_pool_acquire_mask(p,logical,0xffffU);}
/* While external backlog exists, leave the internal banks available to drain
 * it. Allocating both to later FIFO entries would deadlock the older head. */
static inline uint32_t np_pool_internal_first_mask(const NpSdPool *p,uint32_t busy)
{return 0xfffcU | ((p->used&0xfffcU)?0U:(~busy&3U));}
static inline int np_pool_release(NpSdPool *p,unsigned logical)
{
    if(logical>=16 || p->physical[logical]>=16)return -1;
    p->used&=~(1U<<p->physical[logical]);p->physical[logical]=255;return 0;
}
#endif
