#ifndef NP_CAPTURE_FIRST_SOURCE_H
#define NP_CAPTURE_FIRST_SOURCE_H
#include <stdint.h>
/* Private startup-only MMIO witness. Not a record/batch/wire layout. */
typedef struct {
    uintptr_t channel;
    uint32_t generation,count,dar,link,link_base,source,ctr1,ctr2,domain;
} NpCaptureFirstSource;
enum { NP_CAPTURE_FIRST_NONE,NP_CAPTURE_FIRST_WAIT,NP_CAPTURE_FIRST_NOT_CLEAN,
       NP_CAPTURE_FIRST_TIMEOUT,NP_CAPTURE_FIRST_BAD_DMA,NP_CAPTURE_FIRST_CHANGED,
       NP_CAPTURE_FIRST_VALID };
#endif
