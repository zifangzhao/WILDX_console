#ifndef NP_CAPTURE_ANCHOR_H
#define NP_CAPTURE_ANCHOR_H
#include "xe_np_acquisition_anchor.h"
typedef struct {
    uint32_t ms,generation,domain,cycles,hz,root_domain,hal_valid;
} NpTimePoint;
/* Read-only optional provider: never enables/resets a counter. */
void NP_CaptureClock_ReadPoint(NpTimePoint *point);
#if NP_FIRST_SYNC_ENABLE && NP_FINE_COUNTER64_ENABLE
void NP_CaptureClock_SelectFine(int enabled);
#endif
void NP_CaptureTimingEnable(int enabled);
int NP_CaptureTimingStartup(uint8_t anchor[64],uint8_t clock[64]);
void NP_CaptureAnchor_Query(uint8_t out[64],uint32_t request_id);
void NP_CaptureClock_Query(uint8_t out[64],uint32_t request_id,int available);
int NP_CaptureAnchor_GetMs(uint32_t *before,uint32_t *after);
int NP_CaptureAnchor_GetExportMs(uint32_t *before,uint32_t *after);
int NP_CaptureAnchor_Prearmed(void);
int NP_CaptureAnchor_Unpublished(void);
#endif
