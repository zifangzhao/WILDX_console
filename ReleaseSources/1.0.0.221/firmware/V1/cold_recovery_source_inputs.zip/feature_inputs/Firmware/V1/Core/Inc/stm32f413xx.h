#ifndef XE_NP_STM32F413XX_COMPAT_H
#define XE_NP_STM32F413XX_COMPAT_H

#include "stm32u595xx.h"

#endif
