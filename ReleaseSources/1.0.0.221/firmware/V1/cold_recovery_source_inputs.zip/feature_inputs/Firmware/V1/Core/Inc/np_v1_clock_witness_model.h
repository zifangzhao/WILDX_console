#ifndef NP_V1_CLOCK_WITNESS_MODEL_H
#define NP_V1_CLOCK_WITNESS_MODEL_H

/* Offline-only model. Not connected to RCC, an IRQ, capture or wire format.
 * The future owner supplies serialized observations; this model does not
 * acquire interrupt/flag ownership, clear flags, enable CSS or read clocks. */
#ifndef NP_V1_CLOCK_WITNESS_MODEL
#define NP_V1_CLOCK_WITNESS_MODEL 0
#endif

#if NP_V1_CLOCK_WITNESS_MODEL
#include <stdint.h>

#define NP_CLOCK_WITNESS_HSE_READY (1U << 0)
#define NP_CLOCK_WITNESS_PLL_READY (1U << 1)
#define NP_CLOCK_WITNESS_REQUIRED (NP_CLOCK_WITNESS_HSE_READY|NP_CLOCK_WITNESS_PLL_READY)
#define NP_CLOCK_WITNESS_READY_MISSING (1U << 0)
#define NP_CLOCK_WITNESS_CONFIG_CHANGED (1U << 1)
#define NP_CLOCK_WITNESS_FLAG_NEWLY_SET (1U << 2)
#define NP_CLOCK_WITNESS_UNAVAILABLE 0U
#define NP_CLOCK_WITNESS_ENDPOINTS_ONLY 1U
#define NP_CLOCK_WITNESS_SAMPLED_ANOMALY 2U
#define NP_CLOCK_WITNESS_OPEN 0U
#define NP_CLOCK_WITNESS_CLOSED 1U
#define NP_CLOCK_WITNESS_ABORTED 2U

typedef struct {
    uint32_t ready, config_matches, raw_flags;
} NpClockWitnessObservation;

typedef struct {
    uint32_t epoch, active, baseline_flags, flags_seen, observed, samples, close_reason;
} NpClockWitnessModel;

/* This status concerns supplied snapshots only; none qualifies continuity,
 * phase, a covered prefix or hardware interrupt/flag ownership. */
static inline uint32_t np_clock_witness_status(const NpClockWitnessModel *w)
{
    if(!w || !w->samples)return NP_CLOCK_WITNESS_UNAVAILABLE;
    if(w->observed&(NP_CLOCK_WITNESS_READY_MISSING|NP_CLOCK_WITNESS_CONFIG_CHANGED))
        return NP_CLOCK_WITNESS_SAMPLED_ANOMALY;
    return NP_CLOCK_WITNESS_ENDPOINTS_ONLY;
}

/* Zero-initialize once; epochs increase strictly and cannot wrap within this
 * model lifetime. One serialized foreground owner prevents lifecycle races.
 * raw_flags are unqualified register bits: even a newly set bit is not an
 * independently identified clock fault. A clear bit proves no interval. */
static inline int np_clock_witness_begin(NpClockWitnessModel *w,uint32_t epoch,
                                         const NpClockWitnessObservation *o)
{
    if(!w || !epoch || !o || w->active || epoch<=w->epoch)return 0;
    w->epoch=epoch;w->active=1U;w->baseline_flags=o->raw_flags;
    w->flags_seen=0U;w->observed=0U;w->samples=1U;w->close_reason=NP_CLOCK_WITNESS_OPEN;
    if((o->ready&NP_CLOCK_WITNESS_REQUIRED)!=NP_CLOCK_WITNESS_REQUIRED)
        w->observed|=NP_CLOCK_WITNESS_READY_MISSING;
    if(!o->config_matches)w->observed|=NP_CLOCK_WITNESS_CONFIG_CHANGED;
    return 1;
}
static inline int np_clock_witness_observe(NpClockWitnessModel *w,uint32_t epoch,
                                           const NpClockWitnessObservation *o)
{
    uint32_t newly_set;
    if(!w || !o || !w->active || w->epoch!=epoch)return 0;
    if((o->ready&NP_CLOCK_WITNESS_REQUIRED)!=NP_CLOCK_WITNESS_REQUIRED)
        w->observed|=NP_CLOCK_WITNESS_READY_MISSING;
    if(!o->config_matches)w->observed|=NP_CLOCK_WITNESS_CONFIG_CHANGED;
    newly_set=o->raw_flags&~w->baseline_flags;
    w->flags_seen|=newly_set;
    if(newly_set)w->observed|=NP_CLOCK_WITNESS_FLAG_NEWLY_SET;
    if(w->samples!=UINT32_MAX)w->samples++;
    return 1;
}
/* Caller-supplied lifecycle classification only: neither outcome establishes
 * physical source stop, terminal coverage or a clock-health interval. */
static inline int np_clock_witness_end(NpClockWitnessModel *w,uint32_t epoch,uint32_t reason)
{
    if(!w || !w->active || w->epoch!=epoch ||
       (reason!=NP_CLOCK_WITNESS_CLOSED && reason!=NP_CLOCK_WITNESS_ABORTED))return 0;
    w->active=0U;w->close_reason=reason;return 1;
}
#endif
#endif
