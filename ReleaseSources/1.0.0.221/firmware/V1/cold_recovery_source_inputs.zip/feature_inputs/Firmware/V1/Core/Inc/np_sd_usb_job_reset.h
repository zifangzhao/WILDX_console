#ifndef NP_SD_USB_JOB_RESET_H
#define NP_SD_USB_JOB_RESET_H

#include <stdint.h>

/* BKP11..13 hold the one-shot magic and ticket. BKP14..15 independently
 * protect the staged profile and must never be overwritten here. The ticket
 * is compared against the CRC-checked retained journal before use. */
#define NP_V1_JOB_RESET_MAGIC UINT32_C(0x3152534e)

static inline int np_v1_job_reset_seal(volatile uint32_t *word, uint64_t ticket,
                                       void (*barrier)(void))
{
    uint32_t lo = (uint32_t)ticket, hi = (uint32_t)(ticket >> 32U);
    if (!word || !ticket || !barrier) return 0;
    word[0] = 0U; barrier();
    /* Preserve the CRC-bound profile snapshot: only the ticket already
     * committed by profile_stage may acquire one-shot authority. */
    if (word[1] != lo || word[2] != hi) return 0;
    word[0] = NP_V1_JOB_RESET_MAGIC; barrier();
    if (word[0] == NP_V1_JOB_RESET_MAGIC && word[1] == lo && word[2] == hi) return 1;
    word[0] = 0U; barrier(); return 0;
}

/* Always consume the cookie before returning, including mismatches. The
 * caller supplies the captured reset flags and platform masks; conflicting
 * reset sources, zero masks and missing software-reset flags fail closed. */
static inline int np_v1_job_reset_consume(volatile uint32_t *word, uint64_t ticket,
                                          uint32_t flags, uint32_t software_mask,
                                          uint32_t conflicting_mask,
                                          void (*barrier)(void))
{
    uint32_t magic, lo, hi;
    if (!word || !barrier) return 0;
    magic = word[0]; lo = word[1]; hi = word[2];
    word[0] = 0U; barrier();
    return ticket && software_mask && conflicting_mask && !(software_mask & conflicting_mask) &&
           (flags & software_mask) == software_mask && !(flags & conflicting_mask) &&
           magic == NP_V1_JOB_RESET_MAGIC && lo == (uint32_t)ticket &&
           hi == (uint32_t)(ticket >> 32U);
}
#endif
