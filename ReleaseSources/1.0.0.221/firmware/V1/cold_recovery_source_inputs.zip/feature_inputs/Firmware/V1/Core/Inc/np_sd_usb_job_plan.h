#ifndef NP_SD_USB_JOB_PLAN_H
#define NP_SD_USB_JOB_PLAN_H

#include "np_usb_sd_test.h"
#include "np_first_sync_sd.h"
#include "np_sd_rate_plan.h"

/* All inputs are cached foreground snapshots. The caller must establish that
 * identity and frontier came from the same fresh, idle card initialization;
 * this function neither touches the card nor admits a recorder command. */
typedef struct {
    uint32_t uid[3], cid[4], capacity, frontier;
    uint32_t fresh, idle, writable;
} NpV1UsbSdJobIdentity;

static inline int np_v1_usb_sd_job_plan(const uint8_t request[128],
                                        const NpV1UsbSdJobIdentity *card,
                                        uint64_t last_ticket)
{
    NpUsbSdTestPlan plan;
    uint8_t legacy[64];
    uint32_t mask, hz, start, end, session, options;
    uint64_t payload, bytes, expected_end;
    if (!request || !card || !card->fresh || !card->idle || !card->writable ||
        !np_usb_sd_plan_decode(&plan, request, 128U) || !plan.ticket ||
        plan.ticket == last_ticket || memcmp(plan.uid, card->uid, sizeof(plan.uid)) ||
        memcmp(plan.cid, card->cid, sizeof(plan.cid)) || plan.capacity != card->capacity ||
        plan.expected_frontier != card->frontier || !card->capacity ||
        !(card->cid[0] | card->cid[1] | card->cid[2] | card->cid[3]) ||
        (card->cid[0] & card->cid[1] & card->cid[2] & card->cid[3]) == UINT32_MAX ||
        card->frontier < 8192U || card->frontier >= card->capacity ||
        np_first_u64(plan.npsd + 24U) != plan.ticket ||
        np_first_u16(plan.npsd + 6U) != NP_FIRST_SD_START ||
        !np_first_sd_fine_counter64_unwrap(legacy, plan.npsd, 1U, card->uid)) return 0;
    mask = np_first_u32(legacy + 16U); hz = np_first_u32(legacy + 20U);
    start = np_first_u32(legacy + 24U); end = np_first_u32(legacy + 28U);
    session = np_first_u32(legacy + 32U); options = np_first_u32(legacy + 36U);
    if (!mask || !np_sd_rate_valid(mask, hz)) return 0;
    payload = (uint64_t)card->frontier + 8192U;
    payload += (0U - (uint32_t)payload) & 16383U;
    bytes = (uint64_t)plan.seconds * hz * 832U * np_sd_rate_count(mask);
    expected_end = payload + ((bytes + 8388607U) / 8388608U) * 16384U;
    return (!start || start == card->frontier) &&
        expected_end <= card->capacity && end == expected_end && end > card->frontier &&
        session && !(options & ~1U) && !np_first_u32(legacy + 40U) &&
        np_first_zero(legacy + 44U, 16U);
}
#endif
