#ifndef XE_NP_BLE_RESCUE_H
#define XE_NP_BLE_RESCUE_H
#include <stdint.h>
/* Queue-independent CE32 frame boundary tracker. Unlike searching for four
 * reset bytes, this masks every known binary payload, not just B8/B9. Supply
 * command_bytes (command + payload) only when at == 1. No payload copy/CRC. */
typedef struct {uint32_t at,remaining,last_ms;uint8_t command,argument;} XE_NP_BleRescue;
static inline int XE_NP_BleRescue_Feed(XE_NP_BleRescue *p,uint8_t b,
    uint32_t now,uint32_t command_bytes)
{
    if(now-p->last_ms>250U)p->at=0;
    p->last_ms=now;
    if(!p->at){if(b==0x3cU)p->at=1;return 0;}
    if(p->at==1){
        if(!command_bytes){p->at=b==0x3cU?1U:0U;return 0;}
        p->command=b;p->argument=0;p->remaining=command_bytes-1U;p->at=2;return 0;
    }
    if(p->remaining){p->argument=b;p->remaining--;return 0;}
    p->at=0;
    return b==0x3eU && p->command==0xabU && p->argument==0xbaU;
}
#endif
