#ifndef NP_SD_USB_JOB_JOURNAL_H
#define NP_SD_USB_JOB_JOURNAL_H

#include "np_usb_sd_test.h"

/* A single 512-byte lifecycle journal, not a capture buffer. The caller must
 * prove the region is owned, accessible and ECC-initialized before calling;
 * absent/torn commit is UNKNOWN, not permission to run a job. */
#define NP_V1_JOB_JOURNAL_MAGIC UINT32_C(0x314a534e)
#define NP_V1_JOB_JOURNAL_WORDS 128U
/* The profile snapshot occupies previously reserved journal words. It is
 * separately committed by the profile marker before any profile is changed. */
#define NP_V1_JOB_PROFILE_WORD_OFFSET 100U

static inline uint32_t np_v1_job_journal_crc(const volatile uint32_t *word)
{
    uint32_t crc = UINT32_MAX;
    uint8_t b[4];
    for (unsigned i = 1U; i < 127U; ++i) {
        np_usb_sd_put32(b, word[i]);
        crc = np_usb_sd_crc_update(crc, b, 4U);
    }
    return crc ^ UINT32_MAX;
}

static inline int np_v1_job_journal_reseal(volatile uint32_t *word, void (*barrier)(void))
{
    if (!word || !barrier || word[0] != NP_V1_JOB_JOURNAL_MAGIC ||
        word[1] != ~NP_V1_JOB_JOURNAL_MAGIC || word[2] != 1U) return 0;
    word[0] = 0U; barrier();
    word[127] = np_v1_job_journal_crc(word); barrier();
    word[0] = NP_V1_JOB_JOURNAL_MAGIC; barrier();
    return word[127] == np_v1_job_journal_crc(word);
}

/* No output is published unless both wire records and their binding validate. */
static inline int np_v1_job_journal_read(const volatile uint32_t *word,
                                         uint8_t plan[128], uint8_t report[256])
{
    uint8_t p[128], r[256];
    NpUsbSdTestPlan decoded;
    NpUsbSdTestReport status;
    if (!word || !plan || !report || word[0] != NP_V1_JOB_JOURNAL_MAGIC ||
        word[1] != ~NP_V1_JOB_JOURNAL_MAGIC || word[2] != 1U ||
        word[127] != np_v1_job_journal_crc(word)) return 0;
    for (unsigned i = 0; i < 32U; ++i) np_usb_sd_put32(p + i*4U, word[4U+i]);
    for (unsigned i = 0; i < 64U; ++i) np_usb_sd_put32(r + i*4U, word[36U+i]);
    if (!np_usb_sd_plan_decode(&decoded, p, sizeof(p)) || !decoded.ticket ||
        !np_usb_sd_report_decode(&status, r, sizeof(r)) ||
        word[3] != status.words[4] || status.words[12] != 1U ||
        ((uint64_t)status.words[9] << 32U | status.words[8]) != decoded.ticket ||
        status.words[10] != np_usb_sd_u32(p+60U) ||
        status.words[17] != decoded.uid[0] || status.words[18] != decoded.uid[1] ||
        status.words[19] != decoded.uid[2]) return 0;
    memcpy(plan, p, sizeof(p)); memcpy(report, r, sizeof(r)); return 1;
}

/* Caller owns and serializes the journal, and must supply a real hardware
 * barrier. It decides separately whether overwriting an old ticket is legal. */
static inline int np_v1_job_journal_write(volatile uint32_t *word,
                                          const uint8_t plan[128],
                                          const uint8_t report[256],
                                          void (*barrier)(void))
{
    uint8_t check_plan[128], check_report[256];
    NpUsbSdTestPlan decoded;
    NpUsbSdTestReport status;
    if (!word || !plan || !report || !barrier ||
        !np_usb_sd_plan_decode(&decoded, plan, 128U) || !decoded.ticket ||
        !np_usb_sd_report_decode(&status, report, 256U) || status.words[12] != 1U ||
        ((uint64_t)status.words[9] << 32U | status.words[8]) != decoded.ticket ||
        status.words[10] != np_usb_sd_u32(plan+60U) ||
        status.words[17] != decoded.uid[0] || status.words[18] != decoded.uid[1] ||
        status.words[19] != decoded.uid[2]) return 0;
    word[0] = 0U; barrier();
    word[1] = ~NP_V1_JOB_JOURNAL_MAGIC; word[2] = 1U; word[3] = status.words[4];
    for (unsigned i = 0; i < 32U; ++i) word[4U+i] = np_usb_sd_u32(plan+i*4U);
    for (unsigned i = 0; i < 64U; ++i) word[36U+i] = np_usb_sd_u32(report+i*4U);
    for (unsigned i = 100U; i < 127U; ++i) word[i] = 0U;
    word[127] = np_v1_job_journal_crc(word); barrier();
    word[0] = NP_V1_JOB_JOURNAL_MAGIC; barrier();
    if (np_v1_job_journal_read(word, check_plan, check_report) &&
        !memcmp(plan, check_plan, 128U) && !memcmp(report, check_report, 256U)) return 1;
    word[0] = 0U; barrier(); return 0;
}
#endif
