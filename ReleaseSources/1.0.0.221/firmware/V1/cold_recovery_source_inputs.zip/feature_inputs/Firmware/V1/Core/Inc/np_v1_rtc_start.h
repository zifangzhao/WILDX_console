#ifndef NP_V1_RTC_START_H
#define NP_V1_RTC_START_H
#include "np_v1_rtc.h"
#include "np_rtc_start_wire.h"

/* Startup/control boundaries only. The optional cache never gates capture.
 * Begin drops the previous session; Crossstamp attempts once. Freeze needs an
 * independently valid final receipt/anchor and is immutable until next Begin. */
void NP_V1RtcStartBegin(int enabled);
void NP_V1RtcStartCrossstamp(void);
int NP_V1RtcStartFreeze(const NpRtcStartBinding *binding);
int NP_V1RtcStartRead(uint8_t out[128],const NpRtcStartBinding *binding);
#endif
