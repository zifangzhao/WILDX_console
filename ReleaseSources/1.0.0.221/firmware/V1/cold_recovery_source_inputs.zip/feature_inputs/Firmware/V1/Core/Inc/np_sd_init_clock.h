#ifndef NP_SD_INIT_CLOCK_H
#define NP_SD_INIT_CLOCK_H
#include <stdint.h>

/* Default-speed initialization, before CMD6 tuning. A zero kernel is an
 * unavailable clock, never permission to bypass the divider. CLKDIV=0 is
 * bypass; nonzero divisors generate kernel/(2*CLKDIV). */
static inline int np_sd_initial_divider(uint32_t kernel_hz,uint32_t *divider)
{
    const uint32_t limit_hz=25000000U;
    if(!kernel_hz || !divider)return -1;
    *divider=kernel_hz<=limit_hz?0U:
        (kernel_hz-1U)/(2U*limit_hz)+1U;
    return 0;
}
#endif
