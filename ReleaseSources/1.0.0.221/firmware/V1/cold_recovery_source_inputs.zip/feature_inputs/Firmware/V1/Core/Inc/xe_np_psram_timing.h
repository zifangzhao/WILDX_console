#ifndef XE_NP_PSRAM_TIMING_H
#define XE_NP_PSRAM_TIMING_H

/* Shared APS6404 timing rules for V1 and V2. These do not authorize a clock
 * above either device's electrical rating. No hardware access or hot-path work.
 * Preserve the historical minimum dividers at lower clocks. */
#define XE_NP_PSRAM_SLOW_DIV_FOR(hz) \
    ((((hz) + 32999999ULL) / 33000000ULL) < 5ULL ? 5ULL : \
     (((hz) + 32999999ULL) / 33000000ULL))
#define XE_NP_PSRAM_CSHT_FOR(hz) \
    ((((hz) * 18ULL + 999999999ULL) / 1000000000ULL) < 3ULL ? 3ULL : \
     (((hz) * 18ULL + 999999999ULL) / 1000000000ULL))
#define XE_NP_PSRAM_REFRESH_FOR(hz) ((hz) / 400000UL - 1UL)

#endif
