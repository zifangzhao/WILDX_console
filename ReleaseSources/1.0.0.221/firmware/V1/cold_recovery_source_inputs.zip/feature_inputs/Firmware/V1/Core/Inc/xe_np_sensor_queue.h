#ifndef XE_NP_SENSOR_QUEUE_H
#define XE_NP_SENSOR_QUEUE_H
#include "xe_np_sensors.h"
#include <string.h>
/* Foreground-only publication queue, not the BMX hardware FIFO. */
typedef struct {
    uint32_t count,peak,pushed,popped,overflow,last_sequence,have_sequence,head,tail,active;
    XE_NP_SensorSnapshot last,items[16];
} XE_NP_SensorQueue;
static inline int xe_np_sensor_queue_push(XE_NP_SensorQueue *q,const XE_NP_SensorSnapshot *s)
{
    if(!q->active || !(s->valid&XE_NP_SENSOR_VALID_AG) ||
       (q->have_sequence&&q->last_sequence==s->imu_sequence))return 0;
    if(q->count==16){q->overflow++;return -1;}
    q->items[q->tail]=*s;q->tail=(q->tail+1U)&15U;q->count++;q->pushed++;
    if(q->count>q->peak)q->peak=q->count;
    q->last_sequence=s->imu_sequence;q->have_sequence=1;return 0;
}
static inline void xe_np_sensor_queue_begin(XE_NP_SensorQueue *q,const XE_NP_SensorSnapshot *s)
{memset(q,0,sizeof(*q));q->active=1;q->last=*s;(void)xe_np_sensor_queue_push(q,s);}
static inline const XE_NP_SensorSnapshot *xe_np_sensor_queue_pop(XE_NP_SensorQueue *q)
{
    if(q->count){q->last=q->items[q->head];q->head=(q->head+1U)&15U;q->count--;q->popped++;}
    return &q->last;
}
/* One CE64 sensor record accompanies each 64 KiB neural chunk. At low NP
 * rates there are fewer chunk slots than 200 Hz IMU publications, so ordered
 * one-at-a-time popping necessarily overflows. The wire contract is latest
 * values, not a lossless IMU FIFO: consume the newest foreground snapshot in
 * O(1), retire older queued publications, and expose the sequence gap. */
static inline const XE_NP_SensorSnapshot *xe_np_sensor_queue_take_latest(
    XE_NP_SensorQueue *q,const XE_NP_SensorSnapshot *latest)
{
    q->popped+=q->count;q->count=0;q->head=q->tail;
    q->last=*latest;
    if(latest->valid&XE_NP_SENSOR_VALID_AG){q->last_sequence=latest->imu_sequence;q->have_sequence=1;}
    return &q->last;
}
#endif
