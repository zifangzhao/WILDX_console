#ifndef NP_PREPARATION_PORT_H
#define NP_PREPARATION_PORT_H
#include "np_preparation_wire.h"
#include "np_v1_rtc_port.h"
/* V1 private detail codes, not new shared result/state values. */
enum { NP_PREP_CHANGED=1U, NP_PREP_RESET=2U, NP_PREP_PROBE=3U,
       NP_PREP_OWNERSHIP=4U, NP_PREP_READBACK=5U, NP_PREP_DISCONNECT=6U,
       NP_PREP_CANCELED=7U, NP_PREP_EXHAUSTED=8U };
int NP_PreparationControl(uint32_t owner,const uint8_t[64],uint8_t[64]);
void NP_PreparationInvalidate(uint32_t detail);
void NP_PreparationDisconnect(uint32_t owner);
void NP_PreparationStop(void); /* Explicit STOP also retires stopped preparation. */
void NP_PreparationFailed(void);
int NP_PreparationService(void);
int NP_PreparationBoundary(void);
int NP_PreparationFast(void);
int NP_PreparationTake(uint32_t mode);
int NP_PreparationHold(void);
int NP_PreparationClockFrozen(void); /* Read-only; never performs Hold/cleanup. */
/* Implemented by the resident personality; ignore the current NPPC mailbox
 * itself, but reject recording/drain, mode, storage and producer ownership. */
unsigned NP_PreparationPortMode(void);
int NP_PreparationPortBusy(void);
#endif
