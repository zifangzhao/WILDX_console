#ifndef NP_V1_RTC_H
#define NP_V1_RTC_H
#include <stdint.h>
#ifndef NP_HARDWARE_RTC_ENABLE
#define NP_HARDWARE_RTC_ENABLE 0
#endif
#define NP_V1_RTC_HARDWARE 1U
#define NP_V1_RTC_CALENDAR 2U
#define NP_V1_RTC_CALIBRATED 4U
#define NP_V1_RTC_QUANTUM_US 100U
#define NP_V1_RTC_INPUT_HZ 750000U
#define NP_V1_RTC_COMMIT_REJECTED 0
#define NP_V1_RTC_COMMIT_COMPLETE 1
#define NP_V1_RTC_COMMIT_PENDING 2
#define NP_V1_RTC_COMMIT_FAILED (-1)
typedef struct {
    uint64_t lower_us,upper_us; /* Upper is the exclusive100us quantum edge. */
    uint32_t flags,generation,declared_pc_uncertainty_us,set_residual_bound_us;
    uint32_t tr,dr,ssr,calr;
    uint32_t asynchronous,synchronous,input_hz;
} NpV1RtcPoint;
typedef struct {
    uint64_t counter;
    uint32_t domain,hz,cookie; /* Actual owned clock lifetime, NOT NP context. */
} NpV1RtcCounter;
typedef int (*NpV1RtcCounterRead)(NpV1RtcCounter *);
typedef struct {
    NpV1RtcPoint rtc;
    NpV1RtcCounter before,after;
} NpV1RtcBridge;
/* Foreground lifecycle/control only. Default is frozen/no-op. No API touches
 * a backup word, resets the backup domain, or changes an oscillator. */
void NP_V1Rtc_SelectIdle(int idle);
int NP_V1Rtc_InitIdle(void);
void NP_V1Rtc_Invalidate(void); /* Before reset/reclock/handoff; trust is RAM. */
int NP_V1Rtc_Read(NpV1RtcPoint *out);
/* Idle foreground only: observe an already accepted adjustment without
 * writing/replaying it. Returns nonzero only while confirmation is pending. */
int NP_V1Rtc_ServicePending(void);
/* One start-boundary diagnostic snapshot only; no coherence/UTC qualification.
 * Caller caches it for a typed unknown record, never rereads it at Stop. */
int NP_V1Rtc_Diagnostic(NpV1RtcPoint *out);
uint32_t NP_V1Rtc_Generation(void); /* Retained even while pending/uncalibrated. */
/* Accepted phase writes require an observed SHPF assertion then clear; a
 * missed pulse, deadline or freeze stays uncalibrated, with no write replay. */
int NP_V1Rtc_Commit(uint64_t utc_us,uint32_t reference_ms,
    uint32_t declared_uncertainty_us,uint32_t expected_generation);
/* Bind once at the owned counter lifecycle. Never pass an unproven synthetic
 * counter; public sensor Read64 deliberately remains final-root-only. */
void NP_V1Rtc_BindCounter(NpV1RtcCounterRead reader);
int NP_V1Rtc_Crossstamp(NpV1RtcBridge *out);
/* Exact held provider-owned snapshot + live lifetime checks, not a license to
 * qualify caller-constructed calendar/counter fields. Final NP binding is separate. */
int NP_V1Rtc_BridgeCurrent(const NpV1RtcBridge *bridge);
int NP_V1Rtc_BridgeHeld(NpV1RtcBridge *out); /* Private snapshot, checked at final binding. */
#endif
