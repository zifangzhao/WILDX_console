#ifndef NP_USB20_PHASE1_TEST_H
#define NP_USB20_PHASE1_TEST_H

/* Explicit USB-only experiment; never included by the normal SD/BLE build. */
#include "np_usb20_release.h"
#if NP_USB20_CORE_HZ != 124800000U || NP_USB20_EDGE != 0U || NP_USB20_DELAY_TICKS != 2U
#error "Phase1 test requires the unchanged USB89 native20 profile"
#endif
#undef NP_USB20_DELAY_TICKS
#define NP_USB20_DELAY_TICKS 1U

#endif
