#ifndef NP_USB_GRID_CONTROL_H
#define NP_USB_GRID_CONTROL_H

#include <stddef.h>
#include <stdint.h>
#include <string.h>

/* Version 2 is an explicit producer contract, never a legacy diagnostic opt-in. */
#ifndef NP_SENSOR_GRID_ENFORCED
#define NP_SENSOR_GRID_ENFORCED 0
#endif
#define NP_USB_GRID_VERSION (NP_SENSOR_GRID_ENFORCED?2U:1U)

/* Pure EP0 admission/receipt helper. The USB owner supplies readiness and
 * quiescence; this does not allocate a request number or install a router. */
#define NP_USB_GRID_REQUEST 0x81U
#define NP_USB_GRID_STATUS_BYTES 32U
enum { NP_USB_GRID_UNHANDLED = 0, NP_USB_GRID_STALL = -1,
       NP_USB_GRID_STATUS = 1, NP_USB_GRID_ACK = 2 };
typedef struct {
    uint8_t pending;          /* USB-owned selection for the next capture */
    uint8_t frozen;           /* capture lifecycle currently owns a choice */
    uint8_t capture_selected; /* immutable until capture end */
} NpUsbGridControl;

static inline void np_usb_grid_put32(uint8_t *p, uint32_t x)
{ p[0]=(uint8_t)x; p[1]=(uint8_t)(x>>8); p[2]=(uint8_t)(x>>16); p[3]=(uint8_t)(x>>24); }
static inline uint32_t np_usb_grid_crc32(const uint8_t *p, size_t n)
{
    uint32_t c=UINT32_MAX;
    while(n--) {
        c^=*p++;
        for(unsigned i=0;i<8U;i++) c=(c>>1)^((0U-(c&1U))&UINT32_C(0xedb88320));
    }
    return ~c;
}
/* Disconnect/reset revoke only the next USB-owned selection. They do not
 * change a frozen capture or any separate BLE/SD-owned state. */
static inline void np_usb_grid_bus_reset(NpUsbGridControl *s)
{ if(s) s->pending=0U; }
/* A selected grid must never silently degrade to legacy at capture start. */
static inline int np_usb_grid_capture_begin(NpUsbGridControl *s, int ready)
{
    if(!s || s->frozen || (s->pending && !ready)) return 0;
    s->capture_selected=s->pending;
    s->frozen=1U;
    return 1;
}
static inline void np_usb_grid_capture_end(NpUsbGridControl *s)
{ if(s) {s->frozen=0U; s->capture_selected=0U;} }
static inline int np_usb_grid_capture_selected(const NpUsbGridControl *s)
{ return s && s->frozen && s->capture_selected; }

/* Status: NSGC, LE uint32 version, flags, UID[3], revision, CRC32 of
 * bytes 0..27. While frozen selected reports the effective capture choice;
 * otherwise it reports the USB owner's pending choice. A supported flag is
 * never inferred: caller must attest the actual producer and consumer path.
 * OUT ACK is not proof of state; the host must follow with a validated IN. */
static inline int np_usb_grid_request(NpUsbGridControl *s, uint8_t type,
    uint8_t request, uint16_t value, uint16_t index, uint16_t length,
    int ready, int idle, const uint32_t uid[3], uint32_t revision,
    uint8_t status[NP_USB_GRID_STATUS_BYTES])
{
    if(request!=NP_USB_GRID_REQUEST) return NP_USB_GRID_UNHANDLED;
    if(!s || !uid) return NP_USB_GRID_STALL;
    if(type==0xc0U && value==0U && index==0U && length==NP_USB_GRID_STATUS_BYTES && status) {
        uint32_t selected=s->frozen?s->capture_selected:s->pending;
        uint32_t flags=(ready?1U:0U)|(selected?2U:0U)|(s->frozen?4U:0U);
        memcpy(status,"NSGC",4U);
        np_usb_grid_put32(status+4U,NP_USB_GRID_VERSION); np_usb_grid_put32(status+8U,flags);
        for(unsigned i=0;i<3U;i++) np_usb_grid_put32(status+12U+4U*i,uid[i]);
        np_usb_grid_put32(status+24U,revision);
        np_usb_grid_put32(status+28U,np_usb_grid_crc32(status,28U));
        return NP_USB_GRID_STATUS;
    }
    if(type==0x40U && value<=1U && index==0U && length==0U &&
       idle && !s->frozen && (!value || ready)) {
        s->pending=(uint8_t)value;
        return NP_USB_GRID_ACK;
    }
    return NP_USB_GRID_STALL;
}
#endif
