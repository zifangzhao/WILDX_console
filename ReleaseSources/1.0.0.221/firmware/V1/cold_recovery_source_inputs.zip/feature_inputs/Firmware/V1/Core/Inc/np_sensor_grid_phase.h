#ifndef NP_SENSOR_GRID_PHASE_H
#define NP_SENSOR_GRID_PHASE_H
#include <stdint.h>

/* A one-time bound on the first accepted slot relative to NP STARTBYTE,
 * expressed as [low_num,high_num]/den source ticks. Inputs must already
 * belong to the same continuous HSE-derived counter domain. Neither the ISR
 * arrival point nor the root bracket alone is an exact physical edge. */
typedef struct {uint64_t low_num,high_num;uint32_t den;} NpGridPhaseBounds;
/* Actual successful-copy bracket. The final counter read is quantized to one
 * tick; root_after already includes its producer's read quantization guard. */
static inline int np_grid_phase_copy_bounds(NpGridPhaseBounds *out,uint64_t before,
    uint64_t after,uint64_t root_before,uint64_t root_after,uint64_t np_start_ticks,
    uint32_t source_hz,uint32_t counter_hz)
{
    if(!out || !source_hz || !counter_hz || before>after || after==UINT64_MAX ||
       root_after<root_before || before<root_after || np_start_ticks>UINT64_MAX/counter_hz)return 0;
    uint64_t lo=before-root_after,hi=after+1U-root_before;
    if(lo>UINT64_MAX/source_hz || hi>UINT64_MAX/source_hz)return 0;
    lo*=source_hz;hi*=source_hz;
    uint64_t ref=np_start_ticks*counter_hz;
    if(lo<ref)return 0;
    out->low_num=lo-ref;out->high_num=hi-ref;out->den=counter_hz;return 1;
}
static inline int np_grid_phase_bounds(NpGridPhaseBounds *out,uint64_t arrival,
    uint32_t latency_bound,uint64_t root_before,uint64_t root_after,
    uint64_t np_start_ticks,uint32_t source_hz,uint32_t counter_hz)
{
    if(!out || !source_hz || !counter_hz || root_after<root_before ||
       arrival<latency_bound || arrival-latency_bound<root_after ||
       np_start_ticks>UINT64_MAX/counter_hz)return 0;
    uint64_t lo=arrival-latency_bound-root_after,hi=arrival-root_before;
    if(lo>UINT64_MAX/source_hz || hi>UINT64_MAX/source_hz)return 0;
    lo*=source_hz;hi*=source_hz;
    uint64_t ref=np_start_ticks*counter_hz;
    /* If the interval crosses NP T0, pre-origin exclusion is not proven. */
    if(lo<ref)return 0;
    out->low_num=lo-ref;out->high_num=hi-ref;out->den=counter_hz;return 1;
}
#endif
