#ifndef NP_CATALOG_PRESERVE_H
#define NP_CATALOG_PRESERVE_H
#include <stdint.h>
#include <string.h>
#include "np_sd_fast_crc.h"

/* Pure read-only inspection plans. A planner has no write callback. */
enum {NPCR_OK=0,NPCR_BAD_REQUEST=1,NPCR_BUSY=2,NPCR_NONCE=3,
      NPCR_IDENTITY=4,NPCR_IO=5,NPCR_CATALOG=6,NPCR_CANCELLED=7,NPCR_CLOCK=8};
enum {NPCR_FS1=1U,NPCR_FS2=2U,NPCR_FULL=0x10000U,
      NPCR_RECOVERY=0x20000U,NPCR_RECOVERABLE=0x40000U,NPCR_DEGRADED=0x800000U};
#define NPCR_MAX_WRITES 2U
typedef int (*NpcrRead)(void *,uint32_t,uint8_t *);
typedef struct {void *context;NpcrRead read;} NpcrReadIo;
typedef struct {uint32_t lba;uint8_t before[512],after[512];} NpcrWrite;
typedef struct {
    uint32_t layout,flags,next_lba,count,fingerprint,reads,writes;
    uint64_t format_epoch,generation;
    NpcrWrite change[NPCR_MAX_WRITES];
} NpcrPlan;
static inline int npcr_read(const NpcrReadIo *io,NpcrPlan *p,uint32_t lba,uint8_t b[512])
{
    if(!io || !io->read)return NPCR_IO;
    int error=io->read(io->context,lba,b);
    if(error)return error>0 && error<=NPCR_CLOCK?error:NPCR_IO;
    p->fingerprint=(p->fingerprint<<7)|(p->fingerprint>>25);
    p->fingerprint^=np_sd_metadata_crc_fast(b,512)^lba;p->reads++;
    return NPCR_OK;
}
static inline int npcr_change(NpcrPlan *p,uint32_t lba,const uint8_t before[512],const uint8_t after[512])
{
    if(!memcmp(before,after,512))return NPCR_OK;
    if(p->writes>=NPCR_MAX_WRITES)return NPCR_CATALOG;
    NpcrWrite *w=&p->change[p->writes++];w->lba=lba;
    memcpy(w->before,before,512);memcpy(w->after,after,512);
    p->flags|=NPCR_RECOVERY|NPCR_RECOVERABLE;return NPCR_OK;
}
/* Caller zeroes the whole plan before dispatch. Inspectors never write media. */
#endif
