#ifndef NP_SENSOR_GRID_USB_ADAPTER_H
#define NP_SENSOR_GRID_USB_ADAPTER_H
#include "np_sensor_grid_batch.h"
/* Include the carrier exactly once via this adapter, not separately in the
 * same translation unit. Production routing is owned by the integrator. */
#include "../Src/np_usb_grid_port.inc"

typedef struct {
    NpUsbGridPort *port;
    NpUsbGridBatch wire;
    NpSensorGridBatch source;
    int32_t (*scratch)[9];
    uint32_t session,generation,outer,ordinary,grid,phase_sent,invalid_frames;
    uint8_t source_enabled,source_failed,frozen,capture_selected;
} NpSensorGridUsbAdapter;

/* port_start and validated port_phase are owned by the caller. Unselected,
 * unavailable or mismatched optional sources never gate ordinary NP output. */
static inline int np_sensor_grid_usb_begin(NpSensorGridUsbAdapter *a,NpUsbGridPort *p,
    NpSensorGrid *queue,NpSensorGridBatchState *state,int32_t scratch[NP_IMU_GRID_MAX_SLOTS][9])
{
    if(!a || !p)return 0;
    memset(a,0,sizeof(*a));a->port=p;a->scratch=scratch;
    a->session=p->session;a->generation=p->generation;a->outer=p->outer;
    a->ordinary=p->ordinary;a->grid=p->grid;a->phase_sent=p->phase_sent;a->invalid_frames=p->invalid_frames;
    a->frozen=p->control.frozen;a->capture_selected=p->control.capture_selected;
    np_usb_grid_batch_begin(p,&a->wire);
    if(np_usb_grid_capture_selected(&p->control) && p->phase_ready) {
        if(!queue || !state || !scratch || state->generation!=p->generation ||
           state->next_slot<p->phase_first_slot || !np_sensor_grid_batch_begin(queue,state,&a->source))
            a->source_failed=1U;
        else a->source_enabled=1U;
    }
    return 1;
}
static inline uint32_t np_sensor_grid_usb_ordinary_sequence(const NpSensorGridUsbAdapter *a)
{ return np_usb_grid_ordinary_sequence(&a->wire); }
static inline int np_sensor_grid_usb_ordinary_finish(NpSensorGridUsbAdapter *a,uint8_t packet[512])
{ return a && np_usb_grid_ordinary_finish(&a->wire,packet); }
/* Index must exactly match the source prefix. The batch packetizer produces
 * valid bounded NSG1 or no bytes; any source error is reported separately and
 * ordinary capture continues. Queue tail never moves here. */
static inline size_t np_sensor_grid_usb_peek(void *context,uint32_t index,uint8_t *out,size_t capacity)
{
    NpSensorGridUsbAdapter *a=(NpSensorGridUsbAdapter *)context;int bytes;
    if(!a->source_enabled || a->source_failed || index!=a->source.frames){a->source_failed=1U;return 0U;}
    bytes=np_sensor_grid_batch_next(&a->source,out,capacity,a->scratch);
    if(bytes<0){a->source_failed=1U;return 0U;}
    return (size_t)bytes;
}
static inline int np_sensor_grid_usb_try(NpSensorGridUsbAdapter *a,unsigned slot,
                                         int protected_work,uint8_t packet[512])
{
    if(!a || !a->source_enabled || a->source_failed)return 0;
    /* Keep a third ordinary sensor slot when the second grid frame would be
     * partial. The first frame (and phase carrier) remain prompt; the queued
     * remainder is sent on a later batch, without changing grid ordinals. */
    if(slot==3U && a->wire.taken &&
       a->source.head-a->source.cursor<NP_IMU_GRID_MAX_SLOTS)return 0;
    return np_usb_grid_try_packet(a->port,&a->wire,slot,protected_work,np_sensor_grid_usb_peek,a,packet);
}
static inline void np_sensor_grid_usb_retired(void *context,uint32_t count)
{ (void)context;(void)count; } /* source transaction is committed first */

/* Before publication and within the existing queue guard, check this result;
 * the sole consumer/lifecycle owner must keep it true through commit. A false
 * result invalidates only optional metadata, never the neural payload. */
static inline int np_sensor_grid_usb_ready(const NpSensorGridUsbAdapter *a)
{
    NpUsbGridPort *p;
    if(!a || !a->port)return 0;
    p=a->port;
    if(a->wire.slots!=4U ||
       p->session!=a->session || p->generation!=a->generation || p->outer!=a->outer ||
       p->ordinary!=a->ordinary || p->grid!=a->grid || p->phase_sent!=a->phase_sent ||
       p->invalid_frames!=a->invalid_frames || p->control.frozen!=a->frozen ||
       p->control.capture_selected!=a->capture_selected ||
       (a->source_enabled && a->wire.taken!=a->source.frames) ||
       (!a->source_enabled && a->wire.taken))return 0;
    if(a->source_enabled && (!p->phase_ready || !a->source.owner || !a->source.queue ||
       a->source.owner->generation!=a->source.generation || a->source.owner->revision!=a->source.revision ||
       a->source.queue->tail!=a->source.original_tail ||
       a->source.cursor-a->source.original_tail>a->source.head-a->source.original_tail))return 0;
    return 1;
}
/* Call only after the private queue slot is accepted, in the SAME guard as
 * ready(). Abort simply discards this adapter. The ready check is repeated so
 * an accidental caller mistake cannot advance either side. */
static inline int np_sensor_grid_usb_commit(NpSensorGridUsbAdapter *a,int published)
{
    NpUsbGridPort *p;
    if(!published || !np_sensor_grid_usb_ready(a))return 0;
    p=a->port;
    if(a->wire.taken && !np_sensor_grid_batch_commit(&a->source,a->wire.taken))return 0;
    /* Preconditions above make this non-failing; no source work or scans in
     * the guard, and the carrier sees precisely the already-committed prefix. */
    return np_usb_grid_batch_commit(p,&a->wire,np_sensor_grid_usb_retired,NULL);
}
#endif
