#ifndef NP_SENSOR_GRID_CLOCK_H
#define NP_SENSOR_GRID_CLOCK_H
#include <stdint.h>

/* Private deadline bookkeeping. The owner establishes first_tick against the
 * HSE-derived timer once at startup and retires it on any clock/reset change.
 * Calls must occur less than 2^31 counter ticks apart: a longer outage needs a
 * new segment, since a 32-bit counter cannot disambiguate that interval. */
typedef struct {
    uint32_t next_tick,period_ticks,max_lateness_ticks;
    volatile uint32_t last_tick; /* ISR writer; foreground observes before its counter read. */
    uint64_t next_ordinal,missing;
    uint32_t active;
} NpSensorGridClock;
static inline int np_sensor_grid_clock_begin(NpSensorGridClock *c,uint32_t first_tick,
    uint32_t period_ticks,uint32_t max_lateness_ticks,uint64_t first_ordinal)
{
    c->active=0U;
    if(!period_ticks || period_ticks>=0x80000000U || max_lateness_ticks>=period_ticks)return 0;
    c->next_tick=first_tick;c->period_ticks=period_ticks;c->max_lateness_ticks=max_lateness_ticks;
    c->last_tick=first_tick-period_ticks;
    c->next_ordinal=first_ordinal;c->missing=0U;c->active=1U;return 1;
}
/* Return 1 only for an on-time slot. Return 0 for an early or late IRQ;
 * late/coalesced ordinals are counted as missing, never backfilled. Return -1
 * and retire if the ordinal range cannot represent the next observation. */
static inline int np_sensor_grid_clock_observe(NpSensorGridClock *c,uint32_t now,uint64_t *ordinal)
{
    if(!c->active || !ordinal)return -1;
    /* A backward jump or ambiguous >=half-wrap outage ends this domain.
     * Counter wrap itself is forward modulo 2^32. No value is serialized. */
    if(now-c->last_tick>=UINT32_C(0x80000000)){c->active=0U;return -1;}
    c->last_tick=now;
    int32_t delta=(int32_t)(now-c->next_tick);
    if(delta<0)return 0;
    uint32_t elapsed=(uint32_t)delta,skipped=elapsed/c->period_ticks;
    uint32_t lateness=elapsed-skipped*c->period_ticks;
    if(c->next_ordinal>UINT64_MAX-(uint64_t)skipped-1U ||
       c->missing>UINT64_MAX-(uint64_t)skipped-1U){c->active=0U;return -1;}
    c->next_ordinal+=skipped;c->missing+=skipped;
    *ordinal=c->next_ordinal++;
    c->next_tick+=(skipped+1U)*c->period_ticks;
    if(lateness>c->max_lateness_ticks){c->missing++;return 0;}
    return 1;
}
#endif
