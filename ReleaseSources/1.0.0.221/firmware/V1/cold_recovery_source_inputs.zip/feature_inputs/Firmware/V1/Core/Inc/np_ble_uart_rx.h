#ifndef NP_BLE_UART_RX_H
#define NP_BLE_UART_RX_H
#include <stdint.h>
#define NP_BLE_UART_RX_SIZE 1024U
/* One IRQ producer and one foreground consumer. Never overwrite controls. */
typedef struct {
    volatile uint32_t head,tail,fault;
    uint8_t bytes[NP_BLE_UART_RX_SIZE];
    uint32_t ticks[NP_BLE_UART_RX_SIZE];
} NpBleUartRx;
static inline int np_ble_uart_rx_push(NpBleUartRx *r,uint8_t byte,uint32_t tick)
{
    uint32_t head=r->head;
    if(r->fault || head-r->tail>=NP_BLE_UART_RX_SIZE){r->fault=1U;return 0;}
    unsigned at=head&(NP_BLE_UART_RX_SIZE-1U);
    r->bytes[at]=byte;r->ticks[at]=tick;
    __DMB();r->head=head+1U;
    return 1;
}
static inline int np_ble_uart_rx_pop(NpBleUartRx *r,uint8_t *byte,uint32_t *tick,uint32_t now)
{
    (void)now;
    uint32_t tail=r->tail;
    if(r->fault || tail==r->head)return 0;
    __DMB();unsigned at=tail&(NP_BLE_UART_RX_SIZE-1U);
    *byte=r->bytes[at];*tick=r->ticks[at];
    __DMB();r->tail=tail+1U;
    return 1;
}
#endif
