#ifndef NP_BLE_FINE_RX_H
#define NP_BLE_FINE_RX_H
#include "np_v1_fine_clock.h"
/* One actual USART RDR observation, not a parser/foreground timestamp.
 * position is the absolute ring head AFTER the byte was successfully queued;
 * zero is a legitimate wrapped position. CR1/CR2/PRESC/BRR are raw snapshots. */
typedef struct {
    NpV1FinePoint point;
    uint32_t received_ms,position,brr,presc,cr1,cr2,uart_hz;
} NpBleFineRxStamp;
#if NP_FIRST_SYNC_ENABLE && NP_SD_APP
/* Lifecycle owner disables BEFORE clock/config/reset transitions and enables
 * only after the fine provider and UART configuration are qualified. Reset
 * drops associations but does not change the selected enabled/no-op policy. */
void NP_BleFineRxEnable(int enabled);
void NP_BleFineRxReset(void);
/* Call synchronously from the existing parser callback during the ring Feed.
 * Single-use; latest '>' only. Earlier queued tails overwritten by a later '>'
 * are deliberately unavailable. Payload '>' is not parsed or trusted here. */
int NP_BleFineRxTail(uint32_t received_ms,NpBleFineRxStamp *out);
#else
#define NP_BleFineRxEnable(enabled) ((void)(enabled))
#define NP_BleFineRxReset() ((void)0)
static inline int NP_BleFineRxTail(uint32_t ms,NpBleFineRxStamp *out)
{(void)ms;(void)out;return 0;}
#endif
#endif
