#ifndef NP_V1_RTC_CALENDAR_H
#define NP_V1_RTC_CALENDAR_H
#include <stdint.h>

/* UTC Unix microseconds, fixed BCD24h calendar2000..2099. The provider owns
 * source/PRER validation (HSE/32,74/9999), coherent reads and validity. This
 * pure conversion neither proves those conditions nor accesses the RTC. */
typedef struct {uint32_t tr,dr,ssr;} NpV1RtcCalendar;
#define NP_V1_RTC_CALENDAR_FIRST_US UINT64_C(946684800000000)
#define NP_V1_RTC_CALENDAR_END_US UINT64_C(4102444800000000)
#define NP_V1_RTC_CALENDAR_QUANTUM_US 100U

static inline uint32_t np_v1_rtc_calendar_bcd(uint32_t n)
{return ((n/10U)<<4U)|(n%10U);}
static inline int np_v1_rtc_calendar_unbcd(uint32_t b,uint32_t *n)
{
    if((b&15U)>9U || (b>>4U)>9U)return 0;
    *n=(b>>4U)*10U+(b&15U);return 1;
}
static inline uint32_t np_v1_rtc_calendar_month_days(uint32_t year,uint32_t month)
{
    static const uint8_t length[12]={31U,28U,31U,30U,31U,30U,31U,31U,30U,31U,30U,31U};
    return length[month-1U]+(uint32_t)(month==2U && (year&3U)==0U);
}
static inline int np_v1_rtc_calendar_decode(const NpV1RtcCalendar *c,uint64_t *utc_us)
{
    uint32_t hour,minute,second,year,month,day,weekday,days;
    if(utc_us)*utc_us=0U;
    if(!c || !utc_us || (c->tr&~UINT32_C(0x003f7f7f)) ||
       (c->dr&~UINT32_C(0x00ffff3f)) || c->ssr>9999U)return 0;
    if(!np_v1_rtc_calendar_unbcd(c->tr&0x7fU,&second) || second>59U ||
       !np_v1_rtc_calendar_unbcd((c->tr>>8U)&0x7fU,&minute) || minute>59U ||
       !np_v1_rtc_calendar_unbcd((c->tr>>16U)&0x3fU,&hour) || hour>23U ||
       !np_v1_rtc_calendar_unbcd((c->dr>>16U)&0xffU,&year) ||
       !np_v1_rtc_calendar_unbcd((c->dr>>8U)&0x1fU,&month) || !month || month>12U ||
       !np_v1_rtc_calendar_unbcd(c->dr&0x3fU,&day) || !day ||
       day>np_v1_rtc_calendar_month_days(year,month))return 0;
    /* All four-year cycles in this fixed century begin with a leap year. */
    days=year*365U+(year+3U)/4U+day-1U;
    for(uint32_t m=1U;m<month;m++)days+=np_v1_rtc_calendar_month_days(year,m);
    weekday=(c->dr>>13U)&7U;
    if(weekday!=(days+5U)%7U+1U)return 0; /* 2000-01-01 was Saturday=6. */
    *utc_us=NP_V1_RTC_CALENDAR_FIRST_US+
        ((uint64_t)days*86400U+hour*3600U+minute*60U+second)*UINT64_C(1000000)+
        (9999U-c->ssr)*NP_V1_RTC_CALENDAR_QUANTUM_US;
    return 1;
}
static inline int np_v1_rtc_calendar_encode(uint64_t utc_us,NpV1RtcCalendar *c)
{
    uint32_t day,year,month=1U,weekday,seconds;
    uint64_t elapsed;
    if(!c)return 0;
    c->tr=c->dr=c->ssr=0U;
    if(utc_us<NP_V1_RTC_CALENDAR_FIRST_US || utc_us>=NP_V1_RTC_CALENDAR_END_US)return 0;
    elapsed=(utc_us-NP_V1_RTC_CALENDAR_FIRST_US)/UINT64_C(1000000);
    day=(uint32_t)(elapsed/86400U);seconds=(uint32_t)(elapsed%86400U);
    weekday=(day+5U)%7U+1U;
    year=(day/1461U)*4U;day%=1461U;
    if(day>=366U){day-=366U;year+=1U+day/365U;day%=365U;}
    while(day>=np_v1_rtc_calendar_month_days(year,month)){
        day-=np_v1_rtc_calendar_month_days(year,month);month++;
    }
    c->tr=(np_v1_rtc_calendar_bcd(seconds/3600U)<<16U)|
          (np_v1_rtc_calendar_bcd((seconds/60U)%60U)<<8U)|np_v1_rtc_calendar_bcd(seconds%60U);
    c->dr=(np_v1_rtc_calendar_bcd(year)<<16U)|(weekday<<13U)|
          (np_v1_rtc_calendar_bcd(month)<<8U)|np_v1_rtc_calendar_bcd(day+1U);
    /* TARGET phase only. SSR is not directly programmable: the HAL provider
     * must set calendar/phase with the supported shift operation, in idle.
     * Sub100us is floored here; retain its uncertainty outside this helper. */
    c->ssr=9999U-(uint32_t)((utc_us%UINT64_C(1000000))/NP_V1_RTC_CALENDAR_QUANTUM_US);
    return 1;
}
#endif
