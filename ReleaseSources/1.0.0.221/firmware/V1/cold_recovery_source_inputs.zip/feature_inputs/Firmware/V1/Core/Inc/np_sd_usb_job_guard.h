#ifndef NP_SD_USB_JOB_GUARD_H
#define NP_SD_USB_JOB_GUARD_H

/* Lifecycle-only admission. The caller serializes this with the recorder,
 * reloads the committed state before each claim, and proves a matching ticket
 * and exact APP handoff, including consumption of its one-shot permit before
 * dispatch; a reset flag alone is never authorization. The caller must persist
 * UNCERTAIN as UNKNOWN and forbid replay. No memory location is selected here. */
enum {
    NP_USB_JOB_EMPTY = 0,
    NP_USB_JOB_QUEUED = 1,
    NP_USB_JOB_ACCEPTED = 2,
    NP_USB_JOB_RUNNING = 3,
    NP_USB_JOB_COMPLETE = 4,
    NP_USB_JOB_FAILED = 5,
    NP_USB_JOB_UNKNOWN = 6
};
enum { NP_USB_JOB_HOLD = 0, NP_USB_JOB_START = 1, NP_USB_JOB_UNCERTAIN = -1 };
enum {
    NP_USB_JOB_PROOF_RECORD = 1U << 0,
    NP_USB_JOB_PROOF_EXACT_HANDOFF = 1U << 1,
    NP_USB_JOB_PROOF_EXPECTED_RESET = 1U << 2,
    NP_USB_JOB_PROOF_IDENTITY = 1U << 3,
    NP_USB_JOB_PROOF_IDLE = 1U << 4,
    NP_USB_JOB_PROOF_ALL = (1U << 5) - 1U
};

/* persist_running must commit RUNNING and verify the complete retained record
 * before returning success. Any torn or ambiguous result prohibits dispatch;
 * it must be reported as UNKNOWN, never retried. */
static inline int np_sd_usb_job_claim(unsigned state, unsigned proof,
                                     int (*persist_running)(void *), void *ctx)
{
    if (state == NP_USB_JOB_EMPTY || state == NP_USB_JOB_COMPLETE ||
        state == NP_USB_JOB_FAILED) return NP_USB_JOB_HOLD;
    if (state != NP_USB_JOB_ACCEPTED || proof != NP_USB_JOB_PROOF_ALL ||
        !persist_running) return NP_USB_JOB_UNCERTAIN;
    return persist_running(ctx) == 0 ? NP_USB_JOB_START : NP_USB_JOB_UNCERTAIN;
}
#endif
