#ifndef XE_NP_STM32F4XX_HAL_DEF_COMPAT_H
#define XE_NP_STM32F4XX_HAL_DEF_COMPAT_H

#include "stm32u5xx_hal_def.h"

#endif
