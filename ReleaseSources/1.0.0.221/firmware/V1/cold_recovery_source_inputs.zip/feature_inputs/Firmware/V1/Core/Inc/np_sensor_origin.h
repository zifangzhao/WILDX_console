#ifndef NP_SENSOR_ORIGIN_H
#define NP_SENSOR_ORIGIN_H
#include "xe_np_sensors.h"
#include <string.h>
/* Foreground archive-copy filter, not a sensor trigger or conversion timestamp.
 * Callers flush their archive queue at release. Only still-held pre-release
 * components need checking; once every component is fresh the handler retires.
 * Independent IMU physical conversion phase remains unknown. */
typedef struct NpSensorOrigin NpSensorOrigin;
struct NpSensorOrigin {
    void (*filter)(NpSensorOrigin *,XE_NP_SensorSnapshot *);
    uint32_t baseline[3],release_ms,waiting;
};
static inline void np_sensor_origin_pass(NpSensorOrigin *g,XE_NP_SensorSnapshot *s)
{(void)g;(void)s;}
static inline void np_sensor_origin_clear(XE_NP_SensorSnapshot *s,uint32_t mask)
{
    s->valid&=~mask;
    if(mask&XE_NP_SENSOR_VALID_AG){
        memset(s->accel_micro_g,0,sizeof(s->accel_micro_g));
        memset(s->gyro_milli_dps,0,sizeof(s->gyro_milli_dps));
        s->imu_sequence=s->imu_tick_ms=s->sensor_time_24=0U;
    }
    if(mask&XE_NP_SENSOR_VALID_MAG){memset(s->mag_nano_tesla,0,sizeof(s->mag_nano_tesla));
        s->mag_sequence=s->mag_tick_ms=0U;}
    if(mask&XE_NP_SENSOR_VALID_ENV){s->temperature_centi_c=0;s->pressure_pa=s->humidity_milli_percent=0U;
        s->env_sequence=s->env_tick_ms=0U;}
}
static inline void np_sensor_origin_mute(NpSensorOrigin *g,XE_NP_SensorSnapshot *s)
{(void)g;np_sensor_origin_clear(s,7U);}
static inline void np_sensor_origin_wait(NpSensorOrigin *g)
{memset(g,0,sizeof(*g));g->filter=np_sensor_origin_mute;}
static inline void np_sensor_origin_pending(NpSensorOrigin *g,XE_NP_SensorSnapshot *s)
{
    const uint32_t sequence[3]={s->imu_sequence,s->mag_sequence,s->env_sequence};
    const uint32_t tick[3]={s->imu_tick_ms,s->mag_tick_ms,s->env_tick_ms};
    for(unsigned c=0U;c<3U;c++)if(g->waiting&(1U<<c)){
        uint32_t elapsed=tick[c]-g->release_ms;
        if((s->valid&(1U<<c)) && sequence[c]!=g->baseline[c] && elapsed && elapsed<0x80000000U)
            g->waiting&=~(1U<<c);
    }
    np_sensor_origin_clear(s,g->waiting);
    if(!g->waiting)g->filter=np_sensor_origin_pass;
}
static inline void np_sensor_origin_release(NpSensorOrigin *g,const XE_NP_SensorSnapshot *s,
    uint32_t now,uint32_t components)
{
    g->baseline[0]=s->imu_sequence;g->baseline[1]=s->mag_sequence;g->baseline[2]=s->env_sequence;
    g->release_ms=now;g->waiting=components&7U;
    g->filter=g->waiting?np_sensor_origin_pending:np_sensor_origin_pass;
}
#endif
