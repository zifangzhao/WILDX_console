#ifndef NP_USB_CATALOG_ENGINE_H
#define NP_USB_CATALOG_ENGINE_H
#include "np_usb_catalog.h"
#include "np_catalog_fs1.h"
#include "np_catalog_fs2.h"

enum {NPCR_IDLE,NPCR_QUEUED,NPCR_RUNNING,NPCR_COMPLETE,NPCR_FAILED};
typedef struct {uint32_t capacity,cid[4],epoch,clock;} NpcrIdentity;
typedef struct {
    void *context;
    int (*identity)(void *,NpcrIdentity *); /* Cached RAM only; no card I/O. */
    int (*current)(void *,const NpcrIdentity *); /* Ownership/card/epoch/clock. */
    NpcrRead read; /* Returns0 or a numeric NPCR error; never retries. */
    int (*write)(void *,uint32_t,const uint8_t *);
    uint32_t (*enter)(void *); /* Short terminal-publication critical section only. */
    void (*leave)(void *,uint32_t);
} NpcrIo;
typedef struct {
    NpcrIo io;uint32_t report[16];
    uint32_t last_nonce,cancel_generation,job_generation,queued,running,prepared;
    NpcrIdentity card,inspected_card;
    NpcrPlan inspected,work;
} NpcrEngine;
static inline int npcr_same_card(const NpcrIdentity *a,const NpcrIdentity *b)
{return a->capacity==b->capacity && a->epoch==b->epoch && !memcmp(a->cid,b->cid,16);}
static inline int npcr_current(NpcrEngine *e)
{
    if(e->job_generation!=e->cancel_generation)return NPCR_CANCELLED;
    return e->io.current?e->io.current(e->io.context,&e->card):NPCR_BUSY;
}
static inline int npcr_engine_read(void *context,uint32_t lba,uint8_t b[512])
{
    NpcrEngine *e=(NpcrEngine *)context;int error=npcr_current(e);
    if(error)return error;
    if(!e->io.read || lba>=e->card.capacity)return NPCR_IO;
    error=e->io.read(e->io.context,lba,b);
    if(error)return error>0 && error<=NPCR_CLOCK?error:NPCR_IO;
    return npcr_current(e);
}
static inline int npcr_engine_inspect(NpcrEngine *e,NpcrPlan *p)
{
    uint8_t b[512];NpcrReadIo read={e,npcr_engine_read};int error;
    memset(p,0,sizeof(*p));
    if(e->card.capacity<=8192U)return NPCR_CATALOG;
    error=npcr_read(&read,p,16U,b);if(error)return error;
    if(!memcmp(b,"CE_FILESYSTEM_V1",16) && !memcmp(b+32,"NP_CE64_1",9))
        return np_catalog_fs1_inspect(&read,e->card.capacity,p);
    int fs2=!memcmp(b,"NP_FILESYSTEM_V2",16) && !memcmp(b+32,"NP_CE64_2",9);
    if(!fs2){
        error=npcr_read(&read,p,24U,b);if(error)return error;
        fs2=!memcmp(b,"NP_FILESYSTEM_V2",16) && !memcmp(b+32,"NP_CE64_2",9);
    }
    return fs2?np_catalog_fs2_inspect(&read,e->card.capacity,p):NPCR_CATALOG;
}
static inline void npcr_engine_init(NpcrEngine *e,const NpcrIo *io)
{
    memset(e,0,sizeof(*e));e->io=*io;
    e->report[0]=NP_USB_CATALOG_MAGIC;e->report[1]=1U;
}
static inline int npcr_engine_active(const NpcrEngine *e)
{return e->queued || e->running;}
static inline void npcr_engine_cancel(NpcrEngine *e)
{
    uint32_t prepared=e->prepared;e->cancel_generation++;e->prepared=0U;
    if(prepared || e->queued || e->running){
        e->queued=0U;e->report[5]=NPCR_CANCELLED;e->report[3]=NPCR_FAILED;
    }
    e->report[14]=0U;
}
/* Submission invokes cached identity/owner checks only. No read/write I/O. */
static inline int npcr_engine_submit(NpcrEngine *e,uint32_t operation,uint32_t nonce)
{
    NpcrIdentity card={0};int error;
    if(operation!=NP_USB_CATALOG_INSPECT && operation!=NP_USB_CATALOG_REPAIR)return NPCR_BAD_REQUEST;
    if(!nonce || e->last_nonce==UINT32_MAX || nonce!=e->last_nonce+1U)return NPCR_NONCE;
    if(npcr_engine_active(e))return NPCR_BUSY;
    if(!e->io.identity || !e->io.current)return NPCR_BUSY;
    error=e->io.identity(e->io.context,&card);if(error){e->prepared=0U;return error;}
    uint32_t any=0U,all=UINT32_MAX;
    for(unsigned i=0;i<4U;i++){any|=card.cid[i];all&=card.cid[i];}
    if(card.capacity<=8192U || !any || all==UINT32_MAX){e->prepared=0U;return NPCR_IDENTITY;}
    error=e->io.current(e->io.context,&card);if(error){e->prepared=0U;return error;}
    if(operation==NP_USB_CATALOG_REPAIR &&
       (!e->prepared || e->report[2]!=NP_USB_CATALOG_INSPECT || e->report[3]!=NPCR_COMPLETE ||
        e->report[5] || e->report[14]!=e->report[4] || !npcr_same_card(&card,&e->inspected_card))){e->prepared=0U;return NPCR_IDENTITY;}
    if(operation==NP_USB_CATALOG_REPAIR && card.clock!=e->inspected_card.clock){e->prepared=0U;return NPCR_CLOCK;}
    uint32_t inspected=e->report[14];
    e->last_nonce=nonce;e->card=card;e->job_generation=e->cancel_generation;
    memset(e->report+2,0,14U*sizeof(uint32_t));e->report[2]=operation;
    e->report[4]=nonce;e->report[6]=card.capacity;memcpy(e->report+10,card.cid,16);
    e->report[9]=np_sd_metadata_crc_fast((const uint8_t *)card.cid,16);
    e->report[14]=operation==NP_USB_CATALOG_REPAIR?inspected:0U;e->report[15]=card.epoch;
    e->prepared=0U;e->queued=1U;e->report[3]=NPCR_QUEUED;return NPCR_OK;
}
static inline int npcr_write_allowed(uint32_t layout,uint32_t lba)
{
    if(layout==NPCR_FS1)return lba==112U || (lba>=128U && lba<1152U);
    return layout==NPCR_FS2 && (lba==16U || lba==24U || lba==112U || lba==113U);
}
/* One bounded foreground job, no reset/reinit/format/replay-on-error. */
static inline void npcr_engine_service(NpcrEngine *e)
{
    if(!e->queued)return;
    e->queued=0U;e->running=1U;e->report[3]=NPCR_RUNNING;
    memset(&e->work,0,sizeof(e->work));
    int error=npcr_current(e);
    if(!error)error=npcr_engine_inspect(e,&e->work);
    if(!error && e->report[2]==NP_USB_CATALOG_REPAIR){
        if(memcmp(&e->work,&e->inspected,sizeof(e->work)))error=NPCR_CATALOG;
        for(uint32_t i=0;!error && i<e->work.writes;i++){
            const NpcrWrite *w=&e->work.change[i];uint8_t b[512];
            error=npcr_current(e);
            if(!error && !npcr_write_allowed(e->work.layout,w->lba))error=NPCR_CATALOG;
            if(!error)error=npcr_engine_read(e,w->lba,b);
            if(!error && memcmp(b,w->before,512))error=NPCR_CATALOG;
            if(!error){
                if(!e->io.write)error=NPCR_IO;
                else {int result=e->io.write(e->io.context,w->lba,w->after);if(result)error=result>0 && result<=NPCR_CLOCK?result:NPCR_IO;}
            }
            if(!error)error=npcr_engine_read(e,w->lba,b);
            if(!error && memcmp(b,w->after,512))error=NPCR_IO;
        }
        if(!error){
            /* Reuse the inspected buffer only after all comparisons/writes. */
            uint32_t layout=e->work.layout,next=e->work.next_lba,count=e->work.count;
            uint64_t epoch=e->work.format_epoch,generation=e->work.generation;
            error=npcr_engine_inspect(e,&e->inspected);
            if(!error && (e->inspected.layout!=layout || e->inspected.next_lba!=next ||
               e->inspected.count!=count || e->inspected.format_epoch!=epoch ||
               e->inspected.generation!=generation || e->inspected.writes))error=NPCR_CATALOG;
            if(!error)e->work=e->inspected;
        }
    }
    uint32_t key=e->io.enter?e->io.enter(e->io.context):0U;
    int current=npcr_current(e);
    if(!error || current==NPCR_CANCELLED)error=current;
    e->report[7]=e->work.flags;e->report[8]=e->work.next_lba;
    if(!error && e->report[2]==NP_USB_CATALOG_INSPECT){
        e->inspected=e->work;e->inspected_card=e->card;e->prepared=1U;
        e->report[14]=e->report[4];
    }
    e->report[5]=(uint32_t)error;e->report[3]=error?NPCR_FAILED:NPCR_COMPLETE;e->running=0U;
    if(e->io.leave)e->io.leave(e->io.context,key);
}
#endif
