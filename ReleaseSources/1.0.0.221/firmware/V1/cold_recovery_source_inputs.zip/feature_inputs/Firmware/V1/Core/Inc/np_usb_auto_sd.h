#ifndef NP_USB_AUTO_SD_H
#define NP_USB_AUTO_SD_H
#include <stdint.h>
#include "mode_policy.h"
#define NP_USB_AUTO_SD_TIMEOUT_MS 2000U
typedef struct {
    uint32_t attached_ms;
    volatile uint8_t enumerated;
    uint8_t checked,pending;
} NpUsbAutoSd;
static inline int np_usb_auto_sd_due(const NpUsbAutoSd *s,uint32_t now,int busy,uint32_t target)
{
    return !s->enumerated && !s->checked && !busy && !target &&
           (uint32_t)(now-s->attached_ms)>=NP_USB_AUTO_SD_TIMEOUT_MS;
}
static inline void np_usb_auto_sd_cancel_on_enumeration(NpUsbAutoSd *s,NpV1Mode *m)
{
    if(s->pending && s->enumerated){
        if(m->target==NP_V1_SD)np_v1_mode_cancel(m);
        s->pending=0;
    }
}
#endif
