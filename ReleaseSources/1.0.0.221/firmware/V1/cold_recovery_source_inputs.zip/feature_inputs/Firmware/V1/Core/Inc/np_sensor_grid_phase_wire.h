#ifndef NP_SENSOR_GRID_PHASE_WIRE_H
#define NP_SENSOR_GRID_PHASE_WIRE_H
#include "np_imu_grid_wire.h"
#include "np_imu_grid_phase.h"

/* V1 adapter around the byte-identical shared NSGP codec. */
#define NP_GRID_PHASE_BYTES NP_IMU_GRID_PHASE_BYTES
#define NP_GRID_PHASE_UNKNOWN UINT64_C(0x8000000000000000)
enum {NP_GRID_PHASE_INTERVAL=NP_IMU_GRID_PHASE_INTERVAL_VALID,
      NP_GRID_PHASE_JITTER=NP_IMU_GRID_PHASE_JITTER_VALID};
typedef struct {
    uint32_t uid[3],session,generation,source_epoch,domain;
    uint64_t token,first_slot,low_num,high_num;
    uint32_t den,jitter,flags;
} NpGridPhaseWire;
static inline int np_grid_phase_wire_pack(uint8_t out[NP_GRID_PHASE_BYTES],const NpGridPhaseWire *p)
{
    if(!out || !p || np_imu_grid_overlap(out,NP_GRID_PHASE_BYTES,p,sizeof(*p)) ||
       ((p->flags&NP_GRID_PHASE_INTERVAL) && (p->low_num>INT64_MAX || p->high_num>INT64_MAX)) ||
       (!(p->flags&NP_GRID_PHASE_INTERVAL) && (p->low_num!=NP_GRID_PHASE_UNKNOWN || p->high_num!=NP_GRID_PHASE_UNKNOWN)))return 0;
    NpImuGridPhaseRecord q={0};
    for(unsigned i=0U;i<3U;i++)np_imu_grid_put32(q.binding.uid+4U*i,p->uid[i]);
    q.binding.session=p->session;q.binding.capture_generation=p->generation;
    q.binding.source_epoch=p->source_epoch;q.binding.counter_domain=p->domain;q.binding.token=p->token;
    q.first_accepted_slot=p->first_slot;
    q.lower_numerator=(p->flags&NP_GRID_PHASE_INTERVAL)?(int64_t)p->low_num:INT64_MIN;
    q.upper_numerator=(p->flags&NP_GRID_PHASE_INTERVAL)?(int64_t)p->high_num:INT64_MIN;
    q.denominator=p->den;q.maximum_jitter=p->jitter;q.flags=p->flags;
    return np_imu_grid_phase_pack(out,NP_GRID_PHASE_BYTES,&q);
}
static inline int np_grid_phase_wire_read(const uint8_t *raw,size_t bytes,NpGridPhaseWire *out)
{
    NpImuGridPhaseRecord q;
    if(!raw || (out && np_imu_grid_overlap(raw,bytes,out,sizeof(*out))) ||
       !np_imu_grid_phase_read(raw,bytes,&q))return 0;
    if(out){
        for(unsigned i=0U;i<3U;i++)out->uid[i]=np_imu_grid_u32(q.binding.uid+4U*i);
        out->session=q.binding.session;out->generation=q.binding.capture_generation;
        out->source_epoch=q.binding.source_epoch;out->domain=q.binding.counter_domain;out->token=q.binding.token;
        out->first_slot=q.first_accepted_slot;
        out->low_num=(q.flags&NP_IMU_GRID_PHASE_INTERVAL_VALID)?(uint64_t)q.lower_numerator:NP_GRID_PHASE_UNKNOWN;
        out->high_num=(q.flags&NP_IMU_GRID_PHASE_INTERVAL_VALID)?(uint64_t)q.upper_numerator:NP_GRID_PHASE_UNKNOWN;
        out->den=q.denominator;out->jitter=q.maximum_jitter;out->flags=q.flags;
    }
    return 1;
}
#endif
