#ifndef NP_USB_SD_MODE_CHECK_H
#define NP_USB_SD_MODE_CHECK_H

/* Complete one CMD6 transaction with the caller's exact argument. A mode1
 * argument can change functions: only the owning initializer chooses it.
 * status is usable only on HAL_OK, in the same card/initialization session.
 */
static HAL_StatusTypeDef np_usb_sd_read_switch_status(SD_HandleTypeDef *sd,
                                                     uint32_t argument,
                                                     uint32_t status[16])
{
  uint32_t words = 0U;
  uint32_t start = HAL_GetTick();
  const uint32_t errors = SDMMC_FLAG_DTIMEOUT | SDMMC_FLAG_DCRCFAIL | SDMMC_FLAG_RXOVERR;
  SDMMC_DataInitTypeDef data = {0};
  sd->Instance->DCTRL = 0U;
  __HAL_SD_CLEAR_FLAG(sd, SDMMC_STATIC_DATA_FLAGS);
  if (SDMMC_CmdBlockLength(sd->Instance, 64U) != HAL_SD_ERROR_NONE) return HAL_ERROR;
  data.DataTimeOut = SDMMC_DATATIMEOUT;
  data.DataLength = 64U;
  data.DataBlockSize = SDMMC_DATABLOCK_SIZE_64B;
  data.TransferDir = SDMMC_TRANSFER_DIR_TO_SDMMC;
  data.TransferMode = SDMMC_TRANSFER_MODE_BLOCK;
  data.DPSM = SDMMC_DPSM_ENABLE;
  if (SDMMC_ConfigData(sd->Instance, &data) != HAL_OK ||
      SDMMC_CmdSwitch(sd->Instance, argument) != HAL_SD_ERROR_NONE) return HAL_ERROR;
  for (;;)
  {
    if (__HAL_SD_GET_FLAG(sd, errors)) return HAL_ERROR;
    /* U5 FIFO flags/data are valid during the active receive path. Admit
     * reads only on positive half-full status: CMD6 is exactly two bursts.
     */
    if (words < 16U && __HAL_SD_GET_FLAG(sd, SDMMC_FLAG_RXFIFOHF))
      for (uint32_t n = 0U; n < 8U; n++) status[words++] = SDMMC_ReadFIFO(sd->Instance);
    else if (__HAL_SD_GET_FLAG(sd, SDMMC_FLAG_DATAEND)) break;
    if (HAL_GetTick() - start >= 1000U) return HAL_ERROR;
  }
  /* U5 RX DATAEND already requires DATACOUNT=0 and FIFO empty. RXFIFOE is
   * not a valid extra admission gate after DPSM retires (live STA=DATAEND).
   */
  if (words != 16U || __HAL_SD_GET_FLAG(sd, errors)) return HAL_ERROR;
  __HAL_SD_CLEAR_FLAG(sd, SDMMC_STATIC_DATA_FLAGS);
  sd->Instance->DCTRL = 0U;
  if (SDMMC_CmdBlockLength(sd->Instance, 512U) != HAL_SD_ERROR_NONE) return HAL_ERROR;
  return HAL_OK;
}

/* SD Table4-11: group1 SDR50/SDR104/DDR50 support is zero at3.3V.
 * This mask identifies retained1.8V only from a fresh, CRC-checked status in
 * the same session; it is not a cached capability or physical voltage proof.
 */
static uint32_t np_usb_sd_retained_1v8_supported(const uint32_t status[16])
{
  const uint8_t *bytes = (const uint8_t *)status;
  const uint32_t support = ((uint32_t)bytes[12] << 8U) | bytes[13];
  return support & 0x001CU;
}

/* Independent read-only selected-mode/power check. The frozen HAL tests a
 * support bit, not actual selection. Caller already established voltage and
 * tuned/validated read timing. This does not measure/clamp card current.
 */
static HAL_StatusTypeDef np_usb_sd_mode_check(SD_HandleTypeDef *sd, uint32_t mode)
{
  uint32_t function;
  switch (mode)
  {
    /* Caller enters DEFAULT only after a fresh cold init. Its repeated sector
     * reads are the acceptance gate; optional CMD6 must not disable this safe
     * fallback (including older cards which do not implement CMD6).
     */
    case SDMMC_SPEED_MODE_DEFAULT: return HAL_OK;
    case SDMMC_SPEED_MODE_HIGH: function = 1U; break;
    case SDMMC_SPEED_MODE_ULTRA_SDR50: function = 2U; break;
    case SDMMC_SPEED_MODE_ULTRA_SDR104: function = 3U; break;
    default: return HAL_ERROR; /* DDR remains unqualified in this HAL. */
  }
  if (sd->SdCard.CardSpeed == CARD_NORMAL_SPEED)
    return HAL_ERROR;

  uint32_t status[16] = {0U};
  if (np_usb_sd_read_switch_status(sd, 0x00FFFFFFU, status) != HAL_OK) return HAL_ERROR;
  const uint8_t *bytes = (const uint8_t *)status;
  const uint32_t support = ((uint32_t)bytes[12] << 8U) | bytes[13];
  if (!(support & (1U << function)) || (bytes[16] & 15U) != function) return HAL_ERROR;
  /* V1 U1/TLV70533 is a 200mA SD supply. UHS cards (including SDR25) must
   * actually retain group4/function0; a speed ACK does not prove power class.
   * This is the card's allowance, not a measured transient-current clamp.
   */
  if (sd->SdCard.CardSpeed == CARD_ULTRA_HIGH_SPEED &&
      (!(bytes[7] & 1U) || ((bytes[15] >> 4U) & 15U) != 0U)) return HAL_ERROR;
  return HAL_OK;
}

#endif
