#ifndef NP_USB_SOURCE_LOSS_H
#define NP_USB_SOURCE_LOSS_H
/* Native paired USB only. Private queued packets remain owned by USB; only
 * unclaimed capture history may be abandoned. Counters are unknown-gap events,
 * not fabricated elapsed sample counts. NP counters let the host relock. */
static uint8_t np_usb_loss_pending;
static uint32_t np_usb_loss_heads[4];
volatile uint32_t np_usb_loss_diag[4]; /* events,resyncs,last reason,last tick */
static void np_usb_loss_reset(void)
{
    np_usb_loss_pending=0;
    memset(np_usb_loss_heads,0,sizeof(np_usb_loss_heads));
    memset((void *)np_usb_loss_diag,0,sizeof(np_usb_loss_diag));
}
static int np_usb_loss_head(unsigned lane,uint32_t *head)
{
    const uint32_t n=xe_np_runtime.capture.raw_storage_bytes/24U;
    DMA_Channel_TypeDef *ch=np3_channel(lane);
    const uint32_t base=(uint32_t)xe_np_runtime.capture.raw_storage+lane*n*2U;
    if(!ch || !(ch->CCR&DMA_CCR_EN) ||
       (ch->CSR&(DMA_FLAG_DTE|DMA_FLAG_ULE|DMA_FLAG_USE|DMA_FLAG_TO)))return np3_fail(11U);
    const uint32_t address=ch->CDAR;
    if(address<base || address>base+n*2U || ((address-base)&3U))return np3_fail(12U);
    *head=((address-base)/2U)%n;
    return 1;
}
static int np_usb_loss_ready(void)
{
    unsigned moving=0;
    for(unsigned lane=0;lane<4U;lane++){
        uint32_t head;
        if(np_usb_loss_head(lane,&head)<0)return -1;
        if(head!=np_usb_loss_heads[lane])moving++;
    }
    return moving==4U;
}
static int np_usb_loss_recover(void)
{
    const uint32_t reason=np3_diag[1];
    if(!NP_USB20_PAIRED() || np3_claimed || (reason!=10U && reason!=14U))return 0;
    for(unsigned lane=0;lane<4U;lane++)
        if(np_usb_loss_head(lane,&np_usb_loss_heads[lane])<0)return 0;
    if(np_usb_loss_diag[0]!=UINT32_MAX)np_usb_loss_diag[0]++;
#if NP_FIRST_SYNC_ENABLE
    NP_FirstCaptureLoss();
#endif
#if NP_CL_ENABLE
    NP_ClCaptureLoss();
#endif
    np_usb_loss_diag[2]=reason;np_usb_loss_diag[3]=HAL_GetTick();
    np_usb_loss_pending=1;np3_valid=0;
    np3_diag[1]=0;xe_np_quad_usb_word_diag[1]=0;
    np3_last_tick=HAL_GetTick();
    return 1;
}
static void np_usb_loss_resynced(void)
{
    if(!np_usb_loss_pending)return;
    np_usb_loss_pending=0;
    if(np_usb_loss_diag[1]!=UINT32_MAX)np_usb_loss_diag[1]++;
}
#endif
