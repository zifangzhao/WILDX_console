#ifndef NP_SD_VERIFY_H
#define NP_SD_VERIFY_H
#include "np_sd_log.h"
/* Offline-only strict framing oracle. Input is chronological single-probe
 * bytes reconstructed from a stopped recording, never the live GPIO ring. */
typedef struct {
    uint32_t frames,phase,marker_mod,errors[5],first_bad_frame;
    uint32_t previous,have_previous,used,skip;
    uint8_t frame[60];
} NpSdVerifier;
static inline uint32_t np_verify_word(const uint8_t *p,unsigned bit)
{ uint32_t v=0;for(unsigned i=0;i<10;i++)v=(v<<1)|((p[i]>>bit)&1U);return v; }
static inline int np_verify_init(NpSdVerifier *v,const uint8_t *prefix)
{
    uint32_t best=0;memset(v,0,sizeof(*v));v->first_bad_frame=0xffffffffU;
    for(unsigned phase=0;phase<60;phase++) {
        uint32_t count=0;
        for(unsigned p=phase;p+60<=6000;p+=60) {
            uint32_t word=np_verify_word(prefix+p,0);count+=word==0xcfU||word==0x330U;
        }
        if(count>best){best=count;v->phase=phase;}
    }
    uint32_t bins[13]={0};best=0;
    for(unsigned p=v->phase,n=0;p+60<=6000;p+=60,n++)
        if(np_verify_word(prefix+p,0)==0x330U)bins[n%13]++;
    for(unsigned i=0;i<13;i++)if(bins[i]>best){best=bins[i];v->marker_mod=i;}
    v->skip=v->phase;return best?0:-1;
}
static inline void np_verify_frame(NpSdVerifier *v,const uint8_t *b)
{
    uint32_t bad[5]={0},transitions=0;
    bad[0]=np_verify_word(b,0)!=((v->frames%13==v->marker_mod)?0x330U:0xcfU);
    for(unsigned i=11;i<60;i++)transitions+=(b[i]^b[i-1])&1U;
    bad[1]=transitions>1;
    for(unsigned i=50;i<60;i++)bad[2]|=(b[i]&0xfeU)!=0;
    bad[3]=np_verify_word(b+20,7)!=0x22U;
    uint32_t counter=(np_verify_word(b+30,7)<<10)|np_verify_word(b+40,7);
    bad[4]=v->have_previous&&(((counter-v->previous)&0xfffffU)!=1U);
    v->have_previous=1;v->previous=counter;
    for(unsigned i=0;i<5;i++)if(bad[i]){v->errors[i]++;if(v->first_bad_frame==0xffffffffU)v->first_bad_frame=v->frames;}
    v->frames++;
}
static inline void np_verify_feed(NpSdVerifier *v,const uint8_t *b,uint32_t size)
{
    uint32_t n=v->skip<size?v->skip:size;b+=n;size-=n;v->skip-=n;
    if(v->used) {
        n=60-v->used;if(n>size)n=size;
        memcpy(v->frame+v->used,b,n);v->used+=n;b+=n;size-=n;
        if(v->used==60){np_verify_frame(v,v->frame);v->used=0;}
    }
    while(size>=60){np_verify_frame(v,b);b+=60;size-=60;}
    if(size){memcpy(v->frame,b,size);v->used=size;}
}
#endif
