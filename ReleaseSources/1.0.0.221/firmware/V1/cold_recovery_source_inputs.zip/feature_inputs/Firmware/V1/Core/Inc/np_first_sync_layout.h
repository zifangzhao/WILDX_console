#ifndef NP_FIRST_SYNC_LAYOUT_H
#define NP_FIRST_SYNC_LAYOUT_H
#include <stdint.h>

/* Borrow only a completed, retention-accepted private block for this call.
 * Validate once, then use the selected reader with t<ticks. Neither readers
 * nor validators retain pointers, select modes, or inspect live DMA state. */
typedef struct {
    const uint8_t *data;
    uint32_t bytes,ticks,probe;
} NpFirstV1View;
static inline int np_first_view_base(const NpFirstV1View *v)
{
    return v && v->data && v->ticks>=2339U && v->ticks<=61440U &&
        v->bytes<=65536U && v->probe>=1U && v->probe<=3U;
}
static inline int np_first_view_sd8(const NpFirstV1View *v)
{return np_first_view_base(v) && !(v->ticks&3U) && v->ticks<=v->bytes;}
static inline int np_first_view_sd16(const NpFirstV1View *v)
{return np_first_view_base(v) && v->probe<=2U && !(v->ticks&3U) && v->ticks*2U<=v->bytes;}
static inline int np_first_view_usb8(const NpFirstV1View *v)
{return np_first_view_base(v) && !(v->ticks%2024U) && (v->ticks/2024U)*2048U<=v->bytes;}
static inline int np_first_view_usb16(const NpFirstV1View *v)
{return np_first_view_base(v) && v->probe<=2U && !(v->ticks%1008U) &&
    (v->ticks/1008U)*2048U<=v->bytes;}
static inline uint8_t np_first_read_sd8(const void *context,uint32_t t)
{
    const NpFirstV1View *v=(const NpFirstV1View *)context;
    return v->data[(t&3U)*(v->ticks/4U)+(t>>2)];
}
static inline uint8_t np_first_read_sd16(const void *context,uint32_t t)
{
    const NpFirstV1View *v=(const NpFirstV1View *)context;
    return v->data[(t&3U)*(v->ticks/2U)+(t>>2)*2U+v->probe-1U];
}
static inline uint8_t np_first_read_usb8(const void *context,uint32_t t)
{
    const NpFirstV1View *v=(const NpFirstV1View *)context;uint32_t q=t>>2;
    return v->data[((q/506U)*4U+(t&3U))*512U+6U+q%506U];
}
static inline uint8_t np_first_read_usb16(const void *context,uint32_t t)
{
    const NpFirstV1View *v=(const NpFirstV1View *)context;uint32_t q=t>>2;
    return v->data[((q/252U)*4U+(t&3U))*512U+8U+2U*(q%252U)+v->probe-1U];
}
#endif
