#ifndef XE_NP_BASE_STRING_H
#define XE_NP_BASE_STRING_H

#include <math.h>
#include <string.h>

int BASE_Int16toDecimal(short num, char *str, unsigned short *len);
int BASE_Uint16toDecimal(unsigned short num, char *str, unsigned short *len);
int BASE_Int16toChar(short num, char *str, unsigned short *len);
int BASE_Uint16toChar(unsigned short num, char *str, unsigned short *len);
int BASE_Uint16toChar_Decimal(unsigned short num, short place, char *str, unsigned short *len);
int BASE_Uint32toChar(unsigned long num, char *str, unsigned short *len);
int BASE_Uint32toCharN(unsigned long num, char *str, unsigned short len);
int BASE_HextoChar(unsigned char x, char *str, unsigned short *len);
int BASE_SwapEndian(unsigned char *x, int len, int unitBytes);
unsigned short BASE_reverseBits(unsigned short num);

#define BASE_SWAPENDIAN_16BIT(__handle__) ((((__handle__) & 0x00ffU) << 8) | (((__handle__) & 0xff00U) >> 8))
#define BASE_SWAPENDIAN_32BIT(__handle__) ((((__handle__) & 0x000000ffUL) << 24) | (((__handle__) & 0x0000ff00UL) << 8) | (((__handle__) & 0x00ff0000UL) >> 8) | (((__handle__) & 0xff000000UL) >> 24))

#endif
