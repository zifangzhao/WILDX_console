#ifndef NP_USB_CATALOG_H
#define NP_USB_CATALOG_H
#include <stdint.h>
#ifndef NP_USB_CATALOG_REPAIR_ENABLE
#define NP_USB_CATALOG_REPAIR_ENABLE 0U
#endif
#if NP_USB_CATALOG_REPAIR_ENABLE!=0U && NP_USB_CATALOG_REPAIR_ENABLE!=1U
#error "USB catalog repair must be an explicit boolean"
#endif
/* V1 word3 bit0x10 is ROM DFU, NOT the V2 repair capability. */
#define NP_USB_CATALOG_CAPABILITY (NP_USB_CATALOG_REPAIR_ENABLE?0x20U:0U)
#define NP_USB_CATALOG_REPORT 0xA0U
#define NP_USB_CATALOG_INSPECT 0xA1U
#define NP_USB_CATALOG_REPAIR 0xA2U
#define NP_USB_CATALOG_MAGIC 0x3152434EU
/* NCR1 ABI1 words: magic,ABI,operation,state,nonce,error,capacity,layoutflags,
 * nextLBA,CIDcrc32,CID[4],inspectedNonce,USBepoch. GET64 is cached only.
 * OUT0 nonce=wIndex:wValue, strict+1/nonzero/no wrap; no command replay.
 * V1 flags: FS1=1,FS2=2; FULL10000,RECOVERY20000,RECOVERABLE40000,
 * DEGRADED800000. No quarantine/rewind/descriptor invention is defined. */
#if NP_USB_CATALOG_REPAIR_ENABLE
static int np_usb_catalog_owned(void);
static void np_usb_catalog_cancel(void);
#else
static inline int np_usb_catalog_owned(void){return 0;}
static inline void np_usb_catalog_cancel(void){}
#endif
#endif
