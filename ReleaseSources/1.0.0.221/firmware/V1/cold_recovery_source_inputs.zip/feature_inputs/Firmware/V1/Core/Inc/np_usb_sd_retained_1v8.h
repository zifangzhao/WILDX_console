#ifndef NP_USB_SD_RETAINED_1V8_H
#define NP_USB_SD_RETAINED_1V8_H

/* Resident USB only: S18A=0 keeps an already selected signal voltage. The
 * SD specification Table4-11 requires CMD6 group1 bits2..4 to be zero at3.3V.
 * Only a fresh, CRC-checked query may establish this retained1.8V case. This
 * does not fabricate S18A/CMD11 success or use SSR performance classifications.
 */
static volatile struct {
  uint32_t attempts, successes, stage, support, access, power, card_state, error;
} np_usb_sd_retained_diag;

static HAL_StatusTypeDef np_usb_sd_recover_retained_1v8(SD_HandleTypeDef *sd)
{
  uint32_t status[16] = {0U};
  uint8_t reference[512];
  np_usb_sd_retained_diag.stage = 0U;
  np_usb_sd_retained_diag.support = 0U;
  np_usb_sd_retained_diag.error = 0U;
  if (xe_np_sd_signal_1v8_enabled != 0U) return HAL_OK; /* Native CMD11 won. */
  if (sd->Instance != SDMMC1 || sd->Init.TranceiverPresent != SDMMC_TRANSCEIVER_PRESENT ||
      sd->SdCard.CardType != CARD_SDHC_SDXC) return HAL_OK;
  np_usb_sd_retained_diag.stage = 1U;
  if (np_usb_sd_read_switch_status(sd, 0x00FFFFFFU, status) != HAL_OK) return HAL_ERROR;
  np_usb_sd_retained_diag.support = np_usb_sd_retained_1v8_supported(status);
  if (np_usb_sd_retained_diag.support == 0U) return HAL_OK; /* Genuine3.3V. */
  const uint8_t *bytes = (const uint8_t *)status;
  np_usb_sd_retained_diag.access = bytes[16] & 15U;
  np_usb_sd_retained_diag.power = (bytes[15] >> 4U) & 15U;
  /* CMD0 can retain the selected SDR access function as well as1.8V.
   * Low startup clocks are valid for SDR12/25/50/104. DDR remains excluded.
   */
  if (!(bytes[7] & 1U) || np_usb_sd_retained_diag.access > 3U) return HAL_ERROR;
  np_usb_sd_retained_diag.attempts++;
  np_usb_sd_retained_diag.stage = 2U;
  if (XE_NP_Board_ProbeSdMetadataRead() != HAL_OK) return HAL_ERROR;
  memcpy(reference, xe_np_sd_speed_probe_buf, sizeof(reference));

  /* Lower the card allowance before any fast clock or selector change. Leave
   * all access/driver functions unchanged, then require actual function0.
   */
  np_usb_sd_retained_diag.stage = 3U;
  if (np_usb_sd_read_switch_status(sd, 0x80FF0FFFU, status) != HAL_OK ||
      np_usb_sd_retained_1v8_supported(status) == 0U ||
      (((const uint8_t *)status)[16] & 15U) != np_usb_sd_retained_diag.access ||
      (((const uint8_t *)status)[15] & 0xF0U) != 0U) return HAL_ERROR;
  HAL_SD_DriveTransceiver_1_8V_Callback(SET);
  np_usb_sd_retained_diag.stage = 4U;
  if (XE_NP_Board_ProbeSdMetadataRead() != HAL_OK ||
      memcmp(reference, xe_np_sd_speed_probe_buf, sizeof(reference)) != 0 ||
      np_usb_sd_read_switch_status(sd, 0x00FFFFFFU, status) != HAL_OK ||
      np_usb_sd_retained_1v8_supported(status) == 0U ||
      (((const uint8_t *)status)[16] & 15U) != np_usb_sd_retained_diag.access ||
      (((const uint8_t *)status)[15] & 0xF0U) != 0U) goto failed;
  np_usb_sd_retained_diag.card_state = HAL_SD_GetCardState(sd);
  if (np_usb_sd_retained_diag.card_state != HAL_SD_CARD_TRANSFER) goto failed;
  sd->SdCard.CardSpeed = CARD_ULTRA_HIGH_SPEED;
  np_usb_sd_retained_diag.successes++;
  np_usb_sd_retained_diag.stage = 5U;
  return HAL_OK;
failed:
  np_usb_sd_retained_diag.error = sd->ErrorCode;
  HAL_SD_DriveTransceiver_1_8V_Callback(RESET);
  return HAL_ERROR; /* Caller rejects this init; next candidate starts fresh. */
}

#endif
