#ifndef NP_USB_SD_FORMAT_H
#define NP_USB_SD_FORMAT_H
#include <stdint.h>
#include <string.h>
#include "np_sd_fast_crc.h"

/* Pure command engine: no mount/replay, capture runtime, HAL or endpoint I/O.
 * The adapter serializes calls. Submit invokes no callbacks; only foreground
 * Service writes the card. INFO reads cached RAM only and never mounts it. */
#define NP_USB_SD_FORMAT_INFO_MAGIC 0x3153464EU
#define NP_USB_SD_FORMAT_REQUEST_MAGIC 0x3146534EU
#define NP_USB_SD_FORMAT_CONFIRM 0x46524D54U
#define NP_USB_SD_FORMAT_IDENT_LBA 16U
#define NP_USB_SD_FORMAT_LOG_LBA 128U
#define NP_USB_SD_FORMAT_JOURNAL_LBA 112U
#define NP_USB_SD_FORMAT_SHADOW_LBA 113U
#define NP_USB_SD_FORMAT_NEXT_START 8192U
enum {NP_USB_SD_FORMAT_IDLE,NP_USB_SD_FORMAT_QUEUED,NP_USB_SD_FORMAT_RUNNING,
      NP_USB_SD_FORMAT_DONE,NP_USB_SD_FORMAT_FAILED};
enum {NP_USB_SD_FORMAT_OK,NP_USB_SD_FORMAT_FRAME,NP_USB_SD_FORMAT_BUSY,
      NP_USB_SD_FORMAT_IDENTITY,NP_USB_SD_FORMAT_NO_CARD,NP_USB_SD_FORMAT_WRITE,
      NP_USB_SD_FORMAT_READ,NP_USB_SD_FORMAT_VERIFY,NP_USB_SD_FORMAT_TRANSACTION,
      NP_USB_SD_FORMAT_CALLBACK};
typedef struct {uint32_t capacity,uid[3],cid[4];} NpUsbSdFormatIdentity;
typedef struct {
    void *context;
    /* Return0 iff physically ready. Always fill MCU UID, even without a card.
     * This callback must not depend on NP identification/catalog validity. */
    int (*identify)(void *,NpUsbSdFormatIdentity *);
    int (*busy)(void *); /* Nonzero for capture/download/mode-transition ownership. */
    int (*read)(void *,uint32_t,uint8_t *);
    int (*write)(void *,uint32_t,const uint8_t *);
} NpUsbSdFormatIo;
typedef struct {
    NpUsbSdFormatIo io;
    volatile uint32_t state;
    uint32_t error,transaction;
    uint8_t request[64];
    NpUsbSdFormatIdentity expected,observed;
    uint32_t card_ready;
} NpUsbSdFormat;
static inline uint32_t np_usb_sd_format_word(const uint8_t *p)
{return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static inline void np_usb_sd_format_put(uint8_t *p,uint32_t w)
{p[0]=(uint8_t)w;p[1]=(uint8_t)(w>>8);p[2]=(uint8_t)(w>>16);p[3]=(uint8_t)(w>>24);}
static inline int np_usb_sd_format_same(const NpUsbSdFormatIdentity *a,const NpUsbSdFormatIdentity *b)
{return a->capacity==b->capacity && !memcmp(a->uid,b->uid,sizeof(a->uid)) && !memcmp(a->cid,b->cid,sizeof(a->cid));}
static inline void np_usb_sd_format_init(NpUsbSdFormat *f,const NpUsbSdFormatIo *io)
{memset(f,0,sizeof(*f));if(io)f->io=*io;}
/* Seed/update after idle physical initialization, not by mounting a catalog.
 * Service retains its fresh identify result here, including on mismatch. */
static inline void np_usb_sd_format_observe(NpUsbSdFormat *f,const NpUsbSdFormatIdentity *identity,int ready)
{f->observed=*identity;f->card_ready=ready?1U:0U;}
/* Return0 for an accepted request or exact last-request retry. INFO contains
 * its cached operation outcome, including FAILED. Rejections returned here
 * do not replace that transaction/outcome; adapter must report the rejection. */
static inline int np_usb_sd_format_submit(NpUsbSdFormat *f,const uint8_t *request,uint32_t length)
{
    if(!request || length!=64U ||
       np_usb_sd_format_word(request)!=NP_USB_SD_FORMAT_REQUEST_MAGIC ||
       np_usb_sd_format_word(request+4)!=1U || np_usb_sd_format_word(request+8)!=1U ||
       !np_usb_sd_format_word(request+12) ||
       np_usb_sd_format_word(request+16)<=NP_USB_SD_FORMAT_NEXT_START ||
       np_usb_sd_format_word(request+48)!=NP_USB_SD_FORMAT_CONFIRM ||
       np_usb_sd_format_word(request+52) || np_usb_sd_format_word(request+56) ||
       np_usb_sd_format_word(request+60)!=np_sd_metadata_crc_fast(request,60))return NP_USB_SD_FORMAT_FRAME;
    uint32_t transaction=np_usb_sd_format_word(request+12);
    if(f->transaction==transaction)
        return memcmp(f->request,request,64)?NP_USB_SD_FORMAT_TRANSACTION:NP_USB_SD_FORMAT_OK;
    if(f->state==NP_USB_SD_FORMAT_QUEUED || f->state==NP_USB_SD_FORMAT_RUNNING)return NP_USB_SD_FORMAT_BUSY;
    memcpy(f->request,request,64);f->expected.capacity=np_usb_sd_format_word(request+16);
    for(unsigned i=0;i<3;++i)f->expected.uid[i]=np_usb_sd_format_word(request+20+4*i);
    for(unsigned i=0;i<4;++i)f->expected.cid[i]=np_usb_sd_format_word(request+32+4*i);
    f->transaction=transaction;f->error=NP_USB_SD_FORMAT_OK;f->state=NP_USB_SD_FORMAT_QUEUED;
    return NP_USB_SD_FORMAT_OK;
}
static inline int np_usb_sd_format_sector(NpUsbSdFormat *f,uint32_t lba,const uint8_t *expected,uint8_t *readback)
{
    if(f->io.write(f->io.context,lba,expected))return NP_USB_SD_FORMAT_WRITE;
    if(f->io.read(f->io.context,lba,readback))return NP_USB_SD_FORMAT_READ;
    return memcmp(expected,readback,512)?NP_USB_SD_FORMAT_VERIFY:NP_USB_SD_FORMAT_OK;
}
static inline void np_usb_sd_format_service(NpUsbSdFormat *f)
{
    static const uint8_t zero[512]={0};
    static const uint32_t clear_lba[]={NP_USB_SD_FORMAT_IDENT_LBA,NP_USB_SD_FORMAT_LOG_LBA,
        NP_USB_SD_FORMAT_JOURNAL_LBA,NP_USB_SD_FORMAT_SHADOW_LBA};
    NpUsbSdFormatIdentity actual={0};uint8_t readback[512],identity[512]={0};
    int error=NP_USB_SD_FORMAT_OK;
    if(f->state!=NP_USB_SD_FORMAT_QUEUED)return;
    f->state=NP_USB_SD_FORMAT_RUNNING;
    if(!f->io.identify || !f->io.busy || !f->io.read || !f->io.write)error=NP_USB_SD_FORMAT_CALLBACK;
    /* identify may reinitialize the physical SD controller; never call it
     * while capture/download/mode transition owns that controller. */
    else if(f->io.busy(f->io.context))error=NP_USB_SD_FORMAT_BUSY;
    else{
        int ready=!f->io.identify(f->io.context,&actual);
        np_usb_sd_format_observe(f,&actual,ready);
        if(!ready)error=NP_USB_SD_FORMAT_NO_CARD;
        else if(!np_usb_sd_format_same(&actual,&f->expected))error=NP_USB_SD_FORMAT_IDENTITY;
        else if(f->io.busy(f->io.context))error=NP_USB_SD_FORMAT_BUSY;
    }
    /* Verify invalidation before altering the catalog. Publish NP identity
     * last, only after the empty catalog and both journal sectors read back. */
    for(unsigned i=0;!error && i<4;++i)
        error=np_usb_sd_format_sector(f,clear_lba[i],zero,readback);
    if(!error){
        memcpy(identity,"CE_FILESYSTEM_V1",16);memcpy(identity+32,"NP_CE64_1",9);
        error=np_usb_sd_format_sector(f,NP_USB_SD_FORMAT_IDENT_LBA,identity,readback);
    }
    f->error=(uint32_t)error;f->state=error?NP_USB_SD_FORMAT_FAILED:NP_USB_SD_FORMAT_DONE;
}
static inline void np_usb_sd_format_info(const NpUsbSdFormat *f,uint8_t reply[64])
{
    const NpUsbSdFormatIdentity *actual=&f->observed;
    uint32_t ready=f->card_ready;
    uint32_t next=f->state==NP_USB_SD_FORMAT_DONE && ready &&
        np_usb_sd_format_same(actual,&f->expected)?NP_USB_SD_FORMAT_NEXT_START:0U;
    memset(reply,0,64);
    np_usb_sd_format_put(reply,NP_USB_SD_FORMAT_INFO_MAGIC);np_usb_sd_format_put(reply+4,1U);
    np_usb_sd_format_put(reply+8,f->state);np_usb_sd_format_put(reply+12,f->error);
    np_usb_sd_format_put(reply+16,f->transaction);
    np_usb_sd_format_put(reply+20,ready?actual->capacity:0U);
    for(unsigned i=0;i<3;++i)np_usb_sd_format_put(reply+24+4*i,actual->uid[i]);
    if(ready)for(unsigned i=0;i<4;++i)np_usb_sd_format_put(reply+36+4*i,actual->cid[i]);
    np_usb_sd_format_put(reply+52,next);np_usb_sd_format_put(reply+56,1U|(ready?2U:0U));
    np_usb_sd_format_put(reply+60,np_sd_metadata_crc_fast(reply,60));
}
#endif
