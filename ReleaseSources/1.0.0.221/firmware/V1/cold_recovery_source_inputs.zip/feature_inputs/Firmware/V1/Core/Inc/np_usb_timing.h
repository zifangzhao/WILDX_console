#ifndef NP_USB_TIMING_H
#define NP_USB_TIMING_H
#include <stdint.h>
#include <string.h>
#include "np_capture_anchor.h"

/* Frozen common USB timing R2. No HAL, I/O, counter mutation or allocation.
 * Caller serializes short state transitions against the USB OUT callback.
 * Claim/CRC/seal run in foreground; commit ONLY after queue publication. */
#define NPT_BYTES 108U
#define NPT_OFFSET 192U
#define NPT_FEATURE 8U
#define NPT_B 0x4254504eU
#define NPT_M 0x4d54504eU
#define NPT_Q 0x5154504eU
#define NPT_N 0x4e54504eU
#define NPT_I 0x4954504eU
#define NPT_VALID 1U
#define NPT_FINE 2U
#define NPT_PREARM 4U
#define NPT_BUSY 8U
#define NPT_REJECTED 16U

typedef struct {
    volatile uint64_t token;
    uint64_t last_token;
    uint32_t uid[3];
    volatile uint32_t generation,epoch,last_id,busy,rejected,busy_reported,rejected_reported;
    volatile uint32_t pending,pending_id,start_ready,start_sent,staged,last_ms,have_ms;
    uint8_t request[64],start[2][64];
    NpTimePoint rx;
} NpUsbTiming;
typedef struct {
    uint64_t token;
    uint32_t uid[3],epoch,generation,last_id,admitted_id,kind,id,busy,rejected,flags;
    uint8_t body[64];
    NpTimePoint rx;
} NpTimeWork;

static inline uint32_t npt_u32(const uint8_t *p)
{return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static inline uint64_t npt_u64(const uint8_t *p)
{return (uint64_t)npt_u32(p)|((uint64_t)npt_u32(p+4)<<32);}
static inline void npt_put(uint8_t *p,uint32_t v)
{for(unsigned i=0;i<4;i++)p[i]=(uint8_t)(v>>(8*i));}
static inline void npt_put64(uint8_t *p,uint64_t v)
{npt_put(p,(uint32_t)v);npt_put(p+4,(uint32_t)(v>>32));}
static inline uint32_t npt_crc(const uint8_t *p,unsigned n)
{
    uint32_t c=~0U;
    while(n--){c^=*p++;for(unsigned i=0;i<8;i++)c=(c>>1)^((0U-(c&1U))&0xedb88320U);}
    return ~c;
}
static inline int npt_zero(const uint8_t *p,unsigned n)
{while(n--)if(*p++)return 0;return 1;}
static inline void npt_increment(volatile uint32_t *p){if(*p!=UINT32_MAX)++*p;}
static inline void npt_cancel(NpUsbTiming *t)
{
    t->pending=t->pending_id=t->start_ready=t->start_sent=t->staged=0U;
    ++t->epoch;
}
static inline void npt_disable(NpUsbTiming *t)
{npt_cancel(t);t->token=0U;t->have_ms=0U;}
static inline void npt_generation(NpUsbTiming *t,uint32_t generation)
{
    if(t->generation!=generation){
        if(t->pending)npt_increment(&t->rejected);
        npt_cancel(t);t->generation=generation;
    }
}
static inline void npt_observe(NpUsbTiming *t,const NpTimePoint *p)
{
    if(t->token){
        if(!p->hal_valid || (t->have_ms && p->ms-t->last_ms>=0x80000000U)){
            npt_increment(&t->rejected);npt_disable(t);
        }else {t->last_ms=p->ms;t->have_ms=1U;}
    }
    npt_generation(t,p->generation);
}
static inline int npt_negotiate(NpUsbTiming *t,const uint8_t q[64],int admitted)
{
    uint32_t enable=npt_u32(q+4)>>16;
    uint64_t token=npt_u64(q+8);
    if(!admitted || npt_u32(q)!=NPT_N || (npt_u32(q+4)&0xffffU)!=1U || enable>1U ||
       npt_u32(q+60)!=npt_crc(q,60) || memcmp(q+16,t->uid,12) || !npt_zero(q+28,32) ||
       (enable?(!token || token==t->last_token):token!=0U)){
        npt_increment(&t->rejected);return 0;
    }
    npt_cancel(t);t->token=token;t->have_ms=0U;
    if(enable)t->last_token=token;
    t->last_id=t->busy=t->rejected=t->busy_reported=t->rejected_reported=0U;
    return 1;
}
static inline void npt_info(const NpUsbTiming *t,uint32_t gen,int compatible,uint8_t out[64])
{
    memset(out,0,64);npt_put(out,NPT_I);npt_put(out+4,1U|((1U|(t->token?2U:0U)|(compatible?4U:0U))<<16));
    npt_put64(out+8,t->token);memcpy(out+16,t->uid,12);npt_put(out+28,1000U);
    npt_put(out+32,gen);npt_put(out+36,7U); /* optional read-only fine provider exists */
    npt_put(out+40,NPT_BYTES);npt_put(out+44,1U);npt_put(out+48,NPT_OFFSET);npt_put(out+52,1U);
    npt_put(out+60,npt_crc(out,60));
}
/* Callback: exact copy and time latch only. CRC/content are foreground work. */
static inline void npt_receive(NpUsbTiming *t,const uint8_t *q,unsigned bytes,
    const NpTimePoint *rx,int active)
{
    if(!t->token)return;
    if(!active || bytes!=64U || !rx->hal_valid){npt_increment(&t->rejected);return;}
    if(t->pending){npt_increment(&t->busy);return;}
    memcpy(t->request,q,64);t->rx=*rx;t->pending_id=0U;t->pending=1U;
}
/* Validate private startup bytes in foreground, never under the state guard. */
static inline int npt_start_valid(const uint8_t a[64],const uint8_t h[64])
{
    return npt_u32(a)==0x5241504eU && npt_u32(a+4)==1U &&
        npt_u32(a+60)==npt_crc(a,60) && npt_u32(h)==0x5248504eU && npt_u32(h+4)==1U &&
        npt_u32(a+16)==npt_u32(h+20) && npt_u32(h+60)==npt_crc(h,60);
}
/* Caller holds the short state guard after npt_start_valid. A cancel, new
 * token or generation during foreground packing must not relabel old bytes. */
static inline int npt_cache_start(NpUsbTiming *t,const NpTimeWork *snapshot,
    const uint8_t a[64],const uint8_t h[64])
{
    if(!t->token || t->start_ready || t->token!=snapshot->token || t->epoch!=snapshot->epoch ||
       t->generation!=snapshot->generation || npt_u32(a+16)!=t->generation ||
       npt_u32(h+20)!=t->generation || memcmp(h+48,t->uid,12))return 0;
    memcpy(t->start[0],a,64);memcpy(t->start[1],h,64);t->start_ready=1U;return 1;
}
/* A failed/private publication leaves both clock and startup receipts pending. */
static inline void npt_begin(NpUsbTiming *t)
{t->staged=0U;if(t->pending==2U)t->pending=1U;}
static inline int npt_needed(const NpUsbTiming *t)
{return t->token && (t->pending || (t->start_ready && t->start_sent!=3U));}
static inline int npt_claimable(const NpUsbTiming *t)
{return t->token && (t->pending==1U || (t->start_ready && ((t->start_sent|t->staged)&3U)!=3U));}
static inline int npt_claim(NpUsbTiming *t,NpTimeWork *w)
{
    if(!npt_claimable(t))return 0;
    /* No zeroing under the IRQ guard. Every field used by the selected kind
     * is assigned here; the wire only uses the complete copied body. */
    w->id=0U;w->token=t->token;w->epoch=t->epoch;w->generation=t->generation;
    memcpy(w->uid,t->uid,12);w->last_id=t->last_id;w->admitted_id=t->pending_id;
    w->busy=t->busy;w->rejected=t->rejected;
    w->flags=(t->busy!=t->busy_reported?NPT_BUSY:0U)|(t->rejected!=t->rejected_reported?NPT_REJECTED:0U);
    if(t->pending==1U){
        t->pending=2U;w->kind=1U;memcpy(w->body,t->request,64);w->rx=t->rx;return 1;
    }
    if(t->start_ready){
        for(unsigned i=0;i<2;i++)if(!((t->start_sent|t->staged)&(1U<<i))){
            t->staged|=1U<<i;w->kind=i+2U;memcpy(w->body,t->start[i],64);return 1;
        }
    }
    return 0;
}
static inline int npt_same(const NpUsbTiming *t,const NpTimeWork *w)
{return t->token==w->token && t->epoch==w->epoch && t->generation==w->generation;}
static inline void npt_reject(NpUsbTiming *t,const NpTimeWork *w)
{
    if(npt_same(t,w)){
        if(w->kind==1U)t->pending=t->pending_id=0U;
        npt_increment(&t->rejected);
    }
}
static inline int npt_request_valid(const NpTimeWork *w)
{
    const uint8_t *q=w->body;uint32_t id=npt_u32(q+8);
    return npt_u32(q)==NPT_Q && npt_u32(q+4)==0x00010001U && id &&
        (id>w->last_id || (id==w->last_id && id==w->admitted_id)) &&
        !npt_u32(q+12) && npt_u64(q+16)==w->token && npt_u32(q+24)==w->generation &&
        npt_zero(q+28,32) && npt_u32(q+60)==npt_crc(q,60);
}
static inline void npt_envelope(const NpTimeWork *w,uint64_t sequence,uint8_t out[NPT_BYTES])
{
    memset(out,0,NPT_BYTES);npt_put(out,NPT_B);npt_put(out+4,1U|(w->kind<<16));
    npt_put64(out+8,w->token);npt_put(out+16,w->generation);memcpy(out+20,w->uid,12);
    npt_put64(out+32,sequence);memcpy(out+40,w->body,64);npt_put(out+104,npt_crc(out,104));
}
static inline int npt_clock(NpTimeWork *w,const NpTimePoint *seal,uint32_t id,uint32_t flags)
{
    if(!id || !w->rx.hal_valid || !seal->hal_valid || w->rx.generation!=w->generation ||
       seal->generation!=w->generation || seal->ms-w->rx.ms>=0x80000000U ||
       w->rx.domain!=seal->domain || w->rx.hz!=seal->hz)return 0;
    int fine=w->rx.domain && w->rx.hz;
    uint32_t words[15]={NPT_M,1U,id,0x100U|NPT_VALID|flags|(fine?NPT_FINE:0U),
        fine?w->rx.domain:0U,w->generation,w->rx.ms,seal->ms,
        fine?w->rx.cycles:0U,fine?seal->cycles:0U,fine?w->rx.hz:1000U,
        fine?seal->root_domain:0U,w->uid[0],w->uid[1],w->uid[2]};
    for(unsigned i=0;i<15;i++)npt_put(w->body+4*i,words[i]);
    npt_put(w->body+60,npt_crc(w->body,60));w->id=id;return 1;
}
static inline int npt_seal(NpTimeWork *w,const NpTimePoint *seal,uint64_t sequence,uint8_t out[NPT_BYTES])
{
    if(seal->generation!=w->generation || !seal->hal_valid)return 0;
    if(w->kind==1U){
        uint32_t id=npt_u32(w->body+8);
        if(!npt_request_valid(w) || !npt_clock(w,seal,id,w->flags))return 0;
    }
    npt_envelope(w,sequence,out);return 1;
}
/* Admission burns an ID even if later publication is canceled. Retrying the
 * SAME retained pending request is not a new host request or a new admission. */
static inline int npt_admit(NpUsbTiming *t,const NpTimeWork *w)
{
    if(!npt_same(t,w) || w->kind!=1U || t->pending!=2U || !w->id ||
       (t->pending_id?w->id!=t->pending_id:w->id<=t->last_id))return 0;
    t->last_id=t->pending_id=w->id;return 1;
}
static inline int npt_commit(NpUsbTiming *t,const NpTimeWork *w)
{
    if(!npt_same(t,w))return 0;
    if(w->kind==1U){
        if(t->pending!=2U || !w->id || w->id!=t->pending_id || w->id!=t->last_id)return 0;
        t->pending=t->pending_id=0U;t->busy_reported=w->busy;t->rejected_reported=w->rejected;
    }else if(w->kind==2U || w->kind==3U)t->start_sent|=1U<<(w->kind-2U);
    else return 0;
    return 1;
}
#endif
