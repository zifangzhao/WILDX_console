#ifndef NP_SD_USB_JOB_STORAGE_H
#define NP_SD_USB_JOB_STORAGE_H

#include <stdint.h>
#include "np_sd_usb_job_journal.h"

/* Marker registers live outside ECC SRAM. The platform must prove ownership,
 * clock/security accessibility and reset provenance before using this port. */
#define NP_V1_JOB_STORAGE_MAGIC UINT32_C(0x31524d4e)

static inline int np_v1_job_storage_ready(const volatile uint32_t marker[2],
                                          int retained_memory_trusted)
{
    return marker && retained_memory_trusted &&
        marker[0] == NP_V1_JOB_STORAGE_MAGIC && marker[1] == ~NP_V1_JOB_STORAGE_MAGIC;
}

/* Called only with explicit first-use/reconciliation authorization and after
 * recorder/card quiescence. Initialize every complete ECC word before making
 * the marker visible. This never modifies the SD card or any user profile. */
static inline int np_v1_job_storage_initialize(volatile uint32_t marker[2],
                                               volatile uint32_t *region,
                                               void (*barrier)(void))
{
    if (!marker || !region || !barrier) return 0;
    marker[0] = 0U; barrier();
    for (unsigned i = 0U; i < NP_V1_JOB_JOURNAL_WORDS; ++i) region[i] = 0U;
    barrier(); marker[1] = ~NP_V1_JOB_STORAGE_MAGIC; barrier();
    marker[0] = NP_V1_JOB_STORAGE_MAGIC; barrier();
    return np_v1_job_storage_ready(marker, 1);
}

/* On an untrusted power/reset transition, invalidate outside SRAM without
 * reading possibly uninitialized ECC contents. Prior job remains UNKNOWN. */
static inline void np_v1_job_storage_invalidate(volatile uint32_t marker[2],
                                                 void (*barrier)(void))
{
    if (marker && barrier) { marker[0] = 0U; barrier(); }
}
#endif
