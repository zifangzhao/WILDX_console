#ifndef NP_V1_FINE_CLOCK_H
#define NP_V1_FINE_CLOCK_H
#include <stdint.h>
#ifndef NP_FINE_COUNTER64_ENABLE
#define NP_FINE_COUNTER64_ENABLE 0
#endif
/* Private V1 observations, not wire or sample/batch layouts. A valid point
 * belongs to one continuous timer/domain; ms is only the coarse wrap check. */
typedef struct {
    uint32_t ms,counter,domain,hz,generation,source_epoch;
} NpV1FinePoint;
typedef struct {
    uint32_t generation,domain,hz,before_ms,after_ms,before_counter,after_counter;
} NpV1FineRoot;
#if NP_FINE_COUNTER64_ENABLE
/* Actual full counter and one cached final-root context; not a wire ABI. */
typedef struct {
    uint64_t counter;
    uint32_t domain,generation,source_epoch,hz;
} NpV1FinePoint64;
int NP_V1FineClockStart64(uint64_t record_token);
int NP_V1FineClockRead64(NpV1FinePoint64 *point);
void NP_V1FineClockOverflow(void); /* Owned TIM5 IRQ only; no HAL dispatch. */
#endif
/* Always a valid function/no-op selected by counter lifecycle setup. These
 * observation leaves never configure clocks, wait, scan, CRC or access SD. */
int NP_V1FineClockRead(NpV1FinePoint *point);
uint32_t NP_V1FineUartHz(void);
void NP_V1FineClockInit(void);
void NP_V1FineClockInvalidate(void);
int NP_V1FineClockStart(uint64_t record_token);
void NP_V1FineRootReset(void);
void NP_V1FineRootBefore(uint32_t generation);
void NP_V1FineRootAfter(uint32_t generation);
int NP_V1FineRootRead(NpV1FineRoot *root);
#endif
