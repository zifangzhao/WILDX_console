#ifndef NP_SENSOR_GRID_SD_H
#define NP_SENSOR_GRID_SD_H
#include "np_imu_grid_wire.h"
#include "np_sensor_grid_phase_wire.h"
#ifndef NP_SENSOR_GRID_ENFORCED
#define NP_SENSOR_GRID_ENFORCED 0
#endif
#define NP_GRID_SD_VERSION (NP_SENSOR_GRID_ENFORCED?2U:1U)

/* Format-6 NP only. The owner stamps before sealing the enclosing sector
 * CRC. A grid declaration does not imply the payload has been committed. */
#define NP_GRID_SD_BEGIN 62144U
#define NP_GRID_SD_LIMIT 65024U
#define NP_GRID_SD_DESCRIPTOR 61632U
#define NP_GRID_SD_CAPACITY (NP_GRID_SD_LIMIT-NP_GRID_SD_BEGIN)
/* kind: 1 header, 2 chunk descriptor, 3 footer. The three reserved words must
 * be untouched. Caller supplies the actual descriptor span, not capacity. */
static inline int np_grid_sd_can_declare(const uint8_t sector[512],unsigned kind,uint32_t span)
{
    const char *magic=kind==1U?"NPSDLOG1":kind==2U?"NPSDBLK1":kind==3U?"NPSDEND1":0;
    if(!sector || !magic || memcmp(sector,magic,8U) || np_imu_grid_u32(sector+8U)!=6U ||
       span>NP_GRID_SD_CAPACITY || (kind!=2U && span) ||
       np_imu_grid_u32(sector+104U) || np_imu_grid_u32(sector+108U) ||
       np_imu_grid_u32(sector+124U))return 0;
    return 1;
}
static inline int np_grid_sd_declare(uint8_t sector[512],unsigned kind,uint32_t span)
{
    if(!np_grid_sd_can_declare(sector,kind,span))return 0;
    memcpy(sector+104U,"NSG1",4U);np_imu_grid_put32(sector+108U,NP_GRID_SD_VERSION);
    if(kind==2U)np_imu_grid_put32(sector+124U,span);
    return 1;
}
/* Header/descriptor/footer CRC covers all bytes before its final CRC word. */
static inline uint32_t np_grid_sd_crc(const uint8_t *p,size_t n)
{
    uint32_t crc=UINT32_MAX;
    while(n--){crc^=*p++;for(unsigned b=0U;b<8U;b++)crc=(crc>>1U)^(UINT32_C(0xedb88320)&(0U-(crc&1U)));}
    return ~crc;
}
static inline int np_grid_sd_stamp(uint8_t sector[512],unsigned kind,uint32_t span)
{
    if(!np_grid_sd_declare(sector,kind,span))return 0;
    np_imu_grid_put32(sector+508U,np_grid_sd_crc(sector,508U));return 1;
}
/* Peek is non-consuming: 1 supplies an immutable frame until the next peek,
 * 0 means empty, negative means source failure. A caller commits *consumed
 * only after the private chunk is accepted into its own stage queue. */
typedef int (*NpGridSdPeek)(void *context,unsigned index,const uint8_t **frame,size_t *bytes);
/* Returns 1 on success, -1 on source/format error, 0 if no format-6 private
 * descriptor was available. On -1 an empty but valid declaration is sealed;
 * neural data is unchanged, and caller must account the missing grid rows. */
static inline int np_grid_sd_chunk(uint8_t chunk[65536],NpGridSdPeek peek,void *context,unsigned *consumed)
{
    uint8_t *descriptor;size_t used=0U;unsigned count=0U;int result=1;
    uint64_t next=0U;uint32_t generation=0U;
    if(!chunk || !consumed || np_imu_grid_overlap(consumed,sizeof(*consumed),chunk,65536U))return 0;
    *consumed=0U;
    descriptor=chunk+NP_GRID_SD_DESCRIPTOR;
    if(!np_grid_sd_can_declare(descriptor,2U,0U))return 0;
    memset(chunk+NP_GRID_SD_BEGIN,0,NP_GRID_SD_CAPACITY);
    while(peek){
        const uint8_t *frame=0;size_t bytes=0U;NpImuGridView view;int available;
        if(NP_GRID_SD_CAPACITY-used<NP_IMU_GRID_HEADER_BYTES)break;
        available=peek(context,count,&frame,&bytes);
        if(!available)break;
        if(available<0 || !frame || bytes>NP_IMU_GRID_MAX_BYTES ||
           np_imu_grid_overlap(frame,bytes,chunk,65536U) || !np_imu_grid_read(frame,bytes,&view) ||
           (count && (view.header.capture_generation!=generation || view.header.first_slot<next))){result=-1;break;}
        if(bytes>NP_GRID_SD_CAPACITY-used)break; /* preserve the unconsumed frame for the next chunk */
        memcpy(chunk+NP_GRID_SD_BEGIN+used,frame,bytes);used+=bytes;
        generation=view.header.capture_generation;next=view.header.first_slot+view.header.slot_count;count++;
    }
    if(result<0){memset(chunk+NP_GRID_SD_BEGIN,0,NP_GRID_SD_CAPACITY);used=0U;count=0U;}
    if(!np_grid_sd_stamp(descriptor,2U,(uint32_t)used))return 0;
    *consumed=count;return result;
}
/* One foreground owner per session. A reservation prevents two staged
 * chunks from publishing the same once-per-session phase companion. */
typedef struct {
    uint32_t uid[3],session,generation,source_epoch,domain;
    uint64_t token;
} NpGridSdIdentity;
typedef struct {
    NpGridSdIdentity identity;
    uint64_t first_slot;
    uint32_t revision,ticket,pending,phase_emitted,first_matched,valid;
} NpGridSdPhaseState;
typedef struct {
    NpGridSdIdentity identity;
    uint64_t first_slot;
    uint32_t revision,ticket,consumed,phase_present,first_matched,valid;
} NpGridSdPhaseTxn;
static inline int np_grid_sd_identity_equal(const NpGridSdIdentity *a,const NpGridSdIdentity *b)
{
    return a->uid[0]==b->uid[0] && a->uid[1]==b->uid[1] && a->uid[2]==b->uid[2] &&
        a->session==b->session && a->generation==b->generation && a->source_epoch==b->source_epoch &&
        a->domain==b->domain && a->token==b->token;
}
/* Begin on a zero-initialized, fresh session state; never reset a live one. */
static inline int np_grid_sd_phase_begin(NpGridSdPhaseState *state,const NpGridSdIdentity *identity)
{
    if(!state || !identity || state->valid || state->pending ||
       np_imu_grid_overlap(state,sizeof(*state),identity,sizeof(*identity)) ||
       !(identity->uid[0]|identity->uid[1]|identity->uid[2]) ||
       (identity->uid[0]&identity->uid[1]&identity->uid[2])==UINT32_MAX || !identity->session ||
       !identity->generation || !identity->source_epoch || !identity->domain || !identity->token)return 0;
    memset(state,0,sizeof(*state));state->identity=*identity;state->valid=1U;return 1;
}
static inline int np_grid_sd_phase_match(const NpGridSdIdentity *a,const NpGridPhaseWire *p)
{
    NpGridSdIdentity b={{p->uid[0],p->uid[1],p->uid[2]},p->session,p->generation,p->source_epoch,p->domain,p->token};
    return np_grid_sd_identity_equal(a,&b);
}
/* Transaction handles are single-use. Commit only after the private chunk is
 * accepted; then retire exactly txn.consumed frames from the source queue.
 * Caller serializes staging, commit and abort against source queue mutation. */
static inline int np_grid_sd_phase_finish(NpGridSdPhaseState *state,NpGridSdPhaseTxn *txn,int commit)
{
    if(!state || !txn || !state->valid || !txn->valid || !state->pending ||
       state->pending!=txn->ticket || state->revision!=txn->revision ||
       !np_grid_sd_identity_equal(&state->identity,&txn->identity))return 0;
    if(commit){
        if(state->revision==UINT32_MAX)return 0;
        if(txn->phase_present){state->phase_emitted=1U;state->first_slot=txn->first_slot;}
        if(txn->first_matched)state->first_matched=1U;
        state->revision++;
    }
    state->pending=0U;txn->valid=0U;return 1;
}
/* Stage an 84-byte NSGP only before this session's first NSG1 frames. The
 * peek callback is non-consuming; a pending/invalid grid leaves a CRC-sealed
 * empty descriptor and never alters neural bytes. -1 means grid evidence was
 * unavailable or invalid; 0 means unsupported descriptor/arguments. */
static inline int np_grid_sd_chunk_phase(uint8_t chunk[65536],NpGridSdPhaseState *state,
    const uint8_t *phase,size_t phase_bytes,NpGridSdPeek peek,void *context,NpGridSdPhaseTxn *txn)
{
    uint8_t *descriptor;size_t used=0U;unsigned count=0U;uint64_t next=0U,first=0U;
    uint32_t matched=0U;int result=1;NpGridPhaseWire p;
    if(!chunk || !state || !txn || np_imu_grid_overlap(chunk,65536U,state,sizeof(*state)) ||
       np_imu_grid_overlap(chunk,65536U,txn,sizeof(*txn)) || np_imu_grid_overlap(state,sizeof(*state),txn,sizeof(*txn)))return 0;
    descriptor=chunk+NP_GRID_SD_DESCRIPTOR;
    if(!np_grid_sd_can_declare(descriptor,2U,0U))return 0;
    memset(chunk+NP_GRID_SD_BEGIN,0,NP_GRID_SD_CAPACITY);
    if(!state->valid || state->pending || state->ticket==UINT32_MAX || state->revision==UINT32_MAX ||
       np_imu_grid_u32(descriptor+12U)!=state->identity.session){result=-1;goto finished;}
    matched=state->first_matched;
    if(!state->phase_emitted){
        if(!phase || np_imu_grid_overlap(phase,phase_bytes,chunk,65536U) ||
           np_imu_grid_overlap(phase,phase_bytes,state,sizeof(*state)) ||
           np_imu_grid_overlap(phase,phase_bytes,txn,sizeof(*txn)) ||
           !np_grid_phase_wire_read(phase,phase_bytes,&p) || !np_grid_sd_phase_match(&state->identity,&p)){
            result=-1;goto finished;
        }
        first=p.first_slot;memcpy(chunk+NP_GRID_SD_BEGIN,phase,NP_GRID_PHASE_BYTES);
        used=NP_GRID_PHASE_BYTES;
    }else{
        if(phase || phase_bytes){result=-1;goto finished;}
        first=state->first_slot;
    }
    while(peek){
        const uint8_t *frame=0;size_t bytes=0U;NpImuGridView view;int available;
        if(NP_GRID_SD_CAPACITY-used<NP_IMU_GRID_HEADER_BYTES)break;
        available=peek(context,count,&frame,&bytes);if(!available)break;
        if(available<0 || !frame || bytes>NP_IMU_GRID_MAX_BYTES ||
           np_imu_grid_overlap(frame,bytes,chunk,65536U) || !np_imu_grid_read(frame,bytes,&view) ||
           view.header.capture_generation!=state->identity.generation ||
           (count && view.header.first_slot<next)){result=-1;goto finished;}
        if(bytes>NP_GRID_SD_CAPACITY-used)break;
        if(!matched && view.header.observed_mask){
            unsigned bit=0U;while(!(view.header.observed_mask&(1U<<bit)))bit++;
            if(view.header.first_slot+bit!=first){result=-1;goto finished;}
            matched=1U;
        }
        memcpy(chunk+NP_GRID_SD_BEGIN+used,frame,bytes);used+=bytes;
        next=view.header.first_slot+view.header.slot_count;count++;
    }
finished:
    if(result<0){memset(chunk+NP_GRID_SD_BEGIN,0,NP_GRID_SD_CAPACITY);used=0U;count=0U;}
    if(!np_grid_sd_stamp(descriptor,2U,(uint32_t)used))return 0;
    if(result<0)return -1;
    state->pending=++state->ticket;
    memset(txn,0,sizeof(*txn));
    txn->identity=state->identity;txn->revision=state->revision;txn->ticket=state->pending;
    txn->consumed=count;txn->phase_present=!state->phase_emitted;txn->first_slot=first;
    txn->first_matched=matched;txn->valid=1U;return 1;
}
/* Only an explicitly declared v6 descriptor enables copying the formerly
 * skipped gap; all existing legacy copy geometry remains unchanged. */
static inline int np_grid_sd_copy_slice(const uint8_t *source,uint32_t *offset,uint32_t *bytes)
{
    const uint8_t *d;uint32_t at,limit;
    if(!source || !offset || !bytes || *offset>=65536U)return 0;
    d=source+NP_GRID_SD_DESCRIPTOR;at=*offset;*bytes=0U;
    int declared=!memcmp(d,"NPSDBLK1",8U) && np_imu_grid_u32(d+8U)==6U &&
        np_imu_grid_u32(d+104U)==NP_IMU_GRID_MAGIC &&
        (np_imu_grid_u32(d+108U)==1U || np_imu_grid_u32(d+108U)==2U) &&
        np_imu_grid_u32(d+124U)<=NP_GRID_SD_CAPACITY;
    if(!declared && at>=NP_GRID_SD_BEGIN && at<NP_GRID_SD_LIMIT){*offset=NP_GRID_SD_LIMIT;return 1;}
    limit=declared?65536U:at<NP_GRID_SD_BEGIN?NP_GRID_SD_BEGIN:65536U;
    *bytes=limit-at;if(*bytes>16384U)*bytes=16384U;return 1;
}
#endif
