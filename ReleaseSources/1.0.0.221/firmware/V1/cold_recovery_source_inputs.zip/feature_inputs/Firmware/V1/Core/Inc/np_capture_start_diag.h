#ifndef NP_CAPTURE_START_DIAG_H
#define NP_CAPTURE_START_DIAG_H
#include <stdint.h>
#ifndef NP_CAPTURE_START_DIAG_ENABLE
#define NP_CAPTURE_START_DIAG_ENABLE 0U
#endif
/* Private cached CPU trace, not a wire/header ABI or fixed ARM address.
 * Read only after the actual worker is terminal/idle, BEFORE image handover.
 * Stop/invalidation do not clear it; reset/image startup necessarily may.
 * Each new arm replaces arm-local fields; TERMINAL_GENERATION publishes them.
 * CONTEXT0..3 are cached session/generation/source-epoch/profile-CRC, not a
 * running/locked claim. BEFORE_STATE is cached root_valid. For a Start64
 * callback AFTER_STATE0/2 is its actual local reject/accept decision; other
 * callback paths only supply cached state. No qualification is inferred. */
enum { NP_START_DIAG_VERSION=0x3144534EU };
enum { NP_SD_VERSION,NP_SD_FLAGS,NP_SD_ARM_GENERATION,NP_SD_TERMINAL_GENERATION,
       NP_SD_READY_FAILURE,NP_SD_PREPARE_RESULT,NP_SD_TERMINAL_RESULT,
       NP_SD_ANCHOR_FLAGS,NP_SD_CLEAN_MASK,NP_SD_BEFORE_STATE,NP_SD_AFTER_STATE,
       NP_SD_ARMS,NP_SD_CONTEXT0,NP_SD_CONTEXT1,NP_SD_CONTEXT2,NP_SD_CONTEXT3,
       NP_SD_WORDS };
enum { NP_START_ROLE_SD=1U,NP_START_ACCEPTED=2U,NP_START_START64_CALLED=4U,
       NP_START_START64_OK=8U,NP_START_ROOT_BEFORE=16U,NP_START_ROOT_AFTER=32U,
       NP_START_FIRST_SOURCE_SET=64U,NP_START_READY=128U };
enum { NP_START_PREPARE_NONE,NP_START_PREPARE_DISABLED,NP_START_PREPARE_MASK,
       NP_START_PREPARE_TIMER,NP_START_PREPARE_DMA,NP_START_PREPARE_CLOCK,
       NP_START_PREPARE_EXTENT,NP_START_PREPARE_OK };
/* First actually evaluated rejecting prerequisite, not a re-read/all-bit mask. */
enum { NP_START_READY_MASK=1U,NP_START_READY_IPSR=2U,NP_START_READY_BASEPRI=4U,
       NP_START_READY_FAULTMASK=8U,NP_START_READY_PHASE=16U,NP_START_READY_MASTER=32U };
#if NP_CAPTURE_START_DIAG_ENABLE
extern volatile uint32_t np_capture_start_diag[NP_SD_WORDS];
void NP_CaptureStartDiagBegin(void);
void NP_CaptureStartDiagFine(int result);
#else
#define NP_CaptureStartDiagBegin() ((void)0)
#define NP_CaptureStartDiagFine(result) ((void)(result))
#endif
#endif
