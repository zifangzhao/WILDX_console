#ifndef NP_SENSOR_GRID_PUBLISH_H
#define NP_SENSOR_GRID_PUBLISH_H
#include <stdint.h>

/* The selected grid-mode foreground publisher calls this only at the cache
 * pointer swap. A pending timer edge must observe the old cache. If the edge
 * arrives while interrupts are masked, roll back the swap before unmasking.
 * The normal legacy publisher does not call this helper. */
#ifndef NP_GRID_PUBLISH_LOCK
#define NP_GRID_PUBLISH_LOCK() (__get_PRIMASK())
#define NP_GRID_PUBLISH_DISABLE() __disable_irq()
#define NP_GRID_PUBLISH_UNLOCK(key) __set_PRIMASK(key)
#define NP_GRID_PUBLISH_BARRIER() __DMB()
#define NP_GRID_PUBLISH_AFTER_SWAP() ((void)0)
#endif
static inline int np_sensor_grid_publish(volatile uint32_t *index,uint32_t next,
    volatile const uint32_t *timer_status,uint32_t pending_mask)
{
    if(!index || !timer_status || !pending_mask)return 0;
    uint32_t key=NP_GRID_PUBLISH_LOCK();NP_GRID_PUBLISH_DISABLE();
    int committed=0;
    if(!(*timer_status&pending_mask)){
        uint32_t previous=*index;
        NP_GRID_PUBLISH_BARRIER();*index=next;NP_GRID_PUBLISH_BARRIER();
        NP_GRID_PUBLISH_AFTER_SWAP();
        if(*timer_status&pending_mask){*index=previous;NP_GRID_PUBLISH_BARRIER();}
        else committed=1;
    }
    NP_GRID_PUBLISH_UNLOCK(key);return committed;
}
#endif
