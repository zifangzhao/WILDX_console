#ifndef NP_PSRAM_PROFILE_H
#define NP_PSRAM_PROFILE_H

#include "xe_np_psram_timing.h"
#include "np_sd_rate_port.h"

/* V2-derived, startup-only V1 PSRAM experiment. Not a rated operating point.
 * The builder replaces this one frequency for the matched 120 MHz control.
 * 187.2 MHz uses SYSCLK; PLL2Q remains dedicated to 120 MHz SD service. */
#define NP_PSRAM_KERNEL_HZ NP_SD_RateCoreHz()
#define NP_PSRAM_SD_KERNEL_HZ 120000000UL
#define NP_PSRAM_CORE_HZ NP_SD_RateCoreHz()
#define NP_PSRAM_SLOW_DIV XE_NP_PSRAM_SLOW_DIV_FOR(NP_PSRAM_KERNEL_HZ)
#define NP_PSRAM_CSHT_CYCLES XE_NP_PSRAM_CSHT_FOR(NP_PSRAM_KERNEL_HZ)
/* End a continuous CE# selection after at most 2.5 us, below the extended
 * temperature part's 3 us refresh limit. Retain the 1 KiB page boundary. */
#define NP_PSRAM_REFRESH_CYCLES XE_NP_PSRAM_REFRESH_FOR(NP_PSRAM_KERNEL_HZ)
#define NP_PSRAM_HSLV_GPIOA (1UL << 3)
#define NP_PSRAM_HSLV_GPIOD (0x1FUL << 3)

#define NP_PSRAM_CHECK_PROFILE(hz) \
_Static_assert((hz)<=33000000ULL*XE_NP_PSRAM_SLOW_DIV_FOR(hz),"PSRAM ID <=33 MHz"); \
_Static_assert(XE_NP_PSRAM_CSHT_FOR(hz)>=1U && XE_NP_PSRAM_CSHT_FOR(hz)<=8U,"PSRAM CSHT field"); \
_Static_assert(XE_NP_PSRAM_CSHT_FOR(hz)*1000000000ULL>=(hz)*18ULL,"PSRAM CE high >=18 ns"); \
_Static_assert((XE_NP_PSRAM_REFRESH_FOR(hz)+1ULL)*1000000ULL<(hz)*3ULL,"PSRAM refresh <3 us")
NP_PSRAM_CHECK_PROFILE(187200000UL);
NP_PSRAM_CHECK_PROFILE(124800000UL);
#undef NP_PSRAM_CHECK_PROFILE

#endif
