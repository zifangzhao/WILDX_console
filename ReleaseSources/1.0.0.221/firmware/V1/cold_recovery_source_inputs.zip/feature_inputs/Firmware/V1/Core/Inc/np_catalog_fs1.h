#ifndef NP_CATALOG_FS1_H
#define NP_CATALOG_FS1_H
#include "np_catalog_preserve.h"
#include "np_ce64.h"

/* Inspect only: even a complete journal is not authority to shrink or rewrite
 * an existing allocation. Both physical and proposed chains must be known.
 * The caller owns a zeroed plan and an exclusive, stable stopped-time reader. */
static int np_catalog_fs1_inspect(const NpcrReadIo *io,uint32_t capacity,NpcrPlan *p)
{
    union {uint8_t bytes[512];NpCe64SysLog log;} page,shadow;
    uint8_t journal[512],original[512];
    uint32_t target=0U,seen=0U,previous[2]={NP_CE64_DATA,NP_CE64_DATA};
    uint32_t count[2]={0U,0U},done[2]={0U,0U};
    if(!p || capacity<=NP_CE64_DATA)return NPCR_CATALOG;
    int error=npcr_read(io,p,NP_CE64_IDENT,page.bytes);
    if(error)return error;
    if(memcmp(page.bytes,"CE_FILESYSTEM_V1",16U) ||
       memcmp(page.bytes+32U,"NP_CE64_1",9U))return NPCR_CATALOG;
    p->layout=NPCR_FS1;p->flags|=NPCR_FS1;
    error=npcr_read(io,p,NP_CE64_JOURNAL,journal);
    if(error)return error;
    unsigned nonzero=0U;
    for(unsigned i=0U;i<512U;i++)nonzero|=journal[i];
    if(nonzero){
        target=np_get32(journal+8U);
        if(memcmp(journal,"NPC64TX1",8U) ||
           target<NP_CE64_LOG || target>=NP_CE64_LOG+NP_CE64_MAX_LOG_BLOCKS ||
           np_get32(journal+508U)!=np_crc32(journal,508U))return NPCR_CATALOG;
        error=npcr_read(io,p,NP_CE64_JOURNAL+1U,shadow.bytes);
        if(error)return error;
        if(np_get32(journal+12U)!=np_crc32(shadow.bytes,512U))return NPCR_CATALOG;
    }
    for(uint32_t block=0U;block<NP_CE64_MAX_LOG_BLOCKS;block++){
        if(done[0] && done[1])break;
        uint32_t lba=NP_CE64_LOG+block;
        error=npcr_read(io,p,lba,page.bytes);
        if(error)return error;
        if(lba==target){
            const NpCe64SysLog *after=&shadow.log;
            if(done[0] || done[1] || page.log.count>NP_CE64_ENTRIES ||
               after->count>NP_CE64_ENTRIES || after->count<page.log.count ||
               after->continued!=page.log.continued)return NPCR_CATALOG;
            for(unsigned i=0U;i<page.log.count;i++)
                if(after->end[i]!=page.log.end[i] ||
                   after->event_end[i]!=page.log.event_end[i])return NPCR_CATALOG;
            /* A no-op must really be identical; spare bytes are not a repair
             * surface. With an append, only previously unused entries grow. */
            if(after->count==page.log.count && memcmp(page.bytes,shadow.bytes,512U))return NPCR_CATALOG;
            memcpy(original,page.bytes,512U);seen=1U;
        }
        for(unsigned chain=0U;chain<2U;chain++){
            if(done[chain])continue;
            const NpCe64SysLog *log=chain && lba==target?&shadow.log:&page.log;
            if(np_ce64_valid_log(log,previous[chain],capacity))return NPCR_CATALOG;
            if(log->count)previous[chain]=log->end[log->count-1U];
            count[chain]+=log->count;
            if(log->count<NP_CE64_ENTRIES)done[chain]=1U;
        }
    }
    if(!done[0] || !done[1] || (target && !seen) || count[1]<count[0] ||
       previous[1]<previous[0] || previous[0]>UINT32_MAX-8191U ||
       previous[1]>UINT32_MAX-8191U)return NPCR_CATALOG;
    p->next_lba=(previous[1]+8191U)&~8191U;p->count=count[1];
    if(p->next_lba>=capacity)p->flags|=NPCR_FULL;
    if(target){
        uint8_t zero[512]={0};
        if(npcr_change(p,target,original,shadow.bytes) ||
           npcr_change(p,NP_CE64_JOURNAL,journal,zero))return NPCR_CATALOG;
    }
    return NPCR_OK;
}
#endif
