#ifndef NP_SD_USB_JOB_PROFILE_H
#define NP_SD_USB_JOB_PROFILE_H

#include <stdint.h>
#include "np_usb_sd_test.h"
#include "np_sd_rate_plan.h"

/* BKP12..15 hold ticket low/high, compact original profile and its inverse.
 * BKP16/17 commit and CRC those four words before BKP20..23 can change.
 * No retained SRAM access is required to recover the normal profile. */
#define NP_V1_JOB_PROFILE_MAGIC UINT32_C(0x3150464e)
#define NP_V1_JOB_PROFILE_PACK UINT32_C(0x4E500100)
#define NP_V1_JOB_PROFILE_ZERO UINT32_C(0x4E500000)

static inline uint32_t np_v1_job_profile_crc(const volatile uint32_t saved[4])
{
    uint8_t bytes[16];
    for (unsigned i=0; i<4U; ++i) np_usb_sd_put32(bytes+4U*i,saved[i]);
    return np_usb_sd_crc(bytes,sizeof(bytes));
}

/* A virgin all-zero profile has the same effective boot settings as the
 * baseline default, but is restored byte-for-byte as zeros. Other invalid
 * saved profiles are rejected before any change to the profile registers. */
static inline int np_v1_job_profile_decode(const volatile uint32_t saved[4],
                                            uint32_t *mask, uint32_t *hz)
{
    static const uint32_t rates[5]={0U,7500U,15000U,20000U,30000U};
    uint32_t packed,index,m;
    if (!saved || !mask || !hz) return 0;
    packed=saved[2];
    if (saved[3]!=~packed) return 0;
    if (packed==NP_V1_JOB_PROFILE_ZERO) { *mask=3U; *hz=15000U; return 1; }
    if ((packed & ~UINT32_C(0x3f)) != NP_V1_JOB_PROFILE_PACK) return 0;
    m=packed&7U; index=(packed>>3U)&7U;
    if (index>=5U || !np_sd_rate_valid(m,rates[index])) return 0;
    *mask=m; *hz=rates[index]; return 1;
}

static inline int np_v1_job_profile_pending(const volatile uint32_t marker[2],
                                            const volatile uint32_t saved[4])
{
    uint32_t mask,hz;
    return marker && saved && marker[0]==NP_V1_JOB_PROFILE_MAGIC &&
        marker[1]==np_v1_job_profile_crc(saved) &&
        np_v1_job_profile_decode(saved,&mask,&hz);
}

static inline int np_v1_job_profile_stage(volatile uint32_t marker[2],
                                           volatile uint32_t saved[4],
                                           volatile uint32_t profile[4],
                                           uint32_t mask,uint32_t hz,uint64_t ticket,
                                           void (*barrier)(void))
{
    uint32_t packed,index,cookie;
    if (!marker || !saved || !profile || !barrier || !ticket || !mask ||
        !np_sd_rate_valid(mask,hz) || marker[0]) return 0;
    if (!(profile[0]|profile[1]|profile[2]|profile[3])) packed=NP_V1_JOB_PROFILE_ZERO;
    else {
        if (!np_sd_rate_cookie_valid(profile[0],profile[1],profile[2],profile[3])) return 0;
        index=profile[1]==0U?0U:profile[1]==7500U?1U:profile[1]==15000U?2U:
              profile[1]==20000U?3U:4U;
        packed=NP_V1_JOB_PROFILE_PACK | profile[0] | (index<<3U);
    }
    marker[0]=0U; barrier();
    saved[0]=(uint32_t)ticket; saved[1]=(uint32_t)(ticket>>32U);
    saved[2]=packed; saved[3]=~packed; barrier();
    marker[1]=np_v1_job_profile_crc(saved); barrier();
    marker[0]=NP_V1_JOB_PROFILE_MAGIC; barrier();
    if (!np_v1_job_profile_pending(marker,saved)) return 0;
    cookie=np_sd_rate_cookie(mask,hz);
    profile[3]=0U; barrier();
    profile[0]=mask; profile[1]=hz; profile[2]=cookie; barrier();
    profile[3]=~cookie; barrier();
    return np_sd_rate_cookie_valid(profile[0],profile[1],profile[2],profile[3]) &&
        profile[0]==mask && profile[1]==hz;
}

/* Keep the committed backup marker through every profile write and verify;
 * any interruption retries the same restoration on the next startup. */
static inline int np_v1_job_profile_restore(volatile uint32_t marker[2],
                                             const volatile uint32_t saved[4],
                                             volatile uint32_t profile[4],
                                             void (*barrier)(void))
{
    uint32_t mask,hz,cookie,expected[4];
    if (!profile || !barrier || !np_v1_job_profile_pending(marker,saved) ||
        !np_v1_job_profile_decode(saved,&mask,&hz)) return 0;
    if (saved[2]==NP_V1_JOB_PROFILE_ZERO) expected[0]=expected[1]=expected[2]=expected[3]=0U;
    else { cookie=np_sd_rate_cookie(mask,hz); expected[0]=mask; expected[1]=hz;
           expected[2]=cookie; expected[3]=~cookie; }
    profile[3]=0U; barrier();
    for (unsigned i=0;i<3U;++i) profile[i]=expected[i];
    barrier(); profile[3]=expected[3]; barrier();
    for (unsigned i=0;i<4U;++i) if (profile[i]!=expected[i]) return 0;
    marker[0]=0U; barrier(); return marker[0]==0U;
}
#endif
