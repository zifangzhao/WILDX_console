#ifndef NP_USB_DOWNLOAD_LINK_H
#define NP_USB_DOWNLOAD_LINK_H

/* Private causal diagnostic only. Normal unified service remains HS. */
#ifndef NP_USB_DOWNLOAD_FS_DIAGNOSTIC
#define NP_USB_DOWNLOAD_FS_DIAGNOSTIC 0
#endif
#ifndef NP_USB_DOWNLOAD_SHORT_DIAGNOSTIC
#define NP_USB_DOWNLOAD_SHORT_DIAGNOSTIC 0
#endif

static inline unsigned NP_USB_DownloadLinkFs(void)
{
#if NP_USB_DOWNLOAD_FS_DIAGNOSTIC
    extern int NP_USB_IsDownload(void);
    return NP_USB_IsDownload() != 0;
#else
    return 0U;
#endif
}

static inline unsigned NP_USB_DownloadLinkMps(void)
{
    return NP_USB_DownloadLinkFs() ? 64U : 512U;
}

static inline unsigned NP_USB_DownloadShortReplies(void)
{
#if NP_USB_DOWNLOAD_SHORT_DIAGNOSTIC
    extern int NP_USB_IsDownload(void);
    return NP_USB_IsDownload() != 0;
#else
    return NP_USB_DownloadLinkFs();
#endif
}

static inline unsigned NP_USB_DownloadReadLimit(unsigned configured)
{
    /* 32 + 120*512 bytes = 961 FS packets, within DIEPTSIZ.PKTCNT. */
    return NP_USB_DownloadShortReplies() && configured > 120U ? 120U : configured;
}
#endif
