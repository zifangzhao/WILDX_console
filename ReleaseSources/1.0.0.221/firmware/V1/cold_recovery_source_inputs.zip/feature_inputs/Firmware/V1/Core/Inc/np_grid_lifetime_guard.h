#ifndef NP_GRID_LIFETIME_GUARD_H
#define NP_GRID_LIFETIME_GUARD_H
#include <stdint.h>
#include <string.h>

/* Internal foreground-only accounting; not a wire record or timing proof.
 * Caller serializes lifecycle events and separately proves any ordering it
 * supplies. Sampled healthy clocks and RTC agreement cannot certify a prefix. */
typedef struct {
    uint32_t session,generation,epoch,domain;
} NpGridLifetimeIdentity;
enum {
    NP_GRID_LIFE_IDENTITY=1U, NP_GRID_LIFE_ORDER=2U,
    NP_GRID_LIFE_GAP_UNKNOWN=4U, NP_GRID_LIFE_HEALTH=8U,
    NP_GRID_LIFE_REARM=16U, NP_GRID_LIFE_BOUNDARY=32U
};
typedef struct {
    NpGridLifetimeIdentity identity;
    uint64_t accounted_next,closed_next;
    uint32_t faults,active,closed,have_checkpoint,closed_accounted,later_fault;
} NpGridLifetimeGuard;
typedef struct {
    NpGridLifetimeIdentity identity;
    uint64_t accounted_next;
    uint32_t faults,closed_accounted,later_fault,qualified;
} NpGridLifetimeView;
static inline int np_grid_lifetime_identity_valid(const NpGridLifetimeIdentity *id)
{return id && id->session && id->generation && id->epoch && id->domain;}
static inline int np_grid_lifetime_same(const NpGridLifetimeIdentity *a,const NpGridLifetimeIdentity *b)
{return np_grid_lifetime_identity_valid(a) && np_grid_lifetime_identity_valid(b) &&
    a->session==b->session && a->generation==b->generation && a->epoch==b->epoch && a->domain==b->domain;}
/* Explicit reset discards the old evidence. Never use it for a late event. */
static inline void np_grid_lifetime_reset(NpGridLifetimeGuard *g)
{if(g)memset(g,0,sizeof(*g));}
static inline int np_grid_lifetime_begin(NpGridLifetimeGuard *g,const NpGridLifetimeIdentity *id)
{
    if(!g)return 0;
    if(g->active || g->closed){g->faults|=NP_GRID_LIFE_REARM;g->closed_accounted=0U;return 0;}
    if(!np_grid_lifetime_identity_valid(id)){g->faults|=NP_GRID_LIFE_IDENTITY;return 0;}
    if(g->faults)return 0; /* Invalid or aborted owner needs an explicit reset. */
    g->identity=*id;g->active=1U;return 1;
}
/* next is the next ordinal already accounted by the producer, NOT a proof
 * of the last physically scheduled, queued, persisted or delivered slot.
 * gap_unambiguous must be backed by the caller's independent counter/lifetime
 * observation; lack of proof, half-wrap or an outage must pass zero. */
static inline int np_grid_lifetime_checkpoint(NpGridLifetimeGuard *g,const NpGridLifetimeIdentity *id,
                                               uint64_t next,int gap_unambiguous,int health_ok)
{
    if(!g)return 0;
    if(!g->active || !np_grid_lifetime_same(&g->identity,id)){
        g->faults|=NP_GRID_LIFE_IDENTITY;g->closed_accounted=0U;return 0;
    }
    if(!gap_unambiguous)g->faults|=NP_GRID_LIFE_GAP_UNKNOWN;
    if(!health_ok)g->faults|=NP_GRID_LIFE_HEALTH;
    if(next==UINT64_MAX || (g->have_checkpoint && next<g->accounted_next))g->faults|=NP_GRID_LIFE_ORDER;
    if(g->faults)return 0;
    g->accounted_next=next;g->have_checkpoint=1U;return 1;
}
/* Explicit closure records only a supplied accounted boundary. It is not a
 * terminal-tail or clock-continuity certificate. No implicit rollover. */
static inline int np_grid_lifetime_close(NpGridLifetimeGuard *g,const NpGridLifetimeIdentity *id,
                                          uint64_t next,int gap_unambiguous,int health_ok)
{
    if(!g)return 0;
    if(!g->active){g->faults|=NP_GRID_LIFE_ORDER;g->closed_accounted=0U;return 0;}
    int ok=np_grid_lifetime_checkpoint(g,id,next,gap_unambiguous,health_ok);
    g->active=0U;g->closed=1U;
    if(ok){g->closed_next=next;g->closed_accounted=1U;}
    else {g->faults|=NP_GRID_LIFE_BOUNDARY;g->closed_accounted=0U;}
    return ok;
}
/* after_closed_proven is an independent event-order witness, not time of
 * notification or mere arrival order. Otherwise the closed boundary is made
 * unknown, even if a fault was delivered after close returned. */
static inline void np_grid_lifetime_fault(NpGridLifetimeGuard *g,const NpGridLifetimeIdentity *id,
                                          uint32_t reason,int after_closed_proven)
{
    if(!g)return;
    if(g->closed && after_closed_proven && np_grid_lifetime_same(&g->identity,id)){
        g->later_fault|=reason?reason:NP_GRID_LIFE_HEALTH;return;
    }
    if(!np_grid_lifetime_same(&g->identity,id))g->faults|=NP_GRID_LIFE_IDENTITY;
    g->faults|=reason?reason:NP_GRID_LIFE_HEALTH;
    g->closed_accounted=0U;
}
static inline int np_grid_lifetime_view(const NpGridLifetimeGuard *g,NpGridLifetimeView *out)
{
    if(!g || !out)return 0;
    memset(out,0,sizeof(*out));out->identity=g->identity;out->faults=g->faults;
    out->closed_accounted=g->closed && g->closed_accounted;
    if(out->closed_accounted)out->accounted_next=g->closed_next;
    out->later_fault=g->later_fault;
    /* No supported independent full-lifetime witness is wired yet. */
    out->qualified=0U;return 1;
}
#endif
