#include "np_v1_rtc_port.h"

#if NP_FIRST_SYNC_ENABLE
#include "np_first_sync_sd_port.h"
#endif
#include "np_config_port.h"
#include "np_config_compile.h"
#include "probe_identity.h"
#include "xe_np_app.h"
#include "CE32_HJ580.h"
#include "CE32_UART_INTERCOM.h"
NpcState np_configuration;
static uint8_t initialized,mailbox[64],answer[64],shank[3][121],base[3][612];
static volatile uint32_t pending,reply_owner,cancelled,generation[3];
static uint32_t processing_generation,processing_owner;
#if NP_HARDWARE_RTC_ENABLE
static uint32_t pending_received_ms;
#endif
#if NP_FIRST_SYNC_ENABLE && NP_SD_APP
#include "np_preparation_wire.h"
extern volatile uint32_t np_mode_mask,np_mode_hz;
static int np_first_identity_status(const uint8_t request[64],uint8_t reply[64])
{
 NpPreparationRequest q;NpPreparationReply r={0};
 if(!np_preparation_parse(request,&q) || q.op!=NP_PREP_STATUS)return 0;
 r.result=NP_PREP_UNSUPPORTED;r.mode=NP_PREP_SD;r.mask=np_mode_mask;r.hz=np_mode_hz;
 r.uid[0]=HAL_GetUIDw0();r.uid[1]=HAL_GetUIDw1();r.uid[2]=HAL_GetUIDw2();
 np_preparation_pack(reply,&q,&r);return 1;
}
#endif

static int busy(void *p){(void)p;return NP_ConfigBusy();}
static int validate(void *p,const uint8_t *b,uint32_t n){(void)p;(void)b;(void)n;
 if(processing_generation!=generation[processing_owner])return NPC_OWNER;
 /* Staging is private RAM, not acquisition. A validated physical port may
  * be configured before its recording mask is selected. Real probe-model
  * compatibility is checked by NP_ConfigPrepare during bring-up. */
 return NPC_OK;}
static int adopt(void *p,const uint8_t *b,uint32_t n){(void)p;(void)b;(void)n;
 if(processing_generation!=generation[processing_owner])return NPC_OWNER;

#if NP_FIRST_SYNC_ENABLE
 NP_FirstCaptureStop();
#endif
 NP_ConfigRearm();
 for(unsigned port=0;port<3;port++)if(np_configuration.valid[port]){
  np_configuration.port_state[port]=NPC_STAGED;np_configuration.verification[port]=0;
 }
 return NPC_OK;}
void NP_ConfigInit(void){if(initialized)return;NpcIo io={0,busy,validate,adopt};npc_init(&np_configuration,io);initialized=1;}
int NP_ConfigSubmit(uint32_t owner,const uint8_t *request,uint32_t length){
#if defined(NP_USB_SD_JOB_ENABLE) && NP_USB_SD_JOB_ENABLE
 extern int NP_V1UsbJobEarlyClaimed(void);
 if(NP_V1UsbJobEarlyClaimed())return 0;
#endif

 if(length!=64 || (owner!=NPC_USB && owner!=NPC_BLE))return 0;
 uint32_t mask=__get_PRIMASK();__disable_irq();
 if(pending){__set_PRIMASK(mask);return 0;}
#if NP_HARDWARE_RTC_ENABLE
 pending_received_ms=HAL_GetTick();
#endif
 memcpy(mailbox,request,64);__DMB();pending=owner;reply_owner=0;__set_PRIMASK(mask);return 1;
}
int NP_ConfigReply(uint32_t owner,uint8_t reply[64]){
 uint32_t mask=__get_PRIMASK();__disable_irq();
 if(reply_owner!=owner){__set_PRIMASK(mask);return 0;}
 memcpy(reply,answer,64);__set_PRIMASK(mask);return 1;
}
void NP_ConfigReplyConsumed(uint32_t owner){
 uint32_t mask=__get_PRIMASK();__disable_irq();
 if(reply_owner==owner)reply_owner=0;__set_PRIMASK(mask);
}
int NP_ConfigTransferPending(void){return pending || np_configuration.owner;}
void NP_ConfigDisconnect(uint32_t owner){
 if(owner!=NPC_USB && owner!=NPC_BLE)return;
 uint32_t mask=__get_PRIMASK();__disable_irq();
 cancelled|=1U<<owner;generation[owner]++;if(reply_owner==owner)reply_owner=0;
 __set_PRIMASK(mask);
}
/* The base application's foreground CE32 dispatcher calls this optional
 * override after it has removed a complete B8/B9 frame from the UART queue.
 * Returning zero transfers ownership, preventing a second consumer from
 * accidentally reading the next command as configuration data. */
#include <stdint.h>
extern int NP_SD_ControlSubmit(const uint8_t *,unsigned);
extern int NP_SD_Ce32RecordingCommandBackend(uint8_t,const uint8_t *,uint32_t);
extern uint32_t NP_SD_Ce32RecordCount(void);
extern int NP_SD_Ce32Dispatch(const uint8_t *,uint32_t);
int XE_NP_App_BleCe32RecordingCommand(uint8_t command,const uint8_t *data,uint32_t length){
 return NP_SD_Ce32RecordingCommandBackend(command,data,length);
}
uint32_t XE_NP_App_BleCe32RecordCount(void){return NP_SD_Ce32RecordCount();}
int XE_NP_App_BleVendorFrame(const uint8_t *data,uint32_t data_len){
 if(!data || data_len!=65U)return -1;

#if NP_FIRST_SYNC_ENABLE
 if(data[0]==0xB8U && np_first_u32(data+1)==NP_FIRST_SD_REQUEST)return NP_FirstSdSubmit(data+1,64U)?0:-1;
#endif
 if(data[0]==0xB8U)return NP_ConfigSubmit(NPC_BLE,data+1,64U)?0:-1;
 if(data[0]==0xB9U)return NP_SD_ControlSubmit(data+1,64U)?0:-1;
 return -1;
}
void NP_ConfigService(void){
 CE32_INTERCOM_Handle *ble=(CE32_INTERCOM_Handle *)&BLE_handle;
 if(!pending && !reply_owner && !cancelled && !np_configuration.owner && !ble->CMD_RX.cmd_pending)return;
 /* Control traffic is deliberately sparse. In the normal streaming loop this
  * is one tick comparison, not repeated critical sections or sensor polling. */
 static uint32_t last_service;uint32_t now=HAL_GetTick();
 if(now-last_service<20U && !ble->CMD_RX.cmd_pending)return;last_service=now;
 NP_ConfigInit();npc_expire(&np_configuration,HAL_GetTick());
 uint32_t mask=__get_PRIMASK();__disable_irq();uint32_t cancel=cancelled;cancelled=0;
 if(pending && (cancel&(1U<<pending)))pending=0;__set_PRIMASK(mask);
 if(cancel&(1U<<NPC_USB))npc_disconnected(&np_configuration,NPC_USB);
 if(cancel&(1U<<NPC_BLE))npc_disconnected(&np_configuration,NPC_BLE);
 if(pending){uint8_t request[64];uint32_t owner;mask=__get_PRIMASK();__disable_irq();
#if NP_HARDWARE_RTC_ENABLE
  uint32_t received_ms=pending_received_ms;
#endif
  owner=pending;processing_owner=owner;processing_generation=generation[owner];memcpy(request,mailbox,64);__set_PRIMASK(mask);
#if NP_HARDWARE_RTC_ENABLE
  if(processing_generation!=generation[owner])memset(answer,0,64U);
  else if(NP_V1RtcPortExchange(request,answer,received_ms,1)){}
  else
#endif

#if NP_FIRST_SYNC_ENABLE && NP_SD_APP
  if(!np_first_identity_status(request,answer))
#endif
  npc_command(&np_configuration,owner,request,HAL_GetTick(),answer);
  mask=__get_PRIMASK();__disable_irq();pending=0;__DMB();reply_owner=processing_generation==generation[owner]?owner:0;__set_PRIMASK(mask);
 }
#if !defined(XE_NP_APP_BLE_CONTROL_DISPATCH)
 /* Pinned recovery sources predate the application's CE32 dispatcher. Keep
  * their B8 ownership local; current source suppresses this whole block and
  * invokes XE_NP_App_BleVendorFrame instead. */
 if(ble->huart && !pending && !reply_owner){
  uint8_t *data,request[64];uint32_t length;int found=0;
  mask=__get_PRIMASK();__disable_irq();
  uint8_t legacy[513];uint32_t legacy_length=0;int sd_found=0;
  if(CE32_INTERCOM_RX_DequeueCmd(ble,&data,&length)==0){
   if(length==65 && data[0]==0xb8){memcpy(request,data+1,64);found=1;}
   else if(length==65 && data[0]==0xb9){memcpy(request,data+1,64);sd_found=1;}
   else if(length<=sizeof(legacy)){memcpy(legacy,data,length);legacy_length=length;}
  }
  __set_PRIMASK(mask);
  if(found){
#if NP_FIRST_SYNC_ENABLE
   if(np_first_u32(request)==NP_FIRST_SD_REQUEST)(void)NP_FirstSdSubmit(request,64U);
   else
#endif
   (void)NP_ConfigSubmit(NPC_BLE,request,64);
  }
  if(sd_found)(void)NP_SD_ControlSubmit(request,64);
  if(legacy_length)(void)NP_SD_Ce32Dispatch(legacy,legacy_length);
 }
#endif
 if(ble->huart && reply_owner==NPC_BLE){
  uint8_t wire[68];wire[0]=0xad;wire[1]=0xb8;memcpy(wire+2,answer,64);wire[66]=wire[67]=0xda;
  if(CE32_INTERCOM_TX_EnqueueCmd(ble,wire,sizeof(wire))==0){NP_ConfigReplyConsumed(NPC_BLE);(void)CE32_INTERCOM_TX_Start_DMA(ble);}
 }
}
int NP_ConfigPrepare(unsigned port,unsigned model,XE_NP_NricConfig *config){
 NP_ConfigInit();if(port>=3)return -1;if(!np_configuration.valid[port])return 0;
 if(np_configuration.port_state[port]==NPC_FAILED || np_configuration.active[port][4]!=model ||
    !config->chain2 || !config->chain3 || config->chain2_bytes!=306 || config->chain3_bytes!=306){npc_applied(&np_configuration,(uint8_t)port,0,0);return -1;}
 memcpy(base[port],config->chain2,306);memcpy(base[port]+306,config->chain3,306);
 if(npc_compile(np_configuration.active[port],shank[port],base[port])){npc_applied(&np_configuration,(uint8_t)port,0,0);return -1;}
 if(model==2){config->chain1=shank[port];config->chain1_bytes=121;}
 config->chain2=base[port];config->chain3=base[port]+306;
 np_configuration.port_state[port]=NPC_STAGED;np_configuration.verification[port]=0;return 0;
}
void NP_ConfigApplied(unsigned port,int success,unsigned model){
 /* NP1 base chains have strict readback; shank ACK-only. NRIC reports only
    the driver's shift-register-ready result, not full image readback. */
 npc_applied(&np_configuration,(uint8_t)port,success,model==2?3U:4U);
}
/* NPM1 v1 offsets: 0 magic, 4 version, 5 port, 6 selection-present,
 * 8..27 identity model/reason/source/serial, 28 version/revision/state/
 * verification, 32 selection CRC, 36 selection byte count, 48 flex[20],
 * 68 part[40], and the exact 1576-byte NPB1 payload at 108. */
int NP_ConfigBuildRecordingManifest(unsigned port,uint8_t *dst,uint32_t bytes){
 const volatile NP_ProbeIdentity *id;
 uint32_t crc=0U,selection_bytes=0U;
 if(!dst || bytes!=NPC_RECORDING_MANIFEST_BYTES || port>=3U)return -1;
 id=&np_probe_identity[port];memset(dst,0,bytes);memcpy(dst,"NPM1",4);
 dst[4]=1U;dst[5]=(uint8_t)port;dst[6]=np_configuration.valid[port]?1U:0U;
 npc_put32(dst+8,id->model);npc_put32(dst+12,id->reason);npc_put32(dst+16,id->source);
 npc_put32(dst+20,id->serial_lo);npc_put32(dst+24,id->serial_hi);
 dst[28]=id->version;dst[29]=id->revision;dst[30]=(uint8_t)np_configuration.port_state[port];
 dst[31]=(uint8_t)np_configuration.verification[port];
 for(unsigned i=0;i<20U;i++)dst[48U+i]=(uint8_t)id->flex[i];
 for(unsigned i=0;i<40U;i++)dst[68U+i]=(uint8_t)id->part[i];
 if(np_configuration.valid[port]){
  selection_bytes=NPC_BYTES;crc=npc_crc(np_configuration.active[port],NPC_BYTES);
  memcpy(dst+108,np_configuration.active[port],NPC_BYTES);
 }
 npc_put32(dst+32,crc);npc_put32(dst+36,selection_bytes);
 return 0;
}

int NP_ConfigRtcPending(void){
#if NP_HARDWARE_RTC_ENABLE
 if(!pending)return 0;__DMB();
 return !memcmp(mailbox,"NPT2",4U) && npc_u32(mailbox+4U)==2U;
#else
 return 0;
#endif
}
