#ifndef XE_NP_USB_SD_TEST_JOB_H
#define XE_NP_USB_SD_TEST_JOB_H
#include <stdint.h>
#include "np_usb_sd_test.h"

#ifndef XE_NP_USB_SD_TEST_ENABLE
#define XE_NP_USB_SD_TEST_ENABLE 0U
#endif

#if XE_NP_USB_SD_TEST_ENABLE
/* Called once before APP/USB initialization; reads and retires reset causes.
 * Role values are internal: APP=1, USB=2. No recording-loop work. */
void XE_NP_UsbSdTest_Boot(uint32_t role);
/* One shot: 1 gives the committed RUNNING plan; -1 is a newly interrupted
 * handoff. Old Unknown/untrusted journals give 0, never START, and must not
 * force an ordinary later APP selection into a USB bounce loop. */
int XE_NP_UsbSdTest_TakeAppPlan(uint8_t plan[128]);
int XE_NP_UsbSdTest_ReadReport(NpUsbSdTestReport *report);
/* Saves one terminal receipt. return_usb requires the physical quiet/closed
 * proof in report (or no-media-mutation rejection), then normal download reset. */
int XE_NP_UsbSdTest_FinishApp(const NpUsbSdTestReport *report,int return_usb);
int XE_NP_UsbSdTest_Active(void);
/* USB foreground only. No queue mutation or CRC work in SETUP/EP0 IRQs. */
int XE_NP_UsbSdTest_QueueUsb(const uint8_t plan[128],const NpUsbSdTestReport *report);
int XE_NP_UsbSdTest_AcceptUsb(void);
int XE_NP_UsbSdTest_RejectUsb(const NpUsbSdTestReport *report);
void XE_NP_UsbSdTest_CacheReport(const NpUsbSdTestReport *report);
const uint8_t *XE_NP_UsbSdTest_CachedReport(void);
uint32_t XE_NP_UsbSdTest_Capability(void);
int XE_NP_UsbSdTest_ExactDuplicate(const uint8_t plan[128]);
void XE_NP_UsbSdTest_LocalControl(int local);
int XE_NP_UsbSdTest_ControlBlocked(void);
#else
#define XE_NP_UsbSdTest_Boot(role) ((void)(role))
static inline int XE_NP_UsbSdTest_Active(void){return 0;}
#endif
#endif
