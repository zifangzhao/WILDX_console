#ifndef XE_NP_NP2_USB_SD_TEST_H
#define XE_NP_NP2_USB_SD_TEST_H
#include "xe_np_hal.h"
#ifndef XE_NP_USB_SD_TEST_ENABLE
#define XE_NP_USB_SD_TEST_ENABLE 0U
#endif
#if XE_NP_USB_SD_TEST_ENABLE
/* Startup only after APP, RTC, BLE and sensors initialized. */
int XE_NP_Np2UsbSdTest_Start(SD_HandleTypeDef *,DCACHE_HandleTypeDef *);
/* Cold path; media_closed is true only after successful terminal seal. */
void XE_NP_Np2UsbSdTest_Terminal(uint32_t media_closed,uint32_t writer_bound);
void XE_NP_Np2UsbSdTest_StartRejected(void);
#else
#define XE_NP_Np2UsbSdTest_Start(card,cache) (0)
#define XE_NP_Np2UsbSdTest_Terminal(closed,bound) ((void)0)
#define XE_NP_Np2UsbSdTest_StartRejected() ((void)0)
#endif
#endif
