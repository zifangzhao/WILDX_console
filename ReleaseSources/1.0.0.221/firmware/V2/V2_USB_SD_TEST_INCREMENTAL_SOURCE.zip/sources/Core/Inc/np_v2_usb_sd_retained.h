#ifndef NP_V2_USB_SD_RETAINED_H
#define NP_V2_USB_SD_RETAINED_H
#include <stdint.h>
#include "np_usb_sd_test.h"

#define NP_V2_SD_RETAINED_BANK_BYTES 512U

/* Caller owns one exclusively accessed byte-addressable retained bank. The
 * barrier must order completed bank writes before later writes, including
 * across reset; on target use the platform's required cache/DSB policy. */
typedef struct {
    volatile uint8_t *bank;
    void (*barrier)(void *context);
    void *context;
} NpV2SdRetained;

typedef struct {
    uint32_t generation,phase,expected_role;
    uint8_t plan[NP_USB_SD_TEST_PLAN_BYTES];
    uint8_t report[NP_USB_SD_TEST_REPORT_BYTES];
} NpV2SdSnapshot;

enum { NP_V2_SD_ROLE_NONE, NP_V2_SD_ROLE_APP, NP_V2_SD_ROLE_USB };
/* The board adapter ORs observed RCC reset causes; only exactly SOFTWARE
 * authorizes a handoff. A missing, mixed or unrecognized bit is unexpected. */
enum { NP_V2_SD_RESET_SOFTWARE=1U, NP_V2_SD_RESET_POWER=2U,
       NP_V2_SD_RESET_PIN=4U, NP_V2_SD_RESET_WATCHDOG=8U,
       NP_V2_SD_RESET_OTHER=16U };
enum { NP_V2_SD_EMPTY=0, NP_V2_SD_VALID=1, NP_V2_SD_CORRUPT=-1 };
enum { NP_V2_SD_NEW=1, NP_V2_SD_DUPLICATE=2, NP_V2_SD_BUSY=-1,
       NP_V2_SD_INVALID=-2, NP_V2_SD_IO_ERROR=-3 };
enum { NP_V2_SD_BOOT_IDLE=0, NP_V2_SD_BOOT_DISPATCH=1,
       NP_V2_SD_BOOT_INTERRUPTED=2, NP_V2_SD_BOOT_INVALID=-1 };

int np_v2_sd_retained_inspect(const NpV2SdRetained *s,NpV2SdSnapshot *out);
/* Explicit stopped/quiet recovery only; never call automatically on corrupt. */
int np_v2_sd_retained_clear(const NpV2SdRetained *s);
/* queued_report is required only for a new ticket; an exact duplicate keeps
 * the previous receipt byte-for-byte. Ticket reuse with changed plan fails. */
int np_v2_sd_retained_submit(const NpV2SdRetained *s,const uint8_t plan[128],
                             const uint8_t queued_report[256]);
/* Explicit operator-selected new test only. The caller must freshly prove
 * UID/card/frontier, idle source and SD, healthy catalog and append readiness.
 * No GET/boot path calls this and it performs no media operations. */
int np_v2_sd_retained_submit_reconciled(const NpV2SdRetained *s,
                                       const uint8_t plan[128],
                                       const uint8_t queued_report[256],
                                       int manual_fresh_proof);
/* Call only after SUBMIT's status stage has completed and been acknowledged.
 * A fresh, device-sealed NP_USB_SD_VALID_HANDOFF bit is also required. */
int np_v2_sd_retained_accept(const NpV2SdRetained *s);
/* APP may dispatch exactly once only on BOOT_DISPATCH. Every other result
 * forbids START. A committed RUNNING precedes the dispatch return. */
int np_v2_sd_retained_boot(const NpV2SdRetained *s,uint32_t reset_flags,uint32_t role);
/* A RUNNING pre-START rejection is allowed only with REJECTED_UNMUTATED.
 * For request_usb=1, caller proves source+SD quiet plus closed catalog after
 * a started recording, or no media mutation for a pre-START rejection. */
int np_v2_sd_retained_finish(const NpV2SdRetained *s,const uint8_t report[256],int request_usb);
/* Only a queued/accepted job with known no-START rejection may be rejected. */
int np_v2_sd_retained_reject(const NpV2SdRetained *s,const uint8_t report[256]);
#endif
