#include "xe_np_np2_usb_sd_test.h"
#if XE_NP_USB_SD_TEST_ENABLE
#include "xe_np_usb_sd_test_job.h"
#include "xe_np_np2_dual_sd_app.h"
#include "xe_np_np2_dual_sd_catalog_port.h"
#include "xe_np_np2_sd_control.h"
#include "xe_np_np2_first_sync_sd.h"
#include "xe_np_np2_first_sync_runtime.h"
#include "xe_np_np2_live_sd.h"
#include "np_first_sync_sd.h"
#include <string.h>

#if !XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_SD_CATALOG_ENABLE || !XE_NP_NP2_SD_GRID16_ENABLE || !XE_NP_NP2_SD_GRID16_APPEND_ENABLE || !XE_NP_NP2_FIRST_SYNC_ENABLE || !NP_FINE_COUNTER64_ENABLE
#error "USB SD test requires the V2 APP, catalog, Grid16 append and first-sync"
#endif
#if !XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
#error "USB SD test requires the NP drain-overflow loss counters"
#endif

static NpUsbSdTestReport report;
static uint32_t active,prior_mask,prior_hz,start_id,have_profile;

static void u64words(unsigned index,uint64_t value)
{report.words[index]=(uint32_t)value;report.words[index+1U]=(uint32_t)(value>>32);}
static uint32_t following_id(uint32_t id){return id==UINT32_MAX?1U:id+1U;}
static uint32_t preceding_id(uint32_t id){return id==1U?UINT32_MAX:id-1U;}
static int control(uint32_t op,uint32_t id,uint32_t mask,uint32_t hz,uint8_t reply[64])
{
    uint8_t q[64]={0};np_first_put32(q,XE_NP_NP2_SD_CONTROL_REQUEST);np_first_put32(q+4,2U);
    np_first_put32(q+8,op);np_first_put32(q+12,id);np_first_put32(q+16,mask);np_first_put32(q+20,hz);
    np_first_put32(q+60,np_first_crc(q,60U));
    XE_NP_UsbSdTest_LocalControl(1);
    int result=XE_NP_Np2SdControl_Exchange(q,reply) || np_first_u32(reply+16)!=0U;
    XE_NP_UsbSdTest_LocalControl(0);return result;
}
/* Conservative conjunction: catalog port checks PSSI/DMA and SD state; do
 * not claim either quiet proof separately when any part remains uncertain. */
static int quiet(void)
{
    if(!XE_NP_Np2DualSdCatalogPort_Ready())return 0;
    report.words[6]|=NP_USB_SD_VALID_SOURCE_QUIET|NP_USB_SD_VALID_SD_QUIET;return 1;
}
static void restore_profile(void)
{
    uint8_t response[64];
    if(!have_profile)return;
    if(!control(1U,following_id(start_id),prior_mask,prior_hz,response))
        report.words[6]|=NP_USB_SD_VALID_PROFILE_RESTORED;
}
static void finish(uint32_t phase,uint32_t outcome,uint32_t no_mutation,uint32_t closed)
{
    XE_NP_Np2LiveSd_WallStatsEnable(0);
    int q;report.words[4]=phase;report.words[5]=outcome;
    report.words[6]&=~(NP_USB_SD_VALID_SOURCE_QUIET|NP_USB_SD_VALID_SD_QUIET);
    if(no_mutation)report.words[6]|=NP_USB_SD_VALID_REJECTED_UNMUTATED;
    q=quiet();
    if(q && closed){
        uint32_t next=0U;
        if(!XE_NP_Np2DualSdCatalog_Reserved() && !XE_NP_Np2DualSdCatalogPort_MountAvailable(&next)){
            uint32_t flags=XE_NP_Np2DualSdCatalog_Status();
            report.words[25]=next;report.words[26]=flags;report.words[6]|=NP_USB_SD_VALID_CATALOG;
            if(!(flags&XE_NP_NP2_CATALOG_RECOVERY))report.words[6]|=NP_USB_SD_VALID_TERMINAL;
        }
    }
    if(q)restore_profile();
    active=0U;
    (void)XE_NP_UsbSdTest_FinishApp(&report,q && (no_mutation || (report.words[6]&NP_USB_SD_VALID_TERMINAL)));
}
static int first_sync(const uint8_t q[64],uint8_t reply[64])
{
    XE_NP_UsbSdTest_LocalControl(1);
    int result=XE_NP_Np2FirstSyncSd_Exchange(q,reply);
    XE_NP_UsbSdTest_LocalControl(0);return result;
}
static int reject(uint32_t outcome)
{finish(NP_USB_SD_PHASE_REJECTED,outcome,1U,0U);return -1;}
int XE_NP_Np2UsbSdTest_Start(SD_HandleTypeDef *card,DCACHE_HandleTypeDef *cache)
{
    uint8_t raw[128],answer[64];uint32_t actual[3],next,mask,hz,blocks,ticks;NpUsbSdTestPlan plan;XE_NP_Grid16Meta planned;
    int taken=XE_NP_UsbSdTest_TakeAppPlan(raw);
    if(taken<0){
        /* This boot never dispatched START. These three flags describe only
         * the present boot and are used by the backend's non-persisting
         * interrupted return path; the previous job stays UNKNOWN. */
        NpUsbSdTestReport interrupted;
        if(XE_NP_UsbSdTest_ReadReport(&interrupted) &&
           interrupted.words[4]==NP_USB_SD_PHASE_INTERRUPTED_UNKNOWN &&
           interrupted.words[5]==NP_USB_SD_OUTCOME_INTERRUPTED &&
           XE_NP_Np2DualSdCatalogPort_Ready()){
            interrupted.words[6]|=NP_USB_SD_VALID_SOURCE_QUIET|NP_USB_SD_VALID_SD_QUIET|
                                  NP_USB_SD_VALID_REJECTED_UNMUTATED;
            (void)XE_NP_UsbSdTest_FinishApp(&interrupted,1);
        }
        return -1;
    }
    if(!taken)return 0;
    if(!XE_NP_UsbSdTest_ReadReport(&report))return -1;
    /* USB's earlier observations are not fresh APP-side facts. Keep the
     * sealed ticket/capabilities and expected-handoff proof, then measure. */
    report.words[6]&=NP_USB_SD_VALID_HANDOFF;
    for(unsigned i=13U;i<63U;i++)report.words[i]=UINT32_MAX;
    active=1U;have_profile=0U;start_id=0U;
    actual[0]=HAL_GetUIDw0();actual[1]=HAL_GetUIDw1();actual[2]=HAL_GetUIDw2();
    report.words[12]=2U;for(unsigned i=0;i<3;i++)report.words[17U+i]=actual[i];
    {static const uint32_t rates[4]={7500U,15000U,20000U,30000U};uint32_t available=0U;
     for(unsigned m=1;m<8;m++)for(unsigned i=0;i<4;i++)
         if(XE_NP_Np2LiveSd_SupportsProfile(m,rates[i]))available|=1U<<(4U*m+i);
     report.words[27]=available;report.words[28]=120U;}
    if(!np_usb_sd_plan_decode(&plan,raw,128U))return reject(NP_USB_SD_OUTCOME_INTERNAL);
    u64words(8U,plan.ticket);report.words[10]=np_usb_sd_u32(raw+60U);
    start_id=np_first_u32(plan.npsd+8U);report.words[11]=start_id;
    report.words[13]=mask=np_first_u32(plan.npsd+32U);report.words[14]=hz=np_first_u32(plan.npsd+36U);
    report.words[15]=plan.seconds;report.words[16]=blocks=np_first_u32(plan.npsd+40U);report.words[29]=plan.expected_frontier;
    if(memcmp(plan.uid,actual,sizeof(actual)) || !np_first_sd_grid16_append_request_valid(plan.npsd,64U,2U,actual) ||
       np_first_u16(plan.npsd+6U)!=NP_FIRST_SD_START || np_first_u64(plan.npsd+24U)!=plan.ticket)
        return reject(NP_USB_SD_OUTCOME_IDENTITY);
    ticks=XE_NP_Np2DualSd_ProfileTicks(mask,hz);
    if(!ticks || !XE_NP_Np2LiveSd_SupportsProfile(mask,hz))return reject(NP_USB_SD_OUTCOME_UNSUPPORTED);
    uint64_t units=((uint64_t)plan.seconds*hz*1600U+ticks-1U)/ticks;
    units=(units+3U)&~UINT64_C(3);
    if(!units || units>UINT32_MAX || blocks!=(uint32_t)units)return reject(NP_USB_SD_OUTCOME_UNSUPPORTED);
    if(!card || !cache || !card->Instance || card->SdCard.LogBlockNbr!=plan.capacity ||
       memcmp(card->CID,plan.cid,sizeof(plan.cid)))return reject(NP_USB_SD_OUTCOME_IDENTITY);
    report.words[20]=card->SdCard.LogBlockNbr;for(unsigned i=0;i<4;i++)report.words[21U+i]=card->CID[i];
    report.words[6]|=NP_USB_SD_VALID_IDENTITY;
    if(!quiet() || XE_NP_Np2DualSdCatalogPort_MountAvailable(&next))return reject(NP_USB_SD_OUTCOME_CATALOG);
    report.words[25]=next;report.words[26]=XE_NP_Np2DualSdCatalog_Status();report.words[6]|=NP_USB_SD_VALID_CATALOG;
    if(next!=plan.expected_frontier || (report.words[26]&~XE_NP_NP2_CATALOG_DEGRADED))return reject(NP_USB_SD_OUTCOME_CATALOG);
    if(XE_NP_Np2DualSdCatalogPort_PlanGrid16(mask,hz,blocks,1U,0U,11U,0U,&planned))return reject(NP_USB_SD_OUTCOME_CATALOG);
    if(control(0U,1U,0U,0U,answer))return reject(NP_USB_SD_OUTCOME_INTERNAL);
    prior_mask=np_first_u32(answer+28U);prior_hz=np_first_u32(answer+32U);
    report.words[30]=prior_mask;report.words[31]=prior_hz;have_profile=1U;
    if(control(1U,preceding_id(start_id),mask,hz,answer))return reject(NP_USB_SD_OUTCOME_UNSUPPORTED);
    memset(answer,0,sizeof(answer));
    report.words[6]&=~(NP_USB_SD_VALID_SOURCE_QUIET|NP_USB_SD_VALID_SD_QUIET);
    XE_NP_Np2LiveSd_WallStatsEnable(1);
    if(!first_sync(plan.npsd,answer) || np_first_u32(answer+32U)!=NP_FIRST_SD_OK ||
       XE_NP_Np2SdControl_PendingStart()!=start_id)return reject(NP_USB_SD_OUTCOME_INTERNAL);
    return 1;
}
void XE_NP_Np2UsbSdTest_StartRejected(void)
{/* begin() might have torn a reservation before rejecting: never claim that
   * media was untouched without a positive receipt. */
 if(active){report.words[44]=xe_np_np2_dual_sd_app_mailbox.command_error;finish(NP_USB_SD_PHASE_INTERRUPTED_UNKNOWN,NP_USB_SD_OUTCOME_INTERNAL,0U,0U);}}
void XE_NP_Np2UsbSdTest_Terminal(uint32_t closed,uint32_t writer_bound)
{
    if(!active)return;
    const volatile XE_NP_Np2DualSdAppMailbox *a=&xe_np_np2_dual_sd_app_mailbox;
    const volatile XE_NP_Np2LiveSdMailbox *w=&xe_np_np2_live_sd_mailbox;
    if(a->session_id)report.words[32]=a->session_id;
    if(a->reservation_start_lba && a->reservation_end_lba){
        report.words[33]=a->reservation_start_lba;report.words[34]=a->reservation_end_lba;
        if(a->payload_start_lba)report.words[35]=a->payload_start_lba;
    }
    report.words[41]=a->state;report.words[44]=a->command_error;
    if(writer_bound){
        report.words[42]=w->state;report.words[43]=w->error;
        XE_NP_Grid16Footer counts={0};
        XE_NP_Np2SdGridStatus grid={0};
        XE_NP_Np2LiveSdWallStats wall={0};
        if(XE_NP_Np2LiveSd_WallStatsSnapshot(&wall) && wall.completed_writes &&
           (wall.flags&2U) && !(wall.flags&4U) && w->sd_bus_hz && w->cpu_hz &&
           HAL_RCC_GetHCLKFreq()==w->cpu_hz &&
           wall.completed_ms<=UINT64_MAX/1000U && wall.max_write_ms<=UINT32_MAX/1000U &&
           wall.max_service_ms<=UINT32_MAX/1000U){
            report.words[54]=wall.completed_writes;u64words(55,wall.completed_ms*1000U);
            report.words[57]=wall.max_write_ms*1000U;report.words[58]=wall.max_service_ms*1000U;
            report.words[59]=w->sd_bus_hz;report.words[60]=w->cpu_hz;
            report.words[6]|=NP_USB_SD_VALID_PERFORMANCE;
        }
        XE_NP_Np2FirstSyncRuntime_SdGridStatus(&grid);
        const XE_NP_Np2FirstSyncSdContext *association=XE_NP_Np2FirstSyncSd_Record();
        /* Runtime retains counters after detach/retire. Their validity is
         * independent of AUX continuity; bind them to this exact session. */
        if(grid.started && grid.generation && association && a->session_id &&
           association->current.session==a->session_id && association->current.generation==grid.generation &&
           grid.queue_dropped!=UINT32_MAX && grid.scheduler_missing<UINT32_MAX){
            report.words[61]=grid.queue_dropped;report.words[62]=(uint32_t)grid.scheduler_missing;
            report.words[6]|=NP_USB_SD_VALID_AUX;
        }
        /* Zero on an early failure can be an uninitialized measurement. */
        if(w->recording_ms || w->state==XE_NP_NP2_LIVE_SD_COMPLETE)report.words[52]=w->recording_ms;
        if(w->drain_ms || w->state==XE_NP_NP2_LIVE_SD_COMPLETE)report.words[53]=w->drain_ms;
        if(!XE_NP_Np2LiveSd_GetGrid16AppendCounts(&counts)){
            report.words[37]=counts.np_blocks;report.words[39]=counts.logical_prefix_blocks;
            report.words[40]=counts.logical_high_water_blocks;report.words[6]|=NP_USB_SD_VALID_PNH|NP_USB_SD_VALID_APPEND;
            if(counts.append_flags&1U){report.words[38]=counts.admitted_blocks;report.words[6]|=NP_USB_SD_VALID_ADMITTED;}
            uint64_t end=(uint64_t)a->payload_start_lba+(uint64_t)(counts.np_blocks/4U)*
                ((uint64_t)XE_NP_NP2_DUAL_SD_SECTORS_PER_RU+XE_NP_Grid16_K(w->probe_mask,w->sample_hz));
            if(end<=UINT32_MAX && end<=a->reservation_end_lba)report.words[36]=(uint32_t)end;
        }
    }
    uint32_t outcome=NP_USB_SD_OUTCOME_INTERNAL;
    if(writer_bound && w->source_i2c_error)outcome=NP_USB_SD_OUTCOME_PROBE_FAULT;
    else if(writer_bound && (w->sd_error || w->error==XE_NP_NP2_LIVE_SD_ERROR_CARD || w->error==XE_NP_NP2_LIVE_SD_ERROR_WRITE ||
            w->error==XE_NP_NP2_LIVE_SD_ERROR_WRITE_START || w->error==XE_NP_NP2_LIVE_SD_ERROR_READ))
        outcome=NP_USB_SD_OUTCOME_STORAGE;
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
    if(writer_bound){
        report.words[45]=xe_np_np2_sd_loss.dropped_blocks;report.words[46]=xe_np_np2_sd_loss.overflow_events;
        report.words[47]=xe_np_np2_sd_loss.gap_events;u64words(48,xe_np_np2_sd_loss.missing_ticks);
        u64words(50,xe_np_np2_sd_loss.producer_discarded_ticks);
        report.words[6]|=NP_USB_SD_VALID_CAPTURE_COUNTERS|NP_USB_SD_VALID_SOURCE_GAPS|NP_USB_SD_VALID_MISSING_TICKS;
        if(outcome==NP_USB_SD_OUTCOME_INTERNAL && (report.words[45]||report.words[46]||report.words[47]||
           xe_np_np2_sd_loss.missing_ticks||xe_np_np2_sd_loss.producer_discarded_ticks))outcome=NP_USB_SD_OUTCOME_THROUGHPUT_LOSS;
    }
#endif
    if(outcome==NP_USB_SD_OUTCOME_INTERNAL && a->state==XE_NP_NP2_DUAL_SD_CANCELLED)outcome=NP_USB_SD_OUTCOME_CANCELLED;
    if(outcome==NP_USB_SD_OUTCOME_INTERNAL && closed && writer_bound && a->state==XE_NP_NP2_DUAL_SD_COMPLETE && !w->error)
        outcome=NP_USB_SD_OUTCOME_CANDIDATE;
    finish(NP_USB_SD_PHASE_FINISHED,outcome,0U,closed);
}
#endif
