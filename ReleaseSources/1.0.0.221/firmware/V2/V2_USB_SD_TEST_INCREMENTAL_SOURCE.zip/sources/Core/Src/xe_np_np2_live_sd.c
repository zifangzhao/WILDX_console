#include "xe_np_np2_first_sync_sd.h"
#include "xe_np_np2_first_sync_runtime.h"
#include "xe_np_np2_first_sync_port.h"
#include "xe_np_np2_live_sd.h"
#include "xe_np_np2_dual_sd_run.h"
#include "xe_np_np2_dual_sd_app.h"
#include "xe_np_np2_sd_ble.h"
#include "xe_np_np2_preparation.h"
#include "xe_np_np2_config.h"
#include "xe_np_psram.h"
#include "xe_np_sd_write_trace.h"
#include "xe_np_np2_closed_loop_spi.h"
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
#include "xe_np_np2_grid16_idma.h"
#endif
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
#include "xe_np_np2_closed_loop_carrier.h"
#include "xe_np_np2_closed_loop_capture_proof.h"
#endif

#if XE_NP_NP2_LIVE_SD_ENABLE

#if XE_NP_USB_SD_TEST_ENABLE
#include <string.h>
/* BEGIN USB WALL STATS: foreground only; selected once while stopped. */
_Static_assert(sizeof(XE_NP_Np2LiveSdWallStats)==24U,"USB wall snapshot size");
static XE_NP_Np2LiveSdWallStats usb_wall_stats;
static uint32_t usb_wall_last_service;
static void usb_wall_no_service(void){}
static void usb_wall_no_complete(uint32_t start){(void)start;}
static void usb_wall_service(void)
{
    uint32_t now=HAL_GetTick();
    if(usb_wall_stats.flags&1U){
        uint32_t gap=now-usb_wall_last_service;
        if(gap>usb_wall_stats.max_service_ms)usb_wall_stats.max_service_ms=gap;
        usb_wall_stats.flags|=2U;
    }
    usb_wall_last_service=now;usb_wall_stats.flags|=1U;
}
static void usb_wall_complete(uint32_t start)
{
    uint32_t elapsed=HAL_GetTick()-start;
    if(usb_wall_stats.completed_writes==UINT32_MAX || UINT64_MAX-usb_wall_stats.completed_ms<elapsed){
        usb_wall_stats.flags|=4U;return;
    }
    usb_wall_stats.completed_writes++;usb_wall_stats.completed_ms+=elapsed;
    if(elapsed>usb_wall_stats.max_write_ms)usb_wall_stats.max_write_ms=elapsed;
}
static void (*usb_wall_service_observer)(void)=usb_wall_no_service;
static void (*usb_wall_complete_observer)(uint32_t)=usb_wall_no_complete;
static void usb_wall_reset(void)
{memset(&usb_wall_stats,0,sizeof(usb_wall_stats));usb_wall_last_service=0U;}
void XE_NP_Np2LiveSd_WallStatsEnable(int enable)
{
    usb_wall_reset();
    usb_wall_service_observer=enable?usb_wall_service:usb_wall_no_service;
    usb_wall_complete_observer=enable?usb_wall_complete:usb_wall_no_complete;
}
int XE_NP_Np2LiveSd_WallStatsSnapshot(XE_NP_Np2LiveSdWallStats *out)
{
    if(!out || usb_wall_service_observer!=usb_wall_service ||
       (xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_COMPLETE &&
        xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_FAILED))return 0;
    *out=usb_wall_stats;return 1;
}
/* END USB WALL STATS */
#endif

#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE && (!XE_NP_NP2_LIVE_SD_GRID16_ENABLE || \
    !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || \
    !XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST || !XE_NP_NP2_SD_APPEND_ORDER_TEST)
#error "Grid append requires the Grid16 copied whole-RU owner ledger"
#endif

#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
volatile XE_NP_Np2SdLoss xe_np_np2_sd_loss;
/* Existing source-header discontinuity branch only. SD/PSRAM owners and
 * completed blocks are untouched; the partial output was never published. */
static void discard_partial_source(void);
#endif

#if XE_NP_NP2_SD_APPEND_ORDER_TEST
#include "xe_np_np2_sd_append_coverage.h"
static uint8_t record_uses_append;
static uint32_t append_logical_high_water_blocks;
static XE_NP_Np2SdAppendCoverage append_coverage;
#define SESSION_APPEND record_uses_append
#else
#define SESSION_APPEND 0U
#endif
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
#define RUNTIME_DIRECT_RU_CAPACITY (9U+NP2_RUNTIME_DIRECT_RESTORE_RUS)
static uint8_t record_uses_runtime_direct;
static volatile uint8_t runtime_direct_retire_pending;
static uint32_t runtime_direct_retired_rus;
#define SESSION_RUNTIME_DIRECT record_uses_runtime_direct
#else
#define SESSION_RUNTIME_DIRECT 0U
#endif

#define VSC_PSRAM_IDMA (XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST || \
                       XE_NP_NP2_SD_HIGH_TWO_PSRAM_IDMA_TEST)
#if XE_NP_NP2_SD_ACTIVE_CLOCK_SAVE_TEST && \
    (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
     XE_NP_NP2_LIVE_SD_DIRECT)
#error "Idle-clock trial requires the copied runtime SD APP"
#endif
#if XE_NP_NP2_SD_PROFILE_BUS54_TEST && \
    (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
     !XE_NP_NP2_LIVE_SD_VSC_TEST || XE_NP_NP2_LIVE_SD_DIRECT)
#error "Profile SD-bus clock trial requires the copied runtime VSC SD APP"
#endif

#ifndef XE_NP_NP2_SD_COPY_WAKE_TEST
#define XE_NP_NP2_SD_COPY_WAKE_TEST 0U
#endif
#ifndef XE_NP_NP2_SD_COPY_IDLE_GUARD_TEST
#define XE_NP_NP2_SD_COPY_IDLE_GUARD_TEST 0U
#endif
#ifndef XE_NP_NP2_SD_HIGH_TWO_COPY_PRIORITY_TEST
#define XE_NP_NP2_SD_HIGH_TWO_COPY_PRIORITY_TEST 0U
#endif
#ifndef XE_NP_NP2_SD_OSPI_SLEEP_GATE_TEST
#define XE_NP_NP2_SD_OSPI_SLEEP_GATE_TEST 0U
#endif
#ifndef XE_NP_NP2_SD_INGRESS_DMA_TEST
#define XE_NP_NP2_SD_INGRESS_DMA_TEST 0U
#endif
#include "main.h"
/* STOPPED-only discriminator for the CMD13 failure at the high-rate kernel.
 * Default-off; it must never alter an acquisition or a failed SD owner. */
#ifndef XE_NP_NP2_SD_VSC_PREERASE60_TEST
#define XE_NP_NP2_SD_VSC_PREERASE60_TEST 0U
#endif
#if (XE_NP_NP2_SD_VSC_PREERASE60_TEST!=0U && XE_NP_NP2_SD_VSC_PREERASE60_TEST!=1U) || \
    (XE_NP_NP2_SD_VSC_PREERASE60_TEST && \
     (!XE_NP_NP2_SD_VSC_FEED_TEST || !XE_NP_NP2_SD_HIGH_RATE_KERNEL120_TEST))
#error "Stopped preerase60 requires the private VSC feeder and 120 MHz policy"
#endif
#ifndef XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST
#define XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST 0U
#endif
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE && !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST
#error "Grid16 requires the linked-IDMA writer"
#endif
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE && XE_NP_NP2_LIVE_SD_PSRAM_SPILL
#error "Grid16 rejects PSRAM spill ownership"
#endif
#ifndef XE_NP_NP2_LIVE_SD_VERIFY_CLOCK_DIV
#define XE_NP_NP2_LIVE_SD_VERIFY_CLOCK_DIV 0U
#endif
#ifndef XE_NP_NP2_LIVE_SD_VERIFY_READ_RETRY_TEST
#define XE_NP_NP2_LIVE_SD_VERIFY_READ_RETRY_TEST 0U
#endif
#ifndef XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE
#define XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE 0U
#endif
#if XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE!=0U && XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE!=1U
#error "SD sensor snapshot must be an explicit boolean"
#endif
#if XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE
#include "xe_np_sensors_port.h"
#endif
#ifndef XE_NP_NP2_LIVE_SD_STARTUP_PRIME_TEST
#define XE_NP_NP2_LIVE_SD_STARTUP_PRIME_TEST 0U
#endif
#ifndef XE_NP_NP2_LIVE_SD_STARTUP_PRIME_PATTERN_TEST
#define XE_NP_NP2_LIVE_SD_STARTUP_PRIME_PATTERN_TEST 0U
#endif
#if XE_NP_NP2_LIVE_SD_STARTUP_PRIME_PATTERN_TEST && !XE_NP_NP2_LIVE_SD_STARTUP_PRIME_TEST
#error "Nonzero prime requires the existing stopped-only prime owner"
#endif
#if XE_NP_NP2_LIVE_SD_STARTUP_PRIME_PATTERN_TEST!=0U && XE_NP_NP2_LIVE_SD_STARTUP_PRIME_PATTERN_TEST!=1U
#error "Nonzero prime must be an explicit boolean experiment"
#endif
#ifndef XE_NP_NP2_LIVE_SD_NO_WFI_TEST
#define XE_NP_NP2_LIVE_SD_NO_WFI_TEST 0U
#endif
#if XE_NP_NP2_SD_COPY_WAKE_TEST && \
    (XE_NP_NP2_SD_COPY_WAKE_TEST!=1U || !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || \
     !XE_NP_NP2_LIVE_SD_IDLE_SLEEP || XE_NP_NP2_LIVE_SD_PSRAM_SPILL || \
     XE_NP_NP2_STAGED_CAPTURE || XE_NP_NP2_LIVE_SD_NO_WFI_TEST)
#error "Copy wake requires the exclusive overflow-DMA shallow-WFI writer"
#endif
#if XE_NP_NP2_SD_COPY_IDLE_GUARD_TEST && \
    (XE_NP_NP2_SD_COPY_IDLE_GUARD_TEST!=1U || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
     !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || \
     XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_LIVE_SD_PSRAM_SPILL || \
     XE_NP_NP2_STAGED_CAPTURE || XE_NP_NP2_SD_COPY_WAKE_TEST || \
     XE_NP_NP2_SD_RAW_INGRESS_RU_TEST)
#error "Copy idle guard requires the original copied runtime SD geometry without wake IRQ"
#endif
/* HIGH_TWO_COPY_PRIORITY_GUARDS_BEGIN */
#if XE_NP_NP2_SD_HIGH_TWO_COPY_PRIORITY_TEST && \
    (XE_NP_NP2_SD_HIGH_TWO_COPY_PRIORITY_TEST!=1U || XE_NP_IMAGE_ROLE!=XE_NP_IMAGE_SD_APP || \
     !XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
     !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || !XE_NP_NP2_SD_COPY_IDLE_GUARD_TEST || \
     XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_LIVE_SD_PSRAM_SPILL || \
     XE_NP_NP2_STAGED_CAPTURE || XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE || \
     XE_NP_NP2_SD_COPY_WAKE_TEST || XE_NP_NP2_SD_RAW_INGRESS_RU_TEST || \
     XE_NP_NP2_LIVE_SD_OVERFLOW_DMA_BURST_WORDS!=1U)
#error "High-two copy priority requires the guarded original burst1 copied runtime SD APP"
#endif
/* HIGH_TWO_COPY_PRIORITY_GUARDS_END */
#if XE_NP_NP2_SD_OSPI_SLEEP_GATE_TEST && \
    (XE_NP_NP2_SD_OSPI_SLEEP_GATE_TEST!=1U || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
     !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || \
     !XE_NP_NP2_LIVE_SD_IDLE_SLEEP || XE_NP_NP2_LIVE_SD_DIRECT || \
     XE_NP_NP2_LIVE_SD_PSRAM_SPILL || XE_NP_NP2_STAGED_CAPTURE || \
     XE_NP_NP2_SD_COPY_WAKE_TEST || XE_NP_NP2_LIVE_SD_NO_WFI_TEST)
#error "OSPI sleep gate requires the copied runtime shallow-WFI APP without copy wake"
#endif
#if XE_NP_NP2_SD_INGRESS_DMA_TEST && \
    (XE_NP_NP2_SD_INGRESS_DMA_TEST!=1U || XE_NP_IMAGE_ROLE!=XE_NP_IMAGE_SD_APP || \
     !XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
     !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || !XE_NP_NP2_LIVE_SD_IDLE_SLEEP || \
     XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_STAGED_CAPTURE || \
     XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE || XE_NP_NP2_LIVE_SD_PSRAM_SPILL || \
     XE_NP_V2_MEDIA_ENABLE || XE_NP_V2_AUX_ENABLE || XE_NP_NP2_SD_COPY_WAKE_TEST || \
     XE_NP_NP2_SD_OSPI_SLEEP_GATE_TEST || XE_NP_NP2_LIVE_SD_NO_WFI_TEST || \
     XE_NP_NP2_LIVE_SD_TRIPLE_COPY_TIMING_DIAG)
#error "Ingress DMA requires the neural-only copied runtime shallow-WFI APP and exclusive C15"
#endif
#if XE_NP_PSRAM_HOST_PARK_TEST && \
    (XE_NP_IMAGE_ROLE!=XE_NP_IMAGE_SD_APP || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
     !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || \
     XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_STAGED_CAPTURE || \
     XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE || XE_NP_NP2_LIVE_SD_PSRAM_SPILL || \
     XE_NP_V2_MEDIA_ENABLE || XE_NP_V2_AUX_ENABLE || XE_NP_NP2_SD_COPY_WAKE_TEST || \
     XE_NP_NP2_SD_OSPI_SLEEP_GATE_TEST || XE_NP_NP2_SD_INGRESS_DMA_TEST || \
     !XE_NP_PSRAM_MPU_NONCACHEABLE_EXPERIMENT)
#error "Host park requires the neural-only copied runtime APP and noncacheable PSRAM"
#endif
#if XE_NP_NP2_LIVE_SD_NO_WFI_TEST && !XE_NP_NP2_LIVE_SD_IDLE_SLEEP
#error "No-WFI discriminator requires the existing idle recheck"
#endif
#if XE_NP_NP2_LIVE_SD_STARTUP_PRIME_TEST!=0U && XE_NP_NP2_LIVE_SD_STARTUP_PRIME_TEST!=1U
#error "Startup prime must be an explicit boolean experiment"
#endif
#ifndef XE_NP_NP2_LIVE_SD_OVERFLOW_FAULT_DIAG
#define XE_NP_NP2_LIVE_SD_OVERFLOW_FAULT_DIAG 0U
#endif
#ifndef XE_NP_NP2_SD_RETAIN_OVERFLOW_FAULT_TEST
#define XE_NP_NP2_SD_RETAIN_OVERFLOW_FAULT_TEST 0U
#endif
#ifndef XE_NP_NP2_SD_LINKED_COPY_TEST
#define XE_NP_NP2_SD_LINKED_COPY_TEST 0U
#endif
#if XE_NP_NP2_SD_VSC_FEED_TEST
#if !XE_NP_NP2_SD_STOPPED_FEED_TEST || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
    !XE_NP_NP2_LIVE_SD_VSC_TEST || !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || \
    !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || \
    XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U || \
    XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE || \
    XE_NP_NP2_STAGED_CAPTURE || XE_NP_NP2_SD_RETAIN_OVERFLOW_FAULT_TEST || \
    XE_NP_NP2_SD_LINKED_COPY_TEST || VSC_PSRAM_IDMA
#error "Stopped VSC feed requires the original copied fixed1024 writer and private dispatcher"
#endif
static uint8_t vsc_feed_active;
#endif
#ifndef XE_NP_NP2_LIVE_SD_FAULT_SD_PINS_TEST
#define XE_NP_NP2_LIVE_SD_FAULT_SD_PINS_TEST 0U
#endif
#ifndef XE_NP_NP2_LIVE_SD_SKIP_BATCH_HINT_TEST
#define XE_NP_NP2_LIVE_SD_SKIP_BATCH_HINT_TEST 0U
#endif
#ifndef XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
#define XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST 0U
#endif
#ifndef XE_NP_NP2_LIVE_SD_VSC_BUNDLE_AUS_TEST
#define XE_NP_NP2_LIVE_SD_VSC_BUNDLE_AUS_TEST 1U
#endif
#if XE_NP_NP2_LIVE_SD_VSC_BUNDLE_AUS_TEST<1U || XE_NP_NP2_LIVE_SD_VSC_BUNDLE_AUS_TEST>8U
#error "VSC registration may bundle only one to eight reserved AUs"
#endif
#ifndef XE_NP_NP2_LIVE_SD_SPILL_HOLD_TEST
#define XE_NP_NP2_LIVE_SD_SPILL_HOLD_TEST 0U
#endif
#ifndef XE_NP_NP2_LIVE_SD_SPILL_LEG_4K_TEST
#define XE_NP_NP2_LIVE_SD_SPILL_LEG_4K_TEST 0U
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_LEG_4K_TEST!=0U && XE_NP_NP2_LIVE_SD_SPILL_LEG_4K_TEST!=1U
#error "Spill leg cap must be an explicit boolean private experiment"
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_LEG_4K_TEST && !XE_NP_NP2_LIVE_SD_SPILL_HOLD_TEST
#error "Spill leg cap requires the closed direct-PSRAM SYSCLK spill-hold APP"
#endif
#ifndef XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST
#define XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST 0U
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST!=0U && XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST!=1U
#error "Spill defer must be an explicit boolean private experiment"
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST && !XE_NP_NP2_LIVE_SD_SPILL_HOLD_TEST
#error "Spill defer requires the closed direct-PSRAM SYSCLK spill-hold APP"
#endif
#ifndef XE_NP_NP2_LIVE_SD_SPILL_LAUNCH_TRACE_TEST
#define XE_NP_NP2_LIVE_SD_SPILL_LAUNCH_TRACE_TEST 0U
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_LAUNCH_TRACE_TEST!=0U && XE_NP_NP2_LIVE_SD_SPILL_LAUNCH_TRACE_TEST!=1U
#error "Spill launch trace must be an explicit boolean private experiment"
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_LAUNCH_TRACE_TEST && \
    (!XE_NP_NP2_LIVE_SD_SPILL_HOLD_TEST || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
     !XE_NP_NP2_LIVE_SD_VSC_TEST || !XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST || \
     !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || XE_NP_NP2_CAPTURE_PORT0_TEST!=1U || \
     XE_NP_NP2_LIVE_SD_SPILL_LEG_4K_TEST || XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST)
#error "Spill launch trace requires the held direct-PSRAM VSC capture-port0 APP without cap/defer"
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_HOLD_TEST!=0U && XE_NP_NP2_LIVE_SD_SPILL_HOLD_TEST!=1U
#error "Spill hold must be an explicit boolean private experiment"
#endif
#ifndef XE_NP_NP2_LIVE_SD_SPILL_DEST_BURST4_TEST
#define XE_NP_NP2_LIVE_SD_SPILL_DEST_BURST4_TEST 0U
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_DEST_BURST4_TEST!=0U && XE_NP_NP2_LIVE_SD_SPILL_DEST_BURST4_TEST!=1U
#error "Spill destination burst must be an explicit boolean private experiment"
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_DEST_BURST4_TEST && \
    (!XE_NP_NP2_LIVE_SD_SPILL_LAUNCH_TRACE_TEST || !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || \
     XE_NP_NP2_LIVE_SD_OVERFLOW_DMA_BURST_WORDS!=1U)
#error "Spill destination burst4 requires launch trace and source burst1 overflow DMA"
#endif
#ifndef XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_TEST
#define XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_TEST 0U
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_TEST!=0U && XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_TEST!=1U
#error "Spill bus fence must be an explicit boolean private experiment"
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_TEST && \
    (!XE_NP_NP2_LIVE_SD_SPILL_LAUNCH_TRACE_TEST || XE_NP_NP2_LIVE_SD_SPILL_DEST_BURST4_TEST || \
     XE_NP_NP2_LIVE_SD_OVERFLOW_DMA_BURST_WORDS!=1U)
#error "Spill bus fence requires the unchanged source/destination-burst1 launch-trace APP"
#endif
#ifndef XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_DIAG_TEST
#define XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_DIAG_TEST 0U
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_DIAG_TEST!=0U && XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_DIAG_TEST!=1U
#error "Spill bus fence diagnostic must be an explicit boolean private experiment"
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_DIAG_TEST && \
    (!XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_TEST || !XE_NP_NP2_LIVE_SD_SPILL_LAUNCH_TRACE_TEST)
#error "Spill bus fence diagnostic requires the existing bus fence and launch trace"
#endif
#ifndef XE_NP_NP2_LIVE_SD_SPILL_PRESSURE_DIAG_TEST
#define XE_NP_NP2_LIVE_SD_SPILL_PRESSURE_DIAG_TEST 0U
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_PRESSURE_DIAG_TEST!=0U && XE_NP_NP2_LIVE_SD_SPILL_PRESSURE_DIAG_TEST!=1U
#error "Spill pressure diagnostic must be an explicit boolean private experiment"
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_PRESSURE_DIAG_TEST && \
    (!XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_DIAG_TEST || !XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_TEST || \
     !XE_NP_NP2_LIVE_SD_SPILL_HOLD_TEST)
#error "Spill pressure diagnostic requires the existing fence diagnostic and forced hold"
#endif
#if XE_NP_NP2_LIVE_SD_VSC_TEST && XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U
#error "Live VSC requires the copied-nine packed-dual fixed512 writer"
#endif
#ifndef XE_NP_NP2_LIVE_SD_VSC_PRESSURE_PREFIX_TEST
#define XE_NP_NP2_LIVE_SD_VSC_PRESSURE_PREFIX_TEST 0U
#endif
#if (XE_NP_NP2_LIVE_SD_VSC_PRESSURE_PREFIX_TEST!=0U && XE_NP_NP2_LIVE_SD_VSC_PRESSURE_PREFIX_TEST!=1U) || \
    (XE_NP_NP2_LIVE_SD_VSC_PRESSURE_PREFIX_TEST && \
     (!XE_NP_NP2_LIVE_SD_VSC_TEST || XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U || \
      !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || \
      XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST || XE_NP_NP2_LIVE_SD_DIRECT))
#error "Pressure prefix requires the copied VSC ordered-window writer"
#endif
#ifndef XE_NP_NP2_LIVE_SD_LAST_FREE_PREFETCH_TEST
#define XE_NP_NP2_LIVE_SD_LAST_FREE_PREFETCH_TEST 0U
#endif
#if (XE_NP_NP2_LIVE_SD_LAST_FREE_PREFETCH_TEST!=0U && XE_NP_NP2_LIVE_SD_LAST_FREE_PREFETCH_TEST!=1U) || \
    (XE_NP_NP2_LIVE_SD_LAST_FREE_PREFETCH_TEST && \
     (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
      !XE_NP_NP2_LIVE_SD_VSC_TEST || XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U || \
      !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || \
      !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST || \
      XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_LIVE_SD_VSC_PRESSURE_PREFIX_TEST))
#error "Last-FREE prefetch requires the unchanged copied runtime VSC fixed1024 APP"
#endif
#ifndef XE_NP_NP2_LIVE_SD_RESTORE_CHAIN_TEST
#define XE_NP_NP2_LIVE_SD_RESTORE_CHAIN_TEST 0U
#endif
#if (XE_NP_NP2_LIVE_SD_RESTORE_CHAIN_TEST!=0U && XE_NP_NP2_LIVE_SD_RESTORE_CHAIN_TEST!=1U) || \
    (XE_NP_NP2_LIVE_SD_RESTORE_CHAIN_TEST && \
     (!XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || \
      XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST))
#error "Restore chaining requires the copied out-of-order overflow writer"
#endif
#if XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST && \
    ((XE_NP_NP2_LIVE_SD_VSC_TEST && !XE_NP_NP2_SD_PROFILE_CLASSIC_TEST) || \
     XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U || \
     !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_NP2_DUAL_SD_APP_ENABLE)
#error "Classic sequential trial requires the classic or mixed fixed512 runtime SD APP"
#endif
#if XE_NP_NP2_SD_PROFILE_CLASSIC_TEST && XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST && \
    (XE_NP_NP2_SD_CLASSIC15_TEST || XE_NP_NP2_SD_CLASSIC_HIGH_TEST)
#error "Mixed sequential trial retains VSC for the higher-rate profiles"
#endif
#if XE_NP_NP2_SD_HIGH_TWO_CLASSIC_TEST && \
    (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
     !XE_NP_NP2_LIVE_SD_VSC_TEST || XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U || \
     !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || \
     !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || XE_NP_NP2_LIVE_SD_DIRECT || \
     XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST || \
     XE_NP_NP2_LIVE_SD_LAST_FREE_PREFETCH_TEST)
#error "High-two classic trial requires the unchanged copied runtime fixed1024 writer"
#endif
#if XE_NP_NP2_LIVE_SD_CLASSIC_PREPARE_TEST && \
    (XE_NP_NP2_LIVE_SD_VSC_TEST || XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST || \
     !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
     (XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=0U && XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U))
#error "Classic preparation requires the original non-VSC copied runtime SD APP"
#endif
#if XE_NP_NP2_SD_PROFILE_CLASSIC_TEST && \
    (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
     !XE_NP_NP2_LIVE_SD_VSC_TEST || XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U || \
     XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST || \
     XE_NP_NP2_LIVE_SD_CLASSIC_PREPARE_TEST)
#error "Per-profile classic trial requires the copied runtime VSC/fixed1024 APP"
#endif
#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST && \
    (XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST != 1024U || \
     !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || \
     !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || !XE_NP_NP2_USB_PACKED_DUAL || \
     !XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS || XE_NP_NP2_LIVE_SD_DIRECT || \
     XE_NP_NP2_STAGED_CAPTURE || XE_NP_NP2_LIVE_SD_WRITE_RUS != 6U)
#error "Fixed 512KiB writes require the copied-nine packed-dual linked OOO trial"
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_FAULT_DIAG && \
    (!XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER)
#error "Overflow fault snapshot requires the copied-nine OOO DMA trial"
#endif
#if XE_NP_NP2_SD_RETAIN_OVERFLOW_FAULT_TEST && \
    (XE_NP_NP2_SD_RETAIN_OVERFLOW_FAULT_TEST!=1U || XE_NP_IMAGE_ROLE!=XE_NP_IMAGE_SD_APP || \
     !XE_NP_NP2_LIVE_SD_OVERFLOW_FAULT_DIAG || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
     !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_NP2_SD_COPY_IDLE_GUARD_TEST || \
     !XE_NP_NP2_SD_SOURCE_COPY_RECEIPT_TEST || XE_NP_NP2_LIVE_SD_DIRECT || \
     XE_NP_NP2_LIVE_SD_PSRAM_SPILL || XE_NP_NP2_STAGED_CAPTURE || \
     XE_NP_NP2_SD_RAW_INGRESS_RU_TEST || XE_NP_NP2_SD_HIGH_TWO_COPY_PRIORITY_TEST)
#error "Retained fault requires the original guarded S5 copied runtime SD APP and private UNINIT scatter"
#endif
/* LINKED_COPY_GUARDS_BEGIN */
#if XE_NP_NP2_SD_LINKED_COPY_TEST && \
    (XE_NP_NP2_SD_LINKED_COPY_TEST!=1U || XE_NP_IMAGE_ROLE!=XE_NP_IMAGE_SD_APP || \
     !XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
     !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || !XE_NP_NP2_SD_COPY_IDLE_GUARD_TEST || \
     !XE_NP_NP2_SD_RETAIN_OVERFLOW_FAULT_TEST || XE_NP_NP2_LIVE_SD_OVERFLOW_DMA_BURST_WORDS!=1U || \
     XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_LIVE_SD_PSRAM_SPILL || XE_NP_NP2_STAGED_CAPTURE || \
     XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE || XE_NP_NP2_SD_RAW_INGRESS_RU_TEST || \
     XE_NP_NP2_SD_HIGH_TWO_COPY_PRIORITY_TEST || XE_NP_NP2_SD_COPY_WAKE_TEST || \
     XE_NP_NP2_LIVE_SD_COPY_SPLIT_PORTS_TEST || XE_NP_NP2_LIVE_SD_SPILL_DEST_BURST4_TEST || \
     XE_NP_NP2_LIVE_SD_COPY_COST_DIAG || XE_NP_NP2_LIVE_SD_RESTORE_CHAIN_TEST || \
     XE_NP_NP2_LIVE_SD_SPILL_LEG_4K_TEST || XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST || \
     XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_TEST || XE_NP_NP2_LIVE_SD_SPILL_LAUNCH_TRACE_TEST)
#error "Linked COPY requires the retained-fault original guarded burst1 copied runtime APP without other copy experiments"
#endif
/* LINKED_COPY_GUARDS_END */
#ifndef XE_NP_NP2_LIVE_SD_LAUNCH_WAIT_DIAG
#define XE_NP_NP2_LIVE_SD_LAUNCH_WAIT_DIAG 0U
#endif
#ifndef XE_NP_NP2_LIVE_SD_LAUNCH_GAP_SNAPSHOT_DIAG
#define XE_NP_NP2_LIVE_SD_LAUNCH_GAP_SNAPSHOT_DIAG 0U
#endif
#ifndef XE_NP_NP2_LIVE_SD_LAUNCH_GAP_SNAPSHOT_MS
#define XE_NP_NP2_LIVE_SD_LAUNCH_GAP_SNAPSHOT_MS 40U
#endif
#if XE_NP_NP2_LIVE_SD_LAUNCH_GAP_SNAPSHOT_MS != 40U && \
    XE_NP_NP2_LIVE_SD_LAUNCH_GAP_SNAPSHOT_MS != 6U
#error "Launch-gap snapshot threshold is limited to the measured 40/6 ms cases"
#endif
#if (XE_NP_NP2_LIVE_SD_LAUNCH_GAP_SNAPSHOT_DIAG!=0U && XE_NP_NP2_LIVE_SD_LAUNCH_GAP_SNAPSHOT_DIAG!=1U) || \
    (XE_NP_NP2_LIVE_SD_LAUNCH_GAP_SNAPSHOT_DIAG && \
     (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
      !XE_NP_NP2_LIVE_SD_VSC_TEST || XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U || \
      !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || \
      !XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS || !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || \
      !XE_NP_NP2_LIVE_SD_LAUNCH_WAIT_DIAG || XE_NP_NP2_LIVE_SD_DIRECT || \
      XE_NP_NP2_STAGED_CAPTURE || XE_NP_NP2_LIVE_SD_ROLLING_CMD25 || \
      XE_NP_NP2_LIVE_SD_PSRAM_SPILL || XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST || \
      XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE))
#error "Launch-gap snapshot requires the copied runtime VSC fixed1024 OOO launch-wait writer"
#endif
#ifndef XE_NP_NP2_LIVE_SD_PACK_TIMING_DIAG
#define XE_NP_NP2_LIVE_SD_PACK_TIMING_DIAG 0U
#endif
#ifndef XE_NP_NP2_LIVE_SD_TRIPLE_COPY_TIMING_DIAG
#define XE_NP_NP2_LIVE_SD_TRIPLE_COPY_TIMING_DIAG 0U
#endif
#ifndef XE_NP_NP2_LIVE_SD_COPY_COST_DIAG
#define XE_NP_NP2_LIVE_SD_COPY_COST_DIAG 0U
#endif
#ifndef XE_NP_NP2_LIVE_SD_WRITE_LATENCY_DIAG
#define XE_NP_NP2_LIVE_SD_WRITE_LATENCY_DIAG 0U
#endif
#ifndef XE_NP_NP2_LIVE_SD_IDMA_GAP_DIAG
#define XE_NP_NP2_LIVE_SD_IDMA_GAP_DIAG 0U
#endif
#ifndef XE_NP_NP2_LIVE_SD_DATA_PHASE_DIAG
#define XE_NP_NP2_LIVE_SD_DATA_PHASE_DIAG 0U
#endif
#if (XE_NP_NP2_LIVE_SD_DATA_PHASE_DIAG!=0U && XE_NP_NP2_LIVE_SD_DATA_PHASE_DIAG!=1U) || \
    (XE_NP_NP2_LIVE_SD_DATA_PHASE_DIAG && \
     (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
      !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || !XE_NP_NP2_LIVE_SD_LAUNCH_WAIT_DIAG || \
      XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_STAGED_CAPTURE || \
      XE_NP_NP2_LIVE_SD_ROLLING_CMD25 || XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE || \
      XE_NP_NP2_LIVE_SD_PACK_TIMING_DIAG || XE_NP_NP2_LIVE_SD_TRIPLE_COPY_TIMING_DIAG || \
      XE_NP_NP2_LIVE_SD_COPY_COST_DIAG))
#error "DATA-phase samples require the copied runtime linked-list launch-wait APP without another tail observer"
#endif
#if XE_NP_NP2_LIVE_SD_WRITE_LATENCY_DIAG && !XE_NP_NP2_LIVE_SD_LAUNCH_WAIT_DIAG
#error "Write-latency histogram requires the bounded launch-wait diagnostic"
#endif
#if XE_NP_NP2_LIVE_SD_IDMA_GAP_DIAG && \
    (!XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || !XE_NP_NP2_LIVE_SD_WRITE_LATENCY_DIAG)
#error "IDMA node-gap diagnostic requires bounded linked-list latency diagnostics"
#endif
#include "xe_np_board.h"
#if XE_NP_NP2_LIVE_SD_SPILL_HOLD_TEST && \
    (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_VSC_TEST || \
     !XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST || XE_NP_PSRAM_OVERFLOW_PLL2Q108 || \
     XE_NP_PSRAM_OVERFLOW_PLL1Q128 || XE_NP_PSRAM_OVERFLOW_PRESCALER!=1U)
#error "Spill hold requires the private direct-PSRAM SYSCLK live-VSC APP"
#endif
#include "xe_np_capture.h"
#include "xe_np_np2_capture_port.h"
#if XE_NP_NP2_STAGED_CAPTURE
#include "xe_np_np2_stage_queue.h"
#include "xe_np_np2_stage_dma.h"
#include "xe_np_np2_stage_sd_nodes.h"
#if XE_NP_NP2_STAGED_LONG_CMD25
#include "xe_np_np2_stage_long_window.h"
#include "xe_np_np2_stage_long_nodes.h"
#endif
#include "xe_np_psram.h"
#if XE_NP2_STAGE_DIRECT_PSRAM_IDMA && \
    (!XE_NP_NP2_STAGED_LONG_CMD25 || !XE_NP_NP2_STAGE_HYBRID_COPY)
#error "Direct PSRAM IDMA requires the opt-in long CMD25 hybrid staged feeder"
#endif
#if !XE_NP_NP2_LIVE_SD_DIRECT || !XE_NP_NP2_LIVE_SD_EXTENDED_RING || \
    !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || XE_NP_NP2_LIVE_SD_PSRAM_SPILL || \
    XE_NP_NP2_LIVE_SD_IDLE_SLEEP || XE_NP_NP2_LIVE_SD_PROBE_MASK != 7U || \
    XE_NP_NP2_LIVE_SD_WRITE_RUS != 11U
#error "Staged SD requires 13 physical RUs, linked IDMA, raw triple capture and no legacy spill/WFI"
#endif
#endif
#if XE_NP_NP2_LIVE_SD_ROLLING_CMD25
#if XE_NP_NP2_STAGED_CAPTURE || !XE_NP_NP2_LIVE_SD_DIRECT || \
    !XE_NP_NP2_LIVE_SD_EXTENDED_RING || !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || \
    XE_NP_NP2_LIVE_SD_PROBE_MASK != 7U || XE_NP_NP2_LIVE_SD_WRITE_RUS != 11U || \
    XE_NP_NP2_LIVE_SD_COUNTED_WRITES || XE_NP_NP2_LIVE_SD_PREERASE_HINT
#error "Rolling CMD25 requires direct 13-RU triple capture, linked IDMA and CMD12 termination"
#endif
#endif
#ifndef XE_NP_NP2_LIVE_SD_ROLLING_SYNTHETIC
#define XE_NP_NP2_LIVE_SD_ROLLING_SYNTHETIC 0U
#endif
#ifndef XE_NP_NP2_STAGED_SYNTHETIC
#define XE_NP_NP2_STAGED_SYNTHETIC 0U
#endif
#if XE_NP_NP2_LIVE_SD_ROLLING_SYNTHETIC && !XE_NP_NP2_LIVE_SD_ROLLING_CMD25
#error "Synthetic rolling source is limited to the bounded rolling CMD25 experiment"
#endif
#if XE_NP_NP2_STAGED_SYNTHETIC && !XE_NP_NP2_STAGED_CAPTURE
#error "Synthetic staged source requires staged capture"
#endif
#define XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE \
    (XE_NP_NP2_LIVE_SD_ROLLING_SYNTHETIC || XE_NP_NP2_STAGED_SYNTHETIC)
/* COPY_COST_GUARDS_BEGIN */
#if (XE_NP_NP2_LIVE_SD_COPY_COST_DIAG!=0U && XE_NP_NP2_LIVE_SD_COPY_COST_DIAG!=1U) || \
    (XE_NP_NP2_LIVE_SD_COPY_COST_DIAG && \
     (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
      !XE_NP_NP2_LIVE_SD_VSC_TEST || XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U || \
      !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || \
      !XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS || !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || \
      !XE_NP_NP2_LIVE_SD_LAUNCH_WAIT_DIAG || XE_NP_NP2_LIVE_SD_DIRECT || \
      XE_NP_NP2_STAGED_CAPTURE || XE_NP_NP2_LIVE_SD_ROLLING_CMD25 || \
      XE_NP_NP2_LIVE_SD_PSRAM_SPILL || XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST || \
      XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE))
#error "Copy-cost observer requires the copied runtime VSC fixed1024 OOO launch-wait writer"
#endif
/* COPY_COST_GUARDS_END */
/* WHOLE_RU_GUARDS_BEGIN */
#if XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_TEST && \
    (!XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || \
     !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || \
     XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U || XE_NP_NP2_LIVE_SD_DIRECT || \
     XE_NP_NP2_STAGED_CAPTURE || XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST || \
     (XE_NP_NP2_LIVE_SD_LAST_FREE_PREFETCH_TEST && !XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_VSC_TEST) || \
     XE_NP_NP2_LIVE_SD_VSC_PRESSURE_PREFIX_TEST)
#error "Whole-RU geometry requires the copied ordered fixed-descriptor backend without other admission trials"
#endif
/* WHOLE_RU_GUARDS_END */
/* HIGH_TWO_PSRAM_IDMA_GUARDS_BEGIN */
#if XE_NP_NP2_SD_HIGH_TWO_PSRAM_IDMA_TEST && \
    (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
     !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || \
     !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || !XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS || \
     XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U || XE_NP_NP2_LIVE_SD_DIRECT || \
     XE_NP_NP2_STAGED_CAPTURE || XE_NP_NP2_LIVE_SD_PSRAM_SPILL || \
     XE_NP_NP2_LIVE_SD_LAST_FREE_PREFETCH_TEST || XE_NP_NP2_LIVE_SD_VSC_PRESSURE_PREFIX_TEST || \
     XE_NP_NP2_LIVE_SD_COPY_COST_DIAG || XE_NP_NP2_LIVE_SD_COPY_SPLIT_PORTS_TEST)
#error "High-two PSRAM IDMA requires the runtime fixed1024 FIFO without other admission/copy trials"
#endif
/* HIGH_TWO_PSRAM_IDMA_GUARDS_END */
/* COPY_SPLIT_PORTS_GUARDS_BEGIN */
#if XE_NP_NP2_LIVE_SD_COPY_SPLIT_PORTS_TEST && \
    (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
     !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || \
     XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U || \
     XE_NP_NP2_LIVE_SD_OVERFLOW_DMA_BURST_WORDS!=1U || \
     XE_NP_NP2_LIVE_SD_SPILL_DEST_BURST4_TEST || XE_NP_NP2_LIVE_SD_PSRAM_SPILL || \
     XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_STAGED_CAPTURE || \
     XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST || XE_NP2_STAGE_DIRECT_PSRAM_IDMA || \
     XE_NP_NP2_LIVE_SD_ROLLING_CMD25 || XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE)
#error "Copy split-ports requires the copied runtime fixed1024 OOO burst1 SD APP"
#endif
/* COPY_SPLIT_PORTS_GUARDS_END */
#define WRITE_WALL_TIMING (XE_NP_NP2_LIVE_SD_PROBE_MASK == 3U && \
    XE_NP_NP2_USB_PACKED_DUAL && !XE_NP_NP2_LIVE_SD_DIRECT && \
    !XE_NP_NP2_STAGED_CAPTURE && !XE_NP_NP2_LIVE_SD_ROLLING_CMD25 && \
    !XE_NP_NP2_LIVE_SD_LAUNCH_WAIT_DIAG)
#if XE_NP_NP2_LIVE_SD_PACK_TIMING_DIAG && !WRITE_WALL_TIMING
#error "Packing timing requires copied packed-dual capture without launch-wait diagnostics"
#endif
#if XE_NP_NP2_LIVE_SD_PACK_TIMING_DIAG || XE_NP_NP2_LIVE_SD_TRIPLE_COPY_TIMING_DIAG || XE_NP_NP2_LIVE_SD_COPY_COST_DIAG || XE_NP_NP2_LIVE_SD_DATA_PHASE_DIAG
#include <stddef.h>
#endif
#if XE_NP_NP2_LIVE_SD_DATA_PHASE_DIAG
_Static_assert(sizeof(XE_NP_Np2LiveSdPerf)==192U &&
               offsetof(XE_NP_Np2LiveSdPerf,diagnostic.data_detail.previous_dcount)==176U &&
               offsetof(XE_NP_Np2LiveSdPerf,diagnostic.data_detail.unchanged_sta_or)==188U,
               "DATA-phase samples must reuse the fixed performance tail without moving RAM");
#endif
#if XE_NP_NP2_LIVE_SD_COPY_COST_DIAG
_Static_assert(sizeof(XE_NP_Np2LiveSdPerf)==192U &&
               offsetof(XE_NP_Np2LiveSdPerf,diagnostic)==176U,
               "Copy-cost observer must not change the existing performance ABI");
#endif
#if XE_NP_NP2_LIVE_SD_PACK_TIMING_DIAG
_Static_assert(sizeof(XE_NP_Np2LiveSdPerf)==192U &&
               offsetof(XE_NP_Np2LiveSdPerf,diagnostic.pack.cycles)==176U &&
               offsetof(XE_NP_Np2LiveSdPerf,diagnostic.pack.calls)==184U &&
               offsetof(XE_NP_Np2LiveSdPerf,diagnostic.pack.max_cycles)==188U,
               "Packing timing must reuse the fixed performance tail without moving RAM");
#endif
#if XE_NP_NP2_LIVE_SD_TRIPLE_COPY_TIMING_DIAG && \
    (XE_NP_NP2_LIVE_SD_PACK_TIMING_DIAG || XE_NP_NP2_LIVE_SD_LAUNCH_WAIT_DIAG || \
     XE_NP_NP2_LIVE_SD_WRITE_LATENCY_DIAG || XE_NP_NP2_LIVE_SD_DIRECT || \
     !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES)
#error "Raw-triple copy timing requires copied runtime profiles without another tail diagnostic"
#endif
#if XE_NP_NP2_LIVE_SD_TRIPLE_COPY_TIMING_DIAG
_Static_assert(sizeof(XE_NP_Np2LiveSdPerf)==192U &&
               offsetof(XE_NP_Np2LiveSdPerf,diagnostic.triple_copy.pssi_copy_cycles)==176U &&
               offsetof(XE_NP_Np2LiveSdPerf,diagnostic.triple_copy.d8_copy_cycles)==184U,
               "Raw-triple timing must reuse the fixed performance tail without moving RAM");
#endif
#include "xe_np_np2_producer.h"
#include "xe_np_np2_usb_source.h"
#include "xe_np_np2_usb_wire.h"
#include "xe_np_np2_transport.h"
#if XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST
#include "stm32u5xx_hal_sd_ex.h"
#endif
#if XE_NP_NP2_LIVE_SD_PSRAM_SPILL || XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
#include "xe_np_psram.h"
#endif

#include <string.h>


#if XE_NP_NP2_LIVE_SD_VERIFY_CLOCK_DIV > 0x1FFU
#error "Post-record SD readback clock divider exceeds SDMMC CLKDIV"
#endif

#if XE_NP_BOARD_SD_DMA_READ_POLLING_ENABLE || XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U
/* main.c provides the foreground-polled IDMA reader when RX clock 2 is
 * selected. It services the SD interrupt state machine without relying on
 * FIFO polling at the 116 MHz SDR104 bus rate. */
HAL_StatusTypeDef XE_NP_Board_SdReadBlocksDmaPolling(SD_HandleTypeDef *card,
    uint8_t *data,uint32_t block,uint32_t blocks,uint32_t timeout_ms);
#endif

#if !XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || \
    !(XE_NP_BOARD_EXPERIMENTAL_NP2_128MHZ_20KHZ_CORE || XE_NP_BOARD_EXPERIMENTAL_NP2_192MHZ_CORE) || \
    !XE_NP_NP2_USB_SOURCE_ENABLE || !XE_NP_NP2_CAPTURE_PORT_ENABLE || \
    (!XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES && \
     ((XE_NP_NP2_LIVE_SD_PROBE_MASK == 7U) != (XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE != 0U))) || \
    XE_NP_NP2_CAPTURE_16BIT_PSSI || \
    (XE_NP_NP2_USB_V3_ENABLE == 0U) || (XE_NP_NP2_USB_V3_PROBE_MASK != 7U) || \
    (XE_NP_NP2_USB_V3_LIVE_PROBE_MASK != 7U) || XE_NP_IMAGE_ROLE != XE_NP_IMAGE_SD_APP
#error "Live NP2 SD requires PSSI8 and SPI2-D8 only for three probes"
#endif

#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES && \
    (XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_STAGED_CAPTURE || \
     XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE || XE_NP_NP2_LIVE_SD_ROLLING_CMD25 || \
     XE_NP_NP2_LIVE_SD_PSRAM_SPILL || !XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE || \
     !XE_NP_NP2_USB_PACKED_DUAL || XE_NP_NP2_LIVE_SD_PROBE_MASK!=3U || \
     !XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS || \
     !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || XE_NP_NP2_LIVE_SD_SPILL_HOLD_TEST || \
     XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_TEST || XE_NP_NP2_DIRECT_D8_RAW_PHASE || \
     XE_NP_PSRAM_OVERFLOW_PLL2Q108)
#error "Runtime profiles use copied-nine SRAM, packed dual/raw9 and cold-selected SPI D8"
#endif

#if XE_NP_NP2_LIVE_SD_DURATION_SECONDS < 1U || XE_NP_NP2_LIVE_SD_DURATION_SECONDS > 600U
#error "Live NP2 SD validation duration must be 1..600 seconds"
#endif

/* Preserve exactly the USB-qualified wire format on media. Four 91-sector
 * stream blocks form one 364-sector RU; CMD25 batches are profile-selected.
 * The copied backend uses eight units (nine in the explicit SRAM trial);
 * direct DMA uses twelve units and no separate acquisition rings. */
#define STREAM_BYTES       XE_NP_NP2_USB_BLOCK_BYTES
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
static uint32_t record_probe_mask=3U,record_stream_ticks=61440U;
static uint32_t record_stored_bits=6U,record_codec=XE_NP_NP2_USB_V3_CODEC_PACKED;
#define STREAM_TICKS record_stream_ticks
#define LIVE_BITS record_stored_bits
#define LIVE_CODEC record_codec
#define LIVE_PROBE_MASK record_probe_mask
#elif XE_NP_NP2_LIVE_SD_PROBE_MASK == 1U
#define STREAM_TICKS 122880U
#define LIVE_BITS 3U
#define LIVE_CODEC XE_NP_NP2_USB_V3_CODEC_PACKED
#elif XE_NP_NP2_LIVE_SD_PROBE_MASK == 3U
#if XE_NP_NP2_USB_PACKED_DUAL
#define STREAM_TICKS XE_NP_NP2_DUAL_SD_TICKS_PER_BLOCK
#define LIVE_BITS 6U
#define LIVE_CODEC XE_NP_NP2_USB_V3_CODEC_PACKED
#else
#define STREAM_TICKS 46080U
#define LIVE_BITS 8U
#define LIVE_CODEC XE_NP_NP2_USB_V3_CODEC_RAW8
#endif
#elif XE_NP_NP2_LIVE_SD_PROBE_MASK == 7U
#define STREAM_TICKS 40960U
#define LIVE_BITS 9U
#define LIVE_CODEC XE_NP_NP2_USB_V3_CODEC_PSSI8_SPI_D8
#else
#error "Unsupported SD probe mask"
#endif
#if !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
#define LIVE_PROBE_MASK XE_NP_NP2_LIVE_SD_PROBE_MASK
#endif
#if XE_NP_NP2_LIVE_SD_DIRECT && XE_NP_NP2_LIVE_SD_PROBE_MASK != 7U
#error "Direct DMA record layout requires three probes"
#endif
#define STREAM_PAYLOAD     XE_NP_NP2_USB_PAYLOAD_BYTES
#if XE_NP_NP2_LIVE_SD_PROBE_MASK == 7U
#if XE_NP_NP2_USB_PACKED_DUAL
#error "Three-probe SD stores raw PSSI8 plus SPI D8; dual packing is forbidden"
#endif
_Static_assert(LIVE_CODEC == XE_NP_NP2_USB_V3_CODEC_PSSI8_SPI_D8 && LIVE_BITS == 9U,
               "Three-probe records must preserve all eight PSSI bits and SPI D8");
_Static_assert(STREAM_PAYLOAD == STREAM_TICKS + STREAM_TICKS/8U,
               "Raw PSSI bytes must precede the separate SPI bit plane");
#endif
#define BLOCKS_PER_RU      4U
#define RU_BYTES           (STREAM_BYTES*BLOCKS_PER_RU)
#define RU_BLOCKS          (RU_BYTES/512U)
/* Largest cache-line-aligned 16-bit GPDMA byte count: three kicks per dual
 * RU, without changing burst/priority or publishing partial ownership. */
#define OVERFLOW_COPY_BYTES 65504U
#if XE_NP_NP2_SD_LINKED_COPY_TEST
_Static_assert(RU_BYTES==186368U && 2U*OVERFLOW_COPY_BYTES<RU_BYTES &&
               RU_BYTES-2U*OVERFLOW_COPY_BYTES<=OVERFLOW_COPY_BYTES,
               "Linked COPY requires exactly three whole-word normal-geometry nodes");
#endif
_Static_assert(OVERFLOW_COPY_BYTES <= 65535U && (OVERFLOW_COPY_BYTES % 32U) == 0U,
               "Overflow DMA chunks must fit BNDT and preserve cache-line alignment");
#if XE_NP_NP2_LIVE_SD_PROBE_MASK == 3U && XE_NP_NP2_USB_PACKED_DUAL
_Static_assert(STREAM_BYTES == XE_NP_NP2_DUAL_SD_BYTES_PER_BLOCK &&
               BLOCKS_PER_RU == XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU &&
               RU_BLOCKS == XE_NP_NP2_DUAL_SD_SECTORS_PER_RU,
               "Dual NP2 run geometry differs from validated SD writer");
#endif
#if XE_NP_NP2_LIVE_SD_ROLLING_CMD25
#ifndef XE_NP_NP2_LIVE_SD_ROLLING_WINDOW_RUS
#define XE_NP_NP2_LIVE_SD_ROLLING_WINDOW_RUS 32U
#endif
#if XE_NP_NP2_LIVE_SD_ROLLING_WINDOW_RUS != 32U && XE_NP_NP2_LIVE_SD_ROLLING_WINDOW_RUS != 64U && XE_NP_NP2_LIVE_SD_ROLLING_WINDOW_RUS != 180U
#error "Rolling CMD25 window must be 32, 64 or the DLEN-limited 180 RUs"
#endif
#define ROLLING_WRITE_RUS  XE_NP_NP2_LIVE_SD_ROLLING_WINDOW_RUS
#define ROLLING_PRIME_RUS  12U
_Static_assert(ROLLING_WRITE_RUS*RU_BYTES<=SDMMC_DLEN_DATALENGTH_Msk,
               "Rolling CMD25 host data window exceeds SDMMC DLEN");
#endif
#if XE_NP_NP2_LIVE_SD_EXTENDED_RING
#if !XE_NP_NP2_LIVE_SD_DIRECT || !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || \
    ((XE_NP_NP2_LIVE_SD_WRITE_RUS != 4U) && (XE_NP_NP2_LIVE_SD_WRITE_RUS != 8U) && \
     (XE_NP_NP2_LIVE_SD_WRITE_RUS != 11U))
#error "The 13-RU direct ring is restricted to 4-, 8- or 11-RU linked-list profiles"
#endif
#define RU_COUNT           13U
#elif XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
#define RU_COUNT           RUNTIME_DIRECT_RU_CAPACITY
#elif XE_NP_NP2_LIVE_SD_DIRECT
#define RU_COUNT           12U
#elif XE_NP_NP2_SD_RAW_INGRESS_RU_TEST
#define RU_COUNT           10U
#elif XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS
#define RU_COUNT           9U
#else
#define RU_COUNT           8U
#endif
#if XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST
#if (XE_NP_NP2_LIVE_SD_DIRECT && XE_NP_NP2_LIVE_SD_PROBE_MASK != 7U) || \
    (!XE_NP_NP2_LIVE_SD_DIRECT && (XE_NP_NP2_LIVE_SD_PROBE_MASK != 3U || \
                                   XE_NP_NP2_LIVE_SD_PSRAM_SPILL))
#error "SD IDMA linked-list mode requires direct three-probe or SRAM-only copied dual capture"
#endif
#if XE_NP_NP2_STAGED_CAPTURE
#if XE_NP_NP2_STAGED_LONG_CMD25
#ifndef XE_NP_NP2_STAGED_LONG_WINDOW_RUS
#define XE_NP_NP2_STAGED_LONG_WINDOW_RUS XE_NP2_STAGE_LONG_MAX_RUS
#endif
#ifndef XE_NP_NP2_STAGED_LONG_LEAD_TARGET_RUS
#define XE_NP_NP2_STAGED_LONG_LEAD_TARGET_RUS 48U
#endif
#if XE_NP_NP2_STAGED_LONG_WINDOW_RUS != 11U && XE_NP_NP2_STAGED_LONG_WINDOW_RUS != 16U && XE_NP_NP2_STAGED_LONG_WINDOW_RUS != 32U && XE_NP_NP2_STAGED_LONG_WINDOW_RUS != 180U
#error "Staged open-ended CMD25 window must be 11, 16, 32 or 180 RUs"
#endif
#if XE_NP_NP2_STAGED_LONG_LEAD_TARGET_RUS != 9U && XE_NP_NP2_STAGED_LONG_LEAD_TARGET_RUS != 16U && XE_NP_NP2_STAGED_LONG_LEAD_TARGET_RUS != 24U && XE_NP_NP2_STAGED_LONG_LEAD_TARGET_RUS != 32U && XE_NP_NP2_STAGED_LONG_LEAD_TARGET_RUS != 36U && XE_NP_NP2_STAGED_LONG_LEAD_TARGET_RUS != 48U
#error "180-RU staged CMD25 launch lead must be 9, 16, 24, 32, 36 or 48 RUs"
#endif
#define MAX_WRITE_RUS      XE_NP_NP2_STAGED_LONG_WINDOW_RUS
#define MIN_WRITE_RUS      (MAX_WRITE_RUS<=16U?6U:XE_NP2_STAGE_STORE_RUS)
#else
/* Seven staged RUs fit 21 descriptors while leaving source and storage
 * headroom. The physical 13-RU profile is selected by WRITE_RUS=11. */
#define MAX_WRITE_RUS      XE_NP2_STAGE_MAX_SD_UNITS
#define MIN_WRITE_RUS      XE_NP2_STAGE_MAX_SD_UNITS
#endif
#elif XE_NP_NP2_LIVE_SD_ROLLING_CMD25
#define MAX_WRITE_RUS      ROLLING_WRITE_RUS
#define MIN_WRITE_RUS      ROLLING_PRIME_RUS
#else
#define MAX_WRITE_RUS      XE_NP_NP2_LIVE_SD_WRITE_RUS
#ifndef XE_NP_NP2_LIVE_SD_MIN_WRITE_RUS
#if MAX_WRITE_RUS == 11U
/* Preserve the validated adaptive 8-RU startup unless a measured profile
 * explicitly selects a smaller readiness threshold. */
#define XE_NP_NP2_LIVE_SD_MIN_WRITE_RUS 8U
#else
#define XE_NP_NP2_LIVE_SD_MIN_WRITE_RUS MAX_WRITE_RUS
#endif
#endif
#define MIN_WRITE_RUS      XE_NP_NP2_LIVE_SD_MIN_WRITE_RUS
#ifndef XE_NP_NP2_LIVE_SD_COPIED_DUAL_ADAPTIVE
#define XE_NP_NP2_LIVE_SD_COPIED_DUAL_ADAPTIVE 0U
#endif
#if XE_NP_NP2_LIVE_SD_COPIED_DUAL_ADAPTIVE && \
    (XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_LIVE_SD_PROBE_MASK != 3U || \
     !XE_NP_NP2_USB_PACKED_DUAL || (MAX_WRITE_RUS != 4U && MAX_WRITE_RUS != 6U) || \
     (MIN_WRITE_RUS != 1U && MIN_WRITE_RUS != 2U))
#error "Copied dual adaptive writes require packed dual SRAM capture and an admitted 4/6-RU cap"
#endif
#if MIN_WRITE_RUS < 1U || MIN_WRITE_RUS > MAX_WRITE_RUS
#error "Minimum CMD25 batch must be in 1..MAX_WRITE_RUS"
#endif
#if MAX_WRITE_RUS != 11U && MIN_WRITE_RUS != MAX_WRITE_RUS && !XE_NP_NP2_LIVE_SD_COPIED_DUAL_ADAPTIVE
#error "Adaptive minimum requires the 11-RU or explicit copied-dual linked-list profile"
#endif
#endif
/* STM32CubeU5's validated U5 linked-list path uses 127-sector nodes. Split at
 * physical bank boundaries; a wrapped 8-RU command can span three banks. */
#define SD_LLI_MAX_BYTES   (127U*512U)
#if XE_NP_NP2_STAGED_LONG_CMD25
#define SD_LLI_MAX_NODES   (MAX_WRITE_RUS*XE_NP2_STAGE_NODES_PER_RU)
#elif XE_NP_NP2_LIVE_SD_ROLLING_CMD25
#define SD_LLI_MAX_NODES   (ROLLING_WRITE_RUS*3U)
#elif XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
#define SD_LLI_MAX_NODES   (3U*XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_RUS)
#elif !XE_NP_NP2_LIVE_SD_DIRECT
#define SD_LLI_MAX_NODES   (MAX_WRITE_RUS*3U)
#else
#define SD_LLI_MAX_NODES   36U
#endif
_Static_assert((SD_LLI_MAX_BYTES%512U)==0U && SD_LLI_MAX_BYTES<=
               (((SDMMC_IDMABSIZE_IDMABNDT_Msk>>SDMMC_IDMABSIZE_IDMABNDT_Pos)*32U)),
               "SD IDMA node size must be sector aligned and fit IDMABSIZE");
#else
#define MAX_WRITE_RUS      XE_NP_NP2_LIVE_SD_WRITE_RUS
#endif
#if XE_NP_NP2_LIVE_SD_FAULT_SD_PINS_TEST && \
    (!XE_NP_NP2_LIVE_SD_OVERFLOW_FAULT_DIAG || MAX_WRITE_RUS!=6U || \
     !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST)
#error "Fault pin snapshot requires the six-RU copied fault diagnostic"
#endif
#if XE_NP_NP2_SD_RAW_INGRESS_RU_TEST && \
    (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
     !XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS || !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || \
     !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U || \
     XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_LIVE_SD_FAULT_SD_PINS_TEST || MAX_WRITE_RUS!=6U)
#error "Raw-ingress RU trial requires the unchanged copied runtime six-RU SD writer"
#endif
#if XE_NP_NP2_LIVE_SD_SKIP_BATCH_HINT_TEST && \
    (!XE_NP_NP2_LIVE_SD_PREERASE_HINT || !XE_NP_NP2_LIVE_SD_COUNTED_WRITES || \
     !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || MAX_WRITE_RUS!=6U)
#error "Batch-hint comparison requires the retained counted six-RU writer"
#endif
/* The ninth RU reuses SRAM slack, not the direct or external-memory backend. */
#if XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS && \
    (XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_LIVE_SD_EXTENDED_RING || \
     XE_NP_NP2_STAGED_CAPTURE || XE_NP_NP2_LIVE_SD_ROLLING_CMD25 || \
     XE_NP_NP2_LIVE_SD_PSRAM_SPILL || XE_NP_NP2_LIVE_SD_PROBE_MASK != 3U || \
     !XE_NP_NP2_USB_PACKED_DUAL || !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || \
     !XE_NP_NP2_LIVE_SD_COPIED_DUAL_ADAPTIVE || (MAX_WRITE_RUS != 4U && MAX_WRITE_RUS != 6U) || MIN_WRITE_RUS != 1U)
#error "Copied nine-RU trial requires packed dual linked adaptive1..4/6 and no other backend"
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA && !XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS
#error "Overflow DMA requires the copied-nine packed dual adaptive profile"
#endif
#if !XE_NP_NP2_STAGED_LONG_CMD25 && MAX_WRITE_RUS != 1U && MAX_WRITE_RUS != 2U && MAX_WRITE_RUS != 4U && \
    (!XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || \
      (MAX_WRITE_RUS != 6U && MAX_WRITE_RUS != 7U && MAX_WRITE_RUS != 8U && MAX_WRITE_RUS != 10U && MAX_WRITE_RUS != 11U && \
      !(XE_NP_NP2_LIVE_SD_ROLLING_CMD25 && MAX_WRITE_RUS == ROLLING_WRITE_RUS)))
#error "Live SD batches must be 1, 2 or 4 RUs; 8/10/11 RUs require linked-list mode"
#endif
#if MAX_WRITE_RUS>RU_COUNT-1U && !XE_NP_NP2_LIVE_SD_ROLLING_CMD25 && !XE_NP_NP2_STAGED_LONG_CMD25
#error "CMD25 must leave at least one RU available for acquisition while IDMA owns buffers"
#endif
#ifndef XE_NP_NP2_LIVE_SD_WRITE_CAP_RUS
#define XE_NP_NP2_LIVE_SD_WRITE_CAP_RUS MAX_WRITE_RUS
#endif
#if XE_NP_NP2_LIVE_SD_WRITE_CAP_RUS < MIN_WRITE_RUS || XE_NP_NP2_LIVE_SD_WRITE_CAP_RUS > MAX_WRITE_RUS
#error "CMD25 cap must preserve the configured minimum and never exceed the physical maximum"
#endif
#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST && XE_NP_NP2_LIVE_SD_WRITE_CAP_RUS != 6U
#error "Fixed-sector trial requires the existing six-RU descriptor reserve"
#endif
#if XE_NP_NP2_SD_SINGLE7500_WINDOW2048_TEST
/* 2048 sectors touch at most seven364-sector RUs, but still need at most
 * eighteen127-sector IDMA nodes. Ordinary whole-RU command caps stay six. */
#define FIXED_FRAGMENT_OWNERS 7U
_Static_assert(MAX_WRITE_RUS==6U && RU_COUNT==(XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST?
               9U+NP2_RUNTIME_DIRECT_RESTORE_RUS:9U) && SD_LLI_MAX_NODES==
#if XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
               (3U*XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_RUS),
#else
               18U,
#endif
               "Single7500 window preserves the nine-RU/eighteen-node layout");
#else
#define FIXED_FRAGMENT_OWNERS MAX_WRITE_RUS
#endif
#if XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
#if !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
    !XE_NP_NP2_LIVE_SD_COUNTED_WRITES || !XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST || \
    !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || !XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST || \
    XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_STAGED_CAPTURE || \
    XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST || XE_NP_NP2_SD_RAW_INGRESS_RU_TEST || MAX_WRITE_RUS!=6U
#error "Copied counted window requires the existing copied-nine sequential counted writer"
#endif
#define DMA_WINDOW_OWNERS XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_RUS
#else
#define DMA_WINDOW_OWNERS FIXED_FRAGMENT_OWNERS
#endif
#if MAX_WRITE_RUS == 6U && (!XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS || \
    !XE_NP_NP2_LIVE_SD_COPIED_DUAL_ADAPTIVE || !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || \
    !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || \
    MIN_WRITE_RUS != 1U || (XE_NP_NP2_LIVE_SD_WRITE_CAP_RUS != 2U && \
    XE_NP_NP2_LIVE_SD_WRITE_CAP_RUS != 6U))
#error "Six-RU storage requires copied-nine linked OOO overflow adaptive MIN1/CAP2 or CAP6"
#endif
#if XE_NP_NP2_LIVE_SD_STARTUP_PRIME_TEST && \
    (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS || \
     !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || MAX_WRITE_RUS!=6U || \
     !XE_NP_NP2_LIVE_SD_COUNTED_WRITES || !XE_NP_NP2_LIVE_SD_PREERASE_HINT)
#error "Startup prime is limited to the reserved counted six-RU catalog experiment"
#endif
#define SCRATCH_START_LBA  67108864U
#ifndef XE_NP_NP2_LIVE_SD_SAMPLE_HZ
#define XE_NP_NP2_LIVE_SD_SAMPLE_HZ 20000U
#endif
#if XE_NP_NP2_LIVE_SD_SAMPLE_HZ != 15000U && XE_NP_NP2_LIVE_SD_SAMPLE_HZ != 20000U && XE_NP_NP2_LIVE_SD_SAMPLE_HZ != 30000U
#error "SD diagnostic supports 15, 20 or 30 kS/s"
#endif
#define LIVE_MCLK_HZ (XE_NP_NP2_LIVE_SD_SAMPLE_HZ*1600U)
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
#define DIAGNOSTIC_STREAM_TICKS XE_NP_NP2_DUAL_SD_TICKS_PER_BLOCK
#else
#define DIAGNOSTIC_STREAM_TICKS STREAM_TICKS
#endif
#define TARGET_BLOCKS_RAW  ((uint32_t)(((uint64_t)LIVE_MCLK_HZ*XE_NP_NP2_LIVE_SD_DURATION_SECONDS)/DIAGNOSTIC_STREAM_TICKS))
#define TARGET_BLOCKS      (XE_NP_NP2_LIVE_SD_BLOCK_LIMIT?XE_NP_NP2_LIVE_SD_BLOCK_LIMIT:(TARGET_BLOCKS_RAW&~(BLOCKS_PER_RU-1U)))
#define TARGET_RUS         (TARGET_BLOCKS/BLOCKS_PER_RU)
#define SCRATCH_END_LBA    (SCRATCH_START_LBA+TARGET_RUS*RU_BLOCKS)
#define ERASE_TIMEOUT_MS   180000U
#define WRITE_TIMEOUT_MS   3000U
#define STATUS_POLL_CYCLES (128U*50U) /* 50 us, only after DAT0 is released */
#define ERROR_FLAGS        (SDMMC_FLAG_DCRCFAIL|SDMMC_FLAG_DTIMEOUT|SDMMC_FLAG_TXUNDERR|SDMMC_FLAG_IDMATE)

_Static_assert(STREAM_BYTES==46592U && STREAM_PAYLOAD==46080U,"NP2USB03 geometry changed");
_Static_assert(STREAM_BYTES%512U==0U && RU_BYTES%512U==0U,"SD write units must be whole sectors");
_Static_assert(TARGET_BLOCKS>=BLOCKS_PER_RU,"Live test must contain a complete write unit");
_Static_assert(TARGET_BLOCKS%4U==0U && TARGET_BLOCKS<=TARGET_BLOCKS_RAW,"Block limit must be whole RUs within duration");

enum {RU_FREE=0U,RU_FILLING=1U,RU_READY=2U,RU_DMA=3U,RU_COPY=4U};

#if defined(XE_NP_NP2_LIVE_SD_NATIVE_MODEL)
/* Host tests model the linker's contiguous four-unit bank reservations. */
__declspec(align(32)) static uint8_t model_ru_pool[RU_COUNT][RU_BYTES];
#define ru0 model_ru_pool[0]
#define ru1 model_ru_pool[1]
#define ru2 model_ru_pool[2]
#define ru3 model_ru_pool[3]
#define ru4 model_ru_pool[4]
#define ru5 model_ru_pool[5]
#define ru6 model_ru_pool[6]
#define ru7 model_ru_pool[7]
#if XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS
#define ru8 model_ru_pool[8]
#endif
#if XE_NP_NP2_SD_RAW_INGRESS_RU_TEST
/* The tenth physical allocation is an independent bank on hardware. A
 * contiguous host pool would hide stopped-start adjacency assumptions. */
__declspec(align(32)) static struct {
    uint8_t before[32],bytes[RU_BYTES],after[32];
} model_extra_ru;
#define ru9 model_extra_ru.bytes
#elif XE_NP_NP2_LIVE_SD_DIRECT
#define ru9 model_ru_pool[9]
#endif
#if XE_NP_NP2_LIVE_SD_DIRECT
#define ru10 model_ru_pool[10]
#define ru11 model_ru_pool[11]
#if XE_NP_NP2_LIVE_SD_EXTENDED_RING
#define ru12 model_ru_pool[12]
#endif
#endif
#else
static uint8_t ru0[RU_BYTES] __attribute__((section("NP2_LIVE_RU0"),aligned(32)));
static uint8_t ru1[RU_BYTES] __attribute__((section("NP2_LIVE_RU1"),aligned(32)));
static uint8_t ru2[RU_BYTES] __attribute__((section("NP2_LIVE_RU2"),aligned(32)));
static uint8_t ru3[RU_BYTES] __attribute__((section("NP2_LIVE_RU3"),aligned(32)));
static uint8_t ru4[RU_BYTES] __attribute__((section("NP2_LIVE_RU4"),aligned(32)));
static uint8_t ru5[RU_BYTES] __attribute__((section("NP2_LIVE_RU5"),aligned(32)));
static uint8_t ru6[RU_BYTES] __attribute__((section("NP2_LIVE_RU6"),aligned(32)));
static uint8_t ru7[RU_BYTES] __attribute__((section("NP2_LIVE_RU7"),aligned(32)));
#if XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS
static uint8_t ru8[RU_BYTES] __attribute__((section("NP2_LIVE_RU8"),aligned(32)));
#endif
#if XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_SD_RAW_INGRESS_RU_TEST
static uint8_t ru9[RU_BYTES] __attribute__((section("NP2_LIVE_RU9"),aligned(32)));
#endif
#if XE_NP_NP2_LIVE_SD_DIRECT
static uint8_t ru10[RU_BYTES] __attribute__((section("NP2_LIVE_RU10"),aligned(32)));
static uint8_t ru11[RU_BYTES] __attribute__((section("NP2_LIVE_RU11"),aligned(32)));
#if XE_NP_NP2_LIVE_SD_EXTENDED_RING
static uint8_t ru12[RU_BYTES] __attribute__((section("NP2_LIVE_RU12"),aligned(32)));
#endif
#endif
#endif
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
static uint8_t *ru[RU_COUNT];
#define RU_POOL_NAME ru_pool
#else
#define RU_POOL_NAME ru
#endif
static uint8_t *const RU_POOL_NAME[RU_COUNT]={ru0,ru1,ru2,ru3,ru4,ru5,ru6,ru7
#if XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS && !XE_NP_NP2_LIVE_SD_DIRECT
    ,ru8
#if XE_NP_NP2_SD_RAW_INGRESS_RU_TEST
    ,ru9
#endif
#endif
#if XE_NP_NP2_LIVE_SD_DIRECT
    ,ru8,ru9,ru10,ru11
#if XE_NP_NP2_LIVE_SD_EXTENDED_RING
    ,ru12
#endif
#endif
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
#if defined(XE_NP_NP2_LIVE_SD_NATIVE_MODEL)
    ,model_ru_pool[9],model_ru_pool[10],model_ru_pool[11]
#else
    ,(uint8_t *)(uintptr_t)NP2_RUNTIME_DIRECT_RESTORE_BASE
    ,(uint8_t *)(uintptr_t)(NP2_RUNTIME_DIRECT_RESTORE_BASE+RU_BYTES)
    ,(uint8_t *)(uintptr_t)(NP2_RUNTIME_DIRECT_RESTORE_BASE+2U*RU_BYTES)
#endif
#endif
};
#undef RU_POOL_NAME
static volatile uint8_t ru_state[RU_COUNT];
static uint32_t ru_first_block[RU_COUNT];
#if XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE
static uint32_t sensor_tail_publication;
static uint8_t sensor_tail_seen;
static void sensor_append_legacy(uint8_t *block);
#endif
#if XE_NP_NP2_LIVE_SD_VERIFY_READ_RETRY_TEST
#if !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || !XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS || \
    XE_NP_NP2_LIVE_SD_VERIFY_CLOCK_DIV || XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_STAGED_CAPTURE
#error "Read retry diagnostic requires the ordinary-clock copied9 OOO trial"
#endif
/* Failure-only, never consulted during recording. RU0 remains the rejected
 * original; RU1/RU2 retain independent same-clock/quarter-clock media reads.
 * magic/version/state/guard/sequence/LBA/CLKCR before/after, then two each of
 * read status, SD error, changed-byte count, first changed-byte offset.
 * State1=refused,2=first complete,3=both complete/restored,4=read/idle failure. */
volatile uint32_t xe_np_np2_verify_retry_diag[16] __attribute__((aligned(32)));
#endif
#if XE_NP_NP2_STAGED_CAPTURE
static XE_Np2StageQueue stage_queue;
#if XE_NP_NP2_STAGED_LONG_CMD25
static XE_Np2StageLongWindow stage_long_window;
_Static_assert(XE_NP2_STAGE_LONG_MAX_RUS*RU_BYTES<=SDMMC_DLEN_DATALENGTH_Msk,
               "Long staged CMD25 exceeds SDMMC DLEN");
#endif
static XE_Np2StageDma stage_dma;
static uint32_t stage_ru_base[RU_COUNT];
/* Failure-only receipt: no capture or SD service iteration touches this.
 * Keep the first 16 words stable for earlier snapshots. The added words
 * distinguish a card/DPSM stall from a completed transfer whose IRQ was
 * masked or disabled while acquisition continued. Word 27 counts the
 * staged writer's guarded late-DATAEND completion recoveries. */
volatile uint32_t xe_np_np2_stage_fault_diag[44];
/* Stopped-only 96-byte receipt, updated once per completed RU copy. For each
 * copy kind (to SRAM, to PSRAM, from PSRAM): count, 64-bit elapsed cycles,
 * maximum elapsed, 64-bit memcpy-call cycles, maximum memcpy-call cycles. */
volatile uint32_t xe_np_np2_stage_copy_diag[24];
#endif
#if XE_NP_NP2_LIVE_SD_PSRAM_SPILL || XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
#define SPILL_SLOTS 44U
_Static_assert(SPILL_SLOTS*RU_BYTES<=XE_NP_PSRAM_VALIDATED_SIZE_BYTES,"Overflow FIFO exceeds PSRAM");
#else
#define SPILL_SLOTS (XE_NP_PSRAM_SIZE_BYTES/RU_BYTES)
#endif
#define SPILL_FILL (RU_COUNT+1U)
static uint32_t spill_head,spill_tail,spill_count,spill_copy;
#if XE_NP_NP2_LIVE_SD_PSRAM_SPILL
static uint8_t spill_restore=RU_COUNT;
#endif
static uint32_t spill_sequence[SPILL_SLOTS];
static DMA_HandleTypeDef spill_dma;
static uint32_t spill_dma_bytes,spill_dma_started;
#if XE_NP_NP2_SD_LINKED_COPY_TEST
/* Separate cache lines from queue/control; all hardware nodes stay within the
 * existing single64KiB descriptor reservation, not the capture/recording rings. */
static DMA_NodeTypeDef spill_copy_nodes[3]
    __attribute__((section("NP2_DMA_DESCRIPTORS"),aligned(32)));
static DMA_QListTypeDef spill_copy_queue
    __attribute__((section("NP2_DMA_DESCRIPTORS"),aligned(32)));
#endif
#if XE_NP_NP2_LIVE_SD_PSRAM_SPILL
/* magic, completed spills, restored RUs, peak RUs, spill cycles, drain cycles */
volatile uint32_t xe_np_live_spill_diag[8]={0x53504C32U};
#else
static uint8_t overflow_ru=RU_COUNT,overflow_kind;
#if XE_NP_NP2_SD_OSPI_SLEEP_GATE_TEST
/* Lowest-profile only: gated WFIs, quiet-check refusals. No run-clock change. */
volatile uint32_t xe_np_np2_ospi_sleep_gate_diag[2];
#endif
#if XE_NP_NP2_SD_COPY_WAKE_TEST
static uint8_t spill_wake_owned;
/* Private measurement: IRQs, copy WFIs, all active WFIs, TC-before-IDLE visits. */
volatile uint32_t xe_np_np2_copy_wake_diag[4];
void GPDMA1_Channel14_IRQHandler(void)
{
    /* CCR.EN may auto-clear between a read and write. Mask only the owned
     * wake IRQ; do not replay stale EN or consume foreground TC/HAL state. */
    NVIC_DisableIRQ(GPDMA1_Channel14_IRQn);
    xe_np_np2_copy_wake_diag[0]++;
}
static void spill_wake_disarm(void)
{
    NVIC_DisableIRQ(GPDMA1_Channel14_IRQn);
    if(!(GPDMA1_Channel14->CCR&(DMA_CCR_EN|DMA_CCR_RESET|DMA_CCR_SUSP)))
        GPDMA1_Channel14->CCR&=~DMA_CCR_TCIE;
    HAL_NVIC_ClearPendingIRQ(GPDMA1_Channel14_IRQn);
}
static void spill_wake_retire(void)
{
    if(!spill_wake_owned)return;
    spill_wake_disarm();spill_wake_owned=0U;
}
static int spill_wake_prepare(void)
{
    /* Foreground is the sole C14 starter. Configure TCIE before EN, never
     * via a live CCR read/modify/write that could restart a completed leg. */
    if(!spill_wake_owned || NVIC_GetEnableIRQ(GPDMA1_Channel14_IRQn) ||
       spill_dma.State!=HAL_DMA_STATE_READY ||
       (GPDMA1_Channel14->CCR&(DMA_CCR_EN|DMA_CCR_RESET|DMA_CCR_SUSP)) ||
       GPDMA1_Channel14->CBR1 ||
       (GPDMA1_Channel14->CSR&(DMA_FLAG_TC|DMA_FLAG_DTE|DMA_FLAG_ULE|DMA_FLAG_USE)))return -1;
    HAL_NVIC_ClearPendingIRQ(GPDMA1_Channel14_IRQn);
    GPDMA1_Channel14->CCR|=DMA_CCR_TCIE;
    return 0;
}
static int spill_wake_pending(void)
{
    return spill_wake_owned && overflow_kind && spill_dma_bytes &&
        (GPDMA1_Channel14->CCR&(DMA_CCR_EN|DMA_CCR_TCIE|DMA_CCR_SUSP|DMA_CCR_RESET))==
            (DMA_CCR_EN|DMA_CCR_TCIE) &&
        !(GPDMA1_Channel14->CSR&(DMA_FLAG_TC|DMA_FLAG_IDLE|DMA_FLAG_DTE|DMA_FLAG_ULE|DMA_FLAG_USE));
}
#endif
static uint8_t dma_slots[DMA_WINDOW_OWNERS];
#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
#define FIXED_WINDOW_1536_MODE 9U /* Discriminator, not a power-of-two shift. */
#if XE_NP_NP2_SD_SINGLE7500_WINDOW2048_TEST || XE_NP_NP2_SD_DUAL20_WINDOW1536_TEST
/* Cold-selected after accepted profile/allocation; never changed by service. */
/* DUAL20_WINDOW1536_DATA_BEGIN */
#if XE_NP_NP2_SD_DUAL20_WINDOW1536_TEST
/* Do not let LLVM merge this trial byte ahead of existing shared state. */
static uint8_t fixed_window_shift __attribute__((section(".data.np2_window_shift")))=10U;
#else
static uint8_t fixed_window_shift=10U;
#endif
/* DUAL20_WINDOW1536_DATA_END */
#else
#define fixed_window_shift 10U
#endif
/* One recorder RU crosses at most two aligned windows. Bits1/2 record only
 * card-confirmed low/high fragments; a wholly contained RU uses both bits.
 * Carry them with the immutable generation through full-RU spill/restore. */
static uint8_t ru_parts[RU_COUNT],spill_parts[SPILL_SLOTS];
static uint8_t dma_part_bits[DMA_WINDOW_OWNERS],fixed_fallback;
#if VSC_PSRAM_IDMA
/* dma_slots is an SRAM index when0, published FIFO physical index when1.
 * External generations remain in the FIFO through BTC/card PROGRAMMING;
 * only an error-free DATAEND + CMD13 TRANSFER may publish their part bits. */
static uint8_t dma_external[DMA_WINDOW_OWNERS];
#endif
static uint32_t dma_offset[DMA_WINDOW_OWNERS],dma_block_count[DMA_WINDOW_OWNERS];
static uint32_t sd_ll_fragment_end[DMA_WINDOW_OWNERS],dma_generation[DMA_WINDOW_OWNERS];
static uint32_t dma_blocks,dma_complete_mask,dma_complete_units,fixed_confirmed_blocks;
/* magic/version/confirmed sectors/full windows/short windows/fallbacks/
 * last command sectors/confirmed whole RUs. No per-byte or per-IRQ logging. */
volatile uint32_t xe_np_np2_fixed_write_diag[8] __attribute__((aligned(32)));
#endif
static uint32_t overflow_started_ms;
/* magic, version, completed spills/restores, peak/count, copy fault, chunks */
volatile uint32_t xe_np_np2_overflow_dma_diag[8]={0x4F44324EU,1U};
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
static uint32_t dma_first_ru;
/* Only completed, cache-invalidated restores own bits. SD clears exactly its
 * claimed slots; a READY restore must never be evacuated back to PSRAM. */
static volatile uint16_t overflow_restored_mask;
/* Keep the restore/ingress policy independent of the opportunistic CMD25 cap. */
#ifndef XE_NP_NP2_LIVE_SD_OVERFLOW_PREFETCH_RUS
#define XE_NP_NP2_LIVE_SD_OVERFLOW_PREFETCH_RUS 4U
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_PREFETCH_RUS != 4U && \
    (XE_NP_NP2_LIVE_SD_OVERFLOW_PREFETCH_RUS != 6U || MAX_WRITE_RUS != 6U)
#error "Prefetch trial is closed to the existing six-RU writer"
#endif
#define OVERFLOW_PREFETCH_RUS XE_NP_NP2_LIVE_SD_OVERFLOW_PREFETCH_RUS
_Static_assert(OVERFLOW_PREFETCH_RUS <= RU_COUNT-2U,"Prefetch must retain ingress room");
#if XE_NP_NP2_SD_ORDERED_BATCH3_TEST
static uint8_t record_uses_batch3;
#define SESSION_BATCH3 record_uses_batch3
#define ACTIVE_OVERFLOW_PREFETCH_RUS (SESSION_BATCH3?3U:OVERFLOW_PREFETCH_RUS)
#elif XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES && !XE_NP_NP2_LIVE_SD_VSC_TEST && \
    !XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST && MAX_WRITE_RUS==6U && XE_NP_NP2_LIVE_SD_WRITE_CAP_RUS==6U
/* Cold-selected restore budget; dual30 can prepare the whole next command. */
static uint32_t record_overflow_prefetch_rus=4U;
#define ACTIVE_OVERFLOW_PREFETCH_RUS record_overflow_prefetch_rus
#elif XE_NP_NP2_SD_SINGLE7500_WINDOW2048_TEST || XE_NP_NP2_SD_DUAL20_WINDOW1536_TEST
/* Packed windows can need seven FIFO owners; RAW9's eight-RU map needs six.
 * Restore the whole window while retaining two SRAM ingress owners. */
#define ACTIVE_OVERFLOW_PREFETCH_RUS (fixed_window_shift==11U?FIXED_FRAGMENT_OWNERS: \
    ((XE_NP_NP2_SD_TRIPLE7500_WINDOW1536_TEST || XE_NP_NP2_SD_SINGLE_MID_WINDOW1536_TEST || XE_NP_NP2_SD_DUAL20_WINDOW1536_TEST) && \
     fixed_window_shift==FIXED_WINDOW_1536_MODE?6U:OVERFLOW_PREFETCH_RUS))
#else
#define ACTIVE_OVERFLOW_PREFETCH_RUS OVERFLOW_PREFETCH_RUS
#endif
#if !XE_NP_NP2_SD_ORDERED_BATCH3_TEST
#define SESSION_BATCH3 0U
#endif
/* magic, version, durable total, reordered commands, latched first RU,
 * contiguous durable prefix, accounting fault, maximum prefix lag */
volatile uint32_t xe_np_np2_overflow_order_diag[8]={0x4F52324EU,1U};
#if MAX_WRITE_RUS<=6U
/* Wire: v1=24B/bins1..4; closed cap6 v2=32B/bins1..6. Counts are card-confirmed. */
volatile uint32_t xe_np_np2_write_batch_diag[FIXED_FRAGMENT_OWNERS+2U] __attribute__((aligned(32)))={0x4243324EU,MAX_WRITE_RUS==6U?2U:1U};
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_FAULT_DIAG
/* SOURCE/detail1 while CAPTURING; the selected runtime-direct bridge also
 * records CAPTURE/detail5. The extended SD-pin trial records WRITE while
 * CAPTURING/DRAINING. Keep the flag-OFF failure path unchanged.
 * pre-writer-abort ownership, never
 * updated by successful service/IRQ. The producer may already have stopped.
 * 0..5: magic/version/valid/error/detail/tick; 6..14: states; 15..23: sequences;
 * 24..29: free/reserved/restored-mask/fill/blocks/partial (version2);
 * 30..40: copy/FIFO/registers;
 * 41..47: SD ownership, produced/written and saved PRIMASK; 48..55: FIFO ends,
 * HCLK, chunk-start tick, SD DCOUNT/STA and copy addresses. Registers progress
 * asynchronously; IRQ masking freezes software ownership, not hardware DMA. */
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
/* v6 reserves all twelve physical metadata slots, including the unused D8
 * overlay. Runtime active count is eleven only for the selected bridge. */
#define FAULT_GENERATION_BASE (6U+RUNTIME_DIRECT_RU_CAPACITY)
#define FAULT_TAIL_SHIFT (2U*(RUNTIME_DIRECT_RU_CAPACITY-9U))
#elif XE_NP_NP2_SD_RAW_INGRESS_RU_TEST
/* v5 has ten states/generations. Shift the v3 tail by two words, never
 * overwrite generation0 or FREE with slot9. Default v3/v4 stays224B. */
#define FAULT_GENERATION_BASE 16U
#define FAULT_TAIL_SHIFT 2U
#else
#define FAULT_GENERATION_BASE 15U
#define FAULT_TAIL_SHIFT 0U
#endif
#if XE_NP_NP2_SD_RETAIN_OVERFLOW_FAULT_TEST
/* Same failure-only array; private scatter places this ZI input in UNINIT.
 * Survives supported warm rescue only, until the existing accepted-Start clear.
 * Never interpret without this image/map and a fresh LBA-bound backup receipt. */
volatile uint32_t xe_np_np2_overflow_fault_diag[56U+FAULT_TAIL_SHIFT]
    __attribute__((section(".bss.NP2_OVERFLOW_FAULT_NOINIT"),aligned(32)));
#else
volatile uint32_t xe_np_np2_overflow_fault_diag[56U+FAULT_TAIL_SHIFT] __attribute__((aligned(32)));
#endif
_Static_assert(sizeof(xe_np_np2_overflow_fault_diag)==224U+4U*FAULT_TAIL_SHIFT,"Overflow fault ABI changed");
#if XE_NP_NP2_LIVE_SD_FAULT_SD_PINS_TEST
/* Optional pre-abort IDMA receipt, paired with fault v4's GPIO bits. Written
 * only after capture has failed: no successful service/IRQ work. Hardware
 * can progress during the snapshot; final DCOUNT/STA bracket the receipt.
 * 0..3 signature/version/valid/LBA; 4..15 SD registers; 16..23 software
 * cursor/count, NVIC/masks/head; 24..29 first two owned descriptor words.
 * SOURCE retains v1. WRITE uses v2: word18 low16=NodesCounter,
 * high16=external fragment bitmap (only the latched dma_units are valid). */
volatile uint32_t xe_np_np2_idma_fault_diag[32] __attribute__((aligned(32)));
_Static_assert(sizeof(xe_np_np2_idma_fault_diag)==128U,"IDMA fault ABI changed");
#endif
#endif
#endif
#endif
static uint8_t *spill_address(uint32_t slot)
{return (uint8_t *)(XE_NP_PSRAM_BASE_ADDR+slot*RU_BYTES);}
#endif

/* Private first-gap receipt; asynchronous hardware registers are observational. */
volatile uint32_t xe_np_np2_first_gap_diag[24] __attribute__((section("NOINIT"),aligned(32)));
_Static_assert(sizeof(xe_np_np2_first_gap_diag)==96U,"First-gap receipt ABI changed");
volatile XE_NP_Np2LiveSdMailbox xe_np_np2_live_sd_mailbox
    __attribute__((section("NOINIT"),aligned(32)));
volatile XE_NP_Np2LiveSdPerf xe_np_np2_live_sd_perf
    __attribute__((section("NOINIT"),aligned(32)));
#if XE_NP_NP2_LIVE_SD_LAST_FREE_PREFETCH_TEST
/* Private stopped receipt: accepted, maximum published raw debt, last whole
 * BTC credits and missing future-window destinations. No IRQ accounting. */
volatile uint32_t xe_np_np2_last_free_prefetch_diag[4] __attribute__((aligned(32)));
#endif

static SD_HandleTypeDef *card;
static DCACHE_HandleTypeDef *cache;
static const XE_NP_Np2ProducerIo *producer;
static XE_NP_Np2UsbV3Config format;
static uint32_t active_target_blocks,active_target_rus;
static uint32_t record_start_lba,record_end_lba,record_erase_end_lba;
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
/* Grid16 physical progress deliberately does not reuse fixed_confirmed_blocks:
 * that legacy counter names NN sectors, whereas each physical group has K
 * additional auxiliary sectors. */
static struct {
    XE_NP_Np2Grid16IdmaPlan plan;
    XE_NP_Np2Grid16IdmaState idma;
    uint32_t requested_end_lba,physical_confirmed_lba,aux_sectors;
    uint32_t stop_minimum;
    uint32_t first_np_block[XE_NP_NP2_GRID16_GROUPS];
    const uint8_t *aux[XE_NP_NP2_GRID16_GROUPS];
    uint8_t slots[XE_NP_NP2_GRID16_GROUPS];
    volatile uint8_t release_pending;
    XE_NP_Np2LiveSdGrid16Acquire acquire;
    XE_NP_Np2LiveSdGrid16Release release;
    XE_NP_Np2LiveSdGrid16Commit commit;
    XE_NP_Np2LiveSdGrid16SourceStopped source_stopped;
    XE_NP_Np2LiveSdGrid16PrepareStop prepare_stop;
    void *context;
    uint8_t requested,active,stop_prepared;
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
    XE_NP_Np2LiveSdGrid16AcquireAppend acquire_append;
    XE_NP_Np2LiveSdGrid16ReleaseAppend release_append;
    XE_NP_Np2LiveSdGrid16AppendFault append_fault;
    uint32_t pending_ticket;
    uint8_t append,pending,pending_groups,claimed_groups;
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
    /* One whole-RU COPY owner; retained on error until ordinary retirement. */
    uint32_t copy_sequence,copy_fifo;
    volatile uint8_t restored_pending;
#endif
} grid16;
#endif
static uint32_t record_sample_hz,record_mclk_hz;
static uint8_t fill_ru=RU_COUNT,fill_blocks,dma_ru,initialized,dma_buffer_released;
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
/* Arrays reserve nine physical RUs (ten in the private raw-ring trial).
 * Triple D8 overlays physical RU4, so its immutable logical ring skips it. Select
 * once while all owners are off; never remap buffers under DMA. */
static uint32_t active_ru_count=9U+XE_NP_NP2_SD_RAW_INGRESS_RU_TEST;
#undef RU_COUNT
#define RU_COUNT active_ru_count
#endif
static uint8_t dma_units;
static uint8_t irq_service_observed;
static volatile uint8_t dma_active,irq_dataend_seen,irq_return_seen;
#if XE_NP_NP2_LIVE_SD_COUNTED_WRITES
static uint8_t counted_writes_enabled;
static volatile uint8_t counted_write_active;

/* CMD23 is optional on SD cards. Downgrade only for a response that explicitly
 * says ILLEGAL_COMMAND while the card is otherwise transfer-ready; transport,
 * CRC, timeout and unexpected-state errors remain fatal. */
static int counted_write_cmd23_unsupported(uint32_t error)
{
    uint32_t response=card->Instance->RESP1;
    return error==SDMMC_ERROR_ILLEGAL_CMD &&
           (response&SDMMC_OCR_ERRORBITS)==SDMMC_OCR_ILLEGAL_CMD &&
           (response&(0xFU<<9U))==(4U<<9U) && (response&(1U<<8U));
}
#endif
static uint32_t partial_ticks,write_lba,write_started,write_dataend;
#if XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE
static uint32_t synthetic_next_due_cycles;
#define SYNTHETIC_BLOCK_CYCLES ((128000000ULL*STREAM_TICKS)/LIVE_MCLK_HZ)
_Static_assert((128000000ULL*STREAM_TICKS)%LIVE_MCLK_HZ==0U,
               "Synthetic source needs an integral core-cycle interval");
_Static_assert(SYNTHETIC_BLOCK_CYCLES<0x80000000ULL,
               "Synthetic cycle deadline must fit signed wrap comparison");
#endif
static uint32_t last_service_cycles;
static uint32_t last_write_completed;
static volatile uint32_t irq_dataend_cycles,irq_return_cycles;
#if XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST
/* IDMA linked-list nodes must be increasing in memory. Source buffers can
 * still be scattered: descriptors are built in logical write order. */
static SD_DMALinkNodeTypeDef sd_ll_nodes[SD_LLI_MAX_NODES]
    __attribute__((section("NP2_DMA_DESCRIPTORS"),aligned(32)));
static SD_DMALinkedListTypeDef sd_ll __attribute__((section("NP2_DMA_DESCRIPTORS"),aligned(32)));
static uint32_t sd_ll_node_bytes[SD_LLI_MAX_NODES];
static volatile uint32_t sd_ll_node_index,sd_ll_bytes_done,sd_ll_retired_rus;
#if XE_NP_NP2_LIVE_SD_ROLLING_CMD25
static uint32_t rolling_published_rus;
#endif
#if XE_NP_NP2_STAGED_CAPTURE
static volatile uint32_t sd_ll_consumed_rus;
#endif
static volatile uint8_t sd_ll_fault;
static void retire_linked_list_bytes(uint32_t irq_started);
#if XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
static struct {
    uint16_t reserved; /* FREE destinations promised to unpublished generations */
    uint8_t active;
    volatile uint8_t published; /* Foreground publishes; SD IRQ reads. */
} copied_window;
static int copied_window_select(void);
static int copied_window_policy(void);
static int copied_window_build(void);
static int copied_window_publish(void);
static int copied_window_destination(uint32_t sequence);
static uint32_t copied_window_next_sequence(void);
#endif
#if XE_NP_NP2_LIVE_SD_IDMA_GAP_DIAG
/* Optional, stopped-only 64-byte diagnostic. One compare on each IDMA node
 * interrupt; no card polling or extra DWT read in the IRQ hot path. */
volatile uint32_t xe_np_np2_sd_idma_gap_diag[16]
    __attribute__((section("NOINIT"),aligned(32)));
static uint32_t sd_ll_last_node_cycles,sd_ll_last_node_dcount;
#endif
#endif
static uint32_t write_started_ms,status_poll_cycles;
#if XE_NP_NP2_LIVE_SD_WRITE_LATENCY_DIAG
/* Stopped-only 64-byte histogram: bins <25,25-30,30-35,35-40,40-45,
 * 45-50,50-60,>=60 ms. One update per completed CMD25; no capture IRQ work.
 * The last four words describe the longest completed write. */
volatile uint32_t xe_np_np2_sd_latency_diag[16]
    __attribute__((section("NOINIT"),aligned(32)));
static uint32_t write_start_depth;
#endif
static uint32_t record_started_ms,drain_started_ms,verify_started_ms,verify_ru;
static uint64_t next_tick,produced;
#if XE_NP_NP2_PREPARATION_ENABLE
static uint8_t stopped_tail_retired;
#endif
#if XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
/* DirectProgress is a stale-IRQ watchdog, not the record-ready test. DMA
 * IRQs publish normal progress and DirectPrepare checks readiness/faults at
 * each record boundary. Avoid taking the producer lock on every tight-loop
 * foreground pass; one poll per SysTick is still much less frequent than the
 * PSSI event cadence and remains below the profile-specific watchdog limit. */
static uint32_t direct_progress_poll_ms;
static uint8_t direct_progress_poll_valid;
#endif
static uint16_t verify_phase[3];
static uint8_t verify_phase_ready;
static uint8_t verify_clock_reduced;
static uint32_t recording_clkcr;
static uint8_t format_ready;
#if XE_NP_NP2_LIVE_SD_VSC_TEST || XE_NP_NP2_LIVE_SD_CLASSIC_PREPARE_TEST
#include "xe_np_np2_vsc_command.inc"
#endif
#if XE_NP_NP2_LIVE_SD_CLASSIC_PREPARE_TEST
static Np2VscCommand classic_prepare_command;
/* Stopped setup only: magic/version/phase/starts/argument/elapsed/R1/error. */
volatile uint32_t xe_np_np2_classic_prepare_diag[8];
#endif
#if XE_NP_NP2_LIVE_SD_VSC_TEST
#include "xe_np_sd_record_plan.h"
static Np2VscCommand vsc_command;
static uint32_t vsc_au_blocks,vsc_au_end,vsc_stage;
#if XE_NP_NP2_SD_PROFILE_CLASSIC_TEST
static uint8_t record_uses_vsc,vsc_recording_entered;
#define SESSION_VSC record_uses_vsc
#else
#define SESSION_VSC 1U
#endif
/* magic/version/AU/stage/CMD20 count/last arg/last R1/error/renewals/max wait.
 * Command-boundary only; no sample/IRQ logging or hot-loop cache clean. */
volatile uint32_t xe_np_np2_live_vsc_diag[10];
#else
#define SESSION_VSC 0U
#endif
#if XE_NP_NP2_SD_HIGH_TWO_PSRAM_IDMA_TEST
static uint8_t record_uses_psram_idma;
#define SESSION_PSRAM_IDMA record_uses_psram_idma
#else
#define SESSION_PSRAM_IDMA XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST
#endif
#if XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_TEST
static uint8_t record_uses_whole_ru;
#define SESSION_WHOLE_RU record_uses_whole_ru
#else
#define SESSION_WHOLE_RU 0U
#endif
#if XE_NP_NP2_LIVE_SD_STARTUP_PRIME_TEST
/* Test-only, no recorded-data credit: magic/version/state/error/ms/sectors/LBA/SDerror.
 * State 0=not attempted, 1=busy, 2=complete, 255=failed; exactly 32 bytes. */
volatile uint32_t xe_np_np2_startup_prime_diag[8] __attribute__((aligned(32)));
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_HOLD_TEST
/* Private 32B receipt: magic/version/phase/requested_ms/actual_elapsed_ms/
 * trigger_produced_blocks/trigger_written_rus/release_produced_blocks.
 * Phase 0=waiting, 1=holding, 2=released; never recorded-data credit. */
volatile uint32_t xe_np_np2_spill_hold_diag[8] __attribute__((aligned(32)));
static uint32_t spill_hold_started_ms;
_Static_assert(sizeof(xe_np_np2_spill_hold_diag)==32U,"Private spill-hold ABI");
static void spill_hold_reset(void)
{
    memset((void *)xe_np_np2_spill_hold_diag,0,sizeof(xe_np_np2_spill_hold_diag));
    xe_np_np2_spill_hold_diag[0]=0x4853324EU;xe_np_np2_spill_hold_diag[1]=1U;
    xe_np_np2_spill_hold_diag[3]=100U;spill_hold_started_ms=0U;
}
static int spill_hold_defer(uint32_t now,uint32_t state,uint32_t completed,
                            uint32_t active,uint32_t idle,uint32_t blocks,uint32_t written)
{
    volatile uint32_t *d=xe_np_np2_spill_hold_diag;
    if(d[2]==2U)return 0;
    if(d[2]==1U){
        uint32_t elapsed_ms=now-spill_hold_started_ms;
        if(state!=XE_NP_NP2_LIVE_SD_CAPTURING || active || !idle || elapsed_ms>=100U){
            d[4]=elapsed_ms;d[7]=blocks;__DMB();d[2]=2U;return 0;
        }
        return 1;
    }
    if(state!=XE_NP_NP2_LIVE_SD_CAPTURING || active || !idle || completed<128U)return 0;
    spill_hold_started_ms=now;d[5]=blocks;d[6]=written;__DMB();d[2]=1U;return 1;
}
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_LEG_4K_TEST
/* Private32B: magic/version/limit/capped launches/max external-data leg/
 * external-data launches/capped bytes/all new legs. Counts only HAL_OK starts. */
volatile uint32_t xe_np_np2_spill_leg_diag[8] __attribute__((aligned(32)));
static uint8_t dma_window_external;
_Static_assert(sizeof(xe_np_np2_spill_leg_diag)==32U,"Private spill-leg ABI");
static void spill_leg_reset(void)
{
    memset((void *)xe_np_np2_spill_leg_diag,0,sizeof(xe_np_np2_spill_leg_diag));
    xe_np_np2_spill_leg_diag[0]=0x4C53324EU;xe_np_np2_spill_leg_diag[1]=1U;
    xe_np_np2_spill_leg_diag[2]=4096U;dma_window_external=0U;
}
static uint32_t spill_leg_limit(uint32_t bytes,uint32_t external_data)
{return external_data && bytes>4096U?4096U:bytes;}
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST
/* Private32B: magic/version/phase/entry_ms/end_ms/entry_FREE/end_flags/
 * accepted legs while an external SD command owns its window (including
 * accepted-before-DPSMACT setup). Phase0=waiting,1=defer,2=ended,3=pressure,
 * 4=source error. Reasons0=2ms,1=pressure,2=Stop,3=window ended,4=source error.
 * end_flags low8=reason, bit8=current/selected external SD launch accepted,
 * bit9=C14 pending/EN before that launch (preexisting-overlap witness).
 * Unused commands leave phase0 waiting; entry freezes the selected witness.
 * One shot per recording, never a recording/data-durability receipt. */
volatile uint32_t xe_np_np2_spill_defer_diag[8] __attribute__((aligned(32)));
#if !XE_NP_NP2_LIVE_SD_SPILL_LEG_4K_TEST
static uint8_t dma_window_external;
#endif
static uint32_t spill_defer_guard_ticks;
_Static_assert(sizeof(xe_np_np2_spill_defer_diag)==32U,"Private spill-defer ABI");
static void spill_defer_reset(void)
{
    memset((void *)xe_np_np2_spill_defer_diag,0,sizeof(xe_np_np2_spill_defer_diag));
    xe_np_np2_spill_defer_diag[0]=0x4432324EU;xe_np_np2_spill_defer_diag[1]=1U;
    spill_defer_guard_ticks=0U;dma_window_external=0U;
}
static uint32_t spill_defer_pressure(uint64_t latest,uint64_t consumed,
                                    uint32_t free_count,uint32_t guard_ticks)
{
    return free_count<2U || latest<consumed || guard_ticks>=XE_NP_NP2_RETENTION_LIMIT ||
        latest-consumed>=(uint64_t)XE_NP_NP2_RETENTION_LIMIT-guard_ticks;
}
static void spill_defer_window_started(uint32_t prior_leg)
{
    volatile uint32_t *d=xe_np_np2_spill_defer_diag;
    if(!d[2])d[6]=0x100U|(prior_leg?0x200U:0U);
}
static void spill_defer_window_ended(uint32_t now,uint32_t state)
{
    volatile uint32_t *d=xe_np_np2_spill_defer_diag;
    if(!d[2]){d[6]=0U;return;} /* No new-leg opportunity: still unselected. */
    if((d[6]&0x100U) && d[2]==1U){
        d[4]=now;d[6]=(d[6]&~0xFFU)|(state==XE_NP_NP2_LIVE_SD_CAPTURING?3U:2U);
        __DMB();d[2]=2U;
    }
}
static int spill_defer_new_leg(uint32_t now,uint32_t state,uint32_t external_window,
                               uint32_t pressure,uint32_t free_count)
{
    volatile uint32_t *d=xe_np_np2_spill_defer_diag;
    if(d[2]>=2U)return 0;
    if(!d[2]){
        if(state!=XE_NP_NP2_LIVE_SD_CAPTURING || !external_window || !(d[6]&0x100U))return 0;
        d[3]=now;d[5]=free_count;__DMB();d[2]=1U;
    }
    if(pressure || state!=XE_NP_NP2_LIVE_SD_CAPTURING || !external_window || now-d[3]>=2U){
        d[4]=now;d[6]=(d[6]&~0xFFU)|(pressure?1U:(state!=XE_NP_NP2_LIVE_SD_CAPTURING?2U:(!external_window?3U:0U)));
        __DMB();d[2]=pressure?3U:2U;return 0;
    }
    return 1;
}
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_LAUNCH_TRACE_TEST
/* Private64B: magic/version/phase; PRE then POST each contain DWT, SD error,
 * STA, DCOUNT, PSSI RIS, C14 CCR; word15 is the selected write_started DWT.
 * Phase0=unselected,1=PRE-only,2=HAL accepted,3=launch failed. Ordered reads
 * are not simultaneous samples. Select a NEW spill leg, never an active leg;
 * HAL acceptance owns the external SD window even before DPSMACT is visible. */
volatile uint32_t xe_np_np2_spill_launch_trace[16] __attribute__((aligned(32)));
#if !XE_NP_NP2_LIVE_SD_SPILL_LEG_4K_TEST && !XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST
static uint8_t dma_window_external;
#endif
_Static_assert(sizeof(xe_np_np2_spill_launch_trace)==64U,"Private spill-launch trace ABI");
static void spill_launch_trace_reset(void)
{
    memset((void *)xe_np_np2_spill_launch_trace,0,sizeof(xe_np_np2_spill_launch_trace));
    xe_np_np2_spill_launch_trace[0]=0x4C54324EU;xe_np_np2_spill_launch_trace[1]=1U;
    dma_window_external=0U;
}
static void spill_launch_trace_pre(void)
{
    volatile uint32_t *d=xe_np_np2_spill_launch_trace;
    if(d[2] || overflow_kind!=1U || !dma_active || !dma_window_external || spill_dma_bytes)return;
    d[3]=DWT->CYCCNT;d[4]=card->ErrorCode;d[5]=card->Instance->STA;
    d[6]=card->Instance->DCOUNT;d[7]=PSSI->RIS;d[8]=GPDMA1_Channel14->CCR;
    d[15]=write_started;__DMB();d[2]=1U;
}
static void spill_launch_trace_post(uint32_t accepted)
{
    volatile uint32_t *d=xe_np_np2_spill_launch_trace;
    if(d[2]!=1U)return;
    d[9]=DWT->CYCCNT;d[10]=card->ErrorCode;d[11]=card->Instance->STA;
    d[12]=card->Instance->DCOUNT;d[13]=PSSI->RIS;d[14]=GPDMA1_Channel14->CCR;
    __DMB();d[2]=accepted?2U:3U;
}
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_DIAG_TEST
/* Private64B fence receipt: magic/version/total,start-write,service,first-gate;
 * first STA/DCOUNT/SD-owner flags+units+first-RU; then READY/FREE masks,
 * FIFO count, COPY kind/RU/C14-enabled, and pending COPY bytes.  Counters are
 * gate refusals, never DMA launches.  Masks are sampled only for the first
 * refusal so ordinary service polls do not scan the RU array. */
volatile uint32_t xe_np_np2_spill_bus_fence_diag[16] __attribute__((aligned(32)));
_Static_assert(sizeof(xe_np_np2_spill_bus_fence_diag)==64U,"Private spill-fence ABI");
/* Private128B early-service fence receipt.  It is deliberately separate from
 * the stable 64B receipt above: [2] is a nonzero ordinal commit marker, so a
 * reader never treats a partially written or later refusal as the witness.
 *
 * [0..2] magic/version/early-service ordinal; [3] owner flags:
 * bit0 SD active, bit1 SD external, bit2 C14 enabled, bits8..9 COPY kind,
 * bits12..15 COPY RU.  [4] SD span: units[3:0], complete-units[7:4],
 * complete-mask[13:8], external-unit bits[21:16].  [5] six 4-bit SD slots;
 * [6] SD blocks; [7..12] first stream block per slot (UINT32_MAX unused).
 * [13] restored-RU mask[8:0], fill RU[19:16], fill blocks[21:20].
 * [14] FIFO head[5:0], tail[13:8], count[21:16]; [15]/[16] FIFO first/last
 * sequence (UINT32_MAX if empty); [17]/[18] COPY progress/active bytes.
 * [19] nine 3-bit RU states; [20..28] first stream block per RU; [29]/[30]
 * are STA/DCOUNT sampled at refusal.  V1 [31] remains zero and records the
 * first *early service* refusal.  Pressure-only V2 [31] bit0=buffer released,
 * bit1=IRQ return, bit2=DATAEND, bit3=hold released, bit4=external SD owner,
 * bit5=no-FREE allocation; it records no selection or C14 launch. */
volatile uint32_t xe_np_np2_spill_bus_fence_early_diag[32] __attribute__((aligned(32)));
_Static_assert(sizeof(xe_np_np2_spill_bus_fence_early_diag)==128U,"Private early spill-fence ABI");
_Static_assert(RU_COUNT==9U,"Early spill-fence receipt follows copied-nine RU layout");
_Static_assert(MAX_WRITE_RUS==6U,"Early spill-fence receipt follows six-unit SD layout");
static void spill_bus_fence_diag_reset(void)
{
    memset((void *)xe_np_np2_spill_bus_fence_diag,0,sizeof(xe_np_np2_spill_bus_fence_diag));
    xe_np_np2_spill_bus_fence_diag[0]=0x4642324EU;
    xe_np_np2_spill_bus_fence_diag[1]=1U;
}
static void spill_bus_fence_early_diag_reset(void)
{
    memset((void *)xe_np_np2_spill_bus_fence_early_diag,0,sizeof(xe_np_np2_spill_bus_fence_early_diag));
    xe_np_np2_spill_bus_fence_early_diag[0]=0x4542324EU;
    xe_np_np2_spill_bus_fence_early_diag[1]=XE_NP_NP2_LIVE_SD_SPILL_PRESSURE_DIAG_TEST?2U:1U;
}
static void spill_bus_fence_refused(uint32_t gate)
{
    volatile uint32_t *d=xe_np_np2_spill_bus_fence_diag;
    d[2]++;
    if(gate==1U)d[3]++;else d[4]++;
    if(d[5])return;
    uint32_t ready=0U,free=0U;
    for(uint32_t i=0U;i<RU_COUNT;i++){
        if(ru_state[i]==RU_READY)ready|=1U<<i;
        if(ru_state[i]==RU_FREE)free|=1U<<i;
    }
    d[6]=card->Instance->STA;d[7]=card->Instance->DCOUNT;
    d[8]=(dma_active?1U:0U)|(dma_window_external?2U:0U);
    d[9]=dma_units;d[10]=dma_first_ru;d[11]=ready;d[12]=free;
    d[13]=spill_count;d[14]=overflow_kind|((uint32_t)overflow_ru<<8U)|
        ((GPDMA1_Channel14->CCR&DMA_CCR_EN)?0x10000U:0U);
    d[15]=spill_dma_bytes;__DMB();d[5]=gate;
}
static void spill_bus_fence_early_latch(uint32_t tag)
{
    volatile uint32_t *d=xe_np_np2_spill_bus_fence_early_diag;
    if(d[2])return;
    uint32_t owner=(dma_active?1U:0U)|(dma_window_external?2U:0U)|
        ((GPDMA1_Channel14->CCR&DMA_CCR_EN)?4U:0U)|((uint32_t)overflow_kind<<8U)|
        ((uint32_t)overflow_ru<<12U),slots=0U,external=0U,states=0U;
    for(uint32_t i=0U;i<MAX_WRITE_RUS;i++){
        uint32_t used=i<dma_units;
        slots|=(used?(uint32_t)dma_slots[i]:0xFU)<<(4U*i);
        if(used && dma_external[i])external|=1U<<i;
        d[7U+i]=used?dma_generation[i]:UINT32_MAX;
    }
    for(uint32_t i=0U;i<RU_COUNT;i++)states|=(uint32_t)ru_state[i]<<(3U*i);
    d[3]=owner;
    d[4]=dma_units|((dma_complete_units&0xFU)<<4U)|((dma_complete_mask&0x3FU)<<8U)|
        ((external&0x3FU)<<16U);
    d[5]=slots;d[6]=dma_blocks;
    d[13]=(uint32_t)overflow_restored_mask|((uint32_t)fill_ru<<16U)|((uint32_t)fill_blocks<<20U);
    d[14]=(spill_head&0x3FU)|((spill_tail&0x3FU)<<8U)|((spill_count&0x3FU)<<16U);
    d[15]=spill_count?spill_sequence[spill_tail]:UINT32_MAX;
    d[16]=spill_count?spill_sequence[(spill_head+SPILL_SLOTS-1U)%SPILL_SLOTS]:UINT32_MAX;
    d[17]=spill_copy;d[18]=spill_dma_bytes;d[19]=states;
    for(uint32_t i=0U;i<RU_COUNT;i++)d[20U+i]=ru_first_block[i];
    d[29]=card->Instance->STA;d[30]=card->Instance->DCOUNT;d[31]=tag;
    /* Existing service counter was incremented first; committing it last
     * makes [2] a nonzero immutable-capture marker for offline readers. */
    uint32_t ordinal=xe_np_np2_spill_bus_fence_diag[4];
    __DMB();d[2]=ordinal?ordinal:1U;
}
#if !XE_NP_NP2_LIVE_SD_SPILL_PRESSURE_DIAG_TEST
static void spill_bus_fence_early_refused(void)
{
    spill_bus_fence_early_latch(0U);
}
#else
static void spill_bus_fence_pressure_refused(void)
{
    /* This is called only at the existing no-FREE allocation decision.
     * The forced-hold receipt's released phase excludes ordinary early polls. */
    if(!dma_active || !dma_window_external || xe_np_np2_spill_hold_diag[2]!=2U)return;
    /* bits0..2 are buffer/DATAEND observations; bit3=hold released,
     * bit4=external SD owner, bit5=find_free exhausted. */
    spill_bus_fence_early_latch((dma_buffer_released?1U:0U)|
        (irq_return_seen?2U:0U)|(irq_dataend_seen?4U:0U)|8U|16U|32U);
}
#endif
#endif
enum {LAUNCH_WAIT_NONE=0U,LAUNCH_WAIT_NO_READY=1U,
      LAUNCH_WAIT_CARD_NOT_IDLE=2U,LAUNCH_WAIT_BELOW_MIN=3U};
#if XE_NP_NP2_LIVE_SD_LAUNCH_WAIT_DIAG
static uint8_t launch_wait_reason,launch_wait_tracking;
static uint32_t launch_wait_started;
#endif
#if XE_NP_NP2_DIRECT_D8_RAW_PHASE
static uint8_t d8_phase_ready;
#endif
#if XE_NP_NP2_LIVE_SD_PSRAM_SPILL
static uint8_t *capture_block(void)
{return (fill_ru==SPILL_FILL?spill_address(spill_head):ru[fill_ru])+fill_blocks*STREAM_BYTES;}
#endif

static uint32_t cycles(void){return DWT->CYCCNT;}
static uint32_t elapsed(uint32_t start){return cycles()-start;}
static void maximum(volatile uint32_t *value,uint32_t candidate)
{if(candidate>*value)*value=candidate;}
/* HOST_PARK_POLICY_BEGIN */
#if XE_NP_PSRAM_HOST_PARK_TEST
/* N2HP/v1: final park, first-spill wakes, terminal wakes, first error,
 * cold read/write + parked-arm bits, max foreground wake cycles. */
volatile uint32_t xe_np_np2_psram_park_diag[8] __attribute__((aligned(32)));
static int resume_parked_psram(uint32_t terminal)
{
    if(!XE_NP_Psram_HostParked())return 0;
    uint32_t began=cycles();
    if(XE_NP_Psram_ResumeHost()){
        if(!xe_np_np2_psram_park_diag[5])xe_np_np2_psram_park_diag[5]=0xD841U;
        return -1;
    }
    xe_np_np2_psram_park_diag[terminal?4U:3U]++;
    maximum(&xe_np_np2_psram_park_diag[7],elapsed(began));
    return 0;
}
static int prepare_overflow_memory(void)
{
    memset((void *)xe_np_np2_psram_park_diag,0,sizeof(xe_np_np2_psram_park_diag));
    xe_np_np2_psram_park_diag[0]=0x5048324EU;xe_np_np2_psram_park_diag[1]=1U;
#if XE_NP_NP2_SD_SINGLE20_CORE64_TEST || XE_NP_NP2_SD_MULTI20_CORE64_TEST || \
    XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST
    if(XE_NP_Board_InitNp2OverflowMemoryProfile(record_sample_hz,LIVE_PROBE_MASK))return -1;
#else
    if(XE_NP_Board_InitNp2OverflowMemory(record_sample_hz))return -1;
#endif
    /* Lowest-only trial; leave every other profile's host awake. */
    if(LIVE_PROBE_MASK!=1U || record_sample_hz!=7500U)return 0;
    if(overflow_kind || spill_count || spill_dma_bytes ||
       (GPDMA1_Channel14->CCR&(DMA_CCR_EN|DMA_CCR_RESET|DMA_CCR_SUSP)) ||
       GPDMA1_Channel14->CBR1){xe_np_np2_psram_park_diag[5]=0xD842U;return -1;}
    /* Stopped, noncacheable, scratch PSRAM only. Prove resumed read AND write
     * mapping against asymmetric data before the final acquisition-time park. */
    volatile uint32_t *test=(volatile uint32_t *)(uintptr_t)XE_NP_PSRAM_BASE_ADDR;
    uint32_t saved[16];
    for(uint32_t i=0U;i<16U;i++)saved[i]=test[i];
    for(uint32_t i=0U;i<16U;i++)test[i]=0xD1A54B00U^(i*0x10204081U);
    __DSB();
    /* A noncacheable readback drains mapped writes before aborting the read
     * prefetch transaction. DSB alone need not drain the serial TX FIFO. */
    for(uint32_t i=0U;i<16U;i++)if(test[i]!=(0xD1A54B00U^(i*0x10204081U))){
        xe_np_np2_psram_park_diag[5]=0xD84AU;return -1;
    }
    if(XE_NP_Psram_ParkHost() || XE_NP_Psram_ResumeHost()){
        xe_np_np2_psram_park_diag[5]=0xD846U;return -1;
    }
    for(uint32_t i=0U;i<16U;i++)if(test[i]!=(0xD1A54B00U^(i*0x10204081U))){
        xe_np_np2_psram_park_diag[5]=0xD846U;return -1;
    }
    xe_np_np2_psram_park_diag[6]|=1U;
    for(uint32_t i=0U;i<16U;i++)test[i]=~(0xD1A54B00U^(i*0x10204081U));
    __DSB();
    for(uint32_t i=0U;i<16U;i++)if(test[i]!=~(0xD1A54B00U^(i*0x10204081U))){
        xe_np_np2_psram_park_diag[5]=0xD84BU;return -1;
    }
    if(XE_NP_Psram_ParkHost() || XE_NP_Psram_ResumeHost()){
        xe_np_np2_psram_park_diag[5]=0xD847U;return -1;
    }
    for(uint32_t i=0U;i<16U;i++)if(test[i]!=~(0xD1A54B00U^(i*0x10204081U))){
        xe_np_np2_psram_park_diag[5]=0xD847U;return -1;
    }
    xe_np_np2_psram_park_diag[6]|=2U;
    for(uint32_t i=0U;i<16U;i++)test[i]=saved[i];
    __DSB();
    for(uint32_t i=0U;i<16U;i++)if(test[i]!=saved[i]){
        xe_np_np2_psram_park_diag[5]=0xD84CU;return -1;
    }
    if(XE_NP_Psram_ParkHost()){
        xe_np_np2_psram_park_diag[5]=0xD848U;return -1;
    }
    xe_np_np2_psram_park_diag[2]=1U;
    return 0;
}
#endif
/* HOST_PARK_POLICY_END */
/* CAPTURE_SPAN_HELPERS_BEGIN */
#if XE_NP_NP2_LIVE_SD_COPY_COST_DIAG
/* N2CS/v1, 128B. Producer hooks execute inside its existing critical section:
 * accepted nonempty loan and first sticky fault only, before stop/borrow clear.
 * 0..5 magic/version/frozen/HCLK(bit31 invalid)/app stage/failed subcheck;
 * 6..11 DWT accepted/posttake/poststore/postretained/postrelease/first fault;
 * 12 fault-valid(bit31)|IPSR(low9)|app stage(bits16..23); 13..17 loan ticks,
 * bytes,end lo/hi,data; 18..25 accepted produced/consumed, fault produced/
 * consumed (all lo/hi); 26 fault state|error<<8|expected<<16|borrowed<<24;
 * 27..30 last_fault offset/events/now_ms/fault; 31 app freeze DWT.
 * Clock/fault words have only the locked producer writer; foreground frozen
 * flag is separate. No new snapshot, IRQ-success hook or cache work here. */
static volatile uint32_t xe_np_np2_capture_span_diag[32] __attribute__((aligned(32)));
_Static_assert(sizeof(xe_np_np2_capture_span_diag)==128U,"Capture-span receipt ABI");
static void capture_span_reset(void)
{
    memset((void *)xe_np_np2_capture_span_diag,0,sizeof(xe_np_np2_capture_span_diag));
    xe_np_np2_capture_span_diag[0]=0x5343324EU;xe_np_np2_capture_span_diag[1]=1U;
}
void XE_NP_Np2LiveSd_ProducerReceipt(const XE_NP_Np2Producer *p,uint32_t event)
{
    volatile uint32_t *d=xe_np_np2_capture_span_diag;
    if(d[2] || (d[12]&0x80000000U) ||
       xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_CAPTURING)return;
    uint32_t stamp=cycles(),clock=SystemCoreClock;
    if(!(d[3]&0x7FFFFFFFU))d[3]|=clock;
    if(!clock || (d[3]&0x7FFFFFFFU)!=clock)d[3]|=0x80000000U;
    if(event==1U){
        d[4]=1U;d[5]=0U;d[6]=stamp;
        for(uint32_t i=7U;i<=10U;i++)d[i]=0U;
        d[13]=p->held.ticks;d[14]=p->held.bytes;
        d[15]=(uint32_t)p->held.source_end;d[16]=(uint32_t)(p->held.source_end>>32U);
        d[17]=(uint32_t)(uintptr_t)p->held.data;
        d[18]=(uint32_t)p->produced;d[19]=(uint32_t)(p->produced>>32U);
        d[20]=(uint32_t)p->consumed;d[21]=(uint32_t)(p->consumed>>32U);
    }else if(event==2U){
        d[11]=stamp;
        d[22]=(uint32_t)p->produced;d[23]=(uint32_t)(p->produced>>32U);
        d[24]=(uint32_t)p->consumed;d[25]=(uint32_t)(p->consumed>>32U);
        d[26]=p->state|((uint32_t)p->error<<8U)|((uint32_t)p->expected<<16U)|
              ((uint32_t)p->borrowed<<24U);
        d[27]=p->last_fault.offset;d[28]=p->last_fault.events;
        d[29]=p->last_fault.now_ms;d[30]=p->last_fault.fault;
        __DMB();d[12]=0x80000000U|(__get_IPSR()&0x1FFU)|((d[4]&0xFFU)<<16U);
    }
}
static void capture_span_point(uint32_t stage,uint32_t stamp)
{
    if(!xe_np_np2_capture_span_diag[2]){
        xe_np_np2_capture_span_diag[4]=stage;
        xe_np_np2_capture_span_diag[6U+stage]=stamp;
    }
}
static void capture_span_subcheck(uint32_t reason)
{if(!xe_np_np2_capture_span_diag[2])xe_np_np2_capture_span_diag[5]=reason;}
static void capture_span_freeze(void)
{
    if(!xe_np_np2_capture_span_diag[2]){
        xe_np_np2_capture_span_diag[31]=cycles();
        __DMB();xe_np_np2_capture_span_diag[2]=1U;
    }
}
#else
#define capture_span_point(stage,stamp) ((void)0)
#define capture_span_subcheck(reason) ((void)0)
#endif
/* CAPTURE_SPAN_HELPERS_END */
/* COPY_COST_HELPERS_BEGIN */
#if XE_NP_NP2_LIVE_SD_COPY_COST_DIAG
/* Foreground-only, stopped-only receipt. No hardware completion timestamp:
 * issue->last non-TC / accepted HAL completion brackets include setup/IRQs.
 * 0..3 magic/version/first-leg HCLK/status(bit0 frozen,bit1 clock invalid);
 * 4..7 u64 completed leg bytes spill/restore; 8..15 u64 lo/hi cycles by kind;
 * 16..21 u64 capture admission holds: no FREE/reserve/legacy credit;
 * 22..23 completed leg counts; 24..25 maximum upper cycles by kind;
 * 26..29 running issue/last non-TC/wait-start/reason. Frozen: incomplete
 * leg lower/upper/requested bytes/kind, never credited to completed totals. */
static volatile uint32_t xe_np_np2_copy_cost_diag[30] __attribute__((aligned(32)));
_Static_assert(sizeof(xe_np_np2_copy_cost_diag)==120U,"Copy-cost receipt ABI changed");
/* N2RP/v1, foreground observer only; WFI instructions, NOT sleep duty.
 * 0..4 magic/version/frozen/HCLK/WFI entries; 5..7 last successful existing
 * status latest(lo/hi)/DWT; 8 restore count; 9..19 last restore admission:
 * DWT,cached latest(lo/hi)/DWT,next_tick(lo/hi),head,FREE,FIFO,produced,written;
 * 20..25 three accepted leg issue/completion DWT pairs; 26..27 last leg
 * bytes/offset; 28 freeze DWT; 29..30 last WFI PRIMASK/SCR; 31 invalid flags.
 * Cached status age is explicit: this never adds a producer callback. */
static volatile uint32_t xe_np_np2_record_power_diag[32] __attribute__((aligned(32)));
/* N2RE/v1, 288B, same-generation first-seen/candidate/admit observations.
 * 0..7 magic/version/frozen/HCLK/head/valid bits(1,2,4)/generations/invalid;
 * three21-word snapshots at8/29/50: DWT begin,cached latest lo/hi/status DWT,
 * next_tick lo/hi,FREE,reserve,COPY kind,restored,FIFO,pending whole-RU BTC,
 * SD DCOUNT/STA,produced/written/fixed confirmed,active|retired<<8|units<<16,
 * PSSI CDAR/CBR1,DWT end. Word71 reserved. Not atomic: IRQ/DMA may advance
 * within each explicit bracket. Invalid snapshots from older heads are NOT
 * cleared; only valid bits select snapshots belonging to the current head. */
static volatile uint32_t xe_np_np2_restore_elig_diag[72] __attribute__((aligned(32)));
_Static_assert(sizeof(xe_np_np2_restore_elig_diag)==288U,"Restore eligibility ABI");
static void record_eligibility_point(uint32_t point);
static int record_power_clock(void)
{
    volatile uint32_t *d=xe_np_np2_record_power_diag;
    if(d[2] || d[31])return 0;
    if(!d[3])d[3]=SystemCoreClock;
    if(!d[3] || d[3]!=SystemCoreClock){d[31]|=1U;return 0;}
    return 1;
}
static int copy_cost_status(uint64_t *latest)
{
    int result=producer->status(producer->user,latest);
    if(!result && xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_CAPTURING &&
       record_power_clock()){
        xe_np_np2_record_power_diag[5]=(uint32_t)*latest;
        xe_np_np2_record_power_diag[6]=(uint32_t)(*latest>>32U);
        xe_np_np2_record_power_diag[7]=cycles();
    }
    return result;
}
static void record_power_restore(uint32_t head,uint32_t free_count)
{
    if(!record_power_clock())return;
    volatile uint32_t *d=xe_np_np2_record_power_diag;
    d[8]++;d[9]=cycles();d[10]=d[5];d[11]=d[6];d[12]=d[7];
    d[13]=(uint32_t)next_tick;d[14]=(uint32_t)(next_tick>>32U);
    d[15]=head;d[16]=free_count;d[17]=spill_count;
    d[18]=xe_np_np2_live_sd_mailbox.produced_blocks;
    d[19]=xe_np_np2_live_sd_mailbox.written_rus;
    for(uint32_t i=20U;i<28U;i++)d[i]=0U;
}
static void record_power_leg(uint32_t stamp,uint32_t completed)
{
    if(overflow_kind!=2U || !record_power_clock())return;
    uint32_t leg=spill_copy/OVERFLOW_COPY_BYTES;
    if(leg>=3U){xe_np_np2_record_power_diag[31]|=2U;return;}
    xe_np_np2_record_power_diag[20U+2U*leg+completed]=stamp;
    if(!completed){
        xe_np_np2_record_power_diag[26]=spill_dma_bytes;
        xe_np_np2_record_power_diag[27]=spill_copy;
    }
}
static void record_power_wfi(uint32_t key)
{
    if(!record_power_clock())return;
    xe_np_np2_record_power_diag[4]++;
    xe_np_np2_record_power_diag[29]=key;
    xe_np_np2_record_power_diag[30]=SCB->SCR;
}
static void copy_cost_add(uint32_t word,uint32_t value)
{
    uint32_t low=xe_np_np2_copy_cost_diag[word];
    xe_np_np2_copy_cost_diag[word]=low+value;
    xe_np_np2_copy_cost_diag[word+1U]+=xe_np_np2_copy_cost_diag[word]<low;
}
static int copy_cost_clock(void)
{
    volatile uint32_t *d=xe_np_np2_copy_cost_diag;
    if(d[3])return 0;
    if(d[2] && d[2]!=SystemCoreClock){d[3]=2U;return 0;}
    return d[2]!=0U;
}
static void copy_cost_reset(void)
{
    capture_span_reset();
    memset((void *)xe_np_np2_copy_cost_diag,0,sizeof(xe_np_np2_copy_cost_diag));
    xe_np_np2_copy_cost_diag[0]=0x4343324EU;xe_np_np2_copy_cost_diag[1]=1U;
    memset((void *)xe_np_np2_record_power_diag,0,sizeof(xe_np_np2_record_power_diag));
    xe_np_np2_record_power_diag[0]=0x5052324EU;xe_np_np2_record_power_diag[1]=1U;
    memset((void *)xe_np_np2_restore_elig_diag,0,sizeof(xe_np_np2_restore_elig_diag));
    xe_np_np2_restore_elig_diag[0]=0x4552324EU;xe_np_np2_restore_elig_diag[1]=1U;
}
static void copy_cost_leg_start(uint32_t issue)
{
    volatile uint32_t *d=xe_np_np2_copy_cost_diag;
    if(!d[2] && !d[3]){
        if(!SystemCoreClock){d[3]=2U;return;}
        d[2]=SystemCoreClock; /* Profile clocks are already selected here. */
    }
    if(!copy_cost_clock())return;
    d[26]=d[27]=issue;
    record_power_leg(issue,0U);
}
static void copy_cost_non_tc(uint32_t before)
{if(copy_cost_clock())xe_np_np2_copy_cost_diag[27]=before;}
static void copy_cost_leg_complete(void)
{
    if(!copy_cost_clock())return;
    volatile uint32_t *d=xe_np_np2_copy_cost_diag;
    uint32_t kind=overflow_kind-1U,now=cycles(),upper=now-d[26];
    record_power_leg(now,1U);
    copy_cost_add(4U+kind*2U,spill_dma_bytes);
    copy_cost_add(8U+kind*4U,d[27]-d[26]);
    copy_cost_add(10U+kind*4U,upper);
    d[22U+kind]++;maximum(&d[24U+kind],upper);
    d[26]=d[27]=0U;
}
static void copy_cost_block(uint32_t reason)
{
    volatile uint32_t *d=xe_np_np2_copy_cost_diag;
    if(!copy_cost_clock() || d[29]==reason)return;
    uint32_t now=cycles();
    if(d[29])copy_cost_add(16U+(d[29]-1U)*2U,now-d[28]);
    d[28]=now;d[29]=reason;
}
static void copy_cost_freeze(void)
{
    capture_span_freeze();
    if(!xe_np_np2_record_power_diag[2]){
        (void)record_power_clock();
        xe_np_np2_record_power_diag[28]=cycles();
        xe_np_np2_record_power_diag[2]=1U;
        xe_np_np2_restore_elig_diag[2]=1U;
    }
    volatile uint32_t *d=xe_np_np2_copy_cost_diag;
    if(d[3]&1U)return;
    if(copy_cost_clock()){
        copy_cost_block(0U);
        if(overflow_kind && spill_dma_bytes){
            uint32_t lower=d[27]-d[26],upper=cycles()-d[26];
            d[26]=lower;d[27]=upper;d[28]=spill_dma_bytes;d[29]=overflow_kind;
        }else d[26]=d[27]=d[28]=d[29]=0U;
    }else d[26]=d[27]=d[28]=d[29]=0U;
    __DMB();d[3]|=1U;
}
#else
#define copy_cost_reset() ((void)0)
#define copy_cost_block(reason) ((void)0)
#define copy_cost_freeze() ((void)0)
#define copy_cost_status(latest) producer->status(producer->user,(latest))
#define record_power_restore(head,free_count) ((void)0)
#define record_power_wfi(key) ((void)0)
#define record_eligibility_point(point) ((void)0)
#endif
/* COPY_COST_HELPERS_END */
#if XE_NP_NP2_LIVE_SD_LAUNCH_GAP_SNAPSHOT_DIAG
/* Foreground one-shot, NOT an atomic hardware snapshot. DWT/tick and SD/C14
 * end brackets expose IRQ/hardware progress without masking it. Read via SWD
 * only after terminal retirement publishes cache visibility, never live.
 * 0..12: magic/version/valid/words, DWT+tick brackets, HCLK/wait/completion/ages;
 * 13..24: state/ring/confirmed/target/geometry/produced/written/prefetch;
 * 25..43: FIFO ends/parts, copy owner/cursors/ticks, restored/fill/next tick;
 * 44..63: SD software owner/cursor/card state and asynchronous host registers;
 * 64..73: C14 registers, SD/C14 end brackets, free slots;
 * 74..79: rate/mask/VSC stage+end, packed SD slots/parts;
 * 80..106: nine states, first blocks, part masks (inactive slot UINT32_MAX);
 * 107: fixed fallback; 108..115: first four FIFO generations and part masks. */
static volatile uint32_t xe_np_np2_launch_gap_snapshot[116] __attribute__((aligned(32)));
_Static_assert(sizeof(xe_np_np2_launch_gap_snapshot)<512U,"Launch-gap snapshot must remain bounded");
static int card_idle(void);
static void launch_gap_snapshot_reset(void)
{
    for(uint32_t i=0U;i<116U;i++)xe_np_np2_launch_gap_snapshot[i]=0U;
}
static void launch_gap_snapshot(void)
{
    volatile uint32_t *d=xe_np_np2_launch_gap_snapshot;
    if(d[2] || !initialized || !format_ready || !launch_wait_tracking ||
       launch_wait_reason!=LAUNCH_WAIT_BELOW_MIN || !SESSION_VSC || vsc_stage!=3U ||
       xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_CAPTURING ||
       !last_write_completed || !SystemCoreClock)return;
    uint32_t now=cycles(),threshold=(SystemCoreClock/1000U)*XE_NP_NP2_LIVE_SD_LAUNCH_GAP_SNAPSHOT_MS;
    if(!threshold || now-launch_wait_started<=threshold || now-last_write_completed<=threshold ||
       dma_active || !card || card->Instance!=SDMMC1 || !card_idle() ||
       (RU_COUNT!=8U && RU_COUNT!=9U) || !active_target_rus ||
       xe_np_np2_live_sd_mailbox.written_rus>=active_target_rus ||
       spill_head>=SPILL_SLOTS || spill_tail>=SPILL_SLOTS || spill_count>SPILL_SLOTS ||
       overflow_kind>2U || (overflow_kind && (overflow_ru>=RU_COUNT || ru_state[overflow_ru]!=RU_COPY)) ||
       spill_copy>RU_BYTES || spill_dma_bytes>RU_BYTES-spill_copy ||
       fill_ru>SPILL_FILL || fill_blocks>=BLOCKS_PER_RU || partial_ticks>=STREAM_TICKS ||
       dma_units>MAX_WRITE_RUS)return;
    d[0]=0x4C47324EU;d[1]=1U;d[3]=116U;d[4]=now;d[5]=uwTick;
    d[8]=SystemCoreClock;d[9]=launch_wait_started;d[10]=last_write_completed;
    d[11]=now-launch_wait_started;d[12]=now-last_write_completed;
    d[13]=xe_np_np2_live_sd_mailbox.state;d[14]=RU_COUNT;d[15]=fixed_confirmed_blocks;
    d[16]=active_target_blocks;d[17]=active_target_rus;d[18]=RU_BYTES;d[19]=RU_BLOCKS;
    d[20]=BLOCKS_PER_RU;d[21]=STREAM_TICKS;d[22]=xe_np_np2_live_sd_mailbox.produced_blocks;
    d[23]=xe_np_np2_live_sd_mailbox.written_rus;d[24]=ACTIVE_OVERFLOW_PREFETCH_RUS;
    d[25]=spill_head;d[26]=spill_tail;d[27]=spill_count;
    uint32_t last=(spill_head+SPILL_SLOTS-1U)%SPILL_SLOTS;
    d[28]=spill_count?spill_sequence[spill_tail]:UINT32_MAX;
    d[29]=spill_count?spill_sequence[last]:UINT32_MAX;
    d[30]=spill_count?spill_parts[spill_tail]:0U;d[31]=spill_count?spill_parts[last]:0U;
    d[32]=overflow_kind;d[33]=overflow_ru;d[34]=spill_dma_bytes;d[35]=spill_copy;
    d[36]=spill_dma_started;d[37]=overflow_started_ms;d[38]=overflow_restored_mask;
    d[39]=fill_ru;d[40]=fill_blocks;d[41]=partial_ticks;
    d[42]=(uint32_t)next_tick;d[43]=(uint32_t)(next_tick>>32U);
    d[44]=dma_active;d[45]=dma_units;d[46]=dma_first_ru;d[47]=dma_blocks;
    d[48]=sd_ll_node_index;d[49]=sd_ll_bytes_done;d[50]=sd_ll_retired_rus;d[51]=sd_ll_fault;
    d[52]=card->State;d[53]=card->ErrorCode;d[54]=card->Context;
    d[55]=card->Instance->CLKCR;d[56]=card->Instance->STA;d[57]=card->Instance->DCOUNT;
    d[58]=card->Instance->DLEN;d[59]=card->Instance->DCTRL;d[60]=card->Instance->IDMACTRL;
    d[61]=card->Instance->IDMABASER;d[62]=card->Instance->IDMALAR;d[63]=card->Instance->IDMABAR;
    d[64]=GPDMA1_Channel14->CSR;d[65]=GPDMA1_Channel14->CCR;d[66]=GPDMA1_Channel14->CBR1;
    d[67]=GPDMA1_Channel14->CSAR;d[68]=GPDMA1_Channel14->CDAR;
    d[74]=record_sample_hz;d[75]=LIVE_PROBE_MASK;d[76]=vsc_stage;d[77]=vsc_au_end;
    d[78]=d[79]=0U;
    for(uint32_t i=0U;i<dma_units;i++){
        d[78]|=((uint32_t)dma_slots[i]&15U)<<(4U*i);
        d[79]|=((uint32_t)dma_part_bits[i]&15U)<<(4U*i);
    }
    uint32_t free_count=0U;
    for(uint32_t i=0U;i<9U;i++){
        d[80U+i]=i<RU_COUNT?ru_state[i]:UINT32_MAX;
        d[89U+i]=i<RU_COUNT?ru_first_block[i]:UINT32_MAX;
        d[98U+i]=i<RU_COUNT?ru_parts[i]:UINT32_MAX;
        free_count+=i<RU_COUNT && ru_state[i]==RU_FREE;
    }
    d[73]=free_count;d[107]=fixed_fallback;
    for(uint32_t i=0U;i<4U;i++){
        uint32_t slot=(spill_tail+i)%SPILL_SLOTS;
        d[108U+i]=i<spill_count?spill_sequence[slot]:UINT32_MAX;
        d[112U+i]=i<spill_count?spill_parts[slot]:0U;
    }
    d[69]=card->Instance->STA;d[70]=card->Instance->DCOUNT;
    d[71]=GPDMA1_Channel14->CSR;d[72]=GPDMA1_Channel14->CBR1;
    d[7]=uwTick;d[6]=cycles();
    __DMB();d[2]=1U;
}
#endif
#if XE_NP_NP2_LIVE_SD_LAUNCH_WAIT_DIAG
static void launch_wait_change(uint8_t next)
{
    if(!launch_wait_tracking ||
       xe_np_np2_live_sd_mailbox.written_rus>=active_target_rus)return;
    if(launch_wait_reason==next){
#if XE_NP_NP2_LIVE_SD_LAUNCH_GAP_SNAPSHOT_DIAG
        if(next==LAUNCH_WAIT_BELOW_MIN)launch_gap_snapshot();
#endif
        return;
    }
    uint32_t now=cycles();
    if(launch_wait_reason!=LAUNCH_WAIT_NONE){
        uint32_t waited=now-launch_wait_started;
        if(launch_wait_reason==LAUNCH_WAIT_NO_READY)
            xe_np_np2_live_sd_perf.launch_wait_no_ready_cycles+=waited;
        else if(launch_wait_reason==LAUNCH_WAIT_CARD_NOT_IDLE)
            xe_np_np2_live_sd_perf.launch_wait_card_not_idle_cycles+=waited;
        else if(launch_wait_reason==LAUNCH_WAIT_BELOW_MIN)
            xe_np_np2_live_sd_perf.launch_wait_below_min_cycles+=waited;
    }
    launch_wait_reason=next;
    if(next==LAUNCH_WAIT_NONE)return;
    launch_wait_started=now;
    if(next==LAUNCH_WAIT_NO_READY)
        xe_np_np2_live_sd_perf.launch_wait_no_ready_events++;
    else if(next==LAUNCH_WAIT_CARD_NOT_IDLE)
        xe_np_np2_live_sd_perf.launch_wait_card_not_idle_events++;
    else if(next==LAUNCH_WAIT_BELOW_MIN)
        xe_np_np2_live_sd_perf.launch_wait_below_min_events++;
}
#else
#define launch_wait_change(reason) ((void)0)
#endif
#include "xe_np_np2_sd_ble.h"
#if XE_NP_NP2_SD_INTERNAL_SRAM_CACHE_BYPASS_TEST
/* Cortex-M33 internal SRAM requests bypass DCACHE1 in the U595 bus matrix.
 * Do not submit a cache command (and poll it) for uncached DMA owners. */
static int internal_sram_cache_bypass(const void *address,uint32_t bytes)
{
    uintptr_t first=(uintptr_t)address;
    const uintptr_t main_end=SRAM5_BASE_NS+SRAM5_SIZE;
    const uintptr_t sram4_end=SRAM4_BASE_NS+SRAM4_SIZE;
    if(bytes && cache && cache->Instance==DCACHE1 &&
       ((first>=SRAM1_BASE_NS && first<main_end && bytes<=main_end-first) ||
        (first>=SRAM4_BASE_NS && first<sram4_end && bytes<=sram4_end-first))){
        __DSB();return 1;
    }
    return 0;
}
#endif
static int clean(void *address,uint32_t bytes)
{
#if XE_NP_NP2_SD_INTERNAL_SRAM_CACHE_BYPASS_TEST
    if(internal_sram_cache_bypass(address,bytes))return 0;
#endif
#if XE_NP_NP2_LIVE_SD_DIRECT
    if(XE_NP_Np2DirectContains(address,bytes)){__DMB();return 0;}
#endif
#if XE_NP_CAPTURE_SRAM3_MPU_NONCACHEABLE
    if(XE_NP_Capture_Sram3RangeContained(address,bytes))return 0;
#endif
    uintptr_t begin=(uintptr_t)address&~(uintptr_t)31U;
    uintptr_t end=((uintptr_t)address+bytes+31U)&~(uintptr_t)31U;
    return HAL_DCACHE_CleanByAddr(cache,(const uint32_t *)begin,(uint32_t)(end-begin))==HAL_OK?0:-1;
}
/* Every bypass requires full containment. The private internal-SRAM guard
 * covers RU8 across SRAM banks; external PSRAM keeps its existing MPU policy. */
static int invalidate_if_cacheable(void *address,uint32_t bytes)
{
#if XE_NP_NP2_SD_INTERNAL_SRAM_CACHE_BYPASS_TEST
    if(internal_sram_cache_bypass(address,bytes))return 0;
#endif
#if XE_NP_CAPTURE_SRAM3_MPU_NONCACHEABLE
    if(XE_NP_Capture_Sram3RangeContained(address,bytes))return 0;
#endif
#if XE_NP_PSRAM_MPU_NONCACHEABLE_EXPERIMENT
    if(XE_NP_Psram_RangeContained(address,bytes))return 0;
#endif
    return HAL_DCACHE_InvalidateByAddr(cache,(uint32_t *)address,bytes)==HAL_OK?0:-1;
}
static int clean_invalid_if_cacheable(void *address,uint32_t bytes)
{
#if XE_NP_NP2_SD_INTERNAL_SRAM_CACHE_BYPASS_TEST
    if(internal_sram_cache_bypass(address,bytes))return 0;
#endif
#if XE_NP_CAPTURE_SRAM3_MPU_NONCACHEABLE
    if(XE_NP_Capture_Sram3RangeContained(address,bytes))return 0;
#endif
#if XE_NP_PSRAM_MPU_NONCACHEABLE_EXPERIMENT
    if(XE_NP_Psram_RangeContained(address,bytes))return 0;
#endif
    return HAL_DCACHE_CleanInvalidByAddr(cache,(uint32_t *)address,bytes)==HAL_OK?0:-1;
}
#if XE_NP_NP2_SD_INGRESS_DMA_TEST
#include "xe_np_np2_ingress_dma.inc"
static XE_NP_Np2Span ingress_span;
static uint8_t *ingress_block;
static uint32_t ingress_work;
static uint8_t ingress_pending;
#endif
static uint8_t *ru_block(uint32_t unit,uint32_t block)
{
#if XE_NP_NP2_STAGED_CAPTURE
    return ru[unit]+block*STREAM_BYTES;
#elif XE_NP_NP2_LIVE_SD_DIRECT && !defined(XE_NP_NP2_LIVE_SD_NATIVE_MODEL)
    return XE_NP_Np2DirectBlock(unit*BLOCKS_PER_RU+block);
#else
    return ru[unit]+block*STREAM_BYTES;
#endif
}

#if XE_NP_NP2_LIVE_SD_LAUNCH_GAP_SNAPSHOT_DIAG
static void launch_gap_snapshot_publish(void)
{
    uint32_t state=xe_np_np2_live_sd_mailbox.state;
    if(!cache || (state!=XE_NP_NP2_LIVE_SD_FAILED && state!=XE_NP_NP2_LIVE_SD_COMPLETE) ||
       dma_active || !card || !card->Instance || XE_NP_Np2CapturePort_Armed() ||
       (PSSI->CR&PSSI_CR_ENABLE) || (GPDMA1_Channel12->CCR&DMA_CCR_EN) ||
       (GPDMA1_Channel14->CCR&DMA_CCR_EN) || card->Instance->IDMACTRL ||
       (card->Instance->STA&(SDMMC_STA_DPSMACT|SDMMC_STA_CPSMACT|SDMMC_STA_BUSYD0)))return;
    (void)clean((void *)xe_np_np2_launch_gap_snapshot,sizeof(xe_np_np2_launch_gap_snapshot));
}
#endif
#if XE_NP_NP2_LIVE_SD_COPY_COST_DIAG
static void copy_cost_publish(void)
{
    uint32_t state=xe_np_np2_live_sd_mailbox.state;
    if(!(xe_np_np2_copy_cost_diag[3]&1U) || !cache ||
       (state!=XE_NP_NP2_LIVE_SD_FAILED && state!=XE_NP_NP2_LIVE_SD_COMPLETE) ||
       dma_active || !card || !card->Instance || XE_NP_Np2CapturePort_Armed() ||
       (PSSI->CR&PSSI_CR_ENABLE) || (GPDMA1_Channel12->CCR&DMA_CCR_EN) ||
       (GPDMA1_Channel14->CCR&DMA_CCR_EN) || card->Instance->IDMACTRL ||
       (card->Instance->STA&(SDMMC_STA_DPSMACT|SDMMC_STA_CPSMACT|SDMMC_STA_BUSYD0)))return;
    (void)clean((void *)xe_np_np2_copy_cost_diag,sizeof(xe_np_np2_copy_cost_diag));
    (void)clean((void *)xe_np_np2_record_power_diag,sizeof(xe_np_np2_record_power_diag));
    (void)clean((void *)xe_np_np2_restore_elig_diag,sizeof(xe_np_np2_restore_elig_diag));
    (void)clean((void *)xe_np_np2_capture_span_diag,sizeof(xe_np_np2_capture_span_diag));
}
#endif
static void publish(void)
{
    XE_NP_Np2UsbSourceStatus source={0};
    XE_NP_Np2Producer capture={0};
    XE_NP_Np2UsbSource_GetStatus(&source);
    XE_NP_Np2CapturePort_Diagnostics(&capture);
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
    xe_np_np2_sd_loss.overflow_events=capture.overflow_count;
    xe_np_np2_sd_loss.producer_discarded_ticks=capture.dropped_ticks;
    xe_np_np2_sd_loss.source_end_tick=next_tick;
#endif
    xe_np_np2_live_sd_perf.producer_error=capture.error;
    xe_np_np2_live_sd_perf.producer_state=capture.state;
    xe_np_np2_live_sd_mailbox.source_state=source.state;
    xe_np_np2_live_sd_mailbox.source_error=source.error;
    xe_np_np2_live_sd_mailbox.source_flags=source.flags;
    xe_np_np2_live_sd_mailbox.source_i2c_error=source.i2c_error;
    xe_np_np2_live_sd_mailbox.source_produced_lo=(uint32_t)capture.produced;
    xe_np_np2_live_sd_mailbox.source_produced_hi=(uint32_t)(capture.produced>>32U);
    xe_np_np2_live_sd_mailbox.source_consumed_lo=(uint32_t)capture.consumed;
    xe_np_np2_live_sd_mailbox.source_consumed_hi=(uint32_t)(capture.consumed>>32U);
    xe_np_np2_live_sd_mailbox.source_max_backlog=capture.max_backlog;
    xe_np_np2_live_sd_mailbox.source_irq_count=capture.irq_count;
    xe_np_np2_live_sd_mailbox.capture_setup_stage=XE_NP_Np2CapturePort_LastSetupStage();
    xe_np_np2_live_sd_mailbox.d8_error=xe_np_np2_spi2_d8_diag.error;
    if(xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_FAILED){
        xe_np_np2_live_sd_mailbox.sd_error=card?card->ErrorCode:0U;
        xe_np_np2_live_sd_mailbox.sd_sta=(card&&card->Instance)?card->Instance->STA:0U;
    }
    __DMB();
    if(cache)(void)clean((void *)&xe_np_np2_live_sd_mailbox,sizeof(xe_np_np2_live_sd_mailbox));
    if(cache)(void)clean((void *)&xe_np_np2_live_sd_perf,sizeof(xe_np_np2_live_sd_perf));
    if(cache && (xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED ||
                 xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_COMPLETE))
        (void)clean((void *)xe_np_np2_first_gap_diag,sizeof(xe_np_np2_first_gap_diag));
#if XE_NP_PSRAM_HOST_PARK_TEST
    if(cache && (xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED ||
                 xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_COMPLETE))
        (void)clean((void *)xe_np_np2_psram_park_diag,sizeof(xe_np_np2_psram_park_diag));
#endif
#if XE_NP_NP2_SD_INGRESS_DMA_TEST
    /* Debugger visibility only after capture ends; no per-span cache work. */
    if(cache && (xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED ||
                 xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_COMPLETE)){
        (void)clean((void *)xe_np_np2_ingress_dma_diag,sizeof(xe_np_np2_ingress_dma_diag));
        (void)clean((void *)xe_np_np2_ingress_fault_diag,sizeof(xe_np_np2_ingress_fault_diag));
    }
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER && MAX_WRITE_RUS<=6U
    if(cache)(void)clean((void *)xe_np_np2_write_batch_diag,sizeof(xe_np_np2_write_batch_diag));
#endif
#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
    if(cache)(void)clean((void *)xe_np_np2_fixed_write_diag,sizeof(xe_np_np2_fixed_write_diag));
#endif
#if XE_NP_NP2_LIVE_SD_VSC_TEST
    if(cache)(void)clean((void *)xe_np_np2_live_vsc_diag,sizeof(xe_np_np2_live_vsc_diag));
#endif
#if XE_NP_NP2_LIVE_SD_LAUNCH_GAP_SNAPSHOT_DIAG
    launch_gap_snapshot_publish();
#endif
#if XE_NP_NP2_LIVE_SD_COPY_COST_DIAG
    copy_cost_publish();
#endif
#if XE_NP_NP2_LIVE_SD_LAST_FREE_PREFETCH_TEST
    /* Stopped-only visibility of the existing16B admission receipt. */
    if(cache && (xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED ||
                 xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_COMPLETE) &&
       !dma_active && card && card->Instance && !XE_NP_Np2CapturePort_Armed() &&
       !(PSSI->CR&PSSI_CR_ENABLE) && !(GPDMA1_Channel12->CCR&DMA_CCR_EN) &&
       !(GPDMA1_Channel14->CCR&DMA_CCR_EN) && !card->Instance->IDMACTRL &&
       !(card->Instance->STA&(SDMMC_STA_DPSMACT|SDMMC_STA_CPSMACT|SDMMC_STA_BUSYD0)))
        (void)clean((void *)xe_np_np2_last_free_prefetch_diag,sizeof(xe_np_np2_last_free_prefetch_diag));
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_HOLD_TEST
    if(cache)(void)clean((void *)xe_np_np2_spill_hold_diag,sizeof(xe_np_np2_spill_hold_diag));
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_LEG_4K_TEST
    if(cache)(void)clean((void *)xe_np_np2_spill_leg_diag,sizeof(xe_np_np2_spill_leg_diag));
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST
    if(cache)(void)clean((void *)xe_np_np2_spill_defer_diag,sizeof(xe_np_np2_spill_defer_diag));
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_LAUNCH_TRACE_TEST
    if(cache)(void)clean((void *)xe_np_np2_spill_launch_trace,sizeof(xe_np_np2_spill_launch_trace));
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_DIAG_TEST
    if(cache)(void)clean((void *)xe_np_np2_spill_bus_fence_diag,sizeof(xe_np_np2_spill_bus_fence_diag));
    if(cache)(void)clean((void *)xe_np_np2_spill_bus_fence_early_diag,sizeof(xe_np_np2_spill_bus_fence_early_diag));
#endif
#if XE_NP_NP2_LIVE_SD_WRITE_LATENCY_DIAG
    if(cache)(void)clean((void *)xe_np_np2_sd_latency_diag,sizeof(xe_np_np2_sd_latency_diag));
#endif
#if XE_NP_NP2_LIVE_SD_IDMA_GAP_DIAG
    if(cache)(void)clean((void *)xe_np_np2_sd_idma_gap_diag,sizeof(xe_np_np2_sd_idma_gap_diag));
#endif
}

static int card_idle(void)
{
    return card && card->State==HAL_SD_STATE_READY && card->ErrorCode==HAL_SD_ERROR_NONE &&
           !(card->Instance->STA&(ERROR_FLAGS|SDMMC_STA_DPSMACT|SDMMC_STA_CPSMACT)) &&
           card->Instance->IDMACTRL==0U;
}

static int apply_session_clock_save(void)
{
#if XE_NP_NP2_SD_ACTIVE_CLOCK_SAVE_TEST || XE_NP_NP2_SD_PROFILE_BUS54_TEST
    if(!card || !card->Instance || !card_idle() ||
       (card->Instance->DCTRL&SDMMC_DCTRL_DTEN) ||
       (card->Instance->STA&SDMMC_STA_BUSYD0))return -1;
#if XE_NP_NP2_SD_PROFILE_BUS54_TEST
    uint32_t kernel=HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SDMMC);
    if(kernel!=(XE_NP_NP2_SD_KERNEL80_POWER_TEST?80000000U:
                (XE_NP_NP2_SD_HIGH_RATE_KERNEL120_TEST?XE_NP_BOARD_SD_PLL2Q_HZ:
                 (XE_NP_NP2_SD_KERNEL96_POWER_TEST?96000000U:108000000U))) || dma_active || overflow_kind ||
       XE_NP_Np2CapturePort_Armed())return -1;
    /* Dual15's existing /2 policy gives54MHz (private96 kernel:48MHz).
     * Its18.2MB/s stored ingress remains below the24MB/s private wire ceiling.
     * Always select anew: a prior low-rate session must not divide the next
     * dual20/30 or triple15/20 stream. No PLL/PSRAM/acquisition clock changes. */
    uint32_t divider=XE_NP_Np2LiveSd_UsesBus54Profile(LIVE_PROBE_MASK,record_sample_hz)?1U:0U;
    MODIFY_REG(card->Instance->CLKCR,SDMMC_CLKCR_CLKDIV,divider);
    card->Init.ClockDiv=divider;
    xe_np_np2_live_sd_mailbox.sd_bus_hz=kernel/(divider?2U*divider:1U);
#endif
#if XE_NP_NP2_SD_DUAL20_DIRECT_CKIN_TEST
    /* Cold-only receiver comparison. CMD/data state machines are idle here;
     * pre-erase's ordinary command responses must succeed before source arm.
     * RX1 bypasses DLYB; it is an experimental SDR104 departure, not tuning. */
    uint32_t rx=card->Instance->CLKCR&SDMMC_CLKCR_SELCLKRX;
    if(card->Instance!=SDMMC1 || card->Context ||
       !xe_np_np2_live_sd_mailbox.signal_1v8 ||
       xe_np_np2_live_sd_mailbox.sd_speed_mode!=SDMMC_SPEED_MODE_ULTRA_SDR104 ||
       (rx!=SDMMC_CLKCR_SELCLKRX_0 && rx!=SDMMC_CLKCR_SELCLKRX_1))return -1;
    rx=LIVE_PROBE_MASK==3U && record_sample_hz==20000U?
        SDMMC_CLKCR_SELCLKRX_0:SDMMC_CLKCR_SELCLKRX_1;
    MODIFY_REG(card->Instance->CLKCR,SDMMC_CLKCR_SELCLKRX,rx);
#endif
#if XE_NP_NP2_SD_ACTIVE_CLOCK_SAVE_TEST
    /* Stopped startup only. Clear a preceding low-rate session's policy too. */
    uint32_t save=XE_NP_Np2LiveSd_UsesClockSaveProfile(LIVE_PROBE_MASK,record_sample_hz);
    MODIFY_REG(card->Instance->CLKCR,SDMMC_CLKCR_PWRSAV,save?SDMMC_CLKCR_PWRSAV:0U);
    card->Init.ClockPowerSave=save?SDMMC_CLOCK_POWER_SAVE_ENABLE:SDMMC_CLOCK_POWER_SAVE_DISABLE;
#endif
    __DSB();
    recording_clkcr=card->Instance->CLKCR;
#endif
    return 0;
}

#if XE_NP_NP2_LIVE_SD_CLASSIC_PREPARE_TEST
static int service_classic_prepare(void)
{
    if(dma_active || overflow_kind || XE_NP_Np2CapturePort_Armed())return -1;
    int result=0;
    if(!classic_prepare_command.phase){
        if(!card_idle() || vsc_command_begin(&classic_prepare_command,card->Instance,
                                             0U,HAL_GetTick(),1250U))return -1;
        xe_np_np2_classic_prepare_diag[3]++;
    }else result=vsc_command_service(&classic_prepare_command,card->Instance,
                                     card->SdCard.RelCardAdd,HAL_GetTick());
    xe_np_np2_classic_prepare_diag[2]=classic_prepare_command.phase;
    xe_np_np2_classic_prepare_diag[5]=HAL_GetTick()-classic_prepare_command.started_ms;
    xe_np_np2_classic_prepare_diag[6]=classic_prepare_command.response;
    xe_np_np2_classic_prepare_diag[7]=classic_prepare_command.error;
    return result;
}
#endif

static void fail(uint32_t error,uint32_t detail)
{
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    XE_NP_Np2ClCarrier_PortFault();
#endif
    if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED ||
       xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_COMPLETE)return;
#if XE_NP_NP2_LIVE_SD_OVERFLOW_FAULT_DIAG
    if(((error==XE_NP_NP2_LIVE_SD_ERROR_SOURCE && detail==1U)
        || (!XE_NP_NP2_LIVE_SD_DIRECT && !SESSION_RUNTIME_DIRECT &&
            !XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST &&
            error==XE_NP_NP2_LIVE_SD_ERROR_CAPTURE && detail==4U)
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
        || (SESSION_RUNTIME_DIRECT && error==XE_NP_NP2_LIVE_SD_ERROR_CAPTURE && detail==5U)
#endif
#if XE_NP_NP2_LIVE_SD_FAULT_SD_PINS_TEST
        || error==XE_NP_NP2_LIVE_SD_ERROR_WRITE
#endif
        ) &&
       (xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_CAPTURING
#if XE_NP_NP2_LIVE_SD_FAULT_SD_PINS_TEST
        ||
        (error==XE_NP_NP2_LIVE_SD_ERROR_WRITE &&
         xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_DRAINING)
#endif
        )){
    uint32_t now=HAL_GetTick(),core_hz=HAL_RCC_GetHCLKFreq();
    uint32_t key=__get_PRIMASK();__disable_irq();
    volatile uint32_t *d=xe_np_np2_overflow_fault_diag;
#if XE_NP_NP2_SD_DUAL20_STATUS_RETRY_TEST
    /* A recovered CMD13 may precede this overflow. Retain its first receipt
     * and retry tail; the ordinary mailbox/stop/abort below still records
     * this terminal failure. Check while masked, before changing any word. */
    if(d[0]!=0x53444654U || d[1]!=1U || d[2]!=1U){
#endif
    uint32_t free_count=0U;
    volatile uint32_t *tail=d+FAULT_TAIL_SHIFT;
    d[0]=0x4F46324EU;d[1]=XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST?6U:XE_NP_NP2_SD_RAW_INGRESS_RU_TEST?5U:
        (XE_NP_NP2_LIVE_SD_FAULT_SD_PINS_TEST?4U:(MAX_WRITE_RUS==6U?3U:2U));d[3]=error;d[4]=detail;d[5]=now;
    for(uint32_t i=0U;i<RU_COUNT;i++){
        uint32_t state=ru_state[i];d[6U+i]=state;d[FAULT_GENERATION_BASE+i]=ru_first_block[i];
        free_count+=state==RU_FREE;
    }
    tail[24]=free_count;
    tail[25]=spill_count && overflow_kind!=2U && free_count<=1U && !overflow_restored_mask;
    tail[26]=overflow_restored_mask;tail[27]=fill_ru;tail[28]=fill_blocks;tail[29]=partial_ticks;
    tail[30]=overflow_kind;tail[31]=overflow_ru;tail[32]=spill_head;tail[33]=spill_tail;
    tail[34]=spill_count;tail[35]=spill_copy;tail[36]=spill_dma_bytes;
    tail[37]=overflow_kind?d[5]-overflow_started_ms:0U;
    tail[38]=GPDMA1_Channel14->CSR;tail[39]=GPDMA1_Channel14->CCR;tail[40]=GPDMA1_Channel14->CBR1;
    tail[41]=dma_active;tail[42]=dma_units;
#if MAX_WRITE_RUS==6U
    /* Fault v3 retains224B: word43 has six physical-slot nibbles, top byte0.
     * The opt-in v4 pin snapshot uses only that spare byte on failure.
     * v2/MAX4 retains its four byte indices. Only word42 slots are SD-owned. */
    tail[43]=0U;
    for(uint32_t i=0U;i<6U;i++)tail[43]|=((uint32_t)dma_slots[i]&15U)<<(i*4U);
#if XE_NP_NP2_LIVE_SD_FAULT_SD_PINS_TEST
    /* v4 reuses the spare byte only after failure: DAT0..3/CK PC8..12,
     * CMD PD2, CK_IN PB8, valid. One instant, not a busy/clock history. */
    tail[43]|=(((GPIOC->IDR>>8U)&31U)<<24U)|(((GPIOD->IDR>>2U)&1U)<<29U)|
           (((GPIOB->IDR>>8U)&1U)<<30U)|0x80000000U;
#endif
#else
    tail[43]=(uint32_t)dma_slots[0]|((uint32_t)dma_slots[1]<<8U)|
          ((uint32_t)dma_slots[2]<<16U)|((uint32_t)dma_slots[3]<<24U);
#endif
    tail[44]=dma_first_ru;tail[45]=xe_np_np2_live_sd_mailbox.produced_blocks;
    tail[46]=xe_np_np2_live_sd_mailbox.written_rus;tail[47]=key;
    tail[48]=spill_count && spill_count<=SPILL_SLOTS && spill_tail<SPILL_SLOTS?
        spill_sequence[spill_tail]:UINT32_MAX;
    tail[49]=spill_count && spill_count<=SPILL_SLOTS && spill_head<SPILL_SLOTS?
        spill_sequence[(spill_head+SPILL_SLOTS-1U)%SPILL_SLOTS]:UINT32_MAX;
    tail[50]=core_hz;tail[51]=spill_dma_started;
    tail[52]=(card&&card->Instance)?card->Instance->DCOUNT:0U;
    tail[53]=(card&&card->Instance)?card->Instance->STA:0U;
    tail[54]=GPDMA1_Channel14->CSAR;tail[55]=GPDMA1_Channel14->CDAR;
#if XE_NP_NP2_LIVE_SD_FAULT_SD_PINS_TEST
    if(dma_active && card && card->Instance){
        volatile uint32_t *id=xe_np_np2_idma_fault_diag;
        id[0]=0x4649324EU;id[1]=error==XE_NP_NP2_LIVE_SD_ERROR_WRITE?2U:1U;id[3]=write_lba;
        id[4]=card->Instance->IDMACTRL;id[5]=card->Instance->IDMABSIZE;
        id[6]=card->Instance->IDMABASER;id[7]=card->Instance->IDMALAR;
        id[8]=card->Instance->IDMABAR;id[9]=card->Instance->DCTRL;
        id[10]=card->Instance->DLEN;id[11]=card->Instance->DCOUNT;
        id[12]=card->Instance->STA;id[13]=card->Instance->MASK;
        id[14]=card->Instance->CMD;id[15]=card->Instance->ARG;
        id[16]=sd_ll_node_index;id[17]=sd_ll_bytes_done;id[18]=sd_ll.NodesCounter;
#if VSC_PSRAM_IDMA
        if(error==XE_NP_NP2_LIVE_SD_ERROR_WRITE){
            for(uint32_t i=0U;i<FIXED_FRAGMENT_OWNERS && i<16U;i++)
                if(i<dma_units && dma_external[i])id[18]|=1U<<(16U+i);
        }
#endif
        id[19]=NVIC_GetEnableIRQ(SDMMC1_IRQn);id[20]=NVIC_GetPendingIRQ(SDMMC1_IRQn);
        id[21]=key;id[22]=__get_BASEPRI();id[23]=(uint32_t)(uintptr_t)sd_ll.pHeadNode;
        for(uint32_t i=0U;i<2U;i++){
            /* Never chase a hardware-supplied address on the fault path. */
            id[24U+i*3U]=i<sd_ll.NodesCounter?sd_ll_nodes[i].IDMALAR:0U;
            id[25U+i*3U]=i<sd_ll.NodesCounter?sd_ll_nodes[i].IDMABASER:0U;
            id[26U+i*3U]=i<sd_ll.NodesCounter?sd_ll_nodes[i].IDMABSIZE:0U;
        }
        id[30]=card->Instance->DCOUNT;id[31]=card->Instance->STA;
        __DMB();id[2]=1U;
    }
#endif
    __DMB();d[2]=1U;
#if XE_NP_NP2_SD_DUAL20_STATUS_RETRY_TEST
    }
#endif
    __set_PRIMASK(key);
    if(cache)(void)clean((void *)d,sizeof(xe_np_np2_overflow_fault_diag));
#if XE_NP_NP2_LIVE_SD_FAULT_SD_PINS_TEST
    if(cache)(void)clean((void *)xe_np_np2_idma_fault_diag,sizeof(xe_np_np2_idma_fault_diag));
#endif
    }
#endif
    xe_np_np2_live_sd_mailbox.fault_sequence=xe_np_np2_live_sd_mailbox.produced_blocks;
    xe_np_np2_live_sd_mailbox.fault_detail=detail;
    /* These words are otherwise used only by completed wire verification.
     * On the DirectProgress watchdog path, preserve the producer's last raw
     * DMA snapshot at failure instead: phase0=IRQ age in ms, phase1=DMA byte
     * offset, phase2=expected events in the upper halfword and low DMA/PSSI
     * fault flags in the lower halfword. This runs only on failure. */
    if(error==XE_NP_NP2_LIVE_SD_ERROR_SOURCE && detail==1U){
        XE_NP_Np2Producer capture={0};
        XE_NP_Np2CapturePort_Diagnostics(&capture);
        if(capture.error){
            xe_np_np2_live_sd_mailbox.phase0=capture.last_fault.now_ms-capture.last_irq_ms;
            xe_np_np2_live_sd_mailbox.phase1=capture.last_fault.offset;
            xe_np_np2_live_sd_mailbox.phase2=
                ((capture.last_fault.events&0xFFFFU)<<16U)|(capture.last_fault.fault&0xFFFFU);
        }
    }
    /* HAL abort clears ErrorCode/flags; retain the failure before cleanup. */
    xe_np_np2_live_sd_mailbox.sd_error=card?card->ErrorCode:0U;
    xe_np_np2_live_sd_mailbox.sd_sta=(card&&card->Instance)?card->Instance->STA:0U;
    xe_np_np2_live_sd_mailbox.error=error;
#if XE_NP_NP2_LIVE_SD_ROLLING_CMD25
    /* Failure-only rolling receipt: announced RUs, consumed RUs, and the
     * first descriptor not yet retired. No per-node diagnostic traffic. */
    if(error!=XE_NP_NP2_LIVE_SD_ERROR_SOURCE || detail!=1U){
        xe_np_np2_live_sd_mailbox.phase0=rolling_published_rus;
        xe_np_np2_live_sd_mailbox.phase1=sd_ll_retired_rus;
        xe_np_np2_live_sd_mailbox.phase2=sd_ll_node_index;
    }
#endif
    /* Capture the unfinished transfer BEFORE stop/abort clears its evidence.
     * Completed-write maxima alone hide precisely the blocking tail. */
    xe_np_np2_live_sd_perf.fault_dma_active=dma_active;
    if(dma_active){
        xe_np_np2_live_sd_perf.fault_write_age_cycles=elapsed(write_started);
        xe_np_np2_live_sd_perf.fault_dcount=card->Instance->DCOUNT;
        xe_np_np2_live_sd_perf.fault_irq_dataend=irq_dataend_seen;
        xe_np_np2_live_sd_perf.fault_irq_return=irq_return_seen;
        xe_np_np2_live_sd_perf.fault_dma_units=dma_units;
#if XE_NP_NP2_LIVE_SD_IDMA_GAP_DIAG
        xe_np_np2_sd_idma_gap_diag[10]=cycles()-sd_ll_last_node_cycles;
        xe_np_np2_sd_idma_gap_diag[11]=sd_ll_node_index;
        xe_np_np2_sd_idma_gap_diag[12]=card->Instance->DCOUNT;
        xe_np_np2_sd_idma_gap_diag[13]=xe_np_np2_live_sd_perf.fault_write_age_cycles;
        xe_np_np2_sd_idma_gap_diag[14]=write_lba;
#endif
    }
    xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_FAILED;
#if XE_NP_NP2_STAGED_CAPTURE
    xe_np_np2_stage_fault_diag[0]=0x53544644U;
    xe_np_np2_stage_fault_diag[1]=error;
    xe_np_np2_stage_fault_diag[2]=detail;
    xe_np_np2_stage_fault_diag[3]=stage_queue.produced;
    xe_np_np2_stage_fault_diag[4]=stage_queue.handed;
    xe_np_np2_stage_fault_diag[5]=stage_queue.copy_kind;
    xe_np_np2_stage_fault_diag[6]=stage_dma.offset;
    xe_np_np2_stage_fault_diag[7]=stage_dma.chunk_bytes;
    xe_np_np2_stage_fault_diag[8]=GPDMA1_Channel14->CSR;
    xe_np_np2_stage_fault_diag[9]=GPDMA1_Channel14->CCR;
    xe_np_np2_stage_fault_diag[10]=GPDMA1_Channel14->CBR1;
    xe_np_np2_stage_fault_diag[11]=GPDMA1_Channel14->CSAR;
    xe_np_np2_stage_fault_diag[12]=GPDMA1_Channel14->CDAR;
    xe_np_np2_stage_fault_diag[13]=stage_dma.started_cycles;
    xe_np_np2_stage_fault_diag[14]=DWT->CYCCNT;
    xe_np_np2_stage_fault_diag[15]=stage_queue.spill_count;
    xe_np_np2_stage_fault_diag[16]=card->Instance->MASK;
    xe_np_np2_stage_fault_diag[17]=card->Instance->DCTRL;
    xe_np_np2_stage_fault_diag[18]=card->Instance->CMD;
    xe_np_np2_stage_fault_diag[19]=card->Instance->IDMACTRL;
    xe_np_np2_stage_fault_diag[20]=(uint32_t)NVIC_GetEnableIRQ(SDMMC1_IRQn);
    xe_np_np2_stage_fault_diag[21]=(uint32_t)NVIC_GetPendingIRQ(SDMMC1_IRQn);
    xe_np_np2_stage_fault_diag[22]=__get_PRIMASK();
    xe_np_np2_stage_fault_diag[23]=__get_BASEPRI();
    xe_np_np2_stage_fault_diag[24]=(uint32_t)card->State;
    xe_np_np2_stage_fault_diag[25]=card->Context;
    xe_np_np2_stage_fault_diag[26]=write_lba;
    xe_np_np2_stage_fault_diag[28]=stage_queue.committed;
#if XE_NP_NP2_STAGED_LONG_CMD25
    xe_np_np2_stage_fault_diag[29]=stage_long_window.published;
    xe_np_np2_stage_fault_diag[30]=stage_long_window.retired;
    xe_np_np2_stage_fault_diag[31]=stage_long_window.base_sequence;
#endif
    xe_np_np2_stage_fault_diag[32]=sd_ll_node_index;
    xe_np_np2_stage_fault_diag[33]=sd_ll_consumed_rus;
    xe_np_np2_stage_fault_diag[34]=sd_ll_retired_rus;
    xe_np_np2_stage_fault_diag[35]=sd_ll_bytes_done;
    xe_np_np2_stage_fault_diag[36]=sd_ll_fault;
    xe_np_np2_stage_fault_diag[37]=stage_queue.copy_sequence;
    uint32_t store_states=0U;
    for(uint32_t i=0U;i<8U;i++)store_states|=(uint32_t)stage_queue.store_state[i]<<(i*4U);
    xe_np_np2_stage_fault_diag[38]=store_states;
    xe_np_np2_stage_fault_diag[39]=(uint32_t)stage_queue.store_state[8];
#endif
#if XE_NP_NP2_SD_COPY_WAKE_TEST
    spill_wake_retire();
#endif
#if XE_NP_NP2_SD_INGRESS_DMA_TEST
    /* Do not let a source stop or a later session reuse a still-owned span.
     * A failed abort retains the pending owner and blocks reinitialization. */
    if(ingress_dma_stop()==0)ingress_pending=0U;
#endif
#if XE_NP_PSRAM_HOST_PARK_TEST
    /* Resume restores clocks even on refusal; preserve the original failure. */
    (void)resume_parked_psram(1U);
#endif
    copy_cost_freeze(); /* Before source stop/C14 abort or any later clock reduction. */
    XE_NP_Np2UsbSource_Stop();
    XE_NP_Np2Preparation_SourceStopped();
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
    if(overflow_kind || (GPDMA1_Channel14->CCR&DMA_CCR_EN)){
        xe_np_np2_overflow_dma_diag[6]=detail;
        (void)HAL_DMA_Abort(&spill_dma);
    }
#endif
#if XE_NP_NP2_STAGED_CAPTURE
    XE_Np2StageDma_Stop(&stage_dma);
#endif
    if(dma_active && card){(void)HAL_SD_Abort(card);dma_active=0U;}
#if XE_NP_SD_FAILURE_TRACE_ENABLE
    /* Capture is stopped now; publish the failure-only IRQ/command receipt. */
    if(cache && xe_np_np2_overflow_fault_diag[2])
        (void)clean((void *)xe_np_np2_overflow_fault_diag,sizeof(xe_np_np2_overflow_fault_diag));
#endif
    /* Failure-only cleanup. HAL_SD_Abort can time out after setting READY,
     * leaving linked IDMA enabled. Do not treat that as a completed write or
     * reuse a buffer while either state machine/card busy signal is active.
     * Once all three are idle, remove the stale host configuration without
     * clearing the retained error or pretending the card is recording-ready.
     * No register check is added to successful capture/write services. */
    if(card && card->Instance &&
       !(card->Instance->STA&(SDMMC_STA_DPSMACT|SDMMC_STA_CPSMACT|SDMMC_STA_BUSYD0))){
        card->Instance->DCTRL=0U;
        card->Instance->DLEN=0U;
        card->Instance->IDMACTRL=0U;
        __DSB();
    }
    if(record_started_ms && !xe_np_np2_live_sd_mailbox.recording_ms)
        xe_np_np2_live_sd_mailbox.recording_ms=HAL_GetTick()-record_started_ms;
    publish();
}

#if XE_NP_NP2_STAGED_CAPTURE
static void observe_stage_copy(uint32_t kind)
{
    if(kind<XE_NP2_STAGE_TO_SRAM || kind>XE_NP2_STAGE_FROM_PSRAM)return;
    volatile uint32_t *words=&xe_np_np2_stage_copy_diag[2U+(kind-1U)*7U];
    uint32_t elapsed=stage_dma.completed_elapsed_cycles;
    uint32_t work=stage_dma.completed_work_cycles;
    words[0]++;
    uint32_t low=words[1];
    words[1]=low+elapsed;
    words[2]+=(words[1]<low);
    if(elapsed>words[3])words[3]=elapsed;
    low=words[4];
    words[4]=low+work;
    words[5]+=(words[4]<low);
    if(work>words[6])words[6]=work;
}

static void service_stage(void)
{
    if(stage_dma.active){
        int complete=XE_Np2StageDma_Service(&stage_dma);
        if(complete<0){fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,0xDA10U|stage_dma.error);return;}
        if(complete){
            uint32_t kind=stage_queue.copy_kind;
            if(XE_Np2Stage_CompleteCopy(&stage_queue)){
                fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xDA11U);return;
            }
            observe_stage_copy(kind);
            if(kind==XE_NP2_STAGE_TO_PSRAM)
                maximum(&xe_np_np2_live_sd_perf.launch_wait_reserved,
                        stage_queue.spill_count);
            /* Only a complete GPDMA handoff releases the source. SD IDMA
             * owns an independent storage slot and cannot pin RU0..3. */
#if !XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE
            if(kind!=XE_NP2_STAGE_FROM_PSRAM &&
               XE_NP_Np2CapturePort_DirectRetireRUs(stage_queue.handed)){
                fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xDA12U);return;
            }
#else
            (void)kind;
#endif
        }
    }
    if(stage_dma.active ||
       (xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_CAPTURING &&
        xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_DRAINING))return;
    int feeder_urgent=0;
#if XE_NP_NP2_STAGED_LONG_CMD25 && XE_NP_NP2_STAGED_LONG_WINDOW_RUS == 180U && \
    !XE_NP2_STAGE_DIRECT_PSRAM_IDMA
    /* The long CMD25 has no command boundary at which to catch up. Restore
     * its exact next PSRAM RU before IDMA exhausts a three-RU lead, but only
     * if the producer has at most one sealed RU awaiting handoff. */
    if(dma_active)
        feeder_urgent=XE_Np2StageLong_RestoreUrgent(&stage_queue,
            &stage_long_window,sd_ll_consumed_rus);
#endif
    int kind=XE_Np2Stage_BeginCopyPriority(&stage_queue,feeder_urgent);
    if(kind<0){fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xDA13U);return;}
    if(!kind)return;
    uint32_t source=kind==XE_NP2_STAGE_FROM_PSRAM?
        XE_NP_PSRAM_BASE_ADDR+stage_queue.copy_source*RU_BYTES:
        stage_ru_base[XE_Np2Stage_SourcePhysicalRu(stage_queue.copy_sequence)];
    uint32_t destination=kind==XE_NP2_STAGE_TO_PSRAM?
        XE_NP_PSRAM_BASE_ADDR+stage_queue.copy_destination*RU_BYTES:
        stage_ru_base[XE_Np2Stage_StorePhysicalRu(stage_queue.copy_destination)];
    if(XE_Np2StageDma_Start(&stage_dma,source,destination))
        fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,0xDA14U|stage_dma.error);
}
#endif

void XE_NP_Np2LiveSd_Irq(SD_HandleTypeDef *handle)
{
    uint32_t start=cycles();
#if XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST
    /* HAL's SD IRQ is an else-if chain: a coincident DATAEND could otherwise
     * hide IDMABTC. Consume the descriptor event first, then leave all card
     * completion/error handling to HAL. */
    uint32_t flags=handle->Instance->STA;
    if(dma_active && handle==card && (flags&SDMMC_FLAG_IDMABTC) &&
       !(flags&ERROR_FLAGS) && !handle->ErrorCode){
        __HAL_SD_CLEAR_FLAG(handle,SDMMC_FLAG_IDMABTC);
        retire_linked_list_bytes(start);
#if XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
        if(copied_window.active && !sd_ll_fault){
            /* A sticky BTC is not a count. Wire progress is a conservative
             * lower bound on IDMA consumption, so reconcile delayed events
             * without releasing an RU merely because a later IRQ arrived. */
            uint32_t total=dma_blocks*512U,remaining=handle->Instance->DCOUNT;
            if(remaining>total)sd_ll_fault=1U;
            else while(!sd_ll_fault && sd_ll_node_index<sd_ll.NodesCounter &&
                 sd_ll_bytes_done<=total-remaining &&
                 sd_ll_node_bytes[sd_ll_node_index]<=total-remaining-sd_ll_bytes_done)
                retire_linked_list_bytes(start);
        }
#endif
    }
#endif
    uint8_t dataend=(uint8_t)(dma_active && handle==card && !irq_dataend_seen &&
                              (handle->Instance->STA&SDMMC_STA_DATAEND));
    if(dataend){irq_dataend_cycles=start;irq_dataend_seen=1U;}
#if XE_NP_NP2_LIVE_SD_COUNTED_WRITES
    /* CMD23 was acknowledged before this CMD25. Only an error-free DATAEND
     * with DCOUNT zero may use HAL's no-CMD12 completion branch. This is a
     * completion adapter, not CMD24: the wire transfer remains multi-block.
     * Error/abort paths keep the MULTIPLE context and their stop handling. */
    if(dataend && counted_write_active &&
       !(handle->Instance->STA&ERROR_FLAGS) && !handle->ErrorCode){
        if(handle->Instance->DCOUNT)handle->ErrorCode=HAL_SD_ERROR_DMA;
        else if(handle->Context==(SD_CONTEXT_WRITE_MULTIPLE_BLOCK|SD_CONTEXT_DMA))
            handle->Context=SD_CONTEXT_WRITE_SINGLE_BLOCK|SD_CONTEXT_DMA;
        else handle->ErrorCode=HAL_SD_ERROR_DMA;
    }
#endif
#if XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST
    uint32_t context_before=handle->Context;
    /* Preserve the live byte-count witness before HAL clears DLEN/DCTRL.
     * READY/zero IDMA alone also describes an aborted transfer. */
    uint8_t transferred_before_hal=(uint8_t)(dma_active && handle==card &&
        (context_before==(SD_CONTEXT_WRITE_MULTIPLE_BLOCK|SD_CONTEXT_DMA) ||
         context_before==(SD_CONTEXT_WRITE_SINGLE_BLOCK|SD_CONTEXT_DMA)) &&
        handle->State!=HAL_SD_STATE_READY && !handle->ErrorCode &&
        handle->Instance->DCOUNT==0U && !(handle->Instance->STA&ERROR_FLAGS));
#endif
    HAL_SD_IRQHandler(handle);
#if XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST
    /* DATAEND can assert after our entry snapshot but before HAL reads STA.
     * HAL then clears it and marks the command complete while this adapter
     * would otherwise leave the IDMA buffers pinned forever. Accept only an
     * error-free DMA-write transition all the way to HAL READY with zero
     * remaining bytes/IDMA; a partial or aborted write never qualifies.
     * Copied linked-list writes have the same race as staged long CMD25. */
    if(!dataend && dma_active && handle==card && !irq_dataend_seen &&
       (context_before&(SD_CONTEXT_WRITE_MULTIPLE_BLOCK|SD_CONTEXT_DMA))==
           (SD_CONTEXT_WRITE_MULTIPLE_BLOCK|SD_CONTEXT_DMA) &&
       handle->State==HAL_SD_STATE_READY && handle->Context==SD_CONTEXT_NONE &&
       handle->ErrorCode==HAL_SD_ERROR_NONE && handle->Instance->DCOUNT==0U &&
       handle->Instance->IDMACTRL==0U &&
       !(handle->Instance->STA&ERROR_FLAGS)){
        irq_dataend_cycles=cycles();irq_dataend_seen=1U;
#if XE_NP_NP2_STAGED_LONG_CMD25
        xe_np_np2_stage_fault_diag[27]++;
#endif
        dataend=1U;
    }
    if(transferred_before_hal && dataend && dma_active && handle==card && !sd_ll_fault &&
       handle->State==HAL_SD_STATE_READY && handle->Context==SD_CONTEXT_NONE &&
       !handle->ErrorCode && handle->Instance->DCOUNT==0U &&
       handle->Instance->IDMACTRL==0U &&
       !(handle->Instance->STA&(ERROR_FLAGS|SDMMC_STA_DPSMACT))){
        /* BTC is a latched bit, not a descriptor counter: a tiny intermediate
         * node can coalesce with its neighbour. A terminal BTC may also arrive
         * after our entry snapshot and be masked by HAL's DATAEND branch.
         * Reconcile only after the owned full transfer, never at HAL READY alone. */
        if(handle->Instance->STA&SDMMC_FLAG_IDMABTC){
            __HAL_SD_CLEAR_FLAG(handle,SDMMC_FLAG_IDMABTC);
            if(sd_ll_node_index<sd_ll.NodesCounter)retire_linked_list_bytes(start);
        }
        if(sd_ll_node_index && sd_ll_node_index<sd_ll.NodesCounter && !sd_ll_fault){
            uint32_t total=
#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
                dma_blocks*512U;
#else
                (uint32_t)dma_units*RU_BYTES;
#endif
            uint32_t declared=sd_ll_bytes_done;
            if(sd_ll.NodesCounter>SD_LLI_MAX_NODES || declared>total)sd_ll_fault=1U;
            for(uint32_t i=sd_ll_node_index;!sd_ll_fault && i<sd_ll.NodesCounter;i++){
                uint32_t bytes=sd_ll_node_bytes[i];
                if(!bytes || (bytes&511U) || bytes>total-declared)sd_ll_fault=1U;
                else declared+=bytes;
            }
            if(declared!=total)sd_ll_fault=1U;
            while(!sd_ll_fault && sd_ll_node_index<sd_ll.NodesCounter)
                retire_linked_list_bytes(start);
        }
    }
#endif
    if(dataend){irq_return_cycles=cycles();irq_return_seen=1U;}
    xe_np_np2_live_sd_perf.irq_cycles+=elapsed(start);
}

#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
static int ready_sequence(uint32_t sequence)
{
    for(uint32_t i=0U;i<RU_COUNT;i++)
        if(ru_state[i]==RU_READY && ru_first_block[i]==sequence)return (int)i;
    return -1;
}
#if VSC_PSRAM_IDMA
static int ready_spill_sequence(uint32_t sequence)
{
    if(spill_count>SPILL_SLOTS || spill_tail>=SPILL_SLOTS || spill_head>=SPILL_SLOTS){
        fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD924U);return -1;
    }
    for(uint32_t i=0U;i<spill_count;i++){
        uint32_t slot=(spill_tail+i)%SPILL_SLOTS;
        if(spill_sequence[slot]==sequence &&
           !(overflow_kind==1U && slot==spill_head))return (int)slot;
    }
    return -1;
}
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
static int commit_overflow_order(void)
{
    /* Once per card-ready command, never in BTC/capture IRQ. Every sealed
     * RU is durable or still held by SRAM/FIFO. BTC may reuse this command's
     * SRAM early; its latched sequence remained unresolved until NOW.
     * Unproduced/partial RUs bound the prefix, not the largest written LBA. */
    uint32_t produced_rus=xe_np_np2_live_sd_mailbox.produced_blocks/BLOCKS_PER_RU;
    uint32_t prefix=produced_rus,unresolved=spill_count;
    for(uint32_t i=0U;i<RU_COUNT;i++)if(ru_state[i]!=RU_FREE){
        uint32_t sequence=ru_first_block[i]/BLOCKS_PER_RU;
        if(ru_first_block[i]%BLOCKS_PER_RU || sequence>produced_rus ||
           (sequence==produced_rus && ru_state[i]!=RU_FILLING)){
            xe_np_np2_overflow_order_diag[6]=0xD902U;
            fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD902U);return -1;
        }
        if(sequence<prefix)prefix=sequence;
        unresolved+=sequence<produced_rus;
    }
    if(spill_count){
        uint32_t sequence=spill_sequence[spill_tail]/BLOCKS_PER_RU;
        if(spill_sequence[spill_tail]%BLOCKS_PER_RU || sequence>=produced_rus){
            xe_np_np2_overflow_order_diag[6]=0xD903U;
            fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD903U);return -1;
        }
        if(sequence<prefix)prefix=sequence;
    }
    /* A restore owns both its FIFO source and RU_COPY destination until
     * publication. It is one unresolved record, not two. */
    if(overflow_kind==2U){
        if(!spill_count || overflow_ru>=RU_COUNT || ru_state[overflow_ru]!=RU_COPY ||
           ru_first_block[overflow_ru]!=spill_sequence[spill_tail]){
            xe_np_np2_overflow_order_diag[6]=0xD904U;
            fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD904U);return -1;
        }
        unresolved--;
    }
    uint32_t total=xe_np_np2_overflow_order_diag[2]+
#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
        dma_complete_units;
#else
        dma_units;
#endif
    if(dma_first_ru<xe_np_np2_live_sd_mailbox.written_rus ||
       dma_first_ru+dma_units>produced_rus ||
       prefix<xe_np_np2_live_sd_mailbox.written_rus || prefix>total ||
       total>active_target_rus || total>produced_rus ||
       unresolved!=produced_rus-total){
        xe_np_np2_overflow_order_diag[6]=0xD900U;
        fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD900U);return -1;
    }
    xe_np_np2_overflow_order_diag[2]=total;
    xe_np_np2_overflow_order_diag[5]=prefix;
    maximum(&xe_np_np2_overflow_order_diag[7],produced_rus-prefix);
    xe_np_np2_live_sd_mailbox.written_rus=prefix;
    return 0;
}
#endif
#endif

#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
static int runtime_direct_retire(void)
{
    if(!SESSION_RUNTIME_DIRECT || !runtime_direct_retire_pending)return 0;
    /* IRQs can only return owners during this foreground scan. Clear first:
     * a concurrent return leaves the latch set for another conservative pass. */
    runtime_direct_retire_pending=0U;
    uint32_t prepared=xe_np_np2_live_sd_mailbox.produced_blocks/BLOCKS_PER_RU;
    uint32_t prefix=prepared;
    for(uint32_t i=0U;i<NP2_RUNTIME_DIRECT_CAPTURE_RUS;i++)if(ru_state[i]!=RU_FREE){
        uint32_t first=ru_first_block[i],generation=first/BLOCKS_PER_RU;
        if(first%BLOCKS_PER_RU || generation<runtime_direct_retired_rus || generation>prepared ||
           (generation==prepared && ru_state[i]!=RU_FILLING) || ru_state[i]>RU_COPY){
            fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD960U|i);return -1;
        }
        if(generation<prefix)prefix=generation;
    }
    if(prefix<runtime_direct_retired_rus ||
       (prefix>runtime_direct_retired_rus && XE_NP_Np2CapturePort_DirectRetireRUs(prefix))){
        fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD970U);return -1;
    }
    runtime_direct_retired_rus=prefix;
    return 0;
}
#endif

#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
static uint32_t sd_physical_slot(uint32_t unit)
{
    return dma_slots[unit];
}
#else
#define sd_physical_slot(unit) ((dma_ru+(unit))%RU_COUNT)
#endif

static int ready_ru(void)
{
#if XE_NP_NP2_STAGED_CAPTURE
    return XE_Np2Stage_ReadyStore(&stage_queue,stage_queue.committed);
#elif XE_NP_NP2_LIVE_SD_DIRECT
    uint32_t next=xe_np_np2_live_sd_mailbox.written_rus%RU_COUNT;
    return ru_state[next]==RU_READY?(int)next:-1;
#elif XE_NP_NP2_LIVE_SD_OVERFLOW_DMA && !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
    return ready_sequence(xe_np_np2_live_sd_mailbox.written_rus*BLOCKS_PER_RU);
#else
    int selected=-1;
    for(uint32_t i=0U;i<RU_COUNT;i++)if(ru_state[i]==RU_READY &&
       (selected<0 || (int32_t)(ru_first_block[i]-ru_first_block[(uint32_t)selected])<0))selected=(int)i;
    return selected;
#endif
}

static uint32_t ring_depth(void)
{
    uint32_t depth=0U;
#if XE_NP_NP2_STAGED_CAPTURE
    for(uint32_t i=0U;i<XE_NP2_STAGE_ACQ_RUS;i++)
        depth+=stage_queue.source_state[i]!=XE_NP2_STAGE_FREE;
    for(uint32_t i=0U;i<XE_NP2_STAGE_STORE_RUS;i++)
        depth+=stage_queue.store_state[i]!=XE_NP2_STAGE_FREE;
#else
    for(uint32_t i=0U;i<RU_COUNT;i++)depth+=(ru_state[i]!=RU_FREE);
#endif
    return depth;
}

#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
static uint32_t fixed_window_blocks(void)
{
    if((XE_NP_NP2_SD_TRIPLE7500_WINDOW1536_TEST || XE_NP_NP2_SD_SINGLE_MID_WINDOW1536_TEST || XE_NP_NP2_SD_DUAL20_WINDOW1536_TEST) &&
       fixed_window_shift==FIXED_WINDOW_1536_MODE)return 1536U;
    return 1U<<fixed_window_shift;
}
static uint32_t fixed_window_index(uint32_t blocks)
{
    if((XE_NP_NP2_SD_TRIPLE7500_WINDOW1536_TEST || XE_NP_NP2_SD_SINGLE_MID_WINDOW1536_TEST || XE_NP_NP2_SD_DUAL20_WINDOW1536_TEST) &&
       fixed_window_shift==FIXED_WINDOW_1536_MODE)return blocks/1536U;
    return blocks>>fixed_window_shift;
}
/* Build only sealed immutable slices. A normal command is one aligned
 * window (512KiB by default). Under pressure, a pending single-RU piece restores the
 * historical singleton escape: at most two successful commands free it.
 * Never wait for neighbours trapped behind a full external FIFO. */
static uint8_t fixed_part_bits(uint32_t first,uint32_t window)
{
    uint32_t low=fixed_window_index(first),high=fixed_window_index(first+RU_BLOCKS-1U);
    return low==high?3U:(window==low?1U:2U);
}
static int vsc_pressure_profile(void)
{
#if XE_NP_NP2_LIVE_SD_VSC_PRESSURE_PREFIX_TEST
    /* Same logical1024 windows/parts in the explicit high-two classic trial. */
    return (SESSION_VSC || XE_NP_NP2_SD_HIGH_TWO_CLASSIC_TEST) &&
           ((LIVE_PROBE_MASK==3U && record_sample_hz==30000U) ||
            (LIVE_PROBE_MASK==7U && record_sample_hz==20000U));
#else
    return 0;
#endif
}
static uint32_t fixed_sequential_blocks(uint32_t start,uint32_t target)
{
    uint32_t blocks=target-start,cap=fixed_window_blocks();
#if XE_NP_NP2_SD_ORDERED_BATCH3_TEST
    if(SESSION_BATCH3)cap=3U*RU_BLOCKS;
#endif
#if XE_NP_NP2_LIVE_SD_VSC_PRESSURE_PREFIX_TEST
    if(vsc_pressure_profile())cap-=start%1024U;
#endif
    return blocks<cap?blocks:cap;
}

static int fixed_select_span(uint32_t start,uint32_t blocks)
{
    uint32_t end=start+blocks,first=start/RU_BLOCKS;
    uint32_t last=(end-1U)/RU_BLOCKS,units=last-first+1U;
    if(!blocks || units>FIXED_FRAGMENT_OWNERS || last>=active_target_rus)return 0;
    uint32_t complete=0U,mask=0U;
#if XE_NP_NP2_LIVE_SD_SPILL_LEG_4K_TEST || XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST || XE_NP_NP2_LIVE_SD_SPILL_LAUNCH_TRACE_TEST
    dma_window_external=0U;
#endif
    for(uint32_t i=0U;i<units;i++){
        uint32_t sequence=(first+i)*BLOCKS_PER_RU;
        int slot=ready_sequence(sequence);
#if VSC_PSRAM_IDMA
        uint8_t external=0U;
        if(slot<0 && SESSION_PSRAM_IDMA){slot=ready_spill_sequence(sequence);external=1U;}
#endif
        if(slot<0)return 0;
        uint32_t base=(first+i)*RU_BLOCKS;
        uint32_t begin=start>base?start:base;
        uint32_t limit=end<base+RU_BLOCKS?end:base+RU_BLOCKS;
        uint8_t bits=
#if XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_VSC_TEST
            SESSION_WHOLE_RU?((begin==base?1U:0U)|(limit==base+RU_BLOCKS?2U:0U)):
#elif XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_TEST
            SESSION_WHOLE_RU?3U:
#endif
            fixed_part_bits(base,fixed_window_index(start));
        uint8_t parts=
#if VSC_PSRAM_IDMA
            external?spill_parts[slot]:
#endif
            ru_parts[slot];
        if(parts&bits)return 0;
#if XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_VSC_TEST
        /* An AU-edge prefix retains this immutable owner through CMD13.
         * Its suffix must prove that exact prefix; no middle-only slice. */
        if(SESSION_WHOLE_RU && (!bits || parts!=(begin>base?1U:0U)))return 0;
#endif
        dma_slots[i]=(uint8_t)slot;dma_generation[i]=sequence;
#if VSC_PSRAM_IDMA
        dma_external[i]=external;
#if XE_NP_NP2_LIVE_SD_SPILL_LEG_4K_TEST || XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST || XE_NP_NP2_LIVE_SD_SPILL_LAUNCH_TRACE_TEST
        dma_window_external|=external; /* Latch once, not a per-copy owner scan. */
#endif
#endif
        dma_offset[i]=(begin-base)*512U;dma_block_count[i]=limit-begin;
        dma_part_bits[i]=bits;
        sd_ll_fragment_end[i]=(limit-start)*512U;
        if((parts|bits)==3U){mask|=1U<<i;complete++;}
    }
    dma_first_ru=first;dma_ru=dma_slots[0];dma_units=(uint8_t)units;
    dma_blocks=blocks;dma_complete_mask=mask;dma_complete_units=complete;
    write_lba=record_start_lba+start;
    return 1;
}

#if VSC_PSRAM_IDMA
static int commit_external_parts(void)
{
    /* Foreground/card-confirmed only. C14 can append a different unpublished
     * head, but cannot restore/pop or overwrite any of these FIFO owners. */
    for(uint32_t i=0U;i<dma_units;i++)if(dma_external[i]){
        uint32_t slot=dma_slots[i];
        if(slot>=SPILL_SLOTS || spill_sequence[slot]!=dma_generation[i] ||
           (spill_parts[slot]&dma_part_bits[i]) ||
           (overflow_kind==1U && slot==spill_head))return -1;
    }
    for(uint32_t i=0U;i<dma_units;i++)if(dma_external[i])
        spill_parts[dma_slots[i]]|=dma_part_bits[i];
    __DMB();
    while(spill_count && spill_parts[spill_tail]==3U){
        uint32_t matched=0U;
        for(uint32_t i=0U;i<dma_units;i++)if(dma_external[i] &&
            dma_slots[i]==spill_tail && spill_sequence[spill_tail]==dma_generation[i] &&
            (dma_complete_mask&(1U<<i))){matched=1U;break;}
        if(!matched)return -1;
        spill_tail=(spill_tail+1U)%SPILL_SLOTS;spill_count--;
    }
    xe_np_np2_overflow_dma_diag[5]=spill_count;
    return 0;
}
#endif

#if XE_NP_NP2_SD_APPEND_ORDER_TEST
static int select_append_write(void)
{
    /* Immutable whole RUs, existing SG/BTC owners, no payload copy or header
     * rewrite. Logical gaps never become physical card-address gaps. */
    uint32_t physical=fixed_confirmed_blocks/RU_BLOCKS;
    if(dma_active || physical>=active_target_rus)return 0;
    if(fixed_confirmed_blocks%RU_BLOCKS){
        fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD940U);return 0;
    }
    int oldest=ready_ru();
    if(oldest<0)return 0;
    if(!physical && ru_first_block[oldest])return 0; /* Phase origin is logical0. */
    uint32_t cap=XE_NP_NP2_LIVE_SD_WRITE_CAP_RUS;
#if XE_NP_NP2_SD_READY_APPEND_TEST
    /* All selected payloads already exist; unlike the finite-window trial,
     * no future-generation reservation can force tiny prefix-only writes.
     * Logical chunks retain their original headers for the append reader;
     * physical SD addresses still advance by exactly the confirmed count. */
    if(LIVE_PROBE_MASK==3U && record_sample_hz==30000U &&
       !SESSION_VSC && !SESSION_WHOLE_RU)cap=RU_COUNT-1U;
    _Static_assert(sizeof(ru_state)/sizeof(ru_state[0])==9U &&
                   DMA_WINDOW_OWNERS>=8U && SD_LLI_MAX_NODES>=24U,
                   "Ready append table bounds");
#endif
#if XE_NP_NP2_SD_APPEND_DUAL30_CMD1_TEST
    if(LIVE_PROBE_MASK==3U && record_sample_hz==30000U)cap=1U;
#endif
    if(cap>active_target_rus-physical)cap=active_target_rus-physical;
    uint32_t units=0U,produced_rus=xe_np_np2_live_sd_mailbox.produced_blocks/BLOCKS_PER_RU;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    uint32_t selected_slots=0U;
#endif
    for(uint32_t n=0U;n<=RU_COUNT && units<cap;n++){
        uint32_t slot=n?n-1U:(uint32_t)oldest;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
        if(SESSION_RUNTIME_DIRECT){
            /* Include the globally oldest, then choose capture-ring owners
             * before restore-only owners, oldest within each class. At most
             * six eleven-slot scans per command; no payload work here. */
            if(n){
                int next=-1;
                for(uint32_t i=0U;i<RU_COUNT;i++)if(ru_state[i]==RU_READY &&
                   !(selected_slots&(1U<<i)) &&
                   (next<0 ||
                    (i<NP2_RUNTIME_DIRECT_CAPTURE_RUS && (uint32_t)next>=NP2_RUNTIME_DIRECT_CAPTURE_RUS) ||
                    ((i<NP2_RUNTIME_DIRECT_CAPTURE_RUS)==((uint32_t)next<NP2_RUNTIME_DIRECT_CAPTURE_RUS) &&
                     (int32_t)(ru_first_block[i]-ru_first_block[(uint32_t)next])<0)))next=(int)i;
                if(next<0)break;
                slot=(uint32_t)next;
            }
            selected_slots|=1U<<slot;
        }else
#endif
        if((n && slot==(uint32_t)oldest) || ru_state[slot]!=RU_READY)continue;
        uint32_t sequence=ru_first_block[slot],logical=sequence/BLOCKS_PER_RU;
        if(sequence%BLOCKS_PER_RU || ru_parts[slot] ||
           logical<xe_np_np2_live_sd_mailbox.written_rus ||
           logical>=produced_rus || logical>=active_target_rus){
            fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD941U);return 0;
        }
        dma_slots[units]=(uint8_t)slot;dma_generation[units]=sequence;
        dma_offset[units]=0U;dma_block_count[units]=RU_BLOCKS;dma_part_bits[units]=3U;
        sd_ll_fragment_end[units]=(units+1U)*RU_BYTES;
        units++;
    }
    if(!units)return 0;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(SESSION_RUNTIME_DIRECT && physical && units>1U &&
       dma_slots[0]>=NP2_RUNTIME_DIRECT_CAPTURE_RUS &&
       dma_slots[1]<NP2_RUNTIME_DIRECT_CAPTURE_RUS){
        /* Same members/fairness, earlier capture-prefix release. Keep origin0
         * and the oldest logical anchor below; move metadata, never payload. */
        uint8_t first=dma_slots[0];uint32_t generation=dma_generation[0],i=1U;
        for(;i<units && dma_slots[i]<NP2_RUNTIME_DIRECT_CAPTURE_RUS;i++){
            dma_slots[i-1U]=dma_slots[i];dma_generation[i-1U]=dma_generation[i];
        }
        dma_slots[i-1U]=first;dma_generation[i-1U]=generation;
    }
#endif
    dma_first_ru=ru_first_block[oldest]/BLOCKS_PER_RU;dma_ru=dma_slots[0];
    dma_units=(uint8_t)units;dma_blocks=units*RU_BLOCKS;
    dma_complete_units=units;dma_complete_mask=(1U<<units)-1U;fixed_fallback=0U;
    write_lba=record_start_lba+fixed_confirmed_blocks;
    return 1;
}
#endif

static int select_fixed_write(void)
{
#if XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
    if(copied_window_policy())return copied_window_select();
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    if(SESSION_APPEND)return select_append_write();
#endif
#if XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_TEST
    if(SESSION_WHOLE_RU){
        /* Same descriptor/IRQ owners and strictly increasing SD addresses.
         * Ordinary whole-RU trials submit any ready prefix. Batch3 assembles
         * the matching prefetched group; acquisition is never paused. */
        uint32_t start=fixed_confirmed_blocks,first=start/RU_BLOCKS;
        if(dma_active || first>=active_target_rus)return 0;
        if(first!=xe_np_np2_live_sd_mailbox.written_rus ||
#if XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_VSC_TEST
           (start%RU_BLOCKS && (!SESSION_VSC || !vsc_au_blocks ||
                               (record_start_lba+start)%vsc_au_blocks))
#else
           start%RU_BLOCKS
#endif
           ){
            fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD930U);return 0;
        }
        uint32_t units=0U,cap=XE_NP_NP2_LIVE_SD_WRITE_CAP_RUS;
#if XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_VSC_TEST
        uint32_t limit=active_target_rus*RU_BLOCKS;
        if(SESSION_VSC){
            if(vsc_au_end<=record_start_lba || vsc_au_end-record_start_lba<=start)return 0;
            uint32_t registered=vsc_au_end-record_start_lba;
            if(limit>registered)limit=registered;
        }
        uint32_t available=(limit-1U)/RU_BLOCKS+1U-first;
        if(cap>available)cap=available;
#else
        if(cap>active_target_rus-first)cap=active_target_rus-first;
#endif
#if XE_NP_NP2_SD_ORDERED_BATCH3_TEST
        if(SESSION_BATCH3 && cap>3U)cap=3U;
#endif
        while(units<cap && ready_sequence((first+units)*BLOCKS_PER_RU)>=0)units++;
        if(!units)return 0;
#if XE_NP_NP2_SD_ORDERED_BATCH3_TEST
        if(SESSION_BATCH3 && units<cap &&
           xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_DRAINING)return 0;
#endif
        fixed_fallback=0U;
#if XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_VSC_TEST
        uint32_t end=(first+units)*RU_BLOCKS;
        if(end>limit)end=limit;
        return fixed_select_span(start,end-start);
#else
        return fixed_select_span(start,units*RU_BLOCKS);
#endif
    }
#endif
#if XE_NP_NP2_LIVE_SD_VSC_TEST || XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST
#if XE_NP_NP2_SD_PROFILE_CLASSIC_TEST
    if(SESSION_VSC || XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST){
#endif
    /* The confirmed sector count is a contiguous prefix in this profile.
     * Never bypass a spilled head or shrink a command under FIFO pressure.
     * Only the stopped final tail may be shorter than512KiB. The standalone
     * comparison omits CMD20; mixed classic keeps its legacy preparation.
     * Neither claims formal speed-class filesystem qualification. */
    uint32_t target=active_target_rus*RU_BLOCKS,start=fixed_confirmed_blocks;
    if(fixed_confirmed_blocks>=target)return 0;
    uint32_t blocks=fixed_sequential_blocks(start,target);
#if XE_NP_NP2_LIVE_SD_VSC_PRESSURE_PREFIX_TEST
    uint32_t mid_window=vsc_pressure_profile() && (start%1024U);
#else
    uint32_t mid_window=0U;
#endif
    if(blocks<fixed_window_blocks() && !mid_window &&
       xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_DRAINING)return 0;
    fixed_fallback=(uint8_t)mid_window;
    if(fixed_select_span(start,blocks))return 1;
#if XE_NP_NP2_LIVE_SD_VSC_PRESSURE_PREFIX_TEST
    if(!vsc_pressure_profile() || !spill_count ||
       xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_CAPTURING)return 0;
    /* Only whole remaining RU fragments: fixed_part_bits can then prove
     * completion without adding a half-RU owner state or copied payload. */
    uint32_t end=start,previous=start,limit=start+blocks;
    while(end<limit){
        uint32_t unit=end/RU_BLOCKS,base=unit*RU_BLOCKS;
        int slot=ready_sequence(unit*BLOCKS_PER_RU);
        if(slot<0 || (ru_parts[slot]&fixed_part_bits(base,start/1024U)))break;
        uint32_t next=base+RU_BLOCKS;
        previous=end;
        end=next<limit?next:limit;
    }
    /* Avoid a second almost-empty CMD25. A short remaining-RU fragment is
     * useful only when it can release an owner before a blocked FIFO restore.
     * Both choices end on an RU; no sub-RU completion state is invented. */
    if(end<limit && limit-end<RU_BLOCKS/2U && previous>start)end=previous;
    if(end==limit || end==start)return 0;
    if(end-start<RU_BLOCKS/2U && !mid_window && spill_count<SPILL_SLOTS){
        uint32_t free_count=0U;
        for(uint32_t i=0U;i<RU_COUNT;i++)free_count+=ru_state[i]==RU_FREE;
        if(free_count>1U)return 0;
    }
    fixed_fallback=1U;
    return fixed_select_span(start,end-start);
#else
    return 0;
#endif
#if XE_NP_NP2_SD_PROFILE_CLASSIC_TEST
    }
#endif
#endif
#if (!XE_NP_NP2_LIVE_SD_VSC_TEST && !XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST) || XE_NP_NP2_SD_PROFILE_CLASSIC_TEST
    uint32_t target=active_target_rus*RU_BLOCKS,best=UINT32_MAX;
    uint32_t free_count=0U;
    for(uint32_t i=0U;i<RU_COUNT;i++){
        free_count+=ru_state[i]==RU_FREE;
        if(ru_state[i]!=RU_READY)continue;
        uint32_t sequence=ru_first_block[i]/BLOCKS_PER_RU;
        if(ru_parts[i]==3U || ru_first_block[i]%BLOCKS_PER_RU ||
           sequence<xe_np_np2_live_sd_mailbox.written_rus ||
           sequence>=xe_np_np2_live_sd_mailbox.produced_blocks/BLOCKS_PER_RU ||
           sequence>=active_target_rus){
            fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD923U);return 0;
        }
        uint32_t base=(ru_first_block[i]/BLOCKS_PER_RU)*RU_BLOCKS;
        uint32_t window=(ru_parts[i]&1U)?(base+RU_BLOCKS-1U)/1024U:base/1024U;
        uint32_t start=window*1024U;
        if(start>=best || start>=target)continue;
        uint32_t blocks=target-start;
        if(blocks>1024U)blocks=1024U;
        if(fixed_select_span(start,blocks))best=start;
    }
    if(best!=UINT32_MAX){
        uint32_t blocks=target-best;if(blocks>1024U)blocks=1024U;
        fixed_fallback=0U;
        return fixed_select_span(best,blocks);
    }
    if(free_count>=2U && spill_count<SPILL_SLOTS &&
       xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_DRAINING)return 0;
    int selected=ready_ru();
    if(selected<0)return 0;
    uint32_t base=(ru_first_block[selected]/BLOCKS_PER_RU)*RU_BLOCKS;
    uint32_t low=base/1024U,high=(base+RU_BLOCKS-1U)/1024U;
    uint32_t start=base,end=base+RU_BLOCKS;
    if(low!=high){
        uint32_t boundary=(low+1U)*1024U;
        if(ru_parts[selected]&1U)start=boundary;else end=boundary;
    }
    fixed_fallback=1U;
    return fixed_select_span(start,end-start);
#endif
}
#endif

#if XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
static void grid16_release_pending(void)
{
    /* Snapshot-and-clear atomically against BTC's OR. Provider callbacks may
     * take time; all release work remains outside this constant-size section. */
    uint32_t key=__get_PRIMASK();__disable_irq();
    uint8_t pending=grid16.release_pending;grid16.release_pending=0U;
    __DMB();__set_PRIMASK(key);
    if(!pending)return;
    /* BTC proves IDMA no longer reads this group.  Release remains foreground
     * work because the provider may return ownership to another queue. */
    for(uint32_t owner=0U;owner<XE_NP_NP2_GRID16_GROUPS;owner++){
        uint8_t bit=(uint8_t)(1U<<owner);
        if(pending&bit){
            const uint8_t *aux=grid16.aux[owner];
            if(!aux){fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0x47313601U|owner);return;}
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
            if(grid16.append)
                grid16.release_append(grid16.context,grid16.pending_ticket+owner*BLOCKS_PER_RU,
                                      grid16.first_np_block[owner],aux);
            else
#endif
            {
                if(!grid16.release){fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0x47313601U|owner);return;}
                grid16.release(grid16.context,grid16.first_np_block[owner],aux);
            }
            grid16.aux[owner]=NULL;
        }
    }
}

static int grid16_build_linked_list(void)
{
    uintptr_t head=(uintptr_t)&sd_ll_nodes[0];
    uint32_t bytes=0U;
    if(!grid16.active || grid16.plan.node_count==0U ||
       grid16.plan.node_count>SD_LLI_MAX_NODES)return -1;
    sd_ll.pHeadNode=NULL;sd_ll.pTailNode=NULL;sd_ll.NodesCounter=0U;
    sd_ll_node_index=sd_ll_bytes_done=sd_ll_retired_rus=0U;sd_ll_fault=0U;
    XE_NP_Np2Grid16Idma_Begin(&grid16.plan,&grid16.idma);
    for(uint32_t n=0U;n<grid16.plan.node_count;n++){
        const XE_NP_Np2Grid16IdmaNode *src=&grid16.plan.node[n];
        uintptr_t address;
        if(src->owner>=grid16.plan.owner_count || !src->bytes || (src->bytes&511U))return -1;
        if(src->kind==XE_NP_NP2_GRID16_KIND_NN)
            address=(uintptr_t)ru[grid16.slots[src->owner]]+src->source_offset;
        else if(src->kind==XE_NP_NP2_GRID16_KIND_AUX)
            address=(uintptr_t)grid16.aux[src->owner]+src->source_offset;
        else return -1;
        if((address&31U) || clean((void *)address,src->bytes))return -1;
        SD_DMALinkNodeTypeDef *entry=&sd_ll_nodes[n];
        entry->IDMABASER=(uint32_t)address;entry->IDMABSIZE=src->bytes;
        entry->IDMALAR=SDMMC_IDMALAR_ULS|SDMMC_IDMALAR_ABR;
#if XE_NP_NP2_LIVE_SD_NATIVE_MODEL
        entry->buffer=resolve_dma_address((uint32_t)address);
        if(!entry->buffer)return -1;
        entry->bytes=src->bytes;entry->next=NULL;
#endif
        if(n){
            uintptr_t current=(uintptr_t)entry;
            if(current<=head || current-head>SDMMC_IDMALAR_IDMALA)return -1;
            sd_ll_nodes[n-1U].IDMALAR|=SDMMC_IDMALAR_ULA|(uint32_t)(current-head);
#if XE_NP_NP2_LIVE_SD_NATIVE_MODEL
            sd_ll_nodes[n-1U].next=entry;
#endif
        }
        sd_ll_node_bytes[n]=src->bytes;bytes+=src->bytes;
    }
    if(bytes!=grid16.plan.total_bytes || bytes!=dma_blocks*512U)return -1;
    sd_ll.pHeadNode=&sd_ll_nodes[0];
    sd_ll.pTailNode=&sd_ll_nodes[grid16.plan.node_count-1U];
    sd_ll.NodesCounter=grid16.plan.node_count;
    if(clean(sd_ll_nodes,(uint32_t)sd_ll.NodesCounter*(uint32_t)sizeof(sd_ll_nodes[0])) ||
       clean(&sd_ll,(uint32_t)sizeof(sd_ll)))return -1;
    __DMB();return 0;
}
#endif

static int build_sd_linked_list(uint32_t first_ru,uint32_t units)
{
    uint32_t ru_index=first_ru,remaining=units,total_bytes=0U,node_count=0U;
    uintptr_t head=(uintptr_t)&sd_ll_nodes[0];
    /* Only linked nodes are fetched. BuildNode initializes all three hardware
     * words for each used entry, so clear the list head/tail/count rather than
     * zeroing the full 36-entry reserve on every CMD25. */
    sd_ll.pHeadNode=NULL;sd_ll.pTailNode=NULL;sd_ll.NodesCounter=0U;
    sd_ll_node_index=sd_ll_bytes_done=sd_ll_retired_rus=0U;
    sd_ll_fault=0U;
    while(remaining){
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
        ru_index=sd_physical_slot(units-remaining);
#endif
#if XE_NP_NP2_LIVE_SD_DIRECT
        uint32_t bank_units=(ru_index==12U)?1U:4U-(ru_index&3U);
        if(bank_units>remaining)bank_units=remaining;
#else
        /* Three IDMA nodes per copied RU. A descriptor completion at the
         * third node proves that RU is no longer read, even while CMD25 or
         * card programming continues. Never join adjacent RUs in one node. */
        uint32_t bank_units=1U;
#if !XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
        if(clean(ru[ru_index],RU_BYTES))return -1;
#endif
#endif
        uintptr_t address=(uintptr_t)
#if VSC_PSRAM_IDMA
            (dma_external[units-remaining]?spill_address(ru_index):ru[ru_index]);
#else
            ru[ru_index];
#endif
        uint32_t bank_bytes=bank_units*RU_BYTES;
#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
        uint32_t fragment=units-remaining;
        address+=dma_offset[fragment];bank_bytes=dma_block_count[fragment]*512U;
#if VSC_PSRAM_IDMA
        /* C14 owns cache-clean/invalidate BEFORE writing the external RU.
         * A late clean here could write stale CPU lines over completed DMA. */
        if(!dma_external[fragment]){
            xe_np_np2_live_sd_perf.clean_calls++;
            if(clean((void *)address,bank_bytes))return -1;
        }
#else
        if(clean((void *)address,bank_bytes))return -1;
#endif
#endif
        while(bank_bytes){
            uint32_t bytes=bank_bytes>SD_LLI_MAX_BYTES?SD_LLI_MAX_BYTES:bank_bytes;
            uint32_t node=node_count;
            if(node>=SD_LLI_MAX_NODES || (address&31U) || (bytes&511U))return -1;
            SD_DMALinkNodeTypeDef *entry=&sd_ll_nodes[node];
            entry->IDMABASER=(uint32_t)address;
            entry->IDMABSIZE=bytes;
            entry->IDMALAR=SDMMC_IDMALAR_ULS|SDMMC_IDMALAR_ABR;
#if XE_NP_NP2_LIVE_SD_NATIVE_MODEL
            entry->buffer=resolve_dma_address((uint32_t)address);
            if(!entry->buffer)return -1;
            entry->bytes=bytes;entry->next=NULL;
#endif
            if(node){
                uintptr_t current=(uintptr_t)entry;
                if(current<=head || current-head>SDMMC_IDMALAR_IDMALA)return -1;
                sd_ll_nodes[node-1U].IDMALAR|=SDMMC_IDMALAR_ULA|(uint32_t)(current-head);
#if XE_NP_NP2_LIVE_SD_NATIVE_MODEL
                sd_ll_nodes[node-1U].next=entry;
#endif
            }
            node_count++;
            sd_ll_node_bytes[node]=bytes;
            address+=bytes;bank_bytes-=bytes;total_bytes+=bytes;
        }
        remaining-=bank_units;
        ru_index=(ru_index+bank_units)%RU_COUNT;
    }
    if(!node_count || total_bytes!=
#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
       dma_blocks*512U
#else
       units*RU_BYTES
#endif
       )return -1;
    sd_ll.pHeadNode=&sd_ll_nodes[0];sd_ll.pTailNode=&sd_ll_nodes[node_count-1U];
    sd_ll.NodesCounter=node_count;
    if(clean(sd_ll_nodes,(uint32_t)sd_ll.NodesCounter*(uint32_t)sizeof(sd_ll_nodes[0])) ||
       clean(&sd_ll,(uint32_t)sizeof(sd_ll)))return -1;
    __DMB();
    return 0;
}

#if XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
#include "xe_np_np2_copied_counted_window.inc"
#endif

#if XE_NP_NP2_LIVE_SD_ROLLING_CMD25
/* One ordered descriptor triplet per RU. Later RUs are held at ABR=0 until
 * their direct PSSI/SPI source RU is sealed; the first node is the gate. */
static int build_rolling_linked_list(uint32_t first_ru,uint32_t units,uint32_t prime)
{
    uint32_t node_count=0U,total_bytes=0U;
    uintptr_t head=(uintptr_t)&sd_ll_nodes[0];
    sd_ll.pHeadNode=NULL;sd_ll.pTailNode=NULL;sd_ll.NodesCounter=0U;
    sd_ll_node_index=sd_ll_bytes_done=sd_ll_retired_rus=0U;
    sd_ll_fault=0U;
    for(uint32_t unit=0U;unit<units;unit++){
        uint32_t address=(uint32_t)(uintptr_t)ru[(first_ru+unit)%RU_COUNT];
        uint32_t left=RU_BYTES;
        while(left){
            uint32_t bytes=left>SD_LLI_MAX_BYTES?SD_LLI_MAX_BYTES:left;
            if(node_count>=SD_LLI_MAX_NODES || (address&31U) || (bytes&511U))return -1;
            SD_DMALinkNodeTypeDef *entry=&sd_ll_nodes[node_count];
            entry->IDMABASER=address;
            entry->IDMABSIZE=bytes;
            entry->IDMALAR=SDMMC_IDMALAR_ULS|
                (unit<prime?SDMMC_IDMALAR_ABR:0U);
            if(node_count){
                uintptr_t current=(uintptr_t)entry;
                if(current<=head || current-head>SDMMC_IDMALAR_IDMALA)return -1;
                sd_ll_nodes[node_count-1U].IDMALAR|=
                    SDMMC_IDMALAR_ULA|(uint32_t)(current-head);
            }
            sd_ll_node_bytes[node_count++]=bytes;
            address+=bytes;left-=bytes;total_bytes+=bytes;
        }
    }
    if(node_count!=units*3U || total_bytes!=units*RU_BYTES)return -1;
    sd_ll.pHeadNode=&sd_ll_nodes[0];sd_ll.pTailNode=&sd_ll_nodes[node_count-1U];
    sd_ll.NodesCounter=node_count;
    if(clean(sd_ll_nodes,node_count*(uint32_t)sizeof(sd_ll_nodes[0])) ||
       clean(&sd_ll,(uint32_t)sizeof(sd_ll)))return -1;
    __DMB();return 0;
}

static void publish_rolling_ready(void)
{
    while(rolling_published_rus<dma_units){
        uint32_t unit=rolling_published_rus;
        uint32_t physical=(dma_ru+unit)%RU_COUNT;
        if(ru_state[physical]!=RU_READY)return;
        if(ru_first_block[physical]!=
           (xe_np_np2_live_sd_mailbox.written_rus+unit)*BLOCKS_PER_RU){
            fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xDA50U|physical);return;
        }
        ru_state[physical]=RU_DMA;
        uint32_t first=unit*3U;
        sd_ll_nodes[first+1U].IDMALAR|=SDMMC_IDMALAR_ABR;
        sd_ll_nodes[first+2U].IDMALAR|=SDMMC_IDMALAR_ABR;
        if(clean(&sd_ll_nodes[first+1U],2U*(uint32_t)sizeof(sd_ll_nodes[0]))){
            fail(XE_NP_NP2_LIVE_SD_ERROR_CACHE,0xDA51U);return;
        }
        __DMB();
        sd_ll_nodes[first].IDMALAR|=SDMMC_IDMALAR_ABR;
        if(clean(&sd_ll_nodes[first],(uint32_t)sizeof(sd_ll_nodes[0]))){
            fail(XE_NP_NP2_LIVE_SD_ERROR_CACHE,0xDA52U);return;
        }
        __DMB();rolling_published_rus=unit+1U;
    }
}
#endif

/* The source buffer is reusable once IDMA has consumed it, which can precede
 * card busy completion. Release complete RUs at descriptor boundaries only. */
static void retire_linked_list_bytes(uint32_t irq_started)
{
    uint32_t node=(uint32_t)sd_ll_node_index;
    if(node>=sd_ll.NodesCounter){sd_ll_fault=1U;return;}
#if XE_NP_NP2_LIVE_SD_IDMA_GAP_DIAG
    uint32_t gap=irq_started-sd_ll_last_node_cycles;
    uint32_t dcount=card->Instance->DCOUNT;
    xe_np_np2_sd_idma_gap_diag[2]++;
    if(gap>xe_np_np2_sd_idma_gap_diag[3]){
        xe_np_np2_sd_idma_gap_diag[3]=gap;
        xe_np_np2_sd_idma_gap_diag[4]=write_lba;
        xe_np_np2_sd_idma_gap_diag[5]=node;
        xe_np_np2_sd_idma_gap_diag[6]=dcount;
        xe_np_np2_sd_idma_gap_diag[7]=irq_started-write_started;
        xe_np_np2_sd_idma_gap_diag[8]=sd_ll_last_node_dcount;
    }
    if(node==0U && gap>xe_np_np2_sd_idma_gap_diag[9])
        xe_np_np2_sd_idma_gap_diag[9]=gap;
    sd_ll_last_node_cycles=irq_started;
    sd_ll_last_node_dcount=dcount;
#else
    (void)irq_started;
#endif
    uint32_t completed=sd_ll_bytes_done+sd_ll_node_bytes[node];
    sd_ll_bytes_done=completed;sd_ll_node_index=node+1U;
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
    if(grid16.active){
        uint32_t owner=UINT32_MAX;
        if(completed>grid16.plan.total_bytes ||
           XE_NP_Np2Grid16Idma_Btc(&grid16.plan,&grid16.idma,node,&owner)<0){
            sd_ll_fault=1U;return;
        }
        if(owner!=UINT32_MAX){
            uint32_t slot=grid16.slots[owner];
            if(slot>=RU_COUNT || ru_state[slot]!=RU_DMA ||
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
               (!grid16.append &&
#endif
               grid16.first_np_block[owner]!=(xe_np_np2_live_sd_mailbox.written_rus+owner)*BLOCKS_PER_RU
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
               )
#endif
               || ru_first_block[slot]!=grid16.first_np_block[owner]){
                sd_ll_fault=1U;return;
            }
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
            /* Final owner AUX BTC attests no further NN/AUX RAM reads. Keep
             * command identity and durability separate from reusable storage. */
            grid16.restored_pending&=(uint8_t)~(1U<<owner);
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
            overflow_restored_mask&=(uint16_t)~(1U<<slot);
#endif
#endif
            __DMB();ru_state[slot]=RU_FREE;
            grid16.release_pending|=(uint8_t)(1U<<owner);
        }
        uint32_t retired=0U;
        for(uint32_t i=0U;i<grid16.plan.owner_count;i++)
            retired+=(grid16.idma.source_retired_mask&(1U<<i))!=0U;
        __DMB();sd_ll_retired_rus=retired;
        return;
    }
#endif
#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
    if(completed>dma_blocks*512U){sd_ll_fault=1U;return;}
    uint32_t units=(uint32_t)sd_ll_retired_rus;
    while(units<dma_units && completed>=sd_ll_fragment_end[units]){
#if XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
        if(copied_window.active && units>=copied_window.published){sd_ll_fault=1U;return;}
#endif
        uint32_t slot=sd_physical_slot(units);
#if VSC_PSRAM_IDMA
        if(dma_external[units]){
            if(slot>=SPILL_SLOTS || spill_sequence[slot]!=dma_generation[units] ||
               (overflow_kind==1U && slot==spill_head)){
                sd_ll_fault=1U;return;
            }
            /* IDMA consumption is not external durability or FIFO release. */
            units++;continue;
        }
#endif
        if(ru_state[slot]!=RU_DMA || ru_first_block[slot]!=dma_generation[units]){
            sd_ll_fault=1U;return;
        }
        if(dma_complete_mask&(1U<<units)){
            ru_state[slot]=RU_FREE;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
            if(SESSION_RUNTIME_DIRECT && slot<NP2_RUNTIME_DIRECT_CAPTURE_RUS)
                runtime_direct_retire_pending=1U;
#endif
        }
        units++;
    }
    __DMB();sd_ll_retired_rus=units;
#else
    uint32_t units=completed/RU_BYTES;
    if(units>dma_units){sd_ll_fault=1U;return;}
    uint32_t retired=(uint32_t)sd_ll_retired_rus;
#if XE_NP_NP2_STAGED_CAPTURE
    if(units<sd_ll_consumed_rus){sd_ll_fault=1U;return;}
    __DMB();sd_ll_consumed_rus=units;
#else
    if(units<=retired)return;
    for(uint32_t i=retired;i<units;i++)
        if(ru_state[sd_physical_slot(i)]!=RU_DMA){sd_ll_fault=1U;return;}
    uint32_t end_ru=xe_np_np2_live_sd_mailbox.written_rus+units;
#if XE_NP_NP2_LIVE_SD_DIRECT && !XE_NP_NP2_LIVE_SD_ROLLING_SYNTHETIC
    if(XE_NP_Np2CapturePort_DirectRetireRUs(end_ru)){sd_ll_fault=1U;return;}
#else
    (void)end_ru;
#endif
    for(uint32_t i=retired;i<units;i++)ru_state[sd_physical_slot(i)]=RU_FREE;
    __DMB();sd_ll_retired_rus=units;
#endif
#endif
}
#endif

#if XE_NP_NP2_LIVE_SD_VSC_TEST
static int begin_vsc_command(uint32_t argument,uint32_t timeout_ms)
{
    if(!card_idle() || vsc_command_begin(&vsc_command,card->Instance,argument,
                                          HAL_GetTick(),timeout_ms))return -1;
    xe_np_np2_live_vsc_diag[4]++;xe_np_np2_live_vsc_diag[5]=argument;
    return 0;
}
static int poll_vsc_command(void)
{
    int result=vsc_command_service(&vsc_command,card->Instance,card->SdCard.RelCardAdd,HAL_GetTick());
    if(result){
        xe_np_np2_live_vsc_diag[6]=vsc_command.response;
        xe_np_np2_live_vsc_diag[7]=vsc_command.error;
        maximum(&xe_np_np2_live_vsc_diag[9],HAL_GetTick()-vsc_command.started_ms);
    }
    return result;
}
/* Cold/renewal only: register no more than the rounded owned payload extent.
 * The planned boundary grants no write permission until stage3 confirms it. */
static int begin_vsc_free_aus(uint32_t start)
{
    if(!vsc_au_blocks || start>=record_end_lba)return -1;
    uint32_t aus=(uint32_t)(((uint64_t)record_end_lba-start+vsc_au_blocks-1U)/vsc_au_blocks);
    if(aus>XE_NP_NP2_LIVE_SD_VSC_BUNDLE_AUS_TEST)aus=XE_NP_NP2_LIVE_SD_VSC_BUNDLE_AUS_TEST;
    uint64_t blocks=(uint64_t)aus*vsc_au_blocks;
    uint32_t argument;
    if(blocks>UINT32_MAX ||
       XE_NP_SdVscFreeAuArgument(start,(uint32_t)blocks,vsc_au_blocks,
                                card->SdCard.LogBlockNbr,&argument) ||
       begin_vsc_command(argument,350U))return -1;
    vsc_au_end=start+(uint32_t)blocks;
    return 0;
}
/* Initial SetFreeAU/Start runs before producer->arm. An AU renewal is issued
 * only after the previous AU's last counted write is card-confirmed. */
static int service_vsc(void)
{
    if(vsc_stage==3U)return 1;
#if XE_NP_NP2_SD_PROFILE_CLASSIC_TEST
    if(!SESSION_VSC){
        if(dma_active || overflow_kind || XE_NP_Np2CapturePort_Armed())return -1;
        if(!vsc_command.phase){
            if(begin_vsc_command(0U,1250U))return -1;
            vsc_stage=2U;xe_np_np2_live_vsc_diag[3]=vsc_stage;return 0;
        }
        int result=poll_vsc_command();
        if(result>0){vsc_stage=3U;xe_np_np2_live_vsc_diag[3]=vsc_stage;}
        return result;
    }
#endif
    if(vsc_stage==0U){
        if(begin_vsc_free_aus(record_start_lba))return -1;
        vsc_stage=1U;xe_np_np2_live_vsc_diag[3]=vsc_stage;return 0;
    }
    int result=poll_vsc_command();
    if(result<=0)return result;
    if(vsc_stage==1U){
        if(begin_vsc_command(0x08000000U,1250U))return -1;
        vsc_stage=2U;xe_np_np2_live_vsc_diag[3]=vsc_stage;return 0;
    }
    if(vsc_stage==2U || vsc_stage==4U){
#if XE_NP_NP2_SD_PROFILE_CLASSIC_TEST
        if(vsc_stage==2U)vsc_recording_entered=1U;
#endif
        vsc_stage=3U;xe_np_np2_live_vsc_diag[3]=vsc_stage;return 1;
    }
    return -1;
}
/* End/cancel only. Finish an owned command without replaying it; release the
 * registered DIR before readback or footer writes. No capture is armed here. */
static int close_vsc(void)
{
    if(vsc_stage==7U)return 1;
    if(vsc_command.phase && vsc_command.phase!=5U){
        int result=poll_vsc_command();if(result<=0)return result;
#if XE_NP_NP2_SD_PROFILE_CLASSIC_TEST
        if(SESSION_VSC && vsc_stage==2U)vsc_recording_entered=1U;
#endif
    }
#if XE_NP_NP2_SD_PROFILE_CLASSIC_TEST
    if(!SESSION_VSC || vsc_stage==8U){
        vsc_recording_entered=0U;
        vsc_stage=7U;xe_np_np2_live_vsc_diag[3]=vsc_stage;return 1;
    }
    if(vsc_stage==6U && vsc_recording_entered){
        /* ReleaseDIR clears a slot, not the VSC recording period. Suspend
         * after the last data owner and before verification/metadata. */
        if(begin_vsc_command(0x58000000U,350U))return -1;
        vsc_stage=8U;xe_np_np2_live_vsc_diag[3]=vsc_stage;return 0;
    }
#endif
    if(vsc_stage==6U){vsc_stage=7U;xe_np_np2_live_vsc_diag[3]=vsc_stage;return 1;}
    if(begin_vsc_command(0x88000000U,150U))return -1;
    vsc_stage=6U;xe_np_np2_live_vsc_diag[3]=vsc_stage;return 0;
}
#endif

#if XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_TEST
static int spill_bus_fence_blocks_sd(void)
{
    /* Finish the whole copy owner, not just its current leg. Otherwise the
     * next leg can be stranded behind an accepted external CMD25 window. */
    return dma_window_external && (overflow_kind || spill_dma_bytes ||
                                   (GPDMA1_Channel14->CCR&DMA_CCR_EN));
}
static int spill_bus_fence_prefers_spill(void)
{
    if(!dma_window_external || dma_active ||
       xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_CAPTURING ||
       xe_np_np2_live_sd_mailbox.produced_blocks>=active_target_blocks ||
       spill_count>=SPILL_SLOTS)return 0;
    uint32_t free_count=0U,eligible=0U;
    uint32_t last=spill_count?spill_sequence[(spill_head+SPILL_SLOTS-1U)%SPILL_SLOTS]:0U;
    for(uint32_t i=0U;i<RU_COUNT;i++){
        free_count+=ru_state[i]==RU_FREE;
        eligible|=ru_state[i]==RU_READY && !(overflow_restored_mask&(1U<<i)) &&
                  (!spill_count || ru_first_block[i]>last);
    }
    /* Preserve service_overflow's existing <=2 FREE admission and FIFO-full
     * escape. Returning gives that shared scheduler a turn, never waits here. */
    if(free_count>2U || !eligible)return 0;
    const uint64_t source_ru=(uint64_t)BLOCKS_PER_RU*STREAM_TICKS;
    uint64_t ingress=free_count*source_ru;
    if(fill_ru<RU_COUNT && ru_state[fill_ru]==RU_FILLING){
        uint64_t filled=(uint64_t)fill_blocks*STREAM_TICKS+partial_ticks;
        if(fill_blocks>=BLOCKS_PER_RU || partial_ticks>=STREAM_TICKS || filled>=source_ru){
            fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD928U);return 1;
        }
        ingress+=source_ru-filled;
    }
    uint64_t latest=0U;
    if(copy_cost_status(&latest)!=0 || latest<next_tick){
        fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,1U);return 1;
    }
    /* The closed packed-dual profile consumes one raw byte per source tick.
     * next_tick includes only released spans, including partial packed blocks.
     * Retention equality is terminal, not extra staging capacity. */
    const uint64_t raw_limit=XE_NP_NP2_RETENTION_LIMIT-XE_NP_NP2_UNPUBLISHED_BOUND;
    uint64_t retained=latest-next_tick;
    if(retained>=raw_limit){fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,1U);return 1;}
    ingress+=raw_limit-retained;
    /* One full source RU plus an actual publication quantum, not a FREE-slot
     * guess or a card-latency guarantee. No reserve owner/state is introduced. */
    return ingress<=source_ru+XE_NP_NP2_EVENT_BYTES;
}
#endif

/* CMD25 preparation is shared by classic and Grid16. Counts are physical
 * sectors, including AUX. An acknowledged CMD23 alone enables no-CMD12. */
static int prepare_write_commands(uint32_t blocks)
{
    (void)blocks;
#if XE_NP_NP2_LIVE_SD_COUNTED_WRITES
    /* A failed new hint/count must never inherit a previous command receipt. */
    counted_write_active=0U;
#endif
#if XE_NP_NP2_LIVE_SD_PREERASE_HINT && !XE_NP_NP2_LIVE_SD_SKIP_BATCH_HINT_TEST && \
    (!XE_NP_NP2_LIVE_SD_VSC_TEST || XE_NP_NP2_SD_PROFILE_CLASSIC_TEST)
    if(!SESSION_VSC){
    /* CMD55 + command 23 is ACMD23, a hint for the following CMD25, not
     * CMD23's predefined-count transfer. CMD12 remains unless counted
     * writes are separately enabled and their count command succeeds.
     * Hint exactly this batch; never pre-erase beyond the reserved extent. */
    uint32_t hint_error=SDMMC_CmdAppCommand(card->Instance,card->SdCard.RelCardAdd<<16U);
    if(!hint_error)hint_error=SDMMC_CmdBlockCount(card->Instance,blocks);
    if(hint_error){card->ErrorCode=hint_error;return -1;}
    }
#endif
#if XE_NP_NP2_LIVE_SD_COUNTED_WRITES
    if(counted_writes_enabled
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
       && !grid16.requested
#endif
       ){
        uint32_t count_error=SDMMC_CmdBlockCount(card->Instance,blocks);
        if(count_error){
            if(counted_write_cmd23_unsupported(count_error)){
                counted_writes_enabled=0U;
                xe_np_np2_live_sd_perf.counted_write_fallbacks++;
            }else{
                card->ErrorCode=count_error;
                return -1;
            }
        }else{
            counted_write_active=1U;
            xe_np_np2_live_sd_perf.counted_write_batches++;
        }
    }
#endif
    return 0;
}

#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
static void grid16_release_acquired(uint32_t first_ru,uint32_t count)
{
    for(uint32_t owner=0U;owner<count;owner++){
        const uint8_t *aux=grid16.aux[owner];
        if(aux && grid16.release)
            grid16.release(grid16.context,(first_ru+owner)*BLOCKS_PER_RU,aux);
        grid16.aux[owner]=NULL;
    }
}

static int grid16_aux_valid(const uint8_t *aux,uint32_t owner)
{
    uintptr_t start=(uintptr_t)aux,end=start+(uintptr_t)grid16.aux_sectors*512U;
    if(!aux || (start&31U) || end<=start)return 0;
    for(uint32_t i=0U;i<RU_COUNT;i++){
        uintptr_t base=(uintptr_t)ru[i];
        if(start<base+RU_BYTES && end>base)return 0;
    }
    for(uint32_t i=0U;i<owner;i++){
        uintptr_t other=(uintptr_t)grid16.aux[i];
        if(other && start<other+(uintptr_t)grid16.aux_sectors*512U && end>other)return 0;
    }
    return 1;
}

#include "xe_np_np2_grid16_append.inc"

/* Return the first missing future group after the immutable accepted command
 * and a bounded resident READY prefix. No future BTC/free credit is implied. */
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
static int grid16_restore_prefix(uint32_t *sequence,uint32_t *ready)
{
    uint32_t first=xe_np_np2_live_sd_mailbox.written_rus,count=0U;
    if(first>active_target_rus)return -1;
    if(dma_active){
        if(!grid16.active || !dma_units || dma_units>XE_NP_NP2_GRID16_GROUPS ||
           dma_units>active_target_rus-first || grid16.first_np_block[0]!=first*BLOCKS_PER_RU)return -1;
        first+=dma_units;
    }
    while(count<XE_NP_NP2_GRID16_GROUPS && first+count<active_target_rus &&
          ready_sequence((first+count)*BLOCKS_PER_RU)>=0)count++;
    *sequence=(first+count)*BLOCKS_PER_RU;*ready=count;return 0;
}
#endif
/* Ordered classic only: no PSRAM/VSC/fixed-window selection is consulted.
 * A group is claimed only after every NN RU and its sealed auxiliary span are
 * available, so the normal writer never sees an auxiliary LBA as NN payload. */
static void grid16_launch(uint32_t groups)
{
    grid16.active=1U;dma_units=(uint8_t)groups;
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
    grid16.restored_pending=0U;
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
    for(uint32_t owner=0U;owner<groups;owner++)
        if(overflow_restored_mask&(1U<<grid16.slots[owner]))grid16.restored_pending|=(uint8_t)(1U<<owner);
#endif
#endif
    dma_blocks=grid16.plan.total_sectors;write_lba=grid16.plan.first_lba;
    if(grid16_build_linked_list()){
        grid16.active=0U;
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
        if(!grid16.append)
#endif
        grid16_release_acquired(xe_np_np2_live_sd_mailbox.written_rus,groups);
        fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0x47313611U);return;
    }
    for(uint32_t owner=0U;owner<groups;owner++)ru_state[grid16.slots[owner]]=RU_DMA;
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
    grid16.pending=0U;
#endif
    dma_active=1U;dma_buffer_released=0U;
    irq_dataend_seen=irq_return_seen=irq_service_observed=0U;
    write_started=cycles();write_dataend=0U;write_started_ms=HAL_GetTick();
    status_poll_cycles=write_started-STATUS_POLL_CYCLES;card->ErrorCode=HAL_SD_ERROR_NONE;
    if(prepare_write_commands(dma_blocks)){
        fail(XE_NP_NP2_LIVE_SD_ERROR_WRITE_START,write_lba);return;
    }
    __HAL_SD_DISABLE_IT(card,SDMMC_IT_DCRCFAIL|SDMMC_IT_DTIMEOUT|SDMMC_IT_TXUNDERR|
                             SDMMC_IT_DATAEND|SDMMC_IT_IDMABTC);
    __HAL_SD_CLEAR_FLAG(card,SDMMC_STATIC_FLAGS);__DMB();
    if(HAL_SDEx_DMALinkedList_WriteBlocks(card,&sd_ll,write_lba,dma_blocks)!=HAL_OK){
        /* Keep NN/AUX ownership until fail() attempts native abort. A failed
         * HAL start is not proof that IDMA never accepted the buffers. */
        fail(XE_NP_NP2_LIVE_SD_ERROR_WRITE_START,write_lba);return;
    }
    xe_np_np2_live_sd_perf.clean_calls+=grid16.plan.node_count+2U;
    xe_np_np2_live_sd_perf.write_calls++;
    maximum(&xe_np_np2_live_sd_perf.largest_write_rus,groups);
    maximum(&xe_np_np2_live_sd_mailbox.max_cmd25_setup_cycles,elapsed(write_started));
    launch_wait_change(LAUNCH_WAIT_NONE);
}

static void grid16_start_write(void)
{
    uint32_t first_ru=xe_np_np2_live_sd_mailbox.written_rus;
    uint32_t groups=0U;
    if(!grid16.requested || grid16.active || dma_active || !card_idle())return;
    grid16_release_pending();
    if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED)return;
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
    if(grid16.append){
        int selected=grid16_append_select();
        if(selected<=0)return;
        groups=(uint32_t)selected;
        if(grid16_append_acquire(groups)!=1)return;
        if(XE_NP_Np2Grid16Idma_Build(grid16.physical_confirmed_lba,groups,
            grid16.aux_sectors,&grid16.plan) || grid16.plan.end_lba>record_end_lba){
            fail(XE_NP_NP2_LIVE_SD_ERROR_RANGE,0x47415008U);return;
        }
        grid16_launch(groups);return;
    }
#endif
    while(groups<XE_NP_NP2_GRID16_GROUPS && first_ru+groups<active_target_rus){
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
        /* A later resident RU can never overtake an older FIFO generation. */
        if(spill_count){
            if(spill_count>SPILL_SLOTS || spill_tail>=SPILL_SLOTS || spill_head>=SPILL_SLOTS ||
               spill_sequence[spill_tail]<first_ru*BLOCKS_PER_RU){
                fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0x47313631U);return;
            }
            if(spill_sequence[spill_tail]<=(first_ru+groups)*BLOCKS_PER_RU)break;
        }
#endif
        int slot=ready_sequence((first_ru+groups)*BLOCKS_PER_RU);
        if(slot<0 || ru_state[(uint32_t)slot]!=RU_READY ||
           ru_first_block[(uint32_t)slot]!=(first_ru+groups)*BLOCKS_PER_RU)break;
        grid16.slots[groups]=(uint8_t)slot;groups++;
    }
    if(!groups){launch_wait_change(LAUNCH_WAIT_NO_READY);return;}
    /* The final reserved AUX span must be acquired only after source Stop has
     * sealed its accepted partial grid batch. Cover every eager launch caller,
     * including service_overflow; the normal target-ready path stops NP first
     * and re-enters here in DRAINING without inventing a cutoff ordinal. */
    if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_CAPTURING &&
       first_ru+groups==active_target_rus)return;
    if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_CAPTURING &&
       groups<XE_NP_NP2_GRID16_GROUPS && first_ru+groups<active_target_rus){
        uint32_t free_count=0U;
        for(uint32_t i=0U;i<RU_COUNT;i++)free_count+=ru_state[i]==RU_FREE;
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
        uint32_t next=(first_ru+groups)*BLOCKS_PER_RU;
        /* At near-full FIFO, let a second exact FIFO owner reach a real FREE
         * slot before launching the short prefix. Do not wait for BTC credit. */
        if(spill_count>=SPILL_SLOTS-2U && free_count<=1U &&
           ((overflow_kind==2U && grid16.copy_sequence==next) ||
            (!overflow_kind && free_count==1U && spill_sequence[spill_tail]==next)))return;
        /* With only one original FREE slot, restore consumes it. Before
         * launching that singleton, evacuate an actually eligible FIFO-tail
         * successor to create a second real slot. Never wait when FIFO is
         * full or when no exact append owner exists. */
        if(spill_count>=SPILL_SLOTS-2U && spill_count<SPILL_SLOTS &&
           free_count==0U && groups==1U){
            uint32_t last=spill_sequence[(spill_head+SPILL_SLOTS-1U)%SPILL_SLOTS];
            if(last<=UINT32_MAX-BLOCKS_PER_RU){
                if(overflow_kind==1U && grid16.copy_sequence==last+BLOCKS_PER_RU)return;
                if(!overflow_kind)for(uint32_t i=0U;i<RU_COUNT;i++)
                    if(ru_state[i]==RU_READY && ru_first_block[i]>first_ru*BLOCKS_PER_RU &&
                       ru_first_block[i]<active_target_blocks &&
                       ru_first_block[i]==last+BLOCKS_PER_RU &&
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
                       !(overflow_restored_mask&(1U<<i)) &&
#endif
#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
                       !ru_parts[i] &&
#endif
                       1)return;
            }
        }
        /* Coalesce only queued/in-progress exact FIFO work with real ingress
         * headroom. Pressure, Stop and a final tail always launch available. */
        if(free_count>=2U &&
           ((overflow_kind==2U && grid16.copy_sequence==next) ||
            (!overflow_kind && spill_count && spill_sequence[spill_tail]==next)))return;
        /* No FIFO/C14 owner: allow a short direct prefix to fill naturally,
         * bounded by four groups and the existing two-FREE retention margin. */
        if(!spill_count && !overflow_kind && free_count>=3U)return;
#else
        if(free_count>=3U)return;
#endif
    }
    if(XE_NP_Np2Grid16Idma_Build(grid16.physical_confirmed_lba,groups,
                                  grid16.aux_sectors,&grid16.plan) ||
       grid16.plan.end_lba>record_end_lba){
        fail(XE_NP_NP2_LIVE_SD_ERROR_RANGE,0x47313610U);return;
    }
    for(uint32_t owner=0U;owner<groups;owner++){
        const uint8_t *aux=grid16.acquire(grid16.context,
            (first_ru+owner)*BLOCKS_PER_RU,grid16.aux_sectors);
        if(!grid16_aux_valid(aux,owner)){
            grid16_release_acquired(first_ru,owner);
            launch_wait_change(LAUNCH_WAIT_BELOW_MIN);return;
        }
        grid16.aux[owner]=aux;
        grid16.first_np_block[owner]=(first_ru+owner)*BLOCKS_PER_RU;
    }
    grid16_launch(groups);
}
#endif

static void start_write(void)
{
#if XE_NP_NP2_LIVE_SD_SPILL_HOLD_TEST
    /* One common launch gate also covers service_overflow's opportunistic
     * caller. Return before selecting/claiming any SD owner; capture/C14 and
     * existing service_write retirement remain independently serviced. */
    if(spill_hold_defer(HAL_GetTick(),xe_np_np2_live_sd_mailbox.state,
        xe_np_np2_live_sd_perf.completed_calls,dma_active,
        (uint32_t)(card_idle() && !(card->Instance->STA&SDMMC_STA_BUSYD0)),
        xe_np_np2_live_sd_mailbox.produced_blocks,xe_np_np2_live_sd_mailbox.written_rus))return;
#endif
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
    if(grid16.requested){grid16_start_write();return;}
#endif
#if XE_NP_NP2_LIVE_SD_VSC_TEST
    if(vsc_stage!=3U)return;
    if(SESSION_VSC && !dma_active && record_start_lba+fixed_confirmed_blocks==vsc_au_end &&
       fixed_confirmed_blocks<active_target_rus*RU_BLOCKS){
        if(begin_vsc_free_aus(vsc_au_end)){
            fail(XE_NP_NP2_LIVE_SD_ERROR_WRITE_START,0x56530001U);return;
        }
        vsc_stage=4U;xe_np_np2_live_vsc_diag[3]=vsc_stage;
        xe_np_np2_live_vsc_diag[8]++;return;
    }
#endif
#if !XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST
    int selected=-1;
    if(!SESSION_PSRAM_IDMA){
        selected=ready_ru();
        if(selected<0){launch_wait_change(LAUNCH_WAIT_NO_READY);return;}
    }
#endif
    if(!card_idle()){launch_wait_change(LAUNCH_WAIT_CARD_NOT_IDLE);return;}
#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
    if(!select_fixed_write()){launch_wait_change(LAUNCH_WAIT_BELOW_MIN);return;}
#if XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_TEST
    /* Selection only describes immutable sources. Defer before claiming RU
     * owners, cache/node setup or CMD25; foreground still retires C14/capture. */
    if(spill_bus_fence_blocks_sd()){
#if XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_DIAG_TEST
        spill_bus_fence_refused(1U);
#endif
        return;
    }
    if(spill_bus_fence_prefers_spill())return;
#endif
    uint32_t units=dma_units,first_ru=dma_first_ru;
#elif XE_NP_NP2_STAGED_CAPTURE
#if XE_NP_NP2_STAGED_LONG_CMD25
    uint32_t units=active_target_rus-stage_queue.committed;
    if(units>MAX_WRITE_RUS)units=MAX_WRITE_RUS;
    /* Start after a finite, concurrent source lead. The rest of the command
     * is populated from newly sealed RUs while acquisition keeps running. */
    uint32_t lead=units<MIN_WRITE_RUS?units:MIN_WRITE_RUS;
    uint32_t lead_target=units>=XE_NP2_STAGE_LONG_MAX_RUS?XE_NP_NP2_STAGED_LONG_LEAD_TARGET_RUS:
                         (MAX_WRITE_RUS<=32U?MIN_WRITE_RUS:16U);
    uint32_t threshold=units<lead_target?units:lead_target;
    if(stage_queue.produced-stage_queue.committed<threshold){
        launch_wait_change(LAUNCH_WAIT_BELOW_MIN);return;
    }
    int claimed=XE_Np2StageLong_Begin(&stage_queue,&stage_long_window,units,lead);
    if(claimed<0){fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xDA60U);return;}
    if(!claimed){launch_wait_change(LAUNCH_WAIT_BELOW_MIN);return;}
    dma_ru=(uint8_t)XE_Np2Stage_StorePhysicalRu(stage_long_window.slots[0]);
#else
    uint32_t units=active_target_rus-stage_queue.committed;
    if(units>MAX_WRITE_RUS)units=MAX_WRITE_RUS;
    /* A partial final CMD25 is legal only after acquisition has sealed the
     * last RU. During capture, wait for a complete seven-RU prefix. */
    if(units<MAX_WRITE_RUS && stage_queue.produced!=active_target_rus){
        launch_wait_change(LAUNCH_WAIT_BELOW_MIN);return;
    }
    uint32_t minimum=(stage_queue.produced==active_target_rus)?units:MAX_WRITE_RUS;
    int claimed=XE_Np2Stage_BeginSd(&stage_queue,units,minimum);
    if(claimed<0){fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xDA20U);return;}
    if(!claimed){launch_wait_change(LAUNCH_WAIT_BELOW_MIN);return;}
    units=(uint32_t)claimed;
    dma_ru=(uint8_t)XE_Np2Stage_StorePhysicalRu(stage_queue.sd_slots[0]);
#endif
#else
#if XE_NP_NP2_LIVE_SD_PSRAM_SPILL
    if(ru_first_block[selected]!=xe_np_np2_live_sd_mailbox.written_rus*BLOCKS_PER_RU)return;
#endif
    dma_ru=(uint8_t)selected;
    uint32_t first_ru=xe_np_np2_live_sd_mailbox.written_rus;
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
    first_ru=ru_first_block[selected]/BLOCKS_PER_RU;
    if(ru_first_block[selected]%BLOCKS_PER_RU ||
       first_ru<xe_np_np2_live_sd_mailbox.written_rus ||
       first_ru>=xe_np_np2_live_sd_mailbox.produced_blocks/BLOCKS_PER_RU ||
       first_ru>=active_target_rus){
        fail(XE_NP_NP2_LIVE_SD_ERROR_ARGUMENT,0xD901U);return;
    }
#endif
    uint32_t units=XE_NP_NP2_LIVE_SD_WRITE_CAP_RUS;
#if !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST
    if(units>4U-(dma_ru%4U))units=4U-(dma_ru%4U);
#endif
    if(units>active_target_rus-first_ru)
        units=active_target_rus-first_ru;
    /* Count the sealed, ordered prefix once. Opt-in copied dual may launch
     * the configured one/two-RU minimum, retaining card-latency headroom, then use up
     * to the command cap. Never submit filling memory or logical LBA holes
     * within one command, even when bypassing an older external RU. */
    uint32_t ready_units=0U;
    for(uint32_t i=0U;i<units && i<RU_COUNT;i++) {
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
        int found=ready_sequence((first_ru+i)*BLOCKS_PER_RU);
        if(found<0)break;
        uint32_t index=(uint32_t)found;
        dma_slots[i]=(uint8_t)index;
#else
        uint32_t index=(dma_ru+i)%RU_COUNT;
#endif
        if(ru_state[index]!=RU_READY)break;
        if(ru_first_block[index]!=(first_ru+i)*BLOCKS_PER_RU) {
            fail(XE_NP_NP2_LIVE_SD_ERROR_ARGUMENT,index);return;
        }
        ready_units++;
    }
#if XE_NP_NP2_LIVE_SD_ROLLING_CMD25
    uint32_t prime=units<ROLLING_PRIME_RUS?units:ROLLING_PRIME_RUS;
    if(ready_units<prime){launch_wait_change(LAUNCH_WAIT_BELOW_MIN);return;}
    rolling_published_rus=prime;
#elif XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST && (MAX_WRITE_RUS == 11U || XE_NP_NP2_LIVE_SD_COPIED_DUAL_ADAPTIVE)
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER && XE_NP_NP2_LIVE_SD_COPIED_DUAL_ADAPTIVE && MIN_WRITE_RUS==1U
    /* Grow the latest contiguous group toward the command cap only with ingress
     * headroom. Four free slots leave three after the next filling allocation,
     * above the two-free spill threshold. MAX6 may finish that already-partial
     * sixth with the same three free slots, but not begin another RU. Never wait
     * with external FIFO backlog, behind a sealed hole,
     * prefetched old head, pressure, Stop or the final target RU. */
    if(spill_count==0U && ready_units<units &&
       xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_CAPTURING &&
       !(overflow_restored_mask&(1U<<(uint32_t)selected)) &&
       first_ru+ready_units==xe_np_np2_live_sd_mailbox.produced_blocks/BLOCKS_PER_RU){
        uint32_t free_units=0U;
        for(uint32_t i=0U;i<RU_COUNT;i++)free_units+=ru_state[i]==RU_FREE;
        if(free_units>=4U
#if MAX_WRITE_RUS==6U
           || (free_units==3U && units==6U && ready_units==5U &&
               !overflow_kind && !overflow_restored_mask &&
               fill_ru<RU_COUNT && ru_state[fill_ru]==RU_FILLING &&
               ru_first_block[fill_ru]==(first_ru+ready_units)*BLOCKS_PER_RU &&
               (fill_blocks || partial_ticks) && first_ru+units<active_target_rus)
#endif
           ){launch_wait_change(LAUNCH_WAIT_BELOW_MIN);return;}
    }
#endif
    uint32_t min_ready=(units<MIN_WRITE_RUS)?units:MIN_WRITE_RUS;
    if(ready_units<min_ready){launch_wait_change(LAUNCH_WAIT_BELOW_MIN);return;}
    units=ready_units;
#else
    if(ready_units<units)return;
#endif
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
    dma_first_ru=first_ru;
#if !XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
    write_lba=record_start_lba+first_ru*RU_BLOCKS;
#endif
    xe_np_np2_overflow_order_diag[4]=first_ru;
    xe_np_np2_overflow_order_diag[3]+=first_ru!=xe_np_np2_live_sd_mailbox.written_rus;
#endif
    launch_wait_change(LAUNCH_WAIT_NONE);
    dma_units=(uint8_t)units;
    uint32_t blocks=
#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
        dma_blocks;
#else
        RU_BLOCKS*units;
#endif
#if XE_NP_NP2_LIVE_SD_WRITE_LATENCY_DIAG
    write_start_depth=ring_depth();
#endif
    uint32_t clean_started=cycles();
    int cleaned=0;
#if XE_NP_NP2_LIVE_SD_DIRECT
#if XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST
#if XE_NP_NP2_STAGED_CAPTURE
#if XE_NP_NP2_STAGED_LONG_CMD25
    int node_count=XE_Np2StageLong_BuildNodes(&stage_long_window,stage_ru_base,
        sd_ll_nodes,SD_LLI_MAX_NODES,&sd_ll,sd_ll_node_bytes,cache);
    cleaned=node_count>0?0:-1;
#else
    int node_count=XE_Np2StageSd_BuildNodes(&stage_queue,stage_ru_base,
        sd_ll_nodes,SD_LLI_MAX_NODES,&sd_ll,sd_ll_node_bytes,cache);
    cleaned=node_count>0?0:-1;
#endif
    sd_ll_node_index=sd_ll_bytes_done=sd_ll_retired_rus=sd_ll_consumed_rus=0U;
    sd_ll_fault=0U;
#elif XE_NP_NP2_LIVE_SD_ROLLING_CMD25
    cleaned=build_rolling_linked_list(dma_ru,units,rolling_published_rus);
#else
    cleaned=build_sd_linked_list(dma_ru,units);
#endif
    xe_np_np2_live_sd_perf.clean_calls+=2U;
#else
    /* Immutable placement/non-cacheable bounds were attested before arm. */
    __DMB();
#endif
#elif XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST
#if XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
    if(copied_window.active)cleaned=copied_window_build();
    else
#endif
    cleaned=build_sd_linked_list(dma_ru,units);
#if VSC_PSRAM_IDMA
    xe_np_np2_live_sd_perf.clean_calls+=2U; /* Payload cleans counted in the builder. */
#else
    xe_np_np2_live_sd_perf.clean_calls+=units+2U;
#endif
#else
    cleaned=clean(ru[dma_ru],RU_BYTES*units);
#endif
#if !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST
    xe_np_np2_live_sd_perf.clean_calls++;
#endif
    xe_np_np2_live_sd_perf.clean_cycles+=elapsed(clean_started);
    if(cleaned){
        fail(XE_NP_NP2_LIVE_SD_ERROR_CACHE,dma_ru);return;
    }
#if !XE_NP_NP2_STAGED_CAPTURE
#if XE_NP_NP2_LIVE_SD_ROLLING_CMD25
    for(uint32_t i=0U;i<rolling_published_rus;i++)
        ru_state[(dma_ru+i)%RU_COUNT]=RU_DMA;
#else
#if XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
    if(!copied_window.active)
#endif
    for(uint32_t i=0U;i<units;i++){
#if VSC_PSRAM_IDMA
        if(dma_external[i])continue; /* Counted FIFO ownership pins the source. */
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
        overflow_restored_mask&=(uint16_t)~(1U<<sd_physical_slot(i));
#endif
        ru_state[sd_physical_slot(i)]=RU_DMA;
    }
#endif
#endif
    dma_active=1U;dma_buffer_released=0U;
    irq_dataend_seen=irq_return_seen=irq_service_observed=0U;
    write_started=cycles();write_dataend=0U;
#if XE_NP_NP2_LIVE_SD_IDMA_GAP_DIAG
    sd_ll_last_node_cycles=write_started;
    sd_ll_last_node_dcount=blocks*512U;
#endif
    if(last_write_completed){
        uint32_t gap=write_started-last_write_completed;
        xe_np_np2_live_sd_perf.launch_gap_cycles+=gap;
        maximum(&xe_np_np2_live_sd_perf.max_launch_gap_cycles,gap);
    }
    write_started_ms=HAL_GetTick();status_poll_cycles=write_started-STATUS_POLL_CYCLES;
    card->ErrorCode=HAL_SD_ERROR_NONE;
    if(prepare_write_commands(blocks)){
        fail(XE_NP_NP2_LIVE_SD_ERROR_WRITE_START,write_lba);return;
    }
#if XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST
    uint32_t defer_prior_leg=0U;
    if(dma_window_external && !xe_np_np2_spill_defer_diag[2])
        defer_prior_leg=spill_dma_bytes || (GPDMA1_Channel14->CCR&DMA_CCR_EN);
#endif
#if XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST
    __HAL_SD_DISABLE_IT(card,SDMMC_IT_DCRCFAIL|SDMMC_IT_DTIMEOUT|SDMMC_IT_TXUNDERR|
                             SDMMC_IT_DATAEND|SDMMC_IT_IDMABTC);
    __HAL_SD_CLEAR_FLAG(card,SDMMC_STATIC_FLAGS);
    __DMB();
#if XE_NP_NP2_STAGED_LONG_CMD25
    /* A completed prior command can leave the NVIC line disabled even though
     * the card and HAL are idle. Re-arm only at this command boundary, after
     * stale SD flags are cleared and before the new IDMA transfer starts.
     * Never poll/re-arm in the per-block or foreground service hot path. */
    if(!NVIC_GetEnableIRQ(SDMMC1_IRQn)){
        NVIC_ClearPendingIRQ(SDMMC1_IRQn);
        NVIC_EnableIRQ(SDMMC1_IRQn);
        xe_np_np2_stage_fault_diag[42]++;
        __DSB();
    }
#endif
    if(HAL_SDEx_DMALinkedList_WriteBlocks(card,&sd_ll,write_lba,blocks)!=HAL_OK){
#else
    if(HAL_SD_WriteBlocks_DMA(card,ru[dma_ru],write_lba,blocks)!=HAL_OK){
#endif
        fail(XE_NP_NP2_LIVE_SD_ERROR_WRITE_START,write_lba);return;
    }
#if XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST
    if(dma_window_external)spill_defer_window_started(defer_prior_leg);
#endif
    maximum(&xe_np_np2_live_sd_mailbox.max_cmd25_setup_cycles,elapsed(write_started));
#if XE_NP_NP2_LIVE_SD_DATA_PHASE_DIAG
    xe_np_np2_live_sd_perf.diagnostic.data_detail.previous_dcount=UINT32_MAX;
#elif XE_NP_NP2_LIVE_SD_LAUNCH_WAIT_DIAG
    if(units<=4U)xe_np_np2_live_sd_perf.diagnostic.batch.write_batch_rus_1_4++;
    else if(units==5U)xe_np_np2_live_sd_perf.diagnostic.batch.write_batch_rus_5++;
    else if(units==6U)xe_np_np2_live_sd_perf.diagnostic.batch.write_batch_rus_6++;
    else xe_np_np2_live_sd_perf.diagnostic.batch.write_batch_rus_7_11++;
#endif
    xe_np_np2_live_sd_perf.write_calls++;
    maximum(&xe_np_np2_live_sd_perf.largest_write_rus,units);
#if XE_NP_NP2_STAGED_LONG_CMD25
    /* One NVIC read per CMD25 (not per block/IRQ) establishes whether the
     * SD line is enabled after launch. Word 42 counts boundary rearms. */
    uint32_t sd_irq_enabled=(uint32_t)NVIC_GetEnableIRQ(SDMMC1_IRQn);
    xe_np_np2_stage_fault_diag[40U+(sd_irq_enabled==0U)]++;
    xe_np_np2_stage_fault_diag[43]=xe_np_np2_live_sd_perf.write_calls;
#endif
}

#if XE_NP_NP2_SD_DUAL20_STATUS_RETRY_TEST
static __attribute__((noinline)) HAL_SD_CardStateTypeDef retry_completed_status(
    HAL_SD_CardStateTypeDef state)
{
    /* Error path only. The original CMD13 has returned; no data operation is
     * active. Keep its first SDFT witness and never reset the write deadline.
     * Tail words29..34: attempts, valid replies, last error, command number,
     * last returned state and STA. Command number seals ONE retry per CMD25. */
    volatile uint32_t *d=xe_np_np2_overflow_fault_diag;
    uint32_t command=xe_np_np2_live_sd_perf.write_calls;
    if(LIVE_PROBE_MASK!=3U || record_sample_hz!=20000U || state!=0U ||
       !card || card->Instance!=SDMMC1 || card->State!=HAL_SD_STATE_READY ||
       card->Context!=SD_CONTEXT_NONE || card->ErrorCode!=HAL_SD_ERROR_CMD_RSP_TIMEOUT ||
       !dma_active || !dma_buffer_released || !irq_dataend_seen || !irq_return_seen ||
       !dma_units || sd_ll_fault || sd_ll_retired_rus!=dma_units ||
       !sd_ll.NodesCounter || sd_ll_node_index!=sd_ll.NodesCounter ||
       sd_ll_bytes_done!=dma_blocks*512U || !command || d[32]==command ||
       d[0]!=0x53444654U || d[1]!=1U || d[2]!=1U ||
       card->Instance->DCOUNT || card->Instance->DLEN || card->Instance->IDMACTRL ||
       (card->Instance->DCTRL&SDMMC_DCTRL_DTEN) ||
       (card->Instance->CMD&SDMMC_CMD_CMDINDEX)!=SDMMC_CMD_SEND_STATUS ||
       (card->Instance->STA&(ERROR_FLAGS|SDMMC_STA_CPSMACT|SDMMC_STA_DPSMACT|
                            SDMMC_STA_BUSYD0|SDMMC_FLAG_CTIMEOUT|SDMMC_FLAG_CCRCFAIL)) ||
       HAL_GetTick()-write_started_ms>=WRITE_TIMEOUT_MS)return state;
#if XE_NP_NP2_SD_DUAL20_STATUS_SLOW_QUERY_TEST
    uint32_t saved_clkcr=card->Instance->CLKCR,saved_div=card->Init.ClockDiv;
    uint32_t kernel=HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SDMMC);
    if(kernel!=XE_NP_BOARD_SD_PLL2Q_HZ || (kernel!=108000000U && kernel!=96000000U) ||
       saved_div || (saved_clkcr&SDMMC_CLKCR_CLKDIV) ||
       (saved_clkcr&SDMMC_CLKCR_SELCLKRX)!=SDMMC_CLKCR_SELCLKRX_1 ||
       (card->Instance->CMD&SDMMC_CMD_CPSMEN))return state;
    uint32_t slow_clkcr=(saved_clkcr&~SDMMC_CLKCR_CLKDIV)|1U;
#endif
    d[29]++;d[32]=command;
#if XE_NP_NP2_SD_DUAL20_STATUS_SLOW_QUERY_TEST
    d[35]=saved_clkcr;d[39]=saved_div;d[40]=kernel;
    card->Instance->CLKCR=slow_clkcr;card->Init.ClockDiv=1U;__DSB();
    d[36]=card->Instance->CLKCR;
    if(d[36]==slow_clkcr){
#endif
    card->ErrorCode=HAL_SD_ERROR_NONE; /* Exactly this returned CMD13 timeout. */
    state=HAL_SD_GetCardState(card); /* Idempotent query, never a data replay. */
#if XE_NP_NP2_SD_DUAL20_STATUS_SLOW_QUERY_TEST
    }else state=HAL_SD_CARD_ERROR;
    /* ErrorCode may still be the retried timeout. Test physical retirement,
     * not card_idle(), so even that failure restores the exact recording clock.
     * Never change clocks under a newly active host; fail before any commit. */
    d[37]=card->Instance->CLKCR;
    if(card->State==HAL_SD_STATE_READY && card->Context==SD_CONTEXT_NONE &&
       !card->Instance->DCOUNT && !card->Instance->DLEN && !card->Instance->IDMACTRL &&
       !(card->Instance->DCTRL&SDMMC_DCTRL_DTEN) &&
       !(card->Instance->CMD&SDMMC_CMD_CPSMEN) &&
       !(card->Instance->STA&(SDMMC_STA_CPSMACT|SDMMC_STA_DPSMACT|SDMMC_STA_BUSYD0))){
        card->Instance->CLKCR=saved_clkcr;card->Init.ClockDiv=saved_div;__DSB();
        d[37]=card->Instance->CLKCR;
        if(d[37]!=saved_clkcr || card->Init.ClockDiv!=saved_div){
            d[38]=3U;state=HAL_SD_CARD_ERROR;
        }else d[38]=d[36]==slow_clkcr?1U:4U;
    }else {d[38]=2U;state=HAL_SD_CARD_ERROR;}
#endif
    d[31]=card->ErrorCode;d[33]=state;d[34]=card->Instance->STA;
    if(!card->ErrorCode)d[30]++;
    if(HAL_GetTick()-write_started_ms>=WRITE_TIMEOUT_MS)return HAL_SD_CARD_ERROR;
    return state;
}
#endif

static void service_write(void)
{
#if XE_NP_USB_SD_TEST_ENABLE
    usb_wall_service_observer();
#endif
#if XE_NP_NP2_LIVE_SD_VSC_TEST
    if(SESSION_VSC && vsc_stage==4U){
        int result=service_vsc();
        if(result<0){fail(XE_NP_NP2_LIVE_SD_ERROR_WRITE,0x56530002U);return;}
        if(!result)return;
    }
#endif
    uint32_t now=cycles();
    if(last_service_cycles)maximum(&xe_np_np2_live_sd_mailbox.max_service_interval_cycles,
                                  now-last_service_cycles);
    last_service_cycles=now;
    uint32_t sta=card->Instance->STA;
#if XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST
    if(sd_ll_fault){fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0x4C4C0000U|sd_ll_node_index);return;}
#endif
    if(card->ErrorCode || (sta&ERROR_FLAGS)){fail(XE_NP_NP2_LIVE_SD_ERROR_WRITE,sta);return;}
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
    grid16_release_pending();
    if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED)return;
#endif
#if XE_NP_NP2_LIVE_SD_DATA_PHASE_DIAG
    /* Foreground-only hints: D0 can be payload, and STA/DCOUNT are not atomic.
     * Never infer card-program time or lost data from these observations. */
    if(dma_active && !irq_return_seen && (sta&SDMMC_STA_DPSMACT)){
        uint32_t remaining=card->Instance->DCOUNT;
        if(remaining){
            xe_np_np2_live_sd_perf.diagnostic.data_detail.active_polls++;
            if(remaining==xe_np_np2_live_sd_perf.diagnostic.data_detail.previous_dcount){
                xe_np_np2_live_sd_perf.diagnostic.data_detail.unchanged_polls++;
                xe_np_np2_live_sd_perf.diagnostic.data_detail.unchanged_sta_or|=sta;
            }
            xe_np_np2_live_sd_perf.diagnostic.data_detail.previous_dcount=remaining;
        }
    }
#endif
#if XE_NP_NP2_STAGED_CAPTURE
    /* IRQ publishes only a consumed count. Foreground changes queue owner
     * state, keeping the SD interrupt independent of PSRAM and scheduling. */
    while(sd_ll_retired_rus<sd_ll_consumed_rus){
#if XE_NP_NP2_STAGED_LONG_CMD25
        if(XE_Np2StageLong_RetireNext(&stage_queue,&stage_long_window)){
#else
        if(XE_Np2Stage_RetireIdma(&stage_queue)){
#endif
            fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xDA21U);return;
        }
        sd_ll_retired_rus++;
    }
#endif
    if(!dma_active){start_write();return;}
#if XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
    if(copied_window.active && copied_window_publish()){
        fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xDC01U);return;
    }
#endif
#if XE_NP_NP2_STAGED_LONG_CMD25
    while(stage_long_window.published<dma_units){
        uint32_t unit=stage_long_window.published;
        int slot=XE_Np2StageLong_PublishNext(&stage_queue,&stage_long_window);
        if(slot==-2)break;
        if(slot<0 || XE_Np2StageLong_PublishNodes(&stage_long_window,unit,
                     stage_ru_base,sd_ll_nodes,cache)){
            fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xDA61U|unit);return;
        }
    }
#endif
#if XE_NP_NP2_LIVE_SD_ROLLING_CMD25
    publish_rolling_ready();
    if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED)return;
#endif
    if(HAL_GetTick()-write_started_ms>=WRITE_TIMEOUT_MS){
        fail(XE_NP_NP2_LIVE_SD_ERROR_TIMEOUT,write_lba);return;
    }
    if(irq_return_seen && !irq_service_observed){
        maximum(&xe_np_np2_live_sd_mailbox.max_irq_to_service_cycles,
                cycles()-irq_return_cycles);
        irq_service_observed=1U;
    }
    /* Only a completed, error-free DATAEND handler may relinquish IDMA's
     * buffer. HAL READY by itself is also used for aborted/error transfers. */
    if(!irq_return_seen || !card_idle())return;
    if(!dma_buffer_released){
        write_dataend=irq_dataend_cycles;
#if XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST
        if(sd_ll_retired_rus!=dma_units){fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0x4C4C1000U|sd_ll_retired_rus);return;}
#endif
#if XE_NP_NP2_LIVE_SD_DIRECT
#if XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST
#if XE_NP_NP2_LIVE_SD_ROLLING_CMD25
        if(rolling_published_rus!=dma_units){fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xDA53U);return;}
#endif
#else
        /* Capture may reuse these records only after IDMA has finished reading
         * them. Formatting a header is NOT consumption of the DMA source. */
        uint32_t retired_rus=xe_np_np2_live_sd_mailbox.written_rus+dma_units;
        if(XE_NP_Np2CapturePort_DirectRetireRUs(retired_rus)){
            fail(XE_NP_NP2_LIVE_SD_ERROR_RING,dma_ru);return;
        }
#endif
#endif
#if !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST
        for(uint32_t i=0U;i<dma_units;i++)ru_state[dma_ru+i]=RU_FREE;
#endif
        dma_buffer_released=1U;
    }
    if((card->Instance->STA&SDMMC_STA_BUSYD0) ||
       cycles()-status_poll_cycles<STATUS_POLL_CYCLES)return;
    status_poll_cycles=cycles();
    HAL_SD_CardStateTypeDef state=HAL_SD_GetCardState(card);
    if(card->ErrorCode || state==HAL_SD_CARD_ERROR){
#if XE_NP_NP2_SD_DUAL20_STATUS_RETRY_TEST
        state=retry_completed_status(state);
        if(card->ErrorCode || state==HAL_SD_CARD_ERROR)
#endif
        {fail(XE_NP_NP2_LIVE_SD_ERROR_WRITE,state);return;}
    }
    if(state!=HAL_SD_CARD_TRANSFER)return;
    /* TRANSFER alone does not attest an available card buffer. Keep the same
     * write and deadline until the successful CMD13 also reports ready. */
    if(!(card->Instance->RESP1&(1U<<8U))){
#if XE_NP_SD_FAILURE_TRACE_ENABLE
        if(!xe_np_np2_overflow_fault_diag[2])xe_np_np2_overflow_fault_diag[50]++;
#endif
        return;
    }
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
    uint8_t grid16_committed=0U;
    if(grid16.active){
        if(sd_ll_node_index!=sd_ll.NodesCounter ||
           sd_ll_bytes_done!=grid16.plan.total_bytes ||
           sd_ll_retired_rus!=grid16.plan.owner_count ||
           XE_NP_Np2Grid16Idma_CommitReady(&grid16.plan,&grid16.idma)){
            fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0x47313620U);return;
        }
        grid16.physical_confirmed_lba=grid16.idma.committed_end_lba;
        if(grid16.physical_confirmed_lba>record_end_lba){
            fail(XE_NP_NP2_LIVE_SD_ERROR_RANGE,0x47313621U);return;
        }
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
        if(grid16.restored_pending){
            fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0x47313632U);return;
        }
#endif
        /* Source slots may have been legitimately reused since their BTC.
         * Commit only immutable accepted identities and the sealed IDMA plan. */
        for(uint32_t owner=0U;owner<dma_units;owner++)
            if(
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
               !grid16.append &&
#endif
               grid16.first_np_block[owner]!=(xe_np_np2_live_sd_mailbox.written_rus+owner)*BLOCKS_PER_RU){
                fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0x47313639U);return;
            }
        /* The final AUX-node BTC can arrive after this service turn's first
         * pending-release pass.  Return that consumed stage before reporting
         * its durable commit, never from the SD IRQ. */
        grid16_release_pending();
        if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED)return;
        /* This is the only durable hook.  BTC may have released each stage
         * buffer already, so commit receives immutable group identity only. */
        grid16.commit(grid16.context,
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
                      grid16.append?grid16.pending_ticket:
#endif
                      grid16.first_np_block[0],dma_units,grid16.physical_confirmed_lba);
        grid16_committed=1U;
    }else {
#endif
#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
    if(sd_ll_node_index!=sd_ll.NodesCounter || sd_ll_bytes_done!=dma_blocks*512U){
        fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD920U);return;
    }
    for(uint32_t i=0U;i<dma_units;i++)if(!(dma_complete_mask&(1U<<i))
#if VSC_PSRAM_IDMA
        && !dma_external[i]
#endif
        ){
        uint32_t slot=sd_physical_slot(i);
        if(ru_state[slot]!=RU_DMA || ru_first_block[slot]!=dma_generation[i]){
            fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD921U);return;
        }
        ru_parts[slot]|=dma_part_bits[i];
        __DMB();ru_state[slot]=RU_READY;
    }
#if VSC_PSRAM_IDMA
    if(SESSION_PSRAM_IDMA && commit_external_parts()){
        fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD925U);return;
    }
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    if(SESSION_APPEND){
        /* DATAEND/BTC was not durability. Only this card-ready completion
         * advances physical count and the original logical high-water mark. */
        for(uint32_t i=0U;i<dma_units;i++){
            if(dma_generation[i]+BLOCKS_PER_RU>append_logical_high_water_blocks)
                append_logical_high_water_blocks=dma_generation[i]+BLOCKS_PER_RU;
        }
    }
#endif
    fixed_confirmed_blocks+=dma_blocks;
    if(fixed_confirmed_blocks>active_target_rus*RU_BLOCKS){
        fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD922U);return;
    }
    xe_np_np2_fixed_write_diag[2]=fixed_confirmed_blocks;
    xe_np_np2_fixed_write_diag[fixed_fallback?5U:(dma_blocks==fixed_window_blocks()?3U:4U)]++;
    xe_np_np2_fixed_write_diag[6]=dma_blocks;
    xe_np_np2_fixed_write_diag[7]+=dma_complete_units;
#endif
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
    }
#endif
    uint32_t write_cycles=elapsed(write_started);
#if XE_NP_USB_SD_TEST_ENABLE
    usb_wall_complete_observer(write_started_ms);
#endif
#if WRITE_WALL_TIMING
    /* DWT sleep accounting is target-dependent. Reuse the existing timeout
     * start and spare profiling word: one tick read/add per completed CMD25,
     * never in capture/SD IRQs. Includes ACMD23 through the card-ready reply.
     * ponytail: 1-ms quantization; use a free-running timer for finer latency. */
    xe_np_np2_live_sd_perf.launch_wait_reserved+=HAL_GetTick()-write_started_ms;
#endif
#if XE_NP_NP2_LIVE_SD_WRITE_LATENCY_DIAG
    static const uint8_t limits_ms[7]={25U,30U,35U,40U,45U,50U,60U};
    uint32_t cycles_per_ms=xe_np_np2_live_sd_mailbox.cpu_hz/1000U;
    uint32_t bucket=0U;
    while(bucket<7U && write_cycles>=cycles_per_ms*limits_ms[bucket])bucket++;
    xe_np_np2_sd_latency_diag[4U+bucket]++;
    xe_np_np2_sd_latency_diag[2]++;
    if(write_cycles>xe_np_np2_sd_latency_diag[12]){
        xe_np_np2_sd_latency_diag[3]=xe_np_np2_live_sd_perf.write_calls;
        xe_np_np2_sd_latency_diag[12]=write_cycles;
        xe_np_np2_sd_latency_diag[13]=dma_units;
        xe_np_np2_sd_latency_diag[14]=write_start_depth;
        xe_np_np2_sd_latency_diag[15]=ring_depth();
    }
#endif
    xe_np_np2_live_sd_perf.completed_calls++;
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER && MAX_WRITE_RUS<=6U
#if XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
    if(dma_units<=MAX_WRITE_RUS)
#endif
    xe_np_np2_write_batch_diag[1U+dma_units]++;
#endif
    xe_np_np2_live_sd_perf.write_cycles+=write_cycles;
    xe_np_np2_live_sd_perf.data_cycles+=write_dataend-write_started;
    xe_np_np2_live_sd_perf.busy_cycles+=cycles()-write_dataend;
    maximum(&xe_np_np2_live_sd_mailbox.max_write_cycles,write_cycles);
    if(dma_buffer_released)maximum(&xe_np_np2_live_sd_mailbox.max_write_busy_cycles,
                                  cycles()-write_dataend);
    dma_active=dma_buffer_released=0U;
#if XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST
    if(dma_window_external)spill_defer_window_ended(HAL_GetTick(),xe_np_np2_live_sd_mailbox.state);
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_LEG_4K_TEST || XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST || XE_NP_NP2_LIVE_SD_SPILL_LAUNCH_TRACE_TEST
    dma_window_external=0U;
#endif
#if XE_NP_NP2_LIVE_SD_COUNTED_WRITES
    counted_write_active=0U;
#endif
#if XE_NP_NP2_STAGED_CAPTURE
#if XE_NP_NP2_STAGED_LONG_CMD25
    if(XE_Np2StageLong_Commit(&stage_queue,&stage_long_window)){
#else
    if(XE_Np2Stage_CommitSd(&stage_queue)){
#endif
        fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xDA22U);return;
    }
#endif
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
    if(grid16_committed){
        write_lba=grid16.physical_confirmed_lba;
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
        if(grid16.append){
            dma_first_ru=grid16.first_np_block[0]/BLOCKS_PER_RU;
            dma_complete_units=dma_units;
            for(uint32_t owner=0U;owner<dma_units;owner++){
                uint32_t end=grid16.first_np_block[owner]+BLOCKS_PER_RU;
                if(end>append_logical_high_water_blocks)append_logical_high_water_blocks=end;
            }
            if(commit_overflow_order())return;
        }else
#endif
        xe_np_np2_live_sd_mailbox.written_rus+=dma_units;
        grid16.active=0U;
    }else
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
    if(commit_overflow_order())return;
#else
    write_lba+=RU_BLOCKS*dma_units;
    xe_np_np2_live_sd_mailbox.written_rus+=dma_units;
#endif
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
    if(grid16_committed)grid16_release_pending();
#endif
#if XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
    copied_window.active=0U;copied_window.reserved=0U;
#endif
    last_write_completed=cycles();
#if XE_NP_NP2_LIVE_SD_LAUNCH_WAIT_DIAG
    launch_wait_tracking=1U;
#endif
    start_write();
}

static int find_free(void)
{
#if XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
    if(copied_window.active){
#if XE_NP_NP2_SD_APPEND_COUNTED_PIPELINE_TEST
        int target=copied_window_append_free();
#else
        int target=copied_window_destination(xe_np_np2_live_sd_mailbox.produced_blocks);
#endif
        if(target>=0)return ru_state[target]==RU_FREE?target:-1;
        for(uint32_t i=0U;i<RU_COUNT;i++)
            if(ru_state[i]==RU_FREE && !(copied_window.reserved&(1U<<i)))return (int)i;
        return -1;
    }
#endif
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(SESSION_RUNTIME_DIRECT){
        uint32_t target=(xe_np_np2_live_sd_mailbox.produced_blocks/BLOCKS_PER_RU)%NP2_RUNTIME_DIRECT_CAPTURE_RUS;
        return ru_state[target]==RU_FREE?(int)target:-1;
    }
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
    for(uint32_t i=0U;i<RU_COUNT;i++)if(ru_state[i]==RU_FREE)return (int)i;
    return -1;
#else
    /* Keep capture order identical to physical RU order. An early DATAEND
     * may free bank 0 while bank 1 is still being filled: first-free search
     * would then scatter one batch across banks and strand its oldest RU. */
    uint32_t i=(xe_np_np2_live_sd_mailbox.produced_blocks/BLOCKS_PER_RU)%RU_COUNT;
#if XE_NP_NP2_LIVE_SD_PSRAM_SPILL
    if(spill_count || spill_restore!=RU_COUNT || ru_state[i]!=RU_FREE)
        return spill_count<SPILL_SLOTS?(int)SPILL_FILL:-1;
#endif
    return ru_state[i]==RU_FREE?(int)i:-1;
#endif
}

#if (XE_NP_NP2_LIVE_SD_VSC_TEST || XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST) && \
    XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST && \
    XE_NP_NP2_LIVE_SD_OVERFLOW_DMA && XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER && \
    !XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST
static uint32_t fixed_refill_reserve(void)
{
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
    /* Grid16 restores one exact prefix, not legacy fixed-window neighbours. */
    if(grid16.requested)return 0U;
#endif
#if XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
    if(copied_window_policy()){
#if XE_NP_NP2_SD_APPEND_COUNTED_PIPELINE_TEST
        return 0U; /* Append has no exact logical-window restore debt. */
#else
        uint32_t next=copied_window_next_sequence();
        return next!=UINT32_MAX && spill_count &&
            spill_sequence[spill_tail]==next && ready_sequence(next)<0 && !overflow_kind;
#endif
    }
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    if(SESSION_APPEND)return 0U; /* No exact logical-window destination debt. */
#endif
#if XE_NP_NP2_SD_HIGH_TWO_PSRAM_IDMA_TEST
    if(SESSION_PSRAM_IDMA)return 0U;
#endif
#if XE_NP_NP2_SD_PROFILE_CLASSIC_TEST && !XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST
    if(!SESSION_VSC)return 0U;
#endif
    /* Sequential fixed writes cannot bypass a hole or issue a singleton.
     * C14 restores one RU at a time, not all future destinations together.
     * Retain every missing destination, including while a restore owns its
     * separate COPY slot. Each accepted spill or whole-RU SD return supplies
     * only ONE credit, not credit for every missing destination.
     * Partial SD fragments are not future FREE credits. No owner is freed here.
     * Scan only fragments in the next selected window, not the entire FIFO. */
    uint32_t start=fixed_confirmed_blocks+(dma_active?dma_blocks:0U);
    uint32_t target=active_target_rus*RU_BLOCKS;
    if(start>=target || !spill_count)return 0U;
#if XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_TEST
    if(SESSION_WHOLE_RU && !SESSION_BATCH3){
        /* A one-RU command needs at most ONE missing head destination.
         * COPY already owns its destination; a pending whole BTC/SPILL
         * supplies one real future FREE credit. Count it only under the
         * caller's existing IRQ-masked FREE/credit snapshot. */
        uint32_t sequence=(start/RU_BLOCKS)*BLOCKS_PER_RU;
        if(spill_sequence[spill_tail]!=sequence || ready_sequence(sequence)>=0 || overflow_kind)return 0U;
#if XE_NP_NP2_LIVE_SD_LAST_FREE_PREFETCH_TEST
        /* Keep the physical restore destination. A pending whole BTC funds
         * future ingress, not this still-missing FIFO-head destination. */
        return 1U;
#else
        uint32_t pending=dma_active?dma_complete_mask&~((1U<<sd_ll_retired_rus)-1U):0U;
        return pending?0U:1U;
#endif
    }
#endif
    uint32_t blocks=fixed_sequential_blocks(start,target);
    uint32_t first=(start/RU_BLOCKS)*BLOCKS_PER_RU;
    uint32_t last=((start+blocks-1U)/RU_BLOCKS)*BLOCKS_PER_RU;
    uint32_t units=(last-first)/BLOCKS_PER_RU+1U,missing=0U;
    for(uint32_t i=0U;i<spill_count && i<units;i++){
        uint32_t slot=(spill_tail+i)%SPILL_SLOTS,sequence=spill_sequence[slot];
        if(sequence<first || sequence>last)break;
        if(!(i==0U && overflow_kind==2U))missing++;
    }
    if(!missing)return 0U;
#if XE_NP_NP2_SD_ORDERED_BATCH3_TEST
    /* Physical destinations plus ingress room, never future BTC credits.
     * The current COPY already owns its destination and was excluded above. */
    if(SESSION_BATCH3)return missing+1U;
#endif
    uint32_t credits=overflow_kind==1U?1U:0U;
    if(dma_active){
        uint32_t pending=dma_complete_mask&~((1U<<sd_ll_retired_rus)-1U);
        while(pending && credits<missing){pending&=pending-1U;credits++;}
    }
    return missing>credits?missing-credits:0U;
}
#if XE_NP_NP2_LIVE_SD_COPY_COST_DIAG
/* RESTORE_ELIGIBILITY_HELPERS_BEGIN */
static void record_eligibility_snapshot(volatile uint32_t *s)
{
    s[0]=cycles();
    s[1]=xe_np_np2_record_power_diag[5];s[2]=xe_np_np2_record_power_diag[6];
    s[3]=xe_np_np2_record_power_diag[7];
    s[4]=(uint32_t)next_tick;s[5]=(uint32_t)(next_tick>>32U);
    uint32_t free_count=0U,restored=0U;
    for(uint32_t i=0U;i<RU_COUNT;i++){
        free_count+=ru_state[i]==RU_FREE;
        restored+=(overflow_restored_mask&(1U<<i))!=0U;
    }
    s[6]=free_count;s[7]=fixed_refill_reserve();s[8]=overflow_kind;
    s[9]=restored;s[10]=spill_count;
    uint32_t retired=sd_ll_retired_rus;
    s[11]=dma_active?dma_complete_mask&~((1U<<retired)-1U):0U;
    s[12]=card->Instance->DCOUNT;s[13]=card->Instance->STA;
    s[14]=xe_np_np2_live_sd_mailbox.produced_blocks;
    s[15]=xe_np_np2_live_sd_mailbox.written_rus;s[16]=fixed_confirmed_blocks;
    s[17]=dma_active|(retired<<8U)|(dma_units<<16U);
    s[18]=GPDMA1_Channel12->CDAR;s[19]=GPDMA1_Channel12->CBR1;
    s[20]=cycles();
}
static void record_eligibility_point(uint32_t point)
{
    volatile uint32_t *d=xe_np_np2_restore_elig_diag;
    if(d[2] || d[7] || xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_CAPTURING ||
       !spill_count)return;
    if(!record_power_clock()){d[7]|=1U;return;}
    if((point!=1U && point!=2U && point!=4U) || spill_count>SPILL_SLOTS ||
       spill_tail>=SPILL_SLOTS || sd_ll_retired_rus>MAX_WRITE_RUS || !card || !card->Instance){
        d[7]|=2U;return;
    }
    d[3]=SystemCoreClock;
    uint32_t head=spill_sequence[spill_tail];
    if(!d[5] || d[4]!=head){d[4]=head;d[5]=0U;d[6]++;}
    if(!(d[5]&1U)){record_eligibility_snapshot(d+8U);d[5]|=1U;}
    if(point!=1U && !(d[5]&point)){
        record_eligibility_snapshot(d+(point==2U?29U:50U));d[5]|=point;
    }
}
/* RESTORE_ELIGIBILITY_HELPERS_END */
#endif
/* DUAL20_RESTORE_BRIDGE_BEGIN */
#if XE_NP_NP2_SD_DUAL20_WINDOW1536_TEST
static int fixed_refill_ready_bridge(uint32_t last_restored,uint32_t head)
{
    /* A resident sealed prefix may bridge a restored RU to the FIFO head.
     * Prove only the next ordered window; never invent a future FREE credit. */
    if(LIVE_PROBE_MASK!=3U || record_sample_hz!=20000U ||
       fixed_window_shift!=FIXED_WINDOW_1536_MODE || SESSION_VSC || SESSION_APPEND ||
       dma_active || overflow_kind || !spill_count || !card_idle() ||
       (card->Instance->STA&SDMMC_STA_BUSYD0) || head<=last_restored ||
       head-last_restored<=BLOCKS_PER_RU || head%BLOCKS_PER_RU ||
       last_restored%BLOCKS_PER_RU || ready_sequence(head)>=0)return 0;
    uint32_t start=fixed_confirmed_blocks,target=active_target_rus*RU_BLOCKS;
    if(start>=target)return 0;
    uint32_t blocks=fixed_sequential_blocks(start,target);
    uint32_t first=(start/RU_BLOCKS)*BLOCKS_PER_RU;
    uint32_t last=((start+blocks-1U)/RU_BLOCKS)*BLOCKS_PER_RU;
    if(last_restored<first || head>last || spill_parts[spill_tail])return 0;
    for(uint32_t sequence=first;sequence<head;sequence+=BLOCKS_PER_RU){
        int slot=ready_sequence(sequence);
        uint32_t base=(sequence/BLOCKS_PER_RU)*RU_BLOCKS;
        if(slot<0 || ru_parts[slot]!=(base<start?1U:0U))return 0;
    }
    return 1;
}
#endif
/* DUAL20_RESTORE_BRIDGE_END */
static int fixed_refill_completes_window(void)
{
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    /* An append command has no missing logical neighbours. With SD idle,
     * an otherwise empty ring can restore one head and immediately drain it. */
    if(SESSION_APPEND)return !dma_active && !overflow_kind && spill_count &&
        ready_ru()<0 && card_idle() && !(card->Instance->STA&SDMMC_STA_BUSYD0);
#endif
#if XE_NP_NP2_SD_HIGH_TWO_PSRAM_IDMA_TEST
    if(SESSION_PSRAM_IDMA)return 0;
#endif
#if XE_NP_NP2_SD_PROFILE_CLASSIC_TEST && !XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST
    if(!SESSION_VSC)return 0;
#endif
    /* The protected sole FREE owner is usable only for the ONE missing FIFO
     * head of an otherwise sealed/ordered next command. This is not prefetch:
     * the whole COPY must publish before start_write can claim these sources.
     * A second hole, active SD/COPY, busy card or already-written part refuses. */
    if(dma_active || overflow_kind || !spill_count ||
#if XE_NP_NP2_LIVE_SD_VSC_TEST
       vsc_stage!=3U ||
#endif
       !card_idle() || (card->Instance->STA&SDMMC_STA_BUSYD0))return 0;
    uint32_t start=fixed_confirmed_blocks,target=active_target_rus*RU_BLOCKS;
    if(start>=target)return 0;
#if XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_TEST
    if(SESSION_WHOLE_RU && !SESSION_BATCH3){
        /* With no SD/COPY owner, this complete one-RU command is precisely
         * the FIFO head. Its sole FREE destination cannot strand a second
         * command hole, and still publishes only after the entire copy. */
        uint32_t sequence=(start/RU_BLOCKS)*BLOCKS_PER_RU;
        return spill_sequence[spill_tail]==sequence && ready_sequence(sequence)<0
#if XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_VSC_TEST
            /* At an AU edge this one owner may need prefix/renewal/suffix,
             * but never a second COPY destination before it can be freed. */
            && spill_parts[spill_tail]==(start%RU_BLOCKS?1U:0U)
#endif
            ;
    }
#endif
    uint32_t blocks=fixed_sequential_blocks(start,target);
    if(!SESSION_BATCH3 && blocks<fixed_window_blocks() &&
#if XE_NP_NP2_LIVE_SD_VSC_PRESSURE_PREFIX_TEST
       !(vsc_pressure_profile() && start%1024U) &&
#endif
       xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_DRAINING)return 0;
    uint32_t first=start/RU_BLOCKS,last=(start+blocks-1U)/RU_BLOCKS,missing=0U;
    for(uint32_t unit=first;unit<=last;unit++){
        uint32_t sequence=unit*BLOCKS_PER_RU;
        uint8_t bits=SESSION_BATCH3?3U:fixed_part_bits(unit*RU_BLOCKS,fixed_window_index(start));
        int slot=ready_sequence(sequence);
        if(slot>=0){if(ru_parts[slot]&bits)return 0;}
        else{
            if(missing || spill_sequence[spill_tail]!=sequence ||
               (spill_parts[spill_tail]&bits))return 0;
            missing=1U;
        }
    }
    return (int)missing;
}
#if XE_NP_NP2_LIVE_SD_LAST_FREE_PREFETCH_TEST
static int fixed_inflight_refill_credit(void)
{
#if XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_TEST
    /* Reserve a destination, but never spend the sole ingress slot against
     * future whole-RU BTC latency. Held-card tests reject that admission. */
    if(SESSION_WHOLE_RU)return 0;
#endif
    /* Spend the sole FREE destination only while real pending whole-RU BTC
     * returns fund every other missing destination plus one ingress owner.
     * These are future credits, never permission to overwrite an SD owner. */
    if(!SESSION_VSC || !((LIVE_PROBE_MASK==3U && record_sample_hz==30000U) ||
                         (LIVE_PROBE_MASK==7U && record_sample_hz==20000U)) ||
       xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_CAPTURING ||
       !dma_active || irq_return_seen || overflow_kind || !spill_count ||
       spill_count>SPILL_SLOTS || spill_tail>=SPILL_SLOTS || dma_blocks!=1024U ||
       sd_ll_fault || !dma_units || dma_units>MAX_WRITE_RUS || sd_ll_retired_rus>=dma_units ||
       vsc_stage!=3U || card->ErrorCode || (card->Instance->STA&ERROR_FLAGS) ||
       (card->Context&(SD_CONTEXT_WRITE_MULTIPLE_BLOCK|SD_CONTEXT_DMA))!=
           (SD_CONTEXT_WRITE_MULTIPLE_BLOCK|SD_CONTEXT_DMA) ||
       !(card->Instance->IDMACTRL&1U) || !card->Instance->DCOUNT)return 0;
    uint32_t start=fixed_confirmed_blocks+dma_blocks,target=active_target_rus*RU_BLOCKS;
    if(start>=target || (start&1023U))return 0;
    uint32_t blocks=fixed_sequential_blocks(start,target);
    if(blocks!=1024U)return 0;
    uint32_t first=start/RU_BLOCKS,last=(start+blocks-1U)/RU_BLOCKS,missing=0U;
    for(uint32_t unit=first;unit<=last;unit++){
        uint32_t sequence=unit*BLOCKS_PER_RU;
        uint8_t bits=fixed_part_bits(unit*RU_BLOCKS,start/1024U);
        int slot=ready_sequence(sequence);
        if(slot<0){
            /* A shared command-boundary tail may still be SD-owned. Its
             * immutable future slice must be disjoint from the current slice. */
            for(uint32_t i=0U;i<dma_units;i++)if(dma_generation[i]==sequence){
                uint32_t physical=dma_slots[i];
                if(physical>=RU_COUNT || ru_state[physical]!=RU_DMA ||
                   ru_first_block[physical]!=sequence || (dma_part_bits[i]&bits))return 0;
                slot=(int)physical;break;
            }
        }
        if(slot>=0){if(ru_parts[slot]&bits)return 0;}
        else{
            if(missing>=spill_count)return 0;
            uint32_t fifo=(spill_tail+missing)%SPILL_SLOTS;
            if(spill_sequence[fifo]!=sequence || (spill_parts[fifo]&bits))return 0;
            missing++;
        }
    }
    if(!missing)return 0;
    uint32_t pending=dma_complete_mask&((1U<<dma_units)-1U)&
        ~((1U<<sd_ll_retired_rus)-1U),credits=0U;
    while(pending){pending&=pending-1U;credits++;}
    if(credits<missing)return 0;
    uint64_t latest=0U;
    if(copy_cost_status(&latest)!=0 || latest<next_tick){
        fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,1U);return -1;
    }
    const uint64_t guard=XE_NP_NP2_UNPUBLISHED_BOUND+
        (uint64_t)BLOCKS_PER_RU*STREAM_TICKS+record_mclk_hz/500U;
    if(guard>=XE_NP_NP2_RETENTION_LIMIT ||
       latest-next_tick>=(uint64_t)XE_NP_NP2_RETENTION_LIMIT-guard)return 0;
    /* Current raw debt is bounded, not future BTC latency. Normal sticky
     * retention checks remain authoritative if the card subsequently stalls. */
    xe_np_np2_last_free_prefetch_diag[0]++;
    maximum(&xe_np_np2_last_free_prefetch_diag[1],(uint32_t)(latest-next_tick));
    xe_np_np2_last_free_prefetch_diag[2]=credits;
    xe_np_np2_last_free_prefetch_diag[3]=missing;
    return 1;
}
#endif
#endif

#if XE_NP_NP2_LIVE_SD_PSRAM_SPILL || XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
#if XE_NP_NP2_SD_LINKED_COPY_TEST
static int init_spill_linked_copy(void)
{
    DMA_NodeConfTypeDef node={0};
    spill_dma.InitLinkedList.Priority=DMA_LOW_PRIORITY_LOW_WEIGHT;
    spill_dma.InitLinkedList.LinkStepMode=DMA_LSM_FULL_EXECUTION;
    spill_dma.InitLinkedList.LinkAllocatedPort=DMA_LINK_ALLOCATED_PORT1;
    spill_dma.InitLinkedList.TransferEventMode=DMA_TCEM_LAST_LL_ITEM_TRANSFER;
    spill_dma.InitLinkedList.LinkedListMode=DMA_LINKEDLIST_NORMAL;
    if(HAL_DMAEx_List_Init(&spill_dma)!=HAL_OK ||
       HAL_DMAEx_List_ResetQ(&spill_copy_queue)!=HAL_OK)return -1;
    memset(spill_copy_nodes,0,sizeof(spill_copy_nodes));
    node.NodeType=DMA_GPDMA_LINEAR_NODE;node.Init=spill_dma.Init;
    node.Init.TransferEventMode=DMA_TCEM_LAST_LL_ITEM_TRANSFER;
    node.DataHandlingConfig.DataExchange=DMA_EXCHANGE_NONE;
    node.DataHandlingConfig.DataAlignment=DMA_DATA_RIGHTALIGN_ZEROPADDED;
    node.TriggerConfig.TriggerMode=DMA_TRIGM_SINGLE_BURST_TRANSFER;
    node.TriggerConfig.TriggerPolarity=DMA_TRIG_POLARITY_MASKED;
    node.RepeatBlockConfig.RepeatCount=1U;
    uint32_t offset=0U;
    for(uint32_t i=0U;i<3U;i++){
        node.DataSize=i==2U?RU_BYTES-offset:OVERFLOW_COPY_BYTES;
        node.SrcAddress=(uint32_t)(uintptr_t)(ru[0]+offset);
        node.DstAddress=(uint32_t)(uintptr_t)(spill_address(0U)+offset);
        if(HAL_DMAEx_List_BuildNode(&node,&spill_copy_nodes[i])!=HAL_OK ||
           HAL_DMAEx_List_InsertNode_Tail(&spill_copy_queue,&spill_copy_nodes[i])!=HAL_OK)return -1;
        offset+=node.DataSize;
    }
    return HAL_DMAEx_List_LinkQ(&spill_dma,&spill_copy_queue)==HAL_OK?0:-1;
}

static HAL_StatusTypeDef start_spill_linked_copy(uint8_t *source,uint8_t *destination)
{
    /* Never rewrite a descriptor owned by DMA, even at a transient node edge.
     * Queue topology/counts are immutable; retarget only the static word endpoints. */
    if(spill_copy || spill_dma_bytes || spill_dma.State!=HAL_DMA_STATE_READY ||
       spill_copy_queue.State!=HAL_DMA_QUEUE_STATE_READY ||
       (GPDMA1_Channel14->CCR&(DMA_CCR_EN|DMA_CCR_RESET|DMA_CCR_SUSP)) ||
       GPDMA1_Channel14->CBR1)return HAL_ERROR;
    uint32_t offset=0U;
    for(uint32_t i=0U;i<3U;i++){
        spill_copy_nodes[i].LinkRegisters[3]=(uint32_t)(uintptr_t)(source+offset);
        spill_copy_nodes[i].LinkRegisters[4]=(uint32_t)(uintptr_t)(destination+offset);
        offset+=i==2U?RU_BYTES-offset:OVERFLOW_COPY_BYTES;
    }
    if(clean(spill_copy_nodes,sizeof(spill_copy_nodes)))return HAL_ERROR;
    __DMB();
    /* List_Start unlike normal Start does not clear stale owned flags. */
    GPDMA1_Channel14->CFCR=DMA_FLAG_TC|DMA_FLAG_HT|DMA_FLAG_DTE|DMA_FLAG_ULE|
                         DMA_FLAG_USE|DMA_FLAG_TO|DMA_FLAG_SUSP;
    return HAL_DMAEx_List_Start(&spill_dma);
}
#endif
static int init_spill_dma(void)
{
#if XE_NP_NP2_SD_COPY_WAKE_TEST
    if(spill_wake_owned || NVIC_GetEnableIRQ(GPDMA1_Channel14_IRQn) ||
       NVIC_GetPendingIRQ(GPDMA1_Channel14_IRQn))return -1;
#endif
    spill_dma.Instance=GPDMA1_Channel14;
    __HAL_RCC_GPDMA1_CLK_ENABLE();
    if(GPDMA1_Channel14->CCR&DMA_CCR_EN)return -1;
    spill_dma.Init.Request=DMA_REQUEST_SW;
    spill_dma.Init.BlkHWRequest=DMA_BREQ_BLOCK;
    spill_dma.Init.Direction=DMA_MEMORY_TO_MEMORY;
    spill_dma.Init.SrcInc=DMA_SINC_INCREMENTED;spill_dma.Init.DestInc=DMA_DINC_INCREMENTED;
    spill_dma.Init.SrcDataWidth=DMA_SRC_DATAWIDTH_WORD;spill_dma.Init.DestDataWidth=DMA_DEST_DATAWIDTH_WORD;
    spill_dma.Init.Priority=DMA_LOW_PRIORITY_LOW_WEIGHT;
#if XE_NP_NP2_SD_HIGH_TWO_COPY_PRIORITY_TEST
    /* Stopped PREPARE only. Keep acquisition/NVIC priority, burst/ports and
     * all ownership/retirement checks; sharing its DMA class is experimental. */
    if((LIVE_PROBE_MASK==3U && record_sample_hz==30000U) ||
       (LIVE_PROBE_MASK==7U && record_sample_hz==20000U))
        spill_dma.Init.Priority=DMA_HIGH_PRIORITY;
#endif
    spill_dma.Init.SrcBurstLength=XE_NP_NP2_LIVE_SD_OVERFLOW_DMA ?
        XE_NP_NP2_LIVE_SD_OVERFLOW_DMA_BURST_WORDS:4U;
    spill_dma.Init.DestBurstLength=XE_NP_NP2_LIVE_SD_SPILL_DEST_BURST4_TEST ?
        4U:spill_dma.Init.SrcBurstLength;
    /* Keep both memory endpoints on port1; the live PREPARE reset must have
     * finished before these channel settings are installed. */
    spill_dma.Init.TransferAllocatedPort=DMA_SRC_ALLOCATED_PORT1|DMA_DEST_ALLOCATED_PORT1;
    spill_dma.Init.TransferEventMode=DMA_TCEM_BLOCK_TRANSFER;spill_dma.Init.Mode=DMA_NORMAL;
#if XE_NP_NP2_SD_LINKED_COPY_TEST
    if(init_spill_linked_copy())return -1;
#else
    if(HAL_DMA_Init(&spill_dma)!=HAL_OK)return -1;
#endif
#if XE_NP_NP2_SD_OSPI_SLEEP_GATE_TEST
    memset((void *)xe_np_np2_ospi_sleep_gate_diag,0,sizeof(xe_np_np2_ospi_sleep_gate_diag));
#endif
#if XE_NP_NP2_SD_COPY_WAKE_TEST
    memset((void *)xe_np_np2_copy_wake_diag,0,sizeof(xe_np_np2_copy_wake_diag));
    spill_wake_disarm();
    HAL_NVIC_SetPriority(GPDMA1_Channel14_IRQn,8U,0U);
    spill_wake_owned=1U;
#endif
    return 0;
}
#endif

#if XE_NP_NP2_LIVE_SD_PSRAM_SPILL
static void restore_spill(void)
{
    if(!spill_count)return;
    if(spill_restore==RU_COUNT){
        uint32_t slot=(spill_sequence[spill_tail]/BLOCKS_PER_RU)%RU_COUNT;
        if(ru_state[slot]!=RU_FREE || slot==fill_ru)return;
        spill_restore=(uint8_t)slot;spill_copy=0U;
        ru_state[slot]=RU_FILLING;ru_first_block[slot]=spill_sequence[spill_tail];
    }
    if(spill_dma_bytes){
        uint32_t flags=GPDMA1_Channel14->CSR;
        if(flags&(DMA_FLAG_DTE|DMA_FLAG_ULE|DMA_FLAG_USE)){
            (void)HAL_DMA_Abort(&spill_dma);fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,0xD801U);return;
        }
        if(!(flags&DMA_FLAG_TC)){
            if(HAL_GetTick()-spill_dma_started>100U){
                xe_np_live_spill_diag[6]=flags;xe_np_live_spill_diag[7]=GPDMA1_Channel14->CBR1;
                (void)HAL_DMA_Abort(&spill_dma);fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,0xD802U);
            }
            return;
        }
        if(HAL_DMA_PollForTransfer(&spill_dma,HAL_DMA_FULL_TRANSFER,0U)!=HAL_OK ||
           HAL_DCACHE_InvalidateByAddr(cache,(uint32_t *)(ru[spill_restore]+spill_copy),spill_dma_bytes)!=HAL_OK){
            fail(XE_NP_NP2_LIVE_SD_ERROR_CACHE,0xD803U);return;
        }
        __DMB();spill_copy+=spill_dma_bytes;spill_dma_bytes=0U;
    }
    if(spill_copy==RU_BYTES){
        ru_state[spill_restore]=RU_READY;spill_restore=RU_COUNT;
        spill_tail=(spill_tail+1U)%SPILL_SLOTS;spill_count--;
        xe_np_live_spill_diag[2]++;
        return;
    }
    uint32_t bytes=RU_BYTES-spill_copy;
    if(bytes>32768U)bytes=32768U;
    uint32_t began=cycles();
    if(HAL_DCACHE_CleanInvalidByAddr(cache,(uint32_t *)(ru[spill_restore]+spill_copy),bytes)!=HAL_OK ||
       HAL_DMA_Start(&spill_dma,(uint32_t)(spill_address(spill_tail)+spill_copy),
                     (uint32_t)(ru[spill_restore]+spill_copy),bytes)!=HAL_OK){
        fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,0xD804U);return;
    }
    spill_dma_started=HAL_GetTick();spill_dma_bytes=bytes;
    xe_np_live_spill_diag[5]+=elapsed(began);
}
#endif

#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
/* APPEND15_RESTORE_GAP_HELPER_BEGIN */
#if XE_NP_NP2_SD_APPEND15_RESTORE_GAP_TEST
static int append15_restore_gap(uint32_t last_restored,uint32_t head,uint32_t slot)
{
    /* Append has no missing logical neighbours. Reuse the existing owner walk;
     * FIFO publication already excludes duplicate live generations. */
    return SESSION_APPEND && LIVE_PROBE_MASK==7U && record_sample_hz==15000U &&
        slot<RU_COUNT && ru_state[slot]==RU_READY && !ru_parts[slot] &&
        ru_first_block[slot]==last_restored && !(last_restored%BLOCKS_PER_RU) &&
        head>last_restored && head-last_restored>BLOCKS_PER_RU && !(head%BLOCKS_PER_RU) &&
        spill_count && spill_tail<SPILL_SLOTS && spill_sequence[spill_tail]==head &&
        !spill_parts[spill_tail] && head/BLOCKS_PER_RU<active_target_rus &&
        head/BLOCKS_PER_RU<xe_np_np2_live_sd_mailbox.produced_blocks/BLOCKS_PER_RU;
}
#endif
/* APPEND15_RESTORE_GAP_HELPER_END */
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
static int grid16_copy_owned(void)
{
    if(!overflow_kind || overflow_kind>2U || overflow_ru>=RU_COUNT ||
       ru_state[overflow_ru]!=RU_COPY || ru_first_block[overflow_ru]!=grid16.copy_sequence ||
       grid16.copy_fifo>=SPILL_SLOTS || spill_count>SPILL_SLOTS ||
       spill_head>=SPILL_SLOTS || spill_tail>=SPILL_SLOTS || spill_copy>RU_BYTES ||
       spill_dma_bytes>RU_BYTES-spill_copy)return 0;
    if(overflow_kind==1U)return grid16.copy_fifo==spill_head && spill_count<SPILL_SLOTS;
    return spill_count && grid16.copy_fifo==spill_tail &&
        spill_sequence[spill_tail]==grid16.copy_sequence;
}
/* Only foreground chooses an ordered whole-RU COPY. Reuse C14 retirement and
 * the existing PSRAM FIFO; no capture map, optional sensor or wire change. */
static int grid16_copy_begin(void)
{
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
    if(grid16.append)return grid16_append_copy_begin();
#endif
    uint32_t free_count=0U;int free_slot=-1,selected=-1;
    uint32_t prefix=xe_np_np2_live_sd_mailbox.written_rus*BLOCKS_PER_RU;
    uint32_t next=0U,resident=0U;
    if(xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_CAPTURING &&
       xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_DRAINING)return 0;
    if(spill_count>SPILL_SLOTS || spill_head>=SPILL_SLOTS || spill_tail>=SPILL_SLOTS){
        fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0x47313633U);return 0;
    }
    for(uint32_t i=0U;i<RU_COUNT;i++)if(ru_state[i]==RU_FREE){free_count++;if(free_slot<0)free_slot=(int)i;}
    if(grid16_restore_prefix(&next,&resident)){
        fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0x4731363AU);return 0;
    }
    if(spill_count && spill_sequence[spill_tail]<next){
        fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0x47313634U);return 0;
    }
    if(spill_count && resident<XE_NP_NP2_GRID16_GROUPS && next<active_target_blocks &&
       spill_sequence[spill_tail]==next){
        /* Prefetch during accepted SD/data/card-busy phases only with a real
         * spare ingress destination. The exact idle head may use the last
         * FREE to avoid full-FIFO deadlock; never assume a future BTC credit. */
        if(free_slot>=0 && (free_count>=2U ||
           (!dma_active && !resident && next==prefix && card_idle()) ||
           (!dma_active && resident && spill_count>=SPILL_SLOTS-2U && card_idle()))){
            overflow_kind=2U;overflow_ru=(uint8_t)free_slot;
            grid16.copy_sequence=next;grid16.copy_fifo=spill_tail;
            ru_first_block[overflow_ru]=next;ru_state[overflow_ru]=RU_COPY;
            if(clean_invalid_if_cacheable(ru[overflow_ru],RU_BYTES)){
                fail(XE_NP_NP2_LIVE_SD_ERROR_CACHE,0xD813U);return 0;
            }
            return 1;
        }
    }
    if(free_count>2U || spill_count>=SPILL_SLOTS)return 0;
    uint32_t last=spill_count?spill_sequence[(spill_head+SPILL_SLOTS-1U)%SPILL_SLOTS]:0U;
    if(spill_count && last>UINT32_MAX-BLOCKS_PER_RU){
        fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0x47313636U);return 0;
    }
    for(uint32_t i=0U;i<RU_COUNT;i++)if(ru_state[i]==RU_READY &&
       ru_first_block[i]>prefix && ru_first_block[i]<active_target_blocks &&
       !(ru_first_block[i]&(BLOCKS_PER_RU-1U)) &&
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
       !(overflow_restored_mask&(1U<<i)) &&
#endif
#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
       !ru_parts[i] &&
#endif
       (!spill_count || ru_first_block[i]==last+BLOCKS_PER_RU)){
        if(selected<0 || ru_first_block[i]>ru_first_block[(uint32_t)selected])selected=(int)i;
    }
    if(selected<0)return 0;
#if XE_NP_PSRAM_HOST_PARK_TEST
    if(resume_parked_psram(0U)){fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,0xD841U);return 0;}
#endif
    overflow_kind=1U;overflow_ru=(uint8_t)selected;
    grid16.copy_sequence=ru_first_block[overflow_ru];grid16.copy_fifo=spill_head;
    ru_state[overflow_ru]=RU_COPY;
    if(clean(ru[overflow_ru],RU_BYTES)){fail(XE_NP_NP2_LIVE_SD_ERROR_CACHE,0xD814U);return 0;}
    return 1;
}
#endif
static void service_overflow(void)
{
    /* Only foreground schedules copies. Neither SD BTC nor capture IRQ
     * performs PSRAM/cache/HAL work. Publish ownership once per entire RU. */
#if XE_NP_NP2_LIVE_SD_RESTORE_CHAIN_TEST
    uint32_t restore_only=0U;
#endif
    record_eligibility_point(1U);
    if(overflow_kind){
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
        if(grid16.requested && !grid16_copy_owned()){
            fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0x47313637U);return;
        }
#endif
#if VSC_PSRAM_IDMA
        if(SESSION_PSRAM_IDMA && overflow_kind!=1U){fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD926U);return;}
#endif
#if XE_NP_NP2_LIVE_SD_COPY_COST_DIAG
        uint32_t cost_before=cycles();
#endif
        uint32_t flags=GPDMA1_Channel14->CSR;
        if((flags&(DMA_FLAG_DTE|DMA_FLAG_ULE|DMA_FLAG_USE
#if XE_NP_NP2_SD_LINKED_COPY_TEST
                   |DMA_FLAG_TO
#endif
                   )) ||
           (uint32_t)(HAL_GetTick()-overflow_started_ms)>=100U){
            fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,0xD810U);return;
        }
        if(spill_dma_bytes){
            if(!(flags&DMA_FLAG_TC)){
#if XE_NP_NP2_LIVE_SD_COPY_COST_DIAG
                copy_cost_non_tc(cost_before);
#endif
                return;
            }
#if XE_NP_NP2_SD_COPY_WAKE_TEST || XE_NP_NP2_SD_COPY_IDLE_GUARD_TEST
            /* TC can precede HAL's FULL-transfer IDLE condition. Never turn
             * early TC into timeout0/abort or publish a still-owned RU, even
             * when the optional copy wake IRQ is not used. */
            if(!(flags&DMA_FLAG_IDLE) || (GPDMA1_Channel14->CCR&DMA_CCR_EN) ||
               GPDMA1_Channel14->CBR1){
#if XE_NP_NP2_SD_COPY_WAKE_TEST
                xe_np_np2_copy_wake_diag[3]++;
#endif
                return;
            }
#if XE_NP_NP2_SD_COPY_WAKE_TEST
            spill_wake_disarm();
#endif
#endif
            if(HAL_DMA_PollForTransfer(&spill_dma,HAL_DMA_FULL_TRANSFER,0U)!=HAL_OK ||
               (GPDMA1_Channel14->CCR&DMA_CCR_EN) || GPDMA1_Channel14->CBR1
#if XE_NP_NP2_SD_LINKED_COPY_TEST
               || spill_dma.ErrorCode!=HAL_DMA_ERROR_NONE
#endif
               ){
                fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,0xD811U);return;
            }
#if XE_NP_NP2_LIVE_SD_COPY_COST_DIAG
            copy_cost_leg_complete();
#endif
            __DMB();spill_copy+=spill_dma_bytes;spill_dma_bytes=0U;
            xe_np_np2_overflow_dma_diag[7]++;
        }
        /* An error never pops the FIFO or frees the retained COPY owner. */
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
        if(grid16.requested && !grid16_copy_owned()){
            fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0x47313638U);return;
        }
#endif
        if(spill_copy==RU_BYTES){
#if XE_NP_NP2_LIVE_SD_RESTORE_CHAIN_TEST
            restore_only=overflow_kind==2U;
#endif
            if(overflow_kind==1U){
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
                if(SESSION_RUNTIME_DIRECT && overflow_ru>=NP2_RUNTIME_DIRECT_CAPTURE_RUS){
                    fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD971U);return;
                }
#endif
                spill_sequence[spill_head]=ru_first_block[overflow_ru];
#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
                spill_parts[spill_head]=ru_parts[overflow_ru];
#endif
                __DMB();spill_head=(spill_head+1U)%SPILL_SLOTS;spill_count++;
                ru_state[overflow_ru]=RU_FREE;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
                if(SESSION_RUNTIME_DIRECT)runtime_direct_retire_pending=1U;
#endif
                xe_np_np2_overflow_dma_diag[2]++;
                maximum(&xe_np_np2_overflow_dma_diag[4],spill_count);
            }else{
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
                if(SESSION_RUNTIME_DIRECT && overflow_ru<NP2_RUNTIME_DIRECT_CAPTURE_RUS){
                    fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD972U);return;
                }
#endif
                if(invalidate_if_cacheable(ru[overflow_ru],RU_BYTES)){
                    fail(XE_NP_NP2_LIVE_SD_ERROR_CACHE,0xD812U);return;
                }
#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
                ru_parts[overflow_ru]=spill_parts[spill_tail];
#endif
                __DMB();ru_state[overflow_ru]=RU_READY;
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
                if(grid16.requested){
                    /* BTC may clear another slot concurrently. DMB alone
                     * cannot make this foreground read/modify/write atomic. */
                    uint32_t key=__get_PRIMASK();__disable_irq();
                    overflow_restored_mask|=(uint16_t)(1U<<overflow_ru);
                    __DMB();__set_PRIMASK(key);
                }else
#endif
                overflow_restored_mask|=(uint16_t)(1U<<overflow_ru);
#endif
                spill_tail=(spill_tail+1U)%SPILL_SLOTS;spill_count--;
                xe_np_np2_overflow_dma_diag[3]++;
            }
            xe_np_np2_overflow_dma_diag[5]=spill_count;
            overflow_kind=0U;overflow_ru=(uint8_t)RU_COUNT;
            if(!dma_active)start_write(); /* Prefer restored head, never replace an in-flight command. */
#if XE_NP_NP2_LIVE_SD_RESTORE_CHAIN_TEST
            /* Admit at most the next restore before packing can intervene.
             * The ordered writer and all ordinary admission guards go first. */
            if(!restore_only || xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED)return;
#else
            return;
#endif
        }
#if XE_NP_NP2_LIVE_SD_RESTORE_CHAIN_TEST
    }
    if(!overflow_kind){
#else
    }else{
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_TEST
        /* No COPY owner/cache operation/timeout starts during an external
         * command, including its setup and card-busy interval. */
        if(dma_active && dma_window_external){
#if XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_DIAG_TEST
            spill_bus_fence_refused(2U);
#if !XE_NP_NP2_LIVE_SD_SPILL_PRESSURE_DIAG_TEST
            spill_bus_fence_early_refused();
#endif
#endif
            return;
        }
#endif
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
        if(grid16.requested){
            if(!grid16_copy_begin())return;
        }else
#endif
        {
        uint32_t free_count=0U;int free_slot=-1;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
        uint32_t capture_free=0U;
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
        uint32_t restored=0U,last_restored=0U;
/* APPEND15_RESTORE_GAP_SLOT_BEGIN */
#if XE_NP_NP2_SD_APPEND15_RESTORE_GAP_TEST
        uint32_t last_restored_slot=RU_COUNT;
#endif
/* APPEND15_RESTORE_GAP_SLOT_END */
#endif
        for(uint32_t i=0U;i<RU_COUNT;i++){
            if(ru_state[i]==RU_FREE){
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
                if(SESSION_RUNTIME_DIRECT && i<NP2_RUNTIME_DIRECT_CAPTURE_RUS)capture_free++;
                else
#endif
                {
                free_count++;if(free_slot<0)free_slot=(int)i;
                }
            }
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
            if(overflow_restored_mask&(1U<<i)){
                restored++;
/* APPEND15_RESTORE_GAP_SCAN_BEGIN */
#if XE_NP_NP2_SD_APPEND15_RESTORE_GAP_TEST
                if(ru_first_block[i]>=last_restored)last_restored_slot=i;
#endif
/* APPEND15_RESTORE_GAP_SCAN_END */
                if(ru_first_block[i]>last_restored)last_restored=ru_first_block[i];
            }
#endif
        }
        /* Keep checked copied-window/append admission unchanged. The private
         * direct-ring trial alone admits a forward FIFO gap; it is not part
         * of the qualified low-rate power policy. */
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
        uint32_t head=spill_count?spill_sequence[spill_tail]:0U;
        uint32_t restore=spill_count && restored<ACTIVE_OVERFLOW_PREFETCH_RUS &&
            (!restored || head==last_restored+BLOCKS_PER_RU ||
/* APPEND15_RESTORE_GAP_ADMIT_BEGIN */
#if XE_NP_NP2_SD_APPEND15_RESTORE_GAP_TEST
             append15_restore_gap(last_restored,head,last_restored_slot) ||
#endif
/* APPEND15_RESTORE_GAP_ADMIT_END */
#if XE_NP_NP2_SD_DUAL20_WINDOW1536_TEST
             fixed_refill_ready_bridge(last_restored,head) ||
#endif
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
             (SESSION_RUNTIME_DIRECT && head>last_restored) ||
#endif
             (XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST && !SESSION_VSC &&
              head<last_restored));
#if XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
        if(copied_window_policy()){
#if XE_NP_NP2_SD_APPEND_COUNTED_PIPELINE_TEST
            if(copied_window.active){
                free_slot=copied_window_append_free();
                restore=spill_count && restored<ACTIVE_OVERFLOW_PREFETCH_RUS && free_slot>=0;
            }
#else
            int destination=copied_window_destination(head);
            restore=spill_count && head==copied_window_next_sequence();
            if(destination>=0){
                /* Reserved publication destinations cannot be spent on later
                 * ingress or an unrelated FIFO owner. Restore the exact next
                 * missing generation, not a future neighbour's address. */
                restore=restore && ru_state[destination]==RU_FREE;
                free_slot=restore?destination:-1;
            }else{
                free_slot=-1;
                for(uint32_t i=0U;i<RU_COUNT;i++)if(ru_state[i]==RU_FREE &&
                   !(copied_window.reserved&(1U<<i))){free_slot=(int)i;break;}
                if(free_slot<0)restore=0U;
            }
#endif
        }
#endif
#if XE_NP_NP2_SD_ORDERED_BATCH3_TEST
        if(SESSION_BATCH3 && restore){
            uint32_t start=fixed_confirmed_blocks+(dma_active?dma_blocks:0U);
            uint32_t target=active_target_rus*RU_BLOCKS;
            if(start>=target)restore=0U;
            else{
                uint32_t first=(start/RU_BLOCKS)*BLOCKS_PER_RU;
                uint32_t blocks=fixed_sequential_blocks(start,target);
                uint32_t last=((start+blocks-1U)/RU_BLOCKS)*BLOCKS_PER_RU;
                if(head<first || head>last)restore=0U;
            }
        }
#endif
#if VSC_PSRAM_IDMA
        if(SESSION_PSRAM_IDMA)restore=0U; /* Published PSRAM feeds IDMA directly. */
#endif
#else
        uint32_t head=(xe_np_np2_live_sd_mailbox.written_rus+
                       (dma_active?dma_units:0U))*BLOCKS_PER_RU;
        uint32_t restore=spill_count && spill_sequence[spill_tail]==head &&
                         ready_sequence(head)<0;
#endif
        if(restore)record_eligibility_point(2U);
        /* Normal prefetch leaves an ingress owner. Sequential fixed may spend
         * its protected sole FREE only to complete the whole next command. */
#if XE_NP_NP2_LIVE_SD_LAST_FREE_PREFETCH_TEST
        int inflight_refill=0;
        if(restore && free_count==1U){
            inflight_refill=fixed_inflight_refill_credit();
            if(inflight_refill<0)return;
        }
#endif
        if((restore && free_count>=2U)
#if XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
           /* An idle ordered command can need a FIFO head while all other
            * RUs hold later generations. Use the last FREE slot for that
            * exact missing head; waiting for two FREE slots deadlocks. */
           || (copied_window_policy() && restore && free_slot>=0 &&
#if XE_NP_NP2_SD_APPEND_COUNTED_PIPELINE_TEST
               copied_window.active &&
#endif
               (!dma_active || (copied_window.active &&
                 (copied_window.reserved&(1U<<(uint32_t)free_slot)))))
#endif
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
           /* Capture has its own fixed eight-RU ring. Its ingress can never
            * use a restore-only slot, so the last of those three is usable. */
           || (SESSION_RUNTIME_DIRECT && restore && free_count)
#endif
#if XE_NP_NP2_LIVE_SD_LAST_FREE_PREFETCH_TEST
           || inflight_refill
#endif
#if (XE_NP_NP2_LIVE_SD_VSC_TEST || XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST) && \
    XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST && \
    XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER && !XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST
           /* A sealed resident RU may bridge the restored-prefix/FIFO head.
            * The helper proves the complete next ordered window; extra FREE
            * slots must not block that refill in either VSC or classic mode. */
           || ((SESSION_VSC || XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST) &&
               free_count && fixed_refill_completes_window())
#endif
           ){
#if XE_NP_PSRAM_HOST_PARK_TEST
            if(XE_NP_Psram_HostParked()){
                fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD849U);return;
            }
#endif
            record_eligibility_point(4U);
            record_power_restore(head,free_count);
            overflow_kind=2U;overflow_ru=(uint8_t)free_slot;
            ru_first_block[overflow_ru]=head;
            ru_state[overflow_ru]=RU_COPY;
            if(clean_invalid_if_cacheable(ru[overflow_ru],RU_BYTES)){
                fail(XE_NP_NP2_LIVE_SD_ERROR_CACHE,0xD813U);return;
            }
        }else{
#if XE_NP_NP2_LIVE_SD_RESTORE_CHAIN_TEST
            if(restore_only)return; /* No chained evacuation or second admission pass. */
#endif
            /* SRAM-first: spill just enough to prevent ring backpressure.
             * Keep the prefetched next-command prefix resident even after the
             * FIFO empties; otherwise spill/restore can thrash that same RU.
             * Keep the oldest contiguous SRAM prefix for the next CMD25:
             * spilling its newest tail frees several SRAM slots before SD
             * reaches an external-head hole. FIFO append stays monotonic. */
            /* OOO keeps a restored head resident: start evacuation with two
             * FREE slots, one ingress RU before the last-slot deadline. No
             * COPY/SD owner is released early; the ordinary policy stays one. */
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
            /* The selected cyclic ring instead counts capture FREE owners
             * only and evacuates its oldest eligible capture blocker below. */
#endif
            if((
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
                SESSION_RUNTIME_DIRECT?capture_free>2U:
#endif
                (free_count>(XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER?2U:1U) && !restore)) ||
               spill_count>=SPILL_SLOTS)return;
#if XE_NP_NP2_SD_SINGLE7500_WINDOW2048_TEST || XE_NP_NP2_SD_DUAL20_WINDOW1536_TEST
            /* Let the last window fragment finish while two real ingress
             * slots remain. Evacuating its READY neighbour here creates a
             * needless PSRAM round trip. Active-SD/one-slot pressure is unchanged. */
            if((fixed_window_shift==11U || ((XE_NP_NP2_SD_TRIPLE7500_WINDOW1536_TEST ||
                XE_NP_NP2_SD_SINGLE_MID_WINDOW1536_TEST || XE_NP_NP2_SD_DUAL20_WINDOW1536_TEST) &&
                fixed_window_shift==FIXED_WINDOW_1536_MODE)) && !dma_active && free_count>=2U)return;
#endif
            int selected=-1;
            uint32_t last=spill_count?spill_sequence[(spill_head+SPILL_SLOTS-1U)%SPILL_SLOTS]:0U;
            for(uint32_t i=0U;i<RU_COUNT;i++)if(ru_state[i]==RU_READY &&
#if XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
               (!copied_window.active || copied_window_destination(ru_first_block[i])<0) &&
#endif
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
               (!SESSION_RUNTIME_DIRECT || i<NP2_RUNTIME_DIRECT_CAPTURE_RUS) &&
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
               !(overflow_restored_mask&(1U<<i)) &&
#else
               (!dma_active || ru_first_block[i]!=head) &&
#endif
               (!spill_count || ru_first_block[i]>last)){
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
                /* Extend an existing FIFO run when its successor is already
                 * READY; never wait for an absent or otherwise owned RU. */
                if(spill_count && ru_first_block[i]-last==BLOCKS_PER_RU){selected=(int)i;break;}
#endif
                if(selected<0 ||
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
                   (SESSION_RUNTIME_DIRECT?ru_first_block[i]<ru_first_block[(uint32_t)selected]:
                    ru_first_block[i]>ru_first_block[(uint32_t)selected])
#else
                   ru_first_block[i]>ru_first_block[(uint32_t)selected]
#endif
                   )selected=(int)i;
            }
            if(selected<0)return;
#if XE_NP_PSRAM_HOST_PARK_TEST
            /* Before COPY ownership, cache work or any PSRAM aperture access. */
            if(resume_parked_psram(0U)){
                fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,0xD841U);return;
            }
#endif
            overflow_kind=1U;overflow_ru=(uint8_t)selected;
            ru_state[overflow_ru]=RU_COPY;
            if(clean(ru[overflow_ru],RU_BYTES)){
                fail(XE_NP_NP2_LIVE_SD_ERROR_CACHE,0xD814U);return;
            }
#if VSC_PSRAM_IDMA
            /* Drain/invalidate old CPU lines before C14 becomes destination
             * owner. No CPU writer/clean may touch the published PSRAM RU. */
            if(SESSION_PSRAM_IDMA && clean_invalid_if_cacheable(spill_address(spill_head),RU_BYTES)){
                fail(XE_NP_NP2_LIVE_SD_ERROR_CACHE,0xD927U);return;
            }
#endif
        }
        }
        overflow_started_ms=HAL_GetTick();spill_copy=spill_dma_bytes=0U;
    }
#if XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_TEST
    /* TC retirement and whole-RU publication above always run. Only a NEW
     * leg waits; HAL command ownership, not a transient DPSMACT bit, gates it. */
    if(dma_active && dma_window_external){
#if XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_DIAG_TEST
        spill_bus_fence_refused(2U);
#endif
        return;
    }
#endif
#if XE_NP_NP2_SD_LINKED_COPY_TEST
    /* A single software owner spans all three physical nodes. Existing final
     * TC/IDLE/EN0/CBR0 retirement publishes the entire RU, never an intermediate node. */
    uint32_t bytes=RU_BYTES;
#else
    uint32_t bytes=RU_BYTES-spill_copy;
    if(bytes>OVERFLOW_COPY_BYTES)bytes=OVERFLOW_COPY_BYTES;
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_LEG_4K_TEST
    uint32_t external_data=dma_active && dma_window_external &&
        (card->Instance->STA&SDMMC_STA_DPSMACT);
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST
    /* HAL acceptance owns the external window before DPSMACT may be visible.
     * Do not launch a new leg through that setup gap or re-arm on a later
     * transient data-active edge; CMD13 retirement closes this command. */
    uint32_t external_window=dma_active && dma_window_external;
    if(xe_np_np2_spill_defer_diag[2]<2U && (xe_np_np2_spill_defer_diag[2]==1U ||
       (external_window && xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_CAPTURING))){
        uint32_t free_count=0U,pressure=0U;
        if(external_window && xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_CAPTURING){
            for(uint32_t i=0U;i<RU_COUNT;i++)free_count+=ru_state[i]==RU_FREE;
            uint64_t latest=0U;
            if(copy_cost_status(&latest)!=0){
                xe_np_np2_spill_defer_diag[4]=HAL_GetTick();
                xe_np_np2_spill_defer_diag[6]=(xe_np_np2_spill_defer_diag[6]&~0xFFU)|4U;
                __DMB();xe_np_np2_spill_defer_diag[2]=4U;
                fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,1U);return;
            }
            /* next_tick includes released partial spans. Preserve a full raw
             * source-RU plus unpublished data AND 2ms ingress below retention.
             * FREE>=2 is necessary, not an assumption about card latency. */
            pressure=spill_defer_pressure(latest,next_tick,free_count,spill_defer_guard_ticks);
        }
        if(spill_defer_new_leg(HAL_GetTick(),xe_np_np2_live_sd_mailbox.state,
                               external_window,pressure,free_count))return;
    }
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_LEG_4K_TEST
    /* Only a NEW leg is shortened. A pending leg was handled above through
     * its real TC; source/whole-RU publication and the100ms owner timeout stay. */
    uint32_t requested=bytes;
    bytes=spill_leg_limit(bytes,external_data);
#endif
    uint8_t *source=overflow_kind==1U?ru[overflow_ru]:spill_address(spill_tail);
    uint8_t *destination=overflow_kind==1U?spill_address(spill_head):ru[overflow_ru];
#if XE_NP_NP2_LIVE_SD_COPY_SPLIT_PORTS_TEST
    if(!spill_copy){
        /* HAL Start retains CTR1. Set only a new whole-RU owner's ports;
         * subsequent legs and pending transfers keep the same direction. */
        if((GPDMA1_Channel14->CCR&(DMA_CCR_EN|DMA_CCR_RESET|DMA_CCR_SUSP)) ||
           GPDMA1_Channel14->CBR1){fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,0xD81AU);return;}
        MODIFY_REG(GPDMA1_Channel14->CTR1,DMA_CTR1_SAP|DMA_CTR1_DAP,
                   overflow_kind==1U?DMA_CTR1_DAP:DMA_CTR1_SAP);
    }
#endif
    __DMB();
#if XE_NP_NP2_LIVE_SD_SPILL_LAUNCH_TRACE_TEST
    spill_launch_trace_pre();
#endif
#if XE_NP_NP2_LIVE_SD_COPY_COST_DIAG
    uint32_t cost_issue=cycles();
#endif
#if XE_NP_NP2_SD_COPY_WAKE_TEST
    if(spill_wake_prepare()){
        fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,0xD81BU);return;
    }
#endif
    if(
#if XE_NP_NP2_SD_LINKED_COPY_TEST
       start_spill_linked_copy(source,destination)!=HAL_OK
#else
       HAL_DMA_Start(&spill_dma,(uint32_t)(uintptr_t)(source+spill_copy),
                     (uint32_t)(uintptr_t)(destination+spill_copy),bytes)!=HAL_OK
#endif
       ){
#if XE_NP_NP2_LIVE_SD_SPILL_LAUNCH_TRACE_TEST
        spill_launch_trace_post(0U);
#endif
        fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,0xD815U);return;
    }
#if XE_NP_NP2_LIVE_SD_SPILL_LAUNCH_TRACE_TEST
    spill_launch_trace_post(1U);
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_LEG_4K_TEST
    xe_np_np2_spill_leg_diag[7]++;
    if(external_data){
        xe_np_np2_spill_leg_diag[5]++;
        maximum(&xe_np_np2_spill_leg_diag[4],bytes);
        if(bytes<requested){
            xe_np_np2_spill_leg_diag[3]++;xe_np_np2_spill_leg_diag[6]+=bytes;
        }
    }
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST
    if(external_window)xe_np_np2_spill_defer_diag[7]++;
#endif
    spill_dma_started=HAL_GetTick();spill_dma_bytes=bytes;
#if XE_NP_NP2_LIVE_SD_COPY_COST_DIAG
    copy_cost_leg_start(cost_issue);
#endif
}
#endif

#include "xe_np_np2_sd_record_sleep.inc"
#if XE_NP_NP2_LIVE_SD_IDLE_SLEEP
static void idle_until_dma_event(void)
{
    /* The high-rate PSSI IRQ and SD DATAEND both wake WFI. Do not sleep
     * through card-programming busy: there is no enabled DAT0-ready IRQ.
     * Mask/recheck/WFI/unmask closes the check-to-sleep interrupt race;
     * an enabled interrupt pending under PRIMASK still wakes the core. */
    uint32_t key=__get_PRIMASK();
#if XE_NP_NP2_SD_RECORD_SLEEP_GATE_TEST
    if(key || __get_IPSR() || __get_BASEPRI() || __get_FAULTMASK() ||
       (SCB->SCR&(SCB_SCR_SLEEPDEEP_Msk|SCB_SCR_SLEEPONEXIT_Msk)))return;
#endif
#if XE_NP_NP2_SD_COPY_WAKE_TEST || XE_NP_NP2_SD_OSPI_SLEEP_GATE_TEST || XE_NP_NP2_SD_INGRESS_DMA_TEST
    if(key || (SCB->SCR&(SCB_SCR_SLEEPDEEP_Msk|SCB_SCR_SLEEPONEXIT_Msk)))return;
#endif
    __disable_irq();
    if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_CAPTURING &&
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
#if XE_NP_NP2_SD_COPY_WAKE_TEST
       (!overflow_kind || (spill_wake_owned && spill_dma_bytes)) &&
#else
       !overflow_kind && /* C14 is polled: no copy IRQ can wake WFI. */
#endif
#endif
       (!dma_active || !irq_return_seen) && !card->ErrorCode &&
       !(card->Instance->STA&(ERROR_FLAGS|SDMMC_STA_BUSYD0))){
        uint64_t latest=0U;
        if(
#if XE_NP_NP2_LIVE_SD_DIRECT
           XE_NP_Np2CapturePort_DirectProgress(&latest)==0 &&
#else
           copy_cost_status(&latest)==0 &&
#endif
           (
#if XE_NP_NP2_LIVE_SD_DIRECT
            latest<next_tick+STREAM_TICKS ||
#else
            latest==next_tick ||
#endif
#if XE_NP_NP2_SD_INGRESS_DMA_TEST
            (ingress_pending && ingress_dma_active) ||
#endif
            (fill_ru==RU_COUNT && find_free()<0))){
#if XE_NP_NP2_SD_INGRESS_DMA_TEST
            if(ingress_pending && !ingress_dma_arm_wake()){
                __set_PRIMASK(key);return;
            }
#endif
#if XE_NP_NP2_SD_COPY_WAKE_TEST
            if(overflow_kind){
                if(!spill_wake_pending()){__set_PRIMASK(key);return;}
                NVIC_EnableIRQ(GPDMA1_Channel14_IRQn);
                __DSB();
                /* DMA may complete before or during IRQ arming. A completion
                 * after this recheck raises an enabled IRQ and wakes WFI. */
                if(!spill_wake_pending()){
                    spill_wake_disarm();__set_PRIMASK(key);return;
                }
                xe_np_np2_copy_wake_diag[1]++;
            }
            xe_np_np2_copy_wake_diag[2]++;
#endif
#if XE_NP_NP2_SD_OSPI_SLEEP_GATE_TEST
            uint32_t ospi_sleep_saved=0U,ospi_sleep_gate=0U;
            if(LIVE_PROBE_MASK==1U && record_sample_hz==7500U){
                /* No DMA/CPU PSRAM access can start while this foreground
                 * sleeps. Keep PSRAM awake for any outstanding copy or bus
                 * transaction; never tear down its mapped/run-clock state. */
                if(!overflow_kind && !spill_dma_bytes &&
                   !(GPDMA1_Channel14->CCR&(DMA_CCR_EN|DMA_CCR_RESET|DMA_CCR_SUSP)) &&
                   !GPDMA1_Channel14->CBR1 && !(OCTOSPI1->CR&OCTOSPI_CR_EN) &&
                   !(OCTOSPI1->SR&OCTOSPI_SR_BUSY) && !(OCTOSPI2->SR&OCTOSPI_SR_BUSY)){
                    ospi_sleep_saved=RCC->AHB2SMENR2;
                    RCC->AHB2SMENR2=ospi_sleep_saved&~RCC_AHB2SMENR2_OCTOSPI2SMEN;
                    ospi_sleep_gate=1U;xe_np_np2_ospi_sleep_gate_diag[0]++;
                }else xe_np_np2_ospi_sleep_gate_diag[1]++;
            }
#endif
#if XE_NP_NP2_SD_RECORD_SLEEP_GATE_TEST
            /* No foreground command can start while masked and asleep.
             * A pending producer interrupt wakes us; restore SD before ISR. */
            uint32_t sd_sleep_saved=sd_record_sleep_enter();
#endif
            __DSB();
#if !XE_NP_NP2_LIVE_SD_NO_WFI_TEST
            record_power_wfi(key);
            __WFI();
#endif
#if XE_NP_NP2_SD_RECORD_SLEEP_GATE_TEST
            if(sd_sleep_saved){
                RCC->AHB2SMENR1=sd_sleep_saved;__DSB();
                xe_np_np2_sd_record_sleep_diag[1]++;
            }
#endif
#if XE_NP_NP2_SD_OSPI_SLEEP_GATE_TEST
            if(ospi_sleep_gate){RCC->AHB2SMENR2=ospi_sleep_saved;__DSB();}
#endif
        }
    }
    __set_PRIMASK(key);
}
#endif

#if XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE
static uint8_t expected(uint32_t position);
#endif

#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
static void cl_startup_accept(uint64_t first)
{
    if(!XE_NP_Np2ClCarrier_PortNeedsProof())return;
    XE_NP_Np2ClStartupReceipt r={0};
    if(XE_NP_Np2ClCaptureProof_Get(&r)!=1){XE_NP_Np2ClCarrier_PortFault();return;}
    r.record_mask=LIVE_PROBE_MASK;r.session=xe_np_np2_dual_sd_app_mailbox.session_id;
#if !XE_NP_NP2_LIVE_SD_DIRECT && !XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST && XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
    r.copied=1U;
#endif
    if(XE_NP_Np2ClCarrier_PortAttest(&r,first,xe_np_np2_live_sd_mailbox.produced_blocks)==1){
        format.phase[2]=r.phase;
        /* Runtime logical RUs already exclude physical SPI-D8 RU4. Every
         * metadata header here is still unpublished; no DMA source is touched. */
        for(uint32_t i=0U;i<RU_COUNT;i++)for(uint32_t b=0U;b<BLOCKS_PER_RU;b++)
            (void)XE_NP_Np2ClCarrier_PatchPhase(ru_block(i,b),r.phase);
    }
}
#endif
static int configure_format(void)
{
    memset(&format,0,sizeof(format));
    format.mclk_hz=record_mclk_hz;format.sample_hz=record_sample_hz;
    format.probe_mask=format.live_probe_mask=LIVE_PROBE_MASK;
    format.flags=XE_NP_NP2_USB_V3_FLAG_UNCALIBRATED_RAW|
        XE_NP_NP2_USB_V3_FLAG_NO_PAYLOAD_CRC|
        XE_NP_NP2_USB_V3_FLAG_HOST_SYNC_CHECK|
        XE_NP_NP2_USB_V3_FLAG_NO_HEADER_CRC;
#if XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE
    format.flags|=XE_NP_NP2_USB_V3_FLAG_SD_SENSOR_TAIL;
#endif
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
    format.flags|=XE_NP_NP2_USB_V3_FLAG_SOURCE_GAPS;
#endif
#if XE_NP_NP2_DIRECT_D8_RAW_PHASE && !XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE
    format.flags|=XE_NP_NP2_USB_V3_FLAG_RAW_D8_PHASE;
    format.d8_phase_bits=0U;format.d8_lookahead_bytes=0U;d8_phase_ready=0U;
#endif
    format.ingress_bytes_per_tick=1U;format.input_ticks=STREAM_TICKS;
    format.stored_bits=LIVE_BITS;format.codec=LIVE_CODEC;
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    format.flags|=XE_NP_Np2ClCarrier_PortFlag(format.probe_mask,format.sample_hz,format.codec,format.flags);
#endif
    for(uint32_t p=0U;p<3U;p++){
        if(!(LIVE_PROBE_MASK&(1U<<p)))continue;
#if XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE
        memcpy(format.serial[p],"SYNTH001",8U);
        memcpy(format.model[p],"NP2013",6U);
#else
        if(XE_NP_Np2UsbSource_GetProbeIdentity(p,format.serial[p],format.model[p]))return -1;
#endif
        format.profile_id[p]=1U;
    }
    /* All format fields except sequence/source tick are immutable. Initialize
     * headers while capture is OFF, then update only 16 bytes per record.
     * No per-record memset, identity serialization or format validation. */
    for(uint32_t i=0U;i<RU_COUNT;i++)for(uint32_t b=0U;b<BLOCKS_PER_RU;b++)
        if(XE_NP_Np2Usb_HeaderV3(ru_block(i,b),0U,0U,0U,&format))return -1;
#if XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE
    /* Preload immutable payloads before starting the timed producer. The
     * foreground later publishes only one sealed RU at a time; no bulk
     * record-then-write phase or payload copy runs during CMD25. */
    uint8_t *payload=ru_block(0U,0U)+512U;
    memset(payload,0,STREAM_PAYLOAD);
    for(uint32_t tick=0U;tick<STREAM_TICKS;tick++){
        uint32_t position=tick%1600U;
        uint8_t symbol=position%100U<4U?expected(position):0U;
        payload[tick]=(uint8_t)(symbol|(symbol<<3U)|((symbol&3U)<<6U));
        payload[STREAM_TICKS+(tick>>3U)]|=(uint8_t)(((symbol>>2U)&1U)<<(tick&7U));
    }
    for(uint32_t i=0U;i<RU_COUNT;i++)for(uint32_t b=0U;b<BLOCKS_PER_RU;b++)
        if(i||b)memcpy(ru_block(i,b)+512U,payload,STREAM_PAYLOAD);
#endif
    __DMB();
    return 0;
}

#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
static void discard_partial_source(void)
{
    next_tick-=partial_ticks;partial_ticks=0U;
}
static int resume_source(uint64_t first)
{
    uint64_t origin=next_tick-partial_ticks;
    if(first<=next_tick || first%STREAM_TICKS || first<=origin ||
       (first-origin)/STREAM_TICKS>UINT32_MAX-xe_np_np2_sd_loss.dropped_blocks)return -1;
    if(xe_np_np2_sd_loss.gap_events==0U){
        volatile uint32_t *d=xe_np_np2_first_gap_diag;
        uint32_t start=cycles(),free_mask=0U,ready_mask=0U,flags=1U;
        uint32_t leg_kind=overflow_kind,leg_bytes=spill_dma_bytes;
        uint32_t leg_age=UINT32_MAX;
        /* Software owns these per-leg fields until foreground TC retirement.
         * HAL tick age is coarse (~1ms), not a physical transfer duration. */
        if((leg_kind==1U || leg_kind==2U) && overflow_ru<RU_COUNT &&
           leg_bytes && spill_copy<=RU_BYTES && leg_bytes<=RU_BYTES-spill_copy){
            uint32_t age=HAL_GetTick()-spill_dma_started;
            if(age!=UINT32_MAX){leg_age=age;flags|=2U;}
        }
        d[0]=0x4732504EU;d[1]=2U;
        d[3]=xe_np_np2_live_sd_mailbox.produced_blocks;
        d[4]=xe_np_np2_live_sd_mailbox.written_rus;
        d[5]=start;d[6]=(uint32_t)origin;d[7]=(uint32_t)(origin>>32U);
        d[8]=(uint32_t)first;d[9]=(uint32_t)(first>>32U);
        for(uint32_t i=0U;i<RU_COUNT;i++){
            free_mask|=(uint32_t)(ru_state[i]==RU_FREE)<<i;
            ready_mask|=(uint32_t)(ru_state[i]==RU_READY)<<i;
        }
        d[10]=free_mask;d[11]=ready_mask;d[12]=spill_count;
        /* Read-only CBR1/CSR snapshots; CFCR is never accessed/cleared. */
        d[13]=GPDMA1_Channel14->CBR1;d[14]=GPDMA1_Channel14->CSR;
        d[15]=(spill_count && spill_tail<SPILL_SLOTS)?spill_sequence[spill_tail]:UINT32_MAX;
        d[16]=leg_kind|((uint32_t)overflow_ru<<8U)|((uint32_t)dma_active<<16U)|((uint32_t)dma_units<<24U);
        d[17]=leg_bytes;d[18]=card->Instance->STA;d[19]=card->Instance->DCOUNT;
        /* write_started precedes hint/CMD23/HAL start: not the CMD25 wire edge. */
        d[20]=leg_age;d[21]=write_started;
        d[22]=partial_ticks;d[23]=cycles()-start;
        __DMB();d[2]=flags;
    }
    xe_np_np2_sd_loss.gap_events++;
    xe_np_np2_sd_loss.dropped_blocks+=(uint32_t)((first-origin)/STREAM_TICKS);
    xe_np_np2_sd_loss.missing_ticks+=first-origin;
    next_tick=first;partial_ticks=0U;return 0;
}
#endif
#if XE_NP_NP2_FIRST_SYNC_ENABLE && (XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST)
static int first_sync_direct_retained(const uint8_t *block,uint32_t bytes,void *user)
{
    (void)user;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    /* The same runtime APP also serves copied one/two-probe profiles. */
    if(!SESSION_RUNTIME_DIRECT)return 1;
#endif
    return block && bytes==XE_NP_NP2_USB_BLOCK_BYTES &&
        XE_NP_Np2CapturePort_FirstSyncRetained((uint32_t)np_first_u64(block+24U));
}
#endif
#if XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE
static void sensor_append_legacy(uint8_t *block)
{
    /* The sensor port owns packet construction and publication. This path only
     * copies a fresh immutable SNS2 packet into a CPU-owned header. */
    uint32_t publication=0U;
    const uint8_t *packet=XE_NP_SensorsPort_GetSdPacket(&publication);
    if(packet && (!sensor_tail_seen || publication!=sensor_tail_publication)){
        memcpy(block+XE_NP_NP2_USB_SD_SENSOR_OFFSET,packet,XE_NP_NP2_USB_SD_SENSOR_BYTES);
        sensor_tail_publication=publication;sensor_tail_seen=1U;
    }else memset(block+XE_NP_NP2_USB_SD_SENSOR_OFFSET,0,XE_NP_NP2_USB_SD_SENSOR_BYTES);
}
#endif
static void finish_block(uint8_t *block,uint64_t first_tick)
{
    uint32_t sequence=xe_np_np2_live_sd_mailbox.produced_blocks;
    XE_NP_Np2Usb_Put64(block+24U,sequence);
    XE_NP_Np2Usb_Put64(block+32U,first_tick);
#if XE_NP_NP2_FIRST_SYNC_ENABLE
    /* All copied, ingress-DMA and direct completed views converge here.
     * Only the direct view can still be overwritten by the capture engine. */
    XE_NP_Np2FirstSyncPort_Private(block,XE_NP_NP2_USB_BLOCK_BYTES,
#if XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
        first_sync_direct_retained,
#else
        NULL,
#endif
        NULL);
#endif
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    XE_NP_Np2ClTicket cl_ticket;
    int cl_claim=XE_NP_Np2ClCarrier_PortClaim(block,&cl_ticket);
    if(cl_claim<0 || !XE_NP_Np2ClCarrier_PortCommit(&cl_ticket))
        memset(block+NP2_CL_CARRIER_SLOT,0,NP2_CL_CARRIER_BYTES);
#endif
#if XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE
    sensor_append_legacy(block);
#endif
    xe_np_np2_live_sd_mailbox.produced_blocks++;
#if XE_NP_NP2_FIRST_SYNC_ENABLE
    /* The ordinary completed-block owner now accepted this private view.
     * No optional framing failure changes neural publication or Stop. */
    XE_NP_Np2FirstSyncPort_Commit(block);
#endif
    partial_ticks=0U;fill_blocks++;
    if(fill_blocks==BLOCKS_PER_RU){
#if XE_NP_NP2_STAGED_CAPTURE
        if(XE_Np2Stage_Seal(&stage_queue)){
            fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xDA30U);return;
        }
        fill_blocks=0U;fill_ru=RU_COUNT;
        maximum(&xe_np_np2_live_sd_mailbox.ring_peak,ring_depth());
#else
#if XE_NP_NP2_LIVE_SD_PSRAM_SPILL
        if(fill_ru==SPILL_FILL){
            __DSB();spill_head=(spill_head+1U)%SPILL_SLOTS;spill_count++;
            xe_np_live_spill_diag[1]++;maximum(&xe_np_live_spill_diag[3],spill_count);
            fill_blocks=0U;fill_ru=RU_COUNT;return;
        }
#endif
        ru_state[fill_ru]=RU_READY;fill_blocks=0U;fill_ru=(uint8_t)RU_COUNT;
        maximum(&xe_np_np2_live_sd_mailbox.ring_peak,ring_depth());
#endif
    }
}

#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
static void capture_runtime_direct(void)
{
    if(runtime_direct_retire())return;
    uint32_t poll_ms=HAL_GetTick();
    if(!direct_progress_poll_valid || poll_ms!=direct_progress_poll_ms){
        direct_progress_poll_ms=poll_ms;direct_progress_poll_valid=1U;
        if(XE_NP_Np2CapturePort_DirectProgress(&produced)){
            fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,1U);return;
        }
    }
    uint32_t sequence=xe_np_np2_live_sd_mailbox.produced_blocks;
    uint32_t target=(sequence/BLOCKS_PER_RU)%NP2_RUNTIME_DIRECT_CAPTURE_RUS;
    if(next_tick!=(uint64_t)sequence*STREAM_TICKS || partial_ticks){
        fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD973U);return;
    }
    if(fill_ru==RU_COUNT){
        /* There is no generic FREE choice: PSSI's next physical destination
         * is fixed. Waiting never pauses DMA or spends a restore-only RU. */
        if(ru_state[target]!=RU_FREE){copy_cost_block(1U);return;}
        fill_ru=(uint8_t)target;ru_first_block[target]=sequence;ru_parts[target]=0U;
        ru_state[target]=RU_FILLING;copy_cost_block(0U);
        maximum(&xe_np_np2_live_sd_mailbox.ring_peak,ring_depth());
    }
    if(fill_ru!=target || fill_blocks!=sequence%BLOCKS_PER_RU ||
       ru_state[target]!=RU_FILLING || ru_first_block[target]!=sequence-fill_blocks){
        fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD974U);return;
    }
    uint8_t *block=ru_block(target,fill_blocks);
#if !defined(XE_NP_NP2_LIVE_SD_NATIVE_MODEL)
    if(block!=XE_NP_Np2DirectBlock(sequence%NP2_DIRECT_SLOTS)){
        fail(XE_NP_NP2_LIVE_SD_ERROR_RING,0xD975U);return;
    }
#endif
    if(!XE_NP_Np2CapturePort_DirectReady((uint32_t)(next_tick+STREAM_TICKS)))return;
    uint32_t began=cycles();
    int ready=XE_NP_Np2CapturePort_DirectPrepare(sequence);
    if(ready<0){fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,5U);return;}
    if(!ready){xe_np_np2_live_sd_perf.prepare_waits++;return;}
    /* The port owns PSSI visibility and the independent phase-normalized D8
     * copy/retention checks. Only the original logical header is touched here. */
    uint64_t first=next_tick;next_tick+=STREAM_TICKS;
    uint32_t took=elapsed(began);
    maximum(&xe_np_np2_live_sd_mailbox.max_capture_cycles,took);
    xe_np_np2_live_sd_perf.capture_calls++;xe_np_np2_live_sd_perf.capture_cycles+=took;
    finish_block(block,first);
}
#endif

#if XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE
static void capture_one(void)
{
    uint32_t sequence=xe_np_np2_live_sd_mailbox.produced_blocks;
    if(sequence>=active_target_blocks)return;
    /* Compare a rolling deadline, not (sequence+1)*period: the latter wraps
     * after 33.55 s at 128 MHz and breaks long synthetic endurance tests. */
    uint32_t lateness=cycles()-synthetic_next_due_cycles;
    if(lateness&0x80000000U)return;
    uint32_t deadline_slack=(uint32_t)SYNTHETIC_BLOCK_CYCLES;
#if XE_NP2_STAGE_DIRECT_PSRAM_IDMA
    /* Physical PSSI DMA buffers four RUs. Permit at most four synthetic
     * blocks of foreground catch-up (one quarter RU), not silent source
     * loss. Every overdue block still needs its exact free ring slot. */
    deadline_slack*=4U;
#endif
    if(lateness>deadline_slack){
        fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,0x5A00U|sequence);return;
    }
    if(fill_ru==RU_COUNT){
#if XE_NP_NP2_STAGED_CAPTURE
        if(!XE_Np2Stage_CanCapture(&stage_queue))return;
        fill_ru=(uint8_t)XE_Np2Stage_SourcePhysicalRu(stage_queue.produced);
#else
        int selected=find_free();
        if(selected<0)return;
        fill_ru=(uint8_t)selected;
        ru_state[fill_ru]=RU_FILLING;
        ru_first_block[fill_ru]=sequence;
        maximum(&xe_np_np2_live_sd_mailbox.ring_peak,ring_depth());
#endif
    }
    uint8_t *block=ru_block(fill_ru,fill_blocks);
    uint64_t first_tick=(uint64_t)sequence*STREAM_TICKS;
    XE_NP_Np2Usb_Put64(block+24U,sequence);
    XE_NP_Np2Usb_Put64(block+32U,first_tick);
    next_tick=first_tick+STREAM_TICKS;
    finish_block(block,first_tick);
    synthetic_next_due_cycles+=(uint32_t)SYNTHETIC_BLOCK_CYCLES;
    xe_np_np2_live_sd_perf.capture_calls++;
}
#else
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
static int store_profile_span(uint8_t *block,const XE_NP_Np2Span *span,uint64_t first)
{
    /* One profile branch per <=16 KiB span, not per sample. The existing
     * packer and SPI phase/copy machinery keep their specialized hot loops. */
    if(LIVE_PROBE_MASK==7U){
#if XE_NP_NP2_LIVE_SD_TRIPLE_COPY_TIMING_DIAG
        uint32_t pssi_began=cycles();
#endif
        memcpy(block+512U+partial_ticks,span->data,span->ticks);
#if XE_NP_NP2_LIVE_SD_TRIPLE_COPY_TIMING_DIAG
        xe_np_np2_live_sd_perf.diagnostic.triple_copy.pssi_copy_cycles+=elapsed(pssi_began);
        uint32_t d8_began=cycles();
        int copied=XE_NP_Np2CapturePort_CopyD8(span->data,first,span->ticks,
            block+512U+STREAM_TICKS+partial_ticks/8U,(STREAM_TICKS-partial_ticks)/8U);
        xe_np_np2_live_sd_perf.diagnostic.triple_copy.d8_copy_cycles+=elapsed(d8_began);
        return copied;
#else
        return XE_NP_Np2CapturePort_CopyD8(span->data,first,span->ticks,
            block+512U+STREAM_TICKS+partial_ticks/8U,(STREAM_TICKS-partial_ticks)/8U);
#endif
    }
    return XE_NP_Np2PackSelectedFrom8(span->data,span->ticks,(uint8_t)LIVE_PROBE_MASK,
        block+512U+partial_ticks*LIVE_BITS/8U,STREAM_PAYLOAD-partial_ticks*LIVE_BITS/8U);
}
#endif
static void capture_one(void)
{
#if XE_NP_NP2_SD_INGRESS_DMA_TEST
    if(ingress_pending){
        uint32_t began=cycles();
        int completed=ingress_dma_poll();
        if(completed<0){fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,0xD832U);return;}
        if(!completed){ingress_work+=elapsed(began);return;}
        uint8_t *destination=ingress_block+512U+partial_ticks;
        if(invalidate_if_cacheable(destination,ingress_span.bytes)){
            fail(XE_NP_NP2_LIVE_SD_ERROR_CACHE,0xD833U);return;
        }
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
        int held=producer->retained(producer->user,&ingress_span);
        if(held==1){discard_partial_source();ingress_pending=0U;return;}
        int released=held==0?producer->release(producer->user):-1;
        if(released==1){discard_partial_source();ingress_pending=0U;return;}
        if(held!=0 || released!=0){
#else
        if(producer->retained(producer->user,&ingress_span)!=0 ||
           producer->release(producer->user)!=0){
#endif
            fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,4U);return;
        }
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
        cl_startup_accept(ingress_span.source_end-ingress_span.ticks);
#endif
#if XE_NP_NP2_CLOSED_LOOP_SPI_ENABLE
        XE_NP_Np2ClosedLoopSpi_PortOfferP3(ingress_block+512U+STREAM_TICKS+partial_ticks/8U,
            ingress_span.ticks/8U,ingress_span.source_end-ingress_span.ticks,record_sample_hz,
            ring_depth()>=RU_COUNT-2U);
#endif
        next_tick=ingress_span.source_end;partial_ticks+=ingress_span.ticks;
        ingress_pending=0U;ingress_work+=elapsed(began);
        maximum(&xe_np_np2_live_sd_mailbox.max_capture_cycles,ingress_work);
        xe_np_np2_live_sd_perf.capture_calls++;
        xe_np_np2_live_sd_perf.capture_cycles+=ingress_work;
        if(partial_ticks==STREAM_TICKS)finish_block(ingress_block,next_tick-STREAM_TICKS);
        return;
    }
#endif
    if(xe_np_np2_live_sd_mailbox.produced_blocks>=active_target_blocks)return;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(SESSION_RUNTIME_DIRECT){capture_runtime_direct();return;}
#endif
#if XE_NP_NP2_LIVE_SD_DIRECT
    uint32_t poll_ms=HAL_GetTick();
    if(!direct_progress_poll_valid || poll_ms!=direct_progress_poll_ms){
        direct_progress_poll_ms=poll_ms;
        direct_progress_poll_valid=1U;
        if(XE_NP_Np2CapturePort_DirectProgress(&produced)!=0){fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,1U);return;}
    }
#endif
    if(fill_ru==RU_COUNT){
#if XE_NP_NP2_STAGED_CAPTURE
        if(!XE_Np2Stage_CanCapture(&stage_queue)){
#if !XE_NP_NP2_LIVE_SD_DIRECT
            if(copy_cost_status(&produced)!=0)
                fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,1U);
#endif
            return;
        }
        fill_ru=(uint8_t)XE_Np2Stage_SourcePhysicalRu(stage_queue.produced);
#else
        int selected=find_free();
        /* A full SD queue is backpressure, not yet data loss: leave samples
         * in the acquisition ring. Its producer guard detects actual loss. */
        if(selected<0){
            copy_cost_block(1U);
#if !XE_NP_NP2_LIVE_SD_DIRECT
#if XE_NP_NP2_LIVE_SD_SPILL_PRESSURE_DIAG_TEST
            spill_bus_fence_pressure_refused();
#endif
            if(copy_cost_status(&produced)!=0){
                fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,1U);
            }
#endif
            return;
        }
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE && XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
        /* Retain a real SRAM restore destination near a full FIFO. PSSI and
         * its normal best-effort loss accounting continue without waiting. */
        if(grid16.requested && spill_count>=SPILL_SLOTS-1U){
            uint32_t free_count=0U;
            for(uint32_t i=0U;i<RU_COUNT;i++)free_count+=ru_state[i]==RU_FREE;
            if(free_count<=2U){
                copy_cost_block(2U);
                if(copy_cost_status(&produced)!=0)fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,1U);
                return;
            }
        }
#endif
#if (XE_NP_NP2_LIVE_SD_VSC_TEST || XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST) && \
    XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST && \
    XE_NP_NP2_LIVE_SD_OVERFLOW_DMA && XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER && \
    !XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST
        if(!SESSION_PSRAM_IDMA && (SESSION_VSC || XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST) &&
           xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_CAPTURING && spill_count){
            /* BTC turns one future SD credit into one FREE slot. Snapshot
             * both together so that an IRQ cannot count that return twice.
             * No producer/HAL operation runs in this bounded owner scan. */
            uint32_t key=__get_PRIMASK();__disable_irq();
            uint32_t reserve=fixed_refill_reserve(),free_count=0U;
            if(reserve)for(uint32_t i=0U;i<RU_COUNT;i++)free_count+=ru_state[i]==RU_FREE;
            __set_PRIMASK(key);
            if(reserve && free_count<=reserve){
                copy_cost_block(2U); /* PRIMASK was already restored above. */
                /* Leave these RUs unclaimed for foreground spill/refill.
                 * Never hide a terminal raw-ring error while waiting. */
                if(copy_cost_status(&produced)!=0){
                    fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,1U);return;
                }
#if XE_NP_NP2_SD_ORDERED_BATCH3_TEST
                /* Refill reservations must not strand actual FREE SRAM while
                 * raw data approaches retention. Admit the selected real FREE
                 * ingress owner, independent of SD/COPY progress or credits.
                 * Ordinary take/retained/release and loss guards still apply. */
                const uint64_t margin=(uint64_t)XE_NP_NP2_UNPUBLISHED_BOUND+
                    (uint64_t)BLOCKS_PER_RU*STREAM_TICKS;
                if(!SESSION_BATCH3 || margin>=XE_NP_NP2_RETENTION_LIMIT ||
                   produced<next_tick || produced-next_tick<XE_NP_NP2_RETENTION_LIMIT-margin ||
                   !free_count)return;
#else
                return;
#endif
            }
        }
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA && XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER && \
    !XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST
        /* Let a second real BTC release admit the oldest external restore.
         * Never spend the sole ingress slot on a restore, or reserve it after
         * IDMA has exhausted its owned RUs. High raw backlog takes priority. */
        if(!SESSION_PSRAM_IDMA && spill_count && spill_sequence[spill_tail]==
               xe_np_np2_live_sd_mailbox.written_rus*BLOCKS_PER_RU &&
           !overflow_kind && !overflow_restored_mask && dma_active && !irq_return_seen &&
#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
           (dma_complete_mask&~((1U<<sd_ll_retired_rus)-1U)) &&
#else
           sd_ll_retired_rus<dma_units &&
#endif
           (card->Context&SD_CONTEXT_DMA) &&
           (card->Instance->IDMACTRL&1U) && card->Instance->DCOUNT){
            uint32_t free_count=0U;
            for(uint32_t i=0U;i<RU_COUNT;i++)free_count+=ru_state[i]==RU_FREE;
            if(free_count==1U){
                if(copy_cost_status(&produced)!=0){
                    fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,1U);return;
                }
                /* Keep one full source RU plus the existing unpublished
                 * bound below retention; retry admission on the next turn. */
                const uint64_t reserve_ticks=(uint64_t)XE_NP_NP2_UNPUBLISHED_BOUND+
                    (uint64_t)BLOCKS_PER_RU*STREAM_TICKS;
                if(reserve_ticks<XE_NP_NP2_RETENTION_LIMIT && produced>=next_tick &&
                   produced-next_tick<(uint64_t)XE_NP_NP2_RETENTION_LIMIT-reserve_ticks){
                    copy_cost_block(3U);return;
                }
            }
        }
#endif
        copy_cost_block(0U);
        fill_ru=(uint8_t)selected;
#if XE_NP_NP2_LIVE_SD_PSRAM_SPILL
        if(fill_ru==SPILL_FILL){
            spill_sequence[spill_head]=xe_np_np2_live_sd_mailbox.produced_blocks;
            for(uint32_t b=0U;b<BLOCKS_PER_RU;b++)
                if(XE_NP_Np2Usb_HeaderV3(spill_address(spill_head)+b*STREAM_BYTES,0U,0U,0U,&format)){
                    fail(XE_NP_NP2_LIVE_SD_ERROR_ARGUMENT,SPILL_FILL);return;
                }
        }else
#endif
        {
        ru_state[fill_ru]=RU_FILLING;
        ru_first_block[fill_ru]=xe_np_np2_live_sd_mailbox.produced_blocks;
#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
        ru_parts[fill_ru]=0U;
#endif
        maximum(&xe_np_np2_live_sd_mailbox.ring_peak,ring_depth());
        }
#endif
    }
#if XE_NP_NP2_LIVE_SD_DIRECT
    uint32_t sequence=xe_np_np2_live_sd_mailbox.produced_blocks;
    uint32_t end_tick_low=(uint32_t)next_tick+STREAM_TICKS;
    if(!XE_NP_Np2CapturePort_DirectReady(end_tick_low))return;
    uint64_t end=next_tick+STREAM_TICKS;
    uint32_t began=cycles();
    int ready=XE_NP_Np2CapturePort_DirectPrepare(sequence);
    if(ready<0){fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,5U);return;}
    if(!ready){xe_np_np2_live_sd_perf.prepare_waits++;return;}
#if XE_NP_NP2_DIRECT_D8_RAW_PHASE
    if(!d8_phase_ready){
        uint32_t phase=xe_np_np2_spi2_d8_diag.calibrated_offset_bits;
        if(phase>=1600U){fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,7U);return;}
        format.d8_phase_bits=phase;
        format.d8_lookahead_bytes=XE_NP_Np2DirectD8LookaheadBytes(phase);
        d8_phase_ready=1U;
    }
#endif
    /* DirectPrepare only succeeds after the producer has published the full
     * PSSI block and the SPI2 lane has the calibrated lookahead. Capture DMA,
     * PSSI overrun, clocks and power are checked in the owned half-node IRQ;
     * do not take a second full HAL/clock/GPIO snapshot here just to refresh
     * `produced` (the value is no longer consumed below). */
    next_tick=end;
    uint32_t capture_cycles=elapsed(began);
    maximum(&xe_np_np2_live_sd_mailbox.max_capture_cycles,capture_cycles);
    xe_np_np2_live_sd_perf.capture_calls++;
    xe_np_np2_live_sd_perf.capture_cycles+=capture_cycles;
    finish_block(ru_block(fill_ru,fill_blocks),end-STREAM_TICKS);
#else
    XE_NP_Np2Span span={0};
    uint32_t maximum_ticks=STREAM_TICKS-partial_ticks;
    if(maximum_ticks>16384U)maximum_ticks=16384U;
    /* The bound PSSI driver's take() snapshots clock/DMA/IRQ/retention before
     * lending, including an empty take. Avoid a duplicate status snapshot
     * here; backpressure above still checks health when no take is possible.
     * The post-pack retained check remains mandatory before publication. */
    int got=producer->take(producer->user,maximum_ticks,&span);
    if(got<0){capture_span_subcheck(5U);fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,2U);return;}
    if(!got)return;
    uint32_t began=cycles();
    capture_span_point(1U,began);
    uint64_t first=span.source_end-span.ticks;
    if(!span.data || span.bytes!=span.ticks || !span.ticks || (span.ticks&127U) ||
       span.ticks>maximum_ticks
#if !XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
       || first!=next_tick
#endif
       ){
        capture_span_subcheck(4U);
        fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,3U);return;
    }
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
    if(first!=next_tick && resume_source(first)){
        fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,3U);return;
    }
#endif
    uint8_t *block=
#if XE_NP_NP2_LIVE_SD_PSRAM_SPILL
        capture_block();
#else
        ru[fill_ru]+fill_blocks*STREAM_BYTES;
#endif
    producer->invalidate(producer->user,span.data,span.bytes);
#if XE_NP_NP2_SD_BLE_ENABLE
    if(xe_np_np2_preview_active)
        XE_NP_Np2SdBle_PreviewTap(span.data,span.bytes,first,ring_depth()>=RU_COUNT-2U);
#endif
    int stored=0;
#if XE_NP_NP2_SD_INGRESS_DMA_TEST
    if(LIVE_PROBE_MASK==7U){
        uint8_t *destination=block+512U+partial_ticks;
        if(clean_invalid_if_cacheable(destination,span.bytes)){
            fail(XE_NP_NP2_LIVE_SD_ERROR_CACHE,0xD834U);return;
        }
        ingress_span=span;ingress_block=block;ingress_pending=1U;
        if(ingress_dma_start((uint32_t)(uintptr_t)span.data,
                             (uint32_t)(uintptr_t)destination,span.bytes)){
            fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,0xD831U);return;
        }
        /* SPI D8 goes to separate cache-line-aligned bytes. Its existing
         * copy/phase/retention checks complete before this loan can publish. */
        if(XE_NP_Np2CapturePort_CopyD8(span.data,first,span.ticks,
             block+512U+STREAM_TICKS+partial_ticks/8U,
             (STREAM_TICKS-partial_ticks)/8U)){
            fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,4U);return;
        }
        ingress_work=elapsed(began);return;
    }
#endif
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
    stored=store_profile_span(block,&span,first);
#elif XE_NP_NP2_LIVE_SD_PROBE_MASK == 7U
    /* Copied control only. Direct DMA above already lands PSSI verbatim in
     * its final SD slot. Never pack/unpack PSSI for the three-probe path. */
    memcpy(block+512U+partial_ticks,span.data,span.ticks);
    stored=XE_NP_Np2CapturePort_CopyD8(span.data,first,span.ticks,
       block+512U+STREAM_TICKS+partial_ticks/8U,(STREAM_TICKS-partial_ticks)/8U);
#elif XE_NP_NP2_LIVE_SD_PROBE_MASK == 1U || (XE_NP_NP2_LIVE_SD_PROBE_MASK == 3U && XE_NP_NP2_USB_PACKED_DUAL)
#if XE_NP_NP2_LIVE_SD_PACK_TIMING_DIAG
    uint32_t pack_began=cycles();
#endif
    stored=XE_NP_Np2PackSelectedFrom8(span.data,span.ticks,XE_NP_NP2_LIVE_SD_PROBE_MASK,
        block+512U+partial_ticks*LIVE_BITS/8U,STREAM_PAYLOAD-partial_ticks*LIVE_BITS/8U);
#if XE_NP_NP2_LIVE_SD_PACK_TIMING_DIAG
    /* IRQ-inclusive call interval, including a rejected final call. Counter
     * updates are outside it but inside the existing capture_one interval. */
    uint32_t packed_cycles=elapsed(pack_began);
    xe_np_np2_live_sd_perf.diagnostic.pack.cycles+=packed_cycles;
    xe_np_np2_live_sd_perf.diagnostic.pack.calls++;
    maximum(&xe_np_np2_live_sd_perf.diagnostic.pack.max_cycles,packed_cycles);
#endif
#else
    memcpy(block+512U+partial_ticks,span.data,span.ticks);
#endif
#if XE_NP_NP2_LIVE_SD_COPY_COST_DIAG
    if(stored!=0){
        capture_span_subcheck(1U);fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,4U);return;
    }
    capture_span_point(2U,cycles());
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
    int held=producer->retained(producer->user,&span);
    if(held==1){discard_partial_source();return;}
    if(held!=0){
#else
    if(producer->retained(producer->user,&span)!=0){
#endif
        capture_span_subcheck(2U);fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,4U);return;
    }
    capture_span_point(3U,cycles());
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
    int released=producer->release(producer->user);
    if(released==1){discard_partial_source();return;}
    if(released!=0){
#else
    if(producer->release(producer->user)!=0){
#endif
        capture_span_subcheck(3U);fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,4U);return;
    }
#else
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
    if(stored!=0){fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,4U);return;}
    int held=producer->retained(producer->user,&span);
    if(held==1){discard_partial_source();return;}
    int released=held==0?producer->release(producer->user):-1;
    if(released==1){discard_partial_source();return;}
    if(held!=0 || released!=0){
#else
    if(stored!=0 ||
       producer->retained(producer->user,&span)!=0 || producer->release(producer->user)!=0){
#endif
        fail(XE_NP_NP2_LIVE_SD_ERROR_CAPTURE,4U);return;
    }
#endif
#if XE_NP_NP2_CLOSED_LOOP_SPI_ENABLE
    /* Reuse accepted CopyD8 bytes; never touch live SPI DMA or neural words. */
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    if(LIVE_PROBE_MASK==7U)cl_startup_accept(first);
#endif
    if(LIVE_PROBE_MASK==7U)
        XE_NP_Np2ClosedLoopSpi_PortOfferP3(block+512U+STREAM_TICKS+partial_ticks/8U,
            span.ticks/8U,first,record_sample_hz,ring_depth()>=RU_COUNT-2U);
#endif
    next_tick=span.source_end;partial_ticks+=span.ticks;
    uint32_t capture_cycles=elapsed(began);
    capture_span_point(4U,began+capture_cycles);
    maximum(&xe_np_np2_live_sd_mailbox.max_capture_cycles,capture_cycles);
    xe_np_np2_live_sd_perf.capture_calls++;
    xe_np_np2_live_sd_perf.capture_cycles+=capture_cycles;
    if(partial_ticks==STREAM_TICKS)finish_block(block,next_tick-STREAM_TICKS);
#endif
}
#endif

/* The same fixed D3,6A,59,C5,3E,A7,1D,E4,B2,4F,78,96 SuperSync,
 * expanded once at build time. All callers inspect only slots0..3; ADC
 * payload is still skipped, never learned or treated as a sync symbol. */
static const uint8_t verify_sync[16][4]={
    {7U,0U,5U,1U},{0U,0U,1U,7U},{0U,0U,6U,1U},{0U,0U,6U,1U},
    {0U,0U,3U,0U},{0U,0U,5U,7U},{0U,0U,5U,5U},{0U,0U,1U,6U},
    {0U,0U,7U,2U},{0U,0U,4U,0U},{0U,0U,2U,7U},{0U,0U,2U,6U},
    {0U,0U,3U,3U},{0U,0U,1U,4U},{0U,0U,3U,5U},{0U,0U,3U,4U}
};
static uint8_t expected(uint32_t position)
{return verify_sync[position/100U][position%100U];}

static uint8_t group(const uint8_t *block,uint32_t tick,uint32_t probe)
{
    const uint8_t *payload=block+512U;
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
    if(LIVE_PROBE_MASK==7U){
        uint8_t raw=payload[tick];
        if(probe<2U)return (uint8_t)((raw>>(probe*3U))&7U);
        return (uint8_t)(((raw>>6U)&3U)|
            (((payload[STREAM_TICKS+(tick>>3U)]>>(tick&7U))&1U)<<2U));
    }
#endif
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || XE_NP_NP2_LIVE_SD_PROBE_MASK == 1U || (XE_NP_NP2_LIVE_SD_PROBE_MASK == 3U && XE_NP_NP2_USB_PACKED_DUAL)
    uint32_t bit=tick*LIVE_BITS+probe*3U,index=bit/8U,shift=bit%8U;
    uint32_t raw=payload[index];
    if(shift>5U)raw|=(uint32_t)payload[index+1U]<<8U;
    return (uint8_t)((raw>>shift)&7U);
#else
    uint8_t raw=payload[tick];
    if(probe<2U)return (uint8_t)((raw>>(probe*3U))&7U);
#if XE_NP_NP2_DIRECT_D8_RAW_PHASE
    if(format.flags&XE_NP_NP2_USB_V3_FLAG_RAW_D8_PHASE)
        return (uint8_t)(((raw>>6U)&3U)|
            (XE_NP_Np2DirectD8RawBit(block,tick,format.d8_phase_bits)<<2U));
#endif
    return (uint8_t)(((raw>>6U)&3U)|
        (((payload[STREAM_TICKS+(tick>>3U)]>>(tick&7U))&1U)<<2U));
#endif
}

static int acquire_phase(const uint8_t *block,uint32_t probe,uint16_t *phase)
{
    uint32_t matches=0U,found=0U;
    for(uint32_t candidate=0U;candidate<1600U;candidate++){
        uint8_t good=1U;
        for(uint32_t tick=0U;tick<4800U && good;tick++){
            uint32_t position=(tick+candidate)%1600U;
            if(position%100U<4U && group(block,tick,probe)!=expected(position))good=0U;
        }
        if(good){found=candidate;matches++;}
    }
    if(matches!=1U){
        /* Failure-only readback diagnostics. These mailbox words are not
         * touched during capture or CMD25 service. 0x5652 identifies a
         * verifier fault, stage 1 means phase acquisition, and the low byte
         * names the probe. */
        xe_np_np2_live_sd_mailbox.phase0=0x56520100U|probe;
        xe_np_np2_live_sd_mailbox.phase1=matches;
        xe_np_np2_live_sd_mailbox.phase2=found;
        return -1;
    }
    *phase=(uint16_t)found;return 0;
}

static int check_window(const uint8_t *block,uint64_t source,uint32_t probe,
                        uint32_t begin,uint32_t count)
{
    uint32_t end=begin+count;
    uint32_t position=(uint32_t)((source+begin+verify_phase[probe])%1600U);
    uint32_t frame=position/100U,within=position%100U;
    /* Inspect every framing/SuperSync bit, including the middle of each
     * block. Skip ADC samples arithmetically; no per-tick 64-bit division. */
    for(uint32_t tick=begin;tick<end;){
        if(within<4U){
            uint8_t wanted=verify_sync[frame][within],actual=group(block,tick,probe);
            if(actual!=wanted){
                /* Stage 2 reports the first mismatching tick, with expected
                 * and observed 3-bit groups packed into phase2. */
                xe_np_np2_live_sd_mailbox.phase0=0x56520200U|probe;
                xe_np_np2_live_sd_mailbox.phase1=tick;
                xe_np_np2_live_sd_mailbox.phase2=((uint32_t)wanted<<8U)|actual;
                return -1;
            }
            tick++;within++;
        }else{
            tick+=100U-within;within=0U;frame=(frame+1U)&15U;
        }
    }
    return 0;
}

static int verify_block(const uint8_t *block,uint32_t sequence)
{
    uint64_t source=(uint64_t)sequence*STREAM_TICKS;
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
    uint64_t actual;memcpy(&actual,block+32U,sizeof(actual));
    if(actual<source || actual%STREAM_TICKS ||
       actual-source>xe_np_np2_sd_loss.missing_ticks || (!sequence && actual))return -1;
    source=actual;
#endif
    uint8_t header[XE_NP_NP2_USB_HEADER_BYTES];
    if(XE_NP_Np2Usb_HeaderV3(header,sequence,source,0U,&format)!=0)return -1;
    uint32_t lookahead=format.d8_lookahead_bytes;
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    /* Known optional metadata region only. Event validation/export failures
     * affect CL quality, never verified NP payload; all other bytes stay strict. */
    if(format.flags&XE_NP_NP2_USB_V3_FLAG_CLOSED_LOOP)lookahead=72U;
#endif
    if(lookahead>NP2_DIRECT_D8_LOOKAHEAD_MAX ||
       memcmp(block,header,NP2_DIRECT_D8_LOOKAHEAD_OFFSET) ||
       memcmp(block+NP2_DIRECT_D8_LOOKAHEAD_OFFSET+lookahead,
               header+NP2_DIRECT_D8_LOOKAHEAD_OFFSET+lookahead,
               XE_NP_NP2_USB_HEADER_BYTES-NP2_DIRECT_D8_LOOKAHEAD_OFFSET-lookahead))return -1;
#if XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE
    /* Synthetic records deliberately reuse one immutable payload. Compare
     * every readback byte against the retained template in RU1; the header
     * comparison above still enforces per-block sequence and source tick. */
    return memcmp(block+512U,ru_block(1U,0U)+512U,STREAM_PAYLOAD)?-2:0;
#else
    if(!verify_phase_ready){
        for(uint32_t p=0U;p<3U;p++)if((LIVE_PROBE_MASK&(1U<<p)) && acquire_phase(block,p,&verify_phase[p]))return -2;
        verify_phase_ready=1U;
        xe_np_np2_live_sd_mailbox.phase0=verify_phase[0];
        xe_np_np2_live_sd_mailbox.phase1=verify_phase[1];
        xe_np_np2_live_sd_mailbox.phase2=verify_phase[2];
    }
    for(uint32_t p=0U;p<3U;p++)if((LIVE_PROBE_MASK&(1U<<p)) && check_window(block,source,p,0U,STREAM_TICKS))return -2;
#if XE_NP_NP2_SD_BLE_ENABLE
    /* Stopped verification preview currently accepts packed6, not raw9.
     * Live preview taps the original PSSI ring before either storage codec. */
    if(LIVE_CODEC==XE_NP_NP2_USB_V3_CODEC_PACKED && LIVE_BITS==6U)
        XE_NP_Np2SdBle_PreviewVerify(block+512U,source,STREAM_TICKS);
#endif
    return 0;
#endif
}

#if XE_NP_NP2_LIVE_SD_VERIFY_READ_RETRY_TEST
static int verify_retry_idle(void)
{
    return card_idle() && card->Context==SD_CONTEXT_NONE &&
           !(card->Instance->STA&SDMMC_STA_BUSYD0) && !(card->Instance->DCTRL&1U);
}

static void verification_read_retry(uint32_t sequence)
{
    volatile uint32_t *d=xe_np_np2_verify_retry_diag;
    d[0]=0x56525244U;d[1]=1U;d[2]=1U;d[4]=sequence;
    d[5]=record_start_lba+verify_ru*RU_BLOCKS;
    d[6]=d[7]=card->Instance->CLKCR;
    d[8]=d[9]=d[14]=d[15]=UINT32_MAX;
    XE_NP_Np2UsbSourceStatus source={0};XE_NP_Np2UsbSource_GetStatus(&source);
    if(source.state!=XE_NP_NP2_USB_SOURCE_STOPPED || XE_NP_Np2CapturePort_Armed() ||
       dma_active || fill_ru!=RU_COUNT || partial_ticks || fill_blocks ||
       overflow_kind || spill_count || (GPDMA1_Channel14->CCR&DMA_CCR_EN) ||
       xe_np_np2_live_sd_mailbox.written_rus!=active_target_rus ||
       verify_ru>=active_target_rus || d[5]<record_start_lba || d[5]>record_end_lba ||
       record_end_lba-d[5]<RU_BLOCKS){d[3]=1U;goto done;}
    for(uint32_t i=0U;i<RU_COUNT;i++)if(ru_state[i]!=RU_FREE){d[3]=1U;goto done;}
#ifndef XE_NP_NP2_LIVE_SD_NATIVE_MODEL
    if((PSSI->CR&(PSSI_CR_ENABLE|PSSI_CR_DMAEN)) ||
       ((GPDMA1_Channel12->CCR|GPDMA1_Channel9->CCR)&DMA_CCR_EN) ||
       (SPI2->CR1&SPI_CR1_SPE) || (SPI2->CFG1&SPI_CFG1_RXDMAEN) ||
       (RCC->CFGR1&RCC_CFGR1_MCOSEL)!=RCC_MCO1SOURCE_NOCLOCK){d[3]=1U;goto done;}
#endif
    if(!verify_retry_idle() || (d[6]&SDMMC_CLKCR_CLKDIV) || card->Init.ClockDiv){d[3]=2U;goto done;}
    uint32_t original_div=card->Init.ClockDiv;
    for(uint32_t attempt=0U;attempt<2U;attempt++){
        if(!verify_retry_idle()){d[3]=4U;d[2]=4U;break;}
        if(clean(ru[attempt+1U],RU_BYTES)){d[3]=3U;d[2]=4U;break;}
        if(attempt){card->Init.ClockDiv=2U;MODIFY_REG(card->Instance->CLKCR,SDMMC_CLKCR_CLKDIV,2U);__DSB();}
#if XE_NP_BOARD_SD_DMA_READ_POLLING_ENABLE || XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U
        d[8U+attempt]=XE_NP_Board_SdReadBlocksDmaPolling(card,ru[attempt+1U],d[5],RU_BLOCKS,3000U);
#else
        d[8U+attempt]=HAL_SD_ReadBlocks(card,ru[attempt+1U],d[5],RU_BLOCKS,3000U);
#endif
        d[10U+attempt]=card->ErrorCode;
        if(d[8U+attempt]!=HAL_OK || card->ErrorCode || !verify_retry_idle()){
            d[3]=4U;d[2]=4U;break;
        }
        for(uint32_t at=0U;at<RU_BYTES;at++)if(ru0[at]!=ru[attempt+1U][at]){
            if(!d[12U+attempt])d[14U+attempt]=at;
            d[12U+attempt]++;
        }
        d[2]=attempt?3U:2U;
    }
    /* Never change clocks while an unsuccessful read still owns the engine.
     * Its error/ownership remain visible; ordinary finalization may refuse. */
    if(verify_retry_idle()){
        card->Init.ClockDiv=original_div;WRITE_REG(card->Instance->CLKCR,d[6]);__DSB();
    }
done:
    d[7]=card->Instance->CLKCR;
    (void)clean((void *)d,sizeof(xe_np_np2_verify_retry_diag));
}
#endif

void XE_NP_Np2LiveSd_VerifyBleService(SD_HandleTypeDef *input)
{
#if XE_NP_NP2_SD_BLE_ENABLE && XE_NP_NP2_DUAL_SD_APP_ENABLE
    if(input!=card || xe_np_np2_dual_sd_app_mailbox.state!=XE_NP_NP2_DUAL_SD_FINALIZING)return;
    if(xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_VERIFYING
#if XE_NP_NP2_LIVE_SD_VERIFY_READ_RETRY_TEST
       /* The failure-only reader has already admitted its stopped, drained
        * buffers. Its original rejection remains sticky while STATUS runs. */
       && !(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED &&
            (xe_np_np2_live_sd_mailbox.error==XE_NP_NP2_LIVE_SD_ERROR_HEADER ||
             xe_np_np2_live_sd_mailbox.error==XE_NP_NP2_LIVE_SD_ERROR_WIRE))
#endif
       )return;
    XE_NP_Np2UsbSourceStatus source={0};XE_NP_Np2UsbSource_GetStatus(&source);
    if(source.state!=XE_NP_NP2_USB_SOURCE_STOPPED || XE_NP_Np2CapturePort_Armed())return;
    /* FINALIZING rejects storage/mode/START mutations. Only the existing BLE
     * foreground transport runs here, never AppService or another SD read. */
    XE_NP_Np2SdBle_Service();
#else
    (void)input;
#endif
}

static void service_verify(void)
{
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
    /* The legacy verifier maps RU n to a contiguous NN-only LBA.  Grid16
     * inserts K sectors between groups, so it is explicitly unavailable until
     * a physical group-aware reader is supplied by the host path. */
    if(grid16.requested){fail(XE_NP_NP2_LIVE_SD_ERROR_ARGUMENT,0x47313630U);return;}
#endif
#if XE_NP_NP2_LIVE_SD_VERIFY_CLOCK_DIV != 0U
    /* Capture/write remains at the qualified high-speed profile. Once every
     * CMD25 has retired and the card is idle, lower only the host clock for
     * the destructive-free post-record readback. This separates read timing
     * margin from the peak recording clock without touching the card mode. */
    if(!verify_clock_reduced){
        if(!card_idle())return;
        card->Init.ClockDiv=XE_NP_NP2_LIVE_SD_VERIFY_CLOCK_DIV;
        MODIFY_REG(card->Instance->CLKCR,SDMMC_CLKCR_CLKDIV,
                   XE_NP_NP2_LIVE_SD_VERIFY_CLOCK_DIV);
        __DSB();verify_clock_reduced=1U;
    }
#endif
    if(verify_ru>=active_target_rus){
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
        if(SESSION_APPEND && XE_NP_Np2SdAppendCoverage_Complete(&append_coverage)){
            fail(XE_NP_NP2_LIVE_SD_ERROR_HEADER,0xD943U);return;
        }
#endif
        xe_np_np2_live_sd_mailbox.verify_ms=HAL_GetTick()-verify_started_ms;
#if XE_NP_NP2_SD_DUAL20_STATUS_RETRY_TEST
        /* Stopped terminal visibility only; no extra successful-write clean. */
        if(cache && xe_np_np2_overflow_fault_diag[29])
            (void)clean((void *)xe_np_np2_overflow_fault_diag,sizeof(xe_np_np2_overflow_fault_diag));
#endif
        xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_COMPLETE;
        publish();return;
    }
    uint8_t *buffer=ru[0];
    card->ErrorCode=HAL_SD_ERROR_NONE;
    if(
#if XE_NP_BOARD_SD_DMA_READ_POLLING_ENABLE || XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U
       XE_NP_Board_SdReadBlocksDmaPolling(card,buffer,record_start_lba+verify_ru*RU_BLOCKS,RU_BLOCKS,3000U)!=HAL_OK ||
#else
       HAL_SD_ReadBlocks(card,buffer,record_start_lba+verify_ru*RU_BLOCKS,RU_BLOCKS,3000U)!=HAL_OK ||
#endif
       card->ErrorCode){fail(XE_NP_NP2_LIVE_SD_ERROR_READ,verify_ru);return;}
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    uint32_t first_sequence=verify_ru*BLOCKS_PER_RU;
    if(SESSION_APPEND){
        /* Read original 64-bit identity before narrowing. Physical position
         * is not a logical sample number in this explicitly marked layout. */
        uint64_t original;memcpy(&original,buffer+24U,sizeof(original));
        if((original%(uint64_t)BLOCKS_PER_RU) || original>=active_target_blocks ||
           (!verify_ru && original)){
            fail(XE_NP_NP2_LIVE_SD_ERROR_HEADER,0xD944U);return;
        }
        first_sequence=(uint32_t)original;
    }
#endif
    for(uint32_t n=0U;n<BLOCKS_PER_RU;n++){
        uint32_t sequence=
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
            first_sequence+n;
#else
            verify_ru*BLOCKS_PER_RU+n;
#endif
        int result=verify_block(buffer+n*STREAM_BYTES,sequence);
        if(result){fail(result==-2?XE_NP_NP2_LIVE_SD_ERROR_WIRE:
                              XE_NP_NP2_LIVE_SD_ERROR_HEADER,sequence);
#if XE_NP_NP2_LIVE_SD_VERIFY_READ_RETRY_TEST
            /* Failure-only evidence for header or wire corruption. Keep the
             * original rejection/RU0; rereads never qualify the recording. */
            if(!SESSION_APPEND)verification_read_retry(sequence);
#endif
            return;}
        xe_np_np2_live_sd_mailbox.verified_blocks++;
#if XE_NP_NP2_SD_BLE_ENABLE && XE_NP_NP2_DUAL_SD_APP_ENABLE
        XE_NP_Np2LiveSd_VerifyBleService(card);
#endif
    }
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    if(SESSION_APPEND && XE_NP_Np2SdAppendCoverage_Add(&append_coverage,first_sequence)){
        fail(XE_NP_NP2_LIVE_SD_ERROR_HEADER,0xD945U);return;
    }
#endif
    verify_ru++;
}

#if XE_NP_NP2_LIVE_SD_DUAL_SCRATCH_OVERFLOW_DMA
static int scratch_media_admitted(void)
{
    /* One pre-start HIL fence, never capture/service work. Bind this experiment
     * to the attested stopped SanDisk media catalog; reset must not erase a
     * different card or a catalog extended since installation admission. */
    static const uint32_t expected_cid[4]={0x03534453U,0x52353132U,0x876A5D22U,0x6B019A52U};
    static const uint32_t expected_csd[4]={0x400E0032U,0xDB79000EU,0xE6B77F80U,0x0A4040FAU};
    static const uint32_t expected_log[128]={
        [0]=9U,[1]=0xE000U,[2]=0x10800U,[3]=0x45C00U,[4]=0x4D000U,
        [5]=0x82800U,[6]=0x9CC00U,[7]=0xD3400U,[8]=0x10DC00U,[9]=0x145400U,
        [64]=0xE000U,[65]=0x10800U,[66]=0x45C00U,[67]=0x4D000U,
        [68]=0x82800U,[69]=0x9CC00U,[70]=0xD3400U,[71]=0x10DC00U,[72]=0x145400U};
    if(!card || card->SdCard.LogBlockNbr!=1000005632U ||
       memcmp(card->CID,expected_cid,sizeof(expected_cid)) ||
       memcmp(card->CSD,expected_csd,sizeof(expected_csd)) ||
       record_start_lba!=SCRATCH_START_LBA || active_target_blocks!=TARGET_BLOCKS ||
       record_end_lba!=SCRATCH_END_LBA || record_sample_hz!=XE_NP_NP2_LIVE_SD_SAMPLE_HZ ||
       clean(ru[0],1024U))return -1;
    if(XE_NP_Board_SdReadBlocksDmaPolling(card,ru[0],16U,1U,1000U)!=HAL_OK ||
       memcmp(ru[0],"CE_FILESYSTEM_V1",16U) || memcmp(ru[0]+32U,"NP_CE64_1",9U))return -1;
    if(XE_NP_Board_SdReadBlocksDmaPolling(card,ru[0],112U,2U,1000U)!=HAL_OK)return -1;
    /* Journal112 is cleared by commit. Shadow113 legitimately retains the
     * last committed catalog image and must agree with the selected page. */
    for(uint32_t i=0U;i<512U;i++)if(ru[0][i])return -1;
    if(memcmp(ru[0]+512U,expected_log,512U))return -1;
    if(XE_NP_Board_SdReadBlocksDmaPolling(card,ru[0],128U,1U,1000U)!=HAL_OK ||
       memcmp(ru[0],expected_log,512U))return -1;
    return 0;
}
#endif

/* Last existing pre-capture erase only; never updated by capture/SD IRQs.
 * magic/version, state(1 running/2 issued/3 transfer/4 failed), failure
 * (1 HAL/2 card/3 deadline), start/end-exclusive, start-ms/elapsed-ms,
 * HAL result, last CMD13 state, SD error, invocation count. */
volatile uint32_t xe_np_np2_preerase_diag[12]={0x4550324EU,1U};
static int preerase(void)
{
    uint32_t started=HAL_GetTick();
    volatile uint32_t *d=xe_np_np2_preerase_diag;
    d[3]=0U;d[4]=record_start_lba;d[5]=record_erase_end_lba;d[6]=started;
    d[7]=d[8]=d[9]=d[10]=0U;d[11]++;d[2]=1U;
    HAL_StatusTypeDef status=HAL_SD_Erase(card,record_start_lba,record_erase_end_lba-1U);
    HAL_SD_CardStateTypeDef state=(HAL_SD_CardStateTypeDef)0;
    int result=-1;uint32_t reason=1U;
    d[8]=(uint32_t)status;
    if(status==HAL_OK){
        d[2]=2U;
        for(;;){
            state=HAL_SD_GetCardState(card);
            if(card->ErrorCode || state==HAL_SD_CARD_ERROR){reason=2U;break;}
            if(state==HAL_SD_CARD_TRANSFER){result=0;reason=0U;break;}
            if(HAL_GetTick()-started>=ERASE_TIMEOUT_MS){reason=3U;break;}
        }
    }
    d[7]=HAL_GetTick()-started;d[9]=(uint32_t)state;d[10]=card->ErrorCode;
    d[3]=reason;d[2]=result?4U:3U;
    return result;
}

#if XE_NP_NP2_SD_VSC_PREERASE60_TEST
static int stopped_vsc_preerase_clock(uint32_t divider)
{
    if(divider>1U || !vsc_feed_active || !card || card->Instance!=SDMMC1 ||
       !card_idle() || card->Context || dma_active || overflow_kind ||
       (card->Instance->DCTRL&SDMMC_DCTRL_DTEN) ||
       (card->Instance->STA&SDMMC_STA_BUSYD0) ||
       XE_NP_Np2CapturePort_Armed() || XE_NP_Np2UsbSource_IsBusy() ||
       XE_NP_Np2UsbSource_IsReady() ||
       HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SDMMC)!=XE_NP_BOARD_SD_PLL2Q_HZ ||
       card->Init.ClockDiv!=(divider?0U:1U) ||
       (card->Instance->CLKCR&SDMMC_CLKCR_CLKDIV)!=(divider?0U:1U))return -1;
    for(uint32_t n=0U;n<16U;n++){
        const DMA_Channel_TypeDef *ch=(const DMA_Channel_TypeDef *)
            ((uintptr_t)GPDMA1_Channel0+0x80U*n);
        if(ch->CCR&(DMA_CCR_EN|DMA_CCR_SUSP|DMA_CCR_RESET))return -1;
    }
    card->Init.ClockDiv=divider;
    MODIFY_REG(card->Instance->CLKCR,SDMMC_CLKCR_CLKDIV,divider);
    __DSB();
    return (card->Instance->CLKCR&SDMMC_CLKCR_CLKDIV)==divider?0:-1;
}
static int preerase_stopped_vsc(void)
{
    if(!vsc_feed_active)return preerase();
    if(stopped_vsc_preerase_clock(1U))return -1;
    /* A failed erase/readiness check keeps its clock and owner intact.
     * Restore the full kernel only after the same strict predicate passes. */
    if(preerase())return -1;
    return stopped_vsc_preerase_clock(0U);
}
#endif

#if XE_NP_NP2_LIVE_SD_STARTUP_PRIME_TEST
static int startup_prime_idle(void)
{
    return card_idle() && card->Context==SD_CONTEXT_NONE &&
        !(card->Instance->STA&(SDMMC_STA_BUSYD0|SDMMC_FLAG_DATAEND|SDMMC_FLAG_IDMABTC)) &&
        !(card->Instance->DCTRL&1U);
}

static int startup_prime(void)
{
    volatile uint32_t *d=xe_np_np2_startup_prime_diag;
    uint32_t started=HAL_GetTick(),units=active_target_rus,accepted=0U,original_error=0U;
    if(units>MAX_WRITE_RUS)units=MAX_WRITE_RUS;
    d[2]=1U;d[5]=units*RU_BLOCKS;d[6]=record_start_lba;
    const volatile XE_NP_Np2DualSdAppMailbox *a=&xe_np_np2_dual_sd_app_mailbox;
    XE_NP_Np2Producer p={0};XE_NP_Np2CapturePort_Diagnostics(&p);
    if(!units || dma_active || producer || fill_ru!=RU_COUNT || fill_blocks || partial_ticks ||
       produced || next_tick || xe_np_np2_live_sd_mailbox.produced_blocks ||
       xe_np_np2_live_sd_mailbox.written_rus || xe_np_np2_live_sd_mailbox.verified_blocks ||
       overflow_kind || spill_count || overflow_restored_mask ||
       !XE_NP_Np2UsbSource_IsReady() || XE_NP_Np2CapturePort_Armed() ||
       p.error || p.state!=XE_NP_NP2_PRODUCER_IDLE || p.borrowed || p.produced || p.consumed ||
       !startup_prime_idle() || NVIC_GetPendingIRQ(SDMMC1_IRQn) ||
       a->magic!=XE_NP_NP2_DUAL_SD_APP_MAGIC || a->state!=XE_NP_NP2_DUAL_SD_PREPARING ||
       a->error || !a->session_id || a->payload_start_lba!=record_start_lba ||
       a->target_blocks!=active_target_blocks || a->committed_blocks || a->writer_verified_blocks ||
       a->card_blocks!=card->SdCard.LogBlockNbr ||
       memcmp((const void *)a->cid,card->CID,sizeof(card->CID)) ||
       a->reservation_start_lba>=record_start_lba || record_end_lba>=a->reservation_end_lba ||
       a->reservation_end_lba>card->SdCard.LogBlockNbr ||
       d[5]>record_end_lba-record_start_lba){d[3]=1U;goto done;}
    for(uint32_t i=0U;i<RU_COUNT;i++)if(ru_state[i]!=RU_FREE){d[3]=1U;goto done;}
#ifndef XE_NP_NP2_LIVE_SD_NATIVE_MODEL
    /* READY has bound the port, not enabled it. Prepared DMAEN alone is harmless. */
    if((PSSI->CR&PSSI_CR_ENABLE) ||
       ((GPDMA1_Channel12->CCR|GPDMA1_Channel9->CCR|GPDMA1_Channel14->CCR)&DMA_CCR_EN) ||
       (SPI2->CR1&SPI_CR1_SPE) || (SPI2->CFG1&SPI_CFG1_RXDMAEN)){
        d[3]=1U;goto done;
    }
#endif
    for(uint32_t i=0U;i<units;i++){
#if XE_NP_NP2_LIVE_SD_STARTUP_PRIME_PATTERN_TEST
        /* Same nonzero pattern as the stopped SD comparator. Once before arm,
         * within the reserved payload; never a recorded frame or hot service. */
        uint32_t *words=(uint32_t *)ru[i];
        for(uint32_t word=0U;word<RU_BYTES/4U;word++)
            words[word]=((record_start_lba+i*RU_BLOCKS+word/128U)*0x9E3779B1UL)^
                        ((word%128U)*0x85EBCA6BUL)^1078373173U;
#else
        memset(ru[i],0,RU_BYTES);
#endif
        dma_slots[i]=(uint8_t)i;
    }
    if(build_sd_linked_list(0U,units)){d[3]=2U;goto done;}
    uint32_t old_irq=NVIC_GetEnableIRQ(SDMMC1_IRQn),old_mask=card->Instance->MASK;
    NVIC_DisableIRQ(SDMMC1_IRQn);__DSB();
    uint32_t command=SDMMC_CmdAppCommand(card->Instance,card->SdCard.RelCardAdd<<16U);
    if(!command)command=SDMMC_CmdBlockCount(card->Instance,d[5]); /* ACMD23 */
    if(!command)command=SDMMC_CmdBlockCount(card->Instance,d[5]); /* mandatory CMD23 */
    if(command){card->ErrorCode=command;d[3]=3U;goto retired;}
    __HAL_SD_CLEAR_FLAG(card,SDMMC_STATIC_FLAGS);
    if(HAL_SDEx_DMALinkedList_WriteBlocks(card,&sd_ll,record_start_lba,d[5])!=HAL_OK){
        d[3]=4U;goto retired;
    }
    accepted=1U;
    uint32_t transfer_started=HAL_GetTick();
    for(;;){
        uint32_t flags=card->Instance->STA;
        if(card->ErrorCode || (flags&ERROR_FLAGS)){
            HAL_SD_IRQHandler(card);d[3]=5U;break;
        }
        if(flags&SDMMC_FLAG_IDMABTC)__HAL_SD_CLEAR_FLAG(card,SDMMC_FLAG_IDMABTC);
        if(flags&SDMMC_FLAG_DATAEND){
            /* Never invoke the live adapter: no recorded buffers/counters are owned.
             * Exact counted completion avoids CMD12; partial/error context stays fatal. */
            if(card->Instance->DCOUNT ||
               card->Context!=(SD_CONTEXT_WRITE_MULTIPLE_BLOCK|SD_CONTEXT_DMA)){
                card->ErrorCode|=HAL_SD_ERROR_DMA;d[3]=5U;
            }else card->Context=SD_CONTEXT_WRITE_SINGLE_BLOCK|SD_CONTEXT_DMA;
            HAL_SD_IRQHandler(card);
            if(card->ErrorCode || !card_idle() || card->Context!=SD_CONTEXT_NONE ||
               (card->Instance->DCTRL&1U))d[3]=5U;
            break;
        }
        if(HAL_GetTick()-transfer_started>=1000U){d[3]=6U;break;}
    }
    if(!d[3]){
        uint32_t busy_started=HAL_GetTick();
        for(;;){
            HAL_SD_CardStateTypeDef state=HAL_SD_GetCardState(card);
            if(card->ErrorCode || state==HAL_SD_CARD_ERROR){d[3]=7U;break;}
            if(state==HAL_SD_CARD_TRANSFER && startup_prime_idle())break;
            if(HAL_GetTick()-busy_started>=1000U){d[3]=7U;break;}
        }
    }
retired:
    original_error=card->ErrorCode;
    if(d[3] && accepted){
        /* This local prime owner never sets dma_active. Retire only an accepted
         * failed prime; HAL may already be READY with stale linked IDMA. Keep
         * the original error as well as any abort error, and never release an
         * active data/command engine or card-busy owner. */
        (void)HAL_SD_Abort(card);card->ErrorCode|=original_error;
        if(!(card->Instance->STA&(SDMMC_STA_DPSMACT|SDMMC_STA_CPSMACT|SDMMC_STA_BUSYD0))){
            card->Instance->DCTRL=0U;card->Instance->DLEN=0U;
            card->Instance->IDMACTRL=0U;__DSB();
        }
    }
    /* A failed active transfer keeps the SD IRQ masked until ordinary fault
     * cleanup. Restore only this experiment's pending line after proven idle. */
    if(startup_prime_idle()){
        card->Instance->MASK=old_mask;NVIC_ClearPendingIRQ(SDMMC1_IRQn);
        if(old_irq)NVIC_EnableIRQ(SDMMC1_IRQn);
    }
done:
    d[4]=HAL_GetTick()-started;
    d[7]=(accepted && d[3])?original_error:(card?card->ErrorCode:0U);
    d[2]=d[3]?255U:2U;__DMB();
    if(clean((void *)d,sizeof(xe_np_np2_startup_prime_diag))){d[3]=8U;d[2]=255U;return -1;}
    return d[3]?-1:0;
}
#endif

#if XE_NP_NP2_LIVE_SD_PROBE_MASK == 3U && XE_NP_NP2_USB_PACKED_DUAL && \
    !XE_NP_NP2_LIVE_SD_DIRECT && !XE_NP_NP2_STAGED_CAPTURE
static int set_capture_stop_limit(uint64_t blocks)
{
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
    /* Finite reservations bound STORED blocks, not elapsed raw ticks after
     * a drop. Bind left the source continuous; the existing foreground stops
     * it when the stored target is sealed. No pause/restart or new IRQ work. */
    (void)blocks;return 0;
#else
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
    /* Triple's calibrated D8 copy needs samples beyond the PSSI boundary.
     * Keep both sources live until foreground seals the last target block;
     * the ordinary service then stops them before draining SD. Bind resets
     * any previous session's IRQ limit, including a warm dual->triple switch. */
    if(LIVE_PROBE_MASK==7U)return 0;
#endif
    return XE_NP_Np2CapturePort_SetStopTicks(blocks*STREAM_TICKS);
#endif
}
#endif

int XE_NP_Np2LiveSd_RequestStop(void)
{
#if XE_NP_NP2_LIVE_SD_PROBE_MASK == 3U && XE_NP_NP2_USB_PACKED_DUAL && \
    !XE_NP_NP2_LIVE_SD_DIRECT && !XE_NP_NP2_STAGED_CAPTURE
    if(!initialized || xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_CAPTURING)
        return -1;
    uint32_t completed=xe_np_np2_live_sd_mailbox.produced_blocks;
    if(completed>active_target_blocks || (partial_ticks && completed==active_target_blocks))
        return -1;
    uint64_t sampled_ticks=0U;
    if(!producer)return -1;
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
    if(grid16.requested && !grid16.stop_prepared){
        /* Reject a bad NP owner/status before sealing IMU. The callback is
         * foreground-only and runs outside the short NP critical section. */
        uint64_t checked_ticks=0U,acquired;uint32_t check_key=__get_PRIMASK();__disable_irq();
        int admitted=producer->status(producer->user,&checked_ticks)==0;
        acquired=((uint64_t)xe_np_np2_live_sd_mailbox.written_rus+
                  (dma_active?dma_units:0U))*BLOCKS_PER_RU;
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
        if(grid16.append)acquired=(uint64_t)grid16_append_ticket()+
            (grid16.active?(uint32_t)dma_units*BLOCKS_PER_RU:
             grid16.pending?(uint32_t)grid16.claimed_groups*BLOCKS_PER_RU:0U);
#endif
        if(acquired>active_target_blocks || (dma_active && !grid16.active))admitted=0;
        __DMB();__set_PRIMASK(check_key);
        if(!admitted)return -1;
        grid16.stop_prepared=1U;grid16.stop_minimum=0U;
        uint32_t minimum=0U;
        if(grid16.prepare_stop(grid16.context,(uint32_t)acquired,active_target_blocks,&minimum))
            grid16.stop_minimum=minimum;
        /* Unknown AUX budget never gates NP Stop; the provider marks that
         * uncertainty in its ordinary quality/footer path. */
    }
#endif
    /* One stopped-command critical section prevents an IRQ publication
     * between choosing the RU boundary and installing it. No copy, cache
     * maintenance or SD transaction occurs here; publish runs after unlock. */
    uint32_t key=__get_PRIMASK();__disable_irq();__DMB();
    if(producer->status(producer->user,&sampled_ticks)!=0){__set_PRIMASK(key);return -1;}
    /* A consumed but incomplete stream block must also be retained. If STOP
     * lands exactly on an RU boundary while a block is in flight, capture
     * one more complete RU. Include all PSSI data already published by DMA,
     * even when the SD packer is behind the source ring at the stop instant. */
    uint64_t needed=(uint64_t)completed+(partial_ticks!=0U);
#if !XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
    uint64_t sampled_blocks=sampled_ticks/STREAM_TICKS+(sampled_ticks%STREAM_TICKS!=0U);
    if(sampled_blocks>needed)needed=sampled_blocks;
#endif
    if(!needed)needed=1U;
#if XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
    /* A finite CMD25 already promised these immutable logical RUs. Finish
     * its at-most12-RU endpoint before normal Stop, never synthesize a tail. */
    if(copied_window.active && needed<(uint64_t)(dma_first_ru+dma_units)*BLOCKS_PER_RU)
        needed=(uint64_t)(dma_first_ru+dma_units)*BLOCKS_PER_RU;
#endif
    uint64_t target=(needed+BLOCKS_PER_RU-1U)&~(uint64_t)(BLOCKS_PER_RU-1U);
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
    /* The sealed IMU producer cannot add more rows during this bounded NP
     * drain. Never extend the existing reservation for an optional backlog. */
    if(grid16.requested && grid16.stop_prepared && grid16.stop_minimum>target){
        target=grid16.stop_minimum;
    }
#endif
    if(target>active_target_blocks || set_capture_stop_limit(target)!=0){
        /* Preserve ordinary NP rejection/ownership semantics. IMU remains
         * sealed and retained; never fake a resume or abort accepted NN work. */
        __DMB();__set_PRIMASK(key);return -1;
    }
    if(target<active_target_blocks){
        active_target_blocks=(uint32_t)target;active_target_rus=(uint32_t)target/BLOCKS_PER_RU;
        xe_np_np2_live_sd_mailbox.target_blocks=(uint32_t)target;
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
        xe_np_np2_live_sd_mailbox.end_lba=grid16.requested?
            record_start_lba+active_target_rus*(RU_BLOCKS+grid16.aux_sectors):
            record_start_lba+active_target_rus*RU_BLOCKS;
#else
        xe_np_np2_live_sd_mailbox.end_lba=record_start_lba+active_target_rus*RU_BLOCKS;
#endif
    }
    __DMB();__set_PRIMASK(key);publish();
    return 0;
#else
    return -1;
#endif
}

int XE_NP_Np2LiveSd_SupportsProfile(uint32_t mask,uint32_t rate)
{
#if XE_NP_NP2_SD_DUAL20_SDR50_96_TEST
    /* Cold card-mode trial only; do not specialize the shared transfer code. */
    volatile uint32_t mode_mask=mask,mode_rate=rate;
    if(mode_mask!=3U || mode_rate!=20000U)return 0;
#endif
#if XE_NP_NP2_SD_HIGH_RATE_KERNEL120_TEST
    /* Keep this boundary experiment out of every other runtime mode without
     * letting the diagnostic constant-specialize the common writer. */
    volatile uint32_t high_mask=mask,high_rate=rate;
    if(!((high_mask==3U && high_rate==30000U) ||
         (high_mask==7U && high_rate==20000U)))return 0;
#endif
#if XE_NP_NP2_SD_SDR50_POWER_TEST
    /* Admission only: do not let the diagnostic constant-specialize the
     * writer and confound a card-mode power comparison with different code. */
    volatile uint32_t power_mask=mask,power_rate=rate;
#if XE_NP_NP2_SD_SINGLE20_SDR50_TEST
    if(power_mask!=1U || power_rate!=20000U)return 0;
#else
    if(power_mask!=3U || power_rate!=15000U)return 0;
#endif
#endif
    if(!XE_NP_Np2DualSd_ProfileTicks(mask,rate))return 0;
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
    /* Stored formats are role-independent; live7.5k additionally needs the
     * coherent48MHz/Q96 clock route before SELECT or START can accept it. */
    return rate!=7500U || XE_NP_Board_Np2ProfileCoreHz(rate,mask)!=0U;
#elif XE_NP_NP2_LIVE_SD_PROBE_MASK==3U && XE_NP_NP2_USB_PACKED_DUAL
    return mask==3U;
#elif XE_NP_NP2_LIVE_SD_PROBE_MASK==7U
    return mask==7U && rate==XE_NP_NP2_LIVE_SD_SAMPLE_HZ;
#else
    return 0;
#endif
}

#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
static uint32_t select_record_profile(uint32_t probe_mask,uint32_t sample_hz)
{
    uint32_t ticks,bits,codec;
    if(!XE_NP_Np2LiveSd_SupportsProfile(probe_mask,sample_hz) ||
       XE_NP_Np2UsbV3_PerformanceProfile(probe_mask,&ticks,&bits,&codec))return 0xE006U;
#if !defined(XE_NP_NP2_LIVE_SD_NATIVE_MODEL)
    /* D8 overlays physical RU4, not the live preview/UART/IMRO tail. */
    if((uintptr_t)ru_pool[4]!=0x2018C800UL ||
       0x2018C800UL+92160U>(uintptr_t)ru_pool[5])return 0xE007U;
#if XE_NP_NP2_SD_RAW_INGRESS_RU_TEST
    /* Extra independent SRAM bank, after raw/config/BLE state and before D8.
     * The private linker gate also proves every input section is disjoint. */
    if((uintptr_t)ru9!=0x2015A060UL || ((uintptr_t)ru9&31U) ||
       (uintptr_t)ru9<0x200D0000UL+XE_NP_NP2_RING_BYTES ||
       (uintptr_t)ru9+RU_BYTES>(uintptr_t)ru_pool[4])return 0xE008U;
#endif
#endif
    record_probe_mask=probe_mask;record_stream_ticks=ticks;
    record_stored_bits=bits;record_codec=codec;
#if !XE_NP_NP2_LIVE_SD_VSC_TEST && !XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST && \
    MAX_WRITE_RUS==6U && XE_NP_NP2_LIVE_SD_WRITE_CAP_RUS==6U
    record_overflow_prefetch_rus=probe_mask==3U && sample_hz==30000U?6U:4U;
#endif
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(XE_NP_Np2RuntimeDirectPssiProfile(probe_mask,sample_hz)){
        active_ru_count=NP2_RUNTIME_DIRECT_CAPTURE_RUS+NP2_RUNTIME_DIRECT_RESTORE_RUS;
        for(uint32_t i=0U;i<NP2_RUNTIME_DIRECT_CAPTURE_RUS;i++){
            ru[i]=ru_pool[i+(i>=4U)];
#if !defined(XE_NP_NP2_LIVE_SD_NATIVE_MODEL)
            if(ru[i]!=XE_NP_Np2DirectBlock(i*BLOCKS_PER_RU))return 0xE009U;
#endif
        }
        for(uint32_t i=0U;i<NP2_RUNTIME_DIRECT_RESTORE_RUS;i++){
            ru[NP2_RUNTIME_DIRECT_CAPTURE_RUS+i]=ru_pool[9U+i];
#if !defined(XE_NP_NP2_LIVE_SD_NATIVE_MODEL)
            if((uintptr_t)ru[NP2_RUNTIME_DIRECT_CAPTURE_RUS+i]!=
               NP2_RUNTIME_DIRECT_RESTORE_BASE+i*RU_BYTES)return 0xE00AU;
#endif
        }
        _Static_assert(NP2_RUNTIME_DIRECT_RESTORE_BASE+NP2_RUNTIME_DIRECT_RESTORE_RUS*RU_BYTES<=
                       0x20184000UL,"Restore-only RUs must fit retired raw capture storage");
    }else
#endif
    {
        active_ru_count=(probe_mask==7U?8U:9U)+XE_NP_NP2_SD_RAW_INGRESS_RU_TEST;
        for(uint32_t i=0U;i<RU_COUNT;i++)
            ru[i]=ru_pool[i+(probe_mask==7U && i>=4U)];
    }
    return 0U;
}
#endif

/* Preparation binds a stopped source before the ordinary Init path resets old
 * writer state. Raw9 may retain the post-target D8 lookahead, so retire it
 * once per completed writer generation before that bind. */
#if XE_NP_NP2_PREPARATION_ENABLE && XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES && !XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE
int XE_NP_Np2LiveSd_RetireStoppedTailForPreparation(void)
{
    if(!initialized || stopped_tail_retired || xe_np_np2_live_sd_mailbox.probe_mask!=7U)return 0;
    if(!format_ready || xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_COMPLETE ||
       xe_np_np2_live_sd_mailbox.error || !active_target_blocks ||
       xe_np_np2_live_sd_mailbox.target_blocks!=active_target_blocks ||
       xe_np_np2_live_sd_mailbox.produced_blocks!=active_target_blocks ||
       xe_np_np2_live_sd_mailbox.written_rus!=active_target_rus)return -1;
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
    if(XE_NP_Np2CapturePort_RetireStoppedTail(next_tick))return -1;
#else
    if(XE_NP_Np2CapturePort_RetireStoppedTail((uint64_t)active_target_blocks*STREAM_TICKS))return -1;
#endif
    stopped_tail_retired=1U;return 0;
}
#elif XE_NP_NP2_PREPARATION_ENABLE
int XE_NP_Np2LiveSd_RetireStoppedTailForPreparation(void)
{return 0;}
#endif

static int init_extent_profile(SD_HandleTypeDef *input,DCACHE_HandleTypeDef *input_cache,
                                uint32_t payload_start_lba,uint32_t block_count,
                                uint32_t probe_mask,uint32_t sample_hz,uint32_t au_blocks,
                                uint32_t allocation_end_lba,uint32_t append_layout)
{
    HAL_SD_CardCSDTypeDef csd;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    /* The port selects the same physical capture map. Never arm that map
     * through a copied/non-append caller or an unprepared allocation. */
    if(XE_NP_Np2RuntimeDirectPssiProfile(probe_mask,sample_hz) &&
       (!append_layout || !au_blocks || !allocation_end_lba ||
        XE_NP_Np2LiveSd_UsesReservedAu(probe_mask,sample_hz,au_blocks,allocation_end_lba)))return -1;
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    /* Refuse an incompatible request without replacing any old session.
     * Catalog v14 admission must be explicit; no layout fallback is safe. */
    if(append_layout && (!input || !input_cache || !au_blocks || !allocation_end_lba ||
       !((probe_mask==3U && sample_hz==30000U) || (probe_mask==7U &&
          (sample_hz==15000U || sample_hz==20000U))) ||
       XE_NP_Np2LiveSd_UsesReservedAu(probe_mask,sample_hz,au_blocks,allocation_end_lba)))return -1;
#else
    (void)append_layout;
#endif
#if XE_NP_PSRAM_HOST_PARK_TEST
    if(XE_NP_Psram_HostParked())return -1; /* Failed cleanup still owns the host. */
#endif
#if !XE_NP_NP2_LIVE_SD_VSC_TEST
    (void)au_blocks;
#endif
    /* A repeated session may reset software only after a completed stopped
     * writer. Never erase live ownership or recover a hardware fault here. */
#if XE_NP_NP2_SD_INGRESS_DMA_TEST
    if(ingress_pending || ingress_dma_owned || ingress_dma_active)return -1;
#endif
    if(initialized){
        if(xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_COMPLETE ||
           input!=card || dma_active || !card_idle())return -1;
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
        if(overflow_kind || spill_count || (GPDMA1_Channel14->CCR&DMA_CCR_EN))return -1;
#endif
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES && !XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE
#if XE_NP_NP2_PREPARATION_ENABLE
        if(XE_NP_Np2LiveSd_RetireStoppedTailForPreparation())return -1;
#else
        /* Raw9 deliberately samples beyond the target for D8 lookahead. Its
         * durable write drain is sealed; retire only that stopped tail before
         * replacing the old geometry or publishing a new session. */
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
        if(active_target_blocks &&
           !xe_np_np2_live_sd_mailbox.error &&
           xe_np_np2_live_sd_mailbox.target_blocks==active_target_blocks &&
           xe_np_np2_live_sd_mailbox.produced_blocks==active_target_blocks &&
           xe_np_np2_live_sd_mailbox.written_rus==active_target_rus &&
           XE_NP_Np2CapturePort_RetireStoppedTail(next_tick))return -1;
#else
        if(LIVE_PROBE_MASK==7U && active_target_blocks &&
           !xe_np_np2_live_sd_mailbox.error &&
           xe_np_np2_live_sd_mailbox.target_blocks==active_target_blocks &&
           xe_np_np2_live_sd_mailbox.produced_blocks==active_target_blocks &&
           xe_np_np2_live_sd_mailbox.written_rus==active_target_rus &&
           XE_NP_Np2CapturePort_RetireStoppedTail((uint64_t)active_target_blocks*STREAM_TICKS))return -1;
#endif
#endif
#endif
        card->Instance->CLKCR=recording_clkcr;
        card->Init.ClockDiv=recording_clkcr&SDMMC_CLKCR_CLKDIV;
        __DSB();
    }else if(input)recording_clkcr=input->Instance->CLKCR;
    initialized=0U;producer=NULL;format_ready=0U;
#if XE_NP_NP2_PREPARATION_ENABLE
    stopped_tail_retired=0U;
#endif
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
    /* This is before any new source/SD owner. No call may replace an active
     * map; both geometry and pointer order are immutable for this session. */
    uint32_t profile_error=select_record_profile(probe_mask,sample_hz);
    if(profile_error){fail(XE_NP_NP2_LIVE_SD_ERROR_ARGUMENT,profile_error);return -1;}
#endif
#if XE_NP_NP2_SD_PROFILE_CLASSIC_TEST
    record_uses_vsc=(uint8_t)(
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
        grid16.requested?0U:
#endif
        XE_NP_Np2LiveSd_UsesReservedAu(probe_mask,sample_hz,au_blocks,allocation_end_lba));
    vsc_recording_entered=0U;
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    record_uses_append=(uint8_t)(
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
        !grid16.requested &&
#endif
        append_layout!=0U);
    append_logical_high_water_blocks=0U;
    memset(&append_coverage,0,sizeof(append_coverage));
#endif
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    record_uses_runtime_direct=(uint8_t)(
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
        !grid16.requested &&
#endif
        XE_NP_Np2RuntimeDirectPssiProfile(probe_mask,sample_hz));
    runtime_direct_retire_pending=0U;runtime_direct_retired_rus=0U;
#endif
#if XE_NP_NP2_SD_SINGLE7500_WINDOW2048_TEST || XE_NP_NP2_SD_DUAL20_WINDOW1536_TEST
    /* DUAL20_WINDOW1536_RESET_BEGIN */
    fixed_window_shift=10U;
#if XE_NP_NP2_SD_SINGLE7500_WINDOW2048_TEST
    /* DUAL20_WINDOW1536_RESET_END */
    fixed_window_shift=(uint8_t)(!SESSION_VSC && !SESSION_APPEND &&
        ((probe_mask==1U && (sample_hz==7500U ||
            (XE_NP_NP2_SD_SINGLE15_WINDOW2048_TEST && sample_hz==15000U) ||
            (XE_NP_NP2_SD_SINGLE20_WINDOW2048_TEST && sample_hz==20000U) ||
            (XE_NP_NP2_SD_SINGLE30_WINDOW2048_TEST && sample_hz==30000U))) ||
         (XE_NP_NP2_SD_DUAL7500_WINDOW2048_TEST && probe_mask==3U && sample_hz==7500U))?11U:10U);
#if XE_NP_NP2_SD_TRIPLE7500_WINDOW1536_TEST
    if(probe_mask==7U && sample_hz==7500U && !SESSION_VSC && !SESSION_APPEND)
        fixed_window_shift=FIXED_WINDOW_1536_MODE;
#endif
#if XE_NP_NP2_SD_SINGLE_MID_WINDOW1536_TEST
    if(probe_mask==1U && sample_hz==15000U &&
       !SESSION_VSC && !SESSION_APPEND)fixed_window_shift=FIXED_WINDOW_1536_MODE;
#endif
#if XE_NP_NP2_SD_SINGLE30_WINDOW1536_TEST
    if(probe_mask==1U && sample_hz==30000U &&
       !SESSION_VSC && !SESSION_APPEND)fixed_window_shift=FIXED_WINDOW_1536_MODE;
#endif
#endif /* DUAL20_WINDOW1536_SINGLE_END */
#if XE_NP_NP2_SD_DUAL20_WINDOW1536_TEST
    if(probe_mask==3U && sample_hz==20000U && !SESSION_VSC && !SESSION_APPEND)
        fixed_window_shift=FIXED_WINDOW_1536_MODE;
#endif
#endif
#if XE_NP_NP2_SD_ORDERED_BATCH3_TEST
    record_uses_batch3=(uint8_t)(
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
        !grid16.requested &&
#endif
        XE_NP_Np2LiveSd_UsesOrderedBatch3Profile(probe_mask,sample_hz,SESSION_VSC));
#endif
#if XE_NP_NP2_SD_HIGH_TWO_PSRAM_IDMA_TEST
    record_uses_psram_idma=(uint8_t)(
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
        !grid16.requested &&
#endif
        (SESSION_VSC
#if XE_NP_NP2_SD_HIGH_TWO_CLASSIC_PSRAM_IDMA_TEST
        || (!SESSION_APPEND && au_blocks && allocation_end_lba)
#endif
        ) &&
        XE_NP_Np2LiveSd_UsesPsramIdmaProfile(probe_mask,sample_hz));
#endif
#if XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_TEST
    record_uses_whole_ru=(uint8_t)(
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
        !grid16.requested &&
#endif
        XE_NP_Np2LiveSd_UsesWholeRuProfile(probe_mask,sample_hz));
#if XE_NP_NP2_SD_ORDERED_BATCH3_TEST
    record_uses_whole_ru=(uint8_t)(record_uses_whole_ru && SESSION_BATCH3);
#endif
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_HOLD_TEST
    spill_hold_reset(); /* Cold recording init only; never rearm on an empty take. */
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_LEG_4K_TEST
    spill_leg_reset();
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST
    spill_defer_reset();
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_LAUNCH_TRACE_TEST
    spill_launch_trace_reset();
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_BUS_FENCE_DIAG_TEST
    spill_bus_fence_diag_reset();
    spill_bus_fence_early_diag_reset();
#endif
#if XE_NP_NP2_LIVE_SD_VSC_TEST
    vsc_command=(Np2VscCommand){0};vsc_stage=vsc_au_end=0U;
    vsc_au_blocks=SESSION_VSC?au_blocks:0U;
    memset((void *)xe_np_np2_live_vsc_diag,0,sizeof(xe_np_np2_live_vsc_diag));
    xe_np_np2_live_vsc_diag[0]=0x4356324EU;xe_np_np2_live_vsc_diag[1]=1U;
    xe_np_np2_live_vsc_diag[2]=vsc_au_blocks;
#endif
#if XE_NP_NP2_LIVE_SD_CLASSIC_PREPARE_TEST
    classic_prepare_command=(Np2VscCommand){0};
    memset((void *)xe_np_np2_classic_prepare_diag,0,sizeof(xe_np_np2_classic_prepare_diag));
    xe_np_np2_classic_prepare_diag[0]=0x5043324EU;xe_np_np2_classic_prepare_diag[1]=1U;
#endif
#if XE_NP_NP2_LIVE_SD_STARTUP_PRIME_TEST
    memset((void *)xe_np_np2_startup_prime_diag,0,sizeof(xe_np_np2_startup_prime_diag));
    xe_np_np2_startup_prime_diag[0]=0x5053324EU;xe_np_np2_startup_prime_diag[1]=1U;
#endif
    memset((void *)ru_state,0,sizeof(ru_state));memset(ru_first_block,0,sizeof(ru_first_block));
#if XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
    memset(ru_parts,0,sizeof(ru_parts));memset(spill_parts,0,sizeof(spill_parts));
#if VSC_PSRAM_IDMA
    memset(dma_external,0,sizeof(dma_external));
#endif
    dma_blocks=dma_complete_mask=dma_complete_units=fixed_confirmed_blocks=0U;
#if XE_NP_NP2_LIVE_SD_LAST_FREE_PREFETCH_TEST
    memset((void *)xe_np_np2_last_free_prefetch_diag,0,sizeof(xe_np_np2_last_free_prefetch_diag));
#endif
    memset((void *)xe_np_np2_fixed_write_diag,0,sizeof(xe_np_np2_fixed_write_diag));
    xe_np_np2_fixed_write_diag[0]=0x4657324EU;xe_np_np2_fixed_write_diag[1]=1U;
#endif
    fill_ru=(uint8_t)RU_COUNT;fill_blocks=dma_ru=dma_buffer_released=dma_units=0U;
    dma_active=irq_dataend_seen=irq_return_seen=irq_service_observed=0U;
    partial_ticks=write_started=write_dataend=last_service_cycles=0U;
    irq_dataend_cycles=irq_return_cycles=write_started_ms=status_poll_cycles=0U;
    next_tick=produced=0U;verify_phase_ready=0U;memset(verify_phase,0,sizeof(verify_phase));
#if XE_NP_NP2_SD_SENSOR_SNAPSHOT_ENABLE
    sensor_tail_publication=0U;sensor_tail_seen=0U;
#endif
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
    memset((void *)&xe_np_np2_sd_loss,0,sizeof(xe_np_np2_sd_loss));
    memset((void *)xe_np_np2_first_gap_diag,0,sizeof(xe_np_np2_first_gap_diag));
#endif
#if XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST
    sd_ll_node_index=sd_ll_bytes_done=sd_ll_retired_rus=0U;sd_ll_fault=0U;
#endif
#if XE_NP_NP2_LIVE_SD_PSRAM_SPILL
    spill_head=spill_tail=spill_count=spill_copy=spill_dma_bytes=0U;spill_restore=RU_COUNT;
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
    spill_head=spill_tail=spill_count=spill_copy=spill_dma_bytes=spill_dma_started=0U;
    overflow_kind=0U;overflow_ru=(uint8_t)RU_COUNT;overflow_started_ms=0U;
    copy_cost_reset();
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
    dma_first_ru=0U;overflow_restored_mask=0U;
    memset((void *)xe_np_np2_overflow_order_diag,0,sizeof(xe_np_np2_overflow_order_diag));
    xe_np_np2_overflow_order_diag[0]=0x4F52324EU;xe_np_np2_overflow_order_diag[1]=1U;
#if MAX_WRITE_RUS<=6U
    memset((void *)xe_np_np2_write_batch_diag,0,sizeof(xe_np_np2_write_batch_diag));
    xe_np_np2_write_batch_diag[0]=0x4243324EU;
    /* v3 bins count touched fragments, not completed whole recorder RUs. */
    xe_np_np2_write_batch_diag[1]=XE_NP_NP2_SD_SINGLE7500_WINDOW2048_TEST?4U:
        (XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST?3U:(MAX_WRITE_RUS==6U?2U:1U));
#endif
#endif
    memset(dma_slots,0,sizeof(dma_slots));
    memset((void *)xe_np_np2_overflow_dma_diag,0,sizeof(xe_np_np2_overflow_dma_diag));
    xe_np_np2_overflow_dma_diag[0]=0x4F44324EU;xe_np_np2_overflow_dma_diag[1]=1U;
#if XE_NP_NP2_LIVE_SD_OVERFLOW_FAULT_DIAG
    memset((void *)xe_np_np2_overflow_fault_diag,0,sizeof(xe_np_np2_overflow_fault_diag));
    if(cache)(void)clean((void *)xe_np_np2_overflow_fault_diag,sizeof(xe_np_np2_overflow_fault_diag));
#if XE_NP_NP2_LIVE_SD_FAULT_SD_PINS_TEST
    memset((void *)xe_np_np2_idma_fault_diag,0,sizeof(xe_np_np2_idma_fault_diag));
    if(cache)(void)clean((void *)xe_np_np2_idma_fault_diag,sizeof(xe_np_np2_idma_fault_diag));
#endif
#endif
#endif
    memset((void *)&xe_np_np2_live_sd_mailbox,0,sizeof(xe_np_np2_live_sd_mailbox));
    memset((void *)&xe_np_np2_live_sd_perf,0,sizeof(xe_np_np2_live_sd_perf));
#if XE_NP_USB_SD_TEST_ENABLE
    usb_wall_reset(); /* Preserve the stopped-time observer selection. */
#endif
#if XE_NP_NP2_LIVE_SD_WRITE_LATENCY_DIAG
    memset((void *)xe_np_np2_sd_latency_diag,0,sizeof(xe_np_np2_sd_latency_diag));
    xe_np_np2_sd_latency_diag[0]=0x4C53324EU;
    xe_np_np2_sd_latency_diag[1]=1U;
#endif
#if XE_NP_NP2_LIVE_SD_IDMA_GAP_DIAG
    memset((void *)xe_np_np2_sd_idma_gap_diag,0,sizeof(xe_np_np2_sd_idma_gap_diag));
    xe_np_np2_sd_idma_gap_diag[0]=0x4744324EU;
    xe_np_np2_sd_idma_gap_diag[1]=1U;
    sd_ll_last_node_cycles=sd_ll_last_node_dcount=0U;
#endif
#if XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    direct_progress_poll_ms=0U;direct_progress_poll_valid=0U;
#endif
    xe_np_np2_live_sd_perf.magic=0x4650324EU;
#if XE_NP_NP2_LIVE_SD_DATA_PHASE_DIAG
    xe_np_np2_live_sd_perf.version=10U;
#elif XE_NP_NP2_LIVE_SD_TRIPLE_COPY_TIMING_DIAG
    xe_np_np2_live_sd_perf.version=8U;
#elif XE_NP_NP2_LIVE_SD_PACK_TIMING_DIAG
    xe_np_np2_live_sd_perf.version=7U;
#elif WRITE_WALL_TIMING
    xe_np_np2_live_sd_perf.version=6U;
#elif XE_NP_NP2_LIVE_SD_LAUNCH_WAIT_DIAG
    xe_np_np2_live_sd_perf.version=5U;
#else
    xe_np_np2_live_sd_perf.version=4U;
#endif
    xe_np_np2_live_sd_perf.max_write_rus=MAX_WRITE_RUS;
    verify_clock_reduced=0U;
#if XE_NP_NP2_LIVE_SD_VERIFY_READ_RETRY_TEST
    memset((void *)xe_np_np2_verify_retry_diag,0,sizeof(xe_np_np2_verify_retry_diag));
#endif
#if XE_NP_NP2_LIVE_SD_LAUNCH_WAIT_DIAG
    launch_wait_reason=LAUNCH_WAIT_NONE;launch_wait_tracking=0U;launch_wait_started=0U;
#endif
    xe_np_np2_live_sd_mailbox.magic=XE_NP_NP2_LIVE_SD_MAILBOX_MAGIC;
    xe_np_np2_live_sd_mailbox.version=XE_NP_NP2_LIVE_SD_MAILBOX_VERSION;
    xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_PREPARING;
    card=input;cache=input_cache;
    uint64_t extent_end=(uint64_t)payload_start_lba+
                        (uint64_t)block_count*XE_NP_NP2_DUAL_SD_SECTORS_PER_BLOCK;
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
    if(grid16.requested){
        uint64_t groups=block_count/BLOCKS_PER_RU;
        uint64_t expected=(uint64_t)payload_start_lba+
            groups*(RU_BLOCKS+grid16.aux_sectors);
        /* Grid16 is strictly ordered classic SRAM.  It never borrows VSC or
         * PSRAM owners, and the supplied physical extent must be exact. */
        uint32_t callbacks=grid16.acquire && grid16.release;
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
        if(grid16.append)callbacks=grid16.acquire_append && grid16.release_append && grid16.append_fault;
#endif
        if(!callbacks || !grid16.commit || !grid16.source_stopped || !grid16.prepare_stop || !grid16.aux_sectors ||
           grid16.aux_sectors>XE_NP_NP2_GRID16_MAX_AUX_SECTORS ||
            block_count%BLOCKS_PER_RU || grid16.requested_end_lba!=expected ||
           expected>UINT32_MAX || SESSION_VSC || SESSION_PSRAM_IDMA ||
           XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE ||
           RU_BYTES!=XE_NP_NP2_GRID16_NN_BYTES || RU_BLOCKS!=XE_NP_NP2_GRID16_NN_SECTORS ||
           SD_LLI_MAX_NODES<XE_NP_NP2_GRID16_MAX_NODES){
            /* Cold admission only: preserve an actionable reason before
             * clearing the staged owner; no work is added to capture. */
            uint32_t reason=0U;
            if(!callbacks || !grid16.commit || !grid16.source_stopped || !grid16.prepare_stop)reason|=1U;
            if(!grid16.aux_sectors || grid16.aux_sectors>XE_NP_NP2_GRID16_MAX_AUX_SECTORS)reason|=2U;
            if(block_count%BLOCKS_PER_RU || grid16.requested_end_lba!=expected || expected>UINT32_MAX)reason|=4U;
            if(SESSION_VSC)reason|=8U;
            if(SESSION_PSRAM_IDMA)reason|=16U;
            if(XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE)reason|=32U;
            if(RU_BYTES!=XE_NP_NP2_GRID16_NN_BYTES || RU_BLOCKS!=XE_NP_NP2_GRID16_NN_SECTORS)reason|=64U;
            if(SD_LLI_MAX_NODES<XE_NP_NP2_GRID16_MAX_NODES)reason|=128U;
            grid16.requested=0U;fail(XE_NP_NP2_LIVE_SD_ERROR_ARGUMENT,0x47310000U|reason);return -1;
        }
        extent_end=expected;
        grid16.physical_confirmed_lba=payload_start_lba;
        grid16.active=0U;grid16.release_pending=0U;
        memset(grid16.aux,0,sizeof(grid16.aux));
    }
#endif
    uint32_t erase_end=0U;
#if XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST
    if(input && allocation_end_lba && !SESSION_VSC)
        erase_end=XE_NP_SdLegacyAuEraseEnd(payload_start_lba,extent_end,au_blocks,
                                          allocation_end_lba,input->SdCard.LogBlockNbr);
#endif
    if(!input || !input_cache || payload_start_lba<8192U ||
#if XE_NP_NP2_LIVE_SD_VSC_TEST
       (SESSION_VSC?
        (allocation_end_lba || au_blocks<1024U || au_blocks%1024U || payload_start_lba%au_blocks ||
#if XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_VSC_TEST
         (SESSION_WHOLE_RU && au_blocks<RU_BLOCKS) ||
#endif
         (uint64_t)payload_start_lba+((extent_end-payload_start_lba+au_blocks-1U)/au_blocks)*au_blocks>input->SdCard.LogBlockNbr):
        (allocation_end_lba?!erase_end:(au_blocks || payload_start_lba%16384U))) ||
#else
       allocation_end_lba || payload_start_lba%16384U ||
#endif
       block_count<BLOCKS_PER_RU ||
       block_count%BLOCKS_PER_RU || extent_end>UINT32_MAX ||
       extent_end>input->SdCard.LogBlockNbr ||
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
       !XE_NP_Np2LiveSd_SupportsProfile(probe_mask,sample_hz)){
#elif XE_NP_NP2_LIVE_SD_PROBE_MASK == 3U && XE_NP_NP2_USB_PACKED_DUAL
       probe_mask!=3U ||
       (sample_hz!=20000U && sample_hz!=30000U)){
#else
       probe_mask!=XE_NP_NP2_LIVE_SD_PROBE_MASK ||
       sample_hz!=XE_NP_NP2_LIVE_SD_SAMPLE_HZ){
#endif
        fail(XE_NP_NP2_LIVE_SD_ERROR_RANGE,0xE001U);return -1;
    }
    record_start_lba=payload_start_lba;record_end_lba=(uint32_t)extent_end;
    record_erase_end_lba=erase_end?erase_end:record_end_lba;
    record_sample_hz=sample_hz;record_mclk_hz=sample_hz*1600U;
#if XE_NP_NP2_SD_APPEND_COUNTED_PIPELINE_TEST
    if(copied_window_policy())xe_np_np2_live_sd_perf.max_write_rus=DMA_WINDOW_OWNERS;
#endif
#if XE_NP_NP2_SD_READY_APPEND_TEST
    if(SESSION_APPEND && LIVE_PROBE_MASK==3U && record_sample_hz==30000U &&
       !SESSION_VSC && !SESSION_WHOLE_RU)
        xe_np_np2_live_sd_perf.max_write_rus=RU_COUNT-1U;
#endif
#if XE_NP_NP2_LIVE_SD_SPILL_DEFER_2MS_TEST
    spill_defer_guard_ticks=XE_NP_NP2_UNPUBLISHED_BOUND+BLOCKS_PER_RU*STREAM_TICKS+
        (uint32_t)(((uint64_t)record_mclk_hz*2U+999U)/1000U);
#endif
    xe_np_np2_live_sd_mailbox.cpu_hz=HAL_RCC_GetHCLKFreq();
    xe_np_np2_live_sd_mailbox.mclk_hz=record_mclk_hz;
    xe_np_np2_live_sd_mailbox.sample_hz=record_sample_hz;
    xe_np_np2_live_sd_mailbox.probe_mask=LIVE_PROBE_MASK;
    xe_np_np2_live_sd_mailbox.wire_mask=XE_NP_Np2UsbV3_WireMask(LIVE_PROBE_MASK);
    xe_np_np2_live_sd_mailbox.codec=LIVE_CODEC;
    xe_np_np2_live_sd_mailbox.stored_bits=LIVE_BITS;
    xe_np_np2_live_sd_mailbox.start_lba=record_start_lba;
    xe_np_np2_live_sd_mailbox.end_lba=record_end_lba;
    xe_np_np2_live_sd_mailbox.target_blocks=block_count;
    active_target_blocks=block_count;active_target_rus=block_count/BLOCKS_PER_RU;
    xe_np_np2_live_sd_mailbox.stream_block_bytes=STREAM_BYTES;
    xe_np_np2_live_sd_mailbox.ru_bytes=RU_BYTES;xe_np_np2_live_sd_mailbox.ru_count=RU_COUNT;
#if XE_NP_NP2_STAGED_CAPTURE
    XE_Np2Stage_Init(&stage_queue);
    memset((void *)xe_np_np2_stage_copy_diag,0,sizeof(xe_np_np2_stage_copy_diag));
    xe_np_np2_stage_copy_diag[0]=0x50435453U;
    xe_np_np2_stage_copy_diag[1]=1U;
#if XE_NP_NP2_STAGED_LONG_CMD25
    XE_Np2StageLong_Init(&stage_long_window);
#endif
    /* The live source resets all of GPDMA1 in its PREPARE state. Keep the
     * handle quiescent until that reset has completed; HAL_DMA_Start only
     * programs addresses/length and cannot restore a wiped channel CTR1/2. */
    memset(&stage_dma,0,sizeof(stage_dma));
#if XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE
    if(XE_Np2StageDma_Init(&stage_dma)){
        fail(XE_NP_NP2_LIVE_SD_ERROR_ARGUMENT,0xDA40U);return -1;
    }
#endif
    for(uint32_t i=0U;i<RU_COUNT;i++)stage_ru_base[i]=(uint32_t)(uintptr_t)ru[i];
#endif
#if XE_NP_NP2_LIVE_SD_COUNTED_WRITES
    counted_writes_enabled=!(XE_NP_NP2_SD_DUAL20_EXPLICIT_STOP_TEST &&
                            LIVE_PROBE_MASK==3U && record_sample_hz==20000U);
    counted_write_active=0U;
#endif
#if XE_NP_NP2_SD_COPIED_COUNTED_WINDOW_TEST
    memset(&copied_window,0,sizeof(copied_window));
#endif
#if XE_NP_NP2_LIVE_SD_PSRAM_SPILL
    /* Synthetic sources have no PREPARE reset. Live sources configure the
     * copy channel after PREPARE, immediately before arming acquisition. */
#if XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE
    if(init_spill_dma()){fail(XE_NP_NP2_LIVE_SD_ERROR_ARGUMENT,0xD800U);return -1;}
#endif
#endif
    last_write_completed=0U;
    for(uint32_t i=0U;i<RU_COUNT;i++){
        if((i%4U && (uintptr_t)ru[i]!=(uintptr_t)ru[i-1U]+RU_BYTES
#if XE_NP_NP2_SD_RAW_INGRESS_RU_TEST
            /* Copied linked IDMA builds/cleans one physical RU at a time.
             * Only this checked extra bank is intentionally noncontiguous. */
            && ru[i]!=ru9
#endif
           )
#if XE_NP_NP2_LIVE_SD_DIRECT && !defined(XE_NP_NP2_LIVE_SD_NATIVE_MODEL)
#if XE_NP_NP2_STAGED_CAPTURE
           || (i<XE_NP2_STAGE_ACQ_RUS && !XE_NP_Np2DirectContains(ru[i],RU_BYTES))
#else
           || !XE_NP_Np2DirectContains(ru[i],RU_BYTES)
#endif
#endif
          ){fail(XE_NP_NP2_LIVE_SD_ERROR_ARGUMENT,i);return -1;}
    }
    if(!card || !cache || HAL_SD_GetCardCSD(card,&csd)!=HAL_OK){fail(XE_NP_NP2_LIVE_SD_ERROR_ARGUMENT,0U);return -1;}
    xe_np_np2_live_sd_mailbox.card_blocks=card->SdCard.LogBlockNbr;
    xe_np_np2_live_sd_mailbox.sd_speed_mode=XE_NP_Board_SdNegotiatedSpeedMode();
    xe_np_np2_live_sd_mailbox.sd_kernel_hz=HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SDMMC);
    const volatile XE_NP_BoardSdDiag *diag=XE_NP_Board_SdDiag();
    xe_np_np2_live_sd_mailbox.sd_bus_hz=diag?diag->last_speed_mode_sdmmc_bus_hz:0U;
    xe_np_np2_live_sd_mailbox.signal_1v8=diag?diag->signal_1v8_enabled:0U;
    publish();
    if(HAL_RCC_GetHCLKFreq()!=XE_NP_Board_GetRuntimeCoreClockHz() ||
       !XE_NP_Board_SdUhsReadyForNpRaw() ||
       card->SdCard.LogBlockNbr<record_end_lba){fail(XE_NP_NP2_LIVE_SD_ERROR_CARD,1U);return -1;}
    if(card->Context!=SD_CONTEXT_NONE && card_idle())card->Context=SD_CONTEXT_NONE;
    if(!card_idle()){fail(XE_NP_NP2_LIVE_SD_ERROR_CARD,2U);return -1;}
#if XE_NP_NP2_LIVE_SD_LAUNCH_GAP_SNAPSHOT_DIAG
    launch_gap_snapshot_reset(); /* Admitted stopped start only, never fail(). */
#endif
    if(apply_session_clock_save()){fail(XE_NP_NP2_LIVE_SD_ERROR_CARD,3U);return -1;}
#if XE_NP_NP2_LIVE_SD_DUAL_SCRATCH_OVERFLOW_DMA
    if(scratch_media_admitted()){fail(XE_NP_NP2_LIVE_SD_ERROR_RANGE,0xE005U);return -1;}
#endif
#if XE_NP_NP2_SD_VSC_PREERASE60_TEST
    if(preerase_stopped_vsc()){fail(XE_NP_NP2_LIVE_SD_ERROR_ERASE,record_start_lba);return -1;}
#else
    if(preerase()){fail(XE_NP_NP2_LIVE_SD_ERROR_ERASE,record_start_lba);return -1;}
#endif
#if XE_NP_NP2_SD_VSC_FEED_TEST
    if(!vsc_feed_active){
#endif
#if XE_NP_NP2_PREPARATION_ENABLE && !XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE
    int preparation=XE_NP_Np2Preparation_Consume(N2C_BLE,NP_PREP_SD,
                                                   LIVE_PROBE_MASK,record_sample_hz);
    if(preparation<0){fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,3U);return -1;}
    if(!preparation){
#endif
#if !XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
#if XE_NP_PSRAM_HOST_PARK_TEST
    if(prepare_overflow_memory()){
        fail(XE_NP_NP2_LIVE_SD_ERROR_ARGUMENT,0xD840U);return -1;
    }
    if(
#elif XE_NP_NP2_SD_SINGLE20_CORE64_TEST || XE_NP_NP2_SD_MULTI20_CORE64_TEST || \
    XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST
    if(XE_NP_Board_InitNp2OverflowMemoryProfile(record_sample_hz,LIVE_PROBE_MASK)!=0 ||
#else
    if(XE_NP_Board_InitNp2OverflowMemory(record_sample_hz)!=0 ||
#endif
#else
    if(XE_NP_Board_SetNp2SampleRateHz(record_sample_hz)!=0 ||
#endif
       XE_NP_Np2UsbSource_Init()!=0 ||
        XE_NP_Np2UsbSource_SelectProbeMask(LIVE_PROBE_MASK)!=0 || XE_NP_Np2UsbSource_Start()!=0){
        fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,3U);return -1;
    }
#else
    if(configure_format()){fail(XE_NP_NP2_LIVE_SD_ERROR_ARGUMENT,0x5A01U);return -1;}
#endif
#if XE_NP_NP2_PREPARATION_ENABLE && !XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE
    }
#endif
#if XE_NP_NP2_SD_VSC_FEED_TEST
    }
#endif
    xe_np_np2_live_sd_mailbox.cpu_hz=HAL_RCC_GetHCLKFreq();
    CoreDebug->DEMCR|=CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT=0U;DWT->CTRL|=DWT_CTRL_CYCCNTENA_Msk;__DSB();
    HAL_NVIC_ClearPendingIRQ(SDMMC1_IRQn);HAL_NVIC_SetPriority(SDMMC1_IRQn,6U,0U);HAL_NVIC_EnableIRQ(SDMMC1_IRQn);
    write_lba=record_start_lba;
#if XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE
    synthetic_next_due_cycles=cycles()+(uint32_t)SYNTHETIC_BLOCK_CYCLES;
    record_started_ms=HAL_GetTick();
    xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_CAPTURING;
#else
    xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_CONFIGURING;
#endif
    initialized=1U;publish();return 0;
}

void XE_NP_Np2LiveSd_Init(SD_HandleTypeDef *input,DCACHE_HandleTypeDef *input_cache)
{
    XE_NP_Np2LiveSd_InitExtentRate(input,input_cache,SCRATCH_START_LBA,
                                  TARGET_BLOCKS,XE_NP_NP2_LIVE_SD_SAMPLE_HZ);
}

void XE_NP_Np2LiveSd_InitExtentProfile(SD_HandleTypeDef *input,DCACHE_HandleTypeDef *input_cache,
                                      uint32_t start,uint32_t blocks,uint32_t mask,uint32_t rate)
{
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
    if(grid16.pending)return;
#endif
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
    grid16.requested=0U;
#endif
    init_extent_profile(input,input_cache,start,blocks,mask,rate,0U,0U,0U);
}

#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
int XE_NP_Np2LiveSd_InitExtentGrid16(SD_HandleTypeDef *input,DCACHE_HandleTypeDef *input_cache,
    uint32_t start,uint32_t physical_end,uint32_t blocks,uint32_t mask,uint32_t rate,
    uint32_t aux_sectors,XE_NP_Np2LiveSdGrid16Acquire acquire,
    XE_NP_Np2LiveSdGrid16Release release,XE_NP_Np2LiveSdGrid16Commit commit,
    XE_NP_Np2LiveSdGrid16SourceStopped source_stopped,
    XE_NP_Np2LiveSdGrid16PrepareStop prepare_stop,void *context)
{
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
    if(grid16.pending)return -1;
#endif
    if(grid16.active || dma_active || !acquire || !release || !commit || !source_stopped || !prepare_stop)return -1;
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
    /* Do not convert a retained legacy spill/C14 owner into a Grid16 physical
     * sequence. A fresh Init clears these only after normal old-session stop. */
    if(overflow_kind || spill_count || spill_dma_bytes ||
       (GPDMA1_Channel14->CCR&DMA_CCR_EN))return -1;
#endif
    if(!aux_sectors || aux_sectors>XE_NP_NP2_GRID16_MAX_AUX_SECTORS)return -1;
    /* The provider must be usable before source arm.  The sentinel never
     * names a recording group and must yield a sealed padding/preflight span. */
    const uint8_t *probe=acquire(context,UINT32_MAX,aux_sectors);
    if(!probe || ((uintptr_t)probe&31U))return -1;
    release(context,UINT32_MAX,probe);
    memset(&grid16,0,sizeof(grid16));
    grid16.requested=1U;grid16.requested_end_lba=physical_end;
    grid16.aux_sectors=aux_sectors;grid16.acquire=acquire;grid16.release=release;
    grid16.commit=commit;grid16.source_stopped=source_stopped;
    grid16.prepare_stop=prepare_stop;
    grid16.context=context;
    if(init_extent_profile(input,input_cache,start,blocks,mask,rate,0U,0U,0U) ||
       !initialized || xe_np_np2_live_sd_mailbox.error || !grid16.requested){
        memset(&grid16,0,sizeof(grid16));return -1;
    }
    return 0;
}
#endif

#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
int XE_NP_Np2LiveSd_InitExtentGrid16Append(SD_HandleTypeDef *input,DCACHE_HandleTypeDef *input_cache,
    uint32_t start,uint32_t physical_end,uint32_t blocks,uint32_t mask,uint32_t rate,
    uint32_t aux_sectors,XE_NP_Np2LiveSdGrid16AcquireAppend acquire,
    XE_NP_Np2LiveSdGrid16ReleaseAppend release,XE_NP_Np2LiveSdGrid16AppendFault fault,
    XE_NP_Np2LiveSdGrid16Commit commit,XE_NP_Np2LiveSdGrid16SourceStopped stopped,
    XE_NP_Np2LiveSdGrid16PrepareStop prepare_stop,void *context)
{
    if(grid16.active || dma_active || grid16.pending || !acquire || !release || !fault ||
       !commit || !stopped || !prepare_stop || overflow_kind || spill_count || spill_dma_bytes ||
       (GPDMA1_Channel14->CCR&DMA_CCR_EN) || !aux_sectors ||
       aux_sectors>XE_NP_NP2_GRID16_MAX_AUX_SECTORS)return -1;
    const uint8_t *probe=acquire(context,UINT32_MAX,UINT32_MAX,aux_sectors);
    if(!probe || ((uintptr_t)probe&31U) || fault(context))return -1;
    release(context,UINT32_MAX,UINT32_MAX,probe);
    memset(&grid16,0,sizeof(grid16));grid16.requested=grid16.append=1U;
    grid16.requested_end_lba=physical_end;grid16.aux_sectors=aux_sectors;
    grid16.acquire_append=acquire;grid16.release_append=release;grid16.append_fault=fault;
    grid16.commit=commit;grid16.source_stopped=stopped;grid16.prepare_stop=prepare_stop;
    grid16.context=context;
    if(init_extent_profile(input,input_cache,start,blocks,mask,rate,0U,0U,0U) ||
       !initialized || xe_np_np2_live_sd_mailbox.error || !grid16.requested){
        memset(&grid16,0,sizeof(grid16));return -1;
    }
    return 0;
}
int XE_NP_Np2LiveSd_GetGrid16AppendCounts(XE_NP_Grid16Footer *out)
{
    if(!out || !initialized || !grid16.requested || !grid16.append ||
       (xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_COMPLETE &&
        xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_FAILED))return -1;
    out->np_blocks=grid16_append_ticket();
    out->logical_prefix_blocks=xe_np_np2_live_sd_mailbox.written_rus*BLOCKS_PER_RU;
    out->logical_high_water_blocks=append_logical_high_water_blocks;
    out->admitted_blocks=xe_np_np2_live_sd_mailbox.produced_blocks;out->append_flags=1U;
    return 0;
}
#endif
uint32_t XE_NP_Np2LiveSd_StoredBlocks(void)
{
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
    if(grid16.requested && grid16.append)return grid16_append_ticket();
#endif
    return xe_np_np2_live_sd_mailbox.written_rus*BLOCKS_PER_RU;
}

#if XE_NP_NP2_SD_APPEND_ORDER_TEST
int XE_NP_Np2LiveSd_InitExtentAppendProfile(SD_HandleTypeDef *input,DCACHE_HandleTypeDef *input_cache,
                                            uint32_t start,uint32_t blocks,uint32_t mask,uint32_t rate,
                                            uint32_t au,uint32_t allocation_end)
{
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
    if(grid16.pending)return -1;
#endif
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
    grid16.requested=0U;
#endif
    return init_extent_profile(input,input_cache,start,blocks,mask,rate,au,allocation_end,1U);
}

int XE_NP_Np2LiveSd_GetAppendCounts(XE_NP_Np2SdAppendCounts *out)
{
    if(!out || !initialized || !SESSION_APPEND ||
       (xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_COMPLETE &&
        xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_FAILED) ||
       fixed_confirmed_blocks%RU_BLOCKS)return -1;
    XE_NP_Np2SdAppendCounts counts={fixed_confirmed_blocks/RU_BLOCKS*BLOCKS_PER_RU,
        xe_np_np2_live_sd_mailbox.written_rus*BLOCKS_PER_RU,append_logical_high_water_blocks};
    if((counts.logical_prefix_blocks%BLOCKS_PER_RU) ||
       counts.logical_prefix_blocks>counts.physical_blocks ||
       counts.physical_blocks>counts.logical_high_water_blocks ||
       counts.logical_high_water_blocks>active_target_blocks)return -1;
    *out=counts;return 0;
}
#endif

void XE_NP_Np2LiveSd_InitExtentRate(SD_HandleTypeDef *input,DCACHE_HandleTypeDef *input_cache,
                                   uint32_t start,uint32_t blocks,uint32_t rate)
{XE_NP_Np2LiveSd_InitExtentProfile(input,input_cache,start,blocks,XE_NP_NP2_LIVE_SD_PROBE_MASK,rate);}

int XE_NP_Np2LiveSd_CancelPrepared(void)
{
    if(!initialized || xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_CONFIGURING || dma_active)return -1;
#if XE_NP_NP2_LIVE_SD_VSC_TEST
    int closed=close_vsc();
    if(closed<0){fail(XE_NP_NP2_LIVE_SD_ERROR_STOP,0x56530003U);return -1;}
    if(!closed)return 1;
#endif
#if XE_NP_NP2_LIVE_SD_CLASSIC_PREPARE_TEST
    if(classic_prepare_command.phase && classic_prepare_command.phase!=5U){
        int prepared=service_classic_prepare();
        if(prepared<0){fail(XE_NP_NP2_LIVE_SD_ERROR_STOP,0x53435002U);return -1;}
        if(!prepared)return 1;
    }
#endif
#if XE_NP_NP2_SD_INGRESS_DMA_TEST
    if(ingress_dma_stop())return -1;
    ingress_pending=0U;
#endif
#if XE_NP_PSRAM_HOST_PARK_TEST
    if(resume_parked_psram(1U))return -1;
#endif
    XE_NP_Np2UsbSource_Stop();
    XE_NP_Np2Preparation_SourceStopped();
    if(XE_NP_Np2CapturePort_Armed())return -1;
    xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_COMPLETE;
    xe_np_np2_live_sd_mailbox.target_blocks=0U;
    return 0;
}

#if XE_NP_NP2_LIVE_SD_VSC_TEST
void XE_NP_Np2LiveSd_InitExtentAuProfile(SD_HandleTypeDef *input,DCACHE_HandleTypeDef *input_cache,
                                        uint32_t start,uint32_t blocks,uint32_t mask,uint32_t rate,
                                        uint32_t au)
{
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
    if(grid16.pending)return;
#endif
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
    grid16.requested=0U;
#endif
    init_extent_profile(input,input_cache,start,blocks,mask,rate,au,0U,0U);
}

#if XE_NP_NP2_SD_VSC_FEED_TEST
/* FREE from BTC is not durable. Re-admit a generation only beyond the
 * card-confirmed prefix published by commit_overflow_order(). No payload
 * stores or copies occur here; each physical slot repeats its cold template. */
static int vsc_feed_refill(void)
{
    uint32_t next=xe_np_np2_live_sd_mailbox.produced_blocks/BLOCKS_PER_RU;
    uint32_t durable=xe_np_np2_live_sd_mailbox.written_rus;
    if(next<durable || next-durable>RU_COUNT)return -1;
    while(next<active_target_rus && next-durable<RU_COUNT){
        uint32_t slot=next%RU_COUNT;
        if(ru_state[slot]!=RU_FREE || (next>=RU_COUNT &&
           ru_first_block[slot]!=(next-RU_COUNT)*BLOCKS_PER_RU))return -1;
        ru_parts[slot]=0U;ru_first_block[slot]=next*BLOCKS_PER_RU;
        __DMB();ru_state[slot]=RU_READY;
        next++;xe_np_np2_live_sd_mailbox.produced_blocks=next*BLOCKS_PER_RU;
    }
    return 0;
}

int XE_NP_Np2LiveSd_StoppedVscFeed(SD_HandleTypeDef *input,DCACHE_HandleTypeDef *input_cache,
                                  uint32_t rate,uint32_t nonce,volatile uint32_t d[32])
{
    /* The dispatcher owns exact UID/CID, all16 DMA/source quiet and scratch
     * admission. This additional cold refusal precedes every LiveSd mutation. */
    if(initialized || vsc_feed_active || !input || !input_cache || !d || !nonce ||
       (rate!=20000U && rate!=30000U) || XE_NP_Np2CapturePort_Armed() ||
       XE_NP_Np2UsbSource_IsBusy() || XE_NP_Np2UsbSource_IsReady())return 16;
    vsc_feed_active=1U;
    init_extent_profile(input,input_cache,XE_NP_NP2_SD_VSC_FEED_START,
        XE_NP_NP2_SD_VSC_FEED_BLOCKS,rate==20000U?7U:3U,rate,XE_NP_NP2_SD_VSC_FEED_AU,0U,0U);
    if(!initialized || xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_CONFIGURING ||
       xe_np_np2_live_sd_mailbox.error || !SESSION_VSC)return 16;
    uint32_t ble_tick=HAL_GetTick();
    for(uint32_t slot=0U;slot<RU_COUNT;slot++){
        uint32_t *payload=(uint32_t *)ru[slot];
        for(uint32_t word=0U;word<RU_BYTES/4U;word++)
            payload[word]=0x5AF031C7U^((slot*(RU_BYTES/4U)+word)*0x9E3779B9U)^nonce;
        if(clean(payload,RU_BYTES))return 2;
        XE_NP_Np2SdBle_Service();
    }
    d[29]=RU_COUNT;
    uint32_t began=HAL_GetTick();
    int ready;
    do{
        ready=service_vsc();
        if(ready<0 || HAL_GetTick()-began>=3000U)return 17;
        uint32_t now=HAL_GetTick();
        if(now!=ble_tick){ble_tick=now;XE_NP_Np2SdBle_Service();}
    }while(!ready);
    if(vsc_feed_refill())return 20;
    xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_CAPTURING;
    d[6]=1U;began=HAL_GetTick();
    uint32_t error=0U;
    while(xe_np_np2_live_sd_mailbox.written_rus<active_target_rus){
        service_write();
        if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED){error=18U;break;}
        /* service_write may have launched the next command, but this frontier
         * still names only fully confirmed earlier RUs, never its BTC owners. */
        if(vsc_feed_refill()){error=20U;break;}
        uint32_t now=HAL_GetTick();
        if(now!=ble_tick){ble_tick=now;XE_NP_Np2SdBle_Service();}
        if(now-began>=15000U){error=19U;break;}
    }
    d[24]=HAL_GetTick()-began;
    d[11]=fixed_confirmed_blocks*512U;d[30]=fixed_confirmed_blocks;
    d[13]=(uint32_t)xe_np_np2_live_sd_perf.write_cycles;
    d[25]=(uint32_t)(xe_np_np2_live_sd_perf.write_cycles>>32U);
    d[26]=xe_np_np2_live_sd_perf.completed_calls;
    d[27]=xe_np_np2_live_sd_mailbox.max_write_cycles;
    d[28]=xe_np_np2_live_vsc_diag[8];
    if(error)return (int)error; /* Retain failed ownership for supported rescue. */
    if(dma_active || !card_idle() || fixed_confirmed_blocks!=active_target_rus*RU_BLOCKS ||
       d[26]!=((active_target_rus*RU_BLOCKS)/1024U))return 20;
    xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_DRAINING;
    began=HAL_GetTick();
    do{
        ready=close_vsc();
        if(ready<0 || HAL_GetTick()-began>=3000U)return 21;
        uint32_t now=HAL_GetTick();
        if(now!=ble_tick){ble_tick=now;XE_NP_Np2SdBle_Service();}
    }while(!ready);
    d[31]=HAL_GetTick()-began;
    xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_COMPLETE;
    vsc_feed_active=0U;publish();
    return 0;
}
#endif

#if XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST
void XE_NP_Np2LiveSd_InitExtentClassicAuProfile(SD_HandleTypeDef *input,DCACHE_HandleTypeDef *input_cache,
                                               uint32_t start,uint32_t blocks,uint32_t mask,uint32_t rate,
                                               uint32_t au,uint32_t allocation_end)
{
    /* Empty private ownership must not silently select ordinary classic.
     * Like an active-owner refusal, leave the existing session untouched. */
    if(!au || !allocation_end)return;
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
    if(grid16.pending)return;
#endif
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
    grid16.requested=0U;
#endif
    init_extent_profile(input,input_cache,start,blocks,mask,rate,au,allocation_end,0U);
}
#endif

void XE_NP_Np2LiveSd_InitExtentAuRate(SD_HandleTypeDef *input,DCACHE_HandleTypeDef *input_cache,
                                     uint32_t start,uint32_t blocks,uint32_t rate,uint32_t au)
{XE_NP_Np2LiveSd_InitExtentAuProfile(input,input_cache,start,blocks,XE_NP_NP2_LIVE_SD_PROBE_MASK,rate,au);}
#endif

void XE_NP_Np2LiveSd_InitExtent(SD_HandleTypeDef *input,DCACHE_HandleTypeDef *input_cache,
                               uint32_t payload_start_lba,uint32_t block_count)
{
    XE_NP_Np2LiveSd_InitExtentRate(input,input_cache,payload_start_lba,
                                  block_count,XE_NP_NP2_LIVE_SD_SAMPLE_HZ);
}

void XE_NP_Np2LiveSd_Service(void)
{
    if(!initialized || xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED ||
       xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_COMPLETE)return;
    if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_CONFIGURING){
        XE_NP_Np2UsbSource_Service();
        XE_NP_Np2UsbSourceStatus status={0};XE_NP_Np2UsbSource_GetStatus(&status);
        if(status.state==XE_NP_NP2_USB_SOURCE_FAILED){fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,status.error);return;}
        if(!XE_NP_Np2UsbSource_IsReady())return;
        if(!format_ready){
#if XE_NP_NP2_LIVE_SD_STARTUP_PRIME_TEST
            /* The RESERVED payload contains no committed samples. Prime once
             * with invalid zeros, then restore real immutable header templates.
             * No blocking write is permitted after the schedule gate opens. */
            if(startup_prime()){fail(XE_NP_NP2_LIVE_SD_ERROR_WRITE,
                                     0x50520000U|xe_np_np2_startup_prime_diag[3]);return;}
#endif
            if(configure_format()){fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,4U);return;}
            format_ready=1U;
        }
#if XE_NP_NP2_LIVE_SD_VSC_TEST
        int prepared=service_vsc();
        if(prepared<0){fail(XE_NP_NP2_LIVE_SD_ERROR_WRITE_START,0x56530004U);return;}
        if(!prepared)return;
#endif
#if XE_NP_NP2_LIVE_SD_CLASSIC_PREPARE_TEST
        int prepared=service_classic_prepare();
        if(prepared<0){fail(XE_NP_NP2_LIVE_SD_ERROR_WRITE_START,0x53435001U);return;}
        if(!prepared)return;
#endif
#if XE_NP_NP2_DUAL_SD_APP_ENABLE
        int gate=XE_NP_Np2DualSdApp_ArmGate();
        if(gate<0){fail(XE_NP_NP2_LIVE_SD_ERROR_TIMEOUT,0x53434844U);return;}
        if(!gate)return;
#endif
#if XE_NP_NP2_STAGED_CAPTURE
        /* Source PREPARE has finished its GPDMA1 reset; arm the handoff
         * channel now, before producer->arm starts PSSI/SPI DMA. */
        if(XE_Np2StageDma_Init(&stage_dma)){
            fail(XE_NP_NP2_LIVE_SD_ERROR_ARGUMENT,0xDA41U);return;
        }
#endif
#if XE_NP_NP2_LIVE_SD_PSRAM_SPILL || XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
        /* PREPARE resets all GPDMA1, including channel14. Configure only
         * after it is ready and the schedule gate opens, before PSSI arms. */
        if(init_spill_dma()){
            fail(XE_NP_NP2_LIVE_SD_ERROR_ARGUMENT,0xD800U);return;
        }
#endif
#if XE_NP_NP2_SD_INGRESS_DMA_TEST
        if(LIVE_PROBE_MASK==7U && ingress_dma_init()){
            fail(XE_NP_NP2_LIVE_SD_ERROR_ARGUMENT,0xD830U);return;
        }
#endif
        producer=XE_NP_Np2UsbSource_GetProducerIo();
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
        if(XE_NP_Np2CapturePort_EnableDrain(STREAM_TICKS)){
            fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,6U);return;
        }
#endif
        uint64_t origin=0U;
        uint32_t arm_before_ms=HAL_GetTick();
#if XE_NP_PSRAM_HOST_PARK_TEST
        if(xe_np_np2_psram_park_diag[2]){
            if(!XE_NP_Psram_HostParked() || (RCC->AHB2ENR2&RCC_AHB2ENR2_OCTOSPI2EN) ||
               (RCC->AHB2SMENR2&RCC_AHB2SMENR2_OCTOSPI2SMEN)){
                fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,0xD844U);return;
            }
            xe_np_np2_psram_park_diag[6]|=4U;
        }
#endif
#if XE_NP_NP2_LIVE_SD_PROBE_MASK == 3U && XE_NP_NP2_USB_PACKED_DUAL && \
    !XE_NP_NP2_LIVE_SD_DIRECT && !XE_NP_NP2_STAGED_CAPTURE
        if(set_capture_stop_limit(active_target_blocks)!=0){
            fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,6U);return;
        }
#endif
        if(!producer || producer->arm(producer->user,&origin)!=0 || origin!=0U){
            fail(XE_NP_NP2_LIVE_SD_ERROR_SOURCE,5U);return;
        }
        next_tick=origin;record_started_ms=HAL_GetTick();
#if XE_NP_NP2_DUAL_SD_APP_ENABLE
#if XE_NP_NP2_CAPTURE_PORT_ENABLE && XE_NP_NP2_FIRST_SYNC_ENABLE
        XE_NP_AcquisitionAnchor anchor;
        if(XE_NP_Np2FirstSyncRuntime_SdOpted() && XE_NP_Np2CapturePort_GetAnchor(&anchor)){
            arm_before_ms=anchor.before_ms;
            XE_NP_Np2DualSdApp_ArmStamp(arm_before_ms,anchor.after_ms);
        }else
#endif
        XE_NP_Np2DualSdApp_ArmStamp(arm_before_ms,record_started_ms);
#else
        (void)arm_before_ms;
#endif
        XE_NP_Np2FirstSyncRuntime_SdArmed();
        xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_CAPTURING;
        publish();return;
    }
    if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_VERIFYING){service_verify();return;}
#if XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE && XE_NP2_STAGE_DIRECT_PSRAM_IDMA
    /* Model the real PSSI/SPI DMA producer's higher priority: publish a due
     * synthetic blocks before foreground PSRAM copying or SD node work. The
     * bounded deadline and exact-slot ownership checks still apply. */
    if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_CAPTURING){
        for(uint32_t due=0U;due<4U;due++){
            uint32_t before=xe_np_np2_live_sd_mailbox.produced_blocks;
            capture_one();
            if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED)return;
            if(xe_np_np2_live_sd_mailbox.produced_blocks==before ||
               xe_np_np2_live_sd_mailbox.produced_blocks==active_target_blocks)break;
        }
    }
#endif
#if XE_NP_NP2_STAGED_CAPTURE
    service_stage();
    if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED)return;
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA && XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
    /* Publish an already-complete adjacent restore before next-batch selection.
     * Never move a partial copy leg or new copy setup ahead of SD service;
     * existing SD/ring faults retain priority and CMD13 still owns durability. */
    if(overflow_kind==2U && spill_dma_bytes && spill_copy+spill_dma_bytes==RU_BYTES &&
       (GPDMA1_Channel14->CSR&DMA_FLAG_TC) && !sd_ll_fault && card_idle()){
        service_overflow();
        if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED)return;
    }
#endif
    service_write();
    if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED)return;
#if XE_NP_NP2_LIVE_SD_PSRAM_SPILL
    restore_spill();
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
    service_overflow();
    if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED)return;
#endif
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    if(runtime_direct_retire())return;
#endif
    if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_CAPTURING){
#if !(XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE && XE_NP2_STAGE_DIRECT_PSRAM_IDMA)
        capture_one();
        if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED)return;
#endif
#if XE_NP_NP2_STAGED_CAPTURE
        service_stage();
        if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED)return;
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
        /* Packing can complete a C14 leg or an SD BTC can free the second
         * prefetch slot. Service active copying or existing FIFO backlog now,
         * retaining the same ingress/ownership admission before another turn. */
        if(overflow_kind || spill_count){
            service_overflow();
            if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED)return;
        }
#endif
        service_write();
        if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_FAILED)return;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
        if(runtime_direct_retire())return;
#endif
        if(xe_np_np2_live_sd_mailbox.produced_blocks==active_target_blocks){
#if XE_NP_NP2_SD_INGRESS_DMA_TEST
            if(ingress_pending || ingress_dma_active){
                fail(XE_NP_NP2_LIVE_SD_ERROR_STOP,0xD835U);return;
            }
#endif
#if !XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE
            XE_NP_Np2UsbSource_Stop();
            XE_NP_Np2Preparation_SourceStopped();
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
            XE_NP_Np2ClCarrier_PortStop();
#endif
            if(producer->stopped_status(producer->user,&produced)!=0){fail(XE_NP_NP2_LIVE_SD_ERROR_STOP,1U);return;}
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
            /* Source is quiescent, but SD may still have the final ready
             * groups.  Give the stage provider one nonblocking chance to
             * seal/pad that tail before grid16_start_write acquires it. */
            if(grid16.requested)
                grid16.source_stopped(grid16.context,active_target_blocks);
#endif
#endif
            drain_started_ms=HAL_GetTick();
            xe_np_np2_live_sd_mailbox.recording_ms=drain_started_ms-record_started_ms;
            xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_DRAINING;
            publish();
        }
    }
    if(xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_DRAINING &&
       !dma_active && ready_ru()<0 && xe_np_np2_live_sd_mailbox.written_rus==active_target_rus &&
       card_idle() && card->Context==SD_CONTEXT_NONE && !(card->Instance->DCTRL&SDMMC_DCTRL_DTEN) &&
       !(card->Instance->STA&SDMMC_STA_BUSYD0)
#if XE_NP_NP2_LIVE_SD_GRID16_ENABLE
        && (!grid16.requested || (!grid16.active && !grid16.release_pending &&
            grid16.physical_confirmed_lba==record_start_lba+
            active_target_rus*(RU_BLOCKS+grid16.aux_sectors)))
#elif XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST
       && fixed_confirmed_blocks==active_target_rus*RU_BLOCKS
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
       && !overflow_kind && !spill_count && !(GPDMA1_Channel14->CCR&DMA_CCR_EN)
#endif
#if XE_NP_NP2_STAGED_CAPTURE
       && stage_queue.produced==active_target_rus && stage_queue.handed==active_target_rus &&
       stage_queue.committed==active_target_rus && !stage_queue.copy_kind &&
       !stage_queue.spill_count && !stage_dma.active && !stage_queue.sd_active
#endif
       ){
#if XE_NP_NP2_LIVE_SD_VSC_TEST
        int closed=close_vsc();
        if(closed<0){fail(XE_NP_NP2_LIVE_SD_ERROR_STOP,0x56530005U);return;}
        if(!closed)return;
#endif
        xe_np_np2_live_sd_mailbox.drain_ms=HAL_GetTick()-drain_started_ms;
#if XE_NP_NP2_SD_INGRESS_DMA_TEST
        if(ingress_dma_stop()){
            fail(XE_NP_NP2_LIVE_SD_ERROR_STOP,0xD836U);return;
        }
#endif
#if XE_NP_NP2_SD_COPY_WAKE_TEST
        spill_wake_retire();
#endif
#if XE_NP_PSRAM_HOST_PARK_TEST
        if(resume_parked_psram(1U)){
            fail(XE_NP_NP2_LIVE_SD_ERROR_STOP,0xD843U);return;
        }
#endif
        copy_cost_freeze(); /* Capture/drain complete; no media reread is implied. */
        /* All issued writes, overflow owners and source DMA are retired above.
         * COMPLETE means this durable write drain, not payload reread-verified. */
        xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_COMPLETE;
        publish();
    }
#if XE_NP_NP2_CLOSED_LOOP_SPI_ENABLE
    /* All acquisition/write/overflow services above retain priority. */
    XE_NP_Np2ClosedLoopSpi_PortService(ring_depth()>=RU_COUNT-2U);
#endif
#if XE_NP_NP2_LIVE_SD_IDLE_SLEEP
    idle_until_dma_event();
#endif
}

#endif
