/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "xe_np_usb_sd_test_job.h"
#include "xe_np_np2_usb_sd_test.h"
#include "xe_np_sd_tuning_pattern.h"
#include "xe_np_sd_init_diag.h"
#include "xe_np_sd_cmd11_gpio_diag.h"
#include "xe_np_usb_msc.h"
#include "xe_np_sd_info.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "dataMGR.h"
#include "CE32_HJ580.h"
#include "xe_np_np2_sd_ble.h"
#include "xe_np_app.h"
#include "xe_np_capture.h"
#include "xe_np_board.h"
#include "xe_np_np2_acquisition_port.h"
#include "xe_np_np2_read_only_diag.h"
#include "xe_np_np2_pssi_test_diag.h"
#include "xe_np_psram.h"
#include "xe_np_usb_stream.h"
#include "xe_np_usb_unified.h"
#include "xe_np_usb_aux.h"
#include "xe_np_np2_usb_source.h"
#include "xe_np_np2_capture_port.h"
#include "xe_np_sensors_port.h"
#include "xe_np_np2_single_sd_app.h"
#include "xe_np_np2_triple_synthetic_sd.h"
#include "xe_np_np2_live_sd.h"
#include "xe_np_np2_dual_sd_app.h"
#include "xe_np_media_app.h"

#include "stm32u5xx_hal_sd_ex.h"

#include <string.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* DUAL30_PSRAM_SYSCLK192_GUARDS_BEGIN */
#ifndef XE_NP_NP2_SD_DUAL30_PSRAM_SYSCLK192_TEST
#define XE_NP_NP2_SD_DUAL30_PSRAM_SYSCLK192_TEST 0U
#endif
#if (XE_NP_NP2_SD_DUAL30_PSRAM_SYSCLK192_TEST!=0U && XE_NP_NP2_SD_DUAL30_PSRAM_SYSCLK192_TEST!=1U) || \
    (XE_NP_NP2_SD_DUAL30_PSRAM_SYSCLK192_TEST && \
     (XE_NP_IMAGE_ROLE!=1U || !XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || \
      !XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
      !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || \
      !XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS || !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || \
      XE_NP_NP2_LIVE_SD_DIRECT || !XE_NP_PSRAM_OVERFLOW_PLL1Q128 || \
      XE_NP_PSRAM_OVERFLOW_PLL2Q108 || XE_NP_PSRAM_OVERFLOW_PLL1Q_30KHZ_DIV!=4U || \
      XE_NP_PSRAM_OVERFLOW_PRESCALER!=1U || !XE_NP_PSRAM_PAD_HSLV_ENABLE || \
      XE_NP_BOARD_SD_PLL2Q_HZ!=108000000UL || !XE_NP_BOARD_SD_SDR104_ONLY || \
      XE_NP_BOARD_SD_SDR50_ONLY || XE_NP_BOARD_SD_RX_CLOCK_TEST!=2U))
#error "Dual30 PSRAM SYSCLK192 trial requires the copied runtime PLL1Q96/HSLV SDR104108 APP"
#endif
/* DUAL30_PSRAM_SYSCLK192_GUARDS_END */

#if (XE_NP_PSRAM_MPU_NONCACHEABLE_EXPERIMENT != 0U)
#define XE_NP_PSRAM_MPU_REGION_NUMBER MPU_REGION_NUMBER7
#define XE_NP_PSRAM_MPU_ATTRIBUTES_INDEX MPU_ATTRIBUTES_NUMBER7
#endif

#if (XE_NP_CAPTURE_SRAM3_MPU_NONCACHEABLE != 0U)
#define XE_NP_CAPTURE_SRAM3_MPU_REGION_NUMBER MPU_REGION_NUMBER6
#define XE_NP_CAPTURE_SRAM3_MPU_ATTRIBUTES_INDEX MPU_ATTRIBUTES_NUMBER6
#endif

#if (XE_NP_USB_TX_MPU_NONCACHEABLE != 0U)
#define XE_NP_USB_TX_MPU_REGION_NUMBER MPU_REGION_NUMBER5
#define XE_NP_USB_TX_MPU_ATTRIBUTES_INDEX MPU_ATTRIBUTES_NUMBER5
#endif

#ifndef XE_NP_USB_EP0_SETUP_NC_TEST
#define XE_NP_USB_EP0_SETUP_NC_TEST 0U
#endif
#if (XE_NP_USB_EP0_SETUP_NC_TEST!=0U && XE_NP_USB_EP0_SETUP_NC_TEST!=1U) || \
    (XE_NP_USB_EP0_SETUP_NC_TEST && \
     (XE_NP_IMAGE_ROLE!=XE_NP_IMAGE_USB_SERVICE || !XE_NP_USB_TX_MPU_NONCACHEABLE || \
      !XE_NP_BOARD_USB_OTG_HS_INTERNAL_DMA))
#error "SETUP non-cacheable trial requires the DMA USB service MPU policy"
#endif

#ifndef XE_NP_BOARD_EXPERIMENT_MCO_GPIO_SPEED
#define XE_NP_BOARD_EXPERIMENT_MCO_GPIO_SPEED GPIO_SPEED_FREQ_HIGH
#endif

#ifndef XE_NP_NP2_READ_ONLY_DIAG_ENABLE
#define XE_NP_NP2_READ_ONLY_DIAG_ENABLE 0U
#endif

#ifndef XE_NP_SD_IDENTIFY_ONLY_DIAG
#define XE_NP_SD_IDENTIFY_ONLY_DIAG 0U
#endif

#ifndef XE_NP_SD_MEDIA_READOUT_DIAG
#define XE_NP_SD_MEDIA_READOUT_DIAG 0U
#endif
#if XE_NP_SD_MEDIA_READOUT_DIAG
#include "xe_np_sd_readout.h"
#endif

#ifndef XE_NP_NP2_PSSI_TEST_DIAG_ENABLE
#define XE_NP_NP2_PSSI_TEST_DIAG_ENABLE 0U
#endif

#ifndef XE_NP_NP2_TRIPLE_SYNTHETIC_SD_ENABLE
#define XE_NP_NP2_TRIPLE_SYNTHETIC_SD_ENABLE 0U
#endif

#if XE_NP_NP2_READ_ONLY_DIAG_ENABLE && XE_NP_NP2_PSSI_TEST_DIAG_ENABLE
#error "Select exactly one NP2 diagnostic image"
#endif

#if XE_NP_NP2_READ_ONLY_DIAG_ENABLE && \
    (!XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_BOARD_NP2_CAPTURE_PROFILE_COUNT)
#error "The NP2 read-only diagnostic requires an explicit NP2 capture clock profile"
#endif

#if XE_NP_NP2_PSSI_TEST_DIAG_ENABLE && \
    (!XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || (XE_NP_BOARD_NP2_CAPTURE_PROFILE_COUNT != 1U))
#error "The NP2 PSSI test diagnostic requires exactly one explicit NP2 clock profile"
#endif

#if XE_NP_NP2_TRIPLE_SYNTHETIC_SD_ENABLE && \
    (!XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_BOARD_EXPERIMENTAL_NP2_128MHZ_20KHZ_CORE || \
     XE_NP_NP2_READ_ONLY_DIAG_ENABLE || XE_NP_NP2_PSSI_TEST_DIAG_ENABLE || \
     XE_NP_NP2_SD_APP_ENABLE || XE_NP_USB_UNIFIED_ENABLE)
#error "The synthetic triple-NP2 SD test requires the exclusive 20 kS/s no-probe profile"
#endif

#if XE_NP_NP2_LIVE_SD_ENABLE && \
    (!XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || \
     !(XE_NP_BOARD_EXPERIMENTAL_NP2_128MHZ_20KHZ_CORE || XE_NP_BOARD_EXPERIMENTAL_NP2_192MHZ_CORE) || \
     !XE_NP_NP2_USB_SOURCE_ENABLE || !XE_NP_NP2_CAPTURE_PORT_ENABLE || \
     (!XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES && \
      ((XE_NP_NP2_LIVE_SD_PROBE_MASK == 7U) != (XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE != 0U))) || \
     XE_NP_NP2_CAPTURE_16BIT_PSSI || \
     XE_NP_NP2_READ_ONLY_DIAG_ENABLE || XE_NP_NP2_PSSI_TEST_DIAG_ENABLE || \
     XE_NP_NP2_SD_APP_ENABLE || XE_NP_NP2_TRIPLE_SYNTHETIC_SD_ENABLE || XE_NP_USB_UNIFIED_ENABLE || \
     XE_NP_IMAGE_ROLE != XE_NP_IMAGE_SD_APP)
#error "The live NP2 SD recorder requires PSSI8 and SPI2-D8 only for three probes"
#endif

#if XE_NP_NP2_SD_APP_ENABLE && \
    (!XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_BOARD_EXPERIMENTAL_NP2_192MHZ_CORE || \
     XE_NP_NP2_READ_ONLY_DIAG_ENABLE || XE_NP_NP2_PSSI_TEST_DIAG_ENABLE || XE_NP_USB_UNIFIED_ENABLE || \
     XE_NP_IMAGE_ROLE != XE_NP_IMAGE_SD_APP)
#error "The NP2 SD recorder is an exclusive dedicated SD application"
#endif

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
ADC_HandleTypeDef hadc2;

DAC_HandleTypeDef hdac1;

DCACHE_HandleTypeDef hdcache1;

I2C_HandleTypeDef hi2c2;
I2C_HandleTypeDef hi2c3;
I2C_HandleTypeDef hi2c4;
I2C_HandleTypeDef hi2c5;
I2C_HandleTypeDef hi2c6;

UART_HandleTypeDef hlpuart1;
UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_usart2_tx;

OSPI_HandleTypeDef hospi1;
OSPI_HandleTypeDef hospi2;

OPAMP_HandleTypeDef hopamp2;

SD_HandleTypeDef hsd1;

SPI_HandleTypeDef hspi1;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim8;

PCD_HandleTypeDef hpcd_USB_OTG_HS;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void SystemPower_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C4_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM8_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USB_OTG_HS_PCD_Init(void);
static void MX_ADC1_Init(void);
static void MX_ADC2_Init(void);
static void MX_DCACHE1_Init(void);
static void MX_FLASH_Init(void);
static void MX_I2C2_Init(void);
static void MX_I2C3_Init(void);
static void MX_I2C6_Init(void);
static void MX_ICACHE_Init(void);
static void MX_LPUART1_UART_Init(void);
static void MX_OPAMP2_Init(void);
static void MX_SDMMC1_SD_Init(void);
static void MX_SPI1_Init(void);
static void MX_DAC1_Init(void);
static void MX_OCTOSPI1_Init(void);
static void MX_I2C5_Init(void);
static void MX_OCTOSPI2_Init(void);
#if ((XE_NP_PSRAM_MPU_NONCACHEABLE_EXPERIMENT != 0U) || \
     (XE_NP_CAPTURE_SRAM3_MPU_NONCACHEABLE != 0U) || \
     (XE_NP_USB_TX_MPU_NONCACHEABLE != 0U))
static void MX_MPU_Init(void);
#endif
/* USER CODE BEGIN PFP */
int XE_NP_Board_RetrySdInit(void);
static void XE_NP_Board_PrepareSdClockDivForSpeedMode(uint32_t speed_mode, uint32_t requested_clock_div);
static void XE_NP_Board_PostInitSdTuning(void);
static void XE_NP_Board_RunSdWriteBench(void);
static void XE_NP_Board_SetSdHighSpeedLowVoltage(FlagStatus status);
void XE_NP_Board_RecordStartupProgressMarker(uint32_t marker);
static void XE_NP_Board_RecordSdBenchMarker(uint32_t marker);
static uint32_t XE_NP_Board_ComputeSdBusHz(void);
static HAL_StatusTypeDef XE_NP_Board_ConfigureSdmmcClockSources(uint32_t sdmmc_clock_source,
                                                              uint32_t iclk_clock_source);
static void XE_NP_Board_RecordSdBenchSetupMs(uint32_t setup_ms);
static void XE_NP_Board_RecordSdSpeedAttemptParams(uint32_t clock_div,
                                                   uint32_t clock_edge,
                                                   uint32_t selclkrx,
                                                   uint32_t sdmmc_clock_source,
                                                   uint32_t iclk_clock_source);
static uint32_t XE_NP_Board_GetSdModeTargetBusHz(uint32_t speed_mode);
static void XE_NP_Board_RecordSdSpeedAttemptClockRate(uint32_t speed_mode, uint32_t min_negotiated_bus_hz);
static HAL_StatusTypeDef XE_NP_Board_TuneSdDelayBlock(uint32_t speed_mode, uint8_t require_1v8);
static HAL_StatusTypeDef XE_NP_Board_ProbeSdMetadataReadWithTimeout(uint32_t timeout_ms);
static HAL_StatusTypeDef XE_NP_Board_TrySdSpeedMode(uint32_t speed_mode,
                                                   uint8_t require_1v8,
                                                   uint32_t clock_div,
                                                   uint32_t clock_edge,
                                                   uint32_t selclkrx,
                                                   uint32_t sdmmc_clock_source,
                                                   uint32_t iclk_clock_source,
                                                   uint32_t min_negotiated_bus_hz);
static HAL_StatusTypeDef XE_NP_Board_TrySdSpeedModeWithSweep(uint32_t speed_mode,
                                                           uint8_t require_1v8,
                                                           uint32_t min_negotiated_bus_hz);
void HAL_SD_DriveTransceiver_1_8V_Callback(FlagStatus status);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

uint8_t xe_np_sd_init_failed = 0U;
#if (XE_NP_BOARD_SD_RX_CLOCK_TEST != 0U)
volatile uint32_t xe_np_sd_signal_test_finished;
volatile uint32_t xe_np_sd_signal_attempt_count;
volatile uint32_t xe_np_sd_signal_attempts[2][14];
volatile uint32_t xe_np_sd_tuning_recovery_count;
volatile uint32_t xe_np_sd_tuning_recovery_failed;
volatile uint32_t xe_np_sd_phase_detail[128][3];
#endif
#if (XE_NP_BOARD_SD_DMA_READ_POLLING_ENABLE != 0U) || (XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U)
volatile uint32_t xe_np_sd_metadata_diag[6];
#endif
static uint8_t xe_np_sd_speed_probe_buf[512] __attribute__((aligned(32)));
volatile XE_NP_BoardSdDiag xe_np_sd_diag = {
  SDMMC_SPEED_MODE_DEFAULT,
  CARD_NORMAL_SPEED,
  CARD_NORMAL_SPEED,
  0U,
  SDMMC_SPEED_MODE_DEFAULT,
  HAL_SD_ERROR_NONE,
  HAL_SD_CARD_READY,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U
};

#define xe_np_sd_signal_1v8_enabled (xe_np_sd_diag.signal_1v8_enabled)
#define xe_np_sd_negotiated_speed_mode (xe_np_sd_diag.negotiated_speed_mode)
#define xe_np_sd_card_speed (xe_np_sd_diag.card_speed)
#define xe_np_sd_card_speed_raw (xe_np_sd_diag.card_speed_raw)
#define xe_np_sd_card_type (xe_np_sd_diag.card_type)
#define xe_np_sd_last_speed_mode_attempt (xe_np_sd_diag.last_speed_mode_attempt)
#define xe_np_sd_last_speed_mode_error (xe_np_sd_diag.last_speed_mode_error)
#define xe_np_sd_last_speed_mode_card_state (xe_np_sd_diag.last_speed_mode_card_state)
#define xe_np_sd_last_speed_mode_status (xe_np_sd_diag.last_speed_mode_status)
#define xe_np_sd_last_speed_mode_clock_div (xe_np_sd_diag.last_speed_mode_clock_div)
#define xe_np_sd_last_speed_mode_clock_edge (xe_np_sd_diag.last_speed_mode_clock_edge)
#define xe_np_sd_last_speed_mode_selclkrx (xe_np_sd_diag.last_speed_mode_selclkrx)
#define xe_np_sd_last_speed_mode_sdmmc_clock_source (xe_np_sd_diag.last_speed_mode_sdmmc_clock_source)
#define xe_np_sd_last_speed_mode_iclk_clock_source (xe_np_sd_diag.last_speed_mode_iclk_clock_source)
#define xe_np_sd_last_speed_mode_sdmmc_kernel_hz (xe_np_sd_diag.last_speed_mode_sdmmc_kernel_hz)
#define xe_np_sd_last_speed_mode_sdmmc_bus_hz (xe_np_sd_diag.last_speed_mode_sdmmc_bus_hz)
#define xe_np_sd_last_speed_mode_sdmmc_target_bus_hz (xe_np_sd_diag.last_speed_mode_sdmmc_target_bus_hz)
#define xe_np_sd_signal_1v8_seen (xe_np_sd_diag.signal_1v8_seen)

#define XE_NP_SD_WRITE_BUDGET_DEFAULT_BYTES_PER_SEC 10000000UL
#define XE_NP_SD_WRITE_BUDGET_HIGH_BYTES_PER_SEC 20000000UL
#define XE_NP_SD_WRITE_BUDGET_SDR50_BYTES_PER_SEC 40000000UL
#define XE_NP_SD_WRITE_BUDGET_SDR104_BYTES_PER_SEC 60000000UL
#define XE_NP_SD_WRITE_BUDGET_DDR_BYTES_PER_SEC 40000000UL
#define XE_NP_SD_TRY_SDR104_READ_VALIDATED (!XE_NP_BOARD_SD_SDR50_ONLY)
#define XE_NP_SD_TRY_SDR50_READ_VALIDATED 1U
#define XE_NP_SD_TRY_DDR_READ_VALIDATED (!XE_NP_BOARD_SD_SDR50_ONLY)
#define XE_NP_SD_TRY_SDR25_HIGH_SPEED 1U
#ifndef XE_NP_SD_VALIDATE_SPEED_READ
#define XE_NP_SD_VALIDATE_SPEED_READ 1U
#endif
#define XE_NP_SD_POST_INIT_TUNING_ENABLE 1U
#define XE_NP_SD_POST_INIT_TUNE_MAX_DIVS 1U
#define XE_NP_SD_POST_INIT_TUNE_MAX_EDGES 2U
#define XE_NP_SD_POST_INIT_TUNE_MAX_SELCLKRX 2U
#if (XE_NP_BOARD_SD_PLL2Q_HZ != 0UL)
#define XE_NP_SD_POST_INIT_TUNE_MAX_ICLK_CLOCK_SOURCES 1U
#define XE_NP_SDMMC_SDMMC_CLOCK_SOURCE_DEFAULT RCC_SDMMCCLKSOURCE_CLK48
#define XE_NP_SDMMC_ICLK_CLOCK_SOURCE_DEFAULT RCC_ICLK_CLKSOURCE_PLL2
#else
#if XE_NP_BOARD_HSE_ONLY_CLOCKS
#define XE_NP_SD_POST_INIT_TUNE_MAX_ICLK_CLOCK_SOURCES 2U
#define XE_NP_SDMMC_ICLK_CLOCK_SOURCE_DEFAULT RCC_ICLK_CLKSOURCE_PLL1
#else
#define XE_NP_SD_POST_INIT_TUNE_MAX_ICLK_CLOCK_SOURCES 3U
#define XE_NP_SDMMC_ICLK_CLOCK_SOURCE_DEFAULT RCC_ICLK_CLKSOURCE_HSI48
#endif
#define XE_NP_SDMMC_SDMMC_CLOCK_SOURCE_DEFAULT RCC_SDMMCCLKSOURCE_PLL1
#endif
#define XE_NP_SD_POST_INIT_TUNE_MAX_SDMMC_CLOCK_SOURCES 1U
#define XE_NP_SD_DLYB_TUNE_ENABLE 1U
#define XE_NP_SD_DLYB_TUNE_PHASE_TIMEOUT_MS 80U
#define XE_NP_SD_DLYB_TUNE_CONFIRM_ATTEMPTS 2U
#define XE_NP_SD_DLYB_TUNE_MANUAL_UNIT_COUNT 8U
#if (XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U)
#define XE_NP_SD_DLYB_TUNE_MAX_UNIT_CANDIDATES 128U
#else
#define XE_NP_SD_DLYB_TUNE_MAX_UNIT_CANDIDATES 8U
#endif
#define XE_NP_SD_SDR104_MIN_NEGOTIATED_BUS_HZ 180000000UL
#define XE_NP_SD_SDR104_PREFERRED_NEGOTIATED_BUS_HZ 186000000UL
#define XE_NP_SD_SDR104_ALLOW_CLOCKDIV0_LOWER_KERNEL 1U
#ifndef XE_NP_SD_ALLOW_HIGH_SPEED_RAW_PROCESS_TEST
#define XE_NP_SD_ALLOW_HIGH_SPEED_RAW_PROCESS_TEST 0U
#endif
#ifndef XE_NP_SD_ALLOW_HIGH_SPEED_BASIC_TEST
#define XE_NP_SD_ALLOW_HIGH_SPEED_BASIC_TEST 0U
#endif
#if XE_NP_SD_ALLOW_HIGH_SPEED_RAW_PROCESS_TEST && !XE_NP_NP2_LIVE_SD_ENABLE
#error "3.3 V high-speed raw capture is limited to an explicit NP2 live-SD process test"
#endif
#if !XE_NP_SD_VALIDATE_SPEED_READ && !XE_NP_SD_ALLOW_HIGH_SPEED_RAW_PROCESS_TEST && !XE_NP_SD_ALLOW_HIGH_SPEED_BASIC_TEST
#error "Skipping SD speed-mode preflight read is limited to bounded High-Speed data-path diagnostics"
#endif
#ifndef XE_NP_SD_POWER_RAIL_OFF_MS
#define XE_NP_SD_POWER_RAIL_OFF_MS 100U
#endif
#define XE_NP_SD_POWER_RAIL_SETTLE_MS 250U

/* SD_COLD_RETRY_GUARDS_BEGIN */
/* One private pre-bind retry, never an active-card recovery policy. */
#ifndef XE_NP_SD_COLD_RETRY_TEST
#define XE_NP_SD_COLD_RETRY_TEST 0U
#endif
#if (XE_NP_SD_COLD_RETRY_TEST!=0U && XE_NP_SD_COLD_RETRY_TEST!=1U) || \
    (XE_NP_SD_COLD_RETRY_TEST && \
     (!XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || \
      (!XE_NP_SD_CMD11_PIN_COMPAT_ENABLE && !XE_NP_USB_UNIFIED_ENABLE) || \
      XE_NP_SD_POWER_RAIL_OFF_MS!=3000U || XE_NP_SD_TEAMGROUP_UHS_STARTUP_TEST || \
      (!XE_NP_NP2_DUAL_SD_APP_ENABLE && !XE_NP_USB_UNIFIED_ENABLE)))
#error "Cold SD retry requires guarded V2 APP/unified USB entry, ordinary CMD11 and the checked 3000ms rail interval"
#endif
/* SD_COLD_RETRY_GUARDS_END */

#define XE_NP_SD_BENCH_MAGIC 0x5344424EUL
#define XE_NP_SD_BENCH_VERSION 5U
#define XE_NP_SD_BENCH_ENABLE XE_NP_BOARD_SD_WRITE_BENCH_IMAGE
#define XE_NP_SD_BENCH_USE_IDMA_LINKED_LIST 1U
#define XE_NP_SD_BENCH_USE_CMD23_BLOCK_COUNT 1U
#ifndef XE_NP_SD_BENCH_USE_CMD23_NO_CMD12
#define XE_NP_SD_BENCH_USE_CMD23_NO_CMD12 1U
#endif
#define XE_NP_SD_BENCH_USE_ACMD23_PRE_ERASE 1U
#define XE_NP_SD_BENCH_USE_RANGE_ERASE 1U
#define XE_NP_SD_BENCH_USE_CMD20_START_RECORDING 1U
#define XE_NP_SD_BENCH_DISABLE_IDMABTC_IRQ 0U
#define XE_NP_SD_BENCH_START_BLOCK DATA_ADDR
#define XE_NP_SD_BENCH_CHUNK_BLOCKS 256UL
#define XE_NP_SD_BENCH_BLOCK_BYTES 512UL
#ifndef XE_NP_SD_BENCH_SOURCE_SRAM3
#define XE_NP_SD_BENCH_SOURCE_SRAM3 0U
#endif
#ifndef XE_NP_SD_BENCH_LL_NODE_BLOCKS
#define XE_NP_SD_BENCH_LL_NODE_BLOCKS 127UL
#endif
#ifndef XE_NP_SD_BENCH_RETARGET_INTEGRITY_TEST
#define XE_NP_SD_BENCH_RETARGET_INTEGRITY_TEST 0U
#endif
#define XE_NP_SD_BENCH_RETARGET_PASSES 2UL
#define XE_NP_SD_BENCH_RETARGET_TOTAL_BLOCKS \
  (XE_NP_SD_BENCH_LL_NODE_BLOCKS * XE_NP_SD_BENCH_LL_NODE_COUNT * \
   XE_NP_SD_BENCH_RETARGET_PASSES)
#define XE_NP_SD_BENCH_LL_NODE_COUNT 2UL
#ifndef XE_NP_SD_BENCH_LL_TRANSFER_CYCLES
#define XE_NP_SD_BENCH_LL_TRANSFER_CYCLES 258UL
#endif
#define XE_NP_SD_BENCH_LL_NODE_BYTES \
  (XE_NP_SD_BENCH_LL_NODE_BLOCKS * XE_NP_SD_BENCH_BLOCK_BYTES)
#define XE_NP_SD_BENCH_LL_TRANSFER_BLOCKS \
  (XE_NP_SD_BENCH_LL_NODE_BLOCKS * XE_NP_SD_BENCH_LL_NODE_COUNT * XE_NP_SD_BENCH_LL_TRANSFER_CYCLES)
#if (XE_NP_SD_BENCH_USE_IDMA_LINKED_LIST != 0U)
#define XE_NP_SD_BENCH_TOTAL_BLOCKS (XE_NP_SD_BENCH_LL_TRANSFER_BLOCKS * 16UL)
#else
#define XE_NP_SD_BENCH_TOTAL_BLOCKS (1024UL * 1024UL)
#endif
#define XE_NP_SD_BENCH_CHUNK_BYTES \
  (XE_NP_SD_BENCH_CHUNK_BLOCKS * XE_NP_SD_BENCH_BLOCK_BYTES)
#define XE_NP_SD_BENCH_CHUNK_TIMEOUT_MS 10000U
#define XE_NP_SD_BENCH_TOTAL_TIMEOUT_MS 60000U
#define XE_NP_SD_BENCH_METHOD_CHUNK_DMA 1U
#define XE_NP_SD_BENCH_METHOD_IDMA_LINKED_LIST 2U
#define XE_NP_SD_BENCH_PREP_FLAG_CMD23 0x00000001UL
#define XE_NP_SD_BENCH_PREP_FLAG_ACMD23 0x00000002UL
#define XE_NP_SD_BENCH_PREP_FLAG_NO_IDMABTC_IRQ 0x00000004UL
#define XE_NP_SD_BENCH_PREP_FLAG_NO_CMD12 0x00000008UL
#define XE_NP_SD_BENCH_PREP_FLAG_RANGE_ERASE 0x00000010UL
#define XE_NP_SD_BENCH_PREP_FLAG_CMD20_START_RECORDING 0x00000020UL
#define XE_NP_SD_BENCH_PREP_FLAG_HSLV 0x00000040UL
#define XE_NP_SD_BENCH_CMD20_SCC_START_RECORDING 0U
#define XE_NP_SD_BENCH_DIAG_MAIN_REACHED 0x6D61696EU
#define XE_NP_SD_BENCH_DIAG_BEFORE_START 0x6265676EU
#define XE_NP_SD_BENCH_DIAG_BEFORE_BENCH 0x6265666FU
#define XE_NP_SD_BENCH_DIAG_AFTER_BENCH 0x61667472U
#define XE_NP_SD_BENCH_DIAG_FUNCTION_ENTER 0x66756E63
#define XE_NP_SD_BENCH_DIAG_BEFORE_HAL_INIT 0x48414C30U
#define XE_NP_SD_BENCH_DIAG_AFTER_HAL_INIT 0x48414C31U
#define XE_NP_SD_BENCH_DIAG_AFTER_POWER 0x50575231U
#define XE_NP_SD_BENCH_DIAG_AFTER_CLOCK 0x434C4B31U
#define XE_NP_SD_BENCH_DIAG_AFTER_GPIO 0x47504931U
#define XE_NP_SD_BENCH_DIAG_AFTER_SD_RAIL 0x5241494CU
#define XE_NP_SD_BENCH_DIAG_AFTER_USB 0x55534231U
#define XE_NP_SD_BENCH_DIAG_AFTER_DCACHE 0x44434831U
#define XE_NP_SD_BENCH_DIAG_AFTER_FLASH 0x464C5331U
#define XE_NP_SD_BENCH_DIAG_AFTER_ICACHE 0x49434831U
#define XE_NP_SD_BENCH_DIAG_AFTER_OPAMP 0x4F504131U
#define XE_NP_SD_BENCH_DIAG_BEFORE_SD_INIT 0x53444930U
#define XE_NP_SD_BENCH_DIAG_AFTER_SD_HOST_BASE 0x53484231U
#define XE_NP_SD_BENCH_DIAG_BEFORE_SD_TUNE 0x53545530U
#define XE_NP_SD_BENCH_DIAG_AFTER_SD_TUNE 0x53545531U
#define XE_NP_SD_BENCH_DIAG_POST_INIT_ENTRY 0x50494E49U
#define XE_NP_SD_BENCH_DIAG_POST_INIT_AFTER_RAIL 0x50415231U
#define XE_NP_SD_BENCH_DIAG_SWEEP_ENTRY 0x53575031U
#define XE_NP_SD_BENCH_DIAG_BEFORE_SD_SWEEP_RESET 0x53575230U
#define XE_NP_SD_BENCH_DIAG_AFTER_SD_SWEEP_RESET 0x53575231U
#define XE_NP_SD_BENCH_DIAG_BEFORE_SD_SPEED_SWITCH 0x53535730U
#define XE_NP_SD_BENCH_DIAG_AFTER_SD_SPEED_SWITCH 0x53535731U
#define XE_NP_SD_BENCH_DIAG_SD_SPEED_SWITCH_FAIL 0x53535745U
#define XE_NP_SD_BENCH_DIAG_AFTER_SD_INIT 0x53444931U
#define XE_NP_STARTUP_MARK_RESET_HANDLER 0x52535445U
#define XE_NP_STARTUP_MARK_SYSTEM_INIT 0x53595354U
#define XE_NP_STARTUP_MARK_MAIN_ENTRY 0x4D41494EU
#define XE_NP_STARTUP_MARK_BEFORE_BENCH 0x42454642U
#define XE_NP_STARTUP_MARK_BENCH_ENTRY 0x454E5452U
#define XE_NP_STARTUP_MARK_BENCH_RETURN 0x41525242U

#if (XE_NP_SD_BENCH_SOURCE_SRAM3 != 0U)
static uint8_t xe_np_sd_bench_buf[XE_NP_SD_BENCH_CHUNK_BYTES]
  __attribute__((aligned(32), section("NP_CAPTURE")));
#else
static uint8_t xe_np_sd_bench_buf[XE_NP_SD_BENCH_CHUNK_BYTES] __attribute__((aligned(32)));
#endif
static SD_DMALinkNodeTypeDef xe_np_sd_bench_ll_nodes[XE_NP_SD_BENCH_LL_NODE_COUNT] __attribute__((aligned(32)));
static SD_DMALinkedListTypeDef xe_np_sd_bench_ll __attribute__((aligned(32)));
#if (XE_NP_SD_BENCH_RETARGET_INTEGRITY_TEST != 0U)
/* The second pass must use distinct addresses, not merely freshly written data
 * at the old addresses.  That proves SDMMC re-fetches a modified ULA node. */
static uint8_t xe_np_sd_bench_retarget_buf[XE_NP_SD_BENCH_LL_NODE_COUNT *
                                           XE_NP_SD_BENCH_LL_NODE_BYTES]
  __attribute__((aligned(32), section("NP_CAPTURE")));
#endif
static uint32_t xe_np_sd_bench_ll_last_node_tick = 0U;
static const uint32_t xe_np_sd_post_init_uhs_divs[XE_NP_SD_POST_INIT_TUNE_MAX_DIVS] = {
  0U
};
static const uint32_t xe_np_sd_post_init_uhs_clock_edges[XE_NP_SD_POST_INIT_TUNE_MAX_EDGES] = {
#if XE_NP_BOARD_SD_RISING_EDGE_FIRST
  SDMMC_CLOCK_EDGE_RISING,
  SDMMC_CLOCK_EDGE_FALLING
#else
  SDMMC_CLOCK_EDGE_FALLING,
  SDMMC_CLOCK_EDGE_RISING
#endif
};
static const uint32_t xe_np_sd_post_init_uhs_selclkrx[XE_NP_SD_POST_INIT_TUNE_MAX_SELCLKRX] = {
  SDMMC_CLKCR_SELCLKRX_1, /* tuned DLYB feedback */
  SDMMC_CLKCR_SELCLKRX_0  /* direct external CKIN, for SDR50/DDR only */
};
/*
 * For the 187.2 MHz experimental core build, PLL1P is intentionally moved to
 * an intermediate SDMMC kernel point while PLL1R keeps SYSCLK/HCLK at 187.2
 * MHz and MCO remains at 93.6 MHz. Keep the highest-rate paths first and vary
 * only the receive-clock edge/mux plus the ICLK source.
 */
static const uint32_t xe_np_sd_post_init_uhs_sdmmc_sources[XE_NP_SD_POST_INIT_TUNE_MAX_SDMMC_CLOCK_SOURCES] = {
  XE_NP_SDMMC_SDMMC_CLOCK_SOURCE_DEFAULT
};
static const uint32_t xe_np_sd_post_init_uhs_iclk_sources[XE_NP_SD_POST_INIT_TUNE_MAX_ICLK_CLOCK_SOURCES] = {
  RCC_ICLK_CLKSOURCE_PLL2,
#if (XE_NP_BOARD_SD_PLL2Q_HZ == 0UL)
  RCC_ICLK_CLKSOURCE_PLL1,
#if !XE_NP_BOARD_HSE_ONLY_CLOCKS
  RCC_ICLK_CLKSOURCE_HSI48
#endif
#endif
};

#if (XE_NP_V2_MEDIA_ENABLE || XE_NP_NP2_DUAL_SD_APP_ENABLE || XE_NP_SD_BASIC_CURRENT_EXTENT || XE_NP_NP2_LIVE_SD_DUAL_SCRATCH_OVERFLOW_DMA || XE_NP_USB_UNIFIED_ENABLE) && (XE_NP_BOARD_SD_SDR104_ONLY != 0U)
/* Startup-only evidence, never updated by capture/SD service. Words: magic,
 * version, initial init-count/OCR/1v8/attempt-mode/HAL-state/HAL-error,
 * fresh-session-reused, final status/init-count/OCR. Keep the initial OCR
 * visible when the existing reset fallback replaces the HAL diagnostics. */
volatile uint32_t xe_np_sd_first_session_diag[12];
#endif
volatile XE_NP_BoardSdBenchDiag xe_np_sd_bench_diag = {
  XE_NP_SD_BENCH_MAGIC,
  XE_NP_SD_BENCH_VERSION,
  XE_NP_SD_BENCH_STATUS_PRE_MAIN,
  SDMMC_SPEED_MODE_DEFAULT,
  0U,
  0U,
  CARD_NORMAL_SPEED,
  0U,
  XE_NP_SD_BENCH_START_BLOCK,
  XE_NP_SD_BENCH_TOTAL_BLOCKS,
  XE_NP_SD_BENCH_CHUNK_BLOCKS,
  0U,
  0U,
  0U,
  0U,
  0U,
  HAL_SD_ERROR_NONE,
  HAL_SD_CARD_READY,
  HAL_SD_STATE_RESET,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0U,
  0ULL
};

volatile uint32_t xe_np_hw_startup_rcc_csr = 0U;
volatile uint32_t xe_np_hw_startup_cfsr = 0U;
volatile uint32_t xe_np_hw_startup_hfsr = 0U;
volatile uint32_t xe_np_hw_startup_bfar = 0U;
volatile uint32_t xe_np_hw_startup_mmfar = 0U;
volatile uint32_t xe_np_sd_boot_stage_marker __attribute__((used, aligned(4), section("NOINIT")));

void XE_NP_Board_RecordStartupProgressMarker(uint32_t marker)
{
  PWR->DBPR |= PWR_DBPR_DBP;
  TAMP->BKP5R = marker;
  TAMP->BKP4R = TAMP->BKP3R;
  TAMP->BKP3R = TAMP->BKP2R;
  TAMP->BKP2R = TAMP->BKP1R;
  TAMP->BKP1R = TAMP->BKP0R;
  TAMP->BKP0R = marker;
  xe_np_sd_boot_stage_marker = marker;
#if defined(__DCACHE_PRESENT) && (__DCACHE_PRESENT == 1U)
  {
    uintptr_t start_addr = ((uintptr_t)&xe_np_sd_boot_stage_marker) & ~((uintptr_t)31U);
    uintptr_t end_addr = (((uintptr_t)&xe_np_sd_boot_stage_marker) + sizeof(xe_np_sd_boot_stage_marker) + 31U) &
                         ~((uintptr_t)31U);
    SCB_CleanDCache_by_Addr((void *)start_addr, (int32_t)(end_addr - start_addr));
  }
#endif
}

void XE_NP_Board_RecordStartupFaultRegs(void)
{
  xe_np_hw_startup_rcc_csr = RCC->CSR;
  xe_np_hw_startup_cfsr = SCB->CFSR;
  xe_np_hw_startup_hfsr = SCB->HFSR;
  xe_np_hw_startup_bfar = SCB->BFAR;
  xe_np_hw_startup_mmfar = SCB->MMFAR;
}

static void XE_NP_Board_SetSdHighSpeedLowVoltage(FlagStatus status)
{
#if defined(XE_NP_SD_PAD_HSLV_DISABLE) && XE_NP_SD_PAD_HSLV_DISABLE
  /* Keep the SD electrical baseline independent of probe HSLV provisioning. */
  status = RESET;
#endif
  const uint16_t gpioc_pins = GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_12;
  const uint16_t gpiod_pins = GPIO_PIN_2;
  const uint16_t gpiob_pins = GPIO_PIN_8;

  if (status == SET)
  {
    /* These are host-side pins on the fixed 1.8 V VCCA domain. HSLV is
     * permitted only on boards explicitly provisioned for low-voltage I/O. */
    if((FLASH->OPTR & FLASH_OPTR_IO_VDD_HSLV) == 0U) { return; }
    HAL_GPIO_EnableHighSPeedLowVoltage(GPIOC, gpioc_pins);
    HAL_GPIO_EnableHighSPeedLowVoltage(GPIOD, gpiod_pins);
    HAL_GPIO_EnableHighSPeedLowVoltage(GPIOB, gpiob_pins);
  }
  else
  {
    HAL_GPIO_DisableHighSPeedLowVoltage(GPIOC, gpioc_pins);
    HAL_GPIO_DisableHighSPeedLowVoltage(GPIOD, gpiod_pins);
    HAL_GPIO_DisableHighSPeedLowVoltage(GPIOB, gpiob_pins);
  }
}

void HAL_SD_DriveTransceiver_1_8V_Callback(FlagStatus status)
{
  /*
   * Board wiring:
   * - SD card VDD_3V3 remains present from the storage-side supply domain.
   * - SD_VSEL low selects 3.3 V logic signaling on VCCIO_SD.
   * - SD_VSEL high selects 1.8 V logic signaling on VCCIO_SD for UHS modes.
   */
  /* This flag reports the commanded selection, NOT an analog measurement
   * of VCCIO_SD. The HAL CMD11 handshake and negotiated mode are also required. */
  xe_np_sd_signal_1v8_enabled = 0U;
  if (status == SET)
  {
    xe_np_sd_signal_1v8_seen = 1U;
    HAL_GPIO_WritePin(SD_VSEL_GPIO_Port, SD_VSEL_Pin, GPIO_PIN_SET);
    /* SD voltage switching requires at least 5 ms for the new I/O supply. */
    HAL_Delay(5U);
    XE_NP_Board_SetSdHighSpeedLowVoltage(SET);
    xe_np_sd_signal_1v8_enabled =
        (HAL_GPIO_ReadPin(SD_VSEL_GPIO_Port, SD_VSEL_Pin) == GPIO_PIN_SET) ? 1U : 0U;
  }
  else
  {
    XE_NP_Board_SetSdHighSpeedLowVoltage(RESET);
    HAL_GPIO_WritePin(SD_VSEL_GPIO_Port, SD_VSEL_Pin, GPIO_PIN_RESET);
    HAL_Delay(1U);
  }
}

int XE_NP_Board_SdUhsReadyForNpRaw(void)
{
#if (XE_NP_SD_ALLOW_HIGH_SPEED_RAW_PROCESS_TEST != 0U)
  if ((xe_np_sd_init_failed == 0U) &&
      (xe_np_sd_negotiated_speed_mode == SDMMC_SPEED_MODE_HIGH) &&
      (HAL_GPIO_ReadPin(SD_VSEL_GPIO_Port, SD_VSEL_Pin) == GPIO_PIN_RESET))
  {
    return 1;
  }
#endif

  /*
   * Direct Neuropixels raw logging only makes sense once VCCIO_SD logic has
   * actually switched to the 1.8 V UHS path and the negotiated bus mode is
   * one of the UHS transport modes we explicitly accepted. This is independent
   * of the SD card VDD_3V3 supply, which remains present.
   */
  return ((xe_np_sd_init_failed == 0U) &&
          (xe_np_sd_signal_1v8_enabled != 0U) &&
          ((xe_np_sd_negotiated_speed_mode == SDMMC_SPEED_MODE_ULTRA_SDR104) ||
           (xe_np_sd_negotiated_speed_mode == SDMMC_SPEED_MODE_ULTRA_SDR50) ||
           (xe_np_sd_negotiated_speed_mode == SDMMC_SPEED_MODE_DDR)) &&
          (HAL_GPIO_ReadPin(SD_VSEL_GPIO_Port, SD_VSEL_Pin) == GPIO_PIN_SET)) ? 1 : 0;
}

uint32_t XE_NP_Board_SdNegotiatedSpeedMode(void)
{
  return xe_np_sd_negotiated_speed_mode;
}

uint32_t XE_NP_Board_SdEstimatedWriteBudgetBytesPerSec(void)
{
  uint32_t profile;
  /*
   * These are conservative sustained-write budgets for the current
   * M33+SDMMC+filesystem mitigation path, not signaling maxima. The intent is
   * to fail fast on clearly unrealistic Neuropixels raw-rate demands.
   */
  switch (xe_np_sd_negotiated_speed_mode)
  {
    case SDMMC_SPEED_MODE_ULTRA_SDR104:
      profile=XE_NP_SD_WRITE_BUDGET_SDR104_BYTES_PER_SEC;break;
    case SDMMC_SPEED_MODE_ULTRA_SDR50:
      profile=XE_NP_SD_WRITE_BUDGET_SDR50_BYTES_PER_SEC;break;
    case SDMMC_SPEED_MODE_DDR:
      profile=XE_NP_SD_WRITE_BUDGET_DDR_BYTES_PER_SEC;break;
    case SDMMC_SPEED_MODE_HIGH:
      profile=XE_NP_SD_WRITE_BUDGET_HIGH_BYTES_PER_SEC;break;
    case SDMMC_SPEED_MODE_DEFAULT:
    default:
      profile=XE_NP_SD_WRITE_BUDGET_DEFAULT_BYTES_PER_SEC;break;
  }
  if(hsd1.Instance==NULL || xe_np_sd_init_failed) { return 0U; }
  return XE_NP_SdCapWriteBudget(XE_NP_Board_ComputeSdBusHz(),
      hsd1.Init.BusWide==SDMMC_BUS_WIDE_4B?4U:1U,
      (hsd1.Instance->CLKCR & SDMMC_CLKCR_DDR)!=0U,profile);
}

const volatile XE_NP_BoardSdDiag *XE_NP_Board_SdDiag(void)
{
  return &xe_np_sd_diag;
}

const volatile XE_NP_BoardSdBenchDiag *XE_NP_Board_SdBenchDiag(void)
{
  return &xe_np_sd_bench_diag;
}

static void XE_NP_Board_SetSdInitFailed(uint8_t failed)
{
  xe_np_sd_init_failed = failed;
  xe_np_sd_diag.init_failed = failed;
}

static uint32_t XE_NP_Board_NormalizeSdCardSpeed(uint32_t card_speed, uint32_t card_type)
{
  if ((card_speed == CARD_ULTRA_HIGH_SPEED) ||
      (card_speed == CARD_HIGH_SPEED) ||
      (card_speed == CARD_NORMAL_SPEED))
  {
    return card_speed;
  }

  /*
   * Some HAL paths can leave a raw card-status/class value in CardSpeed after
   * fallback. Keep card_speed as a small HAL-style capability enum so the SWD
   * diagnostic is stable, while card_speed_raw preserves the underlying value.
   */
  return (card_type == CARD_SDHC_SDXC) ? CARD_HIGH_SPEED : CARD_NORMAL_SPEED;
}

static uint32_t XE_NP_Board_ComputeSdBusHz(void)
{
  uint32_t sdmmc_kernel_hz = HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SDMMC);
  uint32_t clock_div = hsd1.Init.ClockDiv;

  if (hsd1.Instance != NULL)
  {
    clock_div = hsd1.Instance->CLKCR & SDMMC_CLKCR_CLKDIV;
  }

  if (clock_div == 0U)
  {
    return sdmmc_kernel_hz;
  }

  return sdmmc_kernel_hz / (2U * clock_div);
}

static void XE_NP_Board_RecordSdBenchSetupMs(uint32_t setup_ms)
{
  xe_np_sd_bench_diag.last_setup_ms = setup_ms;
  xe_np_sd_bench_diag.total_setup_ms += setup_ms;
  if (setup_ms > xe_np_sd_bench_diag.worst_setup_ms)
  {
    xe_np_sd_bench_diag.worst_setup_ms = setup_ms;
  }
}

static uint32_t XE_NP_Board_GetSdModeTargetBusHz(uint32_t speed_mode)
{
#if XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ != 0UL
  if (speed_mode == SDMMC_SPEED_MODE_HIGH)
  {
    return XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ;
  }
#endif
  if (speed_mode == SDMMC_SPEED_MODE_ULTRA_SDR104)
  {
#if (XE_NP_BOARD_SD_SDR104_ONLY != 0U)
    return XE_NP_BOARD_SD_TEST_CLKDIV ?
        XE_NP_BOARD_SD_PLL2Q_HZ/(2U*XE_NP_BOARD_SD_TEST_CLKDIV) : XE_NP_BOARD_SD_PLL2Q_HZ;
#else
    return XE_NP_SD_SDR104_MIN_NEGOTIATED_BUS_HZ;
#endif
  }
  if (speed_mode == SDMMC_SPEED_MODE_DDR)
  {
    return 0U;
  }

  return 0U;
}

static void XE_NP_Board_RecordSdSpeedAttemptParams(uint32_t clock_div,
                                                  uint32_t clock_edge,
                                                  uint32_t selclkrx,
                                                  uint32_t sdmmc_clock_source,
                                                  uint32_t iclk_clock_source)
{
  xe_np_sd_last_speed_mode_clock_div = clock_div;
  xe_np_sd_last_speed_mode_clock_edge = clock_edge;
  xe_np_sd_last_speed_mode_selclkrx = selclkrx;
  xe_np_sd_last_speed_mode_sdmmc_clock_source = sdmmc_clock_source;
  xe_np_sd_last_speed_mode_iclk_clock_source = iclk_clock_source;
}

static void XE_NP_Board_RecordSdSpeedAttemptClockRate(uint32_t speed_mode,
                                                     uint32_t min_negotiated_bus_hz)
{
  uint32_t target_bus_hz;

  xe_np_sd_last_speed_mode_sdmmc_kernel_hz = HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SDMMC);
  xe_np_sd_last_speed_mode_sdmmc_bus_hz = XE_NP_Board_ComputeSdBusHz();
  target_bus_hz = XE_NP_Board_GetSdModeTargetBusHz(speed_mode);
  if ((min_negotiated_bus_hz != 0U) && (min_negotiated_bus_hz > target_bus_hz))
  {
    target_bus_hz = min_negotiated_bus_hz;
  }
  xe_np_sd_last_speed_mode_sdmmc_target_bus_hz = target_bus_hz;
}

static void XE_NP_Board_ClearSdSpeedAttemptError(void)
{
  hsd1.ErrorCode = HAL_SD_ERROR_NONE;
  hsd1.State = HAL_SD_STATE_READY;
}

static HAL_StatusTypeDef XE_NP_Board_ConfigureSdmmcClockSources(uint32_t sdmmc_clock_source,
                                                              uint32_t iclk_clock_source)
{
  RCC_PeriphCLKInitTypeDef periph_clk = {0};

  HAL_RCCEx_GetPeriphCLKConfig(&periph_clk);

  periph_clk.PeriphClockSelection = RCC_PERIPHCLK_SDMMC | RCC_PERIPHCLK_CLK48;
  periph_clk.IclkClockSelection = iclk_clock_source;
  periph_clk.SdmmcClockSelection = sdmmc_clock_source;

  if (iclk_clock_source == RCC_ICLK_CLKSOURCE_PLL2)
  {
    if (periph_clk.PLL2.PLL2Source == 0U)
    {
      return HAL_ERROR;
    }
    /* HAL_GetPeriphCLKConfig does not populate PLL2ClockOut. Never OR an
     * uninitialized mask into PLL2CFGR: it can also corrupt source/M/range. */
    periph_clk.PLL2.PLL2ClockOut =
        (RCC->PLL2CFGR & (RCC_PLL2_DIVP|RCC_PLL2_DIVQ|RCC_PLL2_DIVR)) | RCC_PLL2_DIVQ;
    periph_clk.PLL2.PLL2RGE = RCC->PLL2CFGR & RCC_PLL2CFGR_PLL2RGE;
  }

  if (HAL_RCCEx_PeriphCLKConfig(&periph_clk) != HAL_OK)
  {
    return HAL_ERROR;
  }

  return HAL_OK;
}

static void XE_NP_Board_ResetSdPowerRail(void)
{
  /* This toggles the requested enable; it does NOT prove a cold card reset.
   * V2 schematic U12 (SN74LVC1G3157) has V+ on VEE_3V3 but T2 on always-on
   * VDD_1V8. That part has no powered-off protection: an off rail may be
   * back-powered. Confirm the assembled switch / physical rail discharge
   * before using this sequence as a power-cycle experiment. No GPIO must be
   * used as a substitute rail-discharge load. */
  XE_NP_Board_SetSdHighSpeedLowVoltage(RESET);
  HAL_GPIO_WritePin(SD_VSEL_GPIO_Port, SD_VSEL_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(VEE_EN_GPIO_Port, VEE_EN_Pin, GPIO_PIN_RESET);
  HAL_Delay(XE_NP_SD_POWER_RAIL_OFF_MS);
  HAL_GPIO_WritePin(VEE_EN_GPIO_Port, VEE_EN_Pin, GPIO_PIN_SET);
  HAL_Delay(XE_NP_SD_POWER_RAIL_SETTLE_MS);
}

#if (XE_NP_BOARD_SD_DMA_READ_POLLING_ENABLE != 0U) || (XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U)
HAL_StatusTypeDef XE_NP_Board_SdReadBlocksDmaPolling(SD_HandleTypeDef *card,uint8_t *data,
                                                   uint32_t block,uint32_t blocks,uint32_t timeout_ms)
{
  uint32_t irq_enabled=NVIC_GetEnableIRQ(SDMMC1_IRQn);
  uint32_t started=HAL_GetTick(),sta=0U;
#if XE_NP_NP2_LIVE_SD_ENABLE && XE_NP_NP2_SD_BLE_ENABLE && XE_NP_NP2_DUAL_SD_APP_ENABLE
  uint32_t ble_poll_tick=started;
#endif
  HAL_StatusTypeDef result;
  if(card==NULL || card->Instance!=SDMMC1 || data==NULL || ((uintptr_t)data&3U) ||
     blocks==0U || blocks>65535U || timeout_ms==0U) {return HAL_ERROR;}
  /* Poll the HAL IRQ handler in foreground: IDMA avoids CPU FIFO backpressure
   * without making error-handler timeouts depend on lower-priority ticks. */
  NVIC_DisableIRQ(SDMMC1_IRQn);
  xe_np_sd_metadata_diag[0]=1U;
  result=HAL_SD_ReadBlocks_DMA(card,data,block,blocks);
  if(result==HAL_OK) {
    xe_np_sd_metadata_diag[0]=2U;
    while(card->State!=HAL_SD_STATE_READY) {
      sta=card->Instance->STA;
      if(sta & (SDMMC_FLAG_DATAEND|SDMMC_FLAG_DCRCFAIL|SDMMC_FLAG_DTIMEOUT|SDMMC_FLAG_RXOVERR|SDMMC_FLAG_IDMATE)) {
        HAL_SD_IRQHandler(card);
        if(sta & (SDMMC_FLAG_DCRCFAIL|SDMMC_FLAG_DTIMEOUT|SDMMC_FLAG_RXOVERR|SDMMC_FLAG_IDMATE)) {
          if(sta & SDMMC_FLAG_DCRCFAIL) {card->ErrorCode|=HAL_SD_ERROR_DATA_CRC_FAIL;}
          if(sta & SDMMC_FLAG_DTIMEOUT) {card->ErrorCode|=HAL_SD_ERROR_DATA_TIMEOUT;}
          if(sta & SDMMC_FLAG_RXOVERR) {card->ErrorCode|=HAL_SD_ERROR_RX_OVERRUN;}
          if(sta & SDMMC_FLAG_IDMATE) {card->ErrorCode|=HAL_SD_ERROR_DMA;}
          result=HAL_ERROR;break;
        }
      }
      uint32_t now=HAL_GetTick();
      if((uint32_t)(now-started)>=timeout_ms) {result=HAL_TIMEOUT;card->ErrorCode|=HAL_SD_ERROR_TIMEOUT;break;}
#if XE_NP_NP2_LIVE_SD_ENABLE && XE_NP_NP2_SD_BLE_ENABLE && XE_NP_NP2_DUAL_SD_APP_ENABLE
      /* Yield only the stopped verification transport, at most once/tick.
       * Keep the original read deadline and IRQ/error retirement unchanged. */
      if(card->State!=HAL_SD_STATE_READY && now!=ble_poll_tick) {
        ble_poll_tick=now;XE_NP_Np2LiveSd_VerifyBleService(card);
      }
#endif
    }
    if(result==HAL_OK && card->ErrorCode!=HAL_SD_ERROR_NONE) {result=HAL_ERROR;}
  }
  xe_np_sd_metadata_diag[1]=(uint32_t)result;
  xe_np_sd_metadata_diag[2]=card->ErrorCode;
  xe_np_sd_metadata_diag[3]=sta;
  xe_np_sd_metadata_diag[4]=card->Instance->DCTRL;
  xe_np_sd_metadata_diag[5]=card->Instance->IDMACTRL;
  if(result==HAL_OK) {
    /* SD startup also runs in the lean NP2 image without the legacy capture
     * module. Retire IDMA data through the cache peripheral directly. */
    uintptr_t begin=(uintptr_t)data & ~(uintptr_t)31U;
    uintptr_t end=((uintptr_t)data+blocks*512U+31U) & ~(uintptr_t)31U;
    if(HAL_DCACHE_InvalidateByAddr(&hdcache1,(const uint32_t *)begin,
                                  (uint32_t)(end-begin))!=HAL_OK) {
      card->ErrorCode|=HAL_SD_ERROR_GENERAL_UNKNOWN_ERR;
      result=HAL_ERROR;
    }
  }
  NVIC_ClearPendingIRQ(SDMMC1_IRQn);
  /* Do not re-enable a late completion/error IRQ while a failed IDMA transfer
   * still owns the destination. Recovery/reset must retire that ownership. */
  if(irq_enabled && card->State==HAL_SD_STATE_READY && card->Instance->IDMACTRL==0U &&
     !(card->Instance->STA & (SDMMC_STA_DPSMACT|SDMMC_STA_CPSMACT))) {NVIC_EnableIRQ(SDMMC1_IRQn);}
  return result;
}

#if XE_NP_V2_MEDIA_ENABLE
uint32_t XE_NP_Board_MediaSdBusHz(void) {return XE_NP_Board_ComputeSdBusHz();}
#endif
#endif

static HAL_StatusTypeDef XE_NP_Board_ProbeSdMetadataReadWithTimeout(uint32_t timeout_ms)
{
#if (XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U)
  return XE_NP_Board_SdReadBlocksDmaPolling(&hsd1,xe_np_sd_speed_probe_buf,SYS_ADDR,1U,timeout_ms);
#else
  if (timeout_ms == 0U)
  {
    timeout_ms = 1U;
  }

  uint32_t start_tick = HAL_GetTick();

  XE_NP_Board_EnsureSdPowerRail();

  while (HAL_SD_GetCardState(&hsd1) != HAL_SD_CARD_TRANSFER)
  {
    if ((HAL_GetTick() - start_tick) >= timeout_ms)
    {
      return HAL_ERROR;
    }
  }

  if (HAL_SD_ReadBlocks(&hsd1, xe_np_sd_speed_probe_buf, SYS_ADDR, 1U, timeout_ms) != HAL_OK)
  {
    return HAL_ERROR;
  }

  start_tick = HAL_GetTick();
  while (HAL_SD_GetCardState(&hsd1) != HAL_SD_CARD_TRANSFER)
  {
    if ((HAL_GetTick() - start_tick) >= timeout_ms)
    {
      return HAL_ERROR;
    }
  }

  return HAL_OK;
#endif
}

static HAL_StatusTypeDef XE_NP_Board_ProbeSdMetadataRead(void)
{
  return XE_NP_Board_ProbeSdMetadataReadWithTimeout(1000U);
}

volatile struct {
  uint32_t attempts, error, words, sta, response, clock, delay;
  uint32_t data[16];
} xe_np_sd_tuning_block_diag;

static HAL_StatusTypeDef XE_NP_Board_ProbeSdTuningBlock(uint32_t timeout_ms)
{
  SDMMC_DataInitTypeDef data = {0};
  SDMMC_CmdInitTypeDef cmd = {0};
  uint32_t received[16] = {0};
  uint32_t words = 0U, error = HAL_SD_ERROR_NONE;
  uint32_t started = HAL_GetTick(), sta = 0U;
  xe_np_sd_tuning_block_diag.attempts++;
  if(hsd1.State != HAL_SD_STATE_READY || hsd1.Init.BusWide != SDMMC_BUS_WIDE_4B) { return HAL_ERROR; }
  hsd1.State = HAL_SD_STATE_BUSY;hsd1.ErrorCode = HAL_SD_ERROR_NONE;
  hsd1.Instance->DCTRL = SDMMC_DCTRL_FIFORST;
  hsd1.Instance->DCTRL = 0U;hsd1.Instance->IDMACTRL = 0U;
  __HAL_SD_CLEAR_FLAG(&hsd1,SDMMC_STATIC_FLAGS);
  data.DataTimeOut = SDMMC_DATATIMEOUT;data.DataLength = 64U;
  data.DataBlockSize = SDMMC_DATABLOCK_SIZE_64B;
  data.TransferDir = SDMMC_TRANSFER_DIR_TO_SDMMC;
  /* Arm CMD19 data parameters without starting DPSM before the command
   * response. The previously qualified SDR104 image uses this sequencing;
   * pre-enabling DPSM timed out every phase of the 116 MHz tuning sweep. */
  data.TransferMode = SDMMC_TRANSFER_MODE_BLOCK;data.DPSM = SDMMC_DPSM_DISABLE;
  (void)SDMMC_ConfigData(hsd1.Instance,&data);
  __SDMMC_CMDTRANS_ENABLE(hsd1.Instance);
  cmd.Argument = 0U;cmd.CmdIndex = SDMMC_CMD_HS_BUSTEST_WRITE;
  cmd.Response = SDMMC_RESPONSE_SHORT;cmd.WaitForInterrupt = SDMMC_WAIT_NO;cmd.CPSM = SDMMC_CPSM_ENABLE;
  (void)SDMMC_SendCommand(hsd1.Instance,&cmd);
  error = SDMMC_GetCmdResp1(hsd1.Instance,SDMMC_CMD_HS_BUSTEST_WRITE,timeout_ms);
  if(error == HAL_SD_ERROR_NONE) {
    for(;;) {
      sta = hsd1.Instance->STA;
      if(sta & (SDMMC_FLAG_DCRCFAIL|SDMMC_FLAG_DTIMEOUT|SDMMC_FLAG_RXOVERR)) { break; }
      if(words<16U && !(sta & SDMMC_FLAG_RXFIFOE)) { received[words++] = hsd1.Instance->FIFO;continue; }
      if(sta & SDMMC_FLAG_DATAEND) { break; }
      if((uint32_t)(HAL_GetTick()-started)>=timeout_ms) { error=HAL_SD_ERROR_TIMEOUT;break; }
    }
    if(sta & SDMMC_FLAG_DCRCFAIL) { error=HAL_SD_ERROR_DATA_CRC_FAIL; }
    if(sta & SDMMC_FLAG_DTIMEOUT) { error=HAL_SD_ERROR_DATA_TIMEOUT; }
    if(sta & SDMMC_FLAG_RXOVERR) { error=HAL_SD_ERROR_RX_OVERRUN; }
    if(error==HAL_SD_ERROR_NONE && !XE_NP_SdTuningPatternMatches(received,words*4U)) { error=HAL_SD_ERROR_DATA_CRC_FAIL; }
  }
  __SDMMC_CMDTRANS_DISABLE(hsd1.Instance);
  xe_np_sd_tuning_block_diag.error=error;xe_np_sd_tuning_block_diag.words=words;
  xe_np_sd_tuning_block_diag.sta=sta;xe_np_sd_tuning_block_diag.response=hsd1.Instance->RESP1;
  xe_np_sd_tuning_block_diag.clock=hsd1.Instance->CLKCR;
  xe_np_sd_tuning_block_diag.delay=DLYB_SDMMC1->CFGR;
  for(uint32_t i=0U;i<16U;i++) { xe_np_sd_tuning_block_diag.data[i]=received[i]; }
  hsd1.Instance->DCTRL=SDMMC_DCTRL_FIFORST;hsd1.Instance->DCTRL=0U;
  __HAL_SD_CLEAR_FLAG(&hsd1,SDMMC_STATIC_FLAGS);
  hsd1.ErrorCode=error;hsd1.Context=SD_CONTEXT_NONE;hsd1.State=HAL_SD_STATE_READY;
  return error==HAL_SD_ERROR_NONE?HAL_OK:HAL_ERROR;
}

#if (XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U)
static HAL_StatusTypeDef XE_NP_Board_RecoverSdTuningTransfer(void)
{
  uint32_t started=HAL_GetTick();
  uint32_t saved_clock, kernel_hz, recovery_div;
  uint32_t card_ready=0U;
  /* A rejected receive phase can leave DPSM active despite HAL.State=READY.
   * Abort on the wire before changing the sampling phase; clearing flags
   * alone does not terminate the card's outstanding data transaction. */
  if(hsd1.Instance->STA & (SDMMC_STA_DPSMACT|SDMMC_STA_CPSMACT)) {
    SDMMC_CmdInitTypeDef stop_cmd = {0};
    xe_np_sd_tuning_recovery_count++;
    /* The generic LL helper uses SDMMC_STOPTRANSFERTIMEOUT=100000000 ms.
     * A rejected CMD19 phase can therefore block boot for minutes before
     * this function's 2-ms retirement deadline is ever reached. Keep the
     * same CMD12/STOP sequencing, but bound its response wait locally.
     * Never certify a still-active engine as recovered. Startup only. */
    stop_cmd.Argument = 0U;
    stop_cmd.CmdIndex = SDMMC_CMD_STOP_TRANSMISSION;
    stop_cmd.Response = SDMMC_RESPONSE_SHORT;
    stop_cmd.WaitForInterrupt = SDMMC_WAIT_NO;
    stop_cmd.CPSM = SDMMC_CPSM_ENABLE;
    __SDMMC_CMDSTOP_ENABLE(hsd1.Instance);
    __SDMMC_CMDTRANS_DISABLE(hsd1.Instance);
    (void)SDMMC_SendCommand(hsd1.Instance,&stop_cmd);
    (void)SDMMC_GetCmdResp1(hsd1.Instance,SDMMC_CMD_STOP_TRANSMISSION,2U);
    __SDMMC_CMDSTOP_DISABLE(hsd1.Instance);
    while((hsd1.Instance->STA & (SDMMC_STA_CPSMACT|SDMMC_STA_DPSMACT)) &&
          (uint32_t)(HAL_GetTick()-started)<2U) {
      /* Release receive FIFO backpressure while the abort retires. These
       * bytes belong to the rejected phase and are never accepted as data. */
      if(!hsd1.Instance->IDMACTRL && (hsd1.Instance->DCTRL & SDMMC_DCTRL_DTDIR) &&
         !(hsd1.Instance->STA & SDMMC_STA_RXFIFOE)) { (void)hsd1.Instance->FIFO; }
    }
  }
  __SDMMC_CMDTRANS_DISABLE(hsd1.Instance);
  if(!(hsd1.Instance->STA & (SDMMC_STA_DPSMACT|SDMMC_STA_CPSMACT))) {hsd1.Instance->IDMACTRL=0U;}
  hsd1.Instance->DCTRL=SDMMC_DCTRL_FIFORST;
  hsd1.Instance->DCTRL=0U;
  __HAL_SD_CLEAR_FLAG(&hsd1,SDMMC_STATIC_FLAGS);
  if(hsd1.Instance->STA & (SDMMC_STA_DPSMACT|SDMMC_STA_CPSMACT)) {
    xe_np_sd_tuning_recovery_failed++;
    return HAL_ERROR;
  }
  /* Direct feedback is not qualified at the target SDR104 clock. A status
   * timeout there must not prevent every candidate phase from being tried.
   * With both state machines retired, use <=25 MHz only for CMD13 recovery.
   * Restore the exact clock/mux before CMD19 and ordinary read qualification.
   * CMD12 can report ILLEGAL_CMD if a single-block transfer already ended. */
  kernel_hz=HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SDMMC);
  if(kernel_hz==0U) {xe_np_sd_tuning_recovery_failed++;return HAL_ERROR;}
  recovery_div=1U+(kernel_hz-1U)/50000000U;
  saved_clock=hsd1.Instance->CLKCR;
  MODIFY_REG(hsd1.Instance->CLKCR,SDMMC_CLKCR_CLKDIV|SDMMC_CLKCR_SELCLKRX,
             recovery_div|SDMMC_CLKCR_SELCLKRX_0);
  __DSB();
  for(uint32_t attempt=0U;attempt<3U;attempt++) {
    SDMMC_CmdInitTypeDef status_cmd = {0};
    uint32_t error;
    XE_NP_Board_ClearSdSpeedAttemptError();
    status_cmd.Argument = hsd1.SdCard.RelCardAdd << 16U;
    status_cmd.CmdIndex = SDMMC_CMD_SEND_STATUS;
    status_cmd.Response = SDMMC_RESPONSE_SHORT;
    status_cmd.WaitForInterrupt = SDMMC_WAIT_NO;
    status_cmd.CPSM = SDMMC_CPSM_ENABLE;
    /* HAL's CMD13 wait is 250 ms and its software timeout does not retire
     * CPSM. Use the same LL R1 CRC/index/error checks, bounded to 2 ms, and
     * prove BOTH engines idle before retrying or restoring CLKCR. No command
     * cancellation or peripheral reset is inferred from clearing flags. */
    (void)SDMMC_SendCommand(hsd1.Instance,&status_cmd);
    error=SDMMC_GetCmdResp1(hsd1.Instance,SDMMC_CMD_SEND_STATUS,2U);
    hsd1.ErrorCode |= error;
    started=HAL_GetTick();
    while((hsd1.Instance->STA & (SDMMC_STA_CPSMACT|SDMMC_STA_DPSMACT)) &&
          (uint32_t)(HAL_GetTick()-started)<2U) { }
    if(hsd1.Instance->STA & (SDMMC_STA_DPSMACT|SDMMC_STA_CPSMACT)) {
      hsd1.ErrorCode |= HAL_SD_ERROR_TIMEOUT;
      hsd1.State=HAL_SD_STATE_ERROR;
      xe_np_sd_tuning_recovery_failed++;
      /* Keep the recovery clock: never change a live command's clock/mux.
       * The sweep must fail, leaving reset/reinitialization to its caller. */
      return HAL_ERROR;
    }
    if(error==HAL_SD_ERROR_NONE && (hsd1.Instance->RESP1 & (1U<<8U)) &&
       ((hsd1.Instance->RESP1>>9U)&0x0FU)==HAL_SD_CARD_TRANSFER) {
      card_ready=1U;break;
    }
  }
  hsd1.Instance->CLKCR=saved_clock;
  __DSB();
  if(!card_ready) { xe_np_sd_tuning_recovery_failed++;return HAL_ERROR; }
  hsd1.Context=SD_CONTEXT_NONE;
  XE_NP_Board_ClearSdSpeedAttemptError();
  return HAL_OK;
}
#endif

static uint32_t XE_NP_Board_AddUniqueDlybUnitCandidate(uint32_t *candidates,
                                                       uint32_t candidate_count,
                                                       uint32_t unit)
{
  for (uint32_t idx = 0U; idx < candidate_count; ++idx)
  {
    if (candidates[idx] == unit)
    {
      return candidate_count;
    }
  }

  if (candidate_count < XE_NP_SD_DLYB_TUNE_MAX_UNIT_CANDIDATES)
  {
    candidates[candidate_count] = unit;
    return candidate_count + 1U;
  }

  return candidate_count;
}

static void XE_NP_Board_SelectDlybPassWindow(uint32_t pass_mask,
                                             uint32_t *best_start,
                                             uint32_t *best_len)
{
  uint32_t run_start = 0U;
  uint32_t run_len = 0U;

  *best_start = 0U;
  *best_len = 0U;

  for (uint32_t phase = 0U; phase <= DLYB_MAX_SELECT; ++phase)
  {
    if ((pass_mask & (1UL << phase)) != 0U)
    {
      if (run_len == 0U)
      {
        run_start = phase;
      }
      run_len++;
      if (run_len > *best_len)
      {
        *best_start = run_start;
        *best_len = run_len;
      }
    }
    else
    {
      run_len = 0U;
    }
  }
}

static HAL_StatusTypeDef XE_NP_Board_ConfirmSdDelayPhase(const LL_DLYB_CfgTypeDef *period_cfg,
                                                         uint32_t phase)
{
#if defined(DLYB_SDMMC1) && (XE_NP_SD_DLYB_TUNE_ENABLE != 0U)
  LL_DLYB_CfgTypeDef phase_cfg = {0};

#if (XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U)
  if(XE_NP_Board_RecoverSdTuningTransfer()!=HAL_OK) { return HAL_ERROR; }
#endif
  phase_cfg.Units = period_cfg->Units;
  phase_cfg.PhaseSel = phase;
  LL_DLYB_SetDelay(DLYB_SDMMC1, &phase_cfg);
  LL_DLYB_Enable(DLYB_SDMMC1);

  for (uint32_t attempt = 0U; attempt < XE_NP_SD_DLYB_TUNE_CONFIRM_ATTEMPTS; ++attempt)
  {
    __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_STATIC_FLAGS);
    XE_NP_Board_ClearSdSpeedAttemptError();
    if (XE_NP_Board_ProbeSdTuningBlock(XE_NP_SD_DLYB_TUNE_PHASE_TIMEOUT_MS) != HAL_OK)
    {
#if (XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U)
      if(XE_NP_Board_RecoverSdTuningTransfer()!=HAL_OK) { return HAL_ERROR; }
#endif
      __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_STATIC_FLAGS);
      XE_NP_Board_ClearSdSpeedAttemptError();
      return HAL_ERROR;
    }
#if (XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U)
    /* A valid CMD19 pattern alone does not prove command-response and
     * ordinary block-read timing. Require both at each qualification phase. */
    xe_np_sd_phase_detail[period_cfg->Units][0]|=1UL<<phase;
    if (XE_NP_Board_ProbeSdMetadataReadWithTimeout(10U) != HAL_OK)
    {
      xe_np_sd_phase_detail[period_cfg->Units][2]=hsd1.ErrorCode;
      if(XE_NP_Board_RecoverSdTuningTransfer()!=HAL_OK) { return HAL_ERROR; }
      __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_STATIC_FLAGS);
      XE_NP_Board_ClearSdSpeedAttemptError();
      return HAL_ERROR;
    }
    xe_np_sd_phase_detail[period_cfg->Units][1]|=1UL<<phase;
#endif
  }

  return HAL_OK;
#else
  (void)period_cfg;
  (void)phase;
  return HAL_OK;
#endif
}

static HAL_StatusTypeDef XE_NP_Board_TuneSdDelayBlock(uint32_t speed_mode, uint8_t require_1v8)
{
#if defined(DLYB_SDMMC1) && (XE_NP_SD_DLYB_TUNE_ENABLE != 0U)
  LL_DLYB_CfgTypeDef period_cfg = {0};
  LL_DLYB_CfgTypeDef phase_cfg = {0};
  uint32_t unit_candidates[XE_NP_SD_DLYB_TUNE_MAX_UNIT_CANDIDATES];
  const uint32_t manual_units[XE_NP_SD_DLYB_TUNE_MANUAL_UNIT_COUNT] = {0U, 1U, 2U, 3U, 4U, 5U, 6U, 7U};
  uint32_t best_pass_mask = 0U;
  uint32_t best_start = 0U;
  uint32_t best_len = 0U;
  uint32_t best_unit = 0U;
  uint32_t unit_candidate_count = 0U;
  uint32_t selected_phase;
  uint32_t tune_success_status = 2U;
  uint32_t manual_fallback_used = 0U;
  uint32_t phase_limit=DLYB_MAX_SELECT;

  xe_np_sd_bench_diag.dlyb_tune_status = 0U;
  xe_np_sd_bench_diag.dlyb_tune_units = 0U;
  xe_np_sd_bench_diag.dlyb_tune_period_phase = 0U;
  xe_np_sd_bench_diag.dlyb_tune_pass_mask = 0U;
  xe_np_sd_bench_diag.dlyb_tune_selected_phase = 0U;

  if ((require_1v8 == 0U) ||
      ((speed_mode != SDMMC_SPEED_MODE_ULTRA_SDR104) &&
       (speed_mode != SDMMC_SPEED_MODE_ULTRA_SDR50)))
  {
    return HAL_OK;
  }

  xe_np_sd_bench_diag.dlyb_tune_status = 1U;
  if((hsd1.Instance->CLKCR & SDMMC_CLKCR_SELCLKRX) != SDMMC_CLKCR_SELCLKRX_1) {
    /* Direct CKIN has no programmable phase. Verify its pattern without
     * claiming that an unrelated DLYB sweep calibrated it. */
    for(uint32_t attempt=0U;attempt<XE_NP_SD_DLYB_TUNE_CONFIRM_ATTEMPTS;attempt++) {
#if XE_NP_SD_DIRECT_READ_QUALIFICATION
      /* Isolated SDR50 A/B test: ordinary CRC-protected reads followed by
       * complete scratch-pattern verification, not CMD19 phase tuning. */
      if(speed_mode!=SDMMC_SPEED_MODE_ULTRA_SDR50 ||
         XE_NP_Board_ProbeSdMetadataReadWithTimeout(XE_NP_SD_DLYB_TUNE_PHASE_TIMEOUT_MS)!=HAL_OK)
        return HAL_ERROR;
#else
      if(XE_NP_Board_ProbeSdTuningBlock(XE_NP_SD_DLYB_TUNE_PHASE_TIMEOUT_MS)!=HAL_OK) { return HAL_ERROR; }
#endif
    }
    xe_np_sd_bench_diag.dlyb_tune_status=9U;return HAL_OK;
  }
  LL_DLYB_Enable(DLYB_SDMMC1);
  if (LL_DLYB_GetClockPeriod(DLYB_SDMMC1, &period_cfg) != (uint32_t)SUCCESS)
  {
    xe_np_sd_bench_diag.dlyb_tune_status = 5U;
#if (XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U) && (XE_NP_BOARD_SD_DLYB_EXHAUSTIVE == 0U)
    return HAL_ERROR;
#else
    period_cfg.Units = manual_units[0];
    period_cfg.PhaseSel = DLYB_MAX_SELECT;
    tune_success_status = 7U;
    manual_fallback_used = 1U;
#endif
  }

  xe_np_sd_bench_diag.dlyb_tune_units = period_cfg.Units;
  xe_np_sd_bench_diag.dlyb_tune_period_phase = period_cfg.PhaseSel;

#if (XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U)
  #if (XE_NP_BOARD_SD_DLYB_EXHAUSTIVE == 0U)
  /* Use the measured one-clock-period cell length. Counting passing taps
   * across arbitrary UNIT values wrongly favors almost-zero-delay units. */
  unit_candidate_count=XE_NP_Board_AddUniqueDlybUnitCandidate(unit_candidates,0U,period_cfg.Units);
  phase_limit=period_cfg.PhaseSel;
  manual_fallback_used=1U;
  #else
  /* Qualification scans all legal UNIT settings, not just the calibrated
   * neighborhood and the legacy 0..7 fallback. Do not enable in production. */
  manual_fallback_used=1U;
  tune_success_status=7U;
  for(uint32_t unit=0U;unit<DLYB_MAX_UNIT;unit++) {
    unit_candidate_count=XE_NP_Board_AddUniqueDlybUnitCandidate(unit_candidates,unit_candidate_count,unit);
  }
  #endif
#else
  if (manual_fallback_used == 0U)
  {
    unit_candidate_count = XE_NP_Board_AddUniqueDlybUnitCandidate(unit_candidates, unit_candidate_count, period_cfg.Units);
    if (period_cfg.Units > 0U)
    {
      unit_candidate_count = XE_NP_Board_AddUniqueDlybUnitCandidate(unit_candidates,
                                                                    unit_candidate_count,
                                                                    period_cfg.Units - 1U);
    }
    if (period_cfg.Units > 1U)
    {
      unit_candidate_count = XE_NP_Board_AddUniqueDlybUnitCandidate(unit_candidates,
                                                                    unit_candidate_count,
                                                                    period_cfg.Units - 2U);
    }
    if (period_cfg.Units > 2U)
    {
      unit_candidate_count = XE_NP_Board_AddUniqueDlybUnitCandidate(unit_candidates,
                                                                    unit_candidate_count,
                                                                    period_cfg.Units - 3U);
    }
    if (period_cfg.Units < (DLYB_MAX_UNIT - 1U))
    {
      unit_candidate_count = XE_NP_Board_AddUniqueDlybUnitCandidate(unit_candidates,
                                                                    unit_candidate_count,
                                                                    period_cfg.Units + 1U);
    }
    if (period_cfg.Units < (DLYB_MAX_UNIT - 2U))
    {
      unit_candidate_count = XE_NP_Board_AddUniqueDlybUnitCandidate(unit_candidates,
                                                                    unit_candidate_count,
                                                                    period_cfg.Units + 2U);
    }
    if (period_cfg.Units < (DLYB_MAX_UNIT - 3U))
    {
      unit_candidate_count = XE_NP_Board_AddUniqueDlybUnitCandidate(unit_candidates,
                                                                    unit_candidate_count,
                                                                    period_cfg.Units + 3U);
    }
  }
  else
  {
    for (uint32_t unit_idx = 0U; unit_idx < XE_NP_SD_DLYB_TUNE_MANUAL_UNIT_COUNT; ++unit_idx)
    {
      unit_candidate_count = XE_NP_Board_AddUniqueDlybUnitCandidate(unit_candidates,
                                                                    unit_candidate_count,
                                                                    manual_units[unit_idx]);
    }
  }

#endif
  for (uint32_t unit_idx = 0U; unit_idx < unit_candidate_count; ++unit_idx)
  {
    uint32_t local_pass_mask = 0U;
    uint32_t local_best_start = 0U;
    uint32_t local_best_len = 0U;
    uint32_t test_units = unit_candidates[unit_idx];

    period_cfg.Units = test_units;
    xe_np_sd_bench_diag.dlyb_tune_units = test_units;
    for (uint32_t phase = 0U; phase <= phase_limit; ++phase)
    {
      phase_cfg.Units = period_cfg.Units;
      phase_cfg.PhaseSel = phase;
#if (XE_NP_BOARD_SD_RX_CLOCK_TEST != 2U)
      LL_DLYB_SetDelay(DLYB_SDMMC1, &phase_cfg);
      LL_DLYB_Enable(DLYB_SDMMC1);
#endif
      __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_STATIC_FLAGS);
      XE_NP_Board_ClearSdSpeedAttemptError();

      if (XE_NP_Board_ConfirmSdDelayPhase(&period_cfg, phase) == HAL_OK)
      {
        local_pass_mask |= (1UL << phase);
      }
#if (XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U)
      if(hsd1.Instance->STA & (SDMMC_STA_DPSMACT|SDMMC_STA_CPSMACT)) {
        xe_np_sd_bench_diag.dlyb_tune_status=10U;return HAL_ERROR;
      }
#endif

      __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_STATIC_FLAGS);
      XE_NP_Board_ClearSdSpeedAttemptError();
    }

    if (local_pass_mask != 0U)
    {
      XE_NP_Board_SelectDlybPassWindow(local_pass_mask, &local_best_start, &local_best_len);
      if ((local_best_len > best_len) ||
          ((local_best_len == best_len) && (best_pass_mask == 0U)))
      {
        best_pass_mask = local_pass_mask;
        best_start = local_best_start;
        best_len = local_best_len;
        best_unit = test_units;
      }
    }
#if (XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U) && (XE_NP_BOARD_SD_DLYB_EXHAUSTIVE != 0U)
    /* First-longest wins. A fully confirmed window is the maximum possible;
     * further units cannot improve it and can strand a rejected read phase.
     * Keep the common winning-phase reconfirmation and final CRC read below. */
    if (best_len == (phase_limit + 1U)) { break; }
#endif
  }

  if ((best_pass_mask == 0U) && (manual_fallback_used == 0U))
  {
    manual_fallback_used = 1U;
    if (tune_success_status == 2U)
    {
      tune_success_status = 7U;
    }
    unit_candidate_count = 0U;
    for (uint32_t unit_idx = 0U; unit_idx < XE_NP_SD_DLYB_TUNE_MANUAL_UNIT_COUNT; ++unit_idx)
    {
      unit_candidate_count = XE_NP_Board_AddUniqueDlybUnitCandidate(unit_candidates,
                                                                    unit_candidate_count,
                                                                    manual_units[unit_idx]);
    }

    for (uint32_t unit_idx = 0U; unit_idx < unit_candidate_count; ++unit_idx)
    {
      uint32_t local_pass_mask = 0U;
      uint32_t local_best_start = 0U;
      uint32_t local_best_len = 0U;
      uint32_t test_units = unit_candidates[unit_idx];

      period_cfg.Units = test_units;
      xe_np_sd_bench_diag.dlyb_tune_units = test_units;
      for (uint32_t phase = 0U; phase <= DLYB_MAX_SELECT; ++phase)
      {
        phase_cfg.Units = period_cfg.Units;
        phase_cfg.PhaseSel = phase;
#if (XE_NP_BOARD_SD_RX_CLOCK_TEST != 2U)
        LL_DLYB_SetDelay(DLYB_SDMMC1, &phase_cfg);
        LL_DLYB_Enable(DLYB_SDMMC1);
#endif
        __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_STATIC_FLAGS);
        XE_NP_Board_ClearSdSpeedAttemptError();

        if (XE_NP_Board_ConfirmSdDelayPhase(&period_cfg, phase) == HAL_OK)
        {
          local_pass_mask |= (1UL << phase);
        }
#if (XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U)
        if(hsd1.Instance->STA & (SDMMC_STA_DPSMACT|SDMMC_STA_CPSMACT)) {
          xe_np_sd_bench_diag.dlyb_tune_status=10U;return HAL_ERROR;
        }
#endif

        __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_STATIC_FLAGS);
        XE_NP_Board_ClearSdSpeedAttemptError();
      }

      if (local_pass_mask != 0U)
      {
        XE_NP_Board_SelectDlybPassWindow(local_pass_mask, &local_best_start, &local_best_len);
        if ((local_best_len > best_len) ||
            ((local_best_len == best_len) && (best_pass_mask == 0U)))
        {
          best_pass_mask = local_pass_mask;
          best_start = local_best_start;
          best_len = local_best_len;
          best_unit = test_units;
        }
      }
    }
  }

  xe_np_sd_bench_diag.dlyb_tune_pass_mask = best_pass_mask;
  if ((best_pass_mask == 0U) || ((XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U) && (best_len < 3U)))
  {
    xe_np_sd_bench_diag.dlyb_tune_status = manual_fallback_used ? 8U : 3U;
    return HAL_ERROR;
  }

  /* The sweep leaves period_cfg.Units at the last tested candidate, which
   * is not necessarily best_unit. Confirm the winning unit/phase pair,
   * otherwise a good 156 MHz window can be rejected or misreported. */
  period_cfg.Units = best_unit;
  selected_phase = best_start + (best_len / 2U);
  for (uint32_t offset = 0U; offset < best_len; ++offset)
  {
    uint32_t phase_candidates[2];
    uint32_t phase_count = 0U;

    if ((selected_phase >= offset) && ((best_pass_mask & (1UL << (selected_phase - offset))) != 0U))
    {
      phase_candidates[phase_count++] = selected_phase - offset;
    }
    if ((offset != 0U) &&
        ((selected_phase + offset) <= DLYB_MAX_SELECT) &&
        ((best_pass_mask & (1UL << (selected_phase + offset))) != 0U))
    {
      phase_candidates[phase_count++] = selected_phase + offset;
    }

    for (uint32_t phase_idx = 0U; phase_idx < phase_count; ++phase_idx)
    {
      if (XE_NP_Board_ConfirmSdDelayPhase(&period_cfg, phase_candidates[phase_idx]) == HAL_OK)
      {
        xe_np_sd_bench_diag.dlyb_tune_units = best_unit;
        xe_np_sd_bench_diag.dlyb_tune_selected_phase = phase_candidates[phase_idx];
        xe_np_sd_bench_diag.dlyb_tune_status = tune_success_status;
        return HAL_OK;
      }
#if (XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U)
      if(hsd1.Instance->STA & (SDMMC_STA_DPSMACT|SDMMC_STA_CPSMACT)) {
        xe_np_sd_bench_diag.dlyb_tune_status=10U;return HAL_ERROR;
      }
#endif
    }
  }

  period_cfg.Units = best_unit;
  phase_cfg.Units = period_cfg.Units;
  phase_cfg.PhaseSel = selected_phase;
  LL_DLYB_SetDelay(DLYB_SDMMC1, &phase_cfg);
  LL_DLYB_Enable(DLYB_SDMMC1);
  xe_np_sd_bench_diag.dlyb_tune_units = best_unit;
  xe_np_sd_bench_diag.dlyb_tune_selected_phase = selected_phase;
  xe_np_sd_bench_diag.dlyb_tune_status = 6U;
  return HAL_ERROR;
#else
  (void)speed_mode;
  (void)require_1v8;
  xe_np_sd_bench_diag.dlyb_tune_status = 4U;
  return HAL_OK;
#endif
}

static uint32_t XE_NP_Board_ComputeClockDivForTargetHz(uint32_t sdmmc_kernel_hz, uint32_t target_hz)
{
  uint32_t clock_div;

  if ((sdmmc_kernel_hz == 0U) || (target_hz == 0U))
  {
    return 0U;
  }

  if (sdmmc_kernel_hz <= target_hz)
  {
    return 0U;
  }

  /*
   * HAL SD code treats ClockDiv == 0 as "no divide". For divided modes, the
   * effective clock is SDMMCCLK / (2 * ClockDiv), so we must round up to keep
   * fallback non-UHS modes at or below their max bus rate.
   */
  clock_div = (sdmmc_kernel_hz + (2U * target_hz) - 1U) / (2U * target_hz);
  return (clock_div == 0U) ? 1U : clock_div;
}

#if (XE_NP_IMAGE_ROLE == XE_NP_IMAGE_USB_SERVICE)
/* USB diagnostics can encounter a still-powered UHS card after an MCU reset.
 * This override is used only by the read-only diagnostic, never the SD app. */
static uint8_t xe_np_sd_info_preserve_1v8;
#endif

#if XE_NP_BOARD_HSE_ONLY_CLOCKS
#include "xe_np_sd_io_compensation.inc"
#endif

#if XE_NP_SD_BASIC_RECOVER_1V8
static uint8_t xe_np_sd_basic_preserve_1v8;
#endif
#if XE_NP_SD_CMD11_PIN_COMPAT_ENABLE || XE_NP_SD_COLD_RETRY_TEST
static int XE_NP_Cmd11PinSourcesIdle(void);
static int XE_NP_Cmd11SdHostInactive(void)
{
  return !SDMMC1->IDMACTRL && !(SDMMC1->DCTRL&SDMMC_DCTRL_DTEN) &&
      !(SDMMC1->STA&(SDMMC_STA_CPSMACT|SDMMC_STA_DPSMACT|SDMMC_FLAG_BUSYD0)) &&
      !(SDMMC1->POWER&(SDMMC_POWER_VSWITCHEN|SDMMC_POWER_VSWITCH));
}
#endif

#if XE_NP_SD_CMD11_PIN_COMPAT_ENABLE
volatile struct {
  uint32_t magic,version,state,error,card_blocks,bus_hz,clkcr,power;
  uint32_t signal_1v8,current_ma,card_status_valid,transfer_state,reserved[4];
} xe_np_sd_identify_diag;
_Static_assert(sizeof(xe_np_sd_identify_diag)==64U,"shared SD pre-speed identification ABI");
static HAL_StatusTypeDef XE_NP_Board_FreezeSdIdentification(HAL_StatusTypeDef initialized)
{
  HAL_SD_CardStatusTypeDef status={0};
  uint32_t valid=0U,transfer=0U;
  uint32_t bus=XE_NP_Board_ComputeSdBusHz();
  uint32_t switched=((xe_np_sd_init_diag.acmd41_argument&0x01000000U) &&
                     (xe_np_sd_init_diag.ocr&0x01000000U)) ? 1U : 0U;
  xe_np_sd_identify_diag.magic=0x53444944U;xe_np_sd_identify_diag.version=1U;
  xe_np_sd_identify_diag.state=1U;xe_np_sd_identify_diag.current_ma=XE_NP_SD_CARD_MAX_CURRENT_MA;
  for(uint32_t i=0U;i<4U;i++)xe_np_sd_identify_diag.reserved[i]=0U;
  if(initialized==HAL_OK && hsd1.Instance==SDMMC1 && !xe_np_sd_init_failed && !hsd1.ErrorCode &&
     hsd1.State==HAL_SD_STATE_READY && hsd1.SdCard.LogBlockNbr && hsd1.SdCard.LogBlockSize==512U &&
     (hsd1.CID[0]|hsd1.CID[1]|hsd1.CID[2]|hsd1.CID[3]) &&
     (hsd1.CSD[0]|hsd1.CSD[1]|hsd1.CSD[2]|hsd1.CSD[3]) && bus && bus<=25000000U &&
     xe_np_sd_signal_1v8_enabled==switched && SDMMC1->POWER==0x13U &&
     !SDMMC1->IDMACTRL && !(SDMMC1->DCTRL&SDMMC_DCTRL_DTEN) &&
     !(SDMMC1->STA&(SDMMC_STA_CPSMACT|SDMMC_STA_DPSMACT)) && XE_NP_Cmd11PinSourcesIdle()) {
    valid=HAL_SD_GetCardStatus(&hsd1,&status)==HAL_OK;
    if(valid)transfer=(uint32_t)HAL_SD_GetCardState(&hsd1);
  }
  xe_np_sd_identify_diag.error=hsd1.ErrorCode;
  xe_np_sd_identify_diag.card_blocks=hsd1.SdCard.LogBlockNbr;
  xe_np_sd_identify_diag.bus_hz=bus;xe_np_sd_identify_diag.clkcr=SDMMC1->CLKCR;
  xe_np_sd_identify_diag.power=SDMMC1->POWER;xe_np_sd_identify_diag.signal_1v8=xe_np_sd_signal_1v8_enabled;
  xe_np_sd_identify_diag.card_status_valid=valid;xe_np_sd_identify_diag.transfer_state=transfer;
  if(!valid || transfer!=HAL_SD_CARD_TRANSFER || hsd1.ErrorCode || hsd1.State!=HAL_SD_STATE_READY ||
     SDMMC1->RESPCMD!=13U || !(SDMMC1->RESP1&(1U<<8U)) || !XE_NP_Cmd11PinSourcesIdle() ||
     SDMMC1->IDMACTRL || (SDMMC1->DCTRL&SDMMC_DCTRL_DTEN) ||
     (SDMMC1->STA&(SDMMC_STA_CPSMACT|SDMMC_STA_DPSMACT))) {
    if(!xe_np_sd_identify_diag.error)xe_np_sd_identify_diag.error=HAL_SD_ERROR_UNSUPPORTED_FEATURE;
    __DMB();xe_np_sd_identify_diag.state=255U;XE_NP_Board_SetSdInitFailed(1U);return HAL_ERROR;
  }
  __DMB();xe_np_sd_identify_diag.state=2U;return HAL_OK;
}
#endif
static HAL_StatusTypeDef XE_NP_Board_InitSdHostBase(void)
{
#if XE_NP_SD_CMD11_PIN_COMPAT_ENABLE
  /* Shared compatibility may run only before acquisition. Never stop a live
   * source or reset CYCCNT to earn voltage-switch admission. */
  CoreDebug->DEMCR|=CoreDebug_DEMCR_TRCENA_Msk;
  DWT->CTRL|=DWT_CTRL_CYCCNTENA_Msk;__DSB();
  if(!XE_NP_Cmd11PinSourcesIdle() || !XE_NP_Cmd11SdHostInactive()) {
    hsd1.ErrorCode=HAL_SD_ERROR_BUSY;XE_NP_Board_SetSdInitFailed(1U);return HAL_ERROR;
  }
#endif
  XE_NP_Board_EnsureSdPowerRail();

  hsd1.Instance = SDMMC1;
  /* Select the kernel BEFORE deriving the <=25 MHz post-identification
   * divider. HAL_SD_Init calls MSP too, but doing this afterwards used the
   * reset CLK48 frequency, then changed to a much faster PLL unexpectedly. */
  HAL_SD_MspInit(&hsd1);
  /* SD-only images do not run the USB MSP (which otherwise enables SYSCFG).
   * Use calibrated VDD I/O drive, as required by the SD timing conditions. */
  __HAL_RCC_SYSCFG_CLK_ENABLE();
#if XE_NP_BOARD_HSE_ONLY_CLOCKS
  if(XE_NP_Board_CalibrateSdIo()!=HAL_OK) {
    hsd1.ErrorCode=HAL_SD_ERROR_TIMEOUT;XE_NP_Board_SetSdInitFailed(1U);return HAL_ERROR;
  }
#else
  CLEAR_BIT(SYSCFG->CCCSR,SYSCFG_CCCSR_CS1);
  HAL_SYSCFG_EnableVddCompensationCell();
  {
    uint32_t started=HAL_GetTick();
    while((SYSCFG->CCCSR & SYSCFG_CCCSR_RDY1)==0U) {
      if((uint32_t)(HAL_GetTick()-started)>=10U) {
        hsd1.ErrorCode=HAL_SD_ERROR_TIMEOUT;XE_NP_Board_SetSdInitFailed(1U);return HAL_ERROR;
      }
    }
  }
#endif
  /* Qualification-only bootstrap timing; the requested UHS edge is applied
   * independently by TrySdSpeedMode after initialization. Defaults unchanged. */
#if defined(XE_NP_SD_INIT_FALLING_EDGE) && (XE_NP_SD_INIT_FALLING_EDGE != 0U)
  hsd1.Init.ClockEdge = SDMMC_CLOCK_EDGE_FALLING;
#else
  hsd1.Init.ClockEdge = SDMMC_CLOCK_EDGE_RISING;
#endif
  hsd1.Init.ClockPowerSave = SDMMC_CLOCK_POWER_SAVE_DISABLE;
  hsd1.Init.BusWide = SDMMC_BUS_WIDE_4B;
  hsd1.Init.HardwareFlowControl = XE_NP_BOARD_SD_DISABLE_HWFC ?
      SDMMC_HARDWARE_FLOW_CONTROL_DISABLE : SDMMC_HARDWARE_FLOW_CONTROL_ENABLE;
  hsd1.Init.ClockDiv = 0U;
  hsd1.Init.TranceiverPresent = SDMMC_TRANSCEIVER_PRESENT;
#if XE_NP_SD_BASIC_RECOVER_1V8
  if(xe_np_sd_basic_preserve_1v8)
    hsd1.Init.TranceiverPresent=SDMMC_TRANSCEIVER_NOT_PRESENT;
#endif
#if XE_NP_SD_IDENTIFY_ONLY_DIAG || \
    (defined(XE_NP_SD_BASIC_DIAG_ENABLE) && XE_NP_SD_BASIC_DIAG_ENABLE && !XE_NP_SD_BASIC_1V8)
  /* Identification and basic block-I/O diagnostic stays at 3.3 V. */
  hsd1.Init.TranceiverPresent = SDMMC_TRANSCEIVER_NOT_PRESENT;
#if XE_NP_SD_CMD11_TRACE_ONLY_DIAG
  /* Separate native-voltage evidence mode: only HAL's unchanged CMD11 busy
   * admission may invoke the selector callback. Never force a voltage switch. */
  hsd1.Init.TranceiverPresent = SDMMC_TRANSCEIVER_PRESENT;
#endif
#endif
  XE_NP_Board_PrepareSdClockDivForSpeedMode(SDMMC_SPEED_MODE_DEFAULT, 0xFFFFFFFFU);

  /*
   * A failed UHS attempt can leave the external VCCIO_SD selector at 1.8 V.
   * Force the board back to 3.3 V logic before the HAL re-enters card init.
   */
#if XE_NP_SD_BASIC_RECOVER_1V8
  if(xe_np_sd_basic_preserve_1v8) {
    XE_NP_Board_SetSdHighSpeedLowVoltage(SET);
    xe_np_sd_signal_1v8_enabled=1U;
  } else
#endif
#if (XE_NP_IMAGE_ROLE == XE_NP_IMAGE_USB_SERVICE)
  if(xe_np_sd_info_preserve_1v8) {
    XE_NP_Board_SetSdHighSpeedLowVoltage(SET);
    xe_np_sd_signal_1v8_enabled=1U;
  } else
#endif
  {
    XE_NP_Board_SetSdHighSpeedLowVoltage(RESET);
    HAL_GPIO_WritePin(SD_VSEL_GPIO_Port, SD_VSEL_Pin, GPIO_PIN_RESET);
    xe_np_sd_signal_1v8_enabled = 0U;
  }
  xe_np_sd_signal_1v8_seen = 0U;
  xe_np_sd_negotiated_speed_mode = SDMMC_SPEED_MODE_DEFAULT;
  xe_np_sd_card_speed = CARD_NORMAL_SPEED;
  xe_np_sd_card_speed_raw = CARD_NORMAL_SPEED;
  xe_np_sd_card_type = 0U;
  XE_NP_Board_SetSdInitFailed(0U);

  if (HAL_SD_Init(&hsd1) != HAL_OK)
  {
    XE_NP_Board_SetSdInitFailed(1U);
    return HAL_ERROR;
  }

  xe_np_sd_card_type = hsd1.SdCard.CardType;
  xe_np_sd_card_speed_raw = hsd1.SdCard.CardSpeed;
  xe_np_sd_card_speed =
      XE_NP_Board_NormalizeSdCardSpeed(xe_np_sd_card_speed_raw, xe_np_sd_card_type);

  return HAL_OK;
}

static HAL_StatusTypeDef XE_NP_Board_ResetSdHostBase(void)
{
  HAL_StatusTypeDef init_status;

#if XE_NP_SD_CMD11_PIN_COMPAT_ENABLE
  if(!XE_NP_Cmd11PinSourcesIdle() || !XE_NP_Cmd11SdHostInactive())return HAL_ERROR;
#endif
  XE_NP_Board_EnsureSdPowerRail();

  /*
   * A failed UHS speed-mode attempt can leave the live host/card session in a
   * partially switched state. Re-enter lower-priority fallbacks from a fresh
   * HAL_SD_Init() baseline instead of reusing that session.
   */
  xe_np_sd_last_speed_mode_status = 6U;
  (void)HAL_SD_DeInit(&hsd1);
  xe_np_sd_last_speed_mode_status = 7U;
#if defined(DLYB_SDMMC1)
  LL_DLYB_Disable(DLYB_SDMMC1);
#endif
  __HAL_RCC_SDMMC1_FORCE_RESET();
  __HAL_RCC_SDMMC1_RELEASE_RESET();
  XE_NP_Board_ResetSdPowerRail();
  xe_np_sd_last_speed_mode_status = 8U;
  (void)XE_NP_Board_ConfigureSdmmcClockSources(XE_NP_SDMMC_SDMMC_CLOCK_SOURCE_DEFAULT,
                                               XE_NP_SDMMC_ICLK_CLOCK_SOURCE_DEFAULT);
  xe_np_sd_last_speed_mode_status = 9U;
  hsd1.ErrorCode = HAL_SD_ERROR_NONE;
  hsd1.State = HAL_SD_STATE_RESET;
  init_status = XE_NP_Board_InitSdHostBase();
  xe_np_sd_last_speed_mode_status = (init_status == HAL_OK) ? 11U : 10U;
  return init_status;
}

/* A successful reset is recovery, not the result of the speed-mode attempt.
 * Keep that attempt's failure stage visible until another mode is tried. */
static HAL_StatusTypeDef XE_NP_Board_ResetSdHostBasePreserveSpeedResult(void)
{
  uint32_t speed_status = xe_np_sd_last_speed_mode_status;
  uint32_t speed_error = xe_np_sd_last_speed_mode_error;
  HAL_StatusTypeDef status = XE_NP_Board_ResetSdHostBase();

  if ((status == HAL_OK) && (speed_status != 0U))
  {
    xe_np_sd_last_speed_mode_status = speed_status;
    xe_np_sd_last_speed_mode_error = speed_error;
  }
  return status;
}

static void XE_NP_Board_PrepareSdClockDivForSpeedMode(uint32_t speed_mode,
                                                    uint32_t requested_clock_div)
{
  uint32_t sdmmc_kernel_hz;
  uint32_t selected_div = requested_clock_div;

  sdmmc_kernel_hz = HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SDMMC);
  if (selected_div == 0xFFFFFFFFU)
  {
    selected_div = 0U;
  }

  switch (speed_mode)
  {
    case SDMMC_SPEED_MODE_ULTRA_SDR104:
      hsd1.Init.ClockDiv = selected_div;
      break;

    case SDMMC_SPEED_MODE_ULTRA_SDR50:
      hsd1.Init.ClockDiv = (requested_clock_div != 0xFFFFFFFFU) ?
                           selected_div :
                           XE_NP_Board_ComputeClockDivForTargetHz(sdmmc_kernel_hz, XE_NP_BOARD_SD_SDR50_TARGET_HZ);
      break;

    case SDMMC_SPEED_MODE_HIGH:
#if XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ != 0UL
      hsd1.Init.ClockDiv = (requested_clock_div != 0xFFFFFFFFU) ?
                           selected_div :
                           XE_NP_Board_ComputeClockDivForTargetHz(
                               sdmmc_kernel_hz,XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ);
#else
      hsd1.Init.ClockDiv = (requested_clock_div != 0xFFFFFFFFU) ?
                           selected_div :
                           XE_NP_Board_ComputeClockDivForTargetHz(sdmmc_kernel_hz, 50000000UL);
#endif
      break;

    case SDMMC_SPEED_MODE_DDR:
      hsd1.Init.ClockDiv = (requested_clock_div != 0xFFFFFFFFU) ?
                           selected_div :
                           XE_NP_Board_ComputeClockDivForTargetHz(sdmmc_kernel_hz, 50000000UL);
      break;

    case SDMMC_SPEED_MODE_DEFAULT:
    default:
      hsd1.Init.ClockDiv = (requested_clock_div != 0xFFFFFFFFU) ?
                           selected_div :
                           XE_NP_Board_ComputeClockDivForTargetHz(sdmmc_kernel_hz, 25000000UL);
      break;
  }
}

static HAL_StatusTypeDef XE_NP_Board_TrySdSpeedMode(uint32_t speed_mode,
                                                   uint8_t require_1v8,
                                                   uint32_t clock_div,
                                                   uint32_t clock_edge,
                                                   uint32_t selclkrx,
                                                   uint32_t sdmmc_clock_source,
                                                   uint32_t iclk_clock_source,
                                                   uint32_t min_negotiated_bus_hz)
{
  uint32_t effective_selclkrx;
  uint32_t effective_clock_edge;
  uint32_t target_bus_hz;
  uint32_t sdmmc_kernel_hz = 0U;
  uint32_t candidate_bus_hz = 0U;

  XE_NP_Board_EnsureSdPowerRail();

  xe_np_sd_last_speed_mode_attempt = speed_mode;
  xe_np_sd_last_speed_mode_error = HAL_SD_ERROR_NONE;
  xe_np_sd_last_speed_mode_card_state = HAL_SD_CARD_READY;
  xe_np_sd_last_speed_mode_status = 0U;
  /* UHS capability in SSR/CMD6 does not establish the live signaling level.
   * Require a completed voltage switch (or an explicitly recovered 1.8 V
   * session) before HAL's speed switch can drive the translator to 1.8 V. */
  if(require_1v8 && !xe_np_sd_signal_1v8_enabled) {
    xe_np_sd_last_speed_mode_status=3U;
    xe_np_sd_last_speed_mode_error=HAL_SD_ERROR_REQUEST_NOT_APPLICABLE;
    xe_np_sd_last_speed_mode_card_state=HAL_SD_GetCardState(&hsd1);
    return HAL_ERROR;
  }
  effective_selclkrx = selclkrx;
  effective_clock_edge = (clock_edge == SDMMC_CLOCK_EDGE_FALLING) ? SDMMC_CLOCK_EDGE_FALLING : SDMMC_CLOCK_EDGE_RISING;
  if ((speed_mode == SDMMC_SPEED_MODE_HIGH) &&
      (XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ != 0UL))
  {
    effective_selclkrx = XE_NP_BOARD_SD_HIGHSPEED_RX_CLOCK ? SDMMC_CLKCR_SELCLKRX_0 : 0U;
    effective_clock_edge = XE_NP_BOARD_SD_HIGHSPEED_FALLING_EDGE ?
                           SDMMC_CLOCK_EDGE_FALLING : SDMMC_CLOCK_EDGE_RISING;
  }
  else if ((speed_mode != SDMMC_SPEED_MODE_ULTRA_SDR104) &&
           (speed_mode != SDMMC_SPEED_MODE_ULTRA_SDR50))
  {
    effective_selclkrx = require_1v8 ? SDMMC_CLKCR_SELCLKRX_0 : 0U;
    effective_clock_edge = SDMMC_CLOCK_EDGE_RISING;
  }
  target_bus_hz = XE_NP_Board_GetSdModeTargetBusHz(speed_mode);
  if ((speed_mode == SDMMC_SPEED_MODE_ULTRA_SDR104) && (clock_div != 0U))
  {
    /*
     * Keep the high-rate SDR104 label for a slower divider fallback, but do
     * not enforce the 180/186 MHz floor when searching lower SDR104 timings.
     */
    target_bus_hz = 0U;
  }
  if ((min_negotiated_bus_hz != 0U) && (min_negotiated_bus_hz > target_bus_hz))
  {
    target_bus_hz = min_negotiated_bus_hz;
  }

  if (XE_NP_Board_ConfigureSdmmcClockSources(sdmmc_clock_source, iclk_clock_source) != HAL_OK)
  {
    xe_np_sd_last_speed_mode_status = 14U;
    xe_np_sd_last_speed_mode_error = HAL_SD_ERROR_NONE;
    xe_np_sd_last_speed_mode_card_state = HAL_SD_GetCardState(&hsd1);
    xe_np_sd_last_speed_mode_sdmmc_kernel_hz = HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SDMMC);
    xe_np_sd_last_speed_mode_sdmmc_bus_hz = XE_NP_Board_ComputeSdBusHz();
    xe_np_sd_last_speed_mode_sdmmc_target_bus_hz = target_bus_hz;
    return HAL_ERROR;
  }

  XE_NP_Board_PrepareSdClockDivForSpeedMode(speed_mode, clock_div);
  XE_NP_Board_RecordSdSpeedAttemptParams(hsd1.Init.ClockDiv,
                                          effective_clock_edge,
                                          effective_selclkrx,
                                          sdmmc_clock_source,
                                          iclk_clock_source);
  hsd1.Init.ClockEdge = effective_clock_edge;
  sdmmc_kernel_hz = HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SDMMC);
#if (XE_NP_SD_SDR104_ALLOW_CLOCKDIV0_LOWER_KERNEL != 0U)
  if ((speed_mode == SDMMC_SPEED_MODE_ULTRA_SDR104) &&
      (clock_div == 0U) &&
      (sdmmc_kernel_hz < XE_NP_SD_SDR104_MIN_NEGOTIATED_BUS_HZ))
  {
    target_bus_hz = 0U;
  }
#endif
  candidate_bus_hz = (hsd1.Init.ClockDiv == 0U) ? sdmmc_kernel_hz : (sdmmc_kernel_hz / (2U * hsd1.Init.ClockDiv));
  xe_np_sd_last_speed_mode_sdmmc_kernel_hz = sdmmc_kernel_hz;
  xe_np_sd_last_speed_mode_sdmmc_bus_hz = candidate_bus_hz;
  xe_np_sd_last_speed_mode_sdmmc_target_bus_hz = target_bus_hz;
  if ((target_bus_hz != 0U) && (candidate_bus_hz < target_bus_hz))
  {
    xe_np_sd_last_speed_mode_status = 15U;
    xe_np_sd_last_speed_mode_card_state = HAL_SD_GetCardState(&hsd1);
    return HAL_ERROR;
  }
  XE_NP_Board_RecordSdSpeedAttemptClockRate(speed_mode, min_negotiated_bus_hz);
  if ((require_1v8 != 0U) &&
      (xe_np_sd_card_speed != CARD_ULTRA_HIGH_SPEED) &&
      (xe_np_sd_card_type != CARD_SDHC_SDXC))
  {
    /*
     * Keep the early gate aligned with realistic UHS capability:
     * SDHC/SDXC-capable cards are the only practical non-1.8V fallback
     * candidates for SDR/DDR UHS modes.
     */
    xe_np_sd_last_speed_mode_status = 4U;
    xe_np_sd_last_speed_mode_error = HAL_SD_ERROR_REQUEST_NOT_APPLICABLE;
    xe_np_sd_last_speed_mode_card_state = HAL_SD_GetCardState(&hsd1);
    return HAL_ERROR;
  }

  XE_NP_Board_RecordSdBenchMarker(XE_NP_SD_BENCH_DIAG_BEFORE_SD_SPEED_SWITCH);
  if (speed_mode == SDMMC_SPEED_MODE_HIGH)
  {
    /* CMD6 must be issued at default-speed timing. Keep this at <=25 MHz for
     * every High-Speed transition, then apply the selected operating divider
     * only after the card confirms function 1 in its 64-byte status. */
    uint32_t switch_div=XE_NP_Board_ComputeClockDivForTargetHz(
        sdmmc_kernel_hz,25000000UL);
    MODIFY_REG(hsd1.Instance->CLKCR,SDMMC_CLKCR_CLKDIV,switch_div);
    __DSB();
  }
  if (HAL_SD_ConfigSpeedBusOperation(&hsd1, speed_mode) == HAL_OK)
  {
    XE_NP_Board_RecordSdBenchMarker(XE_NP_SD_BENCH_DIAG_AFTER_SD_SPEED_SWITCH);
    /*
     * HAL can leave CLKCR.CLKDIV at a conservative live divider after UHS
     * switching. Force the divider selected above so validation and benchmark
     * run at the intended bus rate.
     */
    MODIFY_REG(hsd1.Instance->CLKCR,
               SDMMC_CLKCR_CLKDIV | SDMMC_CLKCR_NEGEDGE | SDMMC_CLKCR_SELCLKRX,
               hsd1.Init.ClockDiv | (effective_clock_edge == SDMMC_CLOCK_EDGE_FALLING ? SDMMC_CLKCR_NEGEDGE : 0U) |
               (effective_selclkrx & SDMMC_CLKCR_SELCLKRX));
    XE_NP_Board_RecordSdSpeedAttemptClockRate(speed_mode, min_negotiated_bus_hz);

    if ((require_1v8 == 0U) || (xe_np_sd_signal_1v8_enabled != 0U))
    {
      if (XE_NP_Board_TuneSdDelayBlock(speed_mode, require_1v8) != HAL_OK)
      {
        xe_np_sd_last_speed_mode_status = 13U;
        xe_np_sd_last_speed_mode_error = hsd1.ErrorCode;
#if (XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U)
        /* Recovery already bounded and checked CMD13. A diagnostic status
         * query here would re-enter an unretired CPSM and hide the failure. */
        xe_np_sd_last_speed_mode_card_state = HAL_SD_CARD_ERROR;
#else
        xe_np_sd_last_speed_mode_card_state = HAL_SD_GetCardState(&hsd1);
        XE_NP_Board_ClearSdSpeedAttemptError();
#endif
        return HAL_ERROR;
      }

#if (XE_NP_SD_VALIDATE_SPEED_READ != 0U)
      if (XE_NP_Board_ProbeSdMetadataRead() != HAL_OK)
      {
        xe_np_sd_last_speed_mode_status = 5U;
        xe_np_sd_last_speed_mode_error = hsd1.ErrorCode;
        xe_np_sd_last_speed_mode_card_state = HAL_SD_GetCardState(&hsd1);
        XE_NP_Board_ClearSdSpeedAttemptError();
        return HAL_ERROR;
      }
#endif

      /* Preserve the negotiated signaling voltage. SDR12/SDR25 are valid at
       * 1.8 V too; reversing CMD11 by just raising VCCIO is not permitted. */

      xe_np_sd_last_speed_mode_status = 1U;
      xe_np_sd_last_speed_mode_card_state = HAL_SD_GetCardState(&hsd1);
      xe_np_sd_negotiated_speed_mode = speed_mode;
      return HAL_OK;
    }

    xe_np_sd_last_speed_mode_status = 3U;
    xe_np_sd_last_speed_mode_card_state = HAL_SD_GetCardState(&hsd1);
  }
  else
  {
    XE_NP_Board_RecordSdBenchMarker(XE_NP_SD_BENCH_DIAG_SD_SPEED_SWITCH_FAIL);
    xe_np_sd_last_speed_mode_status = 2U;
    xe_np_sd_last_speed_mode_error = hsd1.ErrorCode;
    xe_np_sd_last_speed_mode_card_state = HAL_SD_GetCardState(&hsd1);
  }

  XE_NP_Board_ClearSdSpeedAttemptError();
  return HAL_ERROR;
}

static HAL_StatusTypeDef XE_NP_Board_TrySdSpeedModeWithSweep(uint32_t speed_mode,
                                                           uint8_t require_1v8,
                                                           uint32_t min_negotiated_bus_hz)
{
  HAL_StatusTypeDef status;
  uint32_t div_idx;
  uint32_t edge_idx;
  uint32_t selclkrx_idx;
  uint32_t source_idx;
  uint32_t iclk_source_idx;
  uint32_t clock_div_candidates[2];
  uint32_t clock_div_count;
  uint8_t first_candidate = 1U;

  XE_NP_Board_RecordSdBenchMarker(XE_NP_SD_BENCH_DIAG_SWEEP_ENTRY);

  if ((speed_mode != SDMMC_SPEED_MODE_ULTRA_SDR104) &&
      (speed_mode != SDMMC_SPEED_MODE_ULTRA_SDR50) &&
      (speed_mode != SDMMC_SPEED_MODE_DDR))
  {
    return XE_NP_Board_TrySdSpeedMode(speed_mode,
                                       require_1v8,
                                       0xFFFFFFFFU,
                                       SDMMC_CLOCK_EDGE_RISING,
                                       0U,
                                       XE_NP_SDMMC_SDMMC_CLOCK_SOURCE_DEFAULT,
                                       XE_NP_SDMMC_ICLK_CLOCK_SOURCE_DEFAULT,
                                       0U);
  }

  clock_div_count = 1U;
  clock_div_candidates[0] = (speed_mode == SDMMC_SPEED_MODE_ULTRA_SDR104) ? xe_np_sd_post_init_uhs_divs[0] : 0xFFFFFFFFU;
  if (speed_mode == SDMMC_SPEED_MODE_ULTRA_SDR104)
  {
    clock_div_candidates[1] = 1U;
    clock_div_count = 2U;
  }
  /* Exhaust full-rate receive timings before accepting a divided fallback. */
  for (div_idx = 0U; div_idx < clock_div_count; ++div_idx)
  {
    for (source_idx = 0U; source_idx < XE_NP_SD_POST_INIT_TUNE_MAX_SDMMC_CLOCK_SOURCES; ++source_idx)
    {
      for (edge_idx = 0U; edge_idx < XE_NP_SD_POST_INIT_TUNE_MAX_EDGES; ++edge_idx)
      {
        for (selclkrx_idx = 0U; selclkrx_idx < XE_NP_SD_POST_INIT_TUNE_MAX_SELCLKRX; ++selclkrx_idx)
        {
          for (iclk_source_idx = 0U; iclk_source_idx < XE_NP_SD_POST_INIT_TUNE_MAX_ICLK_CLOCK_SOURCES; ++iclk_source_idx)
          {
            uint32_t candidate_min_negotiated_bus_hz = min_negotiated_bus_hz;

            /* A DLYB sweep is meaningless if the receive mux bypasses it.
             * SDR104 must select tuned feedback, not direct CKIN. */
            if(speed_mode == SDMMC_SPEED_MODE_ULTRA_SDR104 &&
               xe_np_sd_post_init_uhs_selclkrx[selclkrx_idx] != SDMMC_CLKCR_SELCLKRX_1) { continue; }
            if(speed_mode == SDMMC_SPEED_MODE_ULTRA_SDR50 &&
               xe_np_sd_post_init_uhs_selclkrx[selclkrx_idx] !=
               ((XE_NP_BOARD_SD_RX_CLOCK_TEST == 2U) ? SDMMC_CLKCR_SELCLKRX_1 : SDMMC_CLKCR_SELCLKRX_0)) { continue; }

            XE_NP_Board_RecordSdBenchMarker(XE_NP_SD_BENCH_DIAG_BEFORE_SD_SWEEP_RESET);
            /* Preserve the fresh CMD11 session for the first speed attempt.
             * Reinitializing here can lose S18A when the rail has not fully
             * discharged. Failed attempts still require explicit recovery. */
            if (first_candidate && require_1v8 && xe_np_sd_signal_1v8_enabled &&
                xe_np_sd_last_speed_mode_attempt == SDMMC_SPEED_MODE_DEFAULT)
            {
              status = HAL_OK;
            }
            else
            {
              status = XE_NP_Board_ResetSdHostBasePreserveSpeedResult();
            }
            first_candidate = 0U;
            if (status != HAL_OK)
            {
              return status;
            }
            XE_NP_Board_RecordSdBenchMarker(XE_NP_SD_BENCH_DIAG_AFTER_SD_SWEEP_RESET);

            if ((speed_mode == SDMMC_SPEED_MODE_ULTRA_SDR104) && (clock_div_candidates[div_idx] != 0U))
            {
              candidate_min_negotiated_bus_hz = 0U;
            }
#if (XE_NP_SD_SDR104_ALLOW_CLOCKDIV0_LOWER_KERNEL != 0U)
            if ((speed_mode == SDMMC_SPEED_MODE_ULTRA_SDR104) && (clock_div_candidates[div_idx] == 0U))
            {
              candidate_min_negotiated_bus_hz = 0U;
            }
#endif

              status = XE_NP_Board_TrySdSpeedMode(speed_mode,
                                             require_1v8,
                                           clock_div_candidates[div_idx],
                                           xe_np_sd_post_init_uhs_clock_edges[edge_idx],
                                           xe_np_sd_post_init_uhs_selclkrx[selclkrx_idx],
                                           xe_np_sd_post_init_uhs_sdmmc_sources[source_idx],
                                           xe_np_sd_post_init_uhs_iclk_sources[iclk_source_idx],
                                           candidate_min_negotiated_bus_hz);
#if (XE_NP_BOARD_SD_RX_CLOCK_TEST != 0U)
            if(xe_np_sd_signal_attempt_count < 2U) {
              volatile uint32_t *row=xe_np_sd_signal_attempts[xe_np_sd_signal_attempt_count++];
              row[0]=speed_mode;row[1]=xe_np_sd_last_speed_mode_clock_edge;
              row[2]=xe_np_sd_last_speed_mode_selclkrx;row[3]=xe_np_sd_last_speed_mode_status;
              row[4]=xe_np_sd_last_speed_mode_error;row[5]=xe_np_sd_signal_1v8_enabled;
              row[6]=hsd1.Instance->CLKCR;row[7]=DLYB_SDMMC1->CR;row[8]=DLYB_SDMMC1->CFGR;
              row[9]=xe_np_sd_bench_diag.dlyb_tune_status;row[10]=xe_np_sd_bench_diag.dlyb_tune_units;
              row[11]=xe_np_sd_bench_diag.dlyb_tune_pass_mask;row[12]=xe_np_sd_bench_diag.dlyb_tune_selected_phase;
              row[13]=xe_np_sd_tuning_block_diag.error;
            }
#endif
            if (status == HAL_OK)
            {
              return HAL_OK;
            }
          }
        }
      }
    }
  }

  return HAL_ERROR;
}

static void XE_NP_Board_PostInitSdTuning(void)
{
  XE_NP_Board_RecordSdBenchMarker(XE_NP_SD_BENCH_DIAG_POST_INIT_ENTRY);
  XE_NP_Board_EnsureSdPowerRail();
  XE_NP_Board_RecordSdBenchMarker(XE_NP_SD_BENCH_DIAG_POST_INIT_AFTER_RAIL);
  xe_np_sd_negotiated_speed_mode = SDMMC_SPEED_MODE_DEFAULT;

#if (XE_NP_BOARD_SD_SDR104_ONLY != 0U)
  {
    HAL_StatusTypeDef status;
#if XE_NP_V2_MEDIA_ENABLE || XE_NP_NP2_DUAL_SD_APP_ENABLE || XE_NP_SD_BASIC_CURRENT_EXTENT || XE_NP_NP2_LIVE_SD_DUAL_SCRATCH_OVERFLOW_DMA || XE_NP_USB_UNIFIED_ENABLE
    /* Boot only, before catalog mount or acquisition: HAL_SD_Init already
     * completed CMD11 for this fresh session. Do not throw that success away
     * with another rail cycle, which can lose S18A on a still-powered card.
     * Failed/prior speed sessions still require the normal reset baseline.
     * A failed speed switch is not retried or reported as a successful UHS
     * session. Other diagnostic images retain their existing reset policy. */
    xe_np_sd_first_session_diag[0]=0x53444653U;
    xe_np_sd_first_session_diag[1]=1U;
    xe_np_sd_first_session_diag[2]=xe_np_sd_init_diag.attempts;
    xe_np_sd_first_session_diag[3]=xe_np_sd_init_diag.ocr;
    xe_np_sd_first_session_diag[4]=xe_np_sd_signal_1v8_enabled;
    xe_np_sd_first_session_diag[5]=xe_np_sd_last_speed_mode_attempt;
    xe_np_sd_first_session_diag[6]=hsd1.State;
    xe_np_sd_first_session_diag[7]=hsd1.ErrorCode;
    xe_np_sd_first_session_diag[8]=0U;
    if ((xe_np_sd_init_failed == 0U) && xe_np_sd_signal_1v8_enabled &&
        (xe_np_sd_last_speed_mode_attempt == SDMMC_SPEED_MODE_DEFAULT) &&
        (hsd1.State == HAL_SD_STATE_READY) && (hsd1.ErrorCode == HAL_SD_ERROR_NONE))
    {
      status=HAL_OK;
      xe_np_sd_first_session_diag[8]=1U;
    }
    else
#endif
    {
#if XE_NP_SD_CMD11_PIN_COMPAT_ENABLE
      /* Compatibility must not turn an absent S18A/failed fresh session into
       * a hidden rail-cycle retry. The requested UHS mode is unavailable. */
      status=HAL_ERROR;
      xe_np_sd_last_speed_mode_attempt=XE_NP_NP2_SD_STOPPED_DDR50_40_TEST?
          SDMMC_SPEED_MODE_DDR:(XE_NP_NP2_SD_DUAL20_SDR50_96_TEST?
              SDMMC_SPEED_MODE_ULTRA_SDR50:SDMMC_SPEED_MODE_ULTRA_SDR104);
      xe_np_sd_last_speed_mode_status=3U;
      xe_np_sd_last_speed_mode_error=HAL_SD_ERROR_REQUEST_NOT_APPLICABLE;
      XE_NP_Board_SetSdInitFailed(1U);
#else
      status=XE_NP_Board_ResetSdHostBase();
#endif
    }
    if(status==HAL_OK) {
#if XE_NP_NP2_SD_STOPPED_DDR50_40_TEST
      /* Exclusive source-free comparator: DDR50 at 40MHz, not a live profile
       * or a fallback from a failed SDR switch. Fresh 1.8V session required. */
      status=XE_NP_Board_TrySdSpeedMode(SDMMC_SPEED_MODE_DDR,1U,1U,
          SDMMC_CLOCK_EDGE_RISING,SDMMC_CLKCR_SELCLKRX_0,
          XE_NP_SDMMC_SDMMC_CLOCK_SOURCE_DEFAULT,
          XE_NP_SDMMC_ICLK_CLOCK_SOURCE_DEFAULT,40000000U);
#else
      status=XE_NP_Board_TrySdSpeedMode(
          (XE_NP_NP2_SD_SDR50_POWER_TEST || XE_NP_NP2_SD_STOPPED_SDR50_100_TEST ||
           XE_NP_NP2_SD_DUAL20_SDR50_96_TEST)?
              SDMMC_SPEED_MODE_ULTRA_SDR50:SDMMC_SPEED_MODE_ULTRA_SDR104,1U,
          XE_NP_NP2_SD_SDR50_POWER_TEST?1U:XE_NP_BOARD_SD_TEST_CLKDIV,
          XE_NP_BOARD_SD_RISING_EDGE_FIRST ? SDMMC_CLOCK_EDGE_RISING : SDMMC_CLOCK_EDGE_FALLING,
          /* Diagnostic only: CMD19-verified direct CKIN, not DLYB tuning. */
#if XE_NP_SD_BASIC_DIRECT_CKIN
          SDMMC_CLKCR_SELCLKRX_0,
#else
          SDMMC_CLKCR_SELCLKRX_1,
#endif
          XE_NP_SDMMC_SDMMC_CLOCK_SOURCE_DEFAULT,
          XE_NP_SDMMC_ICLK_CLOCK_SOURCE_DEFAULT,
          XE_NP_NP2_SD_DUAL20_SDR50_96_TEST?96000000U:
              (XE_NP_NP2_SD_STOPPED_SDR50_100_TEST?100000000U:
               (XE_NP_NP2_SD_STOPPED_SDR104_120_TEST?120000000U:0U)));
#endif
    }
    xe_np_sd_signal_test_finished=(status==HAL_OK)?1U:2U;
#if XE_NP_V2_MEDIA_ENABLE || XE_NP_NP2_DUAL_SD_APP_ENABLE || XE_NP_SD_BASIC_CURRENT_EXTENT || XE_NP_NP2_LIVE_SD_DUAL_SCRATCH_OVERFLOW_DMA || XE_NP_USB_UNIFIED_ENABLE
    xe_np_sd_first_session_diag[9]=status;
    xe_np_sd_first_session_diag[10]=xe_np_sd_init_diag.attempts;
    xe_np_sd_first_session_diag[11]=xe_np_sd_init_diag.ocr;
#endif
    return;
  }
#endif

#if (XE_NP_SD_POST_INIT_TUNING_ENABLE == 0U)
  /*
   * Current hardware tests show that a failed UHS/SDR fallback can wedge the
   * card/HAL session before the application starts. Keep boot fail-open at a
   * safe default-speed clock; storage readiness will reject NP raw recording
   * until a validated high-speed path is re-enabled.
   */
  XE_NP_Board_PrepareSdClockDivForSpeedMode(SDMMC_SPEED_MODE_DEFAULT, 0xFFFFFFFFU);
  XE_NP_Board_RecordSdSpeedAttemptParams(hsd1.Init.ClockDiv,
                                         SDMMC_CLOCK_EDGE_RISING,
                                         0U,
                                         XE_NP_SDMMC_SDMMC_CLOCK_SOURCE_DEFAULT,
                                         XE_NP_SDMMC_ICLK_CLOCK_SOURCE_DEFAULT);
  XE_NP_Board_ClearSdSpeedAttemptError();
  xe_np_sd_last_speed_mode_attempt = SDMMC_SPEED_MODE_DEFAULT;
  xe_np_sd_last_speed_mode_card_state = HAL_SD_GetCardState(&hsd1);
  xe_np_sd_last_speed_mode_status = 11U;
  (void)XE_NP_Board_ConfigureSdmmcClockSources(XE_NP_SDMMC_SDMMC_CLOCK_SOURCE_DEFAULT,
                                              XE_NP_SDMMC_ICLK_CLOCK_SOURCE_DEFAULT);
  return;
#else
  /*
   * Best-effort post-init tuning:
   * - keep 4-bit mode from HAL_SD_Init()
   * - request the highest speed mode the card supports using an explicit
   *   local fallback chain
   * - current SDR50 ceiling skips SDR104/DDR; explicit experiments may enable them
   * - do not fail boot if a card stays in default-speed mode
  */
#if (XE_NP_SD_TRY_SDR104_READ_VALIDATED != 0U)
  if (XE_NP_Board_TrySdSpeedModeWithSweep(SDMMC_SPEED_MODE_ULTRA_SDR104,
                                          1U,
                                          XE_NP_SD_SDR104_PREFERRED_NEGOTIATED_BUS_HZ) == HAL_OK)
  {
    return;
  }

  if (XE_NP_Board_TrySdSpeedModeWithSweep(SDMMC_SPEED_MODE_ULTRA_SDR104,
                                          1U,
                                          XE_NP_SD_SDR104_MIN_NEGOTIATED_BUS_HZ) == HAL_OK)
  {
    return;
  }
#endif

#if (XE_NP_SD_TRY_SDR50_READ_VALIDATED != 0U)
  if (XE_NP_Board_TrySdSpeedModeWithSweep(SDMMC_SPEED_MODE_ULTRA_SDR50, 1U, 0U) == HAL_OK)
  {
#if (XE_NP_BOARD_SD_RX_CLOCK_TEST != 0U)
    xe_np_sd_signal_test_finished = 1U;
#endif
    return;
  }
#endif
#if (XE_NP_BOARD_SD_RX_CLOCK_TEST != 0U)
  /* Preserve the requested mode's diagnostics rather than hiding failure
   * under a successful lower-mode fallback. These images never auto-write. */
  xe_np_sd_signal_test_finished = 2U;
  return;
#endif

#if (XE_NP_SD_TRY_DDR_READ_VALIDATED != 0U)
  if (XE_NP_Board_TrySdSpeedModeWithSweep(SDMMC_SPEED_MODE_DDR, 1U, 0U) == HAL_OK)
  {
    return;
  }
#endif

#if (XE_NP_SD_TRY_SDR25_HIGH_SPEED != 0U)
  if (XE_NP_Board_TrySdSpeedModeWithSweep(SDMMC_SPEED_MODE_HIGH, 0U, 0U) == HAL_OK)
  {
    return;
  }
#endif

  if (XE_NP_Board_ResetSdHostBasePreserveSpeedResult() == HAL_OK)
  {
    XE_NP_Board_PrepareSdClockDivForSpeedMode(SDMMC_SPEED_MODE_DEFAULT, 0xFFFFFFFFU);
    MODIFY_REG(hsd1.Instance->CLKCR,
               SDMMC_CLKCR_CLKDIV | SDMMC_CLKCR_NEGEDGE | SDMMC_CLKCR_SELCLKRX,
               hsd1.Init.ClockDiv);
    XE_NP_Board_ClearSdSpeedAttemptError();
    xe_np_sd_negotiated_speed_mode = SDMMC_SPEED_MODE_DEFAULT;
    if (xe_np_sd_last_speed_mode_attempt == SDMMC_SPEED_MODE_DEFAULT)
    {
      XE_NP_Board_RecordSdSpeedAttemptParams(hsd1.Init.ClockDiv,
                                             SDMMC_CLOCK_EDGE_RISING,
                                             0U,
                                             XE_NP_SDMMC_SDMMC_CLOCK_SOURCE_DEFAULT,
                                             XE_NP_SDMMC_ICLK_CLOCK_SOURCE_DEFAULT);
      XE_NP_Board_RecordSdSpeedAttemptClockRate(SDMMC_SPEED_MODE_DEFAULT, 0U);
      xe_np_sd_last_speed_mode_attempt = SDMMC_SPEED_MODE_DEFAULT;
      xe_np_sd_last_speed_mode_card_state = HAL_SD_GetCardState(&hsd1);
      xe_np_sd_last_speed_mode_status = 12U;
    }
  }
#endif
}

void XE_NP_Board_EnsureSdPowerRail(void)
{
  /*
   * VEE_EN powers the storage-side domain, including the SD card VDD_3V3 rail.
   * Bring it up before the SD host touches the card. SD_VSEL only selects the
   * VCCIO_SD logic level; it does not replace the 3.3 V card supply.
   */
  if (HAL_GPIO_ReadPin(VEE_EN_GPIO_Port, VEE_EN_Pin) != GPIO_PIN_SET)
  {
    HAL_GPIO_WritePin(VEE_EN_GPIO_Port, VEE_EN_Pin, GPIO_PIN_SET);
    HAL_Delay(XE_NP_SD_POWER_RAIL_SETTLE_MS);
  }
}

static void XE_NP_Board_SdBench_DCacheClean(const void *addr, uint32_t size_bytes)
{
#if defined(__DCACHE_PRESENT) && (__DCACHE_PRESENT == 1U)
  uintptr_t start_addr;
  uintptr_t end_addr;

  if ((addr == NULL) || (size_bytes == 0U))
  {
    return;
  }

  start_addr = ((uintptr_t)addr) & ~((uintptr_t)31U);
  end_addr = (((uintptr_t)addr) + (uintptr_t)size_bytes + 31U) & ~((uintptr_t)31U);
  SCB_CleanDCache_by_Addr((void *)start_addr, (int32_t)(end_addr - start_addr));
#else
  (void)addr;
  (void)size_bytes;
#endif
}

static void XE_NP_Board_RecordSdBenchMarker(uint32_t marker)
{
  xe_np_sd_bench_diag.fail_status = marker;
  xe_np_sd_boot_stage_marker = marker;
  XE_NP_Board_SdBench_DCacheClean((const void *)&xe_np_sd_bench_diag.fail_status,
                                  (uint32_t)sizeof(xe_np_sd_bench_diag.fail_status));
  XE_NP_Board_RecordStartupProgressMarker(marker);
}

static void XE_NP_Board_UpdateSdBenchLiveDiag(void)
{
  xe_np_sd_bench_diag.speed_mode = xe_np_sd_negotiated_speed_mode;
  xe_np_sd_bench_diag.sdmmc_kernel_hz = HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SDMMC);
  xe_np_sd_bench_diag.sdmmc_bus_hz = XE_NP_Board_ComputeSdBusHz();
  xe_np_sd_bench_diag.clock_div = hsd1.Init.ClockDiv;
  xe_np_sd_bench_diag.card_speed = xe_np_sd_card_speed;
  xe_np_sd_bench_diag.card_type = xe_np_sd_card_type;
  xe_np_sd_bench_diag.error_code = hsd1.ErrorCode;
  xe_np_sd_bench_diag.card_state = (hsd1.Instance != NULL) ?
                                   (uint32_t)HAL_SD_GetCardState(&hsd1) :
                                   HAL_SD_CARD_DISCONNECTED;
  xe_np_sd_bench_diag.hal_state = (uint32_t)hsd1.State;
  xe_np_sd_bench_diag.hal_context = hsd1.Context;
  xe_np_sd_bench_diag.sdmmc_sta = (hsd1.Instance != NULL) ? hsd1.Instance->STA : 0U;
  xe_np_sd_bench_diag.sdmmc_dctrl = (hsd1.Instance != NULL) ? hsd1.Instance->DCTRL : 0U;
  xe_np_sd_bench_diag.sdmmc_clkcr = (hsd1.Instance != NULL) ? hsd1.Instance->CLKCR : 0U;
  xe_np_sd_bench_diag.last_speed_mode_clock_div = xe_np_sd_last_speed_mode_clock_div;
  xe_np_sd_bench_diag.last_speed_mode_clock_edge = xe_np_sd_last_speed_mode_clock_edge;
  xe_np_sd_bench_diag.last_speed_mode_selclkrx = xe_np_sd_last_speed_mode_selclkrx;
  xe_np_sd_bench_diag.last_speed_mode_sdmmc_clock_source = xe_np_sd_last_speed_mode_sdmmc_clock_source;
  xe_np_sd_bench_diag.last_speed_mode_iclk_clock_source = xe_np_sd_last_speed_mode_iclk_clock_source;
  xe_np_sd_bench_diag.last_speed_mode_sdmmc_kernel_hz = xe_np_sd_last_speed_mode_sdmmc_kernel_hz;
  xe_np_sd_bench_diag.last_speed_mode_sdmmc_bus_hz = xe_np_sd_last_speed_mode_sdmmc_bus_hz;
  xe_np_sd_bench_diag.last_speed_mode_sdmmc_target_bus_hz = xe_np_sd_last_speed_mode_sdmmc_target_bus_hz;
  xe_np_sd_bench_diag.sdmmc_idmabsize = (hsd1.Instance != NULL) ? hsd1.Instance->IDMABSIZE : 0U;
  xe_np_sd_bench_diag.sdmmc_idmabar = (hsd1.Instance != NULL) ? hsd1.Instance->IDMABAR : 0U;
  xe_np_sd_bench_diag.sdmmc_idmalar = (hsd1.Instance != NULL) ? hsd1.Instance->IDMALAR : 0U;
  xe_np_sd_bench_diag.sdmmc_idmactrl = (hsd1.Instance != NULL) ? hsd1.Instance->IDMACTRL : 0U;
  xe_np_sd_bench_diag.signal_1v8_enabled = xe_np_sd_signal_1v8_enabled;
  xe_np_sd_bench_diag.signal_1v8_seen = xe_np_sd_signal_1v8_seen;
  xe_np_sd_bench_diag.gpio_c_hslvr = GPIOC->HSLVR;
  xe_np_sd_bench_diag.gpio_d_hslvr = GPIOD->HSLVR;
  xe_np_sd_bench_diag.gpio_b_hslvr = GPIOB->HSLVR;
  xe_np_sd_bench_diag.gpio_hslv_enabled =
      (((GPIOC->HSLVR & (GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_12)) != 0U) ||
       ((GPIOD->HSLVR & GPIO_PIN_2) != 0U) ||
       ((GPIOB->HSLVR & GPIO_PIN_8) != 0U)) ? 1U : 0U;
#if defined(DLYB_SDMMC1)
  xe_np_sd_bench_diag.dlyb_cr = DLYB_SDMMC1->CR;
  xe_np_sd_bench_diag.dlyb_cfgr = DLYB_SDMMC1->CFGR;
#else
  xe_np_sd_bench_diag.dlyb_cr = 0U;
  xe_np_sd_bench_diag.dlyb_cfgr = 0U;
#endif

  XE_NP_Board_SdBench_DCacheClean((const void *)&xe_np_sd_bench_diag,
                                  (uint32_t)sizeof(xe_np_sd_bench_diag));
}

static int XE_NP_Board_WaitSdBenchChunkDone(uint32_t timeout_ms)
{
  uint32_t start_tick = HAL_GetTick();

  while ((HAL_GetTick() - start_tick) < timeout_ms)
  {
    if (hsd1.State == HAL_SD_STATE_READY)
    {
      uint32_t card_state = (uint32_t)HAL_SD_GetCardState(&hsd1);
      xe_np_sd_bench_diag.card_state = card_state;
      xe_np_sd_bench_diag.error_code = hsd1.ErrorCode;
      if ((hsd1.ErrorCode != HAL_SD_ERROR_NONE) || (card_state == HAL_SD_CARD_ERROR))
      {
        xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_STATUS_CARD_ERROR;
        return -1;
      }
      if (card_state == HAL_SD_CARD_TRANSFER)
      {
        return 0;
      }
    }
  }

  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_STATUS_TIMEOUT;
  return -1;
}

static HAL_StatusTypeDef XE_NP_Board_BuildSdBenchLinkedList(void)
{
  HAL_StatusTypeDef status;

  memset((void *)xe_np_sd_bench_ll_nodes, 0, sizeof(xe_np_sd_bench_ll_nodes));
  memset((void *)&xe_np_sd_bench_ll, 0, sizeof(xe_np_sd_bench_ll));

  for (uint32_t i = 0U; i < XE_NP_SD_BENCH_LL_NODE_COUNT; ++i)
  {
    SD_DMALinkNodeConfTypeDef node_conf;

    node_conf.BufferAddress = (uint32_t)&xe_np_sd_bench_buf[i * XE_NP_SD_BENCH_LL_NODE_BYTES];
    node_conf.BufferSize = XE_NP_SD_BENCH_LL_NODE_BYTES;

    status = HAL_SDEx_DMALinkedList_BuildNode(&xe_np_sd_bench_ll_nodes[i], &node_conf);
    if (status != HAL_OK)
    {
      return status;
    }

    status = HAL_SDEx_DMALinkedList_InsertNode(&xe_np_sd_bench_ll,
                                               xe_np_sd_bench_ll.pTailNode,
                                               &xe_np_sd_bench_ll_nodes[i]);
    if (status != HAL_OK)
    {
      return status;
    }
  }

  status = HAL_SDEx_DMALinkedList_EnableCircularMode(&xe_np_sd_bench_ll);
  if (status != HAL_OK)
  {
    return status;
  }

  XE_NP_Board_SdBench_DCacheClean(xe_np_sd_bench_ll_nodes, (uint32_t)sizeof(xe_np_sd_bench_ll_nodes));
  XE_NP_Board_SdBench_DCacheClean(&xe_np_sd_bench_ll, (uint32_t)sizeof(xe_np_sd_bench_ll));

  return HAL_OK;
}

static uint32_t XE_NP_Board_SdBenchPreErase(uint32_t block_count)
{
  uint32_t errorstate;

  errorstate = SDMMC_CmdAppCommand(hsd1.Instance, (uint32_t)(hsd1.SdCard.RelCardAdd << 16U));
  if (errorstate != HAL_SD_ERROR_NONE)
  {
    return errorstate;
  }

  /*
   * ACMD23 uses the same command index as CMD23 after CMD55. For SD cards it
   * tells the card how many write blocks to pre-erase before the next CMD25.
   */
  return SDMMC_CmdBlockCount(hsd1.Instance, block_count);
}

static int XE_NP_Board_PreEraseSdBenchRange(void)
{
  const uint32_t erase_start = XE_NP_SD_BENCH_START_BLOCK;
  const uint32_t erase_end = XE_NP_SD_BENCH_START_BLOCK + XE_NP_SD_BENCH_TOTAL_BLOCKS - 1U;

  if (HAL_SD_Erase(&hsd1, erase_start, erase_end) != HAL_OK)
  {
    xe_np_sd_bench_diag.ll_acmd23_error = hsd1.ErrorCode;
    xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_STATUS_CARD_ERROR;
    return -1;
  }

  if (XE_NP_Board_WaitSdBenchChunkDone(120000U) != 0)
  {
    xe_np_sd_bench_diag.ll_acmd23_error = hsd1.ErrorCode;
    xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_STATUS_TIMEOUT;
    return -1;
  }

  return 0;
}

static void XE_NP_Board_ReadSdBenchCardStatus(void)
{
  HAL_SD_CardStatusTypeDef card_status;

  memset(&card_status, 0, sizeof(card_status));
  if (HAL_SD_GetCardStatus(&hsd1, &card_status) != HAL_OK)
  {
    return;
  }

  xe_np_sd_bench_diag.sd_status_speed_class = card_status.SpeedClass;
  xe_np_sd_bench_diag.sd_status_perf_move = card_status.PerformanceMove;
  xe_np_sd_bench_diag.sd_status_au_size = card_status.AllocationUnitSize;
  xe_np_sd_bench_diag.sd_status_erase_size = card_status.EraseSize;
  xe_np_sd_bench_diag.sd_status_uhs_grade = card_status.UhsSpeedGrade;
  xe_np_sd_bench_diag.sd_status_uhs_au_size = card_status.UhsAllocationUnitSize;
  xe_np_sd_bench_diag.sd_status_video_class = card_status.VideoSpeedClass;
}

static uint32_t XE_NP_Board_SdBenchSpeedClassControl(uint32_t scc)
{
  SDMMC_CmdInitTypeDef sdmmc_cmdinit;
  uint32_t errorstate;
  uint32_t start_tick;

  __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_STATIC_FLAGS);

  sdmmc_cmdinit.Argument = (scc & 0xFUL) << 28U;
  sdmmc_cmdinit.CmdIndex = SDMMC_CMD_WRITE_DAT_UNTIL_STOP;
  sdmmc_cmdinit.Response = SDMMC_RESPONSE_SHORT;
  sdmmc_cmdinit.WaitForInterrupt = SDMMC_WAIT_NO;
  sdmmc_cmdinit.CPSM = SDMMC_CPSM_ENABLE;
  (void)SDMMC_SendCommand(hsd1.Instance, &sdmmc_cmdinit);

  errorstate = SDMMC_GetCmdResp1(hsd1.Instance,
                                 SDMMC_CMD_WRITE_DAT_UNTIL_STOP,
                                 SDMMC_CMDTIMEOUT);
  if (errorstate != HAL_SD_ERROR_NONE)
  {
    return errorstate;
  }

  start_tick = HAL_GetTick();
  while ((hsd1.Instance->STA & SDMMC_FLAG_BUSYD0) != 0U)
  {
    if ((HAL_GetTick() - start_tick) >= 5000U)
    {
      return HAL_SD_ERROR_TIMEOUT;
    }
  }
  __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_FLAG_BUSYD0END);

  return HAL_SD_ERROR_NONE;
}

#if ((XE_NP_SD_BENCH_USE_IDMA_LINKED_LIST != 0U) && \
     (XE_NP_SD_BENCH_USE_CMD23_BLOCK_COUNT != 0U) && \
     (XE_NP_SD_BENCH_USE_CMD23_NO_CMD12 != 0U))
static HAL_StatusTypeDef XE_NP_Board_StartSdBenchLinkedListNoCmd12(uint32_t block_add,
                                                                   uint32_t number_of_blocks)
{
  SDMMC_DataInitTypeDef config;
  uint32_t add = block_add;
  uint32_t errorstate;

  if (hsd1.State != HAL_SD_STATE_READY)
  {
    return HAL_BUSY;
  }

  if ((add + number_of_blocks) > hsd1.SdCard.LogBlockNbr)
  {
    hsd1.ErrorCode |= HAL_SD_ERROR_ADDR_OUT_OF_RANGE;
    return HAL_ERROR;
  }

  hsd1.Instance->IDMABASER = (uint32_t)xe_np_sd_bench_ll.pHeadNode->IDMABASER;
  hsd1.Instance->IDMABSIZE = (uint32_t)xe_np_sd_bench_ll.pHeadNode->IDMABSIZE;
  hsd1.Instance->IDMABAR = (uint32_t)xe_np_sd_bench_ll.pHeadNode;
  hsd1.Instance->IDMALAR = (uint32_t)SDMMC_IDMALAR_ABR | SDMMC_IDMALAR_ULS |
                           SDMMC_IDMALAR_ULA | sizeof(SDMMC_DMALinkNodeTypeDef);

  if ((hsd1.Instance->IDMABSIZE == 0U) ||
      (hsd1.Instance->IDMABASER == 0U) ||
      (hsd1.Instance->IDMABAR == 0U))
  {
    hsd1.ErrorCode |= HAL_SD_ERROR_ADDR_OUT_OF_RANGE;
    return HAL_ERROR;
  }

  __HAL_SD_DISABLE_IT(&hsd1, SDMMC_IT_DCRCFAIL | SDMMC_IT_DTIMEOUT | SDMMC_IT_TXUNDERR |
                      SDMMC_IT_DATAEND | SDMMC_IT_IDMABTC);
  __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_STATIC_FLAGS);

  hsd1.Instance->DCTRL = 0U;
  hsd1.ErrorCode = HAL_SD_ERROR_NONE;
  hsd1.State = HAL_SD_STATE_BUSY;

  if (hsd1.SdCard.CardType != CARD_SDHC_SDXC)
  {
    add *= BLOCKSIZE;
  }

  config.DataTimeOut = SDMMC_DATATIMEOUT;
  config.DataLength = BLOCKSIZE * number_of_blocks;
  config.DataBlockSize = SDMMC_DATABLOCK_SIZE_512B;
  config.TransferDir = SDMMC_TRANSFER_DIR_TO_CARD;
  config.TransferMode = SDMMC_TRANSFER_MODE_BLOCK;
  config.DPSM = SDMMC_DPSM_DISABLE;
  (void)SDMMC_ConfigData(hsd1.Instance, &config);

  __SDMMC_CMDTRANS_ENABLE(hsd1.Instance);
  hsd1.Instance->IDMACTRL = SDMMC_ENABLE_IDMA_DOUBLE_BUFF0;
  hsd1.Context = (SD_CONTEXT_WRITE_MULTIPLE_BLOCK | SD_CONTEXT_DMA);

  errorstate = SDMMC_CmdWriteMultiBlock(hsd1.Instance, add);
  if (errorstate != HAL_SD_ERROR_NONE)
  {
    __SDMMC_CMDTRANS_DISABLE(hsd1.Instance);
    hsd1.Instance->IDMACTRL = SDMMC_DISABLE_IDMA;
    hsd1.State = HAL_SD_STATE_READY;
    hsd1.Context = SD_CONTEXT_NONE;
    hsd1.ErrorCode |= errorstate;
    return HAL_ERROR;
  }

  return HAL_OK;
}

static void XE_NP_Board_RecordSdBenchDataError(uint32_t flags)
{
  if ((flags & SDMMC_FLAG_DCRCFAIL) != 0U)
  {
    hsd1.ErrorCode |= HAL_SD_ERROR_DATA_CRC_FAIL;
  }
  if ((flags & SDMMC_FLAG_DTIMEOUT) != 0U)
  {
    hsd1.ErrorCode |= HAL_SD_ERROR_DATA_TIMEOUT;
  }
  if ((flags & SDMMC_FLAG_TXUNDERR) != 0U)
  {
    hsd1.ErrorCode |= HAL_SD_ERROR_TX_UNDERRUN;
  }
  if ((flags & SDMMC_FLAG_IDMATE) != 0U)
  {
    hsd1.ErrorCode |= HAL_SD_ERROR_DMA;
  }
}

static void XE_NP_Board_FinishSdBenchNoCmd12(void)
{
  __HAL_SD_DISABLE_IT(&hsd1, SDMMC_IT_DCRCFAIL | SDMMC_IT_DTIMEOUT | SDMMC_IT_TXUNDERR |
                      SDMMC_IT_DATAEND | SDMMC_IT_IDMABTC);
  __SDMMC_CMDTRANS_DISABLE(hsd1.Instance);
  hsd1.Instance->DLEN = 0U;
  hsd1.Instance->DCTRL = 0U;
  hsd1.Instance->IDMACTRL = SDMMC_DISABLE_IDMA;
  __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_STATIC_DATA_FLAGS);
  hsd1.State = HAL_SD_STATE_READY;
  hsd1.Context = SD_CONTEXT_NONE;
}

static int XE_NP_Board_WaitSdBenchNoCmd12Done(uint32_t timeout_ms)
{
  uint32_t start_tick = HAL_GetTick();
  uint32_t data_end_tick = 0U;
  uint32_t data_end_seen = 0U;
  const uint32_t error_flags = SDMMC_FLAG_DCRCFAIL | SDMMC_FLAG_DTIMEOUT |
                               SDMMC_FLAG_TXUNDERR | SDMMC_FLAG_IDMATE;

  while ((HAL_GetTick() - start_tick) < timeout_ms)
  {
    uint32_t flags = hsd1.Instance->STA;
    xe_np_sd_bench_diag.wait_loop_count++;

    if ((flags & SDMMC_FLAG_IDMABTC) != 0U)
    {
      __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_FLAG_IDMABTC);
      HAL_SDEx_Write_DMALnkLstBufCpltCallback(&hsd1);
    }

    if ((flags & error_flags) != 0U)
    {
      XE_NP_Board_RecordSdBenchDataError(flags);
      __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_STATIC_DATA_FLAGS);
      __SDMMC_CMDTRANS_DISABLE(hsd1.Instance);
      hsd1.Instance->DCTRL |= SDMMC_DCTRL_FIFORST;
      hsd1.Instance->CMD |= SDMMC_CMD_CMDSTOP;
      hsd1.ErrorCode |= SDMMC_CmdStopTransfer(hsd1.Instance);
      hsd1.Instance->CMD &= ~(SDMMC_CMD_CMDSTOP);
      __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_FLAG_DABORT);
      hsd1.Instance->IDMACTRL = SDMMC_DISABLE_IDMA;
      hsd1.State = HAL_SD_STATE_READY;
      hsd1.Context = SD_CONTEXT_NONE;
      xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_STATUS_CARD_ERROR;
      return -1;
    }

    if (((flags & SDMMC_FLAG_DATAEND) != 0U) && (data_end_seen == 0U))
    {
      uint32_t transfer_ms;

      data_end_tick = HAL_GetTick();
      transfer_ms = data_end_tick - start_tick;
      xe_np_sd_bench_diag.last_transfer_ms = transfer_ms;
      xe_np_sd_bench_diag.total_transfer_ms += transfer_ms;
      if (transfer_ms > xe_np_sd_bench_diag.worst_transfer_ms)
      {
        xe_np_sd_bench_diag.worst_transfer_ms = transfer_ms;
      }
      xe_np_sd_bench_diag.dataend_count++;
      __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_FLAG_DATAEND);
      XE_NP_Board_FinishSdBenchNoCmd12();
      data_end_seen = 1U;
    }

    if (data_end_seen != 0U)
    {
      uint32_t now_tick;
      uint32_t busy_ms;
      uint32_t card_state = (uint32_t)HAL_SD_GetCardState(&hsd1);
      xe_np_sd_bench_diag.cmd13_poll_count++;
      xe_np_sd_bench_diag.card_state = card_state;
      xe_np_sd_bench_diag.error_code = hsd1.ErrorCode;
      if ((hsd1.ErrorCode != HAL_SD_ERROR_NONE) || (card_state == HAL_SD_CARD_ERROR))
      {
        xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_STATUS_CARD_ERROR;
        return -1;
      }
      if (card_state == HAL_SD_CARD_TRANSFER)
      {
        now_tick = HAL_GetTick();
        busy_ms = (now_tick >= data_end_tick) ? (now_tick - data_end_tick) : 0U;
        xe_np_sd_bench_diag.last_busy_ms = busy_ms;
        xe_np_sd_bench_diag.total_busy_ms += busy_ms;
        if (busy_ms > xe_np_sd_bench_diag.worst_busy_ms)
        {
          xe_np_sd_bench_diag.worst_busy_ms = busy_ms;
        }
        return 0;
      }
    }
  }

  XE_NP_Board_FinishSdBenchNoCmd12();
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_STATUS_TIMEOUT;
  return -1;
}

#if (XE_NP_SD_BENCH_RETARGET_INTEGRITY_TEST != 0U)
static void XE_NP_Board_SdBench_DCacheInvalidate(void *addr, uint32_t size_bytes);

static void XE_NP_Board_SdBenchFillPattern(uint8_t *buffer, uint32_t bytes, uint8_t value)
{
  memset(buffer, value, bytes);
  /* Make a constant pattern robust against an accidental all-zero/truncated
   * transfer and identify each 512-byte media block independently. */
  for (uint32_t offset = 0U; offset < bytes; offset += XE_NP_SD_BENCH_BLOCK_BYTES)
  {
    buffer[offset] = value;
    buffer[offset + 1U] = (uint8_t)(offset >> 9U);
    buffer[offset + 2U] = (uint8_t)(offset >> 17U);
    buffer[offset + 3U] = (uint8_t)~value;
  }
}

static int XE_NP_Board_SdBenchVerifyPattern(const uint8_t *buffer,
                                             uint32_t bytes,
                                             uint8_t value)
{
  for (uint32_t offset = 0U; offset < bytes; ++offset)
  {
    uint8_t expected = value;

    switch (offset % XE_NP_SD_BENCH_BLOCK_BYTES)
    {
      case 0U: expected = value; break;
      case 1U: expected = (uint8_t)((offset & ~(XE_NP_SD_BENCH_BLOCK_BYTES - 1U)) >> 9U); break;
      case 2U: expected = (uint8_t)((offset & ~(XE_NP_SD_BENCH_BLOCK_BYTES - 1U)) >> 17U); break;
      case 3U: expected = (uint8_t)~value; break;
      default: break;
    }
    if (buffer[offset] != expected)
    {
      return -1;
    }
  }
  return 0;
}

/*
 * Prove that the ULA linked-list descriptors can be changed while an SDMMC
 * CMD25 is active.  The first two nodes point at A/B; immediately after each
 * completion its descriptor is changed to a different C/D source.  A single
 * CMD23-bounded transfer then writes A, B, C, D.  Reading all four portions
 * back prevents a silent circular A, B, A, B replay from being mistaken for a
 * successful recorder transfer.
 */
static int XE_NP_Board_RunSdBenchRetargetIntegrity(void)
{
  static const uint8_t patterns[4] = {0x19U, 0x4EU, 0xB3U, 0xD7U};
  const uint32_t node_bytes = XE_NP_SD_BENCH_LL_NODE_BYTES;
  const uint32_t node_blocks = XE_NP_SD_BENCH_LL_NODE_BLOCKS;
  const uint32_t total_blocks = XE_NP_SD_BENCH_RETARGET_TOTAL_BLOCKS;
  const uint32_t error_flags = SDMMC_FLAG_DCRCFAIL | SDMMC_FLAG_DTIMEOUT |
                               SDMMC_FLAG_TXUNDERR | SDMMC_FLAG_IDMATE;
  uint32_t start_tick;
  uint32_t data_end_seen = 0U;

  if ((XE_NP_SD_BENCH_LL_NODE_COUNT != 2U) ||
      ((node_bytes * XE_NP_SD_BENCH_LL_NODE_COUNT) > sizeof(xe_np_sd_bench_buf)) ||
      ((node_bytes * XE_NP_SD_BENCH_LL_NODE_COUNT) > sizeof(xe_np_sd_bench_retarget_buf)))
  {
    return -1;
  }

  xe_np_sd_bench_diag.retarget_test_enabled = 1U;
  xe_np_sd_bench_diag.retarget_rearm_count = 0U;
  xe_np_sd_bench_diag.retarget_verified_segments = 0U;
  xe_np_sd_bench_diag.retarget_verify_fail = 0U;

  XE_NP_Board_SdBenchFillPattern(&xe_np_sd_bench_buf[0U], node_bytes, patterns[0]);
  XE_NP_Board_SdBenchFillPattern(&xe_np_sd_bench_buf[node_bytes], node_bytes, patterns[1]);
  XE_NP_Board_SdBenchFillPattern(&xe_np_sd_bench_retarget_buf[0U], node_bytes, patterns[2]);
  XE_NP_Board_SdBenchFillPattern(&xe_np_sd_bench_retarget_buf[node_bytes], node_bytes, patterns[3]);
  XE_NP_Board_SdBench_DCacheClean(xe_np_sd_bench_buf, node_bytes * XE_NP_SD_BENCH_LL_NODE_COUNT);
  XE_NP_Board_SdBench_DCacheClean(xe_np_sd_bench_retarget_buf,
                                  node_bytes * XE_NP_SD_BENCH_LL_NODE_COUNT);

  xe_np_sd_bench_diag.ll_acmd23_error = XE_NP_Board_SdBenchPreErase(total_blocks);
  if (xe_np_sd_bench_diag.ll_acmd23_error != HAL_SD_ERROR_NONE)
  {
    return -1;
  }
  xe_np_sd_bench_diag.ll_cmd23_error = SDMMC_CmdBlockCount(hsd1.Instance, total_blocks);
  if (xe_np_sd_bench_diag.ll_cmd23_error != HAL_SD_ERROR_NONE)
  {
    return -1;
  }

  __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_STATIC_FLAGS);
  hsd1.ErrorCode = HAL_SD_ERROR_NONE;
  start_tick = HAL_GetTick();
  if (XE_NP_Board_StartSdBenchLinkedListNoCmd12(XE_NP_SD_BENCH_START_BLOCK,
                                                total_blocks) != HAL_OK)
  {
    return -1;
  }

  while ((HAL_GetTick() - start_tick) < XE_NP_SD_BENCH_TOTAL_TIMEOUT_MS)
  {
    uint32_t flags = hsd1.Instance->STA;

    if ((flags & error_flags) != 0U)
    {
      XE_NP_Board_RecordSdBenchDataError(flags);
      XE_NP_Board_FinishSdBenchNoCmd12();
      return -1;
    }
    if ((flags & SDMMC_FLAG_IDMABTC) != 0U)
    {
      uint32_t rearm_index = xe_np_sd_bench_diag.retarget_rearm_count;

      __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_FLAG_IDMABTC);
      xe_np_sd_bench_diag.ll_node_irq_count++;
      if (rearm_index < XE_NP_SD_BENCH_LL_NODE_COUNT)
      {
        xe_np_sd_bench_ll_nodes[rearm_index].IDMABASER =
          (uint32_t)&xe_np_sd_bench_retarget_buf[rearm_index * node_bytes];
        xe_np_sd_bench_ll_nodes[rearm_index].IDMABSIZE = node_bytes;
        XE_NP_Board_SdBench_DCacheClean(&xe_np_sd_bench_ll_nodes[rearm_index],
                                        (uint32_t)sizeof(xe_np_sd_bench_ll_nodes[rearm_index]));
        xe_np_sd_bench_diag.retarget_rearm_count = rearm_index + 1U;
      }
    }
    if (((flags & SDMMC_FLAG_DATAEND) != 0U) && (data_end_seen == 0U))
    {
      __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_FLAG_DATAEND);
      XE_NP_Board_FinishSdBenchNoCmd12();
      data_end_seen = 1U;
    }
    if ((data_end_seen != 0U) && (HAL_SD_GetCardState(&hsd1) == HAL_SD_CARD_TRANSFER))
    {
      break;
    }
  }

  if ((data_end_seen == 0U) ||
      (xe_np_sd_bench_diag.retarget_rearm_count != XE_NP_SD_BENCH_LL_NODE_COUNT))
  {
    XE_NP_Board_FinishSdBenchNoCmd12();
    return -1;
  }

  for (uint32_t segment = 0U; segment < 4U; ++segment)
  {
    if (HAL_SD_ReadBlocks(&hsd1, xe_np_sd_bench_buf,
                          XE_NP_SD_BENCH_START_BLOCK + (segment * node_blocks),
                          node_blocks, XE_NP_SD_BENCH_TOTAL_TIMEOUT_MS) != HAL_OK)
    {
      xe_np_sd_bench_diag.retarget_verify_fail = segment + 1U;
      return -1;
    }
    XE_NP_Board_SdBench_DCacheInvalidate(xe_np_sd_bench_buf, node_bytes);
    if (XE_NP_Board_SdBenchVerifyPattern(xe_np_sd_bench_buf, node_bytes, patterns[segment]) != 0)
    {
      xe_np_sd_bench_diag.retarget_verify_fail = segment + 1U;
      return -1;
    }
    xe_np_sd_bench_diag.retarget_verified_segments++;
  }

  xe_np_sd_bench_diag.blocks_written = total_blocks;
  xe_np_sd_bench_diag.bytes_written = (uint64_t)total_blocks * XE_NP_SD_BENCH_BLOCK_BYTES;
  xe_np_sd_bench_diag.elapsed_ms = HAL_GetTick() - start_tick;
  if (xe_np_sd_bench_diag.elapsed_ms == 0U)
  {
    xe_np_sd_bench_diag.elapsed_ms = 1U;
  }
  xe_np_sd_bench_diag.bytes_per_sec =
    (uint32_t)((xe_np_sd_bench_diag.bytes_written * 1000ULL) / xe_np_sd_bench_diag.elapsed_ms);
  return 0;
}
#endif
#endif

void HAL_SDEx_Write_DMALnkLstBufCpltCallback(SD_HandleTypeDef *hsd)
{
#if (XE_NP_SD_BENCH_ENABLE != 0U)
  uint32_t now_tick;
  uint32_t node_us;
#endif

  if (hsd != &hsd1)
  {
    return;
  }

#if (XE_NP_SD_BENCH_ENABLE != 0U)
  now_tick = HAL_GetTick();
  if (xe_np_sd_bench_ll_last_node_tick != 0U)
  {
    node_us = (now_tick - xe_np_sd_bench_ll_last_node_tick) * 1000UL;
    xe_np_sd_bench_diag.last_chunk_us = node_us;
    if (node_us > xe_np_sd_bench_diag.worst_chunk_us)
    {
      xe_np_sd_bench_diag.worst_chunk_us = node_us;
    }
  }
  xe_np_sd_bench_ll_last_node_tick = now_tick;
  xe_np_sd_bench_diag.ll_node_irq_count++;
#endif
  /* In the recorder image this callback is deliberately only a counter
   * hand-off.  Benchmark timestamping and cache-dirty diagnostic writes are
   * compiled out so SDMMC BTC cannot add avoidable CPU/bus traffic near GPIO
   * capture deadlines. */
#if !XE_NP_V2_MEDIA_ENABLE && !XE_NP_NP2_LIVE_SD_ENABLE && !XE_NP_SD_IDENTIFY_ONLY_DIAG && !XE_NP_SD_BASIC_TEAMGROUP_UHS && !XE_NP_NP2_PSSI_TEST_DIAG_ENABLE
  XE_NP_App_SdLinkedListNodeComplete(hsd);
#endif
}

static void XE_NP_Board_SdBench_DCacheInvalidate(void *addr, uint32_t size_bytes)
{
#if defined(__DCACHE_PRESENT) && (__DCACHE_PRESENT == 1U)
  uintptr_t start_addr;
  uintptr_t end_addr;

  if ((addr == NULL) || (size_bytes == 0U))
  {
    return;
  }

  start_addr = ((uintptr_t)addr) & ~((uintptr_t)31U);
  end_addr = (((uintptr_t)addr) + (uintptr_t)size_bytes + 31U) & ~((uintptr_t)31U);
  SCB_InvalidateDCache_by_Addr((void *)start_addr, (int32_t)(end_addr - start_addr));
#else
  (void)addr;
  (void)size_bytes;
#endif
}

static void XE_NP_Board_RunSdWriteBench(void)
{
#if (XE_NP_SD_BENCH_ENABLE != 0U)
  XE_NP_Board_RecordStartupProgressMarker(XE_NP_STARTUP_MARK_BENCH_ENTRY);
  xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_RUNNING;
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_FUNCTION_ENTER;
  XE_NP_Board_UpdateSdBenchLiveDiag();
  uint32_t start_tick;
  uint32_t chunk_start_tick;
  uint32_t now_tick;
  uint32_t block;
  uint32_t remaining_blocks;
  uint32_t chunk_blocks;

  memset((void *)xe_np_sd_bench_buf, 0xA5, sizeof(xe_np_sd_bench_buf));
  for (uint32_t i = 0U; i < sizeof(xe_np_sd_bench_buf); i += 512U)
  {
    xe_np_sd_bench_buf[i + 0U] = (uint8_t)(i >> 9U);
    xe_np_sd_bench_buf[i + 1U] = (uint8_t)(i >> 17U);
    xe_np_sd_bench_buf[i + 2U] = 0x5AU;
    xe_np_sd_bench_buf[i + 3U] = 0xC3U;
  }
  XE_NP_Board_SdBench_DCacheClean(xe_np_sd_bench_buf, (uint32_t)sizeof(xe_np_sd_bench_buf));

  xe_np_sd_bench_diag.magic = XE_NP_SD_BENCH_MAGIC;
  xe_np_sd_bench_diag.version = XE_NP_SD_BENCH_VERSION;
  xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_RUNNING;
  XE_NP_Board_UpdateSdBenchLiveDiag();
  xe_np_sd_bench_diag.start_block = XE_NP_SD_BENCH_START_BLOCK;
  xe_np_sd_bench_diag.total_blocks = XE_NP_SD_BENCH_TOTAL_BLOCKS;
  xe_np_sd_bench_diag.chunk_blocks =
#if (XE_NP_SD_BENCH_USE_IDMA_LINKED_LIST != 0U)
    XE_NP_SD_BENCH_LL_TRANSFER_BLOCKS;
#else
    XE_NP_SD_BENCH_CHUNK_BLOCKS;
#endif
  xe_np_sd_bench_diag.blocks_written = 0U;
  xe_np_sd_bench_diag.elapsed_ms = 0U;
  xe_np_sd_bench_diag.bytes_per_sec = 0U;
  xe_np_sd_bench_diag.worst_chunk_us = 0U;
  xe_np_sd_bench_diag.last_chunk_us = 0U;
  xe_np_sd_bench_diag.fail_block = 0U;
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_FUNCTION_ENTER;
  xe_np_sd_bench_diag.method =
#if (XE_NP_SD_BENCH_USE_IDMA_LINKED_LIST != 0U)
    XE_NP_SD_BENCH_METHOD_IDMA_LINKED_LIST;
#else
    XE_NP_SD_BENCH_METHOD_CHUNK_DMA;
#endif
  xe_np_sd_bench_diag.ll_node_blocks = XE_NP_SD_BENCH_LL_NODE_BLOCKS;
  xe_np_sd_bench_diag.ll_node_bytes = XE_NP_SD_BENCH_LL_NODE_BYTES;
  xe_np_sd_bench_diag.ll_node_count = XE_NP_SD_BENCH_LL_NODE_COUNT;
  xe_np_sd_bench_diag.ll_node_irq_count = 0U;
  xe_np_sd_bench_diag.ll_build_status = 0U;
  xe_np_sd_bench_diag.ll_cmd23_error = HAL_SD_ERROR_NONE;
  xe_np_sd_bench_diag.ll_acmd23_error = HAL_SD_ERROR_NONE;
  xe_np_sd_bench_diag.prep_flags = 0U;
  xe_np_sd_bench_diag.cmd20_error = HAL_SD_ERROR_NONE;
  xe_np_sd_bench_diag.sd_status_speed_class = 0U;
  xe_np_sd_bench_diag.sd_status_perf_move = 0U;
  xe_np_sd_bench_diag.sd_status_au_size = 0U;
  xe_np_sd_bench_diag.sd_status_erase_size = 0U;
  xe_np_sd_bench_diag.sd_status_uhs_grade = 0U;
  xe_np_sd_bench_diag.sd_status_uhs_au_size = 0U;
  xe_np_sd_bench_diag.sd_status_video_class = 0U;
  xe_np_sd_bench_diag.sdmmc_bus_hz = 0U;
  xe_np_sd_bench_diag.sdmmc_clkcr = 0U;
  xe_np_sd_bench_diag.dlyb_cr = 0U;
  xe_np_sd_bench_diag.dlyb_cfgr = 0U;
  xe_np_sd_bench_diag.last_speed_mode_clock_div = 0U;
  xe_np_sd_bench_diag.last_speed_mode_clock_edge = 0U;
  xe_np_sd_bench_diag.last_speed_mode_selclkrx = 0U;
  xe_np_sd_bench_diag.last_speed_mode_sdmmc_clock_source = 0U;
  xe_np_sd_bench_diag.last_speed_mode_iclk_clock_source = 0U;
  xe_np_sd_bench_diag.last_speed_mode_sdmmc_kernel_hz = 0U;
  xe_np_sd_bench_diag.last_speed_mode_sdmmc_bus_hz = 0U;
  xe_np_sd_bench_diag.last_speed_mode_sdmmc_target_bus_hz = 0U;
  xe_np_sd_bench_diag.gpio_hslv_enabled = 0U;
  xe_np_sd_bench_diag.gpio_c_hslvr = 0U;
  xe_np_sd_bench_diag.gpio_d_hslvr = 0U;
  xe_np_sd_bench_diag.gpio_b_hslvr = 0U;
  xe_np_sd_bench_diag.range_erase_ms = 0U;
  xe_np_sd_bench_diag.ll_build_ms = 0U;
  xe_np_sd_bench_diag.cmd20_ms = 0U;
  xe_np_sd_bench_diag.chunk_count = 0U;
  xe_np_sd_bench_diag.last_setup_ms = 0U;
  xe_np_sd_bench_diag.worst_setup_ms = 0U;
  xe_np_sd_bench_diag.total_setup_ms = 0U;
  xe_np_sd_bench_diag.last_transfer_ms = 0U;
  xe_np_sd_bench_diag.worst_transfer_ms = 0U;
  xe_np_sd_bench_diag.total_transfer_ms = 0U;
  xe_np_sd_bench_diag.last_busy_ms = 0U;
  xe_np_sd_bench_diag.worst_busy_ms = 0U;
  xe_np_sd_bench_diag.total_busy_ms = 0U;
  xe_np_sd_bench_diag.dataend_count = 0U;
  xe_np_sd_bench_diag.cmd13_poll_count = 0U;
  xe_np_sd_bench_diag.wait_loop_count = 0U;
#if (XE_NP_SD_BENCH_USE_CMD23_BLOCK_COUNT != 0U)
  xe_np_sd_bench_diag.prep_flags |= XE_NP_SD_BENCH_PREP_FLAG_CMD23;
#endif
#if (XE_NP_SD_BENCH_USE_ACMD23_PRE_ERASE != 0U)
  xe_np_sd_bench_diag.prep_flags |= XE_NP_SD_BENCH_PREP_FLAG_ACMD23;
#endif
#if (XE_NP_SD_BENCH_DISABLE_IDMABTC_IRQ != 0U)
  xe_np_sd_bench_diag.prep_flags |= XE_NP_SD_BENCH_PREP_FLAG_NO_IDMABTC_IRQ;
#endif
#if ((XE_NP_SD_BENCH_USE_CMD23_BLOCK_COUNT != 0U) && (XE_NP_SD_BENCH_USE_CMD23_NO_CMD12 != 0U))
  xe_np_sd_bench_diag.prep_flags |= XE_NP_SD_BENCH_PREP_FLAG_NO_CMD12;
#endif
#if (XE_NP_SD_BENCH_USE_RANGE_ERASE != 0U)
  xe_np_sd_bench_diag.prep_flags |= XE_NP_SD_BENCH_PREP_FLAG_RANGE_ERASE;
#endif
#if (XE_NP_SD_BENCH_USE_CMD20_START_RECORDING != 0U)
  xe_np_sd_bench_diag.prep_flags |= XE_NP_SD_BENCH_PREP_FLAG_CMD20_START_RECORDING;
#endif
  if (xe_np_sd_signal_1v8_enabled != 0U)
  {
    xe_np_sd_bench_diag.prep_flags |= XE_NP_SD_BENCH_PREP_FLAG_HSLV;
  }
  xe_np_sd_bench_ll_last_node_tick = 0U;
  xe_np_sd_bench_diag.bytes_written = 0ULL;
  XE_NP_Board_UpdateSdBenchLiveDiag();

  if ((xe_np_sd_init_failed != 0U) ||
      (hsd1.SdCard.LogBlockNbr <= (XE_NP_SD_BENCH_START_BLOCK + XE_NP_SD_BENCH_TOTAL_BLOCKS)))
  {
    xe_np_sd_bench_diag.fail_status = (xe_np_sd_init_failed != 0U) ?
      XE_NP_SD_BENCH_STATUS_CARD_ERROR :
      XE_NP_SD_BENCH_STATUS_SKIPPED;
    xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_SKIPPED;
    XE_NP_Board_UpdateSdBenchLiveDiag();
    return;
  }

  HAL_NVIC_SetPriority(SDMMC1_IRQn, 1U, 0U);
  HAL_NVIC_EnableIRQ(SDMMC1_IRQn);

  if (XE_NP_Board_WaitSdBenchChunkDone(1000U) != 0)
  {
    xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_CARD_ERROR;
    XE_NP_Board_UpdateSdBenchLiveDiag();
    return;
  }

  __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_STATIC_FLAGS);
  hsd1.ErrorCode = HAL_SD_ERROR_NONE;
  XE_NP_Board_ReadSdBenchCardStatus();

#if (XE_NP_SD_BENCH_USE_RANGE_ERASE != 0U)
  now_tick = HAL_GetTick();
  if (XE_NP_Board_PreEraseSdBenchRange() != 0)
  {
    xe_np_sd_bench_diag.status = xe_np_sd_bench_diag.fail_status;
    xe_np_sd_bench_diag.fail_block = XE_NP_SD_BENCH_START_BLOCK;
    XE_NP_Board_UpdateSdBenchLiveDiag();
    return;
  }
  xe_np_sd_bench_diag.range_erase_ms = HAL_GetTick() - now_tick;
  __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_STATIC_FLAGS);
  hsd1.ErrorCode = HAL_SD_ERROR_NONE;
#endif

#if (XE_NP_SD_BENCH_USE_IDMA_LINKED_LIST != 0U)
  now_tick = HAL_GetTick();
  if (XE_NP_Board_BuildSdBenchLinkedList() != HAL_OK)
  {
    xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_LL_BUILD_FAIL;
    xe_np_sd_bench_diag.ll_build_status = (uint32_t)HAL_ERROR;
    XE_NP_Board_UpdateSdBenchLiveDiag();
    return;
  }

  xe_np_sd_bench_diag.ll_build_ms = HAL_GetTick() - now_tick;
  xe_np_sd_bench_diag.ll_build_status = (uint32_t)HAL_OK;
#if (XE_NP_SD_BENCH_USE_CMD20_START_RECORDING != 0U)
  now_tick = HAL_GetTick();
  xe_np_sd_bench_diag.cmd20_error =
    XE_NP_Board_SdBenchSpeedClassControl(XE_NP_SD_BENCH_CMD20_SCC_START_RECORDING);
  xe_np_sd_bench_diag.cmd20_ms = HAL_GetTick() - now_tick;
  if (xe_np_sd_bench_diag.cmd20_error != HAL_SD_ERROR_NONE)
  {
    xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_HAL_START_FAIL;
    xe_np_sd_bench_diag.fail_block = XE_NP_SD_BENCH_START_BLOCK;
    xe_np_sd_bench_diag.fail_status = xe_np_sd_bench_diag.cmd20_error;
    XE_NP_Board_UpdateSdBenchLiveDiag();
    return;
  }
#endif
#if (XE_NP_SD_BENCH_RETARGET_INTEGRITY_TEST != 0U)
  /* This is deliberately a single CMD25 test rather than a throughput loop:
   * its purpose is to qualify the exact descriptor-retarget mechanism used by
   * the 30 kHz raw sink before an active probe is involved. */
  if (XE_NP_Board_RunSdBenchRetargetIntegrity() != 0)
  {
    xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_INTEGRITY_FAIL;
    xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_STATUS_INTEGRITY_FAIL;
    XE_NP_Board_UpdateSdBenchLiveDiag();
    return;
  }
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_STATUS_OK;
  xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_OK;
  XE_NP_Board_UpdateSdBenchLiveDiag();
  return;
#endif
  block = XE_NP_SD_BENCH_START_BLOCK;
  remaining_blocks = XE_NP_SD_BENCH_TOTAL_BLOCKS;
  start_tick = HAL_GetTick();
  while (remaining_blocks != 0U)
  {
    chunk_start_tick = HAL_GetTick();
    chunk_blocks = (remaining_blocks > XE_NP_SD_BENCH_LL_TRANSFER_BLOCKS) ?
      XE_NP_SD_BENCH_LL_TRANSFER_BLOCKS :
      remaining_blocks;
#if (XE_NP_SD_BENCH_USE_ACMD23_PRE_ERASE != 0U)
    xe_np_sd_bench_diag.ll_acmd23_error = XE_NP_Board_SdBenchPreErase(chunk_blocks);
    if (xe_np_sd_bench_diag.ll_acmd23_error != HAL_SD_ERROR_NONE)
    {
      xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_HAL_START_FAIL;
      xe_np_sd_bench_diag.fail_block = block;
      xe_np_sd_bench_diag.fail_status = xe_np_sd_bench_diag.ll_acmd23_error;
      XE_NP_Board_UpdateSdBenchLiveDiag();
      return;
    }
#endif
#if (XE_NP_SD_BENCH_USE_CMD23_BLOCK_COUNT != 0U)
    xe_np_sd_bench_diag.ll_cmd23_error = SDMMC_CmdBlockCount(hsd1.Instance, chunk_blocks);
    if (xe_np_sd_bench_diag.ll_cmd23_error != HAL_SD_ERROR_NONE)
    {
      xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_HAL_START_FAIL;
      xe_np_sd_bench_diag.fail_block = block;
      xe_np_sd_bench_diag.fail_status = xe_np_sd_bench_diag.ll_cmd23_error;
      XE_NP_Board_UpdateSdBenchLiveDiag();
      return;
    }
#endif

    __HAL_SD_CLEAR_FLAG(&hsd1, SDMMC_STATIC_FLAGS);
    hsd1.ErrorCode = HAL_SD_ERROR_NONE;
#if ((XE_NP_SD_BENCH_USE_CMD23_BLOCK_COUNT != 0U) && (XE_NP_SD_BENCH_USE_CMD23_NO_CMD12 != 0U))
    if (XE_NP_Board_StartSdBenchLinkedListNoCmd12(block, chunk_blocks) != HAL_OK)
#else
    if (HAL_SDEx_DMALinkedList_WriteBlocks(&hsd1,
                                           &xe_np_sd_bench_ll,
                                           block,
                                           chunk_blocks) != HAL_OK)
#endif
    {
      xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_HAL_START_FAIL;
      xe_np_sd_bench_diag.fail_block = block;
      xe_np_sd_bench_diag.fail_status = (uint32_t)HAL_ERROR;
      XE_NP_Board_UpdateSdBenchLiveDiag();
      return;
    }
    XE_NP_Board_RecordSdBenchSetupMs(HAL_GetTick() - chunk_start_tick);
#if (XE_NP_SD_BENCH_DISABLE_IDMABTC_IRQ != 0U)
    __HAL_SD_DISABLE_IT(&hsd1, SDMMC_IT_IDMABTC);
#endif

#if ((XE_NP_SD_BENCH_USE_CMD23_BLOCK_COUNT != 0U) && (XE_NP_SD_BENCH_USE_CMD23_NO_CMD12 != 0U))
    if (XE_NP_Board_WaitSdBenchNoCmd12Done(XE_NP_SD_BENCH_TOTAL_TIMEOUT_MS) != 0)
#else
    if (XE_NP_Board_WaitSdBenchChunkDone(XE_NP_SD_BENCH_TOTAL_TIMEOUT_MS) != 0)
#endif
    {
      xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_STATUS_TIMEOUT;
      xe_np_sd_bench_diag.status = xe_np_sd_bench_diag.fail_status;
      xe_np_sd_bench_diag.fail_block = block;
      XE_NP_Board_UpdateSdBenchLiveDiag();
      return;
    }

    block += chunk_blocks;
    remaining_blocks -= chunk_blocks;
    xe_np_sd_bench_diag.blocks_written += chunk_blocks;
    xe_np_sd_bench_diag.chunk_count++;
    xe_np_sd_bench_diag.bytes_written =
      (uint64_t)xe_np_sd_bench_diag.blocks_written * (uint64_t)XE_NP_SD_BENCH_BLOCK_BYTES;
  }

  xe_np_sd_bench_diag.bytes_written =
    (uint64_t)xe_np_sd_bench_diag.blocks_written * (uint64_t)XE_NP_SD_BENCH_BLOCK_BYTES;
  xe_np_sd_bench_diag.elapsed_ms = HAL_GetTick() - start_tick;
  if (xe_np_sd_bench_diag.elapsed_ms == 0U)
  {
    xe_np_sd_bench_diag.elapsed_ms = 1U;
  }
  xe_np_sd_bench_diag.bytes_per_sec =
    (uint32_t)((xe_np_sd_bench_diag.bytes_written * 1000ULL) /
               (uint64_t)xe_np_sd_bench_diag.elapsed_ms);
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_STATUS_OK;
  xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_OK;
  XE_NP_Board_UpdateSdBenchLiveDiag();
#else
  block = XE_NP_SD_BENCH_START_BLOCK;
  remaining_blocks = XE_NP_SD_BENCH_TOTAL_BLOCKS;
  start_tick = HAL_GetTick();

  while (remaining_blocks != 0U)
  {
    chunk_blocks = (remaining_blocks > XE_NP_SD_BENCH_CHUNK_BLOCKS) ?
      XE_NP_SD_BENCH_CHUNK_BLOCKS :
      remaining_blocks;

    chunk_start_tick = HAL_GetTick();
    if (HAL_SD_WriteBlocks_DMA(&hsd1, xe_np_sd_bench_buf, block, chunk_blocks) != HAL_OK)
    {
      xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_HAL_START_FAIL;
      xe_np_sd_bench_diag.fail_block = block;
      xe_np_sd_bench_diag.fail_status = (uint32_t)HAL_ERROR;
      XE_NP_Board_UpdateSdBenchLiveDiag();
      return;
    }

    if (XE_NP_Board_WaitSdBenchChunkDone(XE_NP_SD_BENCH_CHUNK_TIMEOUT_MS) != 0)
    {
      xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_STATUS_TIMEOUT;
      xe_np_sd_bench_diag.status = xe_np_sd_bench_diag.fail_status;
      xe_np_sd_bench_diag.fail_block = block;
      XE_NP_Board_UpdateSdBenchLiveDiag();
      return;
    }

    now_tick = HAL_GetTick();
    xe_np_sd_bench_diag.last_chunk_us = (now_tick - chunk_start_tick) * 1000UL;
    if (xe_np_sd_bench_diag.last_chunk_us > xe_np_sd_bench_diag.worst_chunk_us)
    {
      xe_np_sd_bench_diag.worst_chunk_us = xe_np_sd_bench_diag.last_chunk_us;
    }

    block += chunk_blocks;
    remaining_blocks -= chunk_blocks;
    xe_np_sd_bench_diag.blocks_written += chunk_blocks;
    xe_np_sd_bench_diag.bytes_written =
      (uint64_t)xe_np_sd_bench_diag.blocks_written * (uint64_t)XE_NP_SD_BENCH_BLOCK_BYTES;
  }

  xe_np_sd_bench_diag.elapsed_ms = HAL_GetTick() - start_tick;
  if (xe_np_sd_bench_diag.elapsed_ms == 0U)
  {
    xe_np_sd_bench_diag.elapsed_ms = 1U;
  }
  xe_np_sd_bench_diag.bytes_per_sec =
    (uint32_t)((xe_np_sd_bench_diag.bytes_written * 1000ULL) /
               (uint64_t)xe_np_sd_bench_diag.elapsed_ms);
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_STATUS_OK;
  xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_OK;
  XE_NP_Board_UpdateSdBenchLiveDiag();
#endif
#else
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_DISABLED;
  xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_DISABLED;
  XE_NP_Board_UpdateSdBenchLiveDiag();
#endif
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
#if XE_NP_SD_IDENTIFY_ONLY_DIAG || XE_NP_SD_BASIC_TEAMGROUP_UHS || XE_NP_SD_TEAMGROUP_UHS_STARTUP_TEST
volatile struct {
  uint32_t magic,version,state,error,card_blocks,bus_hz,clkcr,power;
  uint32_t signal_1v8,current_ma,card_status_valid,transfer_state,reserved[4];
} xe_np_sd_identify_diag;
_Static_assert(sizeof(xe_np_sd_identify_diag)==64U,"SD identify-only diagnostic ABI");
#endif
#if defined(XE_NP_SD_BASIC_DIAG_ENABLE) && XE_NP_SD_BASIC_DIAG_ENABLE
#include "xe_np_sd_basic_diag.inc"
#endif
#if XE_NP_SD_TEAMGROUP_UHS_STARTUP_TEST
static int XE_NP_TeamGroupStartupSourcesIdle(void);
#endif
#include "xe_np_sd_cmd11_gpio_diag.inc"
#include "xe_np_sd_teamgroup_startup.inc"

/* SD_COLD_RETRY_BEGIN */
#if XE_NP_SD_COLD_RETRY_TEST
static int XE_NP_Board_InitialSdPowerRail(void)
{
  if(!XE_NP_Cmd11PinSourcesIdle() || !XE_NP_Cmd11SdHostInactive())return -1;
  XE_NP_Board_ResetSdPowerRail();
  return 0;
}

static void XE_NP_Board_RetryColdSdPowerOn(void)
{
  /* Only the first CMD8-qualified, not-ready ACMD41 timeout, before CID/CSD
   * or a recording owner exists. The unchanged HAL counter excludes another
   * retry even if this helper is called again after a failed second init. */
  if(!xe_np_sd_init_failed || hsd1.Instance!=SDMMC1 || hsd1.Context ||
     hsd1.ErrorCode!=HAL_SD_ERROR_TIMEOUT || hsd1.SdCard.LogBlockNbr ||
     (hsd1.CID[0]|hsd1.CID[1]|hsd1.CID[2]|hsd1.CID[3]| \
      hsd1.CSD[0]|hsd1.CSD[1]|hsd1.CSD[2]|hsd1.CSD[3]) ||
     xe_np_sd_init_diag.magic!=XE_NP_SD_INIT_MAGIC || xe_np_sd_init_diag.version!=1U ||
     xe_np_sd_init_diag.attempts!=1U || xe_np_sd_init_diag.stage!=XE_NP_SD_INIT_ACMD41 ||
     xe_np_sd_init_diag.error!=HAL_SD_ERROR_TIMEOUT || xe_np_sd_init_diag.cmd8_error ||
     (xe_np_sd_init_diag.cmd8_response&0xfffU)!=SDMMC_CHECK_PATTERN ||
     (xe_np_sd_init_diag.ocr&0x80000000U) ||
     !XE_NP_Cmd11PinSourcesIdle() || !XE_NP_Cmd11SdHostInactive())return;
  /* A real cold host reset/re-identification, not clearing a live error.
   * Preserve successful CMD11 via the existing post-init path. No loop. */
  if(XE_NP_Board_ResetSdHostBase()==HAL_OK)XE_NP_Board_PostInitSdTuning();
}
#else
#define XE_NP_Board_InitialSdPowerRail() (XE_NP_Board_ResetSdPowerRail(),0)
#define XE_NP_Board_RetryColdSdPowerOn() ((void)0)
#endif
/* SD_COLD_RETRY_END */

#if XE_NP_SD_IDENTIFY_ONLY_DIAG
_Static_assert(XE_NP_IMAGE_ROLE==XE_NP_IMAGE_SD_APP && XE_NP_BOARD_HSE_ONLY_CLOCKS &&
               HSE_VALUE==24000000UL && XE_NP_BOARD_SYSCLK_HZ==128000000UL &&
               (XE_NP_SD_CMD11_TRACE_ONLY_DIAG ?
                 (XE_NP_BOARD_SD_PLL2Q_HZ==108000000UL && XE_NP_BOARD_SD_RX_CLOCK_TEST==2U && XE_NP_SD_ALLOW_S18R) :
                 (XE_NP_BOARD_SD_PLL2Q_HZ==100000000UL && XE_NP_BOARD_SD_RX_CLOCK_TEST==1U && !XE_NP_SD_ALLOW_S18R)) &&
               XE_NP_SD_XPC_ENABLE &&
               XE_NP_SD_POWER_RAIL_OFF_MS==3000U && XE_NP_SD_PAD_HSLV_DISABLE &&
               XE_NP_SD_CARD_MAX_CURRENT_MA==200U && XE_NP_SD_CARD_SUPPLY_BUDGET_MA==200U &&
               XE_NP_BOARD_SD_GPIO_SPEED==GPIO_SPEED_FREQ_VERY_HIGH &&
               XE_NP_BOARD_SD_CLK_GPIO_SPEED==GPIO_SPEED_FREQ_VERY_HIGH && !XE_NP_BOARD_SD_PULLUPS &&
               XE_NP_BOARD_DEFER_PROBE_MCO_START && !XE_NP_NP2_LIVE_SD_ENABLE &&
               !XE_NP_NP2_CAPTURE_PORT_ENABLE && !XE_NP_NP2_USB_SOURCE_ENABLE &&
               !XE_NP_USB_UNIFIED_ENABLE && !XE_NP_NP2_DUAL_SD_APP_ENABLE &&
               !XE_NP_SD_BASIC_DIAG_ENABLE && !XE_NP_SD_CMD0_ONLY_DIAG &&
               !XE_NP_SD_BASIC_RECOVER_1V8,
               "identify-only is the isolated fixed 3.3-V base or separately flagged native CMD11 evidence profile");
#endif
#if XE_NP_SD_IDENTIFY_ONLY_DIAG || XE_NP_SD_BASIC_TEAMGROUP_UHS
/* This isolated image omits the legacy application IRQ object. Preserve the
 * native HAL tick and SD handler; all unused vectors keep startup defaults. */
void SysTick_Handler(void) { HAL_IncTick(); }
void SDMMC1_IRQHandler(void) { HAL_SD_IRQHandler(&hsd1); }
#endif

int main(void)
{
  XE_NP_Board_RecordStartupProgressMarker(XE_NP_STARTUP_MARK_MAIN_ENTRY);
  xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_MAIN_ENTRY;
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_MAIN_REACHED;
  XE_NP_Board_UpdateSdBenchLiveDiag();
  xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_SKIPPED;
  XE_NP_Board_RecordStartupFaultRegs();
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_MAIN_REACHED;
  XE_NP_Board_UpdateSdBenchLiveDiag();


  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_BEFORE_HAL_INIT;
  HAL_Init();
#if XE_NP_USB_SD_TEST_ENABLE
  XE_NP_UsbSdTest_Boot(XE_NP_IMAGE_ROLE==XE_NP_IMAGE_SD_APP?1U:2U);
#endif
#if XE_NP_NP2_SD_BLE_ENABLE
  XE_NP_Np2SdBle_EarlyDfu();
#endif
#if XE_NP_USB_UNIFIED_ENABLE
  XE_NP_UsbUnified_SelectBootMode();
#elif (XE_NP_IMAGE_ROLE == XE_NP_IMAGE_USB_SERVICE)
  XE_NP_UsbMsc_SelectBootMode();
#endif
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_AFTER_HAL_INIT;

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the System Power */
  SystemPower_Config();
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_AFTER_POWER;

  /* Configure the system clock */
  SystemClock_Config();
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_AFTER_CLOCK;

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

#if ((XE_NP_PSRAM_MPU_NONCACHEABLE_EXPERIMENT != 0U) || \
     (XE_NP_CAPTURE_SRAM3_MPU_NONCACHEABLE != 0U) || \
     (XE_NP_USB_TX_MPU_NONCACHEABLE != 0U))
  MX_MPU_Init();
#endif

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
#if XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE && !XE_NP_NP2_READ_ONLY_DIAG_ENABLE && !XE_NP_NP2_PSSI_TEST_DIAG_ENABLE && !XE_NP_NP2_TRIPLE_SYNTHETIC_SD_ENABLE && !XE_NP_NP2_LIVE_SD_ENABLE && !XE_NP_USB_UNIFIED_ENABLE && !XE_NP_SD_IDENTIFY_ONLY_DIAG && !XE_NP_SD_BASIC_TEAMGROUP_UHS
  if(XE_NP_Np2AcquisitionPort_EarlyIdle()!=0) { Error_Handler(); }
#endif
#if XE_NP_USB_UNIFIED_ENABLE
  /* USB personalities never run legacy NP1 startup. Stream skips SD. */
  /* MX_GPIO_Init leaves the status LED low. The unified USB service bypasses
   * XE_NP_App_Init, so assert it here for the entire USB-mode session. */
  HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_SET);
  MX_DCACHE1_Init();
  MX_ICACHE_Init();
  XE_NP_UsbUnified_Prepare();
#if XE_NP_NP2_USB_SOURCE_ENABLE
  if(XE_NP_Np2UsbSource_Init()!=0)Error_Handler();
#endif
  MX_USB_OTG_HS_PCD_Init();
#if XE_NP_USB_TX_PREEMPHASIS == 3U
  HAL_SYSCFG_SetOTGPHYPreemphasisCurrent(SYSCFG_OTG_HS_PHY_PREEMP_3X);
#elif XE_NP_USB_TX_PREEMPHASIS == 2U
  HAL_SYSCFG_SetOTGPHYPreemphasisCurrent(SYSCFG_OTG_HS_PHY_PREEMP_2X);
#elif XE_NP_USB_TX_PREEMPHASIS == 0U
  HAL_SYSCFG_SetOTGPHYPreemphasisCurrent(SYSCFG_OTG_HS_PHY_PREEMP_DISABLED);
#else
  HAL_SYSCFG_SetOTGPHYPreemphasisCurrent(SYSCFG_OTG_HS_PHY_PREEMP_1X);
#endif
  XE_NP_UsbStream_Init(&hpcd_USB_OTG_HS);
  HAL_NVIC_SetPriority(OTG_HS_IRQn,XE_NP_BOARD_USB_OTG_HS_IRQ_PREEMPT_PRIO,0);
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
  MX_I2C5_Init();
#if XE_NP_BOARD_BME280_I2C_WIRING_CONFIRMED
  MX_I2C6_Init();
  XE_NP_SensorsPort_Init(&hi2c5,&hi2c6);
#else
  XE_NP_SensorsPort_Init(&hi2c5,NULL);
#endif
  uint32_t sensor_service_ms=HAL_GetTick();
#endif
  while(1) {
    XE_NP_UsbStream_Service();
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
    /* Auxiliary IT work follows transport/capture work, at most once per ms. */
    uint32_t sensor_now=HAL_GetTick();
    if(sensor_now!=sensor_service_ms){
      sensor_service_ms=sensor_now;
      uint8_t recording=0U;
#if XE_NP_NP2_USB_SOURCE_ENABLE
      recording=(uint8_t)(XE_NP_Np2UsbSource_IsBusy() || XE_NP_Np2CapturePort_Armed());
#endif
      recording|=(uint8_t)XE_NP_UsbAux_IsRunning();
      XE_NP_SensorsPort_Service(recording);
    }
#endif
  }
#elif XE_NP_V2_MEDIA_ENABLE
  /* Isolated media role: no legacy NP/timer/ADC owners or USB stream. */
  HAL_GPIO_WritePin(LED_GPIO_Port,LED_Pin,GPIO_PIN_SET);
  XE_NP_Board_ResetSdPowerRail();
  MX_DCACHE1_Init();MX_ICACHE_Init();
  MX_SDMMC1_SD_Init();
  HAL_PWREx_EnableVddA();
  MX_ADC1_Init();
  hspi1.Instance=SPI1; /* Prepare owns reset-state SPI1 and its camera MSP. */
  (void)XE_NP_MediaApp_Init(xe_np_sd_init_failed?NULL:&hsd1,&hadc1,&hspi1);
  XE_NP_MediaBle_Init();
  for(;;) {
    XE_NP_MediaApp_Service();
    XE_NP_MediaBle_Service();
  }
#elif XE_NP_SD_IDENTIFY_ONLY_DIAG
  /* One native identification: 3.3 V by default; the separate CMD11 trace mode
   * uses only native voltage admission. No speed tuning, sector I/O or recovery. */
  HAL_SD_CardStatusTypeDef card_status;
  HAL_StatusTypeDef init_status;
  xe_np_sd_identify_diag.magic=0x53444944U;xe_np_sd_identify_diag.version=1U;
  xe_np_sd_identify_diag.state=1U;
  xe_np_sd_identify_diag.current_ma=XE_NP_SD_CARD_MAX_CURRENT_MA;
  XE_NP_Board_ResetSdPowerRail();
  MX_DCACHE1_Init();MX_ICACHE_Init();
  init_status=XE_NP_Board_InitSdHostBase();
#if XE_NP_SD_CMD11_GPIO_DMA_DIAG
  XE_NP_SdCmd11GpioFinish();
#endif
  if(init_status==HAL_OK) {
    xe_np_sd_identify_diag.card_status_valid=(HAL_SD_GetCardStatus(&hsd1,&card_status)==HAL_OK);
    if(xe_np_sd_identify_diag.card_status_valid)
      xe_np_sd_identify_diag.transfer_state=(uint32_t)HAL_SD_GetCardState(&hsd1);
  }
  /* Preserve the actual session and native error before any host quiesce. */
  xe_np_sd_identify_diag.error=hsd1.ErrorCode;
  xe_np_sd_identify_diag.card_blocks=hsd1.SdCard.LogBlockNbr;
  xe_np_sd_identify_diag.bus_hz=XE_NP_Board_ComputeSdBusHz();
  xe_np_sd_identify_diag.clkcr=hsd1.Instance->CLKCR;
  xe_np_sd_identify_diag.power=hsd1.Instance->POWER;
  xe_np_sd_identify_diag.signal_1v8=xe_np_sd_signal_1v8_enabled;
  if(init_status==HAL_OK && !xe_np_sd_init_failed && !xe_np_sd_identify_diag.error &&
     xe_np_sd_identify_diag.card_status_valid &&
     xe_np_sd_identify_diag.transfer_state==HAL_SD_CARD_TRANSFER &&
     (hsd1.CID[0]|hsd1.CID[1]|hsd1.CID[2]|hsd1.CID[3])!=0U &&
     xe_np_sd_identify_diag.card_blocks!=0U && xe_np_sd_identify_diag.bus_hz!=0U &&
     xe_np_sd_identify_diag.bus_hz<=25000000U &&
     (XE_NP_SD_CMD11_TRACE_ONLY_DIAG ? xe_np_sd_identify_diag.signal_1v8==1U :
                                     !xe_np_sd_identify_diag.signal_1v8)) {
    __DMB();xe_np_sd_identify_diag.state=2U;
  } else {
    /* A validation failure is not permission to retry or touch media. Native
     * HAL/init errors remain unchanged in hsd1 and xe_np_sd_init_diag. */
    if(!xe_np_sd_identify_diag.error)xe_np_sd_identify_diag.error=HAL_SD_ERROR_UNSUPPORTED_FEATURE;
    __DMB();NVIC_DisableIRQ(SDMMC1_IRQn);
#if defined(DLYB_SDMMC1)
    LL_DLYB_Disable(DLYB_SDMMC1);
#endif
    __HAL_RCC_SDMMC1_FORCE_RESET();__HAL_RCC_SDMMC1_RELEASE_RESET();
    NVIC_ClearPendingIRQ(SDMMC1_IRQn);__DSB();
    xe_np_sd_identify_diag.state=255U;
  }
#if XE_NP_SD_MEDIA_READOUT_DIAG
  /* Test-only polling reads: no capture, writes or cached debugger mailbox. */
  {
    HAL_StatusTypeDef cache_status=HAL_DCACHE_Disable(&hdcache1);
    __DSB();__ISB();
    XE_NP_SdReadout_Init(&hsd1,xe_np_sd_identify_diag.state==2U &&
      cache_status==HAL_OK && HAL_DCACHE_IsEnabled(&hdcache1)==0U);
  }
#endif
  for(;;){
#if XE_NP_SD_MEDIA_READOUT_DIAG
    XE_NP_SdReadout_Service(&hsd1);
#endif
    __WFI();
  }
#elif defined(XE_NP_SD_BASIC_DIAG_ENABLE) && XE_NP_SD_BASIC_DIAG_ENABLE
  XE_NP_Board_ResetSdPowerRail();
  MX_DCACHE1_Init();
  MX_ICACHE_Init();
#if XE_NP_SD_BASIC_PSRAM_SOURCE || XE_NP_SD_BASIC_CONCURRENT_COPY || XE_NP_SD_BASIC_INIT_PSRAM_CONTROL
  /* Prove the SDMMC IDMA path can read the mapped PSRAM window directly.
   * For the concurrent SRAM-source variant, only GPDMA uses PSRAM. The
   * isolated PSRAM self-test touches its fixed diagnostic offsets; the
   * benchmark buffers start at +1 and +4 MiB. Initialize the same SD host base
   * used by the SRAM control first: its MSP sets shared HSE-derived PLL2Q. */
  if(XE_NP_Board_InitSdHostBase()!=HAL_OK) {
    xe_np_sd_basic_diag.magic=0x53444254U;
    xe_np_sd_basic_diag.version=1U;
    xe_np_sd_basic_diag.state=255U;
    xe_np_sd_basic_diag.error=hsd1.ErrorCode;
    xe_np_sd_basic_diag.stage=0x81U;
    for(;;)__WFI();
  }
  MX_OCTOSPI2_Init();
  if(XE_NP_Psram_RunBootSelfTest(&hospi2)!=0) {
    xe_np_sd_basic_diag.magic=0x53444254U;
    xe_np_sd_basic_diag.version=1U;
    xe_np_sd_basic_diag.state=255U;
    xe_np_sd_basic_diag.error=(uint32_t)(-XE_NP_Psram_GetDiag()->result);
    xe_np_sd_basic_diag.stage=0x80U;
    for(;;)__WFI();
  }
#endif
  XE_NP_SdBasic_Run();
  for (;;) __WFI();
#elif defined(XE_NP_SD_CMD0_ONLY_DIAG) && XE_NP_SD_CMD0_ONLY_DIAG
  /* Bounded 3.3 V CMD0 test. Never enter UHS or touch card data. */
  XE_NP_Board_ResetSdPowerRail();
  MX_DCACHE1_Init();
  MX_ICACHE_Init();
  MX_SDMMC1_SD_Init();
  for (;;) __WFI();
#elif XE_NP_NP2_SD_APP_ENABLE
  /* The NP2 recorder is deliberately lean: no legacy application, USB,
   * sensors or general-purpose DMA competes with the PSSI->SD data path. */
  XE_NP_Board_ResetSdPowerRail();
  MX_DCACHE1_Init();
  MX_ICACHE_Init();
  MX_SDMMC1_SD_Init();
  (void)XE_NP_Np2SingleSdApp_Init(&hsd1,&hdcache1);
  while (1)
  {
    XE_NP_Np2SingleSdApp_Service();
  }
#elif XE_NP_NP2_TRIPLE_SYNTHETIC_SD_ENABLE
  /* No probe-side peripheral is initialized in this image.  The dedicated
   * storage qualification owns only SDMMC/IDMA plus synthetic memory data. */
  XE_NP_Board_ResetSdPowerRail();
  MX_DCACHE1_Init();
  MX_ICACHE_Init();
  MX_SDMMC1_SD_Init();
  XE_NP_Np2TripleSyntheticSd_Init(&hsd1, &hdcache1);
  while (1)
  {
    XE_NP_Np2TripleSyntheticSd_Service();
  }
#elif XE_NP_NP2_DUAL_SD_APP_ENABLE
  /* Normal two-NP2 SD application. Boot is read-only; an explicit mailbox
   * FORMAT/START reserves the CE64 extent before PSSI or SD payload writes. */
  const int initial_sd_rail_ready=XE_NP_Board_InitialSdPowerRail()==0;
  MX_DCACHE1_Init();
  MX_ICACHE_Init();
#if XE_NP_SD_TEAMGROUP_UHS_STARTUP_TEST
  /* No source, media mutation, session retry or UART reclock before BLE init. */
  HAL_StatusTypeDef startup_status=initial_sd_rail_ready?XE_NP_TeamGroupStartup():HAL_ERROR;
  (void)XE_NP_Np2DualSdApp_Init(startup_status==HAL_OK ? &hsd1 : NULL,&hdcache1);
#else
  if(initial_sd_rail_ready) {
    MX_SDMMC1_SD_Init();
    XE_NP_Board_RetryColdSdPowerOn();
  }
  (void)XE_NP_Np2DualSdApp_Init(initial_sd_rail_ready ? &hsd1 : NULL,&hdcache1);
#endif
#if XE_NP_NP2_SD_BLE_ENABLE
  XE_NP_Np2SdBle_Init();
#endif
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
  MX_I2C5_Init();
#if XE_NP_BOARD_BME280_I2C_WIRING_CONFIRMED
  MX_I2C6_Init();
  XE_NP_SensorsPort_Init(&hi2c5,&hi2c6);
#else
  XE_NP_SensorsPort_Init(&hi2c5,NULL);
#endif
  uint32_t sensor_service_ms=HAL_GetTick();
#endif
#if XE_NP_USB_SD_TEST_ENABLE
  (void)XE_NP_Np2UsbSdTest_Start(&hsd1,&hdcache1);
#endif
  while (1)
  {
#if XE_NP_NP2_SD_BLE_ENABLE
    XE_NP_Np2SdBle_Service();
    if(XE_NP_Np2SdBle_CommandReady())XE_NP_Np2DualSdApp_Service();
#else
    XE_NP_Np2DualSdApp_Service();
#endif
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
    uint32_t sensor_now=HAL_GetTick();
    if(sensor_now!=sensor_service_ms){
      sensor_service_ms=sensor_now;
      uint32_t state=xe_np_np2_dual_sd_app_mailbox.state;
      uint8_t recording=(uint8_t)(
          xe_np_np2_dual_sd_app_mailbox.command==XE_NP_NP2_DUAL_SD_CMD_START ||
          state==XE_NP_NP2_DUAL_SD_ARMED || state==XE_NP_NP2_DUAL_SD_RECORDING ||
          state==XE_NP_NP2_DUAL_SD_FINALIZING);
      if(!recording){
        if(XE_NP_Np2CapturePort_Armed())recording=1U;
        else if(state==XE_NP_NP2_DUAL_SD_PREPARING){
          /* Stable clocks, no probe I2C/release or acquisition. Reuse only
           * the existing analog settle; no sensor gate or recording delay. */
          XE_NP_Np2UsbSourceStatus source_status;
          XE_NP_Np2UsbSource_GetStatus(&source_status);
          recording=(uint8_t)(source_status.state!=XE_NP_NP2_USB_SOURCE_SETTLING);
        }
      }
      XE_NP_SensorsPort_Service(recording);
    }
#endif
  }
#elif XE_NP_NP2_LIVE_SD_ENABLE
  /* Production-topology three-probe HIL image: PSSI8 plus SPI2-D8 feed an
   * eight-unit SD queue. USB and legacy services remain absent from the hot
   * path. The build selects an explicit bounded raw extent for validation. */
#if XE_NP_NP2_LIVE_SD_PSRAM_PROBE
  /* Isolated PSRAM trial owns PLL2Q and never initializes or accesses SD. */
  MX_DCACHE1_Init();
  MX_ICACHE_Init();
  MX_OCTOSPI2_Init();
  (void)XE_NP_Psram_RunBootSelfTest(&hospi2);
  for(;;)__WFI();
#else
  XE_NP_Board_ResetSdPowerRail();
  MX_DCACHE1_Init();
  MX_ICACHE_Init();
  MX_SDMMC1_SD_Init();
#if XE_NP_NP2_LIVE_SD_PSRAM_SPILL || XE_NP_NP2_STAGED_CAPTURE
  if(XE_NP_Board_SetNp2SampleRateHz(XE_NP_NP2_LIVE_SD_SAMPLE_HZ)!=0)Error_Handler();
  MX_OCTOSPI2_Init();
  if(XE_NP_Psram_RunBootSelfTest(&hospi2)!=0)Error_Handler();
#endif
  XE_NP_Np2LiveSd_Init(&hsd1,&hdcache1);
  while (1)
  {
    XE_NP_Np2LiveSd_Service();
  }
#endif
#elif XE_NP_NP2_PSSI_TEST_DIAG_ENABLE
  /* The test owns PSSI/GPDMA directly and must prepare its only cache domain
   * before the test image configures the probe or arms any capture hardware. */
  MX_DCACHE1_Init();
#if XE_NP_NP2_DIAG_PASSIVE_SPI2
  /* One cold, source-free receive diagnostic. Keep SRAM coherent for DMA and
   * stopped SWD reads before its status or probe configuration is written. */
  if(HAL_DCACHE_Disable(&hdcache1)!=HAL_OK)Error_Handler();
  CoreDebug->DEMCR|=CoreDebug_DEMCR_TRCENA_Msk;
  DWT->CTRL|=DWT_CTRL_CYCCNTENA_Msk;__DSB();
#endif
  XE_NP_Np2PssiTestDiag_Init();
  while (1)
  {
    XE_NP_Np2PssiTestDiag_Service();
  }
#elif XE_NP_NP2_READ_ONLY_DIAG_ENABLE
  /* Isolated bring-up: no NP1 app, USB, PSSI, SD, or electrode configuration. */
  XE_NP_Np2ReadOnlyDiag_Init();
  while (1)
  {
    XE_NP_Np2ReadOnlyDiag_Service();
  }
#else
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_AFTER_GPIO;
  MX_USART2_UART_Init();
#if (XE_NP_APP_BLE_EARLY_BLIND_RENAME_ENABLE != 0U)
  /*
   * The HJ185 vendor demo sends ST_NAME immediately after UART is ready.
   * Do that before the SD rail reset and the later bring-up path so a full
   * board power cycle can still hit the module's early boot command window.
   */
  CE32_HJ185_BootBlindApplyNameEarly(&huart2, XE_NP_APP_LEGACY_BLE_NAME);
#endif
  XE_NP_Board_ResetSdPowerRail();
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_AFTER_SD_RAIL;
#if !XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE
  MX_I2C4_Init();
#endif
  MX_TIM2_Init();
  MX_TIM8_Init();
#if (XE_NP_IMAGE_ROLE != XE_NP_IMAGE_SD_APP)
  MX_USB_OTG_HS_PCD_Init();
#endif
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_AFTER_USB;
  MX_ADC1_Init();
  MX_ADC2_Init();
  MX_DCACHE1_Init();
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_AFTER_DCACHE;
  MX_FLASH_Init();
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_AFTER_FLASH;
#if !XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE
  MX_I2C2_Init();
  MX_I2C3_Init();
#endif
#if XE_NP_BOARD_BME280_I2C_WIRING_CONFIRMED
  MX_I2C6_Init();
#endif
  MX_ICACHE_Init();
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_AFTER_ICACHE;
  MX_LPUART1_UART_Init();
  MX_OPAMP2_Init();
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_AFTER_OPAMP;
#if (XE_NP_BOARD_EXPERIMENT_DISABLE_SD_INIT == 0U)
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_BEFORE_SD_INIT;
  MX_SDMMC1_SD_Init();
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_AFTER_SD_INIT;
#else
  xe_np_sd_init_failed = 1U;
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_DISABLED;
  xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_DISABLED;
  XE_NP_Board_UpdateSdBenchLiveDiag();
#endif
  XE_NP_Board_RecordStartupProgressMarker(XE_NP_STARTUP_MARK_BEFORE_BENCH);
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_BEFORE_START;
  XE_NP_Board_UpdateSdBenchLiveDiag();
  xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_BEFORE_BENCH;
  xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_DISPATCHED;
  XE_NP_Board_UpdateSdBenchLiveDiag();
  XE_NP_Board_RunSdWriteBench();
  if (xe_np_sd_bench_diag.status == XE_NP_SD_BENCH_STATUS_DISPATCHED)
  {
    xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_UNEXPECTED;
    xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_FUNCTION_ENTER;
    XE_NP_Board_UpdateSdBenchLiveDiag();
  }
  XE_NP_Board_RecordStartupProgressMarker(XE_NP_STARTUP_MARK_BENCH_RETURN);
  if (xe_np_sd_bench_diag.status == XE_NP_SD_BENCH_STATUS_NOT_RUN)
  {
    xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_STATUS_NOT_RUN;
  }
  else if (xe_np_sd_bench_diag.status == XE_NP_SD_BENCH_STATUS_RUNNING)
  {
    xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_STATUS_SKIPPED;
    xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_SKIPPED;
  }
  else if (xe_np_sd_bench_diag.status == XE_NP_SD_BENCH_STATUS_OK)
  {
    xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_DIAG_AFTER_BENCH;
  }
  else
  {
    if (xe_np_sd_bench_diag.status == XE_NP_SD_BENCH_STATUS_NOT_RUN)
    {
      xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_STATUS_NOT_RUN;
    }
    else if ((xe_np_sd_bench_diag.fail_status == 0U) ||
             (xe_np_sd_bench_diag.status == 0U))
    {
      xe_np_sd_bench_diag.fail_status = XE_NP_SD_BENCH_STATUS_ZERO;
      xe_np_sd_bench_diag.status = XE_NP_SD_BENCH_STATUS_UNEXPECTED;
    }
  }
  XE_NP_Board_UpdateSdBenchLiveDiag();
#if !XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE
  MX_SPI1_Init();
  MX_DAC1_Init();
#endif
  MX_OCTOSPI1_Init();
  MX_I2C5_Init();
  MX_OCTOSPI2_Init();
  /* USER CODE BEGIN 2 */
  (void)XE_NP_Psram_RunBootSelfTest(&hospi2);
#if (XE_NP_IMAGE_ROLE == XE_NP_IMAGE_USB_SERVICE)
  if(!XE_NP_UsbMsc_IsSelected())
#endif
  { XE_NP_App_Init(); }
#if (XE_NP_IMAGE_ROLE != XE_NP_IMAGE_SD_APP)
  XE_NP_UsbStream_Init(&hpcd_USB_OTG_HS);
  /* The GPDMA channels retain their high bus priority, while their completion
   * IRQs yield to OTG-HS so that a USB-only capture cannot starve EP1 IN. */
  HAL_NVIC_SetPriority(OTG_HS_IRQn, XE_NP_BOARD_USB_OTG_HS_IRQ_PREEMPT_PRIO, 0);
#endif

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
#if (XE_NP_IMAGE_ROLE != XE_NP_IMAGE_SD_APP)
    XE_NP_UsbStream_Service();
    XE_NP_UsbStream_Service();
#endif
#if (XE_NP_IMAGE_ROLE == XE_NP_IMAGE_USB_SERVICE)
    if(!XE_NP_UsbMsc_IsSelected())
#endif
    { XE_NP_App_Service(); }
#if (XE_NP_IMAGE_ROLE != XE_NP_IMAGE_SD_APP)
    XE_NP_UsbStream_Service();
    XE_NP_UsbStream_Service();
#endif
  }
  /* USER CODE END 3 */
#endif
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  /*
   * Run the core regulator in the highest-performance U5 range. Board-level
   * clock macros select the stable NP clock plan, the 160 MHz USB benchmark,
   * or the disabled-by-default 187.2 MHz overclock experiment.
   */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  #if XE_NP_BOARD_HSE_ONLY_CLOCKS
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  #else
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI48|RCC_OSCILLATORTYPE_HSI
                              |RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_HSE;
  #endif
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  #if !XE_NP_BOARD_HSE_ONLY_CLOCKS
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSI48State = RCC_HSI48_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.LSIDiv = RCC_LSI_DIV1;
  #endif
#if (XE_NP_BOARD_NP_I2C_MSIK_ENABLE != 0U)
  RCC_OscInitStruct.OscillatorType |= RCC_OSCILLATORTYPE_MSIK;
  RCC_OscInitStruct.MSIKState = RCC_MSIK_ON;
  RCC_OscInitStruct.MSIKClockRange = RCC_MSIKRANGE_7;
  RCC_OscInitStruct.MSICalibrationValue = RCC_MSICALIBRATION_DEFAULT;
#endif
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMBOOST = RCC_PLLMBOOST_DIV2;
  RCC_OscInitStruct.PLL.PLLM = XE_NP_BOARD_PLL1_M;
  RCC_OscInitStruct.PLL.PLLN = XE_NP_BOARD_PLL1_N;
  RCC_OscInitStruct.PLL.PLLP = XE_NP_BOARD_PLL1P_DIV;
  RCC_OscInitStruct.PLL.PLLQ = XE_NP_BOARD_PLL1Q_DIV;
  RCC_OscInitStruct.PLL.PLLR = XE_NP_BOARD_PLL1R_DIV;
  RCC_OscInitStruct.PLL.PLLRGE = RCC_PLLVCIRANGE_0;
  /* The selected board profile always derives SYSCLK and PA8/MCO from PLL1R.
   * The production NP1 profile uses an integer 468 MHz VCO: PLL1R/5 remains
   * exactly 93.6 MHz while PLL1P/3 supplies a 156 MHz SDMMC kernel clock. */
  RCC_OscInitStruct.PLL.PLLFRACN = XE_NP_BOARD_PLL1_FRACN;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_PCLK3;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
#if (XE_NP_BOARD_APB_CLK_DIVIDER == 2U)
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_HCLK_DIV2;
#else
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_HCLK_DIV1;
#endif

#if (XE_NP_BOARD_EXPERIMENTAL_1872MHZ_CORE || XE_NP_BOARD_EXPERIMENTAL_2496MHZ_CORE || \
     XE_NP_BOARD_EXPERIMENTAL_NP2_192MHZ_CORE || XE_NP_BOARD_EXPERIMENTAL_NP2_128MHZ_20KHZ_CORE || \
     (XE_NP_BOARD_EXPERIMENTAL_PLL1N_CORE != 0U))
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
#elif XE_NP_V2_MEDIA_ENABLE || XE_NP_BOARD_USB_BENCH_160MHZ_CORE
#if (XE_NP_BOARD_USB_BENCH_PLL1_N > 80U)
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
#else
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
#endif
#else
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
#endif
  {
    Error_Handler();
  }

#if XE_NP_BOARD_HSE_ONLY_CLOCKS
  /* Reset starts from MSI. Once PLL1 (fed by HSE) owns SYSCLK, turn off every
   * internal oscillator so an accidental peripheral-mux regression cannot be
   * hidden by a fallback clock. SD startup may briefly enable HSI solely for
   * I/O compensation, latch its code, and turn HSI off before card commands. */
  __HAL_RCC_MSI_DISABLE();
  __HAL_RCC_MSIK_DISABLE();
  __HAL_RCC_HSI_DISABLE();
  __HAL_RCC_HSI48_DISABLE();
  __HAL_RCC_LSI_DISABLE();
#endif

  /** MCO configuration
  */
#if XE_NP_BOARD_MCO_DISABLED || XE_NP_BOARD_DEFER_PROBE_MCO_START
  HAL_RCC_MCOConfig(RCC_MCO1, RCC_MCO1SOURCE_NOCLOCK, RCC_MCODIV_1);
#else
  __HAL_RCC_PLLCLKOUT_ENABLE(RCC_PLL1_DIVR);
#if (XE_NP_BOARD_EFFECTIVE_MCO_DIVIDER == 16U)
  HAL_RCC_MCOConfig(RCC_MCO1, RCC_MCO1SOURCE_PLL1CLK, RCC_MCODIV_16);
#elif (XE_NP_BOARD_EFFECTIVE_MCO_DIVIDER == 8U)
  HAL_RCC_MCOConfig(RCC_MCO1, RCC_MCO1SOURCE_PLL1CLK, RCC_MCODIV_8);
#elif (XE_NP_BOARD_EFFECTIVE_MCO_DIVIDER == 4U)
  HAL_RCC_MCOConfig(RCC_MCO1, RCC_MCO1SOURCE_PLL1CLK, RCC_MCODIV_4);
#elif (XE_NP_BOARD_EFFECTIVE_MCO_DIVIDER == 2U)
  HAL_RCC_MCOConfig(RCC_MCO1, RCC_MCO1SOURCE_PLL1CLK, RCC_MCODIV_2);
#else
  HAL_RCC_MCOConfig(RCC_MCO1, RCC_MCO1SOURCE_PLL1CLK, RCC_MCODIV_1);
#endif
#endif
}

/**
  * @brief Power Configuration
  * @retval None
  */
static void SystemPower_Config(void)
{
  HAL_PWREx_EnableVddIO2();

  /*
   * Retain the checked LDO policy. V2 has an SMPS network, but schematic L1
   * (MLZ1005M2R2WT000) does not meet ST's DCR/saturation requirements. Verify
   * the fitted passives before any SMPS trial; a prior request timed out
   * before USB bring-up. See Note/V2_MODE_POWER_20261014.md.
   */
  if (HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY) != HAL_OK)
  {
    Error_Handler();
  }
/* USER CODE BEGIN PWR */
/* USER CODE END PWR */
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
#if XE_NP_V2_AUX_ENABLE
int XE_NP_UsbAux_InitAdc(void)
{
  if((ADC1->CR&(ADC_CR_ADSTART|ADC_CR_JADSTART)) ||
     (TIM8->CR1&TIM_CR1_CEN))return -1;
  HAL_PWREx_EnableVddA();
  if(hadc1.State==HAL_ADC_STATE_RESET)MX_ADC1_Init();
  return hadc1.Instance==ADC1 && hadc1.State==HAL_ADC_STATE_READY ? 0:-1;
}
#endif

static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc1.Init.Resolution = ADC_RESOLUTION_14B;
  hadc1.Init.GainCompensation = 0;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.TriggerFrequencyMode = ADC_TRIGGER_FREQ_HIGH;
  hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc1.Init.LeftBitShift = ADC_LEFTBITSHIFT_NONE;
  hadc1.Init.ConversionDataManagement = ADC_CONVERSIONDATA_DR;
  hadc1.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
#if XE_NP_BOARD_V2_PSSI_NP1_ENABLE
  /* PC4 is PSRAM SIO3 on the V2 PCB; battery sense is PB2/ADC1_IN17. */
  sConfig.Channel = ADC_CHANNEL_17;
#else
  sConfig.Channel = ADC_CHANNEL_13;
#endif
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_5CYCLE;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief ADC2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC2_Init(void)
{

  /* USER CODE BEGIN ADC2_Init 0 */

  /* USER CODE END ADC2_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC2_Init 1 */

  /* USER CODE END ADC2_Init 1 */

  /** Common config
  */
  hadc2.Instance = ADC2;
  hadc2.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc2.Init.Resolution = ADC_RESOLUTION_14B;
  hadc2.Init.GainCompensation = 0;
  hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc2.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc2.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc2.Init.LowPowerAutoWait = DISABLE;
  hadc2.Init.ContinuousConvMode = DISABLE;
  hadc2.Init.NbrOfConversion = 1;
  hadc2.Init.DiscontinuousConvMode = DISABLE;
  hadc2.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc2.Init.DMAContinuousRequests = DISABLE;
  hadc2.Init.TriggerFrequencyMode = ADC_TRIGGER_FREQ_HIGH;
  hadc2.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc2.Init.LeftBitShift = ADC_LEFTBITSHIFT_NONE;
  hadc2.Init.ConversionDataManagement = ADC_CONVERSIONDATA_DR;
  hadc2.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc2) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_16;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_5CYCLE;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC2_Init 2 */

  /* USER CODE END ADC2_Init 2 */

}

/**
  * @brief DAC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_DAC1_Init(void)
{

  /* USER CODE BEGIN DAC1_Init 0 */

  /* USER CODE END DAC1_Init 0 */

  DAC_ChannelConfTypeDef sConfig = {0};
  DAC_AutonomousModeConfTypeDef sAutonomousMode = {0};

  /* USER CODE BEGIN DAC1_Init 1 */

  /* USER CODE END DAC1_Init 1 */

  /** DAC Initialization
  */
  hdac1.Instance = DAC1;
  if (HAL_DAC_Init(&hdac1) != HAL_OK)
  {
    Error_Handler();
  }

  /** DAC channel OUT1 config
  */
  sConfig.DAC_HighFrequency = DAC_HIGH_FREQUENCY_INTERFACE_MODE_DISABLE;
  sConfig.DAC_DMADoubleDataMode = DISABLE;
  sConfig.DAC_SignedFormat = DISABLE;
  sConfig.DAC_SampleAndHold = DAC_SAMPLEANDHOLD_DISABLE;
  sConfig.DAC_Trigger = DAC_TRIGGER_NONE;
  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_DISABLE;
  sConfig.DAC_ConnectOnChipPeripheral = DAC_CHIPCONNECT_EXTERNAL;
  sConfig.DAC_UserTrimming = DAC_TRIMMING_FACTORY;
  if (HAL_DAC_ConfigChannel(&hdac1, &sConfig, DAC_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Autonomous Mode
  */
  sAutonomousMode.AutonomousModeState = DAC_AUTONOMOUS_MODE_DISABLE;
  if (HAL_DACEx_SetConfigAutonomousMode(&hdac1, &sAutonomousMode) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DAC1_Init 2 */

  /* USER CODE END DAC1_Init 2 */

}

/**
  * @brief DCACHE1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_DCACHE1_Init(void)
{

  /* USER CODE BEGIN DCACHE1_Init 0 */

  /* USER CODE END DCACHE1_Init 0 */

  /* USER CODE BEGIN DCACHE1_Init 1 */

  /* USER CODE END DCACHE1_Init 1 */
  hdcache1.Instance = DCACHE1;
  hdcache1.Init.ReadBurstType = DCACHE_READ_BURST_WRAP;
  if (HAL_DCACHE_Init(&hdcache1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DCACHE1_Init 2 */

  /* USER CODE END DCACHE1_Init 2 */

}

/**
  * @brief MPU Initialization Function
  * @param None
  * @retval None
  */
#if ((XE_NP_PSRAM_MPU_NONCACHEABLE_EXPERIMENT != 0U) || \
     (XE_NP_CAPTURE_SRAM3_MPU_NONCACHEABLE != 0U) || \
     (XE_NP_USB_TX_MPU_NONCACHEABLE != 0U))
static void MX_MPU_Init(void)
{
  MPU_Attributes_InitTypeDef mpu_attributes;
  MPU_Region_InitTypeDef mpu_region;

  memset(&mpu_attributes, 0, sizeof(mpu_attributes));
  memset(&mpu_region, 0, sizeof(mpu_region));

  HAL_MPU_Disable();

#if (XE_NP_CAPTURE_SRAM3_MPU_NONCACHEABLE != 0U)
  /*
   * The continuous GPIO capture lanes live exclusively in SRAM3.  DMA writes
   * this producer ring while the foreground reconstructs completed pairs;
   * making just this bank non-cacheable removes the variable invalidation
   * cost from the narrow live-ring guard window.
   */
  mpu_attributes.Number = XE_NP_CAPTURE_SRAM3_MPU_ATTRIBUTES_INDEX;
  mpu_attributes.Attributes = INNER_OUTER(MPU_NOT_CACHEABLE);
  HAL_MPU_ConfigMemoryAttributes(&mpu_attributes);

  mpu_region.Enable = MPU_REGION_ENABLE;
  mpu_region.Number = XE_NP_CAPTURE_SRAM3_MPU_REGION_NUMBER;
#if XE_NP_NP2_LIVE_SD_DIRECT
  mpu_region.BaseAddress = XE_NP_Np2DirectBank(1U);
#if XE_NP_NP2_LIVE_SD_EXTENDED_RING
  /* The optional thirteenth RU fills the unused tail of SRAM3 and continues
   * into SRAM5; the bank-2 arena starts at the RU's exclusive end. */
  mpu_region.LimitAddress = XE_NP_Np2DirectBank(2U) - 1UL;
#else
  mpu_region.LimitAddress = XE_NP_Np2DirectBank(1U) + NP2_DIRECT_BANK_BYTES - 1UL;
#endif
#else
  mpu_region.BaseAddress = XE_NP_CAPTURE_SRAM3_BASE_ADDR;
  mpu_region.LimitAddress = XE_NP_CAPTURE_SRAM3_BASE_ADDR + XE_NP_CAPTURE_SRAM3_SIZE_BYTES - 1UL;
#endif
  mpu_region.AttributesIndex = XE_NP_CAPTURE_SRAM3_MPU_ATTRIBUTES_INDEX;
  mpu_region.AccessPermission = MPU_REGION_ALL_RW;
  mpu_region.DisableExec = MPU_INSTRUCTION_ACCESS_DISABLE;
  mpu_region.IsShareable = MPU_ACCESS_NOT_SHAREABLE;
  HAL_MPU_ConfigRegion(&mpu_region);
#if XE_NP_NP2_LIVE_SD_DIRECT
  /* Exclusive three-bank, direct-record DMA arenas. Keep stack, descriptors
   * and mailbox outside these mappings; no clean/invalidate in the hot path. */
  mpu_region.Number = MPU_REGION_NUMBER4;
  mpu_region.BaseAddress = XE_NP_Np2DirectBank(0U);
  mpu_region.LimitAddress = XE_NP_Np2DirectBank(0U) + NP2_DIRECT_BANK_BYTES - 1UL;
  HAL_MPU_ConfigRegion(&mpu_region);
  mpu_region.Number = MPU_REGION_NUMBER3;
  mpu_region.BaseAddress = XE_NP_Np2DirectBank(2U);
  mpu_region.LimitAddress = XE_NP_Np2DirectBank(2U) + NP2_DIRECT_BANK_BYTES - 1UL;
  HAL_MPU_ConfigRegion(&mpu_region);
#endif
#endif

#if (XE_NP_USB_TX_MPU_NONCACHEABLE != 0U)
  /* NP2 USB blocks are written once by the CPU and then owned by the OTG HS
   * internal DMA. Mapping the private 512 KiB slot arena non-cacheable removes
   * a full 46,592-byte cache clean from every published block. */
  mpu_attributes.Number = XE_NP_USB_TX_MPU_ATTRIBUTES_INDEX;
  mpu_attributes.Attributes = INNER_OUTER(MPU_NOT_CACHEABLE);
  HAL_MPU_ConfigMemoryAttributes(&mpu_attributes);

  mpu_region.Enable = MPU_REGION_ENABLE;
  mpu_region.Number = XE_NP_USB_TX_MPU_REGION_NUMBER;
  mpu_region.BaseAddress = XE_NP_USB_TX_ARENA_BASE;
  mpu_region.LimitAddress = XE_NP_USB_TX_ARENA_BASE + XE_NP_USB_TX_ARENA_BYTES - 1UL;
  mpu_region.AttributesIndex = XE_NP_USB_TX_MPU_ATTRIBUTES_INDEX;
  mpu_region.AccessPermission = MPU_REGION_ALL_RW;
  mpu_region.DisableExec = MPU_INSTRUCTION_ACCESS_DISABLE;
  mpu_region.IsShareable = MPU_ACCESS_NOT_SHAREABLE;
  HAL_MPU_ConfigRegion(&mpu_region);
#if XE_NP_USB_EP0_SETUP_NC_TEST
  /* SETUP may preempt foreground cache maintenance. Its parser must not
   * depend on an invalidation that can return HAL_BUSY in that interrupt. */
  mpu_region.Number = MPU_REGION_NUMBER2;
  mpu_region.BaseAddress = (uint32_t)(uintptr_t)hpcd_USB_OTG_HS.Setup & ~31UL;
  mpu_region.LimitAddress = ((uint32_t)(uintptr_t)hpcd_USB_OTG_HS.Setup +
      (uint32_t)sizeof(hpcd_USB_OTG_HS.Setup) + 31UL) & ~31UL;
  mpu_region.LimitAddress--;
  HAL_MPU_ConfigRegion(&mpu_region);
#endif
#endif

#if (XE_NP_PSRAM_MPU_NONCACHEABLE_EXPERIMENT != 0U)
  /*
   * Keep the OCTOSPI2 APS6404L window non-cacheable so CPU reads of the
   * capture ring observe the same bytes that the DMA writes, without relying
   * on repeated DCACHE invalidation against memory-mapped PSRAM. On this U5
   * path it also avoids the large sequential-write penalty seen with the
   * default cacheable attributes on the 0x7000_0000 PSRAM window.
   */
  mpu_attributes.Number = XE_NP_PSRAM_MPU_ATTRIBUTES_INDEX;
  mpu_attributes.Attributes = INNER_OUTER(MPU_NOT_CACHEABLE);
  HAL_MPU_ConfigMemoryAttributes(&mpu_attributes);

  mpu_region.Enable = MPU_REGION_ENABLE;
  mpu_region.Number = XE_NP_PSRAM_MPU_REGION_NUMBER;
  mpu_region.BaseAddress = XE_NP_PSRAM_BASE_ADDR;
  mpu_region.LimitAddress = XE_NP_PSRAM_BASE_ADDR + XE_NP_PSRAM_SIZE_BYTES - 1UL;
  mpu_region.AttributesIndex = XE_NP_PSRAM_MPU_ATTRIBUTES_INDEX;
  mpu_region.AccessPermission = MPU_REGION_ALL_RW;
  mpu_region.DisableExec = MPU_INSTRUCTION_ACCESS_DISABLE;
  mpu_region.IsShareable = MPU_ACCESS_NOT_SHAREABLE;
  HAL_MPU_ConfigRegion(&mpu_region);
#endif

  HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);
}
#endif

/**
  * @brief FLASH Initialization Function
  * @param None
  * @retval None
  */
static void MX_FLASH_Init(void)
{

  /* USER CODE BEGIN FLASH_Init 0 */

  /* USER CODE END FLASH_Init 0 */

  /* USER CODE BEGIN FLASH_Init 1 */

  /* USER CODE END FLASH_Init 1 */
  if (HAL_FLASH_Unlock() != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_FLASH_Lock() != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN FLASH_Init 2 */

  /* USER CODE END FLASH_Init 2 */

}

/**
  * @brief I2C2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C2_Init(void)
{

  /* USER CODE BEGIN I2C2_Init 0 */

  /* USER CODE END I2C2_Init 0 */

  /* USER CODE BEGIN I2C2_Init 1 */

  /* USER CODE END I2C2_Init 1 */
  hi2c2.Instance = I2C2;
  hi2c2.Init.Timing = XE_NP_BOARD_NP_I2C_TIMING;
  hi2c2.Init.OwnAddress1 = 0;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c2, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c2, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C2_Init 2 */

  /* USER CODE END I2C2_Init 2 */

}

/**
  * @brief I2C3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C3_Init(void)
{

  /* USER CODE BEGIN I2C3_Init 0 */

  /* USER CODE END I2C3_Init 0 */

  /* USER CODE BEGIN I2C3_Init 1 */

  /* USER CODE END I2C3_Init 1 */
  hi2c3.Instance = I2C3;
  hi2c3.Init.Timing = XE_NP_BOARD_NP_I2C_TIMING;
  hi2c3.Init.OwnAddress1 = 0;
  hi2c3.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c3.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c3.Init.OwnAddress2 = 0;
  hi2c3.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c3.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c3.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c3) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c3, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c3, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C3_Init 2 */

  /* USER CODE END I2C3_Init 2 */

}

/**
  * @brief I2C4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C4_Init(void)
{

  /* USER CODE BEGIN I2C4_Init 0 */

  /* USER CODE END I2C4_Init 0 */

  /* USER CODE BEGIN I2C4_Init 1 */

  /* USER CODE END I2C4_Init 1 */
  hi2c4.Instance = I2C4;
  hi2c4.Init.Timing = XE_NP_BOARD_NP_I2C_TIMING;
  hi2c4.Init.OwnAddress1 = 0;
  hi2c4.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c4.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c4.Init.OwnAddress2 = 0;
  hi2c4.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c4.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c4.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c4) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c4, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c4, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C4_Init 2 */

  /* USER CODE END I2C4_Init 2 */

}

/**
  * @brief I2C5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C5_Init(void)
{

  /* USER CODE BEGIN I2C5_Init 0 */

  /* USER CODE END I2C5_Init 0 */

  /* USER CODE BEGIN I2C5_Init 1 */

  /* USER CODE END I2C5_Init 1 */
  hi2c5.Instance = I2C5;
  hi2c5.Init.Timing = XE_NP_BOARD_SENSOR_I2C_TIMING;
  hi2c5.Init.OwnAddress1 = 0;
  hi2c5.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c5.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c5.Init.OwnAddress2 = 0;
  hi2c5.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c5.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c5.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c5) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c5, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c5, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C5_Init 2 */

  /* USER CODE END I2C5_Init 2 */

}

/**
  * @brief I2C6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C6_Init(void)
{

  /* USER CODE BEGIN I2C6_Init 0 */

  /* USER CODE END I2C6_Init 0 */

  /* USER CODE BEGIN I2C6_Init 1 */

  /* USER CODE END I2C6_Init 1 */
  hi2c6.Instance = I2C6;
  hi2c6.Init.Timing = XE_NP_BOARD_SENSOR_I2C_TIMING;
  hi2c6.Init.OwnAddress1 = 0;
  hi2c6.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c6.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c6.Init.OwnAddress2 = 0;
  hi2c6.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c6.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c6.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c6) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c6, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c6, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C6_Init 2 */

  /* USER CODE END I2C6_Init 2 */

}

/**
  * @brief ICACHE Initialization Function
  * @param None
  * @retval None
  */
static void MX_ICACHE_Init(void)
{

  /* USER CODE BEGIN ICACHE_Init 0 */

  /* USER CODE END ICACHE_Init 0 */

  /* USER CODE BEGIN ICACHE_Init 1 */

  /* USER CODE END ICACHE_Init 1 */

  /** Enable instruction cache in 1-way (direct mapped cache)
  */
  if (HAL_ICACHE_ConfigAssociativityMode(ICACHE_1WAY) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_ICACHE_Enable() != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ICACHE_Init 2 */

  /* USER CODE END ICACHE_Init 2 */

}

/**
  * @brief LPUART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_LPUART1_UART_Init(void)
{

  /* USER CODE BEGIN LPUART1_Init 0 */

  /* USER CODE END LPUART1_Init 0 */

  /* USER CODE BEGIN LPUART1_Init 1 */

  /* USER CODE END LPUART1_Init 1 */
  hlpuart1.Instance = LPUART1;
  hlpuart1.Init.BaudRate = 209700;
  hlpuart1.Init.WordLength = UART_WORDLENGTH_8B;
  hlpuart1.Init.StopBits = UART_STOPBITS_1;
  hlpuart1.Init.Parity = UART_PARITY_NONE;
  hlpuart1.Init.Mode = UART_MODE_TX_RX;
  hlpuart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  hlpuart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  hlpuart1.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  hlpuart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  hlpuart1.FifoMode = UART_FIFOMODE_DISABLE;
  if (HAL_UART_Init(&hlpuart1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&hlpuart1, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&hlpuart1, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&hlpuart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN LPUART1_Init 2 */

  /* USER CODE END LPUART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart2, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart2, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief OCTOSPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_OCTOSPI1_Init(void)
{

  /* USER CODE BEGIN OCTOSPI1_Init 0 */

  /* USER CODE END OCTOSPI1_Init 0 */

  /* USER CODE BEGIN OCTOSPI1_Init 1 */

  /* USER CODE END OCTOSPI1_Init 1 */
  /* OCTOSPI1 parameter configuration*/
  hospi1.Instance = OCTOSPI1;
  hospi1.Init.FifoThreshold = 1;
  hospi1.Init.DualQuad = HAL_OSPI_DUALQUAD_DISABLE;
  hospi1.Init.MemoryType = HAL_OSPI_MEMTYPE_MICRON;
  hospi1.Init.DeviceSize = 32;
  hospi1.Init.ChipSelectHighTime = 1;
  hospi1.Init.FreeRunningClock = HAL_OSPI_FREERUNCLK_DISABLE;
  hospi1.Init.ClockMode = HAL_OSPI_CLOCK_MODE_0;
  hospi1.Init.WrapSize = HAL_OSPI_WRAP_NOT_SUPPORTED;
  hospi1.Init.ClockPrescaler = 1;
  hospi1.Init.SampleShifting = HAL_OSPI_SAMPLE_SHIFTING_NONE;
  hospi1.Init.DelayHoldQuarterCycle = HAL_OSPI_DHQC_DISABLE;
  hospi1.Init.ChipSelectBoundary = 0;
  hospi1.Init.DelayBlockBypass = HAL_OSPI_DELAY_BLOCK_BYPASSED;
  hospi1.Init.MaxTran = 0;
  hospi1.Init.Refresh = 0;
  if (HAL_OSPI_Init(&hospi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN OCTOSPI1_Init 2 */

  /* USER CODE END OCTOSPI1_Init 2 */

}

/**
  * @brief OCTOSPI2 Initialization Function
  * @param None
  * @retval None
  */
static HAL_StatusTypeDef XE_NP_Board_ConfigurePsramHost(void)
{

  /* USER CODE BEGIN OCTOSPI2_Init 0 */

  /* USER CODE END OCTOSPI2_Init 0 */

  OSPIM_CfgTypeDef sOspiManagerCfg = {0};

  /* USER CODE BEGIN OCTOSPI2_Init 1 */

  /* USER CODE END OCTOSPI2_Init 1 */
  /* OCTOSPI2 parameter configuration*/
  hospi2.Instance = OCTOSPI2;
  hospi2.Init.FifoThreshold = 1;
  hospi2.Init.DualQuad = HAL_OSPI_DUALQUAD_DISABLE;
  hospi2.Init.MemoryType = HAL_OSPI_MEMTYPE_APMEMORY;
  hospi2.Init.DeviceSize = 23;
  hospi2.Init.ChipSelectHighTime = 3;
  hospi2.Init.FreeRunningClock = HAL_OSPI_FREERUNCLK_DISABLE;
  hospi2.Init.ClockMode = HAL_OSPI_CLOCK_MODE_0;
  hospi2.Init.WrapSize = HAL_OSPI_WRAP_NOT_SUPPORTED;
  hospi2.Init.ClockPrescaler = 1;
  hospi2.Init.SampleShifting = HAL_OSPI_SAMPLE_SHIFTING_HALFCYCLE;
  hospi2.Init.DelayHoldQuarterCycle = HAL_OSPI_DHQC_DISABLE;
  hospi2.Init.ChipSelectBoundary = 10;
  hospi2.Init.DelayBlockBypass = HAL_OSPI_DELAY_BLOCK_BYPASSED;
  hospi2.Init.MaxTran = 0;
  hospi2.Init.Refresh = 0;
  if (HAL_OSPI_Init(&hospi2) != HAL_OK)
  {
    return HAL_ERROR;
  }
  sOspiManagerCfg.ClkPort = 1;
  sOspiManagerCfg.NCSPort = 2;
  sOspiManagerCfg.IOLowPort = HAL_OSPIM_IOPORT_1_HIGH;
  if (HAL_OSPIM_Config(&hospi2, &sOspiManagerCfg, HAL_OSPI_TIMEOUT_DEFAULT_VALUE) != HAL_OK)
  {
    return HAL_ERROR;
  }
  /* USER CODE BEGIN OCTOSPI2_Init 2 */

  /* USER CODE END OCTOSPI2_Init 2 */
  return HAL_OK;
}

static void MX_OCTOSPI2_Init(void)
{
  if(XE_NP_Board_ConfigurePsramHost()!=HAL_OK)Error_Handler();
}

#if XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
int XE_NP_Board_InitNp2OverflowMemoryProfile(uint32_t sample_hz,uint32_t probe_mask)
{
  if(!XE_NP_Board_Np2ProfileCoreHz(sample_hz,probe_mask))return -1;
#if XE_NP_PSRAM_OVERFLOW_PRESCALER == 1U
   /* Stopped-only preparation/self-test. SD7.5k uses CPU48/MCO12/SPI12;
    * runtime15k uses CPU96/MCO24/SPI24. Both use HSE PLL1Q96 for PSRAM
   * after repeatable128MHz spill corruption; legacy trials remain20/30. */
  if(sample_hz!=20000U && sample_hz!=30000U
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES && !XE_NP_PSRAM_OVERFLOW_PLL2Q108
     && sample_hz!=15000U
#if XE_NP_NP2_DUAL_SD_APP_ENABLE && XE_NP_PSRAM_OVERFLOW_PLL1Q128
     && sample_hz!=7500U
#endif
#endif
    )return -1;
#endif
  /* Quiesce the prior mapped host BEFORE changing its SYSCLK source rate.
   * Train at the runtime HSE clock, not the potentially different boot
   * clock. Only an empty stopped session may call this destructive test. */
  if(!XE_NP_Cmd11PinSourcesIdle() || !XE_NP_Cmd11SdHostInactive())return -1;
  /* No untracked/shared-mux consumer may be active. The tracked mapped
   * OSPI2 host must be disabled before changing PLL1/SYSCLK on every route. */
  if((OCTOSPI1->CR&(OCTOSPI_CR_EN|OCTOSPI_CR_DMAEN)) || (OCTOSPI1->SR&OCTOSPI_SR_BUSY) ||
     (hospi2.Instance && hospi2.Instance!=OCTOSPI2) ||
     (!hospi2.Instance && ((OCTOSPI2->CR&(OCTOSPI_CR_EN|OCTOSPI_CR_DMAEN)) ||
                          (OCTOSPI2->SR&OCTOSPI_SR_BUSY))))return -1;
#if XE_NP_PSRAM_OVERFLOW_PLL2Q108
  if(!XE_NP_Board_Np2Pll2Q108Ready())return -1;
#endif
  if(hospi2.Instance && HAL_OSPI_Abort(&hospi2)!=HAL_OK)return -1;
  if((OCTOSPI2->SR&OCTOSPI_SR_BUSY) || (OCTOSPI2->CR&OCTOSPI_CR_DMAEN))return -1;
  if(hospi2.Instance){__HAL_OSPI_DISABLE(&hospi2);__DSB();}
  if(OCTOSPI2->CR&OCTOSPI_CR_EN)return -1;
  if(XE_NP_Board_SetNp2SampleRateProfile(sample_hz,probe_mask)!=0)return -1;
  /* HAL_OSPI_Init calls MSP only in RESET. Reassert the output and mux on
   * every stopped same-lifetime preparation, before the source clock guard. */
#if XE_NP_PSRAM_OVERFLOW_PLL1Q128
  __HAL_RCC_PLLCLKOUT_ENABLE(RCC_PLL1_DIVQ);
  __HAL_RCC_OSPI_CONFIG(RCC_OSPICLKSOURCE_PLL1);__DSB();
#if XE_NP_NP2_SD_DUAL30_PSRAM_SYSCLK192_TEST
  if(XE_NP_Board_ConfigurePsramHost()!=HAL_OK)return -1;
  uint32_t psram_source=RCC_OSPICLKSOURCE_PLL1;
  uint32_t psram_hz=(sample_hz==7500U || sample_hz==15000U)?96000000U:
      (sample_hz==30000U?384000000U/XE_NP_PSRAM_OVERFLOW_PLL1Q_30KHZ_DIV:128000000U);
  if(sample_hz==30000U && probe_mask==3U){
    /* HAL_OSPI_Init may run MSP and always enables its host. Switch only
     * after that call, while every mapped/DMA consumer is still stopped. */
    if(!XE_NP_Cmd11PinSourcesIdle() || !XE_NP_Cmd11SdHostInactive() ||
       (OCTOSPI1->CR&(OCTOSPI_CR_EN|OCTOSPI_CR_DMAEN)) || (OCTOSPI1->SR&OCTOSPI_SR_BUSY) ||
       hospi2.Instance!=OCTOSPI2 || (OCTOSPI2->SR&OCTOSPI_SR_BUSY) ||
       (OCTOSPI2->CR&OCTOSPI_CR_DMAEN) || HAL_RCC_GetSysClockFreq()!=192000000U ||
       HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_SDMMC)!=108000000U)return -1;
    uint32_t enabled=OCTOSPI2->CR&OCTOSPI_CR_EN;
    __HAL_OSPI_DISABLE(&hospi2);__DSB();
    if(OCTOSPI2->CR&OCTOSPI_CR_EN)return -1;
    __HAL_RCC_OSPI_CONFIG(RCC_OSPICLKSOURCE_SYSCLK);__DSB();
    if(__HAL_RCC_GET_OSPI_SOURCE()!=RCC_OSPICLKSOURCE_SYSCLK ||
       HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_OSPI)!=192000000U)return -1;
    if(enabled)__HAL_OSPI_ENABLE(&hospi2);
    psram_source=RCC_OSPICLKSOURCE_SYSCLK;psram_hz=192000000U;
  }
  if(__HAL_RCC_GET_OSPI_SOURCE()!=psram_source ||
     !(RCC->PLL1CFGR&RCC_PLL1CFGR_PLL1QEN) ||
     HAL_RCC_GetHCLKFreq()!=XE_NP_Board_Np2ProfileCoreHz(sample_hz,probe_mask) ||
     HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_OSPI)!=psram_hz)return -1;
#else
  /* Preserve the original disabled-trial evaluation order and code bytes. */
  if(XE_NP_Board_ConfigurePsramHost()!=HAL_OK ||
     __HAL_RCC_GET_OSPI_SOURCE()!=RCC_OSPICLKSOURCE_PLL1 ||
     !(RCC->PLL1CFGR&RCC_PLL1CFGR_PLL1QEN) ||
     HAL_RCC_GetHCLKFreq()!=XE_NP_Board_Np2ProfileCoreHz(sample_hz,probe_mask) ||
     HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_OSPI)!=
#if XE_NP_NP2_SD_SINGLE7500_SQR_LINEAR_TEST
       (XE_NP_Board_Np2Single7500SqrLinear(sample_hz,probe_mask)?76800000U:
#endif
       ((sample_hz==7500U || sample_hz==15000U)?96000000U:
        (sample_hz==30000U?
#if XE_NP_NP2_SD_DUAL30_PSRAM_Q128_TEST
         (XE_NP_Board_Np2Dual30PsramQ128(sample_hz,probe_mask)?128000000U:
#endif
          384000000U/XE_NP_PSRAM_OVERFLOW_PLL1Q_30KHZ_DIV
#if XE_NP_NP2_SD_DUAL30_PSRAM_Q128_TEST
         )
#endif
         :128000000U))
#if XE_NP_NP2_SD_SINGLE7500_SQR_LINEAR_TEST
       )
#endif
       )return -1;
#endif
#elif XE_NP_PSRAM_OVERFLOW_PLL2Q108
  __HAL_RCC_OSPI_CONFIG(RCC_OSPICLKSOURCE_PLL2);__DSB();
  if(XE_NP_Board_ConfigurePsramHost()!=HAL_OK ||
     !XE_NP_Board_Np2Pll2Q108Ready() ||
     __HAL_RCC_GET_OSPI_SOURCE()!=RCC_OSPICLKSOURCE_PLL2 ||
     HAL_RCC_GetHCLKFreq()!=sample_hz*6400U ||
     HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_OSPI)!=108000000U)return -1;
#else
  __HAL_RCC_OSPI_CONFIG(RCC_OSPICLKSOURCE_SYSCLK);__DSB();
  if(XE_NP_Board_ConfigurePsramHost()!=HAL_OK ||
     __HAL_RCC_GET_OSPI_SOURCE()!=RCC_OSPICLKSOURCE_SYSCLK ||
     HAL_RCCEx_GetPeriphCLKFreq(RCC_PERIPHCLK_OSPI)!=HAL_RCC_GetHCLKFreq())return -1;
#endif
  int result=XE_NP_Psram_RunBootSelfTest(&hospi2);
#if defined(XE_NP_PSRAM_PAD_HSLV_ENABLE) && XE_NP_PSRAM_PAD_HSLV_ENABLE
  /* Overflow memory is prepared here, not at catalog boot. Refuse the
   * opt-in pad trial before Source_Init/Start if the fitted pads did not
   * enable; no check is added to capture, spill/refill or SD service. */
  const uint32_t required=XE_NP_PSRAM_FLAG_PAD_HSLV_OPTION_READY |
                          XE_NP_PSRAM_FLAG_PAD_HSLV_ALL_ENABLED;
  if(result==0 && (XE_NP_Psram_GetDiag()->flags & required)!=required)return -1;
#endif
  return result;
}
int XE_NP_Board_InitNp2OverflowMemory(uint32_t sample_hz)
{
  return XE_NP_Board_InitNp2OverflowMemoryProfile(sample_hz,0U);
}
#endif

/**
  * @brief OPAMP2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_OPAMP2_Init(void)
{

  /* USER CODE BEGIN OPAMP2_Init 0 */

  /* USER CODE END OPAMP2_Init 0 */

  /* USER CODE BEGIN OPAMP2_Init 1 */

  /* USER CODE END OPAMP2_Init 1 */
  hopamp2.Instance = OPAMP2;
  hopamp2.Init.PowerSupplyRange = OPAMP_POWERSUPPLY_HIGH;
  hopamp2.Init.Mode = OPAMP_PGA_MODE;
  hopamp2.Init.NonInvertingInput = OPAMP_NONINVERTINGINPUT_IO0;
  hopamp2.Init.InvertingInput = OPAMP_INVERTINGINPUT_IO1;
  hopamp2.Init.PowerMode = OPAMP_POWERMODE_NORMALPOWER_NORMALSPEED;
  hopamp2.Init.PgaGain = OPAMP_PGA_GAIN_2;
  hopamp2.Init.UserTrimming = OPAMP_TRIMMING_FACTORY;
  hopamp2.Init.TrimmingValueP = 16;
  hopamp2.Init.TrimmingValueN = 16;
  hopamp2.Init.TrimmingValuePLowPower = 16;
  hopamp2.Init.TrimmingValueNLowPower = 16;
  if (HAL_OPAMP_Init(&hopamp2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN OPAMP2_Init 2 */

  /* USER CODE END OPAMP2_Init 2 */

}

/**
  * @brief SDMMC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SDMMC1_SD_Init(void)
{

  /* USER CODE BEGIN SDMMC1_Init 0 */

  /* USER CODE END SDMMC1_Init 0 */

  /* USER CODE BEGIN SDMMC1_Init 1 */

  /* USER CODE END SDMMC1_Init 1 */
#if XE_NP_SD_CMD11_PIN_COMPAT_ENABLE
  HAL_StatusTypeDef initialized=XE_NP_Board_InitSdHostBase();
  if(XE_NP_Board_FreezeSdIdentification(initialized)!=HAL_OK)return;
#else
  XE_NP_Board_EnsureSdPowerRail();
  if (XE_NP_Board_InitSdHostBase() != HAL_OK)
  {
    return;
  }
#endif
  XE_NP_Board_RecordSdBenchMarker(XE_NP_SD_BENCH_DIAG_AFTER_SD_HOST_BASE);

  XE_NP_Board_RecordSdBenchMarker(XE_NP_SD_BENCH_DIAG_BEFORE_SD_TUNE);
  XE_NP_Board_PostInitSdTuning();
  XE_NP_Board_RecordSdBenchMarker(XE_NP_SD_BENCH_DIAG_AFTER_SD_TUNE);
  /* USER CODE BEGIN SDMMC1_Init 2 */

  /* USER CODE END SDMMC1_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  SPI_AutonomousModeConfTypeDef HAL_SPI_AutonomousMode_Cfg_Struct = {0};

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  /* V2 passive NP1 listener: PA5 clocks PB5/DATA3 into the SPI shifter.
     No NSS, MISO, or output pin is enabled, so the MCU cannot drive PSB. */
  hspi1.Init.Mode = SPI_MODE_SLAVE;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES_RXONLY;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  /* NP1 changes PSB data on rising edges; sample on the falling edge. */
  hspi1.Init.CLKPhase = SPI_PHASE_2EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 0x7;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_DISABLE;
  hspi1.Init.NSSPolarity = SPI_NSS_POLARITY_LOW;
  hspi1.Init.FifoThreshold = SPI_FIFO_THRESHOLD_01DATA;
  hspi1.Init.MasterSSIdleness = SPI_MASTER_SS_IDLENESS_00CYCLE;
  hspi1.Init.MasterInterDataIdleness = SPI_MASTER_INTERDATA_IDLENESS_00CYCLE;
  hspi1.Init.MasterReceiverAutoSusp = SPI_MASTER_RX_AUTOSUSP_DISABLE;
  hspi1.Init.MasterKeepIOState = SPI_MASTER_KEEP_IO_STATE_DISABLE;
  hspi1.Init.IOSwap = SPI_IO_SWAP_DISABLE;
  hspi1.Init.ReadyMasterManagement = SPI_RDY_MASTER_MANAGEMENT_INTERNALLY;
  hspi1.Init.ReadyPolarity = SPI_RDY_POLARITY_HIGH;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_SPI_AutonomousMode_Cfg_Struct.TriggerState = SPI_AUTO_MODE_DISABLE;
  HAL_SPI_AutonomousMode_Cfg_Struct.TriggerSelection = SPI_GRP1_GPDMA_CH0_TCF_TRG;
  HAL_SPI_AutonomousMode_Cfg_Struct.TriggerPolarity = SPI_TRIG_POLARITY_RISING;
  if (HAL_SPIEx_SetConfigAutonomousMode(&hspi1, &HAL_SPI_AutonomousMode_Cfg_Struct) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4294967295;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_ETRMODE2;
  /*
   * In direct 23.4 MHz PSB mode the probe changes data on the rising edge of
   * PSB_CLK and the receiver should sample on the falling edge. Drive the
   * timer/DMA cadence from the falling edge so GPIO snapshots land on the
   * data-valid side of the bus timing.
   */
  sClockSourceConfig.ClockPolarity = TIM_CLOCKPOLARITY_INVERTED;
  sClockSourceConfig.ClockPrescaler = TIM_CLOCKPRESCALER_DIV1;
  sClockSourceConfig.ClockFilter = 0;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM8 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM8_Init(void)
{

  /* USER CODE BEGIN TIM8_Init 0 */

  /* USER CODE END TIM8_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM8_Init 1 */

  /* USER CODE END TIM8_Init 1 */
  htim8.Instance = TIM8;
  htim8.Init.Prescaler = 0;
  htim8.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim8.Init.Period = 65535;
  htim8.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim8.Init.RepetitionCounter = 0;
  htim8.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim8) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_ETRMODE2;
  sClockSourceConfig.ClockPolarity = TIM_CLOCKPOLARITY_INVERTED;
  sClockSourceConfig.ClockPrescaler = TIM_CLOCKPRESCALER_DIV1;
  sClockSourceConfig.ClockFilter = 0;
  if (HAL_TIM_ConfigClockSource(&htim8, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim8, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM8_Init 2 */

  /* USER CODE END TIM8_Init 2 */

}

/**
  * @brief USB_OTG_HS Initialization Function
  * @param None
  * @retval None
  */
static void MX_USB_OTG_HS_PCD_Init(void)
{

  /* USER CODE BEGIN USB_OTG_HS_Init 0 */

  /* USER CODE END USB_OTG_HS_Init 0 */

  /* USER CODE BEGIN USB_OTG_HS_Init 1 */

  /* USER CODE END USB_OTG_HS_Init 1 */
  hpcd_USB_OTG_HS.Instance = USB_OTG_HS;
  hpcd_USB_OTG_HS.Init.dev_endpoints = 9;
  hpcd_USB_OTG_HS.Init.speed = PCD_SPEED_HIGH;
  hpcd_USB_OTG_HS.Init.phy_itface = USB_OTG_HS_EMBEDDED_PHY;
  hpcd_USB_OTG_HS.Init.Sof_enable = DISABLE;
  hpcd_USB_OTG_HS.Init.low_power_enable = DISABLE;
  hpcd_USB_OTG_HS.Init.lpm_enable = DISABLE;
  hpcd_USB_OTG_HS.Init.use_dedicated_ep1 = DISABLE;
  hpcd_USB_OTG_HS.Init.vbus_sensing_enable = DISABLE;
#if (XE_NP_BOARD_USB_OTG_HS_INTERNAL_DMA != 0U)
  hpcd_USB_OTG_HS.Init.dma_enable = ENABLE;
#else
  hpcd_USB_OTG_HS.Init.dma_enable = DISABLE;
#endif
#if (XE_NP_IMAGE_ROLE == XE_NP_IMAGE_USB_SERVICE)
  /* MSC owns aligned/cache-maintained scratch buffers and has no capture
   * arbitration load. Keep its endpoint engine independent of the recorder's
   * selectable FIFO/DMA experiment profile. */
  if(XE_NP_UsbMsc_IsSelected()) { hpcd_USB_OTG_HS.Init.dma_enable=ENABLE; }
#endif
  if (HAL_PCD_Init(&hpcd_USB_OTG_HS) != HAL_OK)
  {
    Error_Handler();
  }
#if (XE_NP_BOARD_USB_OTG_HS_IDMA_SINGLE_BURST != 0U)
  /*
   * OTG-HS normally uses INCR4 AHB bursts for endpoint DMA.  At 30 kS/s the
   * Neuropixels GPIO request has only one DDR data-valid eye, so an unrelated
   * four-beat USB transaction can delay a peripheral read long enough to
   * sample the adjacent cell.  Keep USB IDMA enabled, but release arbitration
   * after every beat.  Capture GPDMA therefore retains its high-priority,
   * single-request timing without falling back to CPU FIFO service.
   */
  MODIFY_REG(
      hpcd_USB_OTG_HS.Instance->GAHBCFG,
      USB_OTG_GAHBCFG_HBSTLEN,
      USB_OTG_GAHBCFG_HBSTLEN_SINGLE);
#endif
  /* USER CODE BEGIN USB_OTG_HS_Init 2 */

  /* USER CODE END USB_OTG_HS_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, HJ_MODE_Pin|NP_NRST_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, VCC_EN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOG, IO0_Pin|io1_Pin|SD_VSEL_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, HJ_WAKE_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOF, VEE_EN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, LED_Pin|USB_MODE_Pin, GPIO_PIN_RESET);

  /* Keep V2 PSSI inputs and the unused alternate net attachments high-Z
     until capture is armed. */
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Pin = NP1_D2_Pin|NP1_D3_Pin|NP1_D4_Pin|NP1_D6_Pin;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);
  GPIO_InitStruct.Pin = NP1_D5_Pin|NP1_SYNC_Pin|GPIO_PIN_5|GPIO_PIN_15;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
  GPIO_InitStruct.Pin = NP1_D0_Pin;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
  GPIO_InitStruct.Pin = NP1_D1_Pin;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
  GPIO_InitStruct.Pin = GPIO_PIN_4;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
  GPIO_InitStruct.Pin = NP1_PSSI_PDCK_Pin;
  HAL_GPIO_Init(NP1_PSSI_PDCK_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : HJ_MODE_Pin NP_NRST_Pin */
  GPIO_InitStruct.Pin = HJ_MODE_Pin|NP_NRST_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pin : VCC_EN_Pin */
  GPIO_InitStruct.Pin = VCC_EN_Pin;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : IO0_Pin io1_Pin SD_VSEL_Pin */
  GPIO_InitStruct.Pin = IO0_Pin|io1_Pin|SD_VSEL_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

  /*Configure GPIO pin : HJ_WAKE_Pin */
  GPIO_InitStruct.Pin = HJ_WAKE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : VEE_EN_Pin */
  GPIO_InitStruct.Pin = VEE_EN_Pin;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

  /*Configure GPIO pins : LED_Pin USB_MODE_Pin */
  GPIO_InitStruct.Pin = LED_Pin|USB_MODE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : EXT_RX_SYNCCLK_Pin */
  GPIO_InitStruct.Pin = EXT_RX_SYNCCLK_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF14_TIM15;
  HAL_GPIO_Init(EXT_RX_SYNCCLK_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : HJ_STATE_Pin */
  GPIO_InitStruct.Pin = HJ_STATE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(HJ_STATE_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PA8 */
  GPIO_InitStruct.Pin = GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = XE_NP_BOARD_EXPERIMENT_MCO_GPIO_SPEED;
  GPIO_InitStruct.Alternate = GPIO_AF0_MCO;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : BYP_Pin BYPF11_Pin BYPF12_Pin BYPF13_Pin */
  GPIO_InitStruct.Pin = BYP_Pin|BYPF11_Pin|BYPF12_Pin|BYPF13_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

  /*Configure GPIO pin : PB12 */
  GPIO_InitStruct.Pin = GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /*
   * USB384_NP ties PF4 to NP_MCLK along with PA8/MCO. Keep PF4 high-Z/analog;
   * PA8/MCO is either the intended NP MCLK source or disabled in USB-only
   * benchmark clock modes.
   */
  GPIO_InitStruct.Pin = GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

  /* USER CODE END MX_GPIO_Init_2 */
  /* Read the socket contact explicitly; analog-mode IDR is not a valid
   * presence indication. Card protocol identification remains authoritative. */
  GPIO_InitStruct.Pin = SD_DET_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(SD_DET_GPIO_Port, &GPIO_InitStruct);
}

/* USER CODE BEGIN 4 */

int XE_NP_Board_RetrySdInit(void)
{
#if XE_NP_SD_CMD11_PIN_COMPAT_ENABLE
  if(!XE_NP_Cmd11PinSourcesIdle() || !XE_NP_Cmd11SdHostInactive())return -1;
#endif
  uint32_t sdmmc_irq_was_enabled = NVIC_GetEnableIRQ(SDMMC1_IRQn);

  XE_NP_Board_EnsureSdPowerRail();
  HAL_NVIC_DisableIRQ(SDMMC1_IRQn);
  if (XE_NP_Board_ResetSdHostBase() == HAL_OK)
  {
    XE_NP_Board_PostInitSdTuning();
  }
  if(sdmmc_irq_was_enabled != 0U)
  {
    HAL_NVIC_EnableIRQ(SDMMC1_IRQn);
  }
  return (xe_np_sd_init_failed == 0U) ? 0 : -1;
}

int XE_NP_Board_InitSdForUsb(void)
{
  /* MSC does not need to meet NP acquisition admission bandwidth. Identify
   * the card at the safe base profile; no long UHS sweep in a USB command. */
#if XE_NP_SD_CMD11_PIN_COMPAT_ENABLE
  if(!XE_NP_Cmd11PinSourcesIdle() || !XE_NP_Cmd11SdHostInactive())return -1;
#endif
  if(hsd1.Instance != NULL) { (void)HAL_SD_DeInit(&hsd1); }
  XE_NP_Board_ResetSdPowerRail();
  __HAL_RCC_SDMMC1_FORCE_RESET();
  __HAL_RCC_SDMMC1_RELEASE_RESET();
  hsd1.State = HAL_SD_STATE_RESET;
  return XE_NP_Board_InitSdHostBase() == HAL_OK ? 0 : -1;
}

#include "xe_np_sd_info_port.h"
#include "xe_np_usb_selftest_board.inc"

#if XE_NP_USB_UNIFIED_ENABLE
int XE_NP_Board_InitSdDownload(void)
{
#if XE_NP_SD_CMD11_PIN_COMPAT_ENABLE
  if(!XE_NP_Cmd11PinSourcesIdle() || !XE_NP_Cmd11SdHostInactive())return -1;
#endif
  if(XE_NP_Board_InitialSdPowerRail()!=0)return -1;
  MX_SDMMC1_SD_Init();
  XE_NP_Board_RetryColdSdPowerOn();
  return xe_np_sd_init_failed ? -1 : 0;
}
#endif

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */



