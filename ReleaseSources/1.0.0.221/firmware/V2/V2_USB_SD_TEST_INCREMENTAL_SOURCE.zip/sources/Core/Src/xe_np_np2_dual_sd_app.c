#include "xe_np_np2_sd_fine_clock.h"
#if NP_FINE_COUNTER64_ENABLE || XE_NP_NP2_SD_GRID16_ENABLE
#include "xe_np_np2_first_sync_sd.h"
#endif
#include "xe_np_np2_first_sync_runtime.h"
#include "xe_np_np2_usb_sd_test.h"
#include "xe_np_np2_dual_sd_app.h"
#if XE_NP_NP2_DUAL_SD_APP_ENABLE

#include "main.h"
#include "xe_np_np2_dual_sd_catalog_port.h"
#include "xe_np_np2_live_sd.h"
#include "xe_np_np2_sd_ble.h"
#include "xe_np_np2_online.h"
#include "xe_np_np2_config.h"
#include "xe_np_np2_preparation.h"
#if XE_NP_NP2_SD_GRID16_ENABLE
#if !XE_NP_NP2_LIVE_SD_GRID16_ENABLE
#error "SD16 APP needs the matching grid16 writer"
#endif
#include "xe_np_np2_grid16_pool.h"
#endif
#if XE_NP_NP2_SD_CATALOG_ENABLE
#include "xe_np_np2_sd_control.h"
#endif
#include <string.h>
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
#include "xe_np_np2_closed_loop_carrier.h"
#endif

#if !XE_NP_NP2_DUAL_SD_CATALOG_PORT_ENABLE || !XE_NP_NP2_LIVE_SD_ENABLE || \
    !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || XE_NP_IMAGE_ROLE != XE_NP_IMAGE_SD_APP
#error "NP2 SD app needs the catalog and linked-IDMA V2 SD writer"
#endif

#ifndef XE_NP_NP2_SD_FIRST_FAULT_TEST
#define XE_NP_NP2_SD_FIRST_FAULT_TEST 0U
#endif
#if XE_NP_NP2_SD_FIRST_FAULT_TEST!=0U && XE_NP_NP2_SD_FIRST_FAULT_TEST!=1U
#error "First-fault terminal policy must be an explicit boolean"
#endif
#ifndef XE_NP_NP2_SD_BACKUP_FAULT_TEST
#define XE_NP_NP2_SD_BACKUP_FAULT_TEST 0U
#endif
#if (XE_NP_NP2_SD_BACKUP_FAULT_TEST!=0U && XE_NP_NP2_SD_BACKUP_FAULT_TEST!=1U) || \
    (XE_NP_NP2_SD_BACKUP_FAULT_TEST && !XE_NP_NP2_SD_FIRST_FAULT_TEST)
#error "Backup fault receipt requires the first-fault terminal policy"
#endif
#ifndef XE_NP_NP2_SD_SOURCE_FAULT_RECEIPT_TEST
#define XE_NP_NP2_SD_SOURCE_FAULT_RECEIPT_TEST 0U
#endif
#if (XE_NP_NP2_SD_SOURCE_FAULT_RECEIPT_TEST!=0U && XE_NP_NP2_SD_SOURCE_FAULT_RECEIPT_TEST!=1U) || \
    (XE_NP_NP2_SD_SOURCE_FAULT_RECEIPT_TEST && !XE_NP_NP2_SD_BACKUP_FAULT_TEST)
#error "Source-fault receipt requires the existing failure-only backup policy"
#endif
#ifndef XE_NP_NP2_SD_SOURCE_PRESSURE_RECEIPT_TEST
#define XE_NP_NP2_SD_SOURCE_PRESSURE_RECEIPT_TEST 0U
#endif
#if (XE_NP_NP2_SD_SOURCE_PRESSURE_RECEIPT_TEST!=0U && XE_NP_NP2_SD_SOURCE_PRESSURE_RECEIPT_TEST!=1U) || \
    (XE_NP_NP2_SD_SOURCE_PRESSURE_RECEIPT_TEST && \
     (!XE_NP_NP2_SD_SOURCE_FAULT_RECEIPT_TEST || !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || \
      !XE_NP_NP2_LIVE_SD_OVERFLOW_FAULT_DIAG))
#error "Source pressure receipt requires the existing cached overflow fault snapshot"
#endif
#ifndef XE_NP_NP2_SD_SOURCE_COPY_RECEIPT_TEST
#define XE_NP_NP2_SD_SOURCE_COPY_RECEIPT_TEST 0U
#endif
#if (XE_NP_NP2_SD_SOURCE_COPY_RECEIPT_TEST!=0U && XE_NP_NP2_SD_SOURCE_COPY_RECEIPT_TEST!=1U) || \
    (XE_NP_NP2_SD_SOURCE_COPY_RECEIPT_TEST && !XE_NP_NP2_SD_SOURCE_PRESSURE_RECEIPT_TEST)
#error "Source copy receipt requires the existing failure-only pressure receipt"
#endif
#if XE_NP_NP2_SD_SOURCE_PRESSURE_RECEIPT_TEST
#include "xe_np_np2_producer.h"
extern volatile uint32_t xe_np_np2_overflow_fault_diag[];
#endif

_Static_assert(sizeof(XE_NP_Np2DualSdAppMailbox)==104U,"NP2 SD app mailbox ABI");

static SD_HandleTypeDef *card;
static DCACHE_HandleTypeDef *cache;
static XE_NP_Np2DualSdMeta reservation;
#if XE_NP_NP2_SD_GRID16_ENABLE
static XE_NP_Grid16Meta grid_reservation;
static uint8_t reservation_grid16,grid_writer_bound;
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
static uint8_t reservation_grid16_append;
#endif
#endif
static __attribute__((aligned(32))) uint8_t config[2048];
static uint8_t started,stop_pending,finished;
#if XE_NP_NP2_SD_CATALOG_ENABLE
static XE_NP_Np2DualSdCatalogDelete delete_request;
static uint32_t delete_nonce,delete_state,delete_next,delete_blocks,delete_cid[4];
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
static uint8_t reservation_append,append_writer_bound;
#endif
static uint32_t selected_mask=3U;
static XE_NP_Np2OnlineClock session_clock;
static uint64_t scheduled_utc;
static uint32_t scheduled_tick,arm_before,arm_after,arm_valid;
static uint8_t time_sector[512];
volatile XE_NP_Np2DualSdAppMailbox xe_np_np2_dual_sd_app_mailbox
    __attribute__((section("NOINIT"),aligned(32)));
#include "xe_np_np2_sd_idle_sleep.inc"
#ifndef XE_NP_NP2_SD_STOPPED_FEED_TEST
#define XE_NP_NP2_SD_STOPPED_FEED_TEST 0U
#endif
#if XE_NP_NP2_SD_STOPPED_FEED_TEST!=0U && XE_NP_NP2_SD_STOPPED_FEED_TEST!=1U
#error "Stopped source comparator must be an explicit boolean"
#endif
#if XE_NP_NP2_SD_STOPPED_FEED_TEST
#include "xe_np_np2_sd_stopped_feed.inc"
#endif

static void put32(uint8_t *p,uint32_t v)
{p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8U);p[2]=(uint8_t)(v>>16U);p[3]=(uint8_t)(v>>24U);}
static void put64(uint8_t *p,uint64_t v){put32(p,(uint32_t)v);put32(p+4U,(uint32_t)(v>>32U));}
#if XE_NP_NP2_SD_CATALOG_ENABLE
static int catalog_idle(void)
{
    uint32_t state=xe_np_np2_dual_sd_app_mailbox.state;
    uint32_t writer=xe_np_np2_live_sd_mailbox.state;
    return !started && !stop_pending && !scheduled_utc &&
        !xe_np_np2_dual_sd_app_mailbox.error &&
        (writer==XE_NP_NP2_LIVE_SD_BOOT || writer==XE_NP_NP2_LIVE_SD_COMPLETE) &&
        (state==1U || state==5U || state==7U) &&
        !XE_NP_Np2SdControl_PendingMode() && !XE_NP_Np2DualSdCatalog_Reserved() &&
        XE_NP_Np2DualSdCatalogPort_Ready();
}
int XE_NP_Np2DualSdApp_CatalogReady(void)
{return !xe_np_np2_dual_sd_app_mailbox.command && catalog_idle();}
int XE_NP_Np2DualSdApp_QueueDelete(uint32_t nonce,const XE_NP_Np2DualSdCatalogDelete *request)
{
    if(!nonce || !request)return 3;
    if(!XE_NP_Np2DualSdApp_CatalogReady())return 2;
    int result=XE_NP_Np2DualSdCatalogPort_CheckDelete(request);if(result)return result;
    delete_request=*request;delete_nonce=nonce;
    delete_state=xe_np_np2_dual_sd_app_mailbox.state;
    delete_next=xe_np_np2_dual_sd_app_mailbox.next_start_lba;
    delete_blocks=card->SdCard.LogBlockNbr;memcpy(delete_cid,card->CID,sizeof(delete_cid));
    xe_np_np2_dual_sd_app_mailbox.command_error=0U;
    xe_np_np2_dual_sd_app_mailbox.nonce=nonce;
    xe_np_np2_dual_sd_app_mailbox.key=XE_NP_NP2_CATALOG_DELETE_KEY;
    xe_np_np2_dual_sd_app_mailbox.command=XE_NP_NP2_DUAL_SD_CMD_DELETE_LAST;
    return 0;
}
static uint32_t delete_last(uint32_t nonce,uint32_t key)
{
    if(!delete_nonce || delete_nonce!=nonce || key!=XE_NP_NP2_CATALOG_DELETE_KEY)return 9U;
    delete_nonce=0U; /* One execution, including every refused or failed attempt. */
    if(!card || card->SdCard.LogBlockNbr!=delete_blocks || memcmp(card->CID,delete_cid,sizeof(delete_cid)) ||
       xe_np_np2_dual_sd_app_mailbox.state!=delete_state ||
       xe_np_np2_dual_sd_app_mailbox.next_start_lba!=delete_next)return 9U;
    if(!catalog_idle())return 2U;
    uint32_t next;
    int result=XE_NP_Np2DualSdCatalogPort_DeleteLast(&delete_request,&next);
    if(!result)xe_np_np2_dual_sd_app_mailbox.next_start_lba=next;
    return (uint32_t)result;
}
#endif
uint32_t XE_NP_Np2DualSdApp_ProfileMask(void){return selected_mask;}
int XE_NP_Np2DualSdApp_SelectProfile(uint32_t mask,uint32_t rate)
{
    uint32_t state=xe_np_np2_dual_sd_app_mailbox.state;
    if(started || xe_np_np2_dual_sd_app_mailbox.command ||
       (state!=0U && state!=1U && state!=5U && state!=7U) ||
       !XE_NP_Np2DualSd_ProfileTicks(mask,rate) || !XE_NP_Np2LiveSd_SupportsProfile(mask,rate))return -1;
    if(selected_mask!=mask || xe_np_np2_dual_sd_app_mailbox.sample_hz!=rate)
        XE_NP_Np2Preparation_Invalidate(NP2_PREP_PROFILE);
    selected_mask=mask;xe_np_np2_dual_sd_app_mailbox.sample_hz=rate;return 0;
}
static void clock_snapshot(void)
{
    memset(&session_clock,0,sizeof(session_clock));
#if XE_NP_NP2_SD_BLE_ENABLE
    XE_NP_Np2SdBle_ClockSnapshot(&session_clock);
#endif
}
int XE_NP_Np2DualSdApp_Schedule(uint64_t utc)
{
    uint32_t state=xe_np_np2_dual_sd_app_mailbox.state;
    if(state!=1U && state!=5U && state!=7U)return -1;
    clock_snapshot();
    uint32_t now=HAL_GetTick();
    uint64_t current=XE_NP_Np2Online_Utc(&session_clock,now);
    /* Probe configuration happens before the deadline, never at the deadline.
     * Require 60 s lead and at most 24 h, inside signed tick arithmetic. */
    /* Only an explicit future UTC start needs a known clock. Immediate Start
     * records with unknown UTC when optional calibration is unavailable. */
    if(utc && (!current || utc<current+60000000ULL || utc>current+86400000000ULL))return -1;
    XE_NP_Np2Online_RtcFreeze();
    scheduled_utc=utc;scheduled_tick=utc?now+(uint32_t)((utc-current+999U)/1000U):0U;
    return 0;
}
void XE_NP_Np2DualSdApp_CancelSchedule(void)
{
    /* Foreground-only, before START acceptance. Unlike Schedule(0), cleanup
     * must not depend on an unexpired PC-time anchor. Never alter a session. */
    if(started)return;
    scheduled_utc=0U;scheduled_tick=0U;
    memset(&session_clock,0,sizeof(session_clock));
}
int XE_NP_Np2DualSdApp_ArmGate(void)
{
    if(!scheduled_utc)return 1;
    int32_t remaining=(int32_t)(scheduled_tick-HAL_GetTick());
    if(remaining>0){xe_np_np2_dual_sd_app_mailbox.state=XE_NP_NP2_DUAL_SD_ARMED;return 0;}
    /* Never silently convert a missed schedule into an immediate start. */
    return remaining < -5 ? -1 : 1;
}
void XE_NP_Np2DualSdApp_ArmStamp(uint32_t before,uint32_t after)
{arm_before=before;arm_after=after;arm_valid=1U;}
static int save_time(void)
{
    int first_sync=XE_NP_Np2FirstSyncRuntime_SdOpted();
    memset(time_sector,0,sizeof(time_sector));memcpy(time_sector,first_sync?"N2SDUTC2":"N2SDUTC1",8U);
    put32(time_sector+8,first_sync?2U:1U);put32(time_sector+12,reservation.session_id);
    uint64_t utc=XE_NP_Np2Online_Utc(&session_clock,arm_before);
    put32(time_sector+16,(session_clock.valid?1U:0U)|(arm_valid?2U:0U)|(scheduled_utc?4U:0U));
    put32(time_sector+20,session_clock.generation);put32(time_sector+24,session_clock.uncertainty_us);
    put32(time_sector+28,session_clock.tick);put64(time_sector+32,session_clock.utc_us);
    put64(time_sector+40,scheduled_utc);put32(time_sector+48,arm_before);put32(time_sector+52,arm_after);
    put64(time_sector+56,arm_valid?utc:0U);put64(time_sector+64,arm_valid?XE_NP_Np2Online_Utc(&session_clock,arm_after):0U);
    put32(time_sector+72,xe_np_np2_dual_sd_app_mailbox.sample_hz);
    put32(time_sector+76,1000U); /* tick quantization; not sample synchronization */
#if XE_NP_NP2_SD_DRAIN_OVERFLOW_TEST
    /* Reuse this existing stopped write, never serialize counters per block.
     * A new reservation must not inherit the previous session's statistics. */
    uint32_t live=xe_np_np2_live_sd_mailbox.state;
    if(xe_np_np2_dual_sd_app_mailbox.committed_blocks &&
       xe_np_np2_live_sd_mailbox.start_lba==reservation.run.payload_start_lba &&
       (live==XE_NP_NP2_LIVE_SD_DRAINING || live==XE_NP_NP2_LIVE_SD_VERIFYING ||
        live==XE_NP_NP2_LIVE_SD_COMPLETE)){
        put32(time_sector+16,(session_clock.valid?1U:0U)|(arm_valid?2U:0U)|(scheduled_utc?4U:0U)|8U);
        put32(time_sector+80,xe_np_np2_sd_loss.overflow_events);
        put32(time_sector+84,xe_np_np2_sd_loss.dropped_blocks);
        put64(time_sector+88,xe_np_np2_sd_loss.missing_ticks);
        put64(time_sector+96,xe_np_np2_sd_loss.source_end_tick);
        put64(time_sector+104,xe_np_np2_sd_loss.producer_discarded_ticks);
    }
#endif
    /* Opted-in real PSSI capture uses the inner receiver-enable bracket.
     * Legacy Starts keep UTC1/broad arm semantics. The first-sync receipt
     * keeps SourceClock clear until the owner independently qualifies it;
     * neither marker identifies the physical first ADC conversion. No new
     * write is inserted while recording. */
    put32(time_sector+508,XE_NP_Np2DualSd_Crc32(time_sector,508));
    XE_NP_Np2FirstSyncRuntime_SdTime(time_sector);
    return XE_NP_Np2DualSdCatalogPort_Time(time_sector);
}
#if XE_NP_NP2_CLOSED_LOOP_CARRIER_ENABLE
uint32_t XE_NP_Np2DualSdApp_SelectedMask(void){return selected_mask;}
#endif
static void config_plan(uint32_t mask,uint32_t rate,uint32_t blocks)
{
    memset(config,0,sizeof(config));
    memcpy(config,"N2SDCFG1",8U);
    put32(config+8U,1U);
    put32(config+12U,1U); /* planned fixed profile; observed origin unavailable */
    put32(config+16U,rate);put32(config+20U,rate*1600U);
    put32(config+24U,mask);put32(config+28U,mask==1U?7U:mask==3U?63U:511U);
    put32(config+32U,mask==7U?6U:4U);put32(config+36U,mask==1U?3U:mask==3U?6U:9U);
    put32(config+40U,XE_NP_NP2_DUAL_SD_BYTES_PER_BLOCK);
    put32(config+44U,blocks);
    memcpy(config+48U,(const void *)xe_np_np2_dual_sd_app_mailbox.cid,16U);
    /* Preserve the CE64/catalog header. Two immutable selection requests fit
     * in the existing 2048-byte configuration record, without another sector
     * or any per-block processing. This is planned/staged, not applied proof. */
    memcpy(config+64U,mask==7U?"N2IMRO2":"N2IMRO1",7U);
    if(mask==7U)put32(config+12U,3U);
    for(unsigned p=0U;p<3U;p++){
        if(!(mask&(1U<<p)))continue;
        const uint8_t *selection=XE_NP_Np2Config_Selection(p);
        if(selection){
            config[72U]|=(uint8_t)(1U<<p);
            if(mask!=7U){
                put32(config+12U,2U); /* host selection replaces fixed profile */
                memcpy(config+128U+p*N2C_BYTES,selection,N2C_BYTES);
            }else{
                /* Three full requests do not fit. N2IMRO2/kind3 retains only
                 * identity plus request CRC provenance, NOT maps/applied proof. */
                memcpy(config+128U+p*36U,selection+8U,32U);
                put32(config+160U+p*36U,XE_NP_Np2Config_Crc(selection,N2C_BYTES));
            }
        }
    }
}
static void writer_snapshot(void)
{
    xe_np_np2_dual_sd_app_mailbox.writer_state=xe_np_np2_live_sd_mailbox.state;
    xe_np_np2_dual_sd_app_mailbox.writer_error=xe_np_np2_live_sd_mailbox.error;
    xe_np_np2_dual_sd_app_mailbox.writer_verified_blocks=
        xe_np_np2_live_sd_mailbox.verified_blocks;
    xe_np_np2_dual_sd_app_mailbox.committed_blocks=
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
        reservation_grid16_append && grid_writer_bound ? XE_NP_Np2LiveSd_StoredBlocks() :
#endif
        xe_np_np2_live_sd_mailbox.written_rus*4U;
}
#if XE_NP_NP2_SD_BACKUP_FAULT_TEST
static void backup_writer_fault(void)
{
    const volatile XE_NP_Np2LiveSdMailbox *m=&xe_np_np2_live_sd_mailbox;
    if(m->state!=XE_NP_NP2_LIVE_SD_FAILED || !m->error)return;
    /* N2F1: cached first failure only, no SD I/O/live register sampling.
     * BKP0..21 are startup/synthetic diagnostics;28..31 are DFU/boot tokens.
     * Publish valid last; payload LBA distinguishes this test from stale data. */
    RCC->AHB3ENR|=RCC_AHB3ENR_PWREN;RCC->APB3ENR|=RCC_APB3ENR_RTCAPBEN;
    (void)RCC->APB3ENR;PWR->DBPR|=PWR_DBPR_DBP;(void)PWR->DBPR;__DSB();
    TAMP->BKP22R=0U;__DSB();
#if XE_NP_NP2_SD_SOURCE_PRESSURE_RECEIPT_TEST
    if(m->error==XE_NP_NP2_LIVE_SD_ERROR_CAPTURE && !(m->start_lba&255U) &&
       xe_np_np2_live_sd_perf.producer_error<=255U){
        /* N2C1 implies CAPTURE6; keep its exact stage even when the existing
         * SOURCE-only pre-abort owner snapshot was never populated. */
        uint32_t lba=m->start_lba|xe_np_np2_live_sd_perf.producer_error,detail=m->fault_detail;
        uint32_t sequence=m->fault_sequence,capture=m->max_capture_cycles;
        TAMP->BKP23R=lba;TAMP->BKP24R=detail;TAMP->BKP25R=sequence;TAMP->BKP26R=capture;
        TAMP->BKP27R=0x3143324EU^lba^detail^sequence^capture;__DSB();
        TAMP->BKP22R=0x3143324EU;__DSB();
        return;
    }
#endif
#if XE_NP_NP2_SD_SOURCE_FAULT_RECEIPT_TEST
    if(m->error==XE_NP_NP2_LIVE_SD_ERROR_SOURCE && !(m->start_lba&255U) &&
       xe_np_np2_live_sd_perf.producer_error<=255U){
        /* N2S2 implies SOURCE5. Preserve the existing cached detail, produced
         * sequence and raw producer fault/events, not live peripheral state.
         * Payload LBAs are AU-aligned; their unused low byte retains the
         * cached producer error without truncating any diagnostic word.
         * Unaligned/unrepresentable input falls back to ordinary N2F1. */
        uint32_t lba=m->start_lba|xe_np_np2_live_sd_perf.producer_error,detail=m->fault_detail;
        uint32_t sequence=m->fault_sequence,phase=m->phase2;
#if XE_NP_NP2_SD_SOURCE_PRESSURE_RECEIPT_TEST
        const volatile uint32_t *d=xe_np_np2_overflow_fault_diag;
#if XE_NP_NP2_SD_RAW_INGRESS_RU_TEST
        const uint32_t tail=2U,limit=10U;
#else
        const uint32_t tail=0U,limit=9U;
#endif
        if(detail==1U && xe_np_np2_live_sd_perf.producer_error==XE_NP_NP2_PRODUCER_OVERWRITE &&
           d[0]==0x4F46324EU &&
#if XE_NP_NP2_SD_RAW_INGRESS_RU_TEST
           d[1]==5U &&
#else
           (d[1]==3U || d[1]==4U) &&
#endif
           d[2]==1U &&
           d[3]==XE_NP_NP2_LIVE_SD_ERROR_SOURCE && d[4]==detail &&
           d[45U+tail]==sequence && d[50U+tail]==m->cpu_hz && m->ru_count && m->ru_count<=limit &&
           d[24U+tail]<=m->ru_count && d[34U+tail]<=44U && d[27U+tail]<=m->ru_count &&
           d[30U+tail]<=2U && d[41U+tail]<=1U){
            /* N2S3 implies SOURCE5/detail1/OVERWRITE6. Cached PRE-abort owners
             * distinguish pressure from available ingress; full32 timing
             * maxima are cumulative/IRQ-inclusive, not terminal causality. */
            uint32_t owners=d[24U+tail]|(d[34U+tail]<<8U)|(d[27U+tail]<<16U)|
                (d[30U+tail]<<24U)|(d[41U+tail]<<26U);
#if XE_NP_NP2_SD_SOURCE_COPY_RECEIPT_TEST
            if(d[30U+tail] && d[37U+tail]<=65535U && d[40U+tail]<=65535U &&
               d[36U+tail]<=65535U && d[40U+tail]<=d[36U+tail]){
                /* N2S4: same fault/owner binding, existing PRE-abort C14
                 * snapshot only. CCR EN/SUSP/RESET plus pending-leg presence;
                 * full CSR, BNDT16 and total owner age16(ms). Not chronology.
                 * Out-of-range fields retain N2S3, never silently truncate. */
                uint32_t ccr=d[39U+tail],csr=d[38U+tail];
                uint32_t copy=d[40U+tail]|(d[37U+tail]<<16U);
#if !XE_NP_NP2_SD_RAW_INGRESS_RU_TEST
                uint32_t copied=d[35U+tail],leg_age=d[5]-d[51U+tail];
                if((copied==0U || copied==65504U || copied==131008U) &&
                   d[36U+tail]==(copied==131008U?55360U:65504U) &&
                   leg_age<=511U && leg_age<=d[37U+tail]){
                    /* N2S5 adds current leg0/1/2 and age9(ms), using the
                     * same cached three-leg186368B snapshot, not hot counters.
                     * Compact bounded owners: free4/fifo6/fill4/kind2/SD1,
                     * EN/SUSP/RESET/pending1 each, leg2, leg-age9. */
                    uint32_t packed=d[24U+tail]|(d[34U+tail]<<4U)|
                        (d[27U+tail]<<10U)|(d[30U+tail]<<14U)|(d[41U+tail]<<16U)|
                        ((ccr&1U)<<17U)|(((ccr>>2U)&1U)<<18U)|
                        (((ccr>>1U)&1U)<<19U)|(1U<<20U)|
                        ((copied/65504U)<<21U)|(leg_age<<23U);
                    TAMP->BKP23R=lba;TAMP->BKP24R=packed;TAMP->BKP25R=csr;TAMP->BKP26R=copy;
                    TAMP->BKP27R=0x3553324EU^lba^packed^csr^copy;__DSB();
                    TAMP->BKP22R=0x3553324EU;__DSB();
                    return;
                }
#endif
                owners|=((ccr&1U)<<27U)|(((ccr>>2U)&1U)<<28U)|
                    (((ccr>>1U)&1U)<<29U)|((d[36U+tail]!=0U)<<30U);
                TAMP->BKP23R=lba;TAMP->BKP24R=owners;TAMP->BKP25R=csr;TAMP->BKP26R=copy;
                TAMP->BKP27R=0x3453324EU^lba^owners^csr^copy;__DSB();
                TAMP->BKP22R=0x3453324EU;__DSB();
                return;
            }
#endif
            uint32_t capture=m->max_capture_cycles,setup=m->max_cmd25_setup_cycles;
            TAMP->BKP23R=lba;TAMP->BKP24R=owners;TAMP->BKP25R=capture;TAMP->BKP26R=setup;
            TAMP->BKP27R=0x3353324EU^lba^owners^capture^setup;__DSB();
            TAMP->BKP22R=0x3353324EU;__DSB();
            return;
        }
#endif
        TAMP->BKP23R=lba;TAMP->BKP24R=detail;TAMP->BKP25R=sequence;TAMP->BKP26R=phase;
        TAMP->BKP27R=0x3253324EU^lba^detail^sequence^phase;__DSB();
        TAMP->BKP22R=0x3253324EU;__DSB();
        return;
    }
#endif
    uint32_t lba=m->start_lba,error=m->error,sd_error=m->sd_error,sta=m->sd_sta;
    TAMP->BKP23R=lba;TAMP->BKP24R=error;TAMP->BKP25R=sd_error;TAMP->BKP26R=sta;
    TAMP->BKP27R=0x3146324EU^lba^error^sd_error^sta;__DSB();
    TAMP->BKP22R=0x3146324EU;__DSB();
}
#endif
#if NP_FINE_COUNTER64_ENABLE
volatile uint32_t xe_np_np2_sd_fine64_metadata_error,xe_np_np2_sd_rtc_metadata_error;
static void optional_counter64_time(void)
{
    uint8_t anchor[64];
    const XE_NP_Np2FirstSyncSdContext *c=XE_NP_Np2FirstSyncSd_Record();
    const uint32_t uid[3]={HAL_GetUIDw0(),HAL_GetUIDw1(),HAL_GetUIDw2()};
    const uint8_t *rtc;
    xe_np_np2_sd_fine64_metadata_error=xe_np_np2_sd_rtc_metadata_error=0U;
    if(!c || !c->token || !XE_NP_Np2FirstSyncRuntime_FineCounter64() ||
       !XE_NP_Np2FirstSyncRuntime_SdFineAnchor(anchor))return;
    xe_np_np2_sd_fine64_metadata_error=(uint32_t)XE_NP_Np2DualSdCatalogPort_FineCounter64Time(
        time_sector,anchor,uid,c->token);
    if(!xe_np_np2_sd_fine64_metadata_error && (rtc=XE_NP_Np2FirstSyncRuntime_RtcFrozen())!=NULL)
        xe_np_np2_sd_rtc_metadata_error=(uint32_t)XE_NP_Np2DualSdCatalogPort_RtcTime(
            time_sector,anchor,rtc,uid,c->token);
}
#endif

static void terminal_impl(uint32_t state,uint32_t error)
{
    XE_NP_Np2FirstSyncRuntime_Stop();
    if(finished)return;
    finished=1U;writer_snapshot();
#if XE_NP_NP2_SD_BACKUP_FAULT_TEST
    backup_writer_fault();
#endif
    xe_np_np2_dual_sd_app_mailbox.state=XE_NP_NP2_DUAL_SD_FINALIZING;
    uint32_t committed=xe_np_np2_dual_sd_app_mailbox.committed_blocks;
#if XE_NP_NP2_SD_GRID16_ENABLE
    if(reservation_grid16 && !grid_writer_bound){
        committed=0U;xe_np_np2_dual_sd_app_mailbox.committed_blocks=0U;
        xe_np_np2_dual_sd_app_mailbox.writer_verified_blocks=0U;
        /* No writer was admitted. The pool itself refuses to retire if any
         * stage escaped its preflight ownership. */
        (void)XE_NP_Grid16Pool_AbortPrepared();
    }
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    XE_NP_Np2SdAppendCounts append_counts={0};
    if(reservation_append && !append_writer_bound){
        committed=0U;xe_np_np2_dual_sd_app_mailbox.committed_blocks=0U;
        xe_np_np2_dual_sd_app_mailbox.writer_verified_blocks=0U;
    }
    /* A failed pre-start operation must not reuse the previous writer's
     * counts in a NEW reservation. Only a positively admitted Init binds it. */
    if(reservation_append && append_writer_bound && XE_NP_Np2LiveSd_GetAppendCounts(&append_counts)){
        xe_np_np2_dual_sd_app_mailbox.error=error?error:XE_NP_NP2_DUAL_SD_ERROR_FINALIZE;
        xe_np_np2_dual_sd_app_mailbox.state=XE_NP_NP2_DUAL_SD_FAILED;return;
    }
#endif
    if(state==XE_NP_NP2_DUAL_SD_META_COMPLETE &&
       (xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_COMPLETE ||
        xe_np_np2_live_sd_mailbox.error || !committed ||
        committed!=xe_np_np2_live_sd_mailbox.target_blocks ||
        xe_np_np2_live_sd_mailbox.written_rus*XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU!=committed)){
        state=XE_NP_NP2_DUAL_SD_META_FAILED;error=XE_NP_NP2_DUAL_SD_ERROR_WRITER;
    }
#if XE_NP_NP2_SD_FIRST_FAULT_TEST
    /* Terminal-only: an aborted SD transfer may still own the host/card.
     * Leave its declared allocation incomplete; never write a footer over
     * that owner or replace the first writer fault with a secondary failure. */
    if(!card || !card->Instance || card->State!=HAL_SD_STATE_READY ||
       card->ErrorCode!=HAL_SD_ERROR_NONE || card->Instance->IDMACTRL ||
       (card->Instance->DCTRL&SDMMC_DCTRL_DTEN) ||
       (card->Instance->STA&(SDMMC_STA_DPSMACT|SDMMC_STA_CPSMACT|SDMMC_STA_BUSYD0))){
        xe_np_np2_dual_sd_app_mailbox.error=error?error:XE_NP_NP2_DUAL_SD_ERROR_FINALIZE;
        xe_np_np2_dual_sd_app_mailbox.state=XE_NP_NP2_DUAL_SD_FAILED;return;
    }
#endif
    uint32_t stored_error=error;
    if(state==XE_NP_NP2_DUAL_SD_META_FAILED && error==8U && !committed && !arm_valid &&
       xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_COMPLETE &&
       xe_np_np2_live_sd_mailbox.start_lba==reservation.run.payload_start_lba &&
       !xe_np_np2_live_sd_mailbox.target_blocks && !xe_np_np2_live_sd_mailbox.produced_blocks &&
       !xe_np_np2_live_sd_mailbox.written_rus && !xe_np_np2_live_sd_mailbox.verified_blocks &&
       !xe_np_np2_live_sd_mailbox.source_produced_lo && !xe_np_np2_live_sd_mailbox.source_produced_hi &&
       !xe_np_np2_live_sd_mailbox.source_consumed_lo && !xe_np_np2_live_sd_mailbox.source_consumed_hi
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
       && (!reservation_append || (!append_counts.physical_blocks &&
           !append_counts.logical_prefix_blocks && !append_counts.logical_high_water_blocks))
#endif
       )stored_error=XE_NP_NP2_DUAL_SD_META_CANCELLED_EMPTY;
    int finish_error=save_time();
#if XE_NP_NP2_SD_GRID16_ENABLE
    if(!finish_error && reservation_grid16){
        XE_NP_Grid16Footer grid_footer={0};grid_footer.final_exclusive=UINT64_MAX;
        grid_footer.state=state;grid_footer.error=stored_error;grid_footer.np_blocks=committed;
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
        if(reservation_grid16_append)grid_footer.admitted_blocks=UINT32_MAX;
#endif
        /* Optional pool failure leaves the declared reservation fenced; it
         * must never invent sector counts or delay active NP capture. */
        if(grid_writer_bound && !XE_NP_Grid16Pool_Finish(&grid_footer))finish_error=-1;
        else {
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
            if(reservation_grid16_append && grid_writer_bound){
                XE_NP_Grid16Footer counts={0};
                if(XE_NP_Np2LiveSd_GetGrid16AppendCounts(&counts))finish_error=-1;
                else {
                    grid_footer.logical_prefix_blocks=counts.logical_prefix_blocks;
                    grid_footer.logical_high_water_blocks=counts.logical_high_water_blocks;
                    grid_footer.admitted_blocks=counts.admitted_blocks;
                    grid_footer.append_flags=counts.append_flags;
                }
            }
#endif
            if(grid_writer_bound){
                XE_NP_Np2SdGridStatus grid_status={0};uint64_t discarded=0U;
                XE_NP_Np2FirstSyncRuntime_SdGridStatus(&grid_status);
                if(grid_status.started && grid_status.attached){
                    if(!XE_NP_Np2FirstSyncRuntime_SdGridDiscardStopped(&discarded)){
                        grid_footer.flags|=4U;grid_footer.pending_rows_unknown=1U;
                    }
                    else {
                        XE_NP_Np2FirstSyncRuntime_SdGridStatus(&grid_status);
                        grid_footer.unpersisted_rows=discarded;
                        grid_footer.pending_rows_unknown=grid_status.stopped_discarded_pending?1U:0U;
                        if(discarded || grid_status.stopped_discarded_pending)grid_footer.flags|=4U;
                    }
                }
            }
            if(!finish_error)finish_error=XE_NP_Np2DualSdCatalogPort_FinishGrid16(&grid_footer);
        }
    }else
#endif
    if(!finish_error){
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
       finish_error=reservation_append?XE_NP_Np2DualSdCatalogPort_FinishAppend(state,stored_error,&append_counts):
                           XE_NP_Np2DualSdCatalogPort_Finish(state,stored_error,committed);
#else
       finish_error=XE_NP_Np2DualSdCatalogPort_Finish(state,stored_error,committed);
#endif
    }
    if(finish_error){
#if XE_NP_NP2_SD_FIRST_FAULT_TEST
        xe_np_np2_dual_sd_app_mailbox.error=error?error:XE_NP_NP2_DUAL_SD_ERROR_FINALIZE;
#else
        xe_np_np2_dual_sd_app_mailbox.error=XE_NP_NP2_DUAL_SD_ERROR_FINALIZE;
#endif
        xe_np_np2_dual_sd_app_mailbox.state=XE_NP_NP2_DUAL_SD_FAILED;return;
    }
    if(state==XE_NP_NP2_DUAL_SD_META_COMPLETE || error==8U){
        uint32_t next=reservation.reservation_end_lba;
        /* No remount at full capacity: completion is still durable. Start's
         * bounds check will reject a full card. Otherwise mount read-only. */
        if(state==XE_NP_NP2_DUAL_SD_META_COMPLETE || error==8U)
#if XE_NP_NP2_SD_GRID16_ENABLE
            if(reservation_grid16){
                if(state==XE_NP_NP2_DUAL_SD_META_COMPLETE){
                    uint64_t end=(uint64_t)grid_reservation.payload_start+(uint64_t)(committed/4U)*
                        (XE_NP_NP2_DUAL_SD_SECTORS_PER_RU+XE_NP_Grid16_K(grid_reservation.mask,grid_reservation.sample_hz));
                    uint64_t aligned=(end+8191U)&~UINT64_C(8191);
                    next=aligned>UINT32_MAX?card->SdCard.LogBlockNbr:(uint32_t)aligned;
                }
            }else
#endif
            next=(reservation.run.payload_start_lba+committed*XE_NP_NP2_DUAL_SD_SECTORS_PER_BLOCK+8191U)&~8191U;
        if(next<card->SdCard.LogBlockNbr && XE_NP_Np2DualSdCatalogPort_MountAvailable(&next)){
            xe_np_np2_dual_sd_app_mailbox.error=XE_NP_NP2_DUAL_SD_ERROR_MOUNT;
            xe_np_np2_dual_sd_app_mailbox.state=XE_NP_NP2_DUAL_SD_FAILED;return;
        }
        xe_np_np2_dual_sd_app_mailbox.state=error==8U?XE_NP_NP2_DUAL_SD_CANCELLED:XE_NP_NP2_DUAL_SD_COMPLETE;
        xe_np_np2_dual_sd_app_mailbox.next_start_lba=next;
#if NP_FINE_COUNTER64_ENABLE
        /* Primary NN/footer/catalog/remount already succeeded. Optional timing
         * I/O cannot retroactively mark that durable neural session incomplete. */
        if(state==XE_NP_NP2_DUAL_SD_META_COMPLETE)optional_counter64_time();
#endif
        started=0U;stop_pending=0U;
        XE_NP_Np2Online_RtcIdle();
    }else{
        xe_np_np2_dual_sd_app_mailbox.error=error;
        xe_np_np2_dual_sd_app_mailbox.state=XE_NP_NP2_DUAL_SD_FAILED;
    }
}
static void terminal(uint32_t state,uint32_t error)
{
    if(finished)return;
    terminal_impl(state,error);
#if XE_NP_USB_SD_TEST_ENABLE
    XE_NP_Np2UsbSdTest_Terminal(!XE_NP_Np2DualSdCatalog_Reserved(),grid_writer_bound);
#endif
}
static int begin(uint32_t blocks,uint32_t rate,uint32_t nonce)
{
#if XE_NP_NP2_SD_STOPPED_SDR50_100_TEST || XE_NP_NP2_SD_STOPPED_SDR104_120_TEST || XE_NP_NP2_SD_STOPPED_DDR50_40_TEST || XE_NP_NP2_SD_STOPPED_SRAM6_20_TEST
    /* Keep the cached live writer unreachable; retain its layout/call graph. */
    volatile uint32_t stopped_only=1U;
    if(stopped_only)return -1;
#endif
    uint32_t state=xe_np_np2_dual_sd_app_mailbox.state;
    uint32_t mask=selected_mask;
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    /* Consume the fresh opt-in before any profile/preparation can fail. */
    if(!started && (state==1U || state==5U || state==7U))XE_NP_Np2ClCarrier_PortBeginAttempt();
#endif
    if(started || (state!=1U && state!=5U && state!=7U) ||
       blocks<4U || blocks%4U || !XE_NP_Np2DualSd_ProfileTicks(mask,rate) ||
       !XE_NP_Np2LiveSd_SupportsProfile(mask,rate))return -1;
    uint32_t session=HAL_GetTick()^card->CID[0]^card->CID[3]^nonce;
    if(!session)session=1U;
#if XE_NP_NP2_SD_GRID16_ENABLE
    /* Only a fresh v4 wrapper owns a pre-admitted SD16 pool. Versions 1-3
     * and direct legacy Starts retain the exact legacy writer/format. */
    uint32_t grid_k=XE_NP_Grid16_K(mask,rate);
    reservation_grid16=(uint8_t)(grid_k && XE_NP_Np2FirstSyncSd_Grid16Start(nonce));
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
    reservation_grid16_append=(uint8_t)(reservation_grid16 && XE_NP_Np2FirstSyncSd_Grid16AppendStart(nonce));
#endif
    grid_writer_bound=0U;
#endif
    config_plan(mask,rate,blocks);
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    const XE_NP_Np2ClCarrier *cl_owner=0;
    int cl_copied=0;
#if !XE_NP_NP2_LIVE_SD_DIRECT && !XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST && XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
    cl_copied=1;
#endif
    if(XE_NP_Np2ClCarrier_PortPrepare(session,mask,rate,6U,57U,cl_copied)){
        if(XE_NP_Np2ClCarrier_PortConfig(config)==1)cl_owner=XE_NP_Np2ClCarrier_PortOwner();
        else{
            /* Optional configuration cannot block an ordinary recording. */
            XE_NP_Np2ClCarrier_PortStop();memset(config+1888U,0,160U);
        }
    }
#endif
#if XE_NP_NP2_LIVE_SD_VSC_TEST
    uint32_t use_vsc=0U;
#endif
#if XE_NP_NP2_SD_GRID16_ENABLE
    if(reservation_grid16){
        if(XE_NP_Np2DualSdCatalogPort_PlanGrid16(mask,rate,blocks,session,
             XE_NP_Np2DualSd_Crc32(config,sizeof(config)),11U,0U,&grid_reservation)){
            (void)XE_NP_Grid16Pool_AbortPrepared();return -1;
        }
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
        if(reservation_grid16_append)grid_reservation.schema=3U;
#endif
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
        if(cl_owner){grid_reservation.cl_enabled=1U;grid_reservation.cl_crc=cl_owner->config_crc;}
#endif
        memset(&reservation,0,sizeof(reservation));reservation.session_id=session;
        reservation.reservation_start_lba=grid_reservation.reservation_start;
        reservation.reservation_end_lba=grid_reservation.reservation_end;
        reservation.card_blocks=grid_reservation.card_blocks;reservation.config_crc=grid_reservation.config_crc;
        memcpy(reservation.cid,grid_reservation.cid,sizeof(reservation.cid));
        reservation.run.probe_mask=mask;reservation.run.sample_hz=rate;reservation.run.mclk_hz=rate*1600U;
        reservation.run.payload_start_lba=grid_reservation.payload_start;reservation.run.payload_end_lba=grid_reservation.payload_end;
        reservation.run.max_rus=grid_reservation.max_groups;reservation.run.max_blocks=blocks;
        reservation.run.max_source_ticks=(uint64_t)blocks*XE_NP_Np2DualSd_ProfileTicks(mask,rate);
        reservation.run.max_duration_ms=reservation.run.max_source_ticks*1000U/reservation.run.mclk_hz;
    }else{
#endif
#if XE_NP_NP2_LIVE_SD_VSC_TEST
/* CARD_AU_APP_PLAN_BEGIN */
#if XE_NP_NP2_SD_CARD_AU_POLICY_TEST
    int planned=XE_NP_Np2DualSdCatalogPort_PlanCardAuProfile(mask,rate,blocks,session,
                                      XE_NP_Np2DualSd_Crc32(config,sizeof(config)),&reservation);
    use_vsc=reservation.au_blocks!=0U;
#else
    use_vsc=XE_NP_Np2LiveSd_UsesVscProfile(mask,rate);
    int planned=use_vsc?
        XE_NP_Np2DualSdCatalogPort_PlanVscProfile(mask,rate,blocks,session,
                                       XE_NP_Np2DualSd_Crc32(config,sizeof(config)),&reservation):
#if XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST
        XE_NP_Np2DualSdCatalogPort_PlanLegacyAuProfile(mask,rate,blocks,session,
#else
        XE_NP_Np2DualSdCatalogPort_PlanProfile(mask,rate,blocks,session,
#endif
                                       XE_NP_Np2DualSd_Crc32(config,sizeof(config)),&reservation);
#endif
/* CARD_AU_APP_PLAN_END */
    if(planned)return -1;
#else
    if(XE_NP_Np2DualSdCatalogPort_PlanProfile(mask,rate,blocks,session,
                                       XE_NP_Np2DualSd_Crc32(config,sizeof(config)),
                                       &reservation))return -1;
#endif
#if XE_NP_NP2_SD_GRID16_ENABLE
    }
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    reservation_append=(uint8_t)(
#if XE_NP_NP2_SD_GRID16_ENABLE
      !reservation_grid16 &&
#endif
      XE_NP_Np2LiveSd_UsesAppendProfile(mask,rate,use_vsc,
                                       reservation.legacy_au_blocks));
    append_writer_bound=0U;
#endif
    int reserve_error=
#if XE_NP_NP2_SD_GRID16_ENABLE
        reservation_grid16?XE_NP_Np2DualSdCatalogPort_ReserveGrid16(&grid_reservation,config,
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
        cl_owner
#else
        NULL
#endif
        ):
#endif
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
        cl_owner?XE_NP_Np2DualSdCatalogPort_ReserveClosedLoop(&reservation,config,
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
        reservation_append,
#else
        0U,
#endif
        cl_owner):
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
        reservation_append?XE_NP_Np2DualSdCatalogPort_ReserveAppend(&reservation,config):
#endif
        XE_NP_Np2DualSdCatalogPort_Reserve(&reservation,config);
    if(reserve_error){
#if XE_NP_NP2_SD_GRID16_ENABLE
        if(reservation_grid16)(void)XE_NP_Grid16Pool_AbortPrepared();
#endif
        xe_np_np2_dual_sd_app_mailbox.error=XE_NP_NP2_DUAL_SD_ERROR_RESERVE;
        xe_np_np2_dual_sd_app_mailbox.state=XE_NP_NP2_DUAL_SD_FAILED;
        return -1;
    }
    finished=stop_pending=0U;arm_valid=arm_before=arm_after=0U;
    if(!scheduled_utc)clock_snapshot();
    started=1U;xe_np_np2_dual_sd_app_mailbox.session_id=session;
    XE_NP_Np2FirstSyncRuntime_SdPrepare(nonce,session,mask,rate);
    xe_np_np2_dual_sd_app_mailbox.reservation_start_lba=reservation.reservation_start_lba;
    xe_np_np2_dual_sd_app_mailbox.reservation_end_lba=reservation.reservation_end_lba;
    xe_np_np2_dual_sd_app_mailbox.payload_start_lba=reservation.run.payload_start_lba;
    xe_np_np2_dual_sd_app_mailbox.target_blocks=blocks;
    xe_np_np2_dual_sd_app_mailbox.committed_blocks=0U;
    xe_np_np2_dual_sd_app_mailbox.writer_verified_blocks=0U;
    xe_np_np2_dual_sd_app_mailbox.state=XE_NP_NP2_DUAL_SD_PREPARING;
    if(save_time()){terminal(XE_NP_NP2_DUAL_SD_META_FAILED,XE_NP_NP2_DUAL_SD_ERROR_FINALIZE);return -1;}
#if XE_NP_NP2_SD_GRID16_ENABLE
    if(reservation_grid16){
#if XE_NP_NP2_LIVE_SD_VSC_TEST
        if(XE_NP_Np2DualSdCatalogPort_PrepareClassic(&reservation)){
            terminal(XE_NP_NP2_DUAL_SD_META_FAILED,XE_NP_NP2_DUAL_SD_ERROR_RESERVE);return -1;
        }
#endif
        int grid_init_error;
#if XE_NP_NP2_SD_GRID16_APPEND_ENABLE
        if(reservation_grid16_append)
            grid_init_error=XE_NP_Np2LiveSd_InitExtentGrid16Append(card,cache,grid_reservation.payload_start,
                grid_reservation.payload_end,blocks,mask,rate,grid_k,
                XE_NP_Grid16Pool_AcquireAppend,XE_NP_Grid16Pool_ReleaseAppend,XE_NP_Grid16Pool_AppendFault,
                XE_NP_Grid16Pool_CommitAppend,XE_NP_Grid16Pool_SourceStopped,XE_NP_Grid16Pool_PrepareStopAppend,NULL);
        else
#endif
            grid_init_error=XE_NP_Np2LiveSd_InitExtentGrid16(card,cache,grid_reservation.payload_start,
            grid_reservation.payload_end,blocks,mask,rate,grid_k,
            XE_NP_Grid16Pool_Acquire,XE_NP_Grid16Pool_Release,XE_NP_Grid16Pool_Commit,
            XE_NP_Grid16Pool_SourceStopped,XE_NP_Grid16Pool_PrepareStop,NULL);
        if(grid_init_error){
            terminal(XE_NP_NP2_DUAL_SD_META_FAILED,XE_NP_NP2_DUAL_SD_ERROR_WRITER);return -1;
        }
    }else
#endif
#if XE_NP_NP2_LIVE_SD_VSC_TEST
    if(use_vsc){
        if(XE_NP_Np2DualSdCatalogPort_PrepareVsc(&reservation)){
            terminal(XE_NP_NP2_DUAL_SD_META_FAILED,XE_NP_NP2_DUAL_SD_ERROR_RESERVE);return -1;
        }
        XE_NP_Np2LiveSd_InitExtentAuProfile(card,cache,reservation.run.payload_start_lba,blocks,mask,rate,reservation.au_blocks);
    }else{
        if(XE_NP_Np2DualSdCatalogPort_PrepareClassic(&reservation)){
            terminal(XE_NP_NP2_DUAL_SD_META_FAILED,XE_NP_NP2_DUAL_SD_ERROR_RESERVE);return -1;
        }
#if XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
        if(reservation_append){
            if(XE_NP_Np2LiveSd_InitExtentAppendProfile(card,cache,reservation.run.payload_start_lba,
                  blocks,mask,rate,reservation.legacy_au_blocks,reservation.reservation_end_lba)){
                terminal(XE_NP_NP2_DUAL_SD_META_FAILED,XE_NP_NP2_DUAL_SD_ERROR_WRITER);return -1;
            }
        }else
#endif
        XE_NP_Np2LiveSd_InitExtentClassicAuProfile(card,cache,reservation.run.payload_start_lba,
              blocks,mask,rate,reservation.legacy_au_blocks,reservation.reservation_end_lba);
#else
        XE_NP_Np2LiveSd_InitExtentProfile(card,cache,reservation.run.payload_start_lba,blocks,mask,rate);
#endif
    }
#else
    XE_NP_Np2LiveSd_InitExtentProfile(card,cache,reservation.run.payload_start_lba,blocks,mask,rate);
#endif
    /* Init refuses to reset a non-quiescent prior writer. Do not mistake
     * an unchanged old COMPLETE mailbox for a newly completed recording. */
    if(xe_np_np2_live_sd_mailbox.state!=XE_NP_NP2_LIVE_SD_CONFIGURING
#if XE_NP_NP2_SD_GRID16_ENABLE
       || (reservation_grid16 &&
           (xe_np_np2_live_sd_mailbox.start_lba!=grid_reservation.payload_start ||
            xe_np_np2_live_sd_mailbox.target_blocks!=blocks ||
            xe_np_np2_live_sd_mailbox.probe_mask!=mask || xe_np_np2_live_sd_mailbox.sample_hz!=rate))
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
       || (reservation_append &&
           (xe_np_np2_live_sd_mailbox.start_lba!=reservation.run.payload_start_lba ||
            xe_np_np2_live_sd_mailbox.target_blocks!=blocks ||
            xe_np_np2_live_sd_mailbox.probe_mask!=mask || xe_np_np2_live_sd_mailbox.sample_hz!=rate))
#endif
       ){
        terminal(XE_NP_NP2_DUAL_SD_META_FAILED,XE_NP_NP2_DUAL_SD_ERROR_WRITER);
        return -1;
    }
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    append_writer_bound=reservation_append;
#endif
#if XE_NP_NP2_SD_GRID16_ENABLE
    grid_writer_bound=reservation_grid16;
#endif
    writer_snapshot();
    return 0;
}
static void command(void)
{
    uint32_t cmd=xe_np_np2_dual_sd_app_mailbox.command;
    if(!cmd)return;
#if XE_NP_NP2_SD_IDLE_HCLK_TEST
    XE_NP_Np2DualSdApp_WakeClock();
#endif
    uint32_t nonce=xe_np_np2_dual_sd_app_mailbox.nonce;
    if(!nonce || nonce==xe_np_np2_dual_sd_app_mailbox.accepted_nonce)return;
    uint32_t key=xe_np_np2_dual_sd_app_mailbox.key;
    uint32_t blocks=xe_np_np2_dual_sd_app_mailbox.requested_blocks;
    uint32_t rate=xe_np_np2_dual_sd_app_mailbox.sample_hz;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    if(cmd!=XE_NP_NP2_DUAL_SD_CMD_DELETE_LAST || nonce!=delete_nonce)delete_nonce=0U;
#endif
    XE_NP_Np2Online_RtcFreeze();
    xe_np_np2_dual_sd_app_mailbox.accepted_nonce=nonce;
    xe_np_np2_dual_sd_app_mailbox.command_error=0U;
#if XE_NP_NP2_SD_STOPPED_FEED_TEST
    /* Private SWD sentinel retains the actual START clock-change contract;
     * no new BLE opcode or modified clock/UART predicate. Not a live profile. */
    if(cmd==XE_NP_NP2_DUAL_SD_CMD_START && (blocks==0xF12E0D51U || blocks==0xF12E0D52U
#if XE_NP_NP2_SD_STOPPED_SRAM6_TEST
                                         || blocks==0xF12E0D54U
#endif
#if XE_NP_NP2_SD_VSC_FEED_TEST
                                         || blocks==0xF12E0D53U
#endif
                                        )){
        if(key!=XE_NP_NP2_DUAL_SD_START_KEY || sd_feed_test(blocks-0xF12E0D50U,rate,nonce))
            xe_np_np2_dual_sd_app_mailbox.command_error=XE_NP_NP2_DUAL_SD_ERROR_PLAN;
    }else
#endif
    if(cmd==XE_NP_NP2_DUAL_SD_CMD_FORMAT){
        static const uint8_t system[512]="WILD-X V2 dual NP2 SD v11";
        uint32_t next=0U;
        if((xe_np_np2_dual_sd_app_mailbox.state!=XE_NP_NP2_DUAL_SD_UNMOUNTED &&
            xe_np_np2_dual_sd_app_mailbox.state!=XE_NP_NP2_DUAL_SD_IDLE) ||
           key!=XE_NP_NP2_DUAL_SD_FORMAT_KEY || started ||
           XE_NP_Np2DualSdCatalogPort_Format(key,system) ||
           XE_NP_Np2DualSdCatalogPort_Mount(&next))
            xe_np_np2_dual_sd_app_mailbox.command_error=XE_NP_NP2_DUAL_SD_ERROR_FORMAT;
        else {
            xe_np_np2_dual_sd_app_mailbox.next_start_lba=next;
            xe_np_np2_dual_sd_app_mailbox.state=XE_NP_NP2_DUAL_SD_IDLE;
            XE_NP_Np2Preparation_Invalidate(NP2_PREP_RESET);
        }
    }else if(cmd==XE_NP_NP2_DUAL_SD_CMD_MOUNT || cmd==XE_NP_NP2_DUAL_SD_CMD_RECOVER){
        uint32_t next=0U;
        if((xe_np_np2_dual_sd_app_mailbox.state!=XE_NP_NP2_DUAL_SD_UNMOUNTED &&
            xe_np_np2_dual_sd_app_mailbox.state!=XE_NP_NP2_DUAL_SD_IDLE) || started ||
           (cmd==XE_NP_NP2_DUAL_SD_CMD_RECOVER?
            XE_NP_Np2DualSdCatalogPort_Recover(&next):XE_NP_Np2DualSdCatalogPort_MountAvailable(&next)))
            xe_np_np2_dual_sd_app_mailbox.command_error=XE_NP_NP2_DUAL_SD_ERROR_MOUNT;
        else {
            xe_np_np2_dual_sd_app_mailbox.next_start_lba=next;
            xe_np_np2_dual_sd_app_mailbox.state=XE_NP_NP2_DUAL_SD_IDLE;
            XE_NP_Np2Preparation_Invalidate(NP2_PREP_RESET);
        }
    }else if(cmd==XE_NP_NP2_DUAL_SD_CMD_REWIND){
        uint32_t next=0U;
        if(xe_np_np2_dual_sd_app_mailbox.state!=XE_NP_NP2_DUAL_SD_IDLE || started ||
           key!=XE_NP_NP2_CATALOG_REWIND_KEY ||
           XE_NP_Np2DualSdCatalogPort_Rewind(key,blocks,&next))
            xe_np_np2_dual_sd_app_mailbox.command_error=XE_NP_NP2_DUAL_SD_ERROR_MOUNT;
        else {
            xe_np_np2_dual_sd_app_mailbox.next_start_lba=next;
            XE_NP_Np2Preparation_Invalidate(NP2_PREP_RESET);
        }
#if XE_NP_NP2_SD_CATALOG_ENABLE
    }else if(cmd==XE_NP_NP2_DUAL_SD_CMD_DELETE_LAST){
        xe_np_np2_dual_sd_app_mailbox.command_error=delete_last(nonce,key);
        if(!xe_np_np2_dual_sd_app_mailbox.command_error)XE_NP_Np2Preparation_Invalidate(NP2_PREP_RESET);
#endif
    }else if(cmd==XE_NP_NP2_DUAL_SD_CMD_START){
        if(key!=XE_NP_NP2_DUAL_SD_START_KEY || begin(blocks,rate,nonce))
            xe_np_np2_dual_sd_app_mailbox.command_error=XE_NP_NP2_DUAL_SD_ERROR_PLAN;
    }else if(cmd==XE_NP_NP2_DUAL_SD_CMD_STOP){
        if(!started || (xe_np_np2_dual_sd_app_mailbox.state!=XE_NP_NP2_DUAL_SD_PREPARING &&
                        xe_np_np2_dual_sd_app_mailbox.state!=XE_NP_NP2_DUAL_SD_RECORDING &&
                        xe_np_np2_dual_sd_app_mailbox.state!=XE_NP_NP2_DUAL_SD_ARMED))
            xe_np_np2_dual_sd_app_mailbox.command_error=XE_NP_NP2_DUAL_SD_ERROR_WRITER;
        else {stop_pending=1U;XE_NP_Np2Preparation_Invalidate(NP2_PREP_STOP);}
    }else xe_np_np2_dual_sd_app_mailbox.command_error=XE_NP_NP2_DUAL_SD_ERROR_PLAN;
    xe_np_np2_dual_sd_app_mailbox.command=XE_NP_NP2_DUAL_SD_CMD_NONE;
#if XE_NP_USB_SD_TEST_ENABLE
    if(cmd==XE_NP_NP2_DUAL_SD_CMD_START && xe_np_np2_dual_sd_app_mailbox.command_error)
        XE_NP_Np2UsbSdTest_StartRejected();
#endif
}
int XE_NP_Np2DualSdApp_Init(SD_HandleTypeDef *input,DCACHE_HandleTypeDef *input_cache)
{
    XE_NP_Np2FirstSyncRuntime_Init();
    XE_NP_Np2Preparation_Invalidate(NP2_PREP_RESET);
    selected_mask=3U;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    delete_nonce=0U;
#endif
    memset((void *)&xe_np_np2_dual_sd_app_mailbox,0,sizeof(xe_np_np2_dual_sd_app_mailbox));
    xe_np_np2_dual_sd_app_mailbox.magic=XE_NP_NP2_DUAL_SD_APP_MAGIC;
    xe_np_np2_dual_sd_app_mailbox.version=XE_NP_NP2_DUAL_SD_APP_VERSION;
    xe_np_np2_dual_sd_app_mailbox.state=XE_NP_NP2_DUAL_SD_UNMOUNTED;
    if(!input || !input_cache || XE_NP_Np2DualSdCatalogPort_Bind(input)){
        xe_np_np2_dual_sd_app_mailbox.error=XE_NP_NP2_DUAL_SD_ERROR_BIND;
        xe_np_np2_dual_sd_app_mailbox.state=XE_NP_NP2_DUAL_SD_FAILED;return -1;
    }
    card=input;cache=input_cache;
    xe_np_np2_dual_sd_app_mailbox.card_blocks=card->SdCard.LogBlockNbr;
    for(uint32_t i=0U;i<4U;i++)xe_np_np2_dual_sd_app_mailbox.cid[i]=card->CID[i];
    uint32_t next=0U;
    if(XE_NP_Np2DualSdCatalogPort_MountAvailable(&next)==0){
        xe_np_np2_dual_sd_app_mailbox.next_start_lba=next;
        xe_np_np2_dual_sd_app_mailbox.state=XE_NP_NP2_DUAL_SD_IDLE;
    }
    return 0;
}
void XE_NP_Np2DualSdApp_Service(void)
{
    if(!card || (xe_np_np2_dual_sd_app_mailbox.state==XE_NP_NP2_DUAL_SD_FAILED
#if XE_NP_NP2_SD_CATALOG_ENABLE
                 && xe_np_np2_dual_sd_app_mailbox.command!=XE_NP_NP2_DUAL_SD_CMD_DELETE_LAST
#endif
                ))return;
    command();
    if(!started || finished){
#if XE_NP_NP2_PREPARATION_ENABLE
        uint32_t idle_state=xe_np_np2_dual_sd_app_mailbox.state;
        if(!xe_np_np2_dual_sd_app_mailbox.command &&
           (idle_state==XE_NP_NP2_DUAL_SD_IDLE || idle_state==XE_NP_NP2_DUAL_SD_COMPLETE ||
            idle_state==XE_NP_NP2_DUAL_SD_CANCELLED))
            XE_NP_Np2Preparation_Service(NP_PREP_SD);
#endif
        sd_app_idle_sleep();return;
    }
    if(stop_pending && xe_np_np2_live_sd_mailbox.state==XE_NP_NP2_LIVE_SD_CONFIGURING){
        int cancelled=XE_NP_Np2LiveSd_CancelPrepared();
        if(cancelled==0){
            terminal(XE_NP_NP2_DUAL_SD_META_FAILED,8U);return;
        }
#if XE_NP_NP2_LIVE_SD_VSC_TEST
        /* Do not let a pending CMD20 close advance into producer->arm. */
        if(cancelled>0)return;
#endif
    }
    XE_NP_Np2LiveSd_Service();
    XE_NP_Np2FirstSyncRuntime_Service();
    uint32_t state=xe_np_np2_live_sd_mailbox.state;
    if(state==XE_NP_NP2_LIVE_SD_CAPTURING){
        if(xe_np_np2_dual_sd_app_mailbox.state!=XE_NP_NP2_DUAL_SD_RECORDING){
            xe_np_np2_dual_sd_app_mailbox.state=XE_NP_NP2_DUAL_SD_RECORDING;
            writer_snapshot();
        }
        if(stop_pending){
            if(XE_NP_Np2LiveSd_RequestStop()==0)
                xe_np_np2_dual_sd_app_mailbox.target_blocks=
                    xe_np_np2_live_sd_mailbox.target_blocks;
            stop_pending=0U;
        }
    }else if(state==XE_NP_NP2_LIVE_SD_DRAINING){
        /* Snapshot only phase transitions, never each capture/service iteration. */
        if(xe_np_np2_dual_sd_app_mailbox.writer_state!=state){
            xe_np_np2_dual_sd_app_mailbox.state=XE_NP_NP2_DUAL_SD_FINALIZING;
            writer_snapshot();
        }
    }else if(state==XE_NP_NP2_LIVE_SD_COMPLETE){
        terminal(XE_NP_NP2_DUAL_SD_META_COMPLETE,0U);
    }else if(state==XE_NP_NP2_LIVE_SD_FAILED){
        terminal(XE_NP_NP2_DUAL_SD_META_FAILED,
                 xe_np_np2_live_sd_mailbox.error?xe_np_np2_live_sd_mailbox.error:
                 XE_NP_NP2_DUAL_SD_ERROR_WRITER);
    }
}
#endif
