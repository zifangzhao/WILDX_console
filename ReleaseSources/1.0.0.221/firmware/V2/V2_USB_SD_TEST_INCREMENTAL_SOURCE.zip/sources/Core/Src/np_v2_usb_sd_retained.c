#include "np_v2_usb_sd_retained.h"
#include <string.h>

#define RECORD_MAGIC UINT32_C(0x4A324E50)
#define RECORD_VERSION 1U
#define RECORD_BYTES 416U
#define PLAN_OFFSET 32U
#define REPORT_OFFSET 160U

static void fence(const NpV2SdRetained *s)
{if(s->barrier)s->barrier(s->context);}

static uint32_t record_crc(const uint8_t b[RECORD_BYTES])
{
    uint32_t c=np_usb_sd_crc_update(UINT32_MAX,b+4U,20U);
    return np_usb_sd_crc_update(c,b+PLAN_OFFSET,RECORD_BYTES-PLAN_OFFSET)^UINT32_MAX;
}

static int report_matches(const uint8_t plan[128],const uint8_t report[256],uint32_t phase)
{
    NpUsbSdTestPlan p;NpUsbSdTestReport r;
    if(!np_usb_sd_plan_decode(&p,plan,128U) || !np_usb_sd_report_decode(&r,report,256U) ||
       r.words[4]!=phase || r.words[8]!=(uint32_t)p.ticket ||
       r.words[9]!=(uint32_t)(p.ticket>>32U) || r.words[10]!=np_usb_sd_u32(plan+60U))return 0;
    if((phase==NP_USB_SD_PHASE_QUEUED || phase==NP_USB_SD_PHASE_ACCEPTED ||
        phase==NP_USB_SD_PHASE_RUNNING) && r.words[5]!=NP_USB_SD_OUTCOME_PENDING)return 0;
    if(phase==NP_USB_SD_PHASE_INTERRUPTED_UNKNOWN && r.words[5]!=NP_USB_SD_OUTCOME_INTERRUPTED)return 0;
    if((phase==NP_USB_SD_PHASE_FINISHED || phase==NP_USB_SD_PHASE_REJECTED) &&
       (r.words[5]==NP_USB_SD_OUTCOME_PENDING || r.words[5]==NP_USB_SD_OUTCOME_INTERRUPTED))return 0;
    return 1;
}

int np_v2_sd_retained_inspect(const NpV2SdRetained *s,NpV2SdSnapshot *out)
{
    if(!s || !s->bank || !out)return NP_V2_SD_CORRUPT;
    uint8_t b[RECORD_BYTES];uint32_t any=0U;
    for(uint32_t i=0U;i<RECORD_BYTES;i++){b[i]=s->bank[i];any|=b[i];}
    if(!any)return NP_V2_SD_EMPTY;
    uint32_t magic=np_usb_sd_u32(b),version=np_usb_sd_u32(b+4U);
    uint32_t generation=np_usb_sd_u32(b+8U),inverse=np_usb_sd_u32(b+12U);
    uint32_t phase=np_usb_sd_u32(b+16U),target=np_usb_sd_u32(b+20U);
    uint32_t crc=np_usb_sd_u32(b+24U),crc_inverse=np_usb_sd_u32(b+28U);
    if(magic!=RECORD_MAGIC || version!=RECORD_VERSION || !generation || inverse!=~generation ||
       crc_inverse!=~crc || crc!=record_crc(b) ||
       phase<NP_USB_SD_PHASE_QUEUED || phase>NP_USB_SD_PHASE_INTERRUPTED_UNKNOWN ||
       ((phase==NP_USB_SD_PHASE_ACCEPTED)?target!=NP_V2_SD_ROLE_APP:
        (phase==NP_USB_SD_PHASE_FINISHED || phase==NP_USB_SD_PHASE_REJECTED)?
         (target!=NP_V2_SD_ROLE_NONE && target!=NP_V2_SD_ROLE_USB):target!=NP_V2_SD_ROLE_NONE) ||
       !report_matches(b+PLAN_OFFSET,b+REPORT_OFFSET,phase))return NP_V2_SD_CORRUPT;
    out->generation=generation;out->phase=phase;out->expected_role=target;
    memcpy(out->plan,b+PLAN_OFFSET,128U);memcpy(out->report,b+REPORT_OFFSET,256U);
    return NP_V2_SD_VALID;
}

static int commit(const NpV2SdRetained *s,const NpV2SdSnapshot *v)
{
    if(!s || !s->bank || !v || !v->generation ||
       !report_matches(v->plan,v->report,v->phase))return 0;
    uint8_t b[RECORD_BYTES]={0};
    np_usb_sd_put32(b,RECORD_MAGIC);np_usb_sd_put32(b+4U,RECORD_VERSION);
    np_usb_sd_put32(b+8U,v->generation);np_usb_sd_put32(b+12U,~v->generation);
    np_usb_sd_put32(b+16U,v->phase);np_usb_sd_put32(b+20U,v->expected_role);
    memcpy(b+PLAN_OFFSET,v->plan,128U);memcpy(b+REPORT_OFFSET,v->report,256U);
    uint32_t crc=record_crc(b);np_usb_sd_put32(b+24U,crc);np_usb_sd_put32(b+28U,~crc);
    /* Invalidate first; write the full commit marker only after body+CRC. */
    for(uint32_t i=0U;i<4U;i++)s->bank[i]=0U;
    fence(s);
    for(uint32_t i=4U;i<RECORD_BYTES;i++)s->bank[i]=b[i];
    fence(s);
    for(uint32_t i=0U;i<4U;i++)s->bank[i]=b[i];
    fence(s);
    NpV2SdSnapshot check;
    return np_v2_sd_retained_inspect(s,&check)==NP_V2_SD_VALID &&
        check.generation==v->generation && check.phase==v->phase &&
        check.expected_role==v->expected_role && !memcmp(check.plan,v->plan,128U) &&
        !memcmp(check.report,v->report,256U);
}

int np_v2_sd_retained_clear(const NpV2SdRetained *s)
{
    if(!s || !s->bank)return 0;
    NpV2SdSnapshot old;int status=np_v2_sd_retained_inspect(s,&old);
    if(status==NP_V2_SD_VALID && old.phase!=NP_USB_SD_PHASE_FINISHED &&
       old.phase!=NP_USB_SD_PHASE_REJECTED)return 0;
    for(uint32_t i=0U;i<4U;i++)s->bank[i]=0U;
    fence(s);
    for(uint32_t i=4U;i<NP_V2_SD_RETAINED_BANK_BYTES;i++)s->bank[i]=0U;
    fence(s);return 1;
}

int np_v2_sd_retained_submit(const NpV2SdRetained *s,const uint8_t plan[128],
                             const uint8_t report[256])
{
    NpUsbSdTestPlan decoded;NpV2SdSnapshot v;int status;
    if(!plan || !np_usb_sd_plan_decode(&decoded,plan,128U))return NP_V2_SD_INVALID;
    status=np_v2_sd_retained_inspect(s,&v);
    if(status==NP_V2_SD_CORRUPT)return NP_V2_SD_IO_ERROR;
    if(status==NP_V2_SD_EMPTY)return NP_V2_SD_INVALID;
    if(status==NP_V2_SD_VALID){
        if(np_usb_sd_u64(v.plan+8U)==decoded.ticket)
            return memcmp(v.plan,plan,128U)?NP_V2_SD_INVALID:NP_V2_SD_DUPLICATE;
        if(v.phase!=NP_USB_SD_PHASE_FINISHED && v.phase!=NP_USB_SD_PHASE_REJECTED)return NP_V2_SD_BUSY;
        if(v.generation==UINT32_MAX)return NP_V2_SD_IO_ERROR;
        v.generation++;
    }
    if(np_usb_sd_u32(plan+56U)!=0U || !report || !report_matches(plan,report,NP_USB_SD_PHASE_QUEUED))return NP_V2_SD_INVALID;
    v.phase=NP_USB_SD_PHASE_QUEUED;v.expected_role=NP_V2_SD_ROLE_NONE;
    memcpy(v.plan,plan,128U);memcpy(v.report,report,256U);
    return commit(s,&v)?NP_V2_SD_NEW:NP_V2_SD_IO_ERROR;
}

int np_v2_sd_retained_submit_reconciled(const NpV2SdRetained *s,const uint8_t plan[128],
                                        const uint8_t report[256],int manual_fresh_proof)
{
    NpUsbSdTestPlan decoded;NpUsbSdTestReport observed;NpV2SdSnapshot old;
    if(!plan || !np_usb_sd_plan_decode(&decoded,plan,128U))return NP_V2_SD_INVALID;
    int status=np_v2_sd_retained_inspect(s,&old);
    if(status==NP_V2_SD_VALID){
        if(np_usb_sd_u64(old.plan+8U)==decoded.ticket)
            return memcmp(old.plan,plan,128U)?NP_V2_SD_INVALID:NP_V2_SD_DUPLICATE;
        if(old.phase==NP_USB_SD_PHASE_QUEUED || old.phase==NP_USB_SD_PHASE_ACCEPTED ||
           old.phase==NP_USB_SD_PHASE_RUNNING)return NP_V2_SD_BUSY;
    }
    const uint32_t required=NP_USB_SD_VALID_IDENTITY|NP_USB_SD_VALID_CATALOG|
        NP_USB_SD_VALID_SOURCE_QUIET|NP_USB_SD_VALID_SD_QUIET|
        NP_USB_SD_VALID_APPEND;
    if(manual_fresh_proof!=1 || np_usb_sd_u32(plan+56U)!=1U || !report ||
       !report_matches(plan,report,NP_USB_SD_PHASE_QUEUED) ||
       !np_usb_sd_report_decode(&observed,report,256U) ||
       (observed.words[6]&required)!=required || observed.words[25]!=decoded.expected_frontier || observed.words[26]!=0U ||
       observed.words[20]!=decoded.capacity)return NP_V2_SD_INVALID;
    for(unsigned i=0;i<3U;i++)if(observed.words[17U+i]!=decoded.uid[i])return NP_V2_SD_INVALID;
    for(unsigned i=0;i<4U;i++)if(observed.words[21U+i]!=decoded.cid[i])return NP_V2_SD_INVALID;
    if(status==NP_V2_SD_VALID && old.phase!=NP_USB_SD_PHASE_INTERRUPTED_UNKNOWN &&
       old.phase!=NP_USB_SD_PHASE_FINISHED && old.phase!=NP_USB_SD_PHASE_REJECTED)return NP_V2_SD_BUSY;
    if(status==NP_V2_SD_VALID && old.generation==UINT32_MAX)return NP_V2_SD_IO_ERROR;
    old.generation=status==NP_V2_SD_VALID?old.generation+1U:1U;
    old.phase=NP_USB_SD_PHASE_QUEUED;old.expected_role=NP_V2_SD_ROLE_NONE;
    memcpy(old.plan,plan,128U);memcpy(old.report,report,256U);
    return commit(s,&old)?NP_V2_SD_NEW:NP_V2_SD_IO_ERROR;
}

static int phase_change(const NpV2SdRetained *s,NpV2SdSnapshot *v,uint32_t phase,
                        uint32_t outcome,uint32_t target)
{
    NpUsbSdTestReport r;
    if(v->generation==UINT32_MAX || !np_usb_sd_report_decode(&r,v->report,256U))return 0;
    r.words[4]=phase;r.words[5]=outcome;
    if(target==NP_V2_SD_ROLE_APP)r.words[6]|=NP_USB_SD_VALID_HANDOFF;
    else r.words[6]&=~NP_USB_SD_VALID_HANDOFF;
    if(!np_usb_sd_report_encode(v->report,256U,&r))return 0;
    v->generation++;v->phase=phase;v->expected_role=target;return commit(s,v);
}

int np_v2_sd_retained_accept(const NpV2SdRetained *s)
{
    NpV2SdSnapshot v;NpUsbSdTestReport report;
    if(np_v2_sd_retained_inspect(s,&v)!=NP_V2_SD_VALID || v.phase!=NP_USB_SD_PHASE_QUEUED ||
       !np_usb_sd_report_decode(&report,v.report,256U) || !(report.words[6]&NP_USB_SD_VALID_HANDOFF))return 0;
    return phase_change(s,&v,NP_USB_SD_PHASE_ACCEPTED,NP_USB_SD_OUTCOME_PENDING,NP_V2_SD_ROLE_APP);
}

int np_v2_sd_retained_boot(const NpV2SdRetained *s,uint32_t reset,uint32_t role)
{
    NpV2SdSnapshot v;int status=np_v2_sd_retained_inspect(s,&v);
    if(status==NP_V2_SD_EMPTY)return NP_V2_SD_BOOT_IDLE;
    if(status!=NP_V2_SD_VALID)return NP_V2_SD_BOOT_INVALID;
    NpUsbSdTestReport report;
    if(v.phase==NP_USB_SD_PHASE_ACCEPTED && v.expected_role==NP_V2_SD_ROLE_APP &&
       reset==NP_V2_SD_RESET_SOFTWARE && role==NP_V2_SD_ROLE_APP &&
       np_usb_sd_report_decode(&report,v.report,256U) && (report.words[6]&NP_USB_SD_VALID_HANDOFF)){
        if(!phase_change(s,&v,NP_USB_SD_PHASE_RUNNING,NP_USB_SD_OUTCOME_PENDING,NP_V2_SD_ROLE_NONE))return NP_V2_SD_BOOT_INVALID;
        return NP_V2_SD_BOOT_DISPATCH;
    }
    if(v.phase==NP_USB_SD_PHASE_QUEUED || v.phase==NP_USB_SD_PHASE_ACCEPTED || v.phase==NP_USB_SD_PHASE_RUNNING){
        if(!phase_change(s,&v,NP_USB_SD_PHASE_INTERRUPTED_UNKNOWN,NP_USB_SD_OUTCOME_INTERRUPTED,NP_V2_SD_ROLE_NONE))return NP_V2_SD_BOOT_INVALID;
        return NP_V2_SD_BOOT_INTERRUPTED;
    }
    if(v.expected_role!=NP_V2_SD_ROLE_NONE){
        /* Retain terminal report exactly even on an unexpected reset. */
        if(v.generation==UINT32_MAX)return NP_V2_SD_BOOT_INVALID;
        v.generation++;v.expected_role=NP_V2_SD_ROLE_NONE;
        if(!commit(s,&v))return NP_V2_SD_BOOT_INVALID;
    }
    return NP_V2_SD_BOOT_IDLE;
}

int np_v2_sd_retained_finish(const NpV2SdRetained *s,const uint8_t report[256],int request_usb)
{
    NpV2SdSnapshot v;NpUsbSdTestReport r;
    if(!report || (request_usb!=0 && request_usb!=1) ||
       np_v2_sd_retained_inspect(s,&v)!=NP_V2_SD_VALID || v.phase!=NP_USB_SD_PHASE_RUNNING ||
       !np_usb_sd_report_decode(&r,report,256U) || v.generation==UINT32_MAX ||
       (r.words[4]!=NP_USB_SD_PHASE_FINISHED && r.words[4]!=NP_USB_SD_PHASE_REJECTED) ||
       !report_matches(v.plan,report,r.words[4]))return 0;
    if(r.words[4]==NP_USB_SD_PHASE_REJECTED && !(r.words[6]&NP_USB_SD_VALID_REJECTED_UNMUTATED))return 0;
    if(r.words[4]==NP_USB_SD_PHASE_FINISHED && !(r.words[6]&NP_USB_SD_VALID_TERMINAL))return 0;
    if(request_usb){
        uint32_t required=NP_USB_SD_VALID_SOURCE_QUIET|NP_USB_SD_VALID_SD_QUIET;
        if((r.words[6]&required)!=required)return 0;
        if(r.words[4]==NP_USB_SD_PHASE_FINISHED && !(r.words[6]&NP_USB_SD_VALID_CATALOG))return 0;
    }
    v.generation++;v.phase=r.words[4];v.expected_role=request_usb?NP_V2_SD_ROLE_USB:NP_V2_SD_ROLE_NONE;
    memcpy(v.report,report,256U);return commit(s,&v);
}

int np_v2_sd_retained_reject(const NpV2SdRetained *s,const uint8_t report[256])
{
    NpV2SdSnapshot v;NpUsbSdTestReport r;
    if(!report || np_v2_sd_retained_inspect(s,&v)!=NP_V2_SD_VALID ||
       (v.phase!=NP_USB_SD_PHASE_QUEUED && v.phase!=NP_USB_SD_PHASE_ACCEPTED) ||
       v.generation==UINT32_MAX || !np_usb_sd_report_decode(&r,report,256U) ||
       !(r.words[6]&NP_USB_SD_VALID_REJECTED_UNMUTATED) ||
       !report_matches(v.plan,report,NP_USB_SD_PHASE_REJECTED))return 0;
    v.generation++;v.phase=NP_USB_SD_PHASE_REJECTED;v.expected_role=NP_V2_SD_ROLE_NONE;
    memcpy(v.report,report,256U);return commit(s,&v);
}
