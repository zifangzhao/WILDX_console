"""One affected-unit APP build, then one USB build pinned to that APP CRC."""
from pathlib import Path
import hashlib,json,re,subprocess,sys,struct,zlib
B=Path(__file__).resolve().parent;ROOT=Path(r'D:\Code\XE_NP_V2')
ARM=Path('C:/Keil_v5/ARM/ARMCLANG/bin')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
frozen=json.loads((B/'integration/canonical-receipt.json').read_text())
for rel,pin in frozen['sources'].items():assert sha(ROOT/rel)==pin,rel
APPBASE=Path(r'C:\Frank\Code\XE_NP\_artifacts\grid16_append_main\build-app')
USBBASE=Path(r'C:\Frank\Code\XE_NP\_artifacts\grid16_append_main\build-usb-r2')
assert sha(APPBASE/'application.bin')=='BCBCB5566739BDA7D82B44E0C6B065AF592A5963C11AFDF4945E5CE2CAEA5579'
assert sha(USBBASE/'application.bin')=='527BCCEC86CCF7C46ED69292AB55695A2DF8A09FEE5F2B1B936146F90D19298B'
aplan=json.loads(Path(r'C:\Frank\Code\XE_NP\_artifacts\grid16_sd_build_r8\plan.json').read_text())['commands']
amain=json.loads((ROOT/'_artifacts/v2_release_overlay_20261025/app/build-v9/incremental-build.json').read_text())['compiler_args_by_unit']['main']
uplan=json.loads((ROOT/'_artifacts/v2_grid_source_20261029/usb-grid-candidate/plan.json').read_text())
uflags=json.loads((ROOT/'_artifacts/v2_grid_source_20261029/usb-grid-enforced-r2/result.json').read_text())['flags']

def recipe(role,unit,out,appcrc):
 if role=='app':
  cmd=list(amain if unit=='main' else aplan.get(unit,aplan['xe_np_np2_sd_control']))
  if not cmd[0].endswith('armclang.exe'):cmd=[str(ARM/'armclang.exe'),*cmd]
 else:
  cmd=[str(ARM/'armclang.exe'),*(uplan['flags'] if unit=='main' else uflags)]
 keys=['XE_NP_USB_SD_TEST_ENABLE','XE_NP_USB_SD_TEST_APP_CRC32','XE_NP_NP2_SD_GRID16_ENABLE','XE_NP_NP2_SD_GRID16_APPEND_ENABLE']
 cmd=[x for x in cmd if not any(x.startswith('-D'+k+'=') for k in keys)]
 cmd[1:1]=['-DXE_NP_USB_SD_TEST_ENABLE=1U','-DXE_NP_USB_SD_TEST_APP_CRC32=0x'+appcrc+'UL',
  '-DXE_NP_NP2_SD_GRID16_ENABLE=1U','-DXE_NP_NP2_SD_GRID16_APPEND_ENABLE='+('1U' if role=='app' else '0U'),
  '-I',str(ROOT/'Core/Inc'),'-I',str(ROOT/'Shared/Timing')]
 if role=='app' and unit=='xe_np_np2_usb_sd_test':
  # This terminal-only observer must see the recorder's existing loss counters.
  cmd=[x for x in cmd if not x.startswith('-DXE_NP_NP2_SD_DRAIN_OVERFLOW_TEST=')]
  cmd.insert(1,'-DXE_NP_NP2_SD_DRAIN_OVERFLOW_TEST=1U')
 source=str(ROOT/'Core/Src'/f'{unit}.c');target=str(out/f'{unit}.o')
 if '-c' in cmd:cmd[cmd.index('-c')+1]=source
 else:cmd+=['-c',source]
 if '-o' in cmd:cmd[cmd.index('-o')+1]=target
 else:cmd+=['-o',target]
 if '-MF' in cmd:cmd[cmd.index('-MF')+1]=str(out/f'{unit}.d')
 assert '-O3' in cmd;return cmd

def run(cmd,out,name):
 p=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True)
 (out/(name+'.log')).write_text(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError(name+' failed; see '+str(out/(name+'.log')))

def build(role,base,appcrc='00000000'):
 out=B/('build-'+role);out.mkdir(exist_ok=True)
 changed=['main','xe_np_usb_sd_test_job','np_v2_usb_sd_retained']
 changed+=['xe_np_np2_sd_control','xe_np_np2_dual_sd_app','xe_np_np2_usb_sd_test','xe_np_np2_live_sd'] if role=='app' else ['xe_np_usb_stream']
 lnp=(base/'application.lnp').read_text();objects=re.findall(r'"([^"\r\n]+\.o)"',lnp)
 retained={p:sha(p) for p in objects};commands={}
 for unit in changed:
  cmd=recipe(role,unit,out,appcrc);commands[unit]=cmd
  # Resume only completed unchanged units after an actual compiler/link failure.
  pin=out/(unit+'.compile.json');key=hashlib.sha256(json.dumps(cmd).encode()+Path(cmd[cmd.index('-c')+1]).read_bytes()).hexdigest()
  if not (pin.exists() and json.loads(pin.read_text()).get('key')==key and (out/f'{unit}.o').exists()):
   run(cmd,out,unit);pin.write_text(json.dumps({'key':key,'command':cmd})+'\n')
  old=[p for p in objects if Path(p).stem==unit]
  if old:
   assert len(old)==1;lnp=lnp.replace(old[0],(out/f'{unit}.o').as_posix())
  else:lnp='"'+(out/f'{unit}.o').as_posix()+'"\n'+lnp
 for p,pin in retained.items():assert sha(p)==pin,p
 lnp=lnp.replace((base/'application.axf').as_posix(),(out/'application.axf').as_posix()).replace((base/'application.map').as_posix(),(out/'application.map').as_posix())
 (out/'application.lnp').write_text(lnp)
 run([str(ARM/'armlink.exe'),'--via',str(out/'application.lnp')],out,'link')
 run([str(ARM/'fromelf.exe'),'--bin','--output',str(out/'application.bin'),str(out/'application.axf')],out,'fromelf')
 body=(out/'application.bin').read_bytes();sp,pc=struct.unpack_from('<II',body)
 sys.path.insert(0,str(ROOT/'Tools'));import package_xe_np_firmware as pkg
 from verify_xe_np_slot_hex import verify
 pkg.LOADER_ABI_VERSION=4
 manifest=pkg.build_manifest(body,generation=3,image_id=pkg.IMAGE_ID_APPLICATION if role=='app' else pkg.IMAGE_ID_USB_SERVICE,usb_auto_app=(role=='usb'))
 hexfile=out/('V2_'+role.upper()+'_USB_SD_TEST_CANDIDATE.hex')
 pkg.write_intel_hex(hexfile,pkg.sealed_slot_memory(body,manifest));hexfile.write_bytes(hexfile.read_bytes().replace(b'\r\n',b'\n'));verify(hexfile,body,manifest)
 (out/'application.manifest.bin').write_bytes(manifest)
 d={'role':role,'status':'CANDIDATE_NOT_HARDWARE_QUALIFIED','parent_body_sha256':sha(base/'application.bin'),
  'integration_sha256':sha(B/'integration/canonical-receipt.json'),'compiler_commands':commands,'retained_objects':retained,
  'body_sha256':sha(out/'application.bin'),'crc32':f'{zlib.crc32(body):08X}','body_bytes':len(body),'sp':hex(sp),'reset':hex(pc),
  'hex_sha256':sha(hexfile),'expected_app_crc32':appcrc,'recompiled':changed,
  'execution_regions':re.findall(r'Execution Region[^\r\n]+',(out/'application.map').read_text(errors='replace'))}
 (out/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d[k] for k in ['role','crc32','body_bytes','sp','hex_sha256']}),flush=True);return d

if __name__=='__main__':
 a=build('app',APPBASE);build('usb',USBBASE,a['crc32'])
