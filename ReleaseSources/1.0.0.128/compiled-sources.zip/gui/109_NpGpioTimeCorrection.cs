using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
using System.Threading;

namespace USB512_interface
{
    // Derived event times only; raw RTC events and clock queries are preserved.
    internal static class NpGpioTimeCorrection
    {
        const string CsvName="gpio_rtc_events.timestamps.calibrated.csv",ReportName="gpio_timestamp_calibration.json";
        sealed class Query {internal double Device,Send,Receive;internal string Epoch;}
        static double Number(string s){return Double.Parse(s,CultureInfo.InvariantCulture);}
        static bool Finite(double value){return !Double.IsNaN(value)&&!Double.IsInfinity(value);}
        static string F(double value){return value.ToString("R",CultureInfo.InvariantCulture);}
        static string EventValue(string line,string key){var m=Regex.Match(line,@"(?:^|, )"+Regex.Escape(key)+@": ([^,]+)");return m.Success?m.Groups[1].Value:null;}
        internal static string Correct(string folder,bool replace=false)
        {
            folder=Path.GetFullPath(folder);string events=Path.Combine(folder,"gpio_rtc_events.txt"),sync=Path.Combine(folder,"gpio_rtc_sync.csv"),target=Path.Combine(folder,CsvName);
            if(File.Exists(target)&&!replace)throw new IOException("GPIO calibrated timestamps already exist; use ReplaceDerived to regenerate them.");
            if(!File.Exists(events)||!File.Exists(sync))return "{\"status\":\"unavailable\",\"reason\":\"GPIO raw events/queries missing\"}";
            var queries=new Dictionary<uint,Query>();var points=new List<Query>();
            using(var reader=new StreamReader(sync)) {
                string[] header=(reader.ReadLine()??"").Split(',');int epoch=Array.IndexOf(header,"host_epoch"),pc=Array.IndexOf(header,"host_pc_unix_us");
                if(epoch<0||pc<0)return WriteReport(folder,new{schema=1,status="unavailable",reason="Legacy GPIO log has no shared QPC/PC observations."});
                string line;while((line=reader.ReadLine())!=null) {
                    var c=line.Split(',');uint id;if(c.Length<=Math.Max(epoch,pc)||!UInt32.TryParse(c[1],out id)||String.IsNullOrEmpty(c[pc]))continue;
                    if(c[0]=="query")queries[id]=new Query {Send=Number(c[pc]),Epoch=c[epoch]};
                    else if(c[0]=="reply"&&c[2]!=""&&c[4]!="") {
                        Query q;if(!queries.TryGetValue(id,out q))continue;queries.Remove(id);q.Receive=Number(c[pc]);q.Device=Number(c[4]);
                        if(q.Epoch!=c[epoch]||!Finite(q.Send)||!Finite(q.Receive)||!Finite(q.Device)||q.Send<1577836800000000||q.Receive>4102444800000000||
                            q.Receive<q.Send||q.Receive-q.Send>5000000||q.Device%1!=0||q.Device<0||q.Device>253402300799999)continue;
                        if(points.Count>0&&(q.Device<points[points.Count-1].Device||q.Send<points[points.Count-1].Send))
                            return WriteReport(folder,new{schema=1,status="unavailable",reason="GPIO RTC reset/clock reversal requires separate epochs; raw observations retained."});
                        if(points.Count>0&&q.Device==points[points.Count-1].Device){if(q.Receive-q.Send<points[points.Count-1].Receive-points[points.Count-1].Send)points[points.Count-1]=q;}
                        else points.Add(q);
                    }
                }
            }
            if(points.Count<2||points.Select(p=>p.Epoch).Distinct().Count()!=1)return WriteReport(folder,new{schema=1,status="unavailable",reason="Insufficient consistent shared-PC GPIO clock queries."});
            string temporary=target+"."+Guid.NewGuid().ToString("N")+".partial";long count=0,mapped=0;int at=0;
            try {
                using(var output=new StreamWriter(temporary,false,new UTF8Encoding(false))) {
                    output.WriteLine("event_index,channel,sequence,device_rtc_ms,pc_unix_seconds,pc_lower_unix_seconds,pc_upper_unix_seconds,host_epoch,status");
                    foreach(string line in File.ReadLines(events)) {
                        if(String.IsNullOrWhiteSpace(line))continue;
                        string device=EventValue(line,"DeviceMs"),sequence=EventValue(line,"Sequence"),channel=EventValue(line,"Data"),raw=EventValue(line,"PcClock");
                        double d;uint seq;byte ch;if(!Double.TryParse(device,NumberStyles.None,CultureInfo.InvariantCulture,out d)||!UInt32.TryParse(sequence,out seq)||!Byte.TryParse(channel,out ch))throw new InvalidDataException("Malformed GPIO event at row "+count);
                        while(at+1<points.Count&&points[at+1].Device<d)at++;
                        Query a=points[at],b=at+1<points.Count?points[at+1]:null;
                        bool valid=raw==a.Epoch&&b!=null&&d>=a.Device&&d<=b.Device&&b.Device-a.Device>1&&b.Device-a.Device<=10000;
                        string values=",,,",status="clock_not_bracketed";
                        if(valid) {
                            double f=(d-a.Device)/(b.Device-a.Device);
                            // Both query and event use integer device RTC milliseconds.
                            // Their unknown sub-ms phases can differ by up to 1 ms.
                            double quantum=Math.Max(1000,(b.Receive-a.Send)/(b.Device-a.Device-1));
                            double lo=a.Send+f*(b.Send-a.Send)-quantum,hi=a.Receive+f*(b.Receive-a.Receive)+quantum;
                            values=F((lo+hi)/2000000)+","+F(lo/1000000)+","+F(hi/1000000)+",";status="mapped";mapped++;
                        }
                        output.WriteLine(count+","+ch+","+seq+","+device+","+values+(raw??"")+","+status);count++;
                    }
                }
                if(File.Exists(target))File.Replace(temporary,target,null);else File.Move(temporary,target);
            }finally{if(File.Exists(temporary))File.Delete(temporary);}
            return WriteReport(folder,new{schema=1,status="written",file=CsvName,events=count,mapped_events=mapped,unmapped_events=count-mapped,clock_queries=points.Count,
                host_epoch=points[0].Epoch,reference="Same QPC-to-PC Unix axis as NP derived timestamps; network correction separate.",
                mapping="Linear interpolation between bracketing device/PC query intervals, maximum 10-second query gap; no extrapolation.",
                limitation="Conditional clock mapping with integer-RTC phase uncertainty. Physical GPIO edge/IRQ and probe ADC/filter/receiver latency are not measured."});
        }
        static string WriteReport(string folder,object value){
            string text=new JavaScriptSerializer().Serialize(value),path=Path.Combine(folder,ReportName),temporary=path+"."+Guid.NewGuid().ToString("N")+".partial";
            try{File.WriteAllText(temporary,text);if(File.Exists(path))File.Replace(temporary,path,null);else File.Move(temporary,path);}
            finally{if(File.Exists(temporary))File.Delete(temporary);}return text;
        }
        internal static void Automatic(string folder){try{Correct(folder);}catch(Exception ex){try{WriteReport(folder,new{schema=1,status="unavailable",reason=ex.Message});}catch{}}}
        internal static void Queue(string folder)
        {
            if(File.Exists(Path.Combine(folder,CsvName)))return;
            try{WriteReport(folder,new{schema=1,status="processing",reference="Shared NP/GPIO PC epoch; raw files preserved."});}catch{}
            ThreadPool.QueueUserWorkItem(_=>Automatic(folder));
        }
    }
}
