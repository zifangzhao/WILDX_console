"""Retain exact proven USB main; replace only the sensor startup port."""
import json,sys,shutil
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path[:0]=[str(ROOT/'Tools/V2SdLogger'),str(ROOT/'Tools/V2Usb'),str(ROOT/'Tools')]
from build_np_start_anchor import build
from build_checked_np_start_anchor import seal
from build_usb_rate_fix import digest
from build_once import stack_evidence
import validate_np2_live_sd_memory as ram
base=HERE/'port-fence-build/usb'
r=json.loads((base/'incremental-build.json').read_text(encoding='utf-8-sig'))
assert r['body_crc32']=='14849D61' and digest(base/'application.bin')==r['body_sha256']
source_dir=HERE/'startup-port-source';source_dir.mkdir()
source=source_dir/'xe_np_sensors_port.c';shutil.copyfile(ROOT/'Core/Src/xe_np_sensors_port.c',source)
tree=HERE/'consumer-inputs';ram.CMSIS=tree/'Drivers/CMSIS/Device/ST/STM32U5xx/Include/stm32u595xx.h'
work=HERE/'startup-port-build'
build('USB',str(base.relative_to(ROOT)),r['body_sha256'],{'xe_np_sensors_port':r['compiler_args_by_unit']['xe_np_sensors_port']},
      sources={'xe_np_sensors_port':source},includes=[tree/'Core/Inc',tree/'Core/Src'],work=work)
out=work/'usb';stack=stack_evidence(out/'application.htm');seal(out,'USB')
hexpath=out/'timing_candidate.hex';hexpath.write_bytes(hexpath.read_bytes().replace(b'\r\n',b'\n'))
r=json.loads((out/'incremental-build.json').read_text())
r.update(static_stack=stack,hex_sha256=digest(hexpath),manifest_sha256=digest(out/'application.manifest.bin'),
 scope='14849D61 exact retained USB main/R2/data plane; sensor-port-only unconfigured/Resume SETTLING exception, capture-unarmed/AUX-off; no source status queries after IMU setup',
 hardware_validated=False,published=False)
(out/'incremental-build.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8',newline='\n')
print('PRIVATE USB '+r['body_crc32']+'; one O3 sensor-port unit, exact retained USB main; hardware warm-return qualification pending')
