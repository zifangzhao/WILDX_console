"""Actual sensor port/core lifecycle with modeled I2C and Cortex IRQ endpoints.

This checks software quiescence and recovery policy, not sensor wiring, RCC
transitions, HAL peripheral timing or recording throughput.
"""
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
VC = Path(r"C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat")

NATIVE = r'''
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "xe_np_sensors.h"
#define XE_NP_IMAGE_ROLE MODEL_IMAGE_ROLE
#define XE_NP_NP2_USB_SOURCE_ENABLE 1U
#define XE_NP_BOARD_BME280_I2C_WIRING_CONFIRMED 0U
typedef enum { HAL_OK, HAL_ERROR, HAL_BUSY } HAL_StatusTypeDef;
typedef enum { I2C5_EV_IRQn, I2C5_ER_IRQn, I2C6_EV_IRQn, I2C6_ER_IRQn } IRQn_Type;
typedef struct { uint32_t CR1; } I2cRegisters;
typedef struct {
 I2cRegisters *Instance;void (*XferISR)(void);uint32_t State,Lock;
} I2C_HandleTypeDef;
#define I2C_CR1_PE 1U
#define I2C_CR1_TXIE 2U
#define I2C_CR1_RXIE 4U
#define I2C_CR1_ADDRIE 8U
#define I2C_CR1_NACKIE 16U
#define I2C_CR1_STOPIE 32U
#define I2C_CR1_TCIE 64U
#define I2C_CR1_ERRIE 128U
#define MODEL_OWNED_BITS 255U
#define MODEL_UNRELATED_BIT 0x8000U
#define I2C_MEMADD_SIZE_8BIT 1U
#define I2C_ANALOGFILTER_ENABLE 1U
#define HAL_I2C_STATE_READY 1U
#define HAL_UNLOCKED 0U
#define CLEAR_BIT(reg,bits) ((reg)&=~(bits))
#define __DMB() ((void)0)
#define __DSB() ((void)0)
static I2cRegisters model_regs[2];
static I2C_HandleTypeDef model_handles[2];
static uint32_t model_ms,model_primask,model_ipsr,model_disable_calls;
static uint32_t model_enabled[8],model_pending[8],model_priority[8];
static uint32_t model_init[2],model_deinit[2],model_analog[2],model_digital[2],model_io[2];
static uint32_t model_fail;
static uint8_t model_source_busy,model_capture_armed,model_aux_running;
static uint32_t model_armed_calls,model_source_queries,model_source_state;
static struct {uint32_t state,command;} xe_np_np2_dual_sd_app_mailbox;
typedef struct {uint32_t state;} XE_NP_Np2UsbSourceStatus;
#define XE_NP_NP2_DUAL_SD_CMD_START 2U
#define XE_NP_NP2_DUAL_SD_PREPARING 2U
#define XE_NP_NP2_DUAL_SD_RECORDING 3U
#define XE_NP_NP2_DUAL_SD_FINALIZING 4U
#define XE_NP_NP2_DUAL_SD_ARMED 6U
#define XE_NP_NP2_USB_SOURCE_SETTLING 8U
static int XE_NP_Np2UsbSource_IsBusy(void){return model_source_busy;}
static int XE_NP_Np2CapturePort_Armed(void){model_armed_calls++;return model_capture_armed;}
static int XE_NP_UsbAux_IsRunning(void){return model_aux_running;}
static void XE_NP_Np2UsbSource_GetStatus(XE_NP_Np2UsbSourceStatus *out)
{model_source_queries++;out->state=model_source_state;}
#include "actual_guard.inc"
static uint32_t HAL_GetTick(void){return model_ms;}
static uint32_t __get_PRIMASK(void){return model_primask;}
static void __disable_irq(void){model_primask=1U;model_disable_calls++;}
static void __set_PRIMASK(uint32_t key){model_primask=key;}
static void HAL_NVIC_EnableIRQ(IRQn_Type irq){model_enabled[irq]=1U;}
static void HAL_NVIC_DisableIRQ(IRQn_Type irq){model_enabled[irq]=0U;}
static void HAL_NVIC_ClearPendingIRQ(IRQn_Type irq){model_pending[irq]=0U;}
static void HAL_NVIC_SetPriority(IRQn_Type irq,uint32_t priority,uint32_t sub)
{assert(sub==0U);model_priority[irq]=priority;}
static unsigned model_bus(I2C_HandleTypeDef *h)
{assert(h==&model_handles[0]||h==&model_handles[1]);return h==&model_handles[0]?0U:1U;}
static void model_transfer_isr(void){}
static HAL_StatusTypeDef model_transfer(I2C_HandleTypeDef *h,uint16_t address,
 uint16_t reg,uint16_t size,uint8_t *data,uint16_t length)
{
 unsigned bus=model_bus(h);(void)reg;
 assert(address==0xd0U||address==0xd2U||address==0xecU||address==0xeeU);
 assert(size==I2C_MEMADD_SIZE_8BIT && data && length>0U);
 model_io[bus]++;h->State=2U;h->XferISR=model_transfer_isr;
 h->Instance->CR1|=MODEL_OWNED_BITS;return HAL_OK;
}
static HAL_StatusTypeDef HAL_I2C_Mem_Read_IT(I2C_HandleTypeDef *h,uint16_t address,
 uint16_t reg,uint16_t size,uint8_t *data,uint16_t length)
{return model_transfer(h,address,reg,size,data,length);}
static HAL_StatusTypeDef HAL_I2C_Mem_Write_IT(I2C_HandleTypeDef *h,uint16_t address,
 uint16_t reg,uint16_t size,uint8_t *data,uint16_t length)
{return model_transfer(h,address,reg,size,data,length);}
static HAL_StatusTypeDef HAL_I2C_Init(I2C_HandleTypeDef *h)
{
 unsigned bus=model_bus(h);assert(model_ipsr==0U);model_init[bus]++;
 if(model_fail==1U)return HAL_ERROR;
 h->State=HAL_I2C_STATE_READY;h->Instance->CR1|=I2C_CR1_PE;return HAL_OK;
}
static HAL_StatusTypeDef HAL_I2C_DeInit(I2C_HandleTypeDef *h)
{
 unsigned bus=model_bus(h);assert(model_ipsr==0U);model_deinit[bus]++;
 h->Instance->CR1=0U;h->XferISR=NULL;return HAL_OK;
}
static HAL_StatusTypeDef HAL_I2CEx_ConfigAnalogFilter(I2C_HandleTypeDef *h,uint32_t filter)
{assert(filter==I2C_ANALOGFILTER_ENABLE);model_analog[model_bus(h)]++;return model_fail==2U?HAL_ERROR:HAL_OK;}
static HAL_StatusTypeDef HAL_I2CEx_ConfigDigitalFilter(I2C_HandleTypeDef *h,uint32_t filter)
{assert(filter==0U);model_digital[model_bus(h)]++;return model_fail==3U?HAL_ERROR:HAL_OK;}
#include "actual_port.inc"
static void model_fresh(void)
{
 memset(model_regs,0,sizeof(model_regs));memset(model_handles,0,sizeof(model_handles));
 memset(model_enabled,0,sizeof(model_enabled));memset(model_pending,0,sizeof(model_pending));
 memset(model_priority,0,sizeof(model_priority));memset(model_init,0,sizeof(model_init));
 memset(model_deinit,0,sizeof(model_deinit));memset(model_analog,0,sizeof(model_analog));
 memset(model_digital,0,sizeof(model_digital));memset(model_io,0,sizeof(model_io));
 for(unsigned bus=0U;bus<2U;bus++)model_handles[bus].Instance=&model_regs[bus];
 model_ms=100U;model_primask=model_ipsr=model_fail=model_disable_calls=0U;
 model_source_busy=model_capture_armed=model_aux_running=0U;
 model_armed_calls=model_source_queries=model_source_state=0U;
 memset(&xe_np_np2_dual_sd_app_mailbox,0,sizeof(xe_np_np2_dual_sd_app_mailbox));
 initialized=0U;paused=0U;xe_np_sensor_snapshot_index=0U;
 model_enabled[7]=model_pending[7]=1U;model_priority[7]=3U;
 XE_NP_SensorsPort_Init(&model_handles[0],&model_handles[1]);
 assert(sensors.snapshot.enabled==1U && !sensors.device[1].enabled);
 assert(model_enabled[I2C5_EV_IRQn] && model_enabled[I2C5_ER_IRQn]);
 assert(!model_enabled[I2C6_EV_IRQn] && !model_enabled[I2C6_ER_IRQn]);
}
static void model_disabled_environment(void)
{
 assert(!model_init[1] && !model_deinit[1] && !model_analog[1] && !model_digital[1] && !model_io[1]);
 assert(XE_NP_SensorsPort_GetSnapshot()->error[1]==XE_NP_SENSOR_ERR_DISABLED);
}
int main(void)
{
 XE_NP_SensorsPort_Pause();XE_NP_SensorsPort_Resume();XE_NP_SensorsPort_Service(0U);
 assert(!initialized && !paused && !model_disable_calls);
 /* USB sample-rate changes may resume only in the unarmed analog settle. */
 model_fresh();XE_NP_SensorsPort_Pause();XE_NP_SensorsPort_Resume();
 model_source_busy=1U;model_source_state=7U;
 assert(consumer_recording());XE_NP_SensorsPort_Service(consumer_recording());
 assert(paused==2U && !model_init[0]);
 model_source_state=XE_NP_NP2_USB_SOURCE_SETTLING;
 assert(consumer_recording());XE_NP_SensorsPort_Service(consumer_recording());
#if MODEL_IMAGE_ROLE==2U
 assert(!paused && model_init[0]==1U);
#else
 assert(paused==2U && !model_init[0]);
#endif
 model_capture_armed=1U;model_source_queries=0U;
 assert(consumer_recording() && !model_source_queries);
 model_fresh();
 /* Actual SD consumer: only stable, unarmed analog settling admits setup. */
 for(unsigned owner=0U;owner<4U;owner++){
  model_fresh();XE_NP_SensorsPort_Pause();XE_NP_SensorsPort_Resume();
  const uint32_t blocked_states[4]={1U,XE_NP_NP2_DUAL_SD_ARMED,
      XE_NP_NP2_DUAL_SD_RECORDING,XE_NP_NP2_DUAL_SD_FINALIZING};
  xe_np_np2_dual_sd_app_mailbox.state=blocked_states[owner];
  xe_np_np2_dual_sd_app_mailbox.command=owner==0U?XE_NP_NP2_DUAL_SD_CMD_START:0U;
  assert(consumer_sd_recording());XE_NP_SensorsPort_Service(consumer_sd_recording());
  assert(paused==2U && !model_init[0] && !model_io[0]);
#if MODEL_IMAGE_ROLE==1U
  assert(!model_armed_calls && !model_source_queries);
#endif
 }
 model_fresh();XE_NP_SensorsPort_Pause();XE_NP_SensorsPort_Resume();
 xe_np_np2_dual_sd_app_mailbox.state=XE_NP_NP2_DUAL_SD_PREPARING;
 model_source_state=7U;assert(consumer_sd_recording());
 XE_NP_SensorsPort_Service(consumer_sd_recording());assert(paused==2U && !model_init[0]);
 model_source_state=XE_NP_NP2_USB_SOURCE_SETTLING;assert(!consumer_sd_recording());
 XE_NP_SensorsPort_Service(consumer_sd_recording());assert(!paused && model_init[0]==1U);
 model_ms+=20U;XE_NP_SensorsPort_Service(consumer_sd_recording());
 assert(model_io[0]==1U && sensors.device[0].pending);
 model_capture_armed=1U;uint32_t queries=model_source_queries;
 assert(consumer_sd_recording() && model_source_queries==queries);
 sensors.device[0].data[0]=0xd8U;model_ms++;
 assert(XE_NP_SensorsPort_Complete(&model_handles[0],0U));
 XE_NP_SensorsPort_Service(consumer_sd_recording());
 assert(model_io[0]==1U && !sensors.device[0].pending && model_source_queries==queries);
 model_fresh();XE_NP_SensorsPort_Pause();
 xe_np_np2_dual_sd_app_mailbox.state=XE_NP_NP2_DUAL_SD_PREPARING;
 model_source_state=XE_NP_NP2_USB_SOURCE_SETTLING;
 XE_NP_SensorsPort_Service(consumer_sd_recording());assert(paused==1U && !model_init[0]);
 for(unsigned owner=0U;owner<2U;owner++){
  model_fresh();model_ms=120U;model_source_busy=(uint8_t)(owner==0U);
  model_capture_armed=(uint8_t)(owner==1U);
  for(unsigned pass=0U;pass<100U;pass++){model_ms++;XE_NP_SensorsPort_Service(consumer_recording());}
  assert(!model_io[0] && !sensors.device[0].pending && !model_init[0]);
  model_source_busy=model_capture_armed=0U;XE_NP_SensorsPort_Service(consumer_recording());
  assert(model_io[0]==1U && sensors.device[0].pending);
 }
 model_fresh();model_ms=120U;XE_NP_SensorsPort_Service(0U);
 sensors.device[0].data[0]=0xd8U;model_ms=121U;model_source_busy=1U;
 assert(XE_NP_SensorsPort_Complete(&model_handles[0],0U));
 XE_NP_SensorsPort_Service(consumer_recording());
 assert(model_io[0]==1U && !sensors.device[0].pending && !sensors.device[0].completion);
 model_source_busy=0U;model_capture_armed=1U;model_ms=2121U;
 XE_NP_SensorsPort_Service(consumer_recording());assert(model_io[0]==1U);
 model_capture_armed=0U;XE_NP_SensorsPort_Service(consumer_recording());
 assert(model_io[0]==2U && sensors.device[0].pending); /* reset resumes only idle */
 for(uint32_t key=0U;key<2U;key++){
  model_fresh();model_ms=120U;XE_NP_SensorsPort_Service(0U);
  assert(model_io[0]==1U && sensors.device[0].pending && model_handles[0].XferISR);
  sensors.snapshot.valid=7U;
  for(unsigned bus=0U;bus<2U;bus++)model_regs[bus].CR1|=MODEL_OWNED_BITS|MODEL_UNRELATED_BIT;
  for(unsigned irq=0U;irq<4U;irq++)model_pending[irq]=1U;
  model_primask=key;XE_NP_SensorsPort_Pause();
  assert(paused==1U && model_primask==key && model_disable_calls==1U && !sensors.snapshot.valid);
  for(unsigned bus=0U;bus<2U;bus++){
   assert(model_regs[bus].CR1==MODEL_UNRELATED_BIT && !model_handles[bus].XferISR);
  }
  for(unsigned irq=0U;irq<4U;irq++)assert(!model_enabled[irq] && !model_pending[irq] && model_priority[irq]==7U);
  assert(model_enabled[7] && model_pending[7] && model_priority[7]==3U);
  uint32_t completed=sensors.device[0].completed_token;
  assert(!XE_NP_SensorsPort_Complete(&model_handles[0],0U));
  assert(sensors.device[0].completed_token==completed && !sensors.device[0].completion);
  const XE_NP_SensorSnapshot *snapshot=XE_NP_SensorsPort_GetSnapshot();
  assert(snapshot->magic==0x31534e53U && snapshot->version==1U && !snapshot->valid && snapshot->error[0]==XE_NP_SENSOR_ERR_BUSY);
  model_ms=10000U;XE_NP_SensorsPort_Service(0U);assert(model_io[0]==1U && !model_init[0]);
  assert(start(NULL,0U,0x68U,0U,sensors.device[0].data,1U,0U,99U)==1 && model_io[0]==1U);
  model_ipsr=16U;XE_NP_SensorsPort_Resume();assert(paused==2U && !model_init[0]);
  assert(!XE_NP_SensorsPort_Complete(&model_handles[0],0U) && !XE_NP_SensorsPort_GetSnapshot()->valid);
  model_ipsr=0U;model_primask=0U;XE_NP_SensorsPort_Service(1U);
  assert(paused==2U && !model_init[0] && !model_analog[0] && !model_digital[0]);
  XE_NP_SensorsPort_Service(0U);
  assert(!paused && model_init[0]==1U && model_analog[0]==1U && model_digital[0]==1U);
  assert(!sensors.device[0].pending && !sensors.device[0].completion && model_io[0]==1U);
  assert(model_enabled[I2C5_EV_IRQn] && model_enabled[I2C5_ER_IRQn]);
  for(unsigned pass=0U;pass<10U;pass++)XE_NP_SensorsPort_Service(1U);
  assert(model_init[0]==1U && model_io[0]==1U);model_disabled_environment();
 }
 for(uint32_t failure=1U;failure<=3U;failure++){
  model_fresh();XE_NP_SensorsPort_Pause();XE_NP_SensorsPort_Resume();model_fail=failure;
  XE_NP_SensorsPort_Service(0U);
  assert(paused && model_init[0]==1U && !model_enabled[I2C5_EV_IRQn] && !model_enabled[I2C5_ER_IRQn]);
  assert(!XE_NP_SensorsPort_GetSnapshot()->valid && !XE_NP_SensorsPort_Complete(&model_handles[0],1U));
  model_ms=2099U;XE_NP_SensorsPort_Service(0U);assert(model_init[0]==1U);
  model_ms=2100U;XE_NP_SensorsPort_Service(0U);assert(paused==3U && model_init[0]==2U);
  for(unsigned pass=0U;pass<10U;pass++)XE_NP_SensorsPort_Service(0U);
  assert(model_init[0]==2U); /* no tight retry loop after failure */
  uint32_t analog=model_analog[0],digital=model_digital[0];
  for(unsigned owner=0U;owner<3U;owner++){
   model_source_busy=(uint8_t)(owner==0U);model_capture_armed=(uint8_t)(owner==1U);
   model_aux_running=(uint8_t)(owner==2U);assert(consumer_recording());
   for(unsigned pass=0U;pass<3U;pass++){model_ms+=2000U;XE_NP_SensorsPort_Service(consumer_recording());}
  }
  assert(model_init[0]==2U && model_analog[0]==analog && model_digital[0]==digital && !model_io[0]);
  model_fail=0U;XE_NP_SensorsPort_Service(consumer_recording());assert(paused==3U && model_init[0]==2U);
  model_source_busy=model_capture_armed=model_aux_running=0U;assert(!consumer_recording());
  XE_NP_SensorsPort_Service(consumer_recording());
  assert(!paused && model_init[0]==3U && !model_io[0]);model_disabled_environment();
  XE_NP_SensorsPort_Service(0U);assert(model_init[0]==3U);
  model_ms+=20U;XE_NP_SensorsPort_Service(0U);assert(model_io[0]==1U && sensors.device[0].pending);
 }
 model_fresh();model_ms=0xfffffff0U;XE_NP_SensorsPort_Pause();XE_NP_SensorsPort_Resume();model_fail=1U;
 XE_NP_SensorsPort_Service(0U);assert(paused==3U && model_init[0]==1U);
 model_fail=0U;model_ms=0x7bfU;XE_NP_SensorsPort_Service(0U);assert(paused==3U && model_init[0]==1U);
 model_ms=0x7c0U;XE_NP_SensorsPort_Service(0U);assert(!paused && model_init[0]==2U);
 model_fresh();XE_NP_SensorsPort_Pause();XE_NP_SensorsPort_Resume();model_fail=1U;
 XE_NP_SensorsPort_Service(0U);assert(paused==3U);
 XE_NP_SensorsPort_Pause();model_fail=0U;model_ms+=10000U;
 XE_NP_SensorsPort_Service(0U);assert(paused==1U && model_init[0]==1U);
 XE_NP_SensorsPort_Resume();XE_NP_SensorsPort_Service(0U);assert(!paused && model_init[0]==2U);
 model_fresh();model_ms=120U;XE_NP_SensorsPort_Service(0U);
 model_ms=140U;XE_NP_SensorsPort_Service(1U);
 assert(!sensors.device[0].pending && sensors.snapshot.error[0]==XE_NP_SENSOR_ERR_TIMEOUT && sensors.snapshot.timeouts[0]==1U);
 assert(!(model_regs[0].CR1&MODEL_OWNED_BITS) && !model_handles[0].XferISR);
 for(unsigned pass=0U;pass<10U;pass++){model_ms=2140U+pass;XE_NP_SensorsPort_Service(1U);}
 assert(!model_deinit[0] && !model_init[0] && model_io[0]==1U);
 XE_NP_SensorsPort_Service(0U);
 assert(model_deinit[0]==1U && model_init[0]==1U && model_io[0]==2U && sensors.device[0].pending);
 model_disabled_environment();
 puts("PASS sensor Pause/Resume: actual port/core/USB ownership guard, IRQ quiescence, callbacks, snapshots, bounded idle-only resume retries and recovery");
 return 0;
}
'''


class Np2SensorPause(unittest.TestCase):
    def test_actual_pause_resume_lifecycle(self):
        source = (ROOT / "Core/Src/xe_np_sensors_port.c").read_text()
        # Only the HAL/board include boundary is substituted; all port code and
        # the complete sensor core/compensation units compile unchanged.
        source = source.replace('#include "xe_np_sensors_port.h"', "")
        source = source.replace('#include "xe_np_board.h"', "")
        for header in ("xe_np_np2_usb_source.h", "xe_np_np2_capture_port.h", "xe_np_usb_aux.h"):
            source = source.replace('#include "' + header + '"', "")
        main = (ROOT / "Core/Src/main.c").read_text()
        usb_start = main.index("      uint8_t recording=0U;")
        usb_end = main.index("      XE_NP_SensorsPort_Service(recording);", usb_start)
        guard = [line for line in main[usb_start:usb_end].splitlines()
                 if not line.lstrip().startswith("#")]
        start = main.index("      uint32_t state=xe_np_np2_dual_sd_app_mailbox.state;")
        end = main.index("      XE_NP_SensorsPort_Service(recording);", start)
        sd_guard = main[start:end]
        with tempfile.TemporaryDirectory(prefix="sensor_pause_", dir=ROOT / "_artifacts") as temp:
            out = Path(temp)
            (out / "actual_port.inc").write_text(source)
            (out / "actual_guard.inc").write_text(
                "static uint8_t consumer_recording(void){\n"
                + "\n".join(guard) + "\nreturn recording;}\n"
                + "static uint8_t consumer_sd_recording(void){\n" + sd_guard
                + "\nreturn recording;}\n")
            (out / "native.c").write_text(NATIVE)
            inputs = [out / "native.c"] + [ROOT / "Core/Src" / name for name in (
                "xe_np_sensors.c", "xe_np_bme_compensation.c", "xe_np_bmm_compensation.c")]
            for role in (1, 2):
                exe = out / ("native_role" + str(role) + ".exe")
                command = (f'call "{VC}" >nul && cl /nologo /std:c11 /W4 /WX /TC /O2 '
                           f'/DMODEL_IMAGE_ROLE={role} /I"{ROOT / "Core/Inc"}" ' + " ".join(f'"{p}"' for p in inputs) +
                           f' /Fo"{out}/" /Fe"{exe}"')
                compiled = subprocess.run(f'cmd /d /s /c "{command}"', cwd=out,
                                          capture_output=True, text=True, timeout=30)
                self.assertEqual(compiled.returncode, 0, compiled.stdout + compiled.stderr)
                run = subprocess.run([str(exe)], cwd=out, capture_output=True, text=True, timeout=10)
                self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
                self.assertIn("PASS sensor Pause/Resume", run.stdout)


if __name__ == "__main__":
    unittest.main()
