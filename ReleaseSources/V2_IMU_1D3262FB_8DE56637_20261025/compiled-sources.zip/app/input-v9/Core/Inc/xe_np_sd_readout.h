#ifndef XE_NP_SD_READOUT_H
#define XE_NP_SD_READOUT_H

#include <stdint.h>

#ifndef XE_NP_SD_MEDIA_READOUT_DIAG
#define XE_NP_SD_MEDIA_READOUT_DIAG 0U
#endif
#if XE_NP_SD_MEDIA_READOUT_DIAG != 0U && XE_NP_SD_MEDIA_READOUT_DIAG != 1U
#error "SD media readout flag must be 0 or 1"
#endif

#if XE_NP_SD_MEDIA_READOUT_DIAG
#include "main.h"
#if XE_NP_SD_IDENTIFY_ONLY_DIAG != 1U || XE_NP_SD_CMD11_TRACE_ONLY_DIAG != 0U || \
    XE_NP_NP2_CAPTURE_PORT_ENABLE != 0U || XE_NP_NP2_USB_SOURCE_ENABLE != 0U || \
    XE_NP_NP2_LIVE_SD_ENABLE != 0U || XE_NP_NP2_DUAL_SD_APP_ENABLE != 0U || \
    XE_NP_USB_UNIFIED_ENABLE != 0U
#error "SD media readout requires source-free strict identification only"
#endif

#define XE_NP_SD_READOUT_BUFFER_BYTES 186368U
#define XE_NP_SD_READOUT_MAX_BLOCKS 364U

typedef struct {
    uint32_t magic, version, state, card_blocks, buffer_address, buffer_bytes;
    uint32_t request_lba, request_blocks, request_nonce, completed_nonce;
    uint32_t result, sd_error, completed_lba, completed_blocks;
    uint32_t cid[4], csd[4];
} XE_NP_SdReadoutDiag;

extern uint8_t xe_np_sd_readout_buffer[XE_NP_SD_READOUT_BUFFER_BYTES];
extern volatile XE_NP_SdReadoutDiag xe_np_sd_readout_diag;

/* identification_ok == 1 certifies this same handle's current strict-ID
 * snapshot, including successful native CMD13 TRANSFER. No extra card probe
 * is issued here. The integration must disable/retire DCACHE before Init (or
 * provide admitted noncacheable SRAM) for the request/receipt and buffer;
 * DMB is ordering, not cache maintenance.
 * Host writes request_lba/blocks, then request_nonce LAST; one request at a
 * time. Accept data only for matching completed_nonce, state 1, result 0,
 * sd_error 0, and the requested completed_lba/blocks. */
void XE_NP_SdReadout_Init(SD_HandleTypeDef *hsd, uint32_t identification_ok);
void XE_NP_SdReadout_Service(SD_HandleTypeDef *hsd);
#endif
#endif
