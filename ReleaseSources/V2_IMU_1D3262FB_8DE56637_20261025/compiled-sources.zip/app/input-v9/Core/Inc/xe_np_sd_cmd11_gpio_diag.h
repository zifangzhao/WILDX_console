#ifndef XE_NP_SD_CMD11_GPIO_DIAG_H
#define XE_NP_SD_CMD11_GPIO_DIAG_H
#include "xe_np_sd_init_diag.h"
#ifndef XE_NP_SD_CMD11_GPIO_DMA_DIAG
#define XE_NP_SD_CMD11_GPIO_DMA_DIAG 0U
#endif
#ifndef XE_NP_SD_CMD11_CMD_DMA_DIAG
#define XE_NP_SD_CMD11_CMD_DMA_DIAG 0U
#endif
#ifndef XE_NP_SD_CMD11_PIN_HANDSHAKE_DIAG
#define XE_NP_SD_CMD11_PIN_HANDSHAKE_DIAG 0U
#endif
#ifndef XE_NP_SD_BASIC_TEAMGROUP_UHS
#define XE_NP_SD_BASIC_TEAMGROUP_UHS 0U
#endif
#if XE_NP_SD_BASIC_TEAMGROUP_UHS
/* Separate finite writer role, never identify-only or a recording image. */
_Static_assert(!XE_NP_SD_IDENTIFY_ONLY_DIAG && XE_NP_SD_CMD11_TRACE_ONLY_DIAG &&
               XE_NP_SD_CMD11_PIN_HANDSHAKE_DIAG &&
               !XE_NP_SD_CMD11_GPIO_DMA_DIAG && !XE_NP_SD_CMD11_CMD_DMA_DIAG,
               "TeamGroup UHS requires sampler-free CMD11 pin evidence");
#endif
#if XE_NP_SD_TEAMGROUP_UHS_STARTUP_TEST
_Static_assert(!XE_NP_SD_IDENTIFY_ONLY_DIAG && !XE_NP_SD_BASIC_TEAMGROUP_UHS &&
               XE_NP_SD_CMD11_TRACE_ONLY_DIAG && XE_NP_SD_CMD11_PIN_HANDSHAKE_DIAG &&
               !XE_NP_SD_CMD11_GPIO_DMA_DIAG && !XE_NP_SD_CMD11_CMD_DMA_DIAG,
               "TeamGroup startup requires sampler-free CMD11 pin evidence");
#endif
#if XE_NP_SD_CMD11_PIN_COMPAT_ENABLE
_Static_assert(!XE_NP_SD_CMD11_PIN_HANDSHAKE_DIAG && !XE_NP_SD_BASIC_TEAMGROUP_UHS &&
               !XE_NP_SD_IDENTIFY_ONLY_DIAG && !XE_NP_SD_CMD11_GPIO_DMA_DIAG && !XE_NP_SD_CMD11_CMD_DMA_DIAG,
               "shared CMD11 compatibility is sampler-free and separate from fixed diagnostic roles");
#endif
#if XE_NP_SD_CMD11_PIN_HANDSHAKE_DIAG
#if !XE_NP_SD_BASIC_TEAMGROUP_UHS && !XE_NP_SD_TEAMGROUP_UHS_STARTUP_TEST && (!XE_NP_SD_CMD11_CMD_DMA_DIAG || !XE_NP_SD_CMD11_GPIO_DMA_DIAG)
#error "CMD11 pin handshake requires paired CMD/GPIO diagnostic"
#endif
_Static_assert(XE_NP_SD_CMD11_TRACE_INIT_HZ==400000UL &&
               !XE_NP_SD_INIT_FALLING_EDGE && !XE_NP_SD_CMD11_TRACE_INIT_DIRECT_CKIN,
                "CMD11 pin handshake requires rising 400-kHz RX0");
#endif
#if XE_NP_SD_CMD11_PIN_HANDSHAKE_DIAG || XE_NP_SD_CMD11_PIN_COMPAT_ENABLE
/* Host-side sampled pin compatibility, never a native BUSYD0 qualification.
 * Error bits: 1 policy/precondition, 2 low window, 4 high window,
 * 8 later native PowerON error. States 0 unused, 1 entered, 2 stable low,
 * 3 stable high, 255 failed. End samples describe each successful window. */
typedef struct {
  uint32_t magic,version,state,error,native_error,pre_sta,pre_pc,pre_pd;
  uint32_t low_cycles,low_polls,post_sta,post_pc,post_pd,high_cycles,high_polls,clkcr;
} XE_NP_SdCmd11PinDiag;
_Static_assert(sizeof(XE_NP_SdCmd11PinDiag)==64U,"CMD11 pin handshake ABI");
extern volatile XE_NP_SdCmd11PinDiag xe_np_sd_cmd11_pin_diag;
int XE_NP_SdCmd11PinLow(uint32_t started,uint32_t requested,uint32_t ocr);
int XE_NP_SdCmd11PinHigh(uint32_t started);
void XE_NP_SdCmd11PinResult(uint32_t error);
#endif
#if XE_NP_SD_CMD11_CMD_DMA_DIAG && !XE_NP_SD_CMD11_GPIO_DMA_DIAG
#error "CMD11 CMD DMA requires GPIO DMA diagnostic"
#endif
#if XE_NP_SD_CMD11_GPIO_DMA_DIAG
#if !defined(XE_NP_SD_IDENTIFY_ONLY_DIAG) || !XE_NP_SD_IDENTIFY_ONLY_DIAG || !XE_NP_SD_CMD11_TRACE_ONLY_DIAG
#error "CMD11 GPIO DMA requires source-free trace-only identification"
#endif
_Static_assert((XE_NP_SD_CMD11_TRACE_INIT_HZ==100000UL || XE_NP_SD_CMD11_TRACE_INIT_HZ==400000UL) &&
               !XE_NP_SD_INIT_FALLING_EDGE && !XE_NP_SD_CMD11_TRACE_INIT_DIRECT_CKIN,
               "CMD11 GPIO DMA requires matched rising 100/400-kHz RX0");
#define XE_NP_SD_CMD11_GPIO_WORDS 16000U
#define XE_NP_SD_CMD11_GPIO_SENTINEL 0xa5a5a5a5U
/* State: 1 prepared, 2 running, 3 stopped/stable, 255 diagnostic failure.
 * Error bits: 1 guard, 2 configuration, 4 DMA error flags, 8 progress/bounds,
 * 16 suspend timeout, 32 reset timeout. Native SD error is never replaced.
 * Marks are instantaneous DMA progress, NOT committed-memory edge times.
 * dma_* and timer_* are final raw snapshots BEFORE channel reset/flag clear.
 * Only state 3 promises a stable prefix of (64000-final_bndt)/4 words. */
typedef struct {
  uint32_t magic,version,state,error,buffer_address,buffer_words,sample_hz,timer_hz;
  uint32_t mark_valid_mask,mark_words[4],initial_bndt,final_bndt;
  uint32_t dma_csr,dma_ccr,dma_csar,dma_cdar,dma_ctr1,dma_ctr2,dma_cllr;
  uint32_t timer_cr1,timer_dier,timer_psc,timer_arr,timer_cnt,dwt_elapsed;
  uint32_t start_tick,stop_tick,reserved[2];
} XE_NP_SdCmd11GpioDiag;
_Static_assert(sizeof(XE_NP_SdCmd11GpioDiag)==128U,"CMD11 GPIO DMA ABI");
extern volatile XE_NP_SdCmd11GpioDiag xe_np_sd_cmd11_gpio_diag;
extern volatile uint32_t xe_np_sd_cmd11_gpio_samples[XE_NP_SD_CMD11_GPIO_WORDS];
#if XE_NP_SD_CMD11_CMD_DMA_DIAG
/* Same finite sampler ABI, independent TIM7_UP/request 5/GPDMA1 channel 1.
 * The DWT bracket bounds timer launch, NOT GPIO read simultaneity or DMA
 * arbitration. Native R1 is frozen immediately after the CMD11 helper. */
typedef struct {
  uint32_t magic,version,dwt_before,dwt_after;
  uint32_t response_cmd,response_word,response_valid,reserved0;
} XE_NP_SdCmd11CmdLaunch;
_Static_assert(sizeof(XE_NP_SdCmd11CmdLaunch)==32U,"CMD11 CMD launch ABI");
extern volatile XE_NP_SdCmd11GpioDiag xe_np_sd_cmd11_cmd_diag;
extern volatile uint32_t xe_np_sd_cmd11_cmd_samples[XE_NP_SD_CMD11_GPIO_WORDS];
extern volatile XE_NP_SdCmd11CmdLaunch xe_np_sd_cmd11_cmd_launch;
void XE_NP_SdCmd11CmdResponse(uint32_t command,uint32_t response,uint32_t valid);
#endif
int XE_NP_SdCmd11GpioPrepare(void);
void XE_NP_SdCmd11GpioMark(uint32_t slot);
void XE_NP_SdCmd11GpioFinish(void);
#endif
#endif
