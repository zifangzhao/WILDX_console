#ifndef __CE32_INTERCOM
#define __CE32_INTERCOM

#include "CE32_macro.h"
#include "CE32_COMMAND.h"
#include "stm32f4xx_hal.h"

#define MAX_NCH_GROUP CE32_MAX_NCH_GROUP
#define INTERCOM_CMD_SEQ CMD_SEQ
#define INTERCOM_CMD_BUFSIZE 512U
#define INTERCOM_PKG_HEAD 0x3cU
#define INTERCOM_PKG_TAIL 0x3eU

#if defined(USART_ISR_RXNE_RXFNE)
#define CE32_UART_ISR_RXNE USART_ISR_RXNE_RXFNE
#else
#define CE32_UART_ISR_RXNE USART_ISR_RXNE
#endif

#if defined(USART_ISR_TXE_TXFNF)
#define CE32_UART_ISR_TXE USART_ISR_TXE_TXFNF
#else
#define CE32_UART_ISR_TXE USART_ISR_TXE
#endif

#if defined(USART_ISR_RXNE_RXFNE)
#define CE32_UART_RX_CLEAR(__UART__) ((void)0)
#define CE32_UART_RX_READ(__UART__) ((uint8_t)((__UART__)->RDR))
#else
#define CE32_UART_RX_CLEAR(__UART__) ((__UART__)->SR &= ~USART_SR_RXNE)
#define CE32_UART_RX_READ(__UART__) ((uint8_t)((__UART__)->DR))
#endif

#define CE32_UART_DMA_CONFIGURED(__HANDLE__) \
    (((__HANDLE__) != NULL) && ((__HANDLE__)->huart != NULL) && \
     ((__HANDLE__)->huart->hdmatx != NULL) && \
     ((__HANDLE__)->huart->hdmatx->Instance != NULL))

#define INTERCOM_CHECK_RXNE(__IC_handle__) ((((__IC_handle__)->UART->ISR & CE32_UART_ISR_RXNE) != 0U))
#define INTERCOM_CHECK_TXE(__IC_handle__) ((((__IC_handle__)->UART->ISR & CE32_UART_ISR_TXE) != 0U))
#define INTERCOM_RX_IS_ON(__IC_handle__) ((((__IC_handle__)->state & INTERCOM_STATE_RECIVING) != 0U))
#define INTERCOM_TX_SEND(__IC_handle__, __DATA__) do { (__IC_handle__)->UART->TDR = (__DATA__); } while(0)

#define INTERCOM_UART_CHECK_RXNEIE(__IC_handle__) ((((__IC_handle__)->UART->CR1 & USART_CR1_RXNEIE_RXFNEIE) != 0U))
#define INTERCOM_UART_CHECK_TXEIE(__IC_handle__) ((((__IC_handle__)->UART->CR1 & USART_CR1_TXEIE_TXFNFIE) != 0U))
#define INTERCOM_UART_TXEIE_DISABLE(__IC_handle__) ((__IC_handle__)->UART->CR1 &= ~(USART_CR1_TXEIE_TXFNFIE))

#define INTERCOM_UART_ENABLE(__IC_handle__) ((__IC_handle__)->UART->CR1 |= (USART_CR1_TE | USART_CR1_RE | USART_CR1_UE))
#define INTERCOM_UART_RXIT_ENABLE(__IC_handle__) ((__IC_handle__)->UART->CR1 |= USART_CR1_RXNEIE_RXFNEIE)
#define INTERCOM_UART_TXIT_ENABLE(__IC_handle__) ((__IC_handle__)->UART->CR1 |= USART_CR1_TXEIE_TXFNFIE)

#define INTERCOM_STATE_START_RX_RECEIVE(__IC_handle__) ((__IC_handle__)->state |= INTERCOM_STATE_RECIVING)
#define INTERCOM_STATE_END_RX_RECEIVE(__IC_handle__) ((__IC_handle__)->state &= ~INTERCOM_STATE_RECIVING)

#define INTERCOM_STATE_IDLE 0x0001U
#define INTERCOM_STATE_TXON 0x0002U
#define INTERCOM_STATE_SLEEP 0x0004U
#define INTERCOM_STATE_CONFIG 0x0008U
#define INTERCOM_STATE_CONNECTED 0x0010U
#define INTERCOM_STATE_ERROR 0x0020U
#define INTERCOM_STATE_RXON 0x0040U
#define INTERCOM_STATE_MASTER 0x0080U
#define INTERCOM_STATE_STOP 0x0100U
#define INTERCOM_STATE_RECIVING 0x0200U
#define INTERCOM_STATE_CMD_RESP_PEND 0x0400U
#define INTERCOM_STATE_WAITRESP 0x0800U
#define INTERCOM_STATE_CE32_CMD 0x1000U
#define INTERCOM_STATE_CE32_CMD_PEND 0x2000U
#define INTERCOM_STATE_TX_DMABUSY 0x4000U
#define INTERCOM_STATE_RX_DMABUSY 0x8000U

#define INTERCOM_RX_BUF_SIZE CMD_BUFSIZE

typedef struct
{
    CE32_command CMD_TX;
    CE32_command CMD_RX;
    USART_TypeDef *UART;
    UART_HandleTypeDef *huart;
    __IO uint32_t state;
    __IO int id;
    __IO int type;
    __IO int version;
    dataMGR MGR_RX;
    __IO uint32_t RX_OK;
    __IO uint32_t RX_fail;
} CE32_INTERCOM_Handle;

typedef struct
{
    __IO uint16_t device_state;
    CE32_command command;
    USART_TypeDef *UART;
    UART_HandleTypeDef *huart;
} CE32_device;

void CE32_INTERCOM_Init(CE32_INTERCOM_Handle *handle, UART_HandleTypeDef *huart);
void CE32_INTERCOM_UART_Init(UART_HandleTypeDef *huart);
int CE32_INTERCOM_Incoming_CMD_Len(int index);
int CE32_INTERCOM_RX_EnqueueCmd(CE32_INTERCOM_Handle *handle);
int CE32_INTERCOM_RX_Enqueue_Byte(CE32_INTERCOM_Handle *handle, unsigned char data);
int CE32_INTERCOM_RX_DequeueCmd(CE32_INTERCOM_Handle *handle, uint8_t **data_ptr, uint32_t *cmd_len);
int CE32_INTERCOM_TX_EnqueueCmd(CE32_INTERCOM_Handle *handle, unsigned char *data, int cmd_len);
int CE32_INTERCOM_TX_DequeueCmd(CE32_INTERCOM_Handle *handle);
int CE32_INTERCOM_TX_Dequeue_Byte(CE32_INTERCOM_Handle *handle, uint8_t *data);
int CE32_INTERCOM_TX_Message(CE32_INTERCOM_Handle *handle, char *txt);
int CE32_INTERCOM_RX_ISR(CE32_INTERCOM_Handle *handle);
int CE32_INTERCOM_RX_ISR_SWI(CE32_INTERCOM_Handle *handle);
int CE32_INTERCOM_RX_ProcBuffer(CE32_INTERCOM_Handle *handle);
int CE32_INTERCOM_TX_ISR(CE32_INTERCOM_Handle *handle);
int CE32_INTERCOM_RX_Inputdata_byte(CE32_INTERCOM_Handle *handle, uint8_t data);
int CE32_INTERCOM_TX_DMA_ISR(CE32_INTERCOM_Handle *handle);
int CE32_INTERCOM_TX_Start_DMA(CE32_INTERCOM_Handle *handle);
int CE32_INTERCOM_TX_Stop_DMA(CE32_INTERCOM_Handle *handle);
int CE32_INTERCOM_TX_Stop_All(CE32_INTERCOM_Handle *handle);
void CE32_INTERCOM_UART_TX_DMA_Init(CE32_INTERCOM_Handle *handle);
void CE32_INTERCOM_UART_TX_DMA_Enable(CE32_INTERCOM_Handle *handle);
void CE32_INTERCOM_UART_TX_DMA_Disable(CE32_INTERCOM_Handle *handle);
int CE32_INTERCOM_TX_WaitTillSent(CE32_INTERCOM_Handle *handle);
uint8_t CE32_INTERCOM_TakeResetISRRequest(void);
void CE32_INTERCOM_TX_restart(CE32_INTERCOM_Handle *handle);
void CE32_INTERCOM_RX_dataCached_Act(CE32_INTERCOM_Handle *handle);
void CE32_INTERCOM_TX_EnqueueCmd_Act(CE32_INTERCOM_Handle *handle);

#endif
