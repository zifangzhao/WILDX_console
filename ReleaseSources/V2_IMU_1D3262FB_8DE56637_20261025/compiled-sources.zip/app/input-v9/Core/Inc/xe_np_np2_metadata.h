#ifndef XE_NP_NP2_METADATA_H
#define XE_NP_NP2_METADATA_H
#include "xe_np_np2_session.h"
#define XE_NP_NP2_CONFIG_BYTES 2048U
#define XE_NP_NP2_ORIGIN_BYTES 128U

/* Explicit little-endian NP2 metadata blocks. NOT an extension to existing
 * v5/v6/v7 reserved bytes. The next container version must assign locations
 * and require these blocks before deploying the NP2 session application.
 * These routines write only caller-owned memory, never sectors/peripherals.
 * Output must not overlap the session; rejected calls leave output unchanged.
 * CRC32 is integrity, not authentication or proof of physical recording. */
int XE_NP_Np2Metadata_Config(const XE_NP_Np2Session *, uint32_t session_id,
                           uint8_t *output,uint32_t capacity);
/* Cache once on admission, then embed/copy it through the future container.
 * config_crc is the CRC at config[2044], from the same immutable session/id.
 * Never regenerate expected configuration/phase from received ADC data.
 * Valid after admission including STOP/FAILED for incomplete-record evidence;
 * presence of this block says nothing about SD completion or payload integrity. */
int XE_NP_Np2Metadata_Origin(const XE_NP_Np2Session *, uint32_t session_id,
                           uint32_t config_crc,uint8_t *output,uint32_t capacity);
#endif
