#ifndef XE_NP_NP2_ACQUISITION_H
#define XE_NP_NP2_ACQUISITION_H
#include "xe_np_np2_metadata.h"

enum {XE_NP_NP2_DEST_USB=1,XE_NP_NP2_DEST_SD=2};
enum {XE_NP_NP2_ACQ_EMPTY=0,XE_NP_NP2_ACQ_POWER_OFF,XE_NP_NP2_ACQ_POWER_WAIT,
      XE_NP_NP2_ACQ_CLOCK_WAIT,XE_NP_NP2_ACQ_RESET_HIGH,XE_NP_NP2_ACQ_RESET_LOW,
      XE_NP_NP2_ACQ_RESET_RELEASED,XE_NP_NP2_ACQ_CONFIG_READY,
      XE_NP_NP2_ACQ_RUNNING,XE_NP_NP2_ACQ_STOPPED,XE_NP_NP2_ACQ_FAILED};
enum {XE_NP_NP2_ACQ_ERROR_ARGUMENT=1,XE_NP_NP2_ACQ_ERROR_POWER,
      XE_NP_NP2_ACQ_ERROR_CLOCK,XE_NP_NP2_ACQ_ERROR_RESET,XE_NP_NP2_ACQ_ERROR_BIND,
      XE_NP_NP2_ACQ_ERROR_METADATA,XE_NP_NP2_ACQ_ERROR_TIMEOUT,XE_NP_NP2_ACQ_ERROR_SESSION,
      XE_NP_NP2_ACQ_ERROR_CANCELLED};
/* One action per Service, stopped-only HAL setup; no sleeping in this engine.
 * prepare: stop MCO, isolate I2C2/3/4, shared NRST/CAL low, then probe VCC off.
 * quiesce: cancel control/capture first, isolate pins/clock, then VCC off.
 * Neither callback may switch the SD/storage power rail or write card sectors.
 * reset(1/0) controls shared NRST. clock starts exactly 48MHz after >=10ms supply.
 * healthy checks actual configuration/settings, not measured rail voltages.
 * bind initializes only I2C2/3, then binds real control/producer interfaces;
 * it must NOT start I2C transactions or arm DMA. Ownership lasts to reboot. */
typedef struct {
    void *user;
    int (*prepare)(void *);
    int (*power_on)(void *);
    int (*clock_on)(void *,uint32_t supply_stable_ms);
    int (*reset)(void *,uint8_t released);
    int (*healthy)(void *);
    int (*bind)(void *,XE_NP_Np2ControlIo *,XE_NP_Np2ProducerIo *);
    void (*quiesce)(void *);
    uint32_t (*now_ms)(void *);
} XE_NP_Np2StartupIo;

typedef struct {
    XE_NP_Np2Session *session; /* fresh, caller-owned, remains alive throughout */
    XE_NP_Np2StartupIo hw;
    union {XE_NP_Np2ProbeImage images[2];uint8_t config[XE_NP_NP2_CONFIG_BYTES];} expected;
    uint8_t origin[XE_NP_NP2_ORIGIN_BYTES];
    uint32_t session_id,config_crc,began_ms,stage_ms;
    uint8_t state,error,destination,digital_test,config_ready,origin_ready,quiesced,active_probe_mask;
} XE_NP_Np2Acquisition;

/* Exclusive zeroed acquisition and session, disjoint from both input objects.
 * One explicitly selected sink.
 * Inputs are copied before prepare changes hardware. No fallback maps or
 * assumption that two probe phases are equal; session acquires both phases.
 * This API cannot itself qualify the electrode mapping or physical timing. */
int XE_NP_Np2Acquisition_Begin(XE_NP_Np2Acquisition *,XE_NP_Np2Session *,
                             const XE_NP_Np2StartupIo *,const XE_NP_Np2ProbeImage[2],
                             uint32_t session_id,uint8_t destination,uint8_t digital_test);
int XE_NP_Np2Acquisition_BeginMasked(XE_NP_Np2Acquisition *,XE_NP_Np2Session *,
                             const XE_NP_Np2StartupIo *,const XE_NP_Np2ProbeImage[2],
                             uint32_t session_id,uint8_t destination,uint8_t digital_test,
                             uint8_t active_probe_mask);
void XE_NP_Np2Acquisition_Service(XE_NP_Np2Acquisition *);
/* CONFIG_READY deliberately pauses before any probe configuration or DMA.
 * Caller must persist/verify expected.config for SD, or complete explicit
 * generation/config negotiation for USB, BEFORE confirming the exact ID/CRC.
 * Confirmation is a caller contract, not proof of SD durability/host receipt.
 * This is not a command to replay automatically after failure. */
int XE_NP_Np2Acquisition_ConfirmConfig(XE_NP_Np2Acquisition *,uint32_t session_id,uint32_t config_crc);
/* Same packing contract as Session. Origin metadata is cached on first valid
 * span before returning success; both sinks must store/associate it. */
int XE_NP_Np2Acquisition_Pack(XE_NP_Np2Acquisition *,uint32_t maximum,uint8_t *destination,
                            uint32_t capacity,uint32_t *written,uint64_t *source_start);
/* Stops the source only. The destination still owns drain/commit/finalization.
 * Earlier STOP is cancellation, never a successful zero-length recording. */
void XE_NP_Np2Acquisition_Stop(XE_NP_Np2Acquisition *);
void XE_NP_Np2Acquisition_Abort(XE_NP_Np2Acquisition *);
#endif
