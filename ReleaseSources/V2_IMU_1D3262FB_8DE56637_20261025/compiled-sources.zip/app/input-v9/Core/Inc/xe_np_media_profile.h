#ifndef XE_NP_MEDIA_PROFILE_H
#define XE_NP_MEDIA_PROFILE_H

#include <stdint.h>

/* Dedicated V2 media role. Never turn missing NP probes into media mode. */
#ifndef XE_NP_V2_MEDIA_ENABLE
#define XE_NP_V2_MEDIA_ENABLE 0U
#endif
#if XE_NP_V2_MEDIA_ENABLE != 0U && XE_NP_V2_MEDIA_ENABLE != 1U
#error "V2 media selection must be boolean"
#endif
#if XE_NP_V2_MEDIA_ENABLE && \
    (XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || XE_NP_BOARD_NP1_SPI_TAP_ENABLE || \
     XE_NP_NP2_LIVE_SD_ENABLE || XE_NP_NP2_DUAL_SD_APP_ENABLE)
#error "Dedicated media must exclude NP capture and its SPI1/ring ownership"
#endif

#define XE_NP_MEDIA_CORE_HZ            150000000U
#define XE_NP_MEDIA_CAMERA_SCLK_HZ      75000000U
#define XE_NP_MEDIA_CAMERA_HZ                 50U
#define XE_NP_MEDIA_ADC_HZ                200000U
#define XE_NP_MEDIA_ADC_BITS                  14U
#define XE_NP_MEDIA_ADC_SHIFT                  2U
#define XE_NP_MEDIA_ADC_NODE_BYTES         32768U
#define XE_NP_MEDIA_ADC_NODE_COUNT             4U
#define XE_NP_MEDIA_ADC_RING_BYTES \
    (XE_NP_MEDIA_ADC_NODE_BYTES * XE_NP_MEDIA_ADC_NODE_COUNT)
#define XE_NP_MEDIA_COPY_BYTES              4096U
#define XE_NP_MEDIA_CHUNK_BYTES            65536U
#define XE_NP_MEDIA_PAYLOAD_BYTES          61440U
#define XE_NP_MEDIA_HEADER_OFFSET          61632U
#define XE_NP_MEDIA_FORMAT_VERSION              8U
#define XE_NP_MEDIA_CAMERA_FRAME_BYTES    160000U
#define XE_NP_MEDIA_CAMERA_FRAME_COUNT         2U
/* The shared NanEye driver places immutable rasters after six FIFO units. */
#define XE_NP_MEDIA_CAMERA_FRAME_OFFSET \
    (6U * XE_NP_MEDIA_CHUNK_BYTES)
#define XE_NP_MEDIA_CAMERA_ARENA_MIN_BYTES \
    (XE_NP_MEDIA_CAMERA_FRAME_OFFSET + \
     XE_NP_MEDIA_CAMERA_FRAME_COUNT * XE_NP_MEDIA_CAMERA_FRAME_BYTES)

/* SRAM5 on this U595 board: no memory-mapped PSRAM capture destination. */
static inline int XE_NP_MediaCameraArenaFits(uintptr_t arena, uint32_t bytes)
{
    return !(arena & 31U) && arena >= 0x201A0000U && arena < 0x20270000U &&
        bytes >= XE_NP_MEDIA_CAMERA_ARENA_MIN_BYTES &&
        bytes <= 0x20270000U - arena;
}

/* Timer rates are exact or rejected: never label rounded ADC samples 200k. */
static inline uint32_t XE_NP_MediaAdcTimerPeriod(uint32_t timer_hz)
{
    uint32_t ticks = timer_hz / XE_NP_MEDIA_ADC_HZ;
    return timer_hz % XE_NP_MEDIA_ADC_HZ || !ticks || ticks > 65536U ?
        UINT32_MAX : ticks - 1U;
}

#endif
