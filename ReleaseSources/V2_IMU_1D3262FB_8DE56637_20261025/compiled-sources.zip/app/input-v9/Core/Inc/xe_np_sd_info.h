#ifndef XE_NP_SD_INFO_H
#define XE_NP_SD_INFO_H
#include <stdint.h>
#include <string.h>

/* USB service only: OUT 0x4c queues an idle-only identification; IN 0x4b
 * returns an immutable snapshot. No disk sectors or mode-1 CMD6 are exposed.
 * Scalars are little endian; register arrays retain SD wire byte order. */
#define XE_NP_SD_INFO_MAGIC 0x53444946UL
#define XE_NP_SD_INFO_VERSION 1U
#define XE_NP_SD_INFO_EMPTY 0U
#define XE_NP_SD_INFO_PENDING 1U
#define XE_NP_SD_INFO_READY 2U
#define XE_NP_SD_INFO_FAILED 3U
#define XE_NP_SD_INFO_IDENTIFIED 1U
#define XE_NP_SD_INFO_SIGNAL_1V8 2U
#define XE_NP_SD_INFO_SCR_VALID 4U
#define XE_NP_SD_INFO_SSR_VALID 8U
#define XE_NP_SD_INFO_RECOVERED_1V8 32U
#define XE_NP_SD_INFO_PRESERVED_1V8 64U
#define XE_NP_SD_INFO_UHS_SKIPPED 128U
#define XE_NP_SD_INFO_NOT_QUERIED 0xffffffffUL

typedef struct {
    uint32_t argument, error;
    uint8_t status[64];
} XE_NP_SdInfoCheck;
typedef struct {
    uint32_t magic, version, bytes, state;
    uint32_t sequence, tick_ms, error, flags;
    uint32_t sectors_low, sectors_high, clock_hz, bus_width;
    uint32_t active_function, board_budget_ma, ocr, init_stage;
    uint8_t cid[16], csd[16], scr[8], ssr[64];
    XE_NP_SdInfoCheck checks[3]; /* current, proposed SDR50, proposed SDR104 */
} XE_NP_SdInfo;
typedef char XE_NP_SdInfo_size_must_be_384[(sizeof(XE_NP_SdInfo)==384U)?1:-1];

static inline void XE_NP_SdInfoInit(XE_NP_SdInfo *info, uint32_t sequence)
{
    memset(info,0,sizeof(*info));
    info->magic=XE_NP_SD_INFO_MAGIC;info->version=XE_NP_SD_INFO_VERSION;
    info->bytes=sizeof(*info);info->sequence=sequence;
    info->state=XE_NP_SD_INFO_PENDING;
    info->checks[0].argument=0x00ffffffUL; /* no influence on all groups */
    info->checks[1].argument=0x00ff0ff2UL; /* mode 0, group4=0, group1=2 */
    info->checks[2].argument=0x00ff0ff3UL; /* mode 0, group4=0, group1=3 */
    for(uint32_t i=0;i<3U;i++)info->checks[i].error=XE_NP_SD_INFO_NOT_QUERIED;
}
static inline int XE_NP_SdInfoCanRefresh(uint32_t role, uint32_t configured,
    uint32_t streaming, uint32_t start_pending, uint32_t reset_pending,
    uint32_t capture_active, uint32_t sd_active, uint32_t query_pending)
{
    return role==2U && configured && !streaming && !start_pending &&
        !reset_pending && !capture_active && !sd_active && !query_pending;
}
/* Deliberate allowlist: callers cannot smuggle switch-mode/power changes
 * through the diagnostic transport. Not a general SD command bridge. */
static inline int XE_NP_SdInfoReadAllowed(uint32_t app, uint32_t cmd,
                                        uint32_t argument, uint32_t bytes)
{
    if(app)return argument==0U && ((cmd==51U && bytes==8U)||(cmd==13U && bytes==64U));
    return cmd==6U && bytes==64U && (argument==0x00ffffffUL ||
        argument==0x00ff0ff2UL || argument==0x00ff0ff3UL);
}
void XE_NP_Board_ReadSdInfo(XE_NP_SdInfo *info);
/* SD physical spec 4.3.10: group-1 support bits 2..4 must be zero in
 * 3.3 V mode. A valid UHS mask with S18A=0 may identify a retained UHS
 * session, not an unsupported card. Verify again after changing ONLY the
 * host translator, never issue CMD11 unless ACMD41 grants it. */
static inline int XE_NP_SdInfoNeedsVoltageRecovery(uint32_t flags,uint32_t ocr,
                                                   uint32_t error,const uint8_t *raw)
{
    return (flags&XE_NP_SD_INFO_IDENTIFIED) && !(flags&XE_NP_SD_INFO_SIGNAL_1V8) &&
        (ocr&0xc1000000U)==0xc0000000U && error==0U && raw && (raw[13]&0x1cU);
}
#endif
