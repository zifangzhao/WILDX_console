#ifndef XE_NP_RUNTIME_H
#define XE_NP_RUNTIME_H

#include "CE32_COMMAND.h"
#include "ce32_wire.h"
#include "dataMGR.h"
#include "xe_np_board.h"
#include "xe_np_capture.h"

#define XE_NP_RUNTIME_FLAG_BLE_PRESENT 0x00000001UL
#define XE_NP_RUNTIME_FLAG_SD_PRESENT 0x00000002UL
#define XE_NP_RUNTIME_FLAG_IMU_PRESENT 0x00000004UL
#define XE_NP_RUNTIME_FLAG_NP_INTERFACES_READY 0x00000008UL
#define XE_NP_RUNTIME_FLAG_NP_MCLK_VALID 0x00000010UL
#define XE_NP_RUNTIME_FLAG_NP_GLOBAL_RESET_RELEASED 0x00000020UL
#define XE_NP_RUNTIME_FLAG_NP_RECORD_RESET_RELEASED 0x00000040UL
#define XE_NP_RUNTIME_FLAG_NP_CAPTURE_TIMERS_READY 0x00000080UL
#define XE_NP_RUNTIME_FLAG_NP_CAPTURE_RAW_ONLY 0x00000100UL
#define XE_NP_RUNTIME_FLAG_NP_CAPTURE_BUFFER_TIGHT 0x00000200UL
#define XE_NP_RUNTIME_FLAG_NP_CAPTURE_BUFFER_SHORT 0x00000400UL
#define XE_NP_RUNTIME_FLAG_NP_CAPTURE_DMA_ACTIVE 0x00000800UL
#define XE_NP_RUNTIME_FLAG_NP_CAPTURE_SYNC_LOCKED 0x00001000UL
#define XE_NP_RUNTIME_FLAG_NP_CAPTURE_VALIDATION_ERROR 0x00002000UL
#define XE_NP_RUNTIME_FLAG_NP_CAPTURE_DMA_ERROR 0x00004000UL
#define XE_NP_RUNTIME_FLAG_NP_I2C_READY 0x00008000UL
#define XE_NP_RUNTIME_FLAG_NP_BASE_CONFIGURED 0x00010000UL
#define XE_NP_RUNTIME_FLAG_NP_SHANK_DEFAULTS 0x00020000UL
#define XE_NP_RUNTIME_FLAG_NP_INIT_FAILED 0x00040000UL
#define XE_NP_RUNTIME_FLAG_NP_CAPTURE_BACKLOG_ACTIVE 0x00080000UL
#define XE_NP_RUNTIME_FLAG_NP_CAPTURE_OVERRUN 0x00100000UL
#define XE_NP_RUNTIME_FLAG_NP_CAPTURE_SELFTEST_OK 0x00200000UL
#define XE_NP_RUNTIME_FLAG_NP_CALIBRATION_READY 0x00400000UL
#define XE_NP_RUNTIME_FLAG_NP_POWER_RAILS_ENABLED 0x00800000UL
#define XE_NP_RUNTIME_FLAG_SD_UHS_READY 0x01000000UL
#define XE_NP_RUNTIME_FLAG_ENV_PRESENT 0x02000000UL

#define XE_NP_SYSTEM_STATUS_NP_CAPTURE_TIMERS_READY 0x00010000UL
#define XE_NP_SYSTEM_STATUS_NP_CAPTURE_RAW_ONLY 0x00020000UL
#define XE_NP_SYSTEM_STATUS_NP_CAPTURE_BUFFER_TIGHT 0x00040000UL
#define XE_NP_SYSTEM_STATUS_NP_CAPTURE_BUFFER_SHORT 0x00080000UL
#define XE_NP_SYSTEM_STATUS_NP_CAPTURE_DMA_STRESSED 0x00100000UL
#define XE_NP_SYSTEM_STATUS_NP_CAPTURE_DMA_ACTIVE 0x00200000UL
#define XE_NP_SYSTEM_STATUS_NP_CAPTURE_SYNC_LOCKED 0x00400000UL
#define XE_NP_SYSTEM_STATUS_NP_CAPTURE_VALIDATION_ERROR 0x00800000UL
#define XE_NP_SYSTEM_STATUS_NP_CAPTURE_DMA_ERROR 0x01000000UL
#define XE_NP_SYSTEM_STATUS_NP_I2C_READY 0x02000000UL
#define XE_NP_SYSTEM_STATUS_NP_BASE_CONFIGURED 0x04000000UL
#define XE_NP_SYSTEM_STATUS_NP_SHANK_DEFAULTS 0x08000000UL
#define XE_NP_SYSTEM_STATUS_NP_INIT_FAILED 0x10000000UL
#define XE_NP_SYSTEM_STATUS_NP_CAPTURE_BACKLOG_ACTIVE 0x20000000UL
#define XE_NP_SYSTEM_STATUS_NP_CAPTURE_OVERRUN 0x40000000UL
#define XE_NP_SYSTEM_STATUS_NP_CAPTURE_SELFTEST_OK 0x80000000UL

typedef struct
{
    RTC_HandleTypeDef *hrtc;
    UART_HandleTypeDef *huart_ble;
    SD_HandleTypeDef *hsd_card;
    I2C_HandleTypeDef *hi2c_imu;
    I2C_HandleTypeDef *hi2c_temp;
    I2C_HandleTypeDef *hi2c_np[XE_NP_NEUROPIXELS_MAX_PROBES];
    TIM_HandleTypeDef *htim_np_capture_gpioe;
    TIM_HandleTypeDef *htim_np_capture_gpiod;
    ADC_HandleTypeDef *hadc_batt;
    DAC_HandleTypeDef *hdac_np_cal;
    CE32_systemParam sys_param;
    CE32_systemLog sys_log;
    CE32_dspParam dsp_param[CE32_DSP_COUNT];
    CE32_command ble_cmd_rx;
    CE32_command ble_cmd_tx;
    uint32_t np_mclk_hz;
    uint8_t active_np_probes;
    uint8_t active_np_probe_mask;
    uint32_t flags;
    XE_NP_CaptureState capture;
} XE_NP_Runtime;

void XE_NP_Runtime_Init(XE_NP_Runtime *runtime);
void XE_NP_Runtime_BindRtc(XE_NP_Runtime *runtime, RTC_HandleTypeDef *hrtc);
int XE_NP_Runtime_SetNpMclkHz(XE_NP_Runtime *runtime, uint32_t np_mclk_hz);
int XE_NP_Runtime_HasValidNpMclk(const XE_NP_Runtime *runtime);
uint32_t XE_NP_Runtime_RequiredMclkHz(const XE_NP_Runtime *runtime);
void XE_NP_Runtime_SetProbeMask(XE_NP_Runtime *runtime, uint8_t active_probe_mask);
void XE_NP_Runtime_StampRtcNow(XE_NP_Runtime *runtime, CE32_RTC_DateWire *date, CE32_RTC_TimeWire *time);
void XE_NP_SystemParam_InitDefaults(CE32_systemParam *sys_param);
void XE_NP_SystemParam_SetProbeCount(CE32_systemParam *sys_param, uint8_t active_probes);
void XE_NP_SystemParam_SetStreamRate(CE32_systemParam *sys_param, uint8_t stream_id, uint16_t channels, uint32_t sample_rate_hz);
void XE_NP_SystemLog_Init(CE32_systemLog *sys_log);
void XE_NP_DspParam_InitDefaults(CE32_dspParam *dsp_param);

#endif
