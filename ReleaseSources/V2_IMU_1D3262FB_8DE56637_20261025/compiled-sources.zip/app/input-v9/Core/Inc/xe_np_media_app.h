#ifndef XE_NP_MEDIA_APP_H
#define XE_NP_MEDIA_APP_H
#include "xe_np_hal.h"
#include "xe_np_board.h"
#include "xe_np_media_profile.h"
#include "../../Firmware/V1/Core/Inc/np_media_metadata.h"
#if XE_NP_V2_MEDIA_ENABLE
enum { XE_NP_MEDIA_IDLE=0, XE_NP_MEDIA_RECORDING=1, XE_NP_MEDIA_DRAINING=2,
       XE_NP_MEDIA_COMPLETE=3, XE_NP_MEDIA_FAILED=4, XE_NP_MEDIA_PREPARING=5 };
#define XE_NP_MEDIA_CMD_START 0x53544152U
#define XE_NP_MEDIA_CMD_STOP 0x53544F50U
#define XE_NP_MEDIA_CMD_FORMAT 0x464D4154U
#define XE_NP_MEDIA_CMD_READ 0x52454144U
#define XE_NP_MEDIA_CMD_PREPARE 0x50524550U
typedef struct {
    uint32_t magic,version,command,inverse,duration_ms,state,fault;
    uint32_t card_ready,card_blocks,sd_hz,start_lba,end_lba,session;
    uint32_t start_tick,stop_tick,committed_chunks,queued_chunks,max_write_ms,sd_error;
    uint32_t prepared,read_lba,read_blocks,read_status,read_address;
    uint32_t camera_frames,adc_samples_lo,adc_samples_hi,boot_stage;
} XE_NP_MediaMailbox;
extern volatile XE_NP_MediaMailbox xe_np_media_mailbox;
int XE_NP_MediaApp_Init(SD_HandleTypeDef *sd, ADC_HandleTypeDef *adc, SPI_HandleTypeDef *spi);
void XE_NP_MediaApp_Service(void);
int XE_NP_MediaApp_Start(uint32_t duration_ms);
int XE_NP_MediaApp_StartExtent(uint32_t session,uint32_t start,uint32_t end,uint32_t duration_ms);
int XE_NP_MediaApp_Stop(void);
int XE_NP_MediaApp_Format(void);
/* Preview admission never arms/stops/reconfigures acquisition. */
int XE_NP_MediaApp_Preview(void);
int XE_NP_MediaApp_ReadLog(uint16_t block);
uint32_t XE_NP_MediaApp_StatusStart(void);
const NpMediaMetadata *XE_NP_MediaApp_Metadata(void);
void XE_NP_MediaApp_SdIrq(void);
/* Shared controls are separate from IRQ capture ownership. */
void XE_NP_MediaBle_Init(void);
void XE_NP_MediaBle_Service(void);
void XE_NP_MediaBle_Irq(void);
void XE_NP_MediaBle_FrameSaved(const uint8_t *frame,uint32_t id,uint32_t tick);
void XE_NP_MediaBle_Metadata(NpMediaMetadata *out);
#endif
#endif
