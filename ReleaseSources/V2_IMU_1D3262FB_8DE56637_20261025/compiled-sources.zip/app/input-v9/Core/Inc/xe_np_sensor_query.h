#ifndef XE_NP_SENSOR_QUERY_H
#define XE_NP_SENSOR_QUERY_H
#include "xe_np_online_impl.h"
#include "xe_np_sensors.h"

#define XE_NP_SENSOR_QUERY_MAGIC 0x5153504eU /* NPSQ */
#define XE_NP_SENSOR_REPLY_MAGIC 0x5253504eU /* NPSR */
typedef struct {
    XE_NP_SensorSnapshot view;
    uint32_t token, serial, latched_ms;
} XE_NP_SensorQuery;

/* Foreground-only optional view. Never reads I2C, writes SD or changes capture.
 * Five CRC-checked replies carry one immutable140-byte sparse SNS1 snapshot. */
static inline int XE_NP_SensorQuery_Exchange(XE_NP_SensorQuery *q,
    const uint8_t in[64],uint8_t out[64],const XE_NP_SensorSnapshot *snapshot,
    uint32_t now)
{
    if(xe_np_online_word(in)!=XE_NP_SENSOR_QUERY_MAGIC)return 0;
    uint32_t op=xe_np_online_word(in+8),id=xe_np_online_word(in+12);
    uint32_t token=xe_np_online_word(in+16),offset=xe_np_online_word(in+20),error=0U;
    if(xe_np_online_word(in+4)!=1U || !id || op>1U ||
       xe_np_online_word(in+60)!=xe_np_online_crc(in))error=1U;
    for(uint32_t i=24U;i<60U;i++)if(in[i])error=1U;
    if(!op){if(token || offset)error=1U;}
    else if(offset!=28U && offset!=56U && offset!=84U && offset!=112U)error=1U;
    if(!error && !op){
        if(!snapshot || snapshot->magic!=0x31534e53U || snapshot->version!=1U)error=2U;
        else if(!snapshot->enabled && snapshot->error[0]==XE_NP_SENSOR_ERR_BUSY)error=4U;
        else {
            q->view=*snapshot;
            uint32_t published=q->view.published_ms;
            XE_NP_Sensors_RefreshValidity(&q->view,now);
            q->view.published_ms=published;
            if(++q->serial==0U)++q->serial;
            q->token=q->serial;q->latched_ms=now;
        }
    } else if(!error && (!token || token!=q->token ||
                         (uint32_t)(now-q->latched_ms)>=1000U))error=3U;
    memset(out,0,64U);
    xe_np_online_put(out,XE_NP_SENSOR_REPLY_MAGIC);xe_np_online_put(out+4,1U);
    xe_np_online_put(out+8,op);xe_np_online_put(out+12,id);
    xe_np_online_put(out+16,error);xe_np_online_put(out+24,offset);
    if(!error){
        xe_np_online_put(out+20,q->token);xe_np_online_put(out+28,sizeof(q->view));
        memcpy(out+32,(const uint8_t *)&q->view+offset,28U);
    }
    xe_np_online_put(out+60,xe_np_online_crc(out));return 1;
}
#endif
