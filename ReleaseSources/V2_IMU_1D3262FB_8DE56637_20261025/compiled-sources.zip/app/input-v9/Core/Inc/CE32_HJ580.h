#ifndef __CE32_HJ580
#define __CE32_HJ580

#include "stm32f4xx_hal.h"
#include "dataMGR.h"
#include "CE32_macro.h"
#include "main.h"
#include "CE32_UART_INTERCOM.h"

/*
 * Keep the legacy CE64-facing surface so the old system/filesystem/submodule
 * code remains understandable. The implementation underneath is adapted for
 * HJ185IMH, not the original HJ580 command set.
 */

#define CE32_STATE_CONNECTED 0x0001U
#define CE32_STATE_REC 0x0002U
#define CE32_STATE_PREV 0x0004U
#define CE32_STATE_STIM 0x0008U
#define CE32_STATE_DSP 0x0010U
#define CE32_STATE_COMMOK 0x0020U
#define CE32_STATE_SYNCSTART 0x0040U
#define CE32_STATE_SYNCED 0x0080U

#define HJ580_PARITY_NA 0U
#define HJ580_PARITY_ODD 1U
#define HJ580_PARITY_EVEN 2U

#define HJ580_STOPBIT_1 1U
#define HJ580_STOPBIT_2 2U

#define HJ580_STATE_IDLE 0x0001U
#define HJ580_STATE_TXON 0x0002U
#define HJ580_STATE_SLEEP 0x0004U
#define HJ580_STATE_CONFIG 0x0008U
#define HJ580_STATE_CONNECTED 0x0010U
#define HJ580_STATE_ERROR 0x0020U
#define HJ580_STATE_RXON 0x0040U
#define HJ580_STATE_MASTER 0x0080U
#define HJ580_STATE_STOP 0x0100U
#define HJ580_STATE_CMDRESP 0x0200U
#define HJ580_STATE_CMD_RESP_PEND 0x0400U
#define HJ580_STATE_WAITRESP 0x0800U
#define HJ580_STATE_CE32_CMD 0x1000U
#define HJ580_STATE_CE32_CMD_PEND 0x2000U
#define HJ580_STATE_TXDMA 0x4000U
#define HJ580_STATE_BONDED 0x8000U

#define HJ580_SIG_AUX1 0x01U
#define HJ580_SIG_AUX2 0x02U
#define HJ580_SIG_AUX3 0x04U
#define HJ580_SIG_EXT1 0x08U
#define HJ580_SIG_EXT2 0x10U
#define HJ580_SIG_EXT3 0x20U
#define HJ580_SIG_MASK 0x3FU

#define BLE_RX_SIZE CMD_BUFSIZE
#define HJ_CFG_CMD_SEQ 2U
#define HJ_CFG_CMD_MAXSIZE CMD_MAXSIZE
#define HJ_CFG_CMD_BUFSIZE (HJ_CFG_CMD_MAXSIZE * HJ_CFG_CMD_SEQ)

typedef struct
{
    uint16_t state;
    int8_t RSSI;
    uint8_t hw_version;
    int16_t voltage;
    int16_t capacity;
    int16_t data_recorded;
    int16_t channel_number;
    int16_t preview_channel;
    uint16_t EXT_SIG;
    uint16_t version;
    uint8_t MAC[6];
} CE32_Basic_BLE_Info;

typedef struct
{
    __IO uint16_t state;
    __IO uint8_t buffer[HJ_CFG_CMD_BUFSIZE];
    __IO uint8_t *cmd_buf[HJ_CFG_CMD_SEQ];
    __IO uint16_t cmd_pad[HJ_CFG_CMD_SEQ];
    __IO uint32_t cmd_len[HJ_CFG_CMD_SEQ];
    __IO uint16_t free_buffer, buffer_boundary_correction;
    CE32_SyncTypeDef cmd_time[HJ_CFG_CMD_SEQ];
    CE32_MEMORY_PTR stream_in, stream_out;

    __IO uint32_t cmd_idx_in;
    __IO uint32_t cmd_ptr_in;
    __IO uint32_t cmd_idx_out;

    __IO uint32_t cmd_pending;
    uint32_t IN_OK, IN_Fail;
} CE32_command_cfg;

typedef struct
{
    CE32_INTERCOM_Handle COMM;
    CE32_Basic_BLE_Info DEV;
    __IO uint16_t state;

    uint32_t baud;
    uint8_t parity;
    uint8_t stop_bit;

    char DeviceName[50];
    char DeviceMAC[6];
    char PeerMAC[6];
    char BondMAC[6];
    char ADVdata[50];

    __IO float transmit_delay;
    CE32_command_cfg Config_CMD_TX, Config_CMD_RX;
    dataMGR RX_MGR;
    dataMGR TX_MGR;
} CE32_HJ580_Handle;

extern CE32_HJ580_Handle BLE_handle;

int HJ_WaitCmdResp(CE32_HJ580_Handle *handle);
int CE32_HJ_Setting(CE32_HJ580_Handle *handle, char *RX_buf, uint16_t RX_size, char *TX_buf, uint16_t TX_size);
int CE32_HJ_Init_Slave(CE32_HJ580_Handle *handle);
int CE32_HJ_Init_Master(CE32_HJ580_Handle *handle);
void CE32_HJ_RXISR(CE32_HJ580_Handle *handle);
void HJ_UartSend(UART_HandleTypeDef *huart, char *buf);
void HJ_UartSend_LimLen(UART_HandleTypeDef *huart, char *buf, int maxLen);
void CE32_UART_TRANSMIT_PREV_DMA(uint8_t *data, uint16_t size, int16_t sig1, int32_t sig2, uint16_t *sig3);
void CE32_UART_TRANSMIT_IT(UART_HandleTypeDef *huart, uint8_t *data, uint16_t size, int16_t sig1, int32_t sig2, uint16_t *sig3);
void CE32_UART_TRANSMIT_VAR_HEADER_DMA(uint8_t *header, uint16_t sizeHeader, uint8_t *data, uint16_t size);
int CE32_HJ_TX_EnqueueCmd_DMA(CE32_INTERCOM_Handle *handle, unsigned char *data, int cmd_len);
void HJ_BlockTransmit(char *buf, uint32_t size);
void CE32_UART_Init_unconfigState(UART_HandleTypeDef *huart);
void CE32_UART_Init_configedState(UART_HandleTypeDef *huart);
int CE32_HJ_HandShake(CE32_HJ580_Handle *handle);
int CE32_HJ_READPEERINFO(CE32_HJ580_Handle *handle);
int CE32_HJ_READRSSI(CE32_HJ580_Handle *handle);
int CE32_HJ_BondMAC(CE32_HJ580_Handle *handle);
int CE32_HJ_DisbondMAC(CE32_HJ580_Handle *handle);
int CE32_HJ_SetAdvData(CE32_HJ580_Handle *handle, char *data, uint8_t data_len);

void CE32_HJ_Upload_State(CE32_HJ580_Handle *handle);
void CE32_HJ185_DiagNoteStreamRxIrq(void);
void CE32_HJ185_DiagNoteStreamRawByte(uint8_t data);
void CE32_HJ185_DiagNoteStreamCmdRx(const uint8_t *data, uint32_t data_len);
void CE32_HJ185_DiagNoteStreamCmdTxLaunch(const uint8_t *data, uint32_t data_len);
void CE32_HJ185_BootBlindApplyNameEarly(UART_HandleTypeDef *huart, const char *device_name);
int CE32_HJ185_ConfigureNameMinimal(CE32_HJ580_Handle *handle, const char *device_name);
int CE32_HJ580_RX_CONFIG_ISR(CE32_HJ580_Handle *handle_BLE);
int CE32_HJ580_RX_ISR(CE32_HJ580_Handle *handle_BLE);
int CE32_HJ580_RX_ISR_SWI(CE32_HJ580_Handle *handle);
int CE32_HJ580_RX_ProcBuffer(CE32_HJ580_Handle *handle);
int CE32_HJ580_RX_PREV_ISR(CE32_HJ580_Handle *handle_BLE);
int CE32_HJ580_TX_CONFIG_ISR(CE32_HJ580_Handle *handleBLE);
void HJ580_EnterConfigMode(CE32_HJ580_Handle *handle);
void HJ580_ExitConfigMode(CE32_HJ580_Handle *handle);
void CE32_HJ580_TX_Start(CE32_HJ580_Handle *handle);
void CE32_HJ580_TX_Start_DMA(CE32_HJ580_Handle *handle);
int CE32_HJ580_TX_Stop_DMA(CE32_HJ580_Handle *handle);
void CE32_HJ580_Start(CE32_HJ580_Handle *handle);
void CE32_HJ580_RX_dataCached_Act(CE32_HJ580_Handle *handle_IC);
void CE32_HJ_CMD_RECEIVED_ACT(CE32_HJ580_Handle *handle);

int CE32_HJ580_COMMAND_Init(CE32_command_cfg *handle);
int CE32_HJ580_COMMAND_EnqueueCmd_MEMCopy(CE32_command_cfg *handle, unsigned char *data, int cmd_len);
int CE32_HJ580_COMMAND_Enqueue_Allocate(CE32_command_cfg *handle, int cmd_len, uint8_t **ptr);
int CE32_HJ580_COMMAND_Enqueue_Byte(CE32_command_cfg *handle, unsigned char data);
int CE32_HJ580_COMMAND_Enqueue_BytesLeft(CE32_command_cfg *handle);
int CE32_HJ580_COMMAND_Enqueue_Byte_Abort(CE32_command_cfg *handle);
int CE32_HJ580_COMMAND_EnqueueCmd_buffered(CE32_command_cfg *handle);
int CE32_HJ580_COMMAND_DequeueCmd(CE32_command_cfg *handle, uint8_t **data_ptr, uint32_t *cmd_len);
int CE32_HJ580_COMMAND_Dequeue_Byte(CE32_command_cfg *handle, uint8_t *data);
int CE32_HJ580_COMMAND_GetPendingCounts(CE32_command_cfg *handle);
int CE32_HJ580_COMMAND_GetCmdPointer(CE32_command_cfg *handle, uint8_t **data_ptr, uint32_t *cmd_len);
int CE32_HJ580_COMMAND_DiscardAll(CE32_command_cfg *handle);

#endif
