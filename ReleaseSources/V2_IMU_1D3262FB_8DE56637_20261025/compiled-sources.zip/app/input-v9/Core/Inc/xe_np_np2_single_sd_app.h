#ifndef XE_NP_NP2_SINGLE_SD_APP_H
#define XE_NP_NP2_SINGLE_SD_APP_H

/* Dedicated V2 NP2 SD application.  This is deliberately separate from the
 * legacy NP1 application and the resident USB service: it owns PSSI, GPDMA,
 * I2C2/3, CRC and SDMMC1 until reset. */
#include <stdint.h>

#ifndef XE_NP_NP2_SD_APP_ENABLE
#define XE_NP_NP2_SD_APP_ENABLE 0U
#endif

#if XE_NP_NP2_SD_APP_ENABLE
#include "stm32u5xx_hal.h"

#define XE_NP_NP2_SINGLE_SD_MAILBOX_MAGIC 0x4E325344U /* "N2SD" */
#define XE_NP_NP2_SINGLE_SD_MAILBOX_VERSION 7U
#define XE_NP_NP2_SINGLE_SD_START_KEY 0x4E325253U /* "N2RS" */

enum {
    XE_NP_NP2_SINGLE_SD_CMD_NONE=0U,
    XE_NP_NP2_SINGLE_SD_CMD_FORMAT=1U,
    XE_NP_NP2_SINGLE_SD_CMD_START=2U,
    XE_NP_NP2_SINGLE_SD_CMD_STOP=3U
};
enum {
    XE_NP_NP2_SINGLE_SD_IDLE=0U,
    XE_NP_NP2_SINGLE_SD_UNMOUNTED=1U,
    XE_NP_NP2_SINGLE_SD_STARTING=2U,
    XE_NP_NP2_SINGLE_SD_RECORDING=3U,
    XE_NP_NP2_SINGLE_SD_FINALIZING=4U,
    XE_NP_NP2_SINGLE_SD_COMPLETE=5U,
    XE_NP_NP2_SINGLE_SD_FAILED=6U
};
enum {
    XE_NP_NP2_SINGLE_SD_ERROR_NONE=0U,
    XE_NP_NP2_SINGLE_SD_ERROR_BIND=1U,
    XE_NP_NP2_SINGLE_SD_ERROR_MOUNT=2U,
    XE_NP_NP2_SINGLE_SD_ERROR_COMMAND=3U,
    XE_NP_NP2_SINGLE_SD_ERROR_RANGE=4U,
    XE_NP_NP2_SINGLE_SD_ERROR_ACQUISITION=5U,
    XE_NP_NP2_SINGLE_SD_ERROR_RECORD=6U,
    XE_NP_NP2_SINGLE_SD_ERROR_PREPARE=7U,
    XE_NP_NP2_SINGLE_SD_ERROR_FINALIZE=8U
};

/* This object is in the stopped-only NOINIT mailbox.  A debugger writes the
 * command arguments first and `command` last, with a new nonzero nonce.
 * START needs START_KEY; FORMAT additionally needs the exact SD format key.
 * No command is acted on twice, and there is intentionally no auto-start. */
typedef struct {
    uint32_t magic,version;
    volatile uint32_t command,nonce,command_key,requested_blocks;
    uint32_t accepted_nonce,state,error;
    uint32_t card_blocks,next_start_lba,start_lba,end_lba,session_id;
    uint32_t acquisition_state,acquisition_error,record_state,record_error;
    uint32_t committed_chunks,max_pack_ms,max_write_ms;
    uint32_t sd_phase,sd_error,sd_status,sd_cmd25,sd_cmd12;
    uint32_t cid[4];
    uint32_t startup_stage;
    uint32_t startup_detail;
    uint32_t session_state,session_error;
    uint32_t control_state,control_error,control_transactions;
    uint32_t control_transaction,control_expected;
    uint32_t control_progress,control_indices;
    uint32_t control_i2c_error,control_i2c_isr,control_i2c_cr1,control_i2c_cr2,control_i2c_state;
    uint32_t control_i2c_thread_assists;
    uint32_t capture_setup_stage,capture_state;
    uint32_t capture_produced_lo,capture_produced_hi,capture_consumed_lo,capture_consumed_hi;
    uint32_t capture_irq_count,capture_max_backlog;
    uint32_t capture_fault_offset,capture_fault_events,capture_fault_tick,capture_fault_raw,capture_fault_active;
    uint32_t capture_invalidate_calls,capture_invalidate_fail_mask;
    uint32_t capture_invalidate_address,capture_invalidate_count;
    uint32_t max_pack_cycles;
} XE_NP_Np2SingleSdMailbox;

extern volatile XE_NP_Np2SingleSdMailbox xe_np_np2_single_sd_mailbox;
int XE_NP_Np2SingleSdApp_Init(SD_HandleTypeDef *,DCACHE_HandleTypeDef *);
void XE_NP_Np2SingleSdApp_Service(void);
#endif
#endif
