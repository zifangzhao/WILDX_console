#ifndef XE_NP_USB_MSC_H
#define XE_NP_USB_MSC_H
#include "xe_np_hal.h"
#define XE_NP_USB_MSC_PID 0xB388U
void XE_NP_UsbMsc_SelectBootMode(void);
int XE_NP_UsbMsc_IsSelected(void);
void XE_NP_UsbMsc_Init(PCD_HandleTypeDef *);
void XE_NP_UsbMsc_Service(void);
void XE_NP_UsbMsc_Configure(uint8_t);
void XE_NP_UsbMsc_Reset(void);
void XE_NP_UsbMsc_DataIn(void);
void XE_NP_UsbMsc_DataOut(uint32_t);
void XE_NP_UsbMsc_ClassReset(void);
void XE_NP_UsbMsc_ClearHalt(uint8_t);
int XE_NP_Board_InitSdForUsb(void);
#endif
