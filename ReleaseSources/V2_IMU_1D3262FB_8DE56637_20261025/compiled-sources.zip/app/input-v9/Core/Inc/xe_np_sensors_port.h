#ifndef XE_NP_SENSORS_PORT_H
#define XE_NP_SENSORS_PORT_H
#include "stm32u5xx_hal.h"
#include "xe_np_sensors.h"
void XE_NP_SensorsPort_Init(I2C_HandleTypeDef *imu,I2C_HandleTypeDef *environment);
void XE_NP_SensorsPort_Service(uint8_t recording_active);
/* Stopped profile changes/diagnostics only; no waits in the clock boundary. */
void XE_NP_SensorsPort_Pause(void);
void XE_NP_SensorsPort_Resume(void);
int XE_NP_SensorsPort_Complete(I2C_HandleTypeDef *,uint32_t error);
const XE_NP_SensorSnapshot *XE_NP_SensorsPort_GetSnapshot(void);
/* SWD-visible copy: atomic index into two foreground-published buffers. */
extern XE_NP_SensorSnapshot xe_np_sensor_snapshot[2];
extern volatile uint32_t xe_np_sensor_snapshot_index;
#endif
