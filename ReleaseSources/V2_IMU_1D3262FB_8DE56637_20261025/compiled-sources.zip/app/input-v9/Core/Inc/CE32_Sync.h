#ifndef XE_NP_CE32_SYNC_H
#define XE_NP_CE32_SYNC_H

#include "xe_np_hal.h"

#define SUBSEC_PRECISION 9999U

typedef struct
{
    uint32_t Seconds;
    uint32_t SubSeconds;
} CE32_SyncTypeDef;

typedef struct
{
    uint32_t Milliseconds;
} CE32_Timebase;

#define CE32_DELAYESTIMATE_STATE_PEND 0x00U
#define CE32_DELAYESTIMATE_STATE_BASELINE 0x01U
#define CE32_DELAYESTIMATE_STATE_CAL 0x02U
#define CE32_DELAYESTIMATE_STATE_FINISH 0x04U
#define CE32_DELAYESTIMATE_STATE_ABORT 0x08U

#define CE32_DELAYESTIMATE_SAMPLES 256U
#define CE32_DELAYESTIMATE_ESTIMATORS 1U

typedef struct
{
    __IO uint16_t state;
    __IO float proc_delay;
    __IO float t_diff;
    __IO float delay[CE32_DELAYESTIMATE_ESTIMATORS];
    __IO float delay_temp[CE32_DELAYESTIMATE_ESTIMATORS];
    __IO float temp_mean[CE32_DELAYESTIMATE_ESTIMATORS];
    __IO float std[CE32_DELAYESTIMATE_ESTIMATORS];
    __IO float mean_corrected[CE32_DELAYESTIMATE_ESTIMATORS];
    __IO float median[CE32_DELAYESTIMATE_ESTIMATORS];
    __IO uint16_t count_current;
    __IO uint16_t count;
    __IO uint16_t fail_cnt;
    float rtc_diff[CE32_DELAYESTIMATE_ESTIMATORS][CE32_DELAYESTIMATE_SAMPLES];
} CE32_DelayEstimate;

extern CE32_DelayEstimate delay_estimate;

void CE32_Time2Sync(const RTC_TimeTypeDef *time, CE32_SyncTypeDef *sync);
float CE32_Sync_TimeDiff(const CE32_SyncTypeDef *sync, const CE32_SyncTypeDef *sync1);
void CE32_Sync_DelayEstimate_init(CE32_DelayEstimate *estimate);
uint16_t CE32_Sync_DelayEstimate_inputdata(CE32_DelayEstimate *estimate, float time_diff);
HAL_StatusTypeDef CE32_RTC_SetTimeCompat(RTC_HandleTypeDef *hrtc, RTC_TimeTypeDef *time, uint32_t format);
HAL_StatusTypeDef CE32_RTC_AdjustTime(RTC_HandleTypeDef *hrtc, float time_adjustment);
int CE32_Sync_Sort(float *ptr, uint32_t len);

CE32_FORCE_INLINE void CE32_RTC_GetTime(RTC_HandleTypeDef *hrtc, CE32_SyncTypeDef *sync)
{
    RTC_TimeTypeDef t1;
    RTC_TimeTypeDef t2;
    RTC_DateTypeDef date_sink;

    if((hrtc == NULL) || (sync == NULL))
    {
        return;
    }

    do
    {
        (void)HAL_RTC_GetTime(hrtc, &t1, RTC_FORMAT_BIN);
        (void)HAL_RTC_GetDate(hrtc, &date_sink, RTC_FORMAT_BIN);
        (void)HAL_RTC_GetTime(hrtc, &t2, RTC_FORMAT_BIN);
        (void)HAL_RTC_GetDate(hrtc, &date_sink, RTC_FORMAT_BIN);
    } while(t1.Seconds != t2.Seconds);

    sync->Seconds = ((uint32_t)t2.Minutes * 60U) + (uint32_t)t2.Seconds;
    sync->SubSeconds = SUBSEC_PRECISION - t2.SubSeconds;
}

#endif
