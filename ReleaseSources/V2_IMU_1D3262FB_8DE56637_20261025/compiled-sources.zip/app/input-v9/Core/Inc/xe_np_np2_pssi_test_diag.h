#ifndef XE_NP_NP2_PSSI_TEST_DIAG_H
#define XE_NP_NP2_PSSI_TEST_DIAG_H

#include <stdint.h>

/* SWD-visible result of the bounded NP2 digital/normal-ADC PSSI diagnostic.
 * It writes only volatile ASIC control and shift-chain registers, captures a
 * retained raw PSSI window (normal ADC mode certifies framing only), then
 * fails closed (PSSI/DMA stopped, reset asserted, MCO off, rail off). */
#define XE_NP_NP2_PSSI_TEST_DIAG_MAGIC   0x4E503254UL /* "NP2T" */
#define XE_NP_NP2_PSSI_TEST_DIAG_VERSION 9UL

/* Opt-in HIL comparison only. This is not a recording or a PSSI result. */
#ifndef XE_NP_NP2_DIAG_INDEPENDENT_GPIO
#define XE_NP_NP2_DIAG_INDEPENDENT_GPIO 0U
#endif
#if XE_NP_NP2_DIAG_INDEPENDENT_GPIO
typedef struct {
    uint32_t magic, version, source_hz, core_hz;
    uint32_t ticks, timeout, mco_register, clock_pin;
    uint32_t pssi_cr_before, dma_ccr_before, pssi_cr_after, dma_ccr_after;
    uint32_t periods_address, periods_bytes, elapsed_cycles, terminal;
    uint32_t probe_index;
} XE_NP_Np2GpioDiag;
extern volatile XE_NP_Np2GpioDiag xe_np_np2_gpio_diag;
#endif

enum {
    XE_NP_NP2_TEST_DIAG_INIT = 1U,
    XE_NP_NP2_TEST_DIAG_POWER_WAIT,
    XE_NP_NP2_TEST_DIAG_CLOCK_WAIT,
    XE_NP_NP2_TEST_DIAG_RESET_WAIT,
    XE_NP_NP2_TEST_DIAG_VERIFY_ID,
    XE_NP_NP2_TEST_DIAG_HOLD_REC,
    XE_NP_NP2_TEST_DIAG_HOLD_REC_VERIFY,
    XE_NP_NP2_TEST_DIAG_CLEAR_CAL,
    XE_NP_NP2_TEST_DIAG_CLEAR_CAL_VERIFY,
    XE_NP_NP2_TEST_DIAG_CHAIN_LENGTH_LO,
    XE_NP_NP2_TEST_DIAG_CHAIN_LENGTH_LO_VERIFY,
    XE_NP_NP2_TEST_DIAG_CHAIN_LENGTH_HI,
    XE_NP_NP2_TEST_DIAG_CHAIN_LENGTH_HI_VERIFY,
    XE_NP_NP2_TEST_DIAG_CHAIN_WRITE,
    XE_NP_NP2_TEST_DIAG_CHAIN_VERIFY,
    XE_NP_NP2_TEST_DIAG_SYNC_WRITE,
    XE_NP_NP2_TEST_DIAG_SYNC_VERIFY,
    XE_NP_NP2_TEST_DIAG_ENABLE_PATTERN,
    XE_NP_NP2_TEST_DIAG_ENABLE_PATTERN_VERIFY,
    XE_NP_NP2_TEST_DIAG_PATTERN_SETTLE,
    XE_NP_NP2_TEST_DIAG_ARM_PSSI,
    XE_NP_NP2_TEST_DIAG_RELEASE_REC,
    XE_NP_NP2_TEST_DIAG_RELEASE_REC_VERIFY,
    XE_NP_NP2_TEST_DIAG_WAIT_WINDOW,
    XE_NP_NP2_TEST_DIAG_VALIDATE,
    XE_NP_NP2_TEST_DIAG_COMPLETE,
    XE_NP_NP2_TEST_DIAG_SOFT_RESET_FF,
    XE_NP_NP2_TEST_DIAG_SOFT_RESET_ZERO,
    XE_NP_NP2_TEST_DIAG_SOFT_RESET_OP_VERIFY,
    XE_NP_NP2_TEST_DIAG_SOFT_RESET_REC_VERIFY,
    XE_NP_NP2_TEST_DIAG_FINAL_HOLD,
    XE_NP_NP2_TEST_DIAG_FINAL_HOLD_VERIFY,
    XE_NP_NP2_TEST_DIAG_EEPROM_READ,
    XE_NP_NP2_TEST_DIAG_RAW_CAPTURED, /* Normal-mode framing only, not qualification. */
    XE_NP_NP2_TEST_DIAG_FINAL_CAL_WRITE,
    XE_NP_NP2_TEST_DIAG_FINAL_CAL_VERIFY,
    XE_NP_NP2_TEST_DIAG_FAILED = 0xFFU
};

enum {
    XE_NP_NP2_TEST_DIAG_ERROR_NONE = 0U,
    XE_NP_NP2_TEST_DIAG_ERROR_CLOCK = 1U,
    XE_NP_NP2_TEST_DIAG_ERROR_HSLV = 2U,
    XE_NP_NP2_TEST_DIAG_ERROR_I2C_INIT = 3U,
    XE_NP_NP2_TEST_DIAG_ERROR_MCO = 4U,
    XE_NP_NP2_TEST_DIAG_ERROR_I2C = 5U,
    XE_NP_NP2_TEST_DIAG_ERROR_PROBE_ID = 6U,
    XE_NP_NP2_TEST_DIAG_ERROR_CHAIN = 7U,
    XE_NP_NP2_TEST_DIAG_ERROR_PSSI_ARM = 8U,
    XE_NP_NP2_TEST_DIAG_ERROR_PSSI_SOURCE = 9U,
    XE_NP_NP2_TEST_DIAG_ERROR_PATTERN = 10U,
    XE_NP_NP2_TEST_DIAG_ERROR_CACHE = 11U,
    XE_NP_NP2_TEST_DIAG_ERROR_CAL_GROUND = 12U
};

/* validation_flags: transport evidence recorded by the diagnostic.  The
 * documented all-0x555/all-0xAAA digital pattern is intentionally separate:
 * a difference is exposed to the host, never treated as a phase correction. */
enum {
    XE_NP_NP2_TEST_DIAG_VALID_SYNC_UNIQUE = 1U,
    XE_NP_NP2_TEST_DIAG_VALID_WORDS_STABLE = 2U,
    XE_NP_NP2_TEST_DIAG_VALID_LANES_AGREE = 4U,
    XE_NP_NP2_TEST_DIAG_VALID_DOC_DIGITAL_WORDS = 8U,
    XE_NP_NP2_TEST_DIAG_NORMAL_RAW_FRAMED = 16U
};

typedef struct {
    uint32_t magic, version, state, error;
    uint32_t hclk_hz, sysclk_hz, flash_optr, rcc_cfgr1;
    uint32_t started_ms, state_since_ms, i2c_error, i2c_operations;
    uint32_t id, op, rec, cal, status, chain_fail_mask;
    uint32_t chain, chain_pass, chain_index, sync_index;
    uint32_t pssi_origin, release_barrier, produced, raw_window_start;
    uint32_t raw_window_bytes, raw_window_address, raw_checksum, pattern_matches;
    uint32_t matched_phase, first_mismatch_tick, expected_wire, observed_wire;
    uint32_t validation_flags, digital_word_slot0, digital_word_slot1;
    uint32_t dma_irq_count, dma_error, capture_stage, pssi_cr, pssi_ris;
    uint32_t shift_method, chain_status[6];
    uint32_t sample_falling, eeprom_error, eeprom_reads, eeprom_match;
    uint8_t eeprom[2][84]; /* Two read-only identity snapshots, offsets 00..53. */
    uint32_t probe_mode, chain_image; /* mode 0=digital, 1=normal, 2=grounded CH_CAL; image 0=zero,1=ground-bank0. */
    uint32_t clock_stop_before_susp; /* Diagnostic-only shutdown A/B, 0 or 1. */
    /* v9 preserves the exact producer snapshot that tripped a live-DMA guard. */
    uint32_t dma_fault_offset, dma_fault_events, dma_fault_ms;
    uint32_t dma_fault_flags, dma_fault_active;
} XE_NP_Np2PssiTestDiag;

extern volatile XE_NP_Np2PssiTestDiag xe_np_np2_pssi_test_diag;

void XE_NP_Np2PssiTestDiag_Init(void);
void XE_NP_Np2PssiTestDiag_Service(void);

#endif
