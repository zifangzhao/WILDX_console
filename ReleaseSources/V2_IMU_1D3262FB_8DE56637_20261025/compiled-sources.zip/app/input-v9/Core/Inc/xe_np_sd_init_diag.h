#ifndef XE_NP_SD_INIT_DIAG_H
#define XE_NP_SD_INIT_DIAG_H
#include <stdint.h>
#ifndef XE_NP_SD_TEAMGROUP_UHS_STARTUP_TEST
#define XE_NP_SD_TEAMGROUP_UHS_STARTUP_TEST 0U
#endif
#ifndef XE_NP_SD_CMD11_PIN_COMPAT_ENABLE
#define XE_NP_SD_CMD11_PIN_COMPAT_ENABLE 0U
#endif
#ifndef XE_NP_SD_XPC_ENABLE
#define XE_NP_SD_XPC_ENABLE 0U
#endif
#ifndef XE_NP_SD_ALLOW_S18R
#define XE_NP_SD_ALLOW_S18R 1U
#endif
#ifndef XE_NP_SD_CMD11_TRACE_ONLY_DIAG
#define XE_NP_SD_CMD11_TRACE_ONLY_DIAG 0U
#endif
#ifndef XE_NP_SD_CMD11_TRACE_INIT_HZ
#define XE_NP_SD_CMD11_TRACE_INIT_HZ 400000UL
#endif
#ifndef XE_NP_SD_INIT_FALLING_EDGE
#define XE_NP_SD_INIT_FALLING_EDGE 0U
#endif
#ifndef XE_NP_SD_CMD11_TRACE_INIT_DIRECT_CKIN
#define XE_NP_SD_CMD11_TRACE_INIT_DIRECT_CKIN 0U
#endif
#if XE_NP_SD_CMD11_TRACE_INIT_DIRECT_CKIN
#if !defined(XE_NP_SD_IDENTIFY_ONLY_DIAG) || !XE_NP_SD_IDENTIFY_ONLY_DIAG || !XE_NP_SD_CMD11_TRACE_ONLY_DIAG
#error "CMD11 direct CKIN requires trace-only identification"
#endif
_Static_assert(XE_NP_SD_CMD11_TRACE_INIT_HZ==400000UL && !XE_NP_SD_INIT_FALLING_EDGE,
               "CMD11 direct CKIN is the matched rising 400-kHz experiment");
#endif
#if defined(XE_NP_SD_IDENTIFY_ONLY_DIAG) && XE_NP_SD_IDENTIFY_ONLY_DIAG
/* Native-init launch dephasing also persists after identification; it is not
 * a receive-delay selector. Keep strict 3.3-V identification unchanged. */
_Static_assert(!XE_NP_SD_INIT_FALLING_EDGE || XE_NP_SD_CMD11_TRACE_ONLY_DIAG,
               "identify falling launch phase requires CMD11 trace-only");
#endif

/* Power-on negotiation only: COMPLETE does not claim CID/CSD or block I/O. */
#define XE_NP_SD_INIT_MAGIC 0x5344494eUL
#define XE_NP_SD_INIT_CMD0 1U
#define XE_NP_SD_INIT_CMD8 2U
#define XE_NP_SD_INIT_CMD55 3U
#define XE_NP_SD_INIT_ACMD41 4U
#define XE_NP_SD_INIT_CMD11 5U
#define XE_NP_SD_INIT_SWITCH 6U
#define XE_NP_SD_INIT_COMPLETE 7U
typedef struct {
    uint32_t magic, version, attempts, stage, error, elapsed_ms;
    uint32_t cmd8_error, cmd8_response, cmd55_response;
    uint32_t acmd41_argument, ocr, ocr_trials;
    uint32_t sdmmc_sta, sdmmc_respcmd, sdmmc_clkcr;
} XE_NP_SdInitDiag;
extern volatile XE_NP_SdInitDiag xe_np_sd_init_diag;

#if XE_NP_SD_CMD11_PIN_COMPAT_ENABLE
_Static_assert(!XE_NP_SD_CMD11_TRACE_ONLY_DIAG && !XE_NP_SD_INIT_FALLING_EDGE &&
               !XE_NP_SD_CMD11_TRACE_INIT_DIRECT_CKIN && !XE_NP_SD_TEAMGROUP_UHS_STARTUP_TEST,
               "shared CMD11 pin compatibility uses ordinary rising RX0 initialization");
_Static_assert(SDMMC_SWDATATIMEOUT==500U,"shared CMD11 compatibility bounded software timeout");
#endif
#if XE_NP_SD_CMD11_TRACE_ONLY_DIAG
_Static_assert(SDMMC_SWDATATIMEOUT==500U,"CMD11 trace bounded software timeout");
_Static_assert(XE_NP_SD_CMD11_TRACE_INIT_HZ==100000UL ||
               XE_NP_SD_CMD11_TRACE_INIT_HZ==200000UL ||
               XE_NP_SD_CMD11_TRACE_INIT_HZ==400000UL,"CMD11 trace identification rate");
#endif
#if XE_NP_SD_CMD11_TRACE_ONLY_DIAG || XE_NP_SD_CMD11_PIN_COMPAT_ENABLE
/* Separate opt-in ABI; never enlarge the normal 60-byte initialization record.
 * Slots: pre-CMD11, after R1, CKSTOP before clear, >=1 ms after a latched
 * missing-BUSYD0 failure. Row: tick,STA,POWER,CLKCR,PC_IDR,PD_IDR,PG_ODR,PF_ODR.
 * GPIO values are host-side observations/requests, not measured card rails. */
typedef struct {
    uint32_t magic, version, valid_mask, row_bytes;
    uint32_t rows[4][8];
} XE_NP_SdCmd11Trace;
_Static_assert(sizeof(XE_NP_SdCmd11Trace)==144U,"CMD11 trace ABI");
extern volatile XE_NP_SdCmd11Trace xe_np_sd_cmd11_trace;
#endif

/* ACMD41 bit31 is a response busy flag, not a host request flag. Advertise
 * HCS/S18R only for a CMD8-qualified card and available voltage switching;
 * S18R can be disabled for bounded, deterministic 3.3-V path tests. */
static inline uint32_t XE_NP_SdOcrArgument(uint32_t voltage_window,
                                         uint32_t version2, uint32_t transceiver)
{
    return (voltage_window & 0x00ffffffUL) |
        (version2 ? 0x40000000UL : 0U) |
        ((version2 && XE_NP_SD_XPC_ENABLE) ? 0x10000000UL : 0U) |
        ((version2 && transceiver && XE_NP_SD_ALLOW_S18R) ? 0x01000000UL : 0U);
}
#endif
