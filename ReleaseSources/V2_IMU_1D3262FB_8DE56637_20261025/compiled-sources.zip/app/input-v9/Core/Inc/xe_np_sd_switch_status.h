#ifndef XE_NP_SD_SWITCH_STATUS_H
#define XE_NP_SD_SWITCH_STATUS_H
#include <stdint.h>
#include <stddef.h>
/* Keep unmodified 200 mA boards safe by default. Upgraded-supply qualification
 * builds must explicitly provide both a supply budget and a CMD6 class.
 * VDD-only removable UHS-I tests use group4 function0/1 (200/400 mA).
 * Neither the class nor the supplied budget measures/clamps transient current. */
#ifndef XE_NP_SD_CARD_SUPPLY_BUDGET_MA
#define XE_NP_SD_CARD_SUPPLY_BUDGET_MA 200U
#endif
#ifndef XE_NP_SD_CARD_MAX_CURRENT_MA
#define XE_NP_SD_CARD_MAX_CURRENT_MA 200U
#endif
#if XE_NP_SD_CARD_MAX_CURRENT_MA == 200U
#define XE_NP_SD_UHS_POWER_FUNCTION 0U
#elif XE_NP_SD_CARD_MAX_CURRENT_MA == 400U
#define XE_NP_SD_UHS_POWER_FUNCTION 1U
#else
#error "VDD-only SD qualification supports only the 200/400 mA classes"
#endif
#if XE_NP_SD_CARD_MAX_CURRENT_MA > XE_NP_SD_CARD_SUPPLY_BUDGET_MA
#error "SD current class exceeds the confirmed card supply budget"
#endif
/* Private SDR50/SDR104 driver control. 15 leaves the driver unchanged;
 * 0/1/2/3 select B/A/C/D independently of the mandatory power budget. */
#ifndef XE_NP_SD_UHS_DRIVER_TYPE
#define XE_NP_SD_UHS_DRIVER_TYPE 15U
#endif
#if (XE_NP_SD_UHS_DRIVER_TYPE > 3U) && (XE_NP_SD_UHS_DRIVER_TYPE != 15U)
#error "Invalid SD UHS driver type"
#endif
static inline uint32_t XE_NP_SdUhsSwitchArgument(uint32_t argument)
{
    uint32_t function=argument&15U;
    if(function>=2U && function<=4U)
        argument=(argument & ~0x0000f000UL) | (XE_NP_SD_UHS_POWER_FUNCTION<<12U);
    if((function==2U || function==3U) && XE_NP_SD_UHS_DRIVER_TYPE!=15U)
        return (argument & ~0x00000f00UL) | (XE_NP_SD_UHS_DRIVER_TYPE<<8U);
    return argument;
}
/* CMD6 support fields are big-endian wire pairs; selected groups occupy
 * nibbles from byte16 backwards. Reject 'no influence' as a selected function. */
static inline int XE_NP_SdSwitchGroupMatches(const uint8_t *status,size_t bytes,
                                            uint32_t group,uint32_t function)
{
    uint32_t support,offset,selected;
    if(!status || bytes!=64U || group<1U || group>6U || function>=15U)return 0;
    offset=14U-2U*group;
    support=((uint32_t)status[offset]<<8U)|status[offset+1U];
    selected=(status[16U-(group-1U)/2U] >> (((group-1U)%2U)*4U)) & 15U;
    return (support & (1U<<function)) && selected==function;
}
static inline int XE_NP_SdUhsPowerMatches(const uint8_t *status,size_t bytes,uint32_t function)
{
    if(function<2U || function>4U)return 1;
    return XE_NP_SdSwitchGroupMatches(status,bytes,4U,XE_NP_SD_UHS_POWER_FUNCTION);
}
/* CMD6 group-1 support is SSR-like wire bytes12..13; selected function is
 * byte16 low nibble. A capability bit alone does not prove the switch. */
static inline int XE_NP_SdSwitchStatusMatches(const uint8_t *status,size_t bytes,uint32_t function)
{
    if(!status || bytes!=64U || function>4U)return 0;
    return XE_NP_SdSwitchGroupMatches(status,bytes,1U,function);
}
#endif
