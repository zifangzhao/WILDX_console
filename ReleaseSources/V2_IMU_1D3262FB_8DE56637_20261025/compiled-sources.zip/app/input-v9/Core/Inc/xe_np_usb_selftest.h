#ifndef XE_NP_USB_SELFTEST_H
#define XE_NP_USB_SELFTEST_H
#include <stdint.h>

/* Resident V2 USB only. OUT 0x78: wValue=command, wIndex=wLength=0.
 * IN 0x79: wValue=wIndex=0, wLength=256. Little-endian uint32_t words.
 * Tests are idle-only and foreground-owned. No SD write/erase is exposed.
 * Rails remain held until RELEASE or a physical/software reset; USB bus
 * reset/disconnection does not release them. RELEASE keeps the shared USB
 * mux/SD rail on. Reboot to a normal mode before acquiring after diagnostics.
 * SD voltage selection is a manual, host-off measurement, NOT CMD11. */
#define XE_NP_SELFTEST_MAGIC 0x58535432UL
#define XE_NP_SELFTEST_VERSION 1U
#define XE_NP_SELFTEST_RUN 1U
#define XE_NP_SELFTEST_HOLD 2U
#define XE_NP_SELFTEST_HOLD_1V8 3U
#define XE_NP_SELFTEST_RELEASE 4U
#define XE_NP_SELFTEST_HOLD_3V3 5U
#define XE_NP_SELFTEST_IDLE 0U
#define XE_NP_SELFTEST_QUEUED 1U
#define XE_NP_SELFTEST_RUNNING 2U
#define XE_NP_SELFTEST_DONE 3U
#define XE_NP_SELFTEST_HELD 4U
#define XE_NP_SELFTEST_REJECTED 5U
#define XE_NP_SELFTEST_FLAG_HOLD 1U
#define XE_NP_SELFTEST_FLAG_SD_1V8 2U
#define XE_NP_SELFTEST_FLAG_VOLTS_UNMEASURED 4U
#define XE_NP_SELFTEST_FLAG_SD_READ_ONLY 8U
#define XE_NP_SELFTEST_FLAG_REBOOT_REQUIRED 16U
#define XE_NP_SELFTEST_CHECK_CLOCK (1UL<<0)
#define XE_NP_SELFTEST_CHECK_SRAM (1UL<<1)
#define XE_NP_SELFTEST_CHECK_APP (1UL<<2)
#define XE_NP_SELFTEST_CHECK_USB_IMAGE (1UL<<3)
#define XE_NP_SELFTEST_CHECK_PSRAM (1UL<<4)
#define XE_NP_SELFTEST_CHECK_SD_INFO (1UL<<5)
#define XE_NP_SELFTEST_CHECK_SD_READ (1UL<<6)
#define XE_NP_SELFTEST_CHECK_BMX (1UL<<7)
#define XE_NP_SELFTEST_CHECK_BME (1UL<<8)
#define XE_NP_SELFTEST_CHECK_USB_CONTROL (1UL<<9)
/* Require connected-device/capture or external instrumentation; never pretend
 * a quick register/ID check qualifies these end-to-end functions. */
#define XE_NP_SELFTEST_EXTERNAL_CHECKS 0x3C00UL /* NP, ADC, camera, BLE */

typedef struct {
    uint32_t magic, version, bytes, sequence;
    uint32_t state, command, phase, started_ms, elapsed_ms, flags;
    uint32_t checked, passed, failed, skipped, error, rails_requested;
    uint32_t pf_odr, pd_odr, pg_odr, pc_odr;
    uint32_t cpu_hz, hclk_hz, sd_kernel_hz, rcc_cr, rcc_ccipr1, rcc_ccipr2;
    uint32_t pwr_vosr, pwr_svmcr, pwr_svmsr, usb_phy;
    uint32_t usb_configured, usb_resets, usb_setups, usb_dsts;
    uint32_t app_valid, usb_image_valid, sram_errors;
    uint32_t psram_result, psram_id0, psram_id1, psram_flags;
    uint32_t sd_state, sd_error, sd_init_stage, sd_ocr, sd_sectors, sd_hz, sd_width;
    uint32_t bmx_id, bmx_error, bme_id, bme_error, ble_state_pin, np_reset_pin;
    uint32_t sd_power, sd_clkcr, sd_arg, sd_cmd, sd_sta;
    uint32_t uid[3], reserved[2];
} XE_NP_UsbSelfTestReport;
typedef char XE_NP_UsbSelfTestReport_size[(sizeof(XE_NP_UsbSelfTestReport)==256U)?1:-1];

static inline int XE_NP_SelfTestCommandAllowed(uint32_t command,uint32_t busy,
                                             uint32_t stream_mode,uint32_t running)
{
    return command>=1U && command<=5U && !busy && stream_mode && !running;
}
/* SWD fallback: write one allowed command while the USB service is idle.
 * Same admission/ownership rules apply; never a general memory/SD bridge. */
extern volatile uint32_t xe_np_usb_selftest_command;
extern volatile XE_NP_UsbSelfTestReport xe_np_usb_selftest_report;
void XE_NP_Board_UsbSelfTestSensors(XE_NP_UsbSelfTestReport *report);
int XE_NP_Board_UsbSelfTestPsram(XE_NP_UsbSelfTestReport *report);
void XE_NP_Board_UsbSelfTestSd(XE_NP_UsbSelfTestReport *report);
void XE_NP_Board_UsbSelfTestSdHostOff(void);
#endif
