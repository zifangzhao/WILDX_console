#ifndef XE_NP_NP2_TRIPLE_SYNTHETIC_SD_H
#define XE_NP_NP2_TRIPLE_SYNTHETIC_SD_H

/* A hardware storage/CPU qualification only.  It never enables a probe rail,
 * MCO, PSSI, GPDMA capture channel, I2C controller, or USB. */
#include <stdint.h>

#ifndef XE_NP_NP2_TRIPLE_SYNTHETIC_SD_ENABLE
#define XE_NP_NP2_TRIPLE_SYNTHETIC_SD_ENABLE 0U
#endif

#if XE_NP_NP2_TRIPLE_SYNTHETIC_SD_ENABLE
#include "stm32u5xx_hal.h"

#define XE_NP_NP2_SYNTH_SD_MAILBOX_MAGIC 0x334E5354U /* "TSN3" */
#define XE_NP_NP2_SYNTH_SD_MAILBOX_VERSION 2U

enum {
    XE_NP_NP2_SYNTH_SD_BOOT=0U,
    XE_NP_NP2_SYNTH_SD_RECORDING=1U,
    XE_NP_NP2_SYNTH_SD_DRAINING=2U,
    XE_NP_NP2_SYNTH_SD_READBACK=3U,
    XE_NP_NP2_SYNTH_SD_COMPLETE=4U,
    XE_NP_NP2_SYNTH_SD_FAILED=5U
};
enum {
    XE_NP_NP2_SYNTH_SD_ERROR_NONE=0U,
    XE_NP_NP2_SYNTH_SD_ERROR_ARGUMENT=1U,
    XE_NP_NP2_SYNTH_SD_ERROR_UHS=2U,
    XE_NP_NP2_SYNTH_SD_ERROR_RANGE=3U,
    XE_NP_NP2_SYNTH_SD_ERROR_PACK=4U,
    XE_NP_NP2_SYNTH_SD_ERROR_DEADLINE=5U,
    XE_NP_NP2_SYNTH_SD_ERROR_RING=6U,
    XE_NP_NP2_SYNTH_SD_ERROR_WRITE_START=7U,
    XE_NP_NP2_SYNTH_SD_ERROR_WRITE=8U,
    XE_NP_NP2_SYNTH_SD_ERROR_READ=9U,
    XE_NP_NP2_SYNTH_SD_ERROR_VERIFY=10U
};

typedef struct {
    uint32_t magic,version,state,error;
    uint32_t cpu_hz,pssi_hz,pssi_bits,stored_bits,active_wire_mask;
    uint32_t container_bytes_per_sec,chunk_bytes,chunk_input_ticks,chunk_payload_bytes;
    uint32_t duration_seconds,planned_chunks,planned_rus,start_lba,end_lba;
    uint32_t card_blocks,sd_speed_mode,sd_kernel_hz,sd_bus_hz,signal_1v8;
    uint32_t produced_chunks,written_rus,verified_rus,deadline_misses;
    uint32_t max_producer_late_cycles,max_pack_cycles,max_ru_crc_cycles,max_write_cycles;
    uint32_t max_write_busy_cycles,max_ring_depth,max_source_backlog,sd_error,sd_sta;
    /* Published even when admission fails, so SWD can distinguish card-init,
     * capacity-decode, and UHS-timing failures without relying on cache-stale
     * HAL state. */
    uint32_t card_info_status,card_type,card_block_size,card_block_count;
    uint32_t sd_init_failed,last_speed_attempt,last_speed_status,last_speed_error;
    uint32_t power_stage,power_error,power_ocr,power_ocr_trials;
    uint32_t power_cmd8_response,power_cmd55_response,power_sta,power_clkcr;
    uint32_t write_crc_last,read_crc_last,readback_mismatch_offset;
    uint32_t mco_enabled,probe_power_enabled,pssi_enabled,payload_byte_compare;
    uint32_t started_cycles,record_end_cycles,complete_cycles;
    /* V2 timing. Cycle sums have an explicit high word: 60 seconds exceeds
     * one CYCCNT wrap. Latencies use modular differences within one transfer.
     * Card-ready time is an observed upper bound including polling latency. */
    uint32_t ru_bytes,ru_count,pack_slice_ticks,hot_crc_enabled;
    uint32_t record_elapsed_ms,drain_elapsed_ms,readback_elapsed_ms;
    uint32_t total_pack_cycles_lo,total_pack_cycles_hi,max_pack_slice_cycles;
    uint32_t max_cmd25_setup_cycles,max_dataend_cycles,max_irq_handler_cycles;
    uint32_t max_irq_to_service_cycles,max_ready_poll_cycles,max_retire_to_start_cycles;
    uint32_t completed_write_cycles_lo,completed_write_cycles_hi;
    uint32_t write_ready_count,irq_dataend_count,max_service_interval_cycles,prepared_scratch;
} XE_NP_Np2TripleSyntheticSdMailbox;

extern volatile XE_NP_Np2TripleSyntheticSdMailbox xe_np_np2_triple_synthetic_sd_mailbox;
void XE_NP_Np2TripleSyntheticSd_Init(SD_HandleTypeDef *, DCACHE_HandleTypeDef *);
void XE_NP_Np2TripleSyntheticSd_Service(void);
void XE_NP_Np2TripleSyntheticSd_Irq(SD_HandleTypeDef *);
#endif
#endif
