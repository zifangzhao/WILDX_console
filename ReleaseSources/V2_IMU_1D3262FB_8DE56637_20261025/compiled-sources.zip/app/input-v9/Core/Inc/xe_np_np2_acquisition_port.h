#ifndef XE_NP_NP2_ACQUISITION_PORT_H
#define XE_NP_NP2_ACQUISITION_PORT_H
#include "xe_np_np2_acquisition.h"
/* NP2-only hardware implementation. Call after GPIO/clock initialization,
 * before any SD/USB service work. Does not touch VEE_EN or SD_VSEL. */
int XE_NP_Np2AcquisitionPort_EarlyIdle(void);
/* One caller per boot, exclusive probe buses/reset/power and PSSI. The actual
 * control/capture interfaces are bound only after the cold sequence. No I2C
 * transactions here. Call Begin with the returned startup interface. */
int XE_NP_Np2AcquisitionPort_Bind(uint8_t *ring,uint32_t ring_bytes,XE_NP_Np2StartupIo *);
/* Read-only provenance for the dedicated recorder mailbox. It never changes
 * startup policy or allows a failed acquisition to resume. */
uint32_t XE_NP_Np2AcquisitionPort_LastStartupStage(void);
uint32_t XE_NP_Np2AcquisitionPort_LastStartupDetail(void);
#endif
