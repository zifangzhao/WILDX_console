#include "xe_np_sensors_port.h"
#include "xe_np_board.h"
#include <string.h>

static XE_NP_Sensors sensors;
static I2C_HandleTypeDef *buses[2];
static uint32_t tokens[2];
static uint8_t initialized;
static volatile uint8_t paused;
static uint32_t resume_retry_ms;
static const XE_NP_SensorSnapshot paused_snapshot={
    .magic=0x31534e53U,.version=1U,
    .error={XE_NP_SENSOR_ERR_BUSY,XE_NP_SENSOR_ERR_DISABLED}
};
XE_NP_SensorSnapshot xe_np_sensor_snapshot[2];
volatile uint32_t xe_np_sensor_snapshot_index;
static const IRQn_Type event_irq[2]={I2C5_EV_IRQn,I2C6_EV_IRQn};
static const IRQn_Type error_irq[2]={I2C5_ER_IRQn,I2C6_ER_IRQn};
typedef char sensor_snapshot_wire_size[(sizeof(XE_NP_SensorSnapshot)==140U)?1:-1];

static int start(void *ctx,uint8_t bus,uint8_t address,uint8_t reg,uint8_t *data,
                 uint16_t length,uint8_t write,uint32_t token)
{
    HAL_StatusTypeDef status;I2C_HandleTypeDef *h=buses[bus];(void)ctx;
    if(paused)return 1;
    if(!h||!h->Instance)return -1;
    tokens[bus]=token;__DMB();
    /* U5 Mem_*_IT returns HAL_BUSY immediately, without a polling timeout. */
    status=write?HAL_I2C_Mem_Write_IT(h,(uint16_t)(address<<1),reg,I2C_MEMADD_SIZE_8BIT,data,length):
                 HAL_I2C_Mem_Read_IT(h,(uint16_t)(address<<1),reg,I2C_MEMADD_SIZE_8BIT,data,length);
    return status==HAL_OK?0:(status==HAL_BUSY?1:-1);
}
static void stop(void *ctx,uint8_t bus)
{
    I2C_HandleTypeDef *h=buses[bus];(void)ctx;
    HAL_NVIC_DisableIRQ(event_irq[bus]);HAL_NVIC_DisableIRQ(error_irq[bus]);
    if(h&&h->Instance) {
        /* No DMA. Disable IRQs and PE before relinquishing the buffer, even
         * when SDA stays low or a STOP never arrives. No waits or GPIO clocks. */
        CLEAR_BIT(h->Instance->CR1,I2C_CR1_TXIE|I2C_CR1_RXIE|I2C_CR1_ADDRIE|
            I2C_CR1_NACKIE|I2C_CR1_STOPIE|I2C_CR1_TCIE|I2C_CR1_ERRIE|I2C_CR1_PE);
        __DSB();h->XferISR=NULL;
    }
    HAL_NVIC_ClearPendingIRQ(event_irq[bus]);HAL_NVIC_ClearPendingIRQ(error_irq[bus]);
}
static int recover(void *ctx,uint8_t bus)
{
    I2C_HandleTypeDef *h=buses[bus];(void)ctx;
    if(!h||!h->Instance)return -1;
    /* Called only at idle, never in an IRQ or during NP recording. */
    stop(ctx,bus);
    if(HAL_I2C_DeInit(h)!=HAL_OK||HAL_I2C_Init(h)!=HAL_OK)return -1;
    if(HAL_I2CEx_ConfigAnalogFilter(h,I2C_ANALOGFILTER_ENABLE)!=HAL_OK||
       HAL_I2CEx_ConfigDigitalFilter(h,0)!=HAL_OK)return -1;
    HAL_NVIC_EnableIRQ(event_irq[bus]);HAL_NVIC_EnableIRQ(error_irq[bus]);return 0;
}
static void publish(uint32_t now)
{
    uint32_t inactive=xe_np_sensor_snapshot_index^1U;
    XE_NP_Sensors_Snapshot(&sensors,&xe_np_sensor_snapshot[inactive],now);
    __DMB();xe_np_sensor_snapshot_index=inactive;
}
void XE_NP_SensorsPort_Init(I2C_HandleTypeDef *imu,I2C_HandleTypeDef *environment)
{
    XE_NP_SensorIo io={NULL,start,stop,recover};uint32_t enabled=XE_NP_SENSOR_MASK_BMX;
    buses[0]=imu;buses[1]=environment;
#if XE_NP_BOARD_BME280_I2C_WIRING_CONFIRMED
    enabled|=XE_NP_SENSOR_MASK_BME;
#endif
    XE_NP_Sensors_Init(&sensors,&io,enabled,HAL_GetTick());
    for(uint8_t i=0;i<2;i++) {
        HAL_NVIC_SetPriority(event_irq[i],7U,0U);HAL_NVIC_SetPriority(error_irq[i],7U,0U);
        if((enabled&(1UL<<i))&&buses[i]&&buses[i]->Instance) {
            HAL_NVIC_ClearPendingIRQ(event_irq[i]);HAL_NVIC_ClearPendingIRQ(error_irq[i]);
            HAL_NVIC_EnableIRQ(event_irq[i]);HAL_NVIC_EnableIRQ(error_irq[i]);
        } else stop(NULL,i);
    }
    paused=0U;initialized=1;publish(HAL_GetTick());
}
void XE_NP_SensorsPort_Pause(void)
{
    if(!initialized)return;
    uint32_t key=__get_PRIMASK();__disable_irq();
    paused=1U;
    for(uint8_t i=0U;i<2U;i++)stop(NULL,i);
    sensors.snapshot.valid=0U;__DMB();__set_PRIMASK(key);
}
void XE_NP_SensorsPort_Resume(void)
{
    /* Re-initialize dedicated controllers/driver only on the next foreground
     * pass. No sensor transaction spans a PCLK transition; IRQ never waits. */
    if(initialized && paused){__DMB();paused=2U;}
}
void XE_NP_SensorsPort_Service(uint8_t recording)
{
    uint32_t now;
    if(!initialized)return;
    if(paused==1U)return;
    now=HAL_GetTick();
    if(paused==3U){
        /* A failed stopped-clock resume must not latch the sensors off.
         * Retry only at idle, never during NP preparation or recording. */
        if(recording || (int32_t)(now-resume_retry_ms)<0)return;
        paused=2U;
    }
    if(paused==2U){
        for(uint8_t i=0U;i<2U;i++){
            I2C_HandleTypeDef *h=buses[i];
            if(!h || !h->Instance || !sensors.device[i].enabled)continue;
            /* One bounded initialization after an explicit stopped profile
             * change, not periodic fault recovery while recording. */
            h->State=HAL_I2C_STATE_READY;h->Lock=HAL_UNLOCKED;
            if(HAL_I2C_Init(h)!=HAL_OK ||
               HAL_I2CEx_ConfigAnalogFilter(h,I2C_ANALOGFILTER_ENABLE)!=HAL_OK ||
               HAL_I2CEx_ConfigDigitalFilter(h,0U)!=HAL_OK){
                for(uint8_t bus=0U;bus<2U;bus++)stop(NULL,bus);
                resume_retry_ms=now+2000U;paused=3U;return;
            }
        }
        XE_NP_SensorsPort_Init(buses[0],buses[1]);
    }
    now=HAL_GetTick();XE_NP_Sensors_Service(&sensors,now,recording);
    if(xe_np_sensor_snapshot[xe_np_sensor_snapshot_index].published_ms!=now)publish(now);
}
int XE_NP_SensorsPort_Complete(I2C_HandleTypeDef *h,uint32_t error)
{
    if(!initialized || paused)return 0;
    for(uint8_t i=0;i<2;i++)if(h==buses[i]) {
        __DMB();XE_NP_Sensors_Complete(&sensors,i,tokens[i],error,HAL_GetTick());__DMB();return 1;
    }
    return 0;
}
const XE_NP_SensorSnapshot *XE_NP_SensorsPort_GetSnapshot(void)
{
    if(paused)return &paused_snapshot;
    uint32_t index=xe_np_sensor_snapshot_index;__DMB();return &xe_np_sensor_snapshot[index];
}
