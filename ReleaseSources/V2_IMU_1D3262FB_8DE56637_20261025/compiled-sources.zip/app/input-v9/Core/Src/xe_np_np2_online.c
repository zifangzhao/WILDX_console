#include "xe_np_np2_online.h"
#include "xe_np_online_impl.h"
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
#include "xe_np_sensor_query.h"
#include "xe_np_sensors_port.h"
static XE_NP_SensorQuery sensor_query;
#endif
void XE_NP_Np2Online_Init(XE_NP_Np2OnlineClock *c){XE_NP_Online_Init(c);}
uint64_t XE_NP_Np2Online_Utc(const XE_NP_Np2OnlineClock *c,uint32_t now)
{return XE_NP_Online_Utc(c,now);}
int XE_NP_Np2Online_Exchange(XE_NP_Np2OnlineClock *c,const uint8_t in[64],
    uint8_t out[64],uint32_t received,uint32_t sent,uint32_t state)
{
#if XE_NP_BOARD_SENSOR_SERVICE_ENABLE
    if(XE_NP_SensorQuery_Exchange(&sensor_query,in,out,
        XE_NP_SensorsPort_GetSnapshot(),sent))return 0;
#endif
    /* UTC is a RAM-only control feature: it does not require a mounted SD
       catalog. Still never step it while preparing, armed, or recording. */
    return XE_NP_Online_Exchange(c,in,out,received,sent,state,
        state==0 || state==1 || state==5 || state==7);
}
