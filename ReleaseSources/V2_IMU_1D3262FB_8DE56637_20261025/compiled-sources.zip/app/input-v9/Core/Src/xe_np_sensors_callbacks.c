#include "xe_np_image_role.h"
#include "xe_np_board.h"

#if XE_NP_IMAGE_ROLE == XE_NP_IMAGE_SD_APP && \
    XE_NP_NP2_DUAL_SD_APP_ENABLE && XE_NP_BOARD_SENSOR_SERVICE_ENABLE
#include "xe_np_sensors_port.h"

/* Lean NP2 APP only: the port filters dedicated sensor handles. USB keeps
 * its existing CE32 callback owners; no legacy fallback belongs here. */
void HAL_I2C_MemRxCpltCallback(I2C_HandleTypeDef *h)
{
    if(h)(void)XE_NP_SensorsPort_Complete(h,0U);
}

void HAL_I2C_MemTxCpltCallback(I2C_HandleTypeDef *h)
{
    if(h)(void)XE_NP_SensorsPort_Complete(h,0U);
}

void HAL_I2C_ErrorCallback(I2C_HandleTypeDef *h)
{
    if(h)(void)XE_NP_SensorsPort_Complete(h,h->ErrorCode?h->ErrorCode:1U);
}
#endif
