/* Included by main.c so this read-only port shares the existing private SD
 * power/clock implementation, without introducing a second init sequence. */
#if (XE_NP_IMAGE_ROLE == XE_NP_IMAGE_USB_SERVICE)
#include "xe_np_sd_init_diag.h"
#include "xe_np_sd_switch_status.h"

static uint32_t XE_NP_SdInfoRead(uint32_t app, uint32_t cmd, uint32_t argument,
                               uint8_t *buffer, uint32_t bytes)
{
  SDMMC_DataInitTypeDef data={0};
  SDMMC_CmdInitTypeDef command={0};
  uint32_t error=0U, words=0U, started, sta;
  if(!buffer || !XE_NP_SdInfoReadAllowed(app,cmd,argument,bytes))
    return HAL_SD_ERROR_PARAM;
  if(hsd1.State!=HAL_SD_STATE_READY ||
     (hsd1.Instance->STA & (SDMMC_STA_DPSMACT|SDMMC_STA_CPSMACT)))
    return HAL_SD_ERROR_BUSY;
  memset(buffer,0,bytes);
  hsd1.Instance->IDMACTRL=0U;
  hsd1.Instance->DCTRL=SDMMC_DCTRL_FIFORST;hsd1.Instance->DCTRL=0U;
  __HAL_SD_CLEAR_FLAG(&hsd1,SDMMC_STATIC_FLAGS);
  if(app) {
    error=SDMMC_CmdAppCommand(hsd1.Instance,hsd1.SdCard.RelCardAdd<<16U);
    if(error)return error;
  }
  started=HAL_GetTick();
  /* Both the hardware and foreground timeouts are bounded (250 ms). */
  data.DataTimeOut=XE_NP_Board_ComputeSdBusHz()/4U;
  data.DataLength=bytes;
  data.DataBlockSize=bytes==8U?SDMMC_DATABLOCK_SIZE_8B:SDMMC_DATABLOCK_SIZE_64B;
  data.TransferDir=SDMMC_TRANSFER_DIR_TO_SDMMC;
  data.TransferMode=SDMMC_TRANSFER_MODE_BLOCK;data.DPSM=SDMMC_DPSM_DISABLE;
  (void)SDMMC_ConfigData(hsd1.Instance,&data);
  __SDMMC_CMDTRANS_ENABLE(hsd1.Instance);
  command.Argument=argument;command.CmdIndex=cmd;
  command.Response=SDMMC_RESPONSE_SHORT;command.WaitForInterrupt=SDMMC_WAIT_NO;
  command.CPSM=SDMMC_CPSM_ENABLE;
  (void)SDMMC_SendCommand(hsd1.Instance,&command);
  error=SDMMC_GetCmdResp1(hsd1.Instance,cmd,250U);
  while(!error) {
    sta=hsd1.Instance->STA;
    if(sta&SDMMC_FLAG_DCRCFAIL)error=HAL_SD_ERROR_DATA_CRC_FAIL;
    else if(sta&SDMMC_FLAG_DTIMEOUT)error=HAL_SD_ERROR_DATA_TIMEOUT;
    else if(sta&SDMMC_FLAG_RXOVERR)error=HAL_SD_ERROR_RX_OVERRUN;
    else if(words<bytes/4U && !(sta&SDMMC_FLAG_RXFIFOE)) {
      uint32_t word=hsd1.Instance->FIFO;
      /* FIFO's first byte is the first byte on the wire. */
      memcpy(buffer+4U*words++,&word,4U);
      continue;
    } else if(sta&SDMMC_FLAG_DATAEND) {
      if(words!=bytes/4U)error=HAL_SD_ERROR_DATA_TIMEOUT;
      break;
    }
    if((uint32_t)(HAL_GetTick()-started)>=250U)error=HAL_SD_ERROR_TIMEOUT;
  }
  __SDMMC_CMDTRANS_DISABLE(hsd1.Instance);
  hsd1.Instance->DCTRL=SDMMC_DCTRL_FIFORST;hsd1.Instance->DCTRL=0U;
  __HAL_SD_CLEAR_FLAG(&hsd1,SDMMC_STATIC_FLAGS);
  if(error)memset(buffer,0,bytes); /* Partial data is never advertised as valid. */
  return error;
}

/* Do not call the generic deinit's voltage-reset callback on a powered UHS
 * card. Release the peripheral/pins, preserving the external selector. */
static void XE_NP_SdInfoReleaseHost(void)
{
  if(hsd1.Instance!=NULL) {
    uint32_t transceiver=hsd1.Init.TranceiverPresent;
    hsd1.Init.TranceiverPresent=SDMMC_TRANSCEIVER_NOT_PRESENT;
    (void)HAL_SD_DeInit(&hsd1);
    hsd1.Init.TranceiverPresent=transceiver;
  }
  NVIC_ClearPendingIRQ(SDMMC1_IRQn);
}

static int XE_NP_SdInfoInitHost(void)
{
  XE_NP_SdInfoReleaseHost();
  /* VEE_3V3 also powers the USB mux in the schematic. Never toggle that
   * shared rail during an EP0 query or assume EN guarantees discharge. */
  XE_NP_Board_EnsureSdPowerRail();
  __HAL_RCC_SDMMC1_FORCE_RESET();__HAL_RCC_SDMMC1_RELEASE_RESET();
  hsd1.State=HAL_SD_STATE_RESET;hsd1.ErrorCode=HAL_SD_ERROR_NONE;
  xe_np_sd_info_preserve_1v8=(HAL_GPIO_ReadPin(SD_VSEL_GPIO_Port,SD_VSEL_Pin)==GPIO_PIN_SET);
  int result=XE_NP_Board_InitSdHostBase()==HAL_OK?0:-1;
  xe_np_sd_info_preserve_1v8=0U;
  return result;
}

void XE_NP_Board_ReadSdInfo(XE_NP_SdInfo *info)
{
  uint32_t error=0U, irq=NVIC_GetEnableIRQ(SDMMC1_IRQn),sequence=info->sequence;
  uint32_t recovery=0U;
  uint8_t original_cid[16]={0};
  HAL_NVIC_DisableIRQ(SDMMC1_IRQn);
  for(uint32_t pass=0U;pass<2U;pass++) {
  uint32_t preserved=(HAL_GPIO_ReadPin(SD_VSEL_GPIO_Port,SD_VSEL_Pin)==GPIO_PIN_SET);
  XE_NP_SdInfoInit(info,sequence);
  info->board_budget_ma=XE_NP_SD_CARD_MAX_CURRENT_MA;
  /* Fresh CMD0/CMD8/CID/CSD every time, without assuming a power cycle.
   * CMD0 resets functions but does not reset a card's signaling voltage. */
  error=XE_NP_SdInfoInitHost()==0?0U:hsd1.ErrorCode;
  /* MSP initialization may have enabled the IRQ again. This port polls its
   * transfers; keep an ISR from consuming DATAEND/error flags underneath it. */
  HAL_NVIC_DisableIRQ(SDMMC1_IRQn);
  info->ocr=xe_np_sd_init_diag.ocr;info->init_stage=xe_np_sd_init_diag.stage;
  if(error || xe_np_sd_init_failed) {
    info->error=error?error:HAL_SD_ERROR_GENERAL_UNKNOWN_ERR;
    info->state=XE_NP_SD_INFO_FAILED;
    break;
  } else {
    info->flags=XE_NP_SD_INFO_IDENTIFIED |
        ((xe_np_sd_init_diag.acmd41_argument&0x01000000U)?16U:0U) |
        (xe_np_sd_signal_1v8_enabled?XE_NP_SD_INFO_SIGNAL_1V8:0U) |
        (preserved?XE_NP_SD_INFO_PRESERVED_1V8:0U);
    info->sectors_low=hsd1.SdCard.LogBlockNbr;
    info->clock_hz=XE_NP_Board_ComputeSdBusHz();
    info->bus_width=hsd1.Init.BusWide==SDMMC_BUS_WIDE_4B?4U:1U;
    info->active_function=0U; /* Fresh SDR12/default session, NOT the SD app. */
    for(uint32_t i=0;i<16U;i++) {
      info->cid[i]=(uint8_t)(hsd1.CID[i/4U]>>(24U-8U*(i%4U)));
      info->csd[i]=(uint8_t)(hsd1.CSD[i/4U]>>(24U-8U*(i%4U)));
    }
    error=XE_NP_SdInfoRead(1U,51U,0U,info->scr,8U);
    if(!error)info->flags|=XE_NP_SD_INFO_SCR_VALID;
    if(!error) {
      error=XE_NP_SdInfoRead(1U,13U,0U,info->ssr,64U);
      if(!error)info->flags|=XE_NP_SD_INFO_SSR_VALID;
    }
    if(!error) {
      error=XE_NP_SdInfoRead(0U,6U,info->checks[0].argument,info->checks[0].status,64U);
      info->checks[0].error=error;
    }
    if(!error && pass==0U && XE_NP_SdInfoNeedsVoltageRecovery(info->flags,info->ocr,
            info->checks[0].error,info->checks[0].status)) {
      /* A CRC-valid CMD6 reports UHS-only functions despite S18A=0. The
       * card may have retained its 1.8 V session across MCU reset. Reconcile
       * ONLY the host translator; CMD11 is forbidden without S18A=1.
       * Re-identify and require identical CID + another valid UHS response. */
      memcpy(original_cid,info->cid,16U);recovery=1U;
      XE_NP_SdInfoReleaseHost();
      HAL_SD_DriveTransceiver_1_8V_Callback(SET);
      continue;
    }
    if(!error && recovery && (memcmp(original_cid,info->cid,16U)!=0 ||
        !(info->flags&XE_NP_SD_INFO_SIGNAL_1V8) || !(info->checks[0].status[13]&0x1cU))) {
      info->flags=0U;error=HAL_SD_ERROR_UNSUPPORTED_FEATURE;
    }
    if(!error && recovery)info->flags|=XE_NP_SD_INFO_RECOVERED_1V8;
    for(uint32_t i=1U;i<3U && !error;i++) {
      /* UHS capability checks require the negotiated 1.8 V signaling session.
       * A supported bit is not proof that this board can run that mode. */
      if(!(info->flags&XE_NP_SD_INFO_SIGNAL_1V8)) {info->flags|=XE_NP_SD_INFO_UHS_SKIPPED;continue;}
      error=XE_NP_SdInfoRead(0U,6U,info->checks[i].argument,info->checks[i].status,64U);
      info->checks[i].error=error;
    }
    info->error=error;
    info->state=error?XE_NP_SD_INFO_FAILED:XE_NP_SD_INFO_READY;
  }
  break;
  }
  /* Leave no SD transfer/interrupt source behind for subsequent USB capture.
   * VDD stays powered; this is not a sector write or card formatting operation. */
  XE_NP_SdInfoReleaseHost();
  NVIC_ClearPendingIRQ(SDMMC1_IRQn);
  if(irq)HAL_NVIC_EnableIRQ(SDMMC1_IRQn);
  info->tick_ms=HAL_GetTick();
}
#endif
