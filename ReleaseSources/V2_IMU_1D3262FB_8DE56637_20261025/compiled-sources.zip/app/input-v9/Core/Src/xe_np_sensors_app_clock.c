#include "xe_np_image_role.h"
#include "xe_np_board.h"

#if XE_NP_IMAGE_ROLE == XE_NP_IMAGE_SD_APP && \
    XE_NP_NP2_DUAL_SD_APP_ENABLE && XE_NP_BOARD_SENSOR_SERVICE_ENABLE
extern int $Super$$XE_NP_Np2SdBle_BeginClockChange(void);
extern void $Super$$XE_NP_Np2SdBle_EndClockChange(void);
extern void XE_NP_SensorsPort_Pause(void);
extern void XE_NP_SensorsPort_Resume(void);

/* Patch the existing stopped clock boundary without rebuilding its owners. */
int $Sub$$XE_NP_Np2SdBle_BeginClockChange(void)
{
    int status=$Super$$XE_NP_Np2SdBle_BeginClockChange();
    if(status==0)XE_NP_SensorsPort_Pause();
    return status;
}

void $Sub$$XE_NP_Np2SdBle_EndClockChange(void)
{
    XE_NP_SensorsPort_Resume();
    $Super$$XE_NP_Np2SdBle_EndClockChange();
}
#endif
