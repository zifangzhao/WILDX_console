# STM32 USB Device middleware subset

STMicroelectronics USB Device middleware, imported from a local STM32 project
reference for XE_NP V2 MSC integration. Original copyright notices and the
component LICENSE.txt (SLA0044) are retained. No exact upstream release/tag is
asserted for this imported baseline. Only BOT/SCSI/data C sources are compiled;
Core and MSC headers provide types. The upstream USBD core and MSC class
dispatcher are not linked; XE_NP owns EP0, descriptors and foreground dispatch.

XE_NP local changes to the imported C sources:

- Reject CBW reserved flags and short command-specific CDBs.
- Clamp short-reply residue to actual bytes sent.
- Bound READ CAPACITY(16) reply/zeroing to 32 bytes and validate service action.
- Report READ FORMAT CAPACITIES block count correctly and honor allocation.
- Correct MODE SENSE(6) write-protect byte clearing.
- Refresh media geometry before read/write; handle zero-block no-ops.
- Reject overflowing LBA/length arithmetic and invalid zero block size.
- Route vendor C0 and SYNCHRONIZE CACHE through the XE_NP adapter.

The adapter, not the imported stack, adds DMA scratch ownership, strict OUT
length checking, read-only/eject enforcement, CSW ACK fencing and reset gates.
Run Tools/test_np_msc.ps1 after changing this subset.
