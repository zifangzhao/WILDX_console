"""Single guarded D449 APP overlay build; no hardware/deployment/publication."""
import argparse, json, re, struct, subprocess, sys, zlib
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
SRC, INPUT = HERE / "source-v7", HERE / "input-v9"
sys.path[:0] = [str(ROOT / "Tools/V2Usb"), str(ROOT / "Tools/V2SdLogger"), str(ROOT / "Tools")]
from build_usb_rate_fix import BIN, digest, relink
from validate_np2_live_sd_memory import parse_regions
import package_xe_np_firmware as pack

D449 = ROOT / "_artifacts/v2_ble_catalog_restore_20261022/delivery/source-manifest.json"
CBA = ROOT / "_artifacts/v2_imu_restore_20261023/app/incremental-build.json"
META = ROOT / "_artifacts/v2_sd_append_20261018/app/incremental-build.json"
USB = ROOT / "_artifacts/v2_np_start_anchor_20261023/checked/query/usb"

UNITS = ("main", "xe_np_np2_online", "xe_np_sensors_callbacks",
         "xe_np_sensors_app_clock", "xe_np_sensors", "xe_np_sensors_port",
         "xe_np_np2_dual_sd_meta", "xe_np_np2_dual_sd_catalog", "xe_np_np2_dual_sd_app")
SOURCE_TREE_SHA256 = "5E1BABB8F700AF4082AA8BDFD984A7A6B0FF4F1B176766F6598B754F6502E9A7"
INPUT_TREE_SHA256 = "D56903C865D4172A7FFC267F6D00216F106E11F6F1D564283052312CC89F0454"


def tree_digest(root):
    rows = []
    for path in sorted(root.rglob("*")):
        if path.is_file(): rows.append(path.relative_to(root).as_posix() + "\0" + digest(path) + "\n")
    return hashlib.sha256("".join(rows).encode()).hexdigest().upper()


def relocated(flags):
    out, skip = [], False
    for flag in flags:
        if skip:
            skip = False
        elif flag in ("-I", "-iquote"):
            skip = True
        elif flag.startswith("-I") or flag.startswith("-iquote"):
            continue
        else:
            out.append(flag)
    return ["-I", str(INPUT / "Core/Inc"), "-iquote", str(INPUT / "Core/Src"),
            "-I", str(INPUT / "Drivers/STM32U5xx_HAL_Driver/Inc"),
            "-I", str(INPUT / "Drivers/STM32U5xx_HAL_Driver/Inc/Legacy"),
            "-I", str(INPUT / "Drivers/CMSIS/Device/ST/STM32U5xx/Include"),
            "-I", str(INPUT / "Drivers/CMSIS/Include"),
            "-I", str(INPUT / "Middlewares/ST/Core/Inc"),
            "-I", str(INPUT / "Middlewares/ST/Class/MSC/Inc"),
            "-I", str(INPUT / "MDK-ARM/RTE"), *out]


def check_objects(link, d449):
    objects = re.findall(r'(?m)^"([^"\r\n]+\.o)"\r?$', link)
    expected = {str(Path(p).resolve()): h for p, h in d449["build"]["reused_checked_object_sha256"].items()}
    expected.update({str(Path(v["path"]).resolve()): v["sha256"] for v in d449["build"]["replaced_objects"].values()})
    if len(objects) != 63 or set(map(lambda p: str(Path(p).resolve()), objects)) != set(expected):
        raise ValueError("D449 actual object graph changed")
    for obj in objects:
        if digest(obj) != expected[str(Path(obj).resolve())]:
            raise ValueError("D449 object changed: " + obj)
    return objects


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--baseline", required=True, help="root-relative D449 graph with application.bin/.lnp/.map")
    ap.add_argument("--output", default="_artifacts/v2_release_overlay_20261025/app/build-v9")
    args = ap.parse_args()
    base, out = ROOT / args.baseline, ROOT / args.output
    if not out.resolve().is_relative_to(HERE) or out.resolve().is_relative_to(SRC) or out.resolve().is_relative_to(INPUT):
        raise ValueError("Fresh output must remain in the assigned APP overlay")
    if digest(D449) != "4A90E3BB33672F0552039E648FD0FC815EC96F9C9E2E3F567A5A21DBA40C2338":
        raise ValueError("D449 source/object receipt changed")
    d449 = json.loads(D449.read_text(encoding="utf-8-sig"))
    cba = json.loads(CBA.read_text(encoding="utf-8-sig"))
    meta = json.loads(META.read_text(encoding="utf-8-sig"))
    if out.exists(): raise ValueError("Fresh output required: " + str(out))
    if tree_digest(SRC) != SOURCE_TREE_SHA256 or tree_digest(INPUT) != INPUT_TREE_SHA256:
        raise ValueError("Frozen source/header input tree changed")
    if any(not (base / n).is_file() for n in ("application.bin", "application.lnp", "application.map")):
        raise ValueError("Retained D449 graph unavailable")
    if digest(base / "application.bin") != d449["body_sha256"]: raise ValueError("Wrong D449 body")
    link = (base / "application.lnp").read_text()
    old = re.findall(r'(?m)^"([^"\r\n]+\.o)"\r?$', link)
    old = check_objects(link, d449)
    frozen = {p: digest(p) for p in old}
    expected_compensation = {"xe_np_bme_compensation": "0DE7BB9556B989A6C1C65D676B3AB33C21990B92BA61503C3804B9D38CCB97B3",
                             "xe_np_bmm_compensation": "C71249943F2A4C5A2EA80A474B2027EB3AAF532C987F107040BC36B62056E2C3"}
    usb_link_before = (USB / "application.lnp").read_text()
    comp_inputs = {}
    for unit, expected in expected_compensation.items():
        matches = [p for p in re.findall(r'(?m)^"([^"\r\n]+\.o)"\r?$', usb_link_before) if Path(p).stem == unit]
        if len(matches) != 1 or digest(matches[0]) != expected:
            raise ValueError("Checked compensation object changed: " + unit)
        comp_inputs[matches[0]] = expected
    out.mkdir(parents=True)
    d449_args = d449["build"]["compiler_args_by_unit"]
    raw = {u: cba["compiler_args"] for u in UNITS[:6]}
    raw["xe_np_np2_dual_sd_meta"] = meta["compiler_args"]
    raw["xe_np_np2_dual_sd_catalog"] = d449_args["xe_np_np2_dual_sd_catalog"]
    raw["xe_np_np2_dual_sd_app"] = d449_args["xe_np_np2_dual_sd_app"]
    changed = {}
    for unit in UNITS:
        flags = relocated(raw[unit])
        if "-O3" not in flags: raise ValueError("O3 missing: " + unit)
        source, obj = SRC / "Core/Src" / (unit + ".c"), out / (unit + ".o")
        if not source.is_file(): raise ValueError("Missing source: " + str(source))
        run = subprocess.run([str(BIN / "armclang.exe"), *flags, str(source), "-o", str(obj)],
                             cwd=ROOT / "MDK-ARM", capture_output=True, text=True, timeout=60)
        (out / (unit + ".compile.log")).write_text(run.stdout + run.stderr)
        if run.returncode: raise RuntimeError("Compile failed: " + unit)
        prior = [p for p in old if Path(p).stem == unit]
        if len(prior) > 1: raise ValueError("Ambiguous original unit: " + unit)
        link = link.replace('"' + prior[0] + '"', '"' + obj.as_posix() + '"') if prior else '"' + obj.as_posix() + '"\n' + link
        changed[unit] = {"source_sha256": digest(source), "object_sha256": digest(obj), "flags": flags}
    usb_link = (USB / "application.lnp").read_text()
    compensation = {}
    for unit in ("xe_np_bme_compensation", "xe_np_bmm_compensation"):
        match = [p for p in re.findall(r'(?m)^"([^"\r\n]+\.o)"\r?$', usb_link) if Path(p).stem == unit]
        if len(match) != 1 or any(Path(p).stem == unit for p in old): raise ValueError("Bad compensation lineage: " + unit)
        link = '"' + match[0] + '"\n' + link; compensation[match[0]] = digest(match[0])
    if compensation != comp_inputs:
        raise ValueError("Compensation graph changed across compilation")
    if tree_digest(SRC) != SOURCE_TREE_SHA256 or tree_digest(INPUT) != INPUT_TREE_SHA256:
        raise ValueError("Compiler input changed during build")
    image = relink(link, out, "application")
    data, mapped = image.with_suffix(".bin").read_bytes(), image.with_suffix(".map").read_text()
    if parse_regions(mapped, linked=True) != parse_regions((base / "application.map").read_text(), linked=True):
        raise ValueError("RAM reservations changed")
    if any(digest(p) != h for p, h in frozen.items()) or any(digest(p) != h for p, h in compensation.items()):
        raise ValueError("Retained object changed")
    sp, pc = struct.unpack_from("<II", data)
    stack = re.findall(r'^\s*Stack_Mem\s+(0x[0-9a-f]+)\s+Data\s+(\d+)\s+startup_stm32u595xx.o\(STACK\)', mapped, re.M)
    if len(stack) != 1 or int(stack[0][1]) != 8192 or sp != int(stack[0][0], 16) + 8192 or sp % 8 or not pc & 1:
        raise ValueError("Entry/stack contract changed")
    if not 0x08020000 <= (pc & ~1) < 0x08020000 + len(data) <= 0x0817e000:
        raise ValueError("APP entry/body escaped its partition")
    report = image.with_suffix(".htm").read_text()
    known_stack = re.search(r"Maximum Stack Usage\s*=\s*(\d+) bytes", report)
    if not known_stack or int(known_stack[1]) > 8192:
        raise ValueError("Missing/excess known stack depth")
    for callback in ("HAL_I2C_MemRxCpltCallback", "HAL_I2C_MemTxCpltCallback", "HAL_I2C_ErrorCallback"):
        if not re.search(r"^\s*" + callback + r"\s+0x[0-9a-f]+.*xe_np_sensors_callbacks.o", mapped, re.M):
            raise ValueError("Strong callback owner missing: " + callback)
    if "$Sub$$XE_NP_Np2SdBle_BeginClockChange" not in mapped:
        raise ValueError("Stopped clock adapter was not linked")
    pack.LOADER_ABI_VERSION = 4
    manifest = pack.build_manifest(data, generation=4, image_id=pack.IMAGE_ID_APPLICATION)
    (out / "application.manifest.bin").write_bytes(manifest)
    pack.write_intel_hex(out / "app_overlay_v5.hex", pack.sealed_slot_memory(data, manifest))
    hex_path = out / "app_overlay_v5.hex"
    hex_path.write_bytes(hex_path.read_bytes().replace(b"\r\n", b"\n"))
    if pack.read_intel_hex(hex_path) != pack.sealed_slot_memory(data, manifest):
        raise ValueError("Sealed APP HEX round trip failed")
    receipt = {"role": "APP", "baseline": d449["body_sha256"], "compiler_args_by_unit": {u:v["flags"] for u,v in changed.items()},
               "changed_units": changed, "retained_objects": frozen, "compensation_objects": compensation,
               "body_sha256": digest(image.with_suffix(".bin")), "body_crc32": f"{zlib.crc32(data):08X}",
               "body_bytes": len(data), "ram_reservations_unchanged": True, "hardware_validated": False, "published": False,
               "source_tree_sha256": SOURCE_TREE_SHA256, "include_tree_sha256": INPUT_TREE_SHA256,
               "hex_sha256": digest(hex_path), "manifest_sha256": digest(out / "application.manifest.bin"),
               "known_stack_bytes": int(known_stack[1]), "stack_allocation_bytes": 8192,
               "stack_limit": "Known callgraph only; function pointers/IRQ nesting remain outside static proof",
               "source_scope": "D449 + B9/IMU lifecycle and exact empty cancellation; no UTC2 or anchor extras"}
    (out / "incremental-build.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print("PRIVATE APP " + receipt["body_crc32"] + "; 9 O3 units +2 checked compensation, D449 reuse/partition/RAM/stack/callback/seal checks; NOT hardware qualified")


if __name__ == "__main__": main()
