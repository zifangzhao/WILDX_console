"""One private CRC-only USB stream-unit build; no hardware or publication."""
import hashlib,json,re,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
sys.path[:0]=[str(ROOT/'Tools/V2Usb'),str(ROOT/'Tools/V2SdLogger'),str(ROOT/'Tools/Power')]
from build_usb_rate_fix import digest,BIN
from build_np_start_anchor import build
from build_checked_np_start_anchor import seal
from build_sd_single20_bus54 import object_facts
import validate_np2_live_sd_memory as ram
BASE=ROOT/'_artifacts/v2_release_overlay_20261025/usb/startup-port-build/usb'
FROZEN=ROOT/'_artifacts/v2_usb_format_20261022/source-freeze'
R2=ROOT/'_artifacts/v2_release_overlay_20261025/usb/retained-r2'
SHARED=Path('Tools/V1Capture/SdLogger/np_sd_usb_download.inc')
native=json.loads((HERE/'native-r4-interleaved/result.json').read_text(encoding='utf-8'))
assert native['passed'] and digest(ROOT/SHARED)==native['source_sha256']
baseline=json.loads((BASE/'incremental-build.json').read_text(encoding='utf-8-sig'))
assert baseline['body_crc32']=='1D3262FB' and digest(BASE/'application.bin')==baseline['body_sha256']
recipe=json.loads((ROOT/'_artifacts/v2_usb_timing_20261024/image_r2/build-receipt.json').read_text(encoding='utf-8-sig'))
tree=HERE/'inputs-interleaved';assert not tree.exists();(tree/'Core/Src').mkdir(parents=True)
for p in R2.iterdir():
 if p.is_file() and p.suffix in ('.c','.h','.inc'):shutil.copyfile(p,tree/'Core/Src'/p.name)
before=(FROZEN/SHARED).read_text(encoding='utf-8-sig')
assert digest(FROZEN/SHARED)=='E59609EC3F755F750758C9C11207F0423668A2633FB9EAD9CF77A09E56E14EDC'
sys.path.insert(0,str(ROOT/'Tools/V2Usb/tests'))
from test_download_crc_batch import extract
current=(ROOT/SHARED).read_text(encoding='utf-8-sig')
after=before.replace(extract(before),extract(current))
guard=current[current.index('#ifndef NP_SD_USB_CRC_ALIGNED_BATCH'):current.index('#if (NP_SD_USB_DEFER_NEXT_READ')]
after=after.replace('#if NP_SD_USB_HW_CRC\n',guard+'#if NP_SD_USB_HW_CRC\n',1)
target=tree/SHARED;target.parent.mkdir(parents=True);target.write_text(after,encoding='utf-8',newline='\n')
# Keep current, unrelated deferred-request work out of this candidate entirely.
assert 'np_download_deferred' not in after and 'NP_SD_USB_DEFER_NEXT_READ' not in after
flags=recipe['compiler_args_by_unit']['xe_np_usb_stream']
filtered=[];skip=False
for i,flag in enumerate(flags):
 if skip:skip=False;continue
 if flag in ('-I','-iquote'):
  folder=flags[i+1];skip=True
  if Path(folder).resolve()==(ROOT/'Core/Src').resolve():continue
  filtered += [flag,folder]
 else:filtered.append(flag)
filtered+=['-DNP_SD_USB_CRC_ALIGNED_BATCH=1']
assert '-O3' in filtered
ram.CMSIS=FROZEN/'Drivers/CMSIS/Device/ST/STM32U5xx/Include/stm32u595xx.h'
work=HERE/'build-r2-interleaved';source=tree/'Core/Src/xe_np_usb_stream.c'
build('USB',str(BASE.relative_to(ROOT)),baseline['body_sha256'],{'xe_np_usb_stream':filtered},
      sources={'xe_np_usb_stream':source},includes=[tree/'Core/Src',FROZEN/'Core/Inc',FROZEN/'Core/Src'],work=work)
out=work/'usb';receipt=json.loads((out/'incremental-build.json').read_text())
objects=re.findall(r'(?m)^"([^"\r\n]+\.o)"\r?$',(BASE/'application.lnp').read_text())
original=Path(next(p for p in objects if Path(p).stem=='xe_np_usb_stream'))
assert digest(original)=='0071E594F045AB116A39E5CB9AD4C13A1BA2FFD73C5DC546C2045A582C977599'
a,b=object_facts(original),object_facts(out/'xe_np_usb_stream.o')
changed=sorted(n for n in set(a['allocated'])|set(b['allocated']) if a['allocated'].get(n)!=b['allocated'].get(n) or a['relocations'].get(n)!=b['relocations'].get(n))
allowed={'.text.np_download_crc_hw','.text.XE_NP_UsbStream_Service'}
unexpected=[n for n in changed if n not in allowed]
receipt.update(changed_allocated_sections=changed,unexpected_sections=unexpected,exact_main_retained=True,
 source_diff_scope='Exact released shared include plus opt-in aligned CRC batch only; unrelated deferred request code excluded',
 native_crc_evidence_sha256=digest(HERE/'native-r4-interleaved/result.json'),shared_before_sha256=digest(FROZEN/SHARED),shared_after_sha256=digest(target),
 hardware_validated=False,installed=False,published=False)
(out/'incremental-build.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
assert not unexpected,'Reject unrelated allocated/relocation changes: '+str(unexpected)
for path,label in ((original,'baseline'),(out/'xe_np_usb_stream.o','candidate')):
 asm=subprocess.check_output([str(BIN/'fromelf.exe'),'--text','-c',str(path)]).decode().replace('\r','')
 m=re.search(r'(?m)^\s*np_download_crc_hw\s*$',asm);assert m
 part=asm[m.start():].split('\n** Section',1)[0]
 (HERE/(label+'-interleaved-crc-assembly.txt')).write_text(part,encoding='utf-8',newline='\n')
seal(out,'USB')
p=out/'timing_candidate.hex';p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
receipt.update(hex_sha256=digest(p),manifest_sha256=digest(out/'application.manifest.bin'))
(out/'incremental-build.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print('PRIVATE CRC candidate '+receipt['body_crc32']+'; changed sections='+str(changed)+'; not installed or hardware qualified')
