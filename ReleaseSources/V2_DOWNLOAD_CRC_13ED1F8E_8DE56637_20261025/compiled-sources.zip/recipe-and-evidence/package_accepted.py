"""Package accepted components once; no build or hardware access."""
import hashlib,json,shutil,struct,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
LATEST=ROOT/'LATEST_FIRMWARE/V2_NP2';BUILD=HERE/'build-r2-interleaved/usb';OUT=HERE/'delivery'
SOURCE='ReleaseSources/V2_CRC_13ED1F8E_8DE56637_20261025/compiled-sources.zip'
sys.path.insert(0,str(ROOT/'Tools'));import package_xe_np_firmware as pack
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def emit(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
assert not OUT.exists()
old=load(LATEST/'package-receipt.json');assert (old['usb_crc32'],old['app_crc32'])==('1D3262FB','8DE56637')
comparison=load(HERE/'comparison-interleaved.json');assert comparison['decision']=='accept_interleaved_13ED_download_path_only'
assert comparison['all_six_hash_dictionaries_match'] and comparison['firmware_errors']==0 and comparison['crc_selftest']==1
build=load(BUILD/'incremental-build.json');assert build['body_crc32']=='13ED1F8E'
for name,want in {'application.bin':'C084875E8111D0D64D55B58935E9FC6673CE2A47E52DE350C11D02C3CDA9C767','application.manifest.bin':'606738E6A1D28DB36131E80345FD3E2F561809D63649AFE4A6F9AD32E5CAE21A','timing_candidate.hex':'DE68D67ECCC615720EF74EA002E2698803A4168BDE3840845950FC1FDB0666B3'}.items():assert sha(BUILD/name)==want
body=(BUILD/'application.bin').read_bytes();manifest=(BUILD/'application.manifest.bin').read_bytes()
usb=pack.sealed_slot_memory(body,manifest);assert pack.read_intel_hex(BUILD/'timing_candidate.hex')==usb
assert all(0x0817E000<=a<0x0817E080 or 0x08180000<=a<0x081FD000 for a in usb)
parent=LATEST/next(n for n in old['files'] if 'fused' in n);assert sha(parent)==old['files'][parent.name]['sha256']
previous=pack.read_intel_hex(parent);fused={a:b for a,b in previous.items() if a<0x0817E000}
fused.update(dict.fromkeys(range(0x0817E000,0x081FD000),0xff));fused.update(usb)
assert {a:b for a,b in previous.items() if a<0x0817E000}=={a:b for a,b in fused.items() if a<0x0817E000}
assert not any(0x0801C000<=a<0x0801E000 or 0x081FD000<=a<0x08200000 for a in fused)
loader={a:b for a,b in fused.items() if a<pack.CONFIG_BASE};pack.validate_loader(loader)
sp,reset=struct.unpack('<II',bytes(loader[pack.FLASH_BASE+i] for i in range(8)))
assert pack.valid_initial_stack_pointer(sp) and reset&1 and pack.FLASH_BASE<=(reset&~1)<pack.LOADER_LIMIT
OUT.mkdir()
usb_hex='V2_USB_only_13ED1F8E_CRC_READ_20261025.hex';usb_xenp='V2_USB_update_13ED1F8E_CRC_READ_20261025.xenp'
fused_name='V2_fused_RECOVERY_6408DBB8_USB_13ED1F8E_APP_8DE56637_CRC_READ_20261025.hex'
shutil.copyfile(BUILD/'timing_candidate.hex',OUT/usb_hex);(OUT/usb_xenp).write_bytes(manifest+body)
pack.write_intel_hex(OUT/fused_name,fused);(OUT/fused_name).write_bytes((OUT/fused_name).read_bytes().replace(b'\r\n',b'\n'))
assert pack.read_intel_hex(OUT/fused_name)==fused
for name,identity in old['files'].items():
 if 'logger_APP' in name or 'recovery_only' in name:
  assert sha(LATEST/name)==identity['sha256'];shutil.copyfile(LATEST/name,OUT/name)
for p in (OUT/usb_hex,OUT/fused_name):assert b'\r' not in p.read_bytes()
a=next(OUT.glob('*logger_APP_update*.xenp')).read_bytes();app=pack.sealed_slot_memory(a[128:],a[:128])
assert all(fused[k]==v for k,v in app.items())
acceptance={'accepted_usb_crc32':'13ED1F8E','unchanged_app_crc32':'8DE56637','unchanged_recovery_crc32':'6408DBB8','comparison':comparison,
 'usb_install_readback':load(HERE/'interleaved-hil/install-interleaved/readback.json'),'native_crc':load(HERE/'native-r4-interleaved/result.json'),
 'final_idle_status':(HERE/'accepted13ed-status/host.log').read_text(encoding='utf-8-sig'),'baseline_pair_validation':old['validation'],
 'interpretation':'SD phase also improved; entire gain cannot be attributed solely to CRC loop. Existing same-record baseline reused; no fresh raw-only control.',
 'scope':'Accepted USB SD-download path through actual WILDX139 APIs on current board/card. APP8DE and recovery reused byte-for-byte with prior evidence. No new NP capture, card write, APP flash, all-mode/endurance, whole-fused or WILDX140+13ED hardware qualification.',
 'hardware_lease_returned':True,'fused_whole_flash_tested':False,'new_build_or_hardware_during_packaging':False,
 'learning':'Instruction count alone did not predict peripheral/bus throughput. Interleaved source loads and CRC writes measured better than grouped loads; retain checksum semantics and compare complete export hashes.'}
emit(OUT/'acceptance.json',acceptance)
bench=load(HERE/'benchmark13ed-r1/benchmark.json');bench.pop('catalog',None);emit(OUT/'benchmark-selected.json',bench)
archive_files={}
def inc(p,n):assert p.is_file(),str(p);archive_files[n]=p
for p in sorted((HERE/'inputs-interleaved').rglob('*')):
 if p.is_file():inc(p,'compiled-inputs/'+p.relative_to(HERE/'inputs-interleaved').as_posix())
inc(ROOT/'_artifacts/v2_usb_format_20261022/source-freeze/Tools/V1Capture/SdLogger/np_sd_usb_download.inc','baseline/np_sd_usb_download.inc')
for n in ('incremental-build.json','application.lnp','application.map','application.htm','xe_np_usb_stream.o'):inc(BUILD/n,'build/'+n)
for n in ('build_interleaved.py','package_accepted.py','comparison-interleaved.json','candidate-interleaved-crc-assembly.txt','baseline-interleaved-crc-assembly.txt'):inc(HERE/n,'recipe-and-evidence/'+n)
inc(ROOT/'Tools/V2Usb/tests/test_download_crc_batch.py','regression/test_download_crc_batch.py')
inc(HERE/'native-r4-interleaved/result.json','regression/result.json');inc(HERE/'interleaved-hil/install-interleaved/readback.json','acceptance/readback.json')
for n in ('acceptance.json','benchmark-selected.json'):inc(OUT/n,'acceptance/'+n)
index={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in sorted(archive_files.items())}
with zipfile.ZipFile(OUT/'compiled-sources.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for n,p in sorted(archive_files.items()):z.write(p,n)
 z.writestr('archive-index.json',json.dumps(index,indent=2)+'\n')
source={'usb_crc32':'13ED1F8E','app_crc32':'8DE56637','source_scope':'Exact compiled CRC-delta input snapshots, retained-object identities, recipe/build maps, native and hardware acceptance receipts; not a clean-tree reconstruction.',
 'parent_release_commit':'3280df8fea774eb3fce1650a6fd1c84ce4383817','parent_source_archive_path':old['firmware_source_archive_path'],'parent_source_archive_sha256':old['firmware_source_archive_sha256'],
 'source_archive_path':SOURCE,'source_archive_sha256':sha(OUT/'compiled-sources.zip'),'archive_inputs':index,'usb_build_receipt':build,
 'canonical_source_equivalence_claimed':False,'retained_main_object_sha256':'4DFDB1A929FFE48BAD5A8B9470BF3346D1350895B85EFEDD99F5E3D660B570C4',
 'retained_main_source_limit':'Historical main source preimage unavailable; exact checked retained main.o reused unchanged.',
 'build_time_flags_are_historical':'Build receipt hardware_validated=false is immutable build-time state; subsequent acceptance is recorded separately.'}
emit(OUT/'source-manifest.json',source)
files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.iterdir() if p.suffix in ('.hex','.xenp')}
receipt={'release':'V2_CRC_READ_USB13ED1F8E_APP8DE56637_20261025','usb_crc32':'13ED1F8E','app_crc32':'8DE56637','recovery_crc32':'6408DBB8','files':files,
 'firmware_source_archive_path':SOURCE,'firmware_source_archive_sha256':sha(OUT/'compiled-sources.zip'),'acceptance_sha256':sha(OUT/'acceptance.json'),'source_manifest_sha256':sha(OUT/'source-manifest.json'),
 'previous_usb_crc32':'1D3262FB','parent_fused_sha256':sha(parent),'packaging':'Direct merge of checked sealed13ED into prior fused; all non-USB addresses unchanged. APP/recovery copied byte-for-byte. No rebuild/reseal/hardware access.',
 'settings_omitted':True,'omitted_ranges':['0801C000-0801DFFF','081FD000-081FFFFF'],'validation_scope':acceptance['scope'],'validation':{'download':comparison,'prior_unchanged_app':old['validation']},
 'installer_target':'WILDX1.0.0.140; exact assets for direct inclusion by canonical owner','standalone_update_zip':False,'fused_whole_flash_tested':False,'published':False}
emit(OUT/'package-receipt.json',receipt)
(OUT/'SHA256SUMS.txt').write_text(''.join(f"{v['sha256']}  {n}\n" for n,v in sorted(files.items())),encoding='utf-8',newline='\n')
(OUT/'README.md').write_text('''# V2 CRC-read improvement - 2026-10-25

Recovery6408DBB8 / USB13ED1F8E / BLE-SD APP8DE56637.

Fused HEX merges the exact checked USB with unchanged APP/recovery and omits
retained configuration. Components retain their existing bytes/seals. New USB/fused HEX use LF; the
unchanged legacy recovery HEX retains its existing CRLF formatting.
No separate whole-fused flash test was run.

WILD-X139 download comparison: serial export median30.41 to31.82MB/s; all six
exports matched baseline hashes, firmware errors0 and CRC self-test1. SD time
also improved, so the entire gain cannot be attributed solely to the CRC loop.
No new neural capture/endurance test was added. Prior APP evidence is reused.

These exact assets are intended for the single WILD-X140 installer. Its owner
records final installer identity. No standalone update ZIP is required. The
compiled-sources ZIP is source/build/evidence only, not an updater.

See package-receipt.json, acceptance.json, source-manifest.json and
../../Note/V2_USB_TIMING_SIDEBAND_20261024.md for scope and provenance.
''',encoding='utf-8',newline='\n')
print(json.dumps({'delivery':str(OUT),'files':files,'source_archive_sha256':sha(OUT/'compiled-sources.zip'),'package_receipt_sha256':sha(OUT/'package-receipt.json')},indent=2))
