"""Actual download CRC functions with modeled register writes; no hardware."""
import argparse,hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'_artifacts/v2_usb_format_20261022/source-freeze/Tools/V1Capture/SdLogger/np_sd_usb_download.inc'
SOURCE=ROOT/'Tools/V1Capture/SdLogger/np_sd_usb_download.inc'
VC=Path('C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def extract(s):
 start=s.index('static uint32_t np_download_crc_hw(');opening=s.index('{',start);depth=0
 for end in range(opening,len(s)):
  depth+=(s[end]=='{')-(s[end]=='}')
  if depth==0:return s[start:end+1]
 raise ValueError('CRC function not closed')
def modeled(s,name):
 s=s.replace('np_download_crc_hw(',name+'(')
 s=re.sub(r'CRC->CR\s*=\s*([^;]+);',r'model_control(\1);',s)
 s=re.sub(r'\*\(__IO uint8_t \*\)&CRC->DR\s*=\s*([^;]+);',r'model_byte(\1);',s)
 s=re.sub(r'CRC->DR\s*=\s*([^;]+);',r'model_word(\1);',s)
 return s.replace('return CRC->DR^~0U;','return model_read()^~0U;')
MODEL=r'''
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CRC_CR_REV_IN 0x60U
#define CRC_CR_REV_IN_0 0x20U
#define CRC_CR_REV_OUT 0x80U
#define CRC_CR_RESET 1U
#define __IO volatile
static struct {uint32_t POL,INIT;} regs;
#define CRC (&regs)
static uint32_t control,state,word_count,byte_count,clock_enabled;
#define __HAL_RCC_CRC_CLK_ENABLE() ((void)(clock_enabled=1U))
static uint32_t reverse(uint32_t x,unsigned n){uint32_t r=0U;while(n--){r=(r<<1)|(x&1U);x>>=1;}return r;}
static void model_control(uint32_t c){assert(clock_enabled && regs.POL==0x04c11db7U && regs.INIT==~0U);control=c&~1U;if(c&1U){state=regs.INIT;word_count=byte_count=0U;}}
static void bits(uint32_t v,unsigned n){while(n--){uint32_t top=(state>>31)^((v>>n)&1U);state<<=1;if(top)state^=regs.POL;}}
static void model_word(uint32_t v){assert((control&CRC_CR_REV_IN)==CRC_CR_REV_IN);bits(reverse(v,32),32);word_count++;}
static void model_byte(uint8_t v){assert((control&CRC_CR_REV_IN)==CRC_CR_REV_IN_0);bits(reverse(v,8),8);byte_count++;}
static uint32_t model_read(void){assert(control==0xa0U);return reverse(state,32);}
#include "actual_crc.inc"
static uint32_t table[256],cases;
static uint32_t reference(const uint8_t *p,uint32_t n){uint32_t c=~0U;while(n--)c=(c>>8)^table[(c^*p++)&255U];return ~c;}
static void check(const uint8_t *p,uint32_t n){
 uint32_t want=reference(p,n),value;clock_enabled=0U;
 value=baseline_crc(p,n);assert(value==want && word_count==n/4U && byte_count==n%4U);
 value=off_crc(p,n);assert(value==want && word_count==n/4U && byte_count==n%4U);
 value=batch_crc(p,n);assert(value==want && word_count==n/4U && byte_count==n%4U);cases++;
}
int main(void){
 for(uint32_t i=0;i<256U;i++){uint32_t c=i;for(unsigned j=0;j<8U;j++)c=(c>>1)^((c&1U)?0xedb88320U:0U);table[i]=c;}
 assert(reference((const uint8_t *)"123456789",9)==0xcbf43926U);check((const uint8_t *)"123456789",9);
 const uint32_t size=522240U+64U;uint8_t *p=malloc(size);assert(p);
 for(unsigned pattern=0;pattern<4U;pattern++){
  for(uint32_t i=0;i<size;i++)p[i]=(uint8_t)(pattern==0U?0U:pattern==1U?255U:pattern==2U?i:(i*37U+(i>>5)*17U+11U));
  for(unsigned offset=0;offset<16U;offset++)for(unsigned n=0;n<=257U;n++)check(p+offset,n);
 }
 const uint32_t lengths[]={511U,512U,1023U,4095U,4096U,522239U,522240U};
 for(unsigned offset=0;offset<8U;offset++)for(unsigned i=0;i<sizeof(lengths)/sizeof(lengths[0]);i++)check(p+offset,lengths[i]);
 for(uint32_t i=0;i<size;i++)assert(p[i]==(uint8_t)(i*37U+(i>>5)*17U+11U));
 free(p);printf("PASS actual CRC batch: %u cases; released/default-off/batch match independent IEEE CRC, word/byte width, reset/order, all offsets/tails and full510KiB payload; modeled registers only\n",cases);return 0;
}
'''
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',default='_artifacts/v2_download_crc_20261025/native');a=ap.parse_args()
 out=ROOT/a.output;assert out.resolve().is_relative_to(ROOT/'_artifacts') and not out.exists()
 assert sha(BASE)=='E59609EC3F755F750758C9C11207F0423668A2633FB9EAD9CF77A09E56E14EDC'
 out.mkdir(parents=True)
 baseline,current=extract(BASE.read_text(encoding='utf-8-sig')),extract(SOURCE.read_text(encoding='utf-8-sig'))
 code=modeled(baseline,'baseline_crc')+'\n#define NP_SD_USB_CRC_ALIGNED_BATCH 0\n'+modeled(current,'off_crc')+'\n#undef NP_SD_USB_CRC_ALIGNED_BATCH\n#define NP_SD_USB_CRC_ALIGNED_BATCH 1\n'+modeled(current,'batch_crc')
 (out/'actual_crc.inc').write_text(code,encoding='utf-8',newline='\n');(out/'model.c').write_text(MODEL,encoding='utf-8',newline='\n')
 command=f'call "{VC}" >nul && cl /nologo /std:c11 /W4 /WX /TC /O2 "{out}/model.c" /Fo"{out}/" /Fe"{out}/model.exe"'
 build=subprocess.run(f'cmd /d /s /c "{command}"',cwd=out,capture_output=True,text=True,timeout=30)
 (out/'compile.log').write_text(build.stdout+build.stderr,encoding='utf-8');assert build.returncode==0,build.stdout+build.stderr
 run=subprocess.run([str(out/'model.exe')],cwd=out,capture_output=True,text=True,timeout=30)
 (out/'run.log').write_text(run.stdout+run.stderr,encoding='utf-8');assert run.returncode==0,run.stdout+run.stderr
 result={'passed':True,'source_sha256':sha(SOURCE),'released_shared_include_sha256':sha(BASE),'fixture_sha256':sha(Path(__file__)),'scope':'Actual source functions with modeled register widths/reversal/order; not peripheral timing, throughput or hardware acceptance','log':run.stdout.strip(),'hardware_access':False}
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(run.stdout.strip())
if __name__=='__main__':main()
