$ErrorActionPreference='Stop'
$taskRoot=$PSScriptRoot
$lease=Get-Content -LiteralPath (Join-Path $taskRoot 'owner/lease.json') -Raw|ConvertFrom-Json
if($lease.status -ne 'active' -or $lease.uid -ne '001A0004434250062039314E' -or !(Get-Process -Id $lease.pid -ErrorAction SilentlyContinue)){throw 'Exact active lease required'}
$original=Get-Content -LiteralPath (Join-Path $taskRoot 'original/receipt.json') -Raw|ConvertFrom-Json
$restored=Get-Content -LiteralPath (Join-Path $taskRoot 'deployment/Restore-verified.json') -Raw|ConvertFrom-Json
if($restored.whole_flash_sha256 -ne $original.full_sha256 -or $restored.options_sha256 -ne $original.options_sha256){throw 'Exact original flash/options proof missing'}
# The first finish pass already verified physical quiet/debug state, then
# correctly stopped at a changed test-preference expectation. Reuse that proof.
$debugProof=Join-Path $taskRoot 'debug-restored.txt'
if(!(Test-Path -LiteralPath $debugProof) -or [IO.File]::ReadAllText($debugProof) -notmatch 'UID correct, APP7F238587/USB74FC7104, physical SD/DMA quiet, DHCSR=01000000, C_DEBUGEN=0, S_HALT=0'){throw 'Existing exact debug/quiet proof required'}
$prefs=$original.preferences.path
if($original.preferences.existed){throw 'Unexpected original preferences admission'}
if(Test-Path -LiteralPath $prefs){
 $expected='{"Enabled":false,"MayBeConfigured":false,"TrainingStartMs":0,"TrainingDurationMs":1000,"Channels":[{"Probe":2,"Filter":6,"Channel":0,"Gain":2,"Rectify":true}]}'
 if([IO.File]::ReadAllText($prefs) -ne $expected){throw 'Host preferences differ from exact generated test settings; no removal'}
 $hash=(Get-FileHash -LiteralPath $prefs -Algorithm SHA256).Hash
 Copy-Item -LiteralPath $prefs -Destination (Join-Path $taskRoot 'original/generated-preferences-final.json')
 if((Get-FileHash -LiteralPath $prefs -Algorithm SHA256).Hash -ne $hash){throw 'Host preference changed'}
 Remove-Item -LiteralPath $prefs
}
if(Test-Path -LiteralPath $prefs){throw 'Original absent preferences not restored'}
$asm=[Reflection.Assembly]::LoadFrom('C:/Frank/Code/USB_PCconsole/_artifacts/sd_usb_test_host/enabled248-bleready/WILDX_console.exe');$f=[Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
$type=$asm.GetType('USB512_interface.NpV2UsbDevice',$true);$path='\\?\usb#vid_1209&pid_b386#001a0004434250062039314e#{8f5a4a7b-0aa6-4f8e-a14f-a2f7b3c6aa4e}'
$device=$type.GetMethod('Open',$f).Invoke($null,@($path))
try{$status=$type.GetMethod('GetServiceStatus',$f).Invoke($device,@());$mode=$status.GetType().GetField('Mode',$f).GetValue($status);$busy=$status.GetType().GetField('Busy',$f).GetValue($status);$target=$status.GetType().GetField('Target',$f).GetValue($status);if($mode -ne 2 -or $busy -ne 0 -or $target -ne 0){throw 'Original mode2 idle not restored'}}finally{$device.Dispose()}
$receipt=[ordered]@{status='EXACT_ORIGINALS_RESTORED_IDLE';uid=$lease.uid;app_crc32='7F238587';usb_crc32='74FC7104';whole_flash_sha256=$original.full_sha256;options_sha256=$original.options_sha256;protected_flash_settings_restored=$true;original_preferences_absent=$true;mode=$mode;busy=$busy;target=$target;c_debugen=0;physical_sd_dma_quiet=$true;original_card_count=22;card_format=$false;old_recordings_deleted=$false;utc=[DateTime]::UtcNow.ToString('o')}
$receipt|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $taskRoot 'restoration-complete.json') -Encoding utf8
[IO.File]::WriteAllText((Join-Path $taskRoot 'owner/release.flag'),'Exact originals, preferences, idle and debug verified')
$receipt|ConvertTo-Json -Compress
