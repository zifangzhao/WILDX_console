from pathlib import Path
import hashlib,json
n=Path(r'C:/Frank/Code/XE_NP/_artifacts/v2_final_usb_delete_20261105').resolve();c=n/'compact';c.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest().upper()
assert load(n/'validation.json')['status']=='PASS_BOUNDED_FINAL_PAIR_WITH_RETAINED_TIMING_LIMITS'
files=[]
for name in ['sd-export1','sd-export2','usb-run1b','usb-run2']:
 r=(n/name).resolve();assert r.is_relative_to(n) and not r.is_symlink()
 targets=list(r.glob('neuropixels_probe*_ap.dat')) if name.startswith('sd') else [p for d in r.glob('probe[123]') for p in d.iterdir() if p.name in ('neuropixels_ap.dat','timestamps.dat','timestamps_calibrated.dat')]
 assert len([p for p in targets if p.name.endswith('_ap.dat')])==3
 for p in targets:
  assert p.resolve().is_relative_to(r) and p.is_file() and not p.is_symlink()
  size=p.stat().st_size;window=min(size,49152 if p.name.endswith('_ap.dat') else 512)
  with p.open('rb') as f:first=f.read(window);f.seek(max(0,size-window));last=f.read(window)
  dest=c/p.relative_to(n);dest.parent.mkdir(parents=True,exist_ok=True)
  pins={}
  for suffix,b in [('first64',first),('last64',last)]:
   q=dest.with_name(dest.name+'.'+suffix+'.bin');q.write_bytes(b);pins[suffix]=dict(file=str(q.relative_to(n)),bytes=len(b),sha256=sha(b))
  files.append(dict(file=str(p.relative_to(n)),original_bytes=size,windows=pins))
(c/'secured-before-cleanup.json').write_text(json.dumps(dict(status='BOUNDED_FIXTURES_SECURED_PRIOR_TO_GENERATED_PAYLOAD_REMOVAL',files=files),indent=2)+'\n')
for item in files:
 p=n/item['file'];assert p.resolve().is_relative_to(n) and p.stat().st_size==item['original_bytes'];p.unlink()
r=dict(status='CONCLUDED_GENERATED_NEURAL_DAT_REMOVED_AFTER_DURABLE_NOTE_AND_FIXTURES',removed_bytes=sum(p['original_bytes'] for p in files),files=files,preserved='All small NP/IMU/native/grid/probe/timing/status/control evidence and prior hardware recovery evidence; all22 user recordings remain on SD')
(c/'cleanup.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(dict(status=r['status'],removed_bytes=r['removed_bytes'],files=len(files))))
