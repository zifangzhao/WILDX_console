from pathlib import Path
import json,hashlib,zipfile
n=Path(r'C:/Frank/Code/XE_NP/_artifacts/v2_final_usb_delete_20261105');p=n/'release';p.mkdir(exist_ok=False)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest().upper();load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
parent=Path(r'C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/accepted.json');assert sha(parent)=='95D6FC028F7FB66DF46A575861D4158EBF70AEA0543F9A9038C9B926FC26201F'
files=set()
for pattern in ('*.json','*.py','*.cs','*.ps1','*.tcl','*.md'):
 files.update(n.glob(pattern))
for name in ('sd-run1','sd-run2','sd-export1','sd-export2','usb-run1','usb-run1b','usb-run2','usb-delete1','usb-delete2','usb-inspect1','baseline-info','baseline-meta','after-delete1-meta','after-delete2-meta','compact','preflight','selftest','usb-api-selftest'):
 files.update(f for f in (n/name).rglob('*') if f.is_file())
for name in ('baseline','after-delete1','after-delete2'):
 files.update((n/name).glob('*.json'));files.update((n/name).glob('sector-*.bin'))
for rel in ('original/receipt.json','deployment/receipt.json','deployment/Install-verified.json','deployment/Restore-verified.json','owner/lease.json','debug-restored.txt','finish-debug.log'):
 files.add(n/rel)
files.update((n/'deployment').glob('*.log'))
assert all(f.is_file() and f.resolve().is_relative_to(n.resolve()) and f.stat().st_size<8*1024*1024 for f in files)
with zipfile.ZipFile(p/'closure.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in sorted(files):z.write(f,f.relative_to(n).as_posix())
assets={}
r=Path(r'D:/Code/XE_NP_V2')
for rel,expected in [('LATEST_FIRMWARE/V2_NP2/V2_FUSED_BOOT_USB067D89A2_APP7E463C83.hex','AEA45E2FF8966F6F3B60EEB04F9937EA9D865C0196BCF92A74DE395D91D8E6F0'),('LATEST_INSTALLERS/WILDX_V2/WILDX_console-Setup-1.0.0.248.exe','06024C10B732F38035AC5F7A6038C769BC964FFEDAAA3470491C3C264B91494E')]:
 f=r/rel;assert sha(f)==expected;assets[rel]=dict(bytes=f.stat().st_size,sha256=sha(f))
a=dict(status='ACCEPTED_SUPPLEMENTAL_BOUNDED_FINAL067_NORMAL_DELETE_AND_RECORDING',parent_acceptance_sha256=sha(parent),original_release_commit='514ebe1c8362e032c90cb292f70075d73ee2aebf',firmware=dict(app='7E463C83',usb='067D89A2',recovery='6408DBB8'),console='1.0.0.248',unchanged_published_assets=assets,validation_sha256=sha(n/'validation.json'),closure=dict(file='closure.zip',bytes=(p/'closure.zip').stat().st_size,sha256=sha(p/'closure.zip'),file_count=len(files)),all22_originals_preserved_by_bounded_checks=True,normal_usb_a7_mutations_passed=2,ordinary_ble_sd_recordings_full_export_passed=2,ordinary_usb_recordings_normal_restart_passed=2,format=False,product_changes=False,new_firmware_or_installer_builds=0,new_power_interruptions=0,source_window_qualified=False,terminal_tail_qualified=False,full_restoration_and_leases_closed=True,limits=load(n/'validation.json')['limits'])
(p/'accepted.json').write_text(json.dumps(a,indent=2)+'\n',encoding='utf-8');ah=sha(p/'accepted.json');zh=sha(p/'closure.zip')
extra=f'\nSupplemental receipt SHA256 **{ah}**; compact closure ZIP SHA256 **{zh}**, {len(files)} files. Concluded generated neural DATs totaling1,935,082,752bytes were removed only after the durable Note and bounded head/tail fixtures were secured. The original acceptance, firmware, fused HEX and WILDX248 installer remain byte-identical. Durable supplemental evidence is under `ReleaseSources/V2_DELETE_LAST_7E463C83_067D89A2_20261105/final067_supplement/`.\n'
note=r/'Note/V2_DELETE_LAST_RECOVERY_20261105.md';note.write_text(note.read_text(encoding='utf-8')+extra,encoding='utf-8');(p/'report.md').write_text((n/'supplemental.md').read_text(encoding='utf-8')+extra,encoding='utf-8')
d=r/'ReleaseSources/V2_DELETE_LAST_7E463C83_067D89A2_20261105/final067_supplement';d.mkdir(exist_ok=False)
for name in ('closure.zip','accepted.json','report.md'):(d/name).write_bytes((p/name).read_bytes())
print(json.dumps(dict(status=a['status'],accepted_sha256=ah,closure_sha256=zh,closure_bytes=(p/'closure.zip').stat().st_size,closure_files=len(files),destination=str(d)),indent=2))
