param([Parameter(Mandatory=$true)][string]$ReceiptName)
$ErrorActionPreference='Stop'
$lease=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'owner/lease.json') -Raw | ConvertFrom-Json
if($lease.status -ne 'active' -or $lease.global_status -ne 'held' -or $lease.uid -ne '001A0004434250062039314E'){throw 'V2 exclusive lease required'}
if($ReceiptName -notmatch '^[a-zA-Z0-9_-]+$'){throw 'Simple receipt name required'}
$receipt=Join-Path $PSScriptRoot "preflight/$ReceiptName.json"
if(Test-Path -LiteralPath $receipt){throw 'Fresh restart receipt required'}
$exe='C:/Frank/Code/USB_PCconsole/_artifacts/sd_usb_test_host/enabled248-bleready/WILDX_console.exe'
if((Get-FileHash -LiteralPath $exe).Hash -ne '364BE7FF77B45C4B959FB72FE9CB657E8F04CEDBCF4C21E3F8F2AC22890DAF30'){throw 'Pinned host changed'}
$asm=[Reflection.Assembly]::LoadFrom($exe)
$f=[Reflection.BindingFlags]'Public,NonPublic,Static,Instance'
$t=$asm.GetType('USB512_interface.NpV2UsbDevice',$true)
function GetValue($o,$n){$field=$o.GetType().GetField($n,$f);if($field){return $field.GetValue($o)};return $o.GetType().GetProperty($n,$f).GetValue($o)}
$path='\\?\usb#vid_1209&pid_b386#001a0004434250062039314e#{8f5a4a7b-0aa6-4f8e-a14f-a2f7b3c6aa4e}'
$d=$t.GetMethod('Open',$f).Invoke($null,@($path))
try{
 $s=$t.GetMethod('GetServiceStatus',$f).Invoke($d,@());$c=$t.GetMethod('GetCaptureStatus',$f).Invoke($d,@())
 if((GetValue $s 'Mode') -ne 2 -or (GetValue $s 'Busy') -ne 0 -or (GetValue $s 'Target') -ne 0 -or (GetValue $c 'State') -notin 4,255 -or (GetValue $c 'SourceState') -ne 11){throw 'Stopped terminal USB source required'}
 [ordered]@{uid=$lease.uid;utc=[DateTime]::UtcNow.ToString('o');prior_capture_state=(GetValue $c 'State');prior_source_state=(GetValue $c 'SourceState');prior_completed=(GetValue $c 'Completed');attempted=$true;confirmed=$false} | ConvertTo-Json | Set-Content -LiteralPath $receipt
 $t.GetMethod('RequestStreamMode',$f).Invoke($d,@()) | Out-Null
}finally{$d.Dispose()}
$watch=[Diagnostics.Stopwatch]::StartNew()
do{
 Start-Sleep -Milliseconds 300
 try{
  $d=$t.GetMethod('Open',$f).Invoke($null,@($path));try{
   $s=$t.GetMethod('GetServiceStatus',$f).Invoke($d,@());$c=$t.GetMethod('GetCaptureStatus',$f).Invoke($d,@());$src=$t.GetMethod('GetSourceStatus',$f).Invoke($d,@())
   if((GetValue $s 'Busy') -eq 0 -and (GetValue $s 'Mode') -eq 2 -and (GetValue $c 'State') -eq 0 -and (GetValue $src 'State') -eq 0){
    $row=Get-Content -LiteralPath $receipt -Raw | ConvertFrom-Json;$row.confirmed=$true;$row | ConvertTo-Json | Set-Content -LiteralPath $receipt
    'Normal production stream restart confirmed idle';exit 0
   }
  }finally{$d.Dispose()}
 }catch{}
}while($watch.Elapsed.TotalSeconds -lt 30)
throw 'Idle not confirmed after one restart; no automatic retry'
