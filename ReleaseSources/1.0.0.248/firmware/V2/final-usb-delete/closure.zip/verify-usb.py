"""Check a stopped production USB248 run. Never delete data or access hardware."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import struct
import zlib

HOST_SHA = "364BE7FF77B45C4B959FB72FE9CB657E8F04CEDBCF4C21E3F8F2AC22890DAF30"
SDK_SHA = "EBC98EEB84FDE42DEE06B713F1F6246B30B3527732075D9F84C6DF57BCA69EFB"
WORKER_SHA = "E28FED0FB3688CFA0994DE65FF8E1023CE7776F89225221913EF8B12DD1216BA"
USB_CRC = "067D89A2"
APP_CRC = "7E463C83"
UID = "001A0004434250062039314E"


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def fields(path):
    return dict(line.strip().split("=", 1) for line in path.read_text(encoding="utf-8-sig").splitlines() if "=" in line)


def need(condition, why):
    if not condition:
        raise ValueError(why)


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest().upper()


def verify(folder):
    report = load(folder / "usb-report.json")
    result = report["result"]
    np = fields(folder / "neuropixels_np2usb_status.txt")
    grid = fields(folder / "imu_grid_status.txt")
    encoding = fields(folder / "analogin_encoding.txt")
    native = load(folder / "imu_native_samples_status.json")
    meta = load(folder / "first_sample_timestamps.json")
    reference = load(folder / "recording_start_utc.json")
    checks = {}
    checks["actual_host248"] = report.get("host_sha256") == HOST_SHA and report.get("sdk_sha256") == SDK_SHA and report.get("worker_source_sha256") == WORKER_SHA and report.get("host_file_version", "").startswith("1.0.0.248")
    checks["final_firmware_pair"] = report.get("usb_crc32") == USB_CRC and report.get("app_crc32") == APP_CRC and report.get("uid") == UID
    checks["read_only_profile_admission"] = report.get("profile_readonly") is True and report.get("profile_selected_probe_mask") == 7 and report.get("profile_hz") == 20000 and report.get("requested_detectors") == 0
    checks["bounded_ordinary_worker"] = report.get("target_data_seconds") == 10 and report.get("confirm_configuration_calls") == 1 and report.get("before_device_dispose_calls") == 1
    checks["normal_complete"] = report.get("complete") is True and report.get("error") is None and report.get("first_data_seen") is True and result.get("Complete") is True and not result.get("CancelledBeforeCapture") and result.get("Error") is None and np.get("complete") == "True" and np.get("final_state") == "complete"
    received, verified = int(result["ReceivedBlocks"]), int(result["VerifiedBlocks"])
    checks["all_np_blocks_verified"] = received > 0 and received == verified and int(np["received_blocks"]) == received and int(np["verified_blocks"]) == verified
    checks["no_host_losses"] = all(int(result[k]) == 0 for k in ("RawDroppedBlocks", "DecodedDroppedLaneBlocks")) and all(np.get(k) == "0" for k in ("raw_dropped_blocks", "decoded_dropped_lane_blocks"))
    checks["no_np_errors"] = all(np.get(k) == "0" for k in ("final_capture_error", "final_producer_error", "final_source_error")) and all(np.get(k) == "none" for k in ("error", "raw_writer_error", "decode_error", "preview_error")) and all(result.get(k) is None for k in ("RawWriterError", "DecodeError", "PreviewError"))
    checks["three_probe_20k"] = result.get("DecodedDatProbeMask") == 7 and result.get("DecodedDatSampleHz") == 20000 and result.get("DecodedDatMerged") is False and np.get("probe_mask") == "0x7" and np.get("live_probe_mask") == "0x7" and np.get("decoded_ap_sample_hz") == "20000" and np.get("mclk_hz") == "32000000"
    hz, ticks = int(np["mclk_hz"]), int(np["ticks_per_block"])
    need(hz == 32000000 and ticks > 0, "Known NP source clock and positive block extent required")
    extent = verified * ticks
    checks["ten_second_capture"] = 9.9 <= float(result["DataSeconds"]) <= 15 and 9.8 <= extent / hz <= 15
    need(meta["anchor"]["exported_source_origin"] == 0, "NP source origin is not the exported zero origin")
    ap = [row for row in meta["rows"] if row.get("band") == "ap"]
    need(len(ap) == 3 and {row["probe"] for row in ap} == {1, 2, 3}, "Three unique AP probe row anchors required")
    probes = []
    for row in sorted(ap, key=lambda item: item["probe"]):
        first = row["decoder_first_row_source_tick"]
        need(isinstance(first, int) and 0 <= first < 1600, "Unambiguous first decoded source tick required")
        need((row["rate_numerator"], row["rate_denominator"]) == (20000, 1), "AP rate anchor differs")
        path = folder / ("probe" + str(row["probe"])) / "neuropixels_ap.dat"
        size = path.stat().st_size
        need(size > 0 and size % 768 == 0, "AP DAT lacks complete384-channel int16 rows")
        rows = size // 768
        expected = (extent - first) // 1600
        checks["probe" + str(row["probe"]) + "_complete_rows"] = rows == expected
        probes.append({"probe": row["probe"], "rows": rows, "expected_rows": expected, "bytes": size, "first_source_tick": first})
    checks["np_row_accounting"] = sum(p["rows"] for p in probes) == int(result["DecodedDatRows"]) == int(np["decoded_ap_rows"])
    requested = (folder / "closed_loop_requested.bin").read_bytes()
    receipt = (folder / "closed_loop_control_receipt.bin").read_bytes()
    need(len(requested) == len(receipt) == 64, "Immutable CL-off worker request/receipt missing")
    checks["confirmed_cl_off"] = requested[:4] == b"NPCC" and receipt[:4] == b"NPCR" and zlib.crc32(requested[:60]) == struct.unpack_from("<I", requested, 60)[0] and zlib.crc32(receipt[:60]) == struct.unpack_from("<I", receipt, 60)[0] and struct.unpack_from("<I", requested, 8)[0] == struct.unpack_from("<I", receipt, 8)[0] == 1 and struct.unpack_from("<I", requested, 12)[0] == struct.unpack_from("<I", receipt, 12)[0] and struct.unpack_from("<I", requested, 32)[0] == 0 and struct.unpack_from("<I", receipt, 16)[0] == 0 and not (struct.unpack_from("<I", receipt, 20)[0] & 2) and struct.unpack_from("<I", receipt, 24)[0] == 0
    events = folder / "closed_loop_events.csv"
    checks["no_cl_events"] = not events.exists() or not list(csv.DictReader(events.open(newline="", encoding="utf-8-sig")))
    checks["imu_no_reported_loss"] = all(grid.get(k) == "0" for k in ("queue_dropped", "scheduler_missing", "aux_sequence_gap_count")) and grid.get("error") == grid.get("transport_error") == "none" and grid.get("counters_lower_bounds") == "False" and result.get("OptionalImuError") is None and native.get("error") is None
    checks["imu_grid_timing"] = all(grid.get(k, "").lower() == "true" for k in ("selected", "enforced_schedule_verified", "phase_qualified", "first_source_verified", "retirement_confirmed")) and all(result.get(k) is True for k in ("ImuGridSelected", "ImuGridEnforcedSchedule", "ImuGridPhaseQualified"))
    validity = (folder / "analogin_validity.dat").read_bytes()
    rows = int(result["ImuGridRows"])
    checks["imu_all_rows_retained"] = rows > 0 and rows == int(result["ImuGridObserved"]) == len(validity) == int(encoding["rows"]) == int(encoding["observed"]) and (folder / "analogin.dat").stat().st_size == rows * 32 and int(encoding["missing"]) == 0
    checks["imu_grid_validity"] = bool(validity) and all((v & 7) == 7 and not (v & ~63) and not (v & 32) for v in validity)
    checks["imu_1250hz_cadence"] = 1240 < rows / float(result["DataSeconds"]) < 1260
    phase = (folder / "imu_grid_phase.bin").read_bytes()
    terminal = (folder / "imu_grid_terminal.bin").read_bytes()
    need(len(phase) == 84 and zlib.crc32(phase[:80]) == struct.unpack_from("<I", phase, 80)[0], "Invalid phase record extent/CRC")
    need(len(terminal) == 80 and zlib.crc32(terminal[:76]) == struct.unpack_from("<I", terminal, 76)[0], "Invalid terminal record extent/CRC")
    first = struct.unpack_from("<Q", phase, 44)[0]
    lo, hi = struct.unpack_from("<qq", phase, 52)
    den, jitter, flags = struct.unpack_from("<III", phase, 68)
    segments = list(csv.DictReader((folder / "imu_grid_segments.csv").open(newline="", encoding="utf-8-sig")))
    need(len(segments) == 1 and int(segments[0]["first_slot"]) == first == 0 and int(segments[0]["first_file_row"]) == 0 and int(segments[0]["row_count"]) == rows, "One contiguous scheduled grid extent required")
    need(den > 0 and lo <= hi and reference["reference_source_hz"] == hz, "Invalid phase/source-clock interval")
    remaining = extent - int(reference["reference_source_tick"]) - (rows - 1) * (hz // 1250) - jitter
    source_window = remaining >= 0 and hi <= remaining * den and lo + (hz // 1250 - jitter) * den >= 0
    checks["imu_source_window_replay_matches"] = source_window == (grid.get("source_window_verified") == "True") == bool(result["ImuGridSourceWindowVerified"])
    inputs = ("usb-report.json", "neuropixels_np2usb_status.txt", "imu_grid_status.txt", "analogin_encoding.txt", "analogin_validity.dat", "analogin.dat", "imu_native_samples_status.json", "first_sample_timestamps.json", "recording_start_utc.json", "closed_loop_requested.bin", "closed_loop_control_receipt.bin", "imu_grid_phase.bin", "imu_grid_terminal.bin", "imu_grid_segments.csv")
    return {"status": "PASS" if all(checks.values()) else "FAIL", "scope": "Stopped production USB248 bounded3P20k CL-off recording, writer/verifier evidence and file extents; read-only assessment.", "uid": report.get("uid"), "usb_crc32": report.get("usb_crc32"), "app_crc32": report.get("app_crc32"), "host_sha256": report.get("host_sha256"), "checks": checks, "np_verified_blocks": verified, "source_extent_ticks": extent, "source_seconds": extent / hz, "data_seconds": result["DataSeconds"], "probes": probes, "imu_grid_rows": rows, "imu_cadence_hz": rows / float(result["DataSeconds"]), "source_window_verified": source_window, "final_slot_known": grid["final_slot_known"], "terminal_final_exclusive": struct.unpack_from("<Q", terminal, 52)[0], "phase": {"first_slot": first, "lower_numerator": lo, "upper_numerator": hi, "denominator": den, "jitter_ticks": jitter, "flags": flags}, "native_sparse_observations": {k: native.get(k) for k in ("observations", "retained_samples", "accepted_samples", "invalid_observations", "sequence_gaps", "reset_segments")}, "input_pins": {name: {"bytes": (folder / name).stat().st_size, "sha256": sha(folder / name)} for name in inputs}, "limits": ["Actual production worker verifies every received block's header, sequence, source extent and NP supersync; AP DAT extents are checked here without rereading full neural payloads.", "The performance codec omits application payload CRC; no analog stimulus, arbitrary ADC bit-error or gain/calibration claim.", "1250Hz grid rows are scheduled cached snapshots. Native conversion/filter phase and SAMPLE0_LOCK are not inferred.", "Sparse native sequence gaps and invalid startup observations remain recorded; they are not converted into primary-grid loss or physical ADC-loss counts.", "Source-window replay retains its actual true/false result. Unknown final scheduled ordinal and physical terminal tail remain unknown.", "Device RTC validity, local RTC-to-NP uncertainty and PC/network time accuracy are separate; no clock was set or newly qualified by this assessment.", "One bounded run is not endurance or an all-mode qualification; no data was deleted."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    folder = args.folder.resolve(strict=True)
    need(not args.output.exists(), "Fresh verification output required")
    result = verify(folder)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: result[k] for k in ("status", "usb_crc32", "np_verified_blocks", "data_seconds", "imu_grid_rows", "source_window_verified", "final_slot_known")}, indent=2))
    if result["status"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
