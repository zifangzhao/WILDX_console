using System;using System.IO;using System.Linq;using System.Reflection;using System.Collections;using System.Collections.Generic;using System.Security.Cryptography;using System.Threading;using System.Threading.Tasks;using System.Web.Script.Serialization;
internal static class NpV2MaintenanceHil {
 const string Root="C:/Frank/Code/XE_NP/_artifacts/v2_final_usb_delete_20261105",Uid="001A0004434250062039314E",PathUsb="\\\\?\\usb#vid_1209&pid_b386#001a0004434250062039314e#{8f5a4a7b-0aa6-4f8e-a14f-a2f7b3c6aa4e}";
 const BindingFlags F=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Static|BindingFlags.Instance;
 static Assembly app;static JavaScriptSerializer json=new JavaScriptSerializer();static Func<bool> Yes=()=>true,No=()=>false;
 static Type T(string n){var t=app.GetType(n,false);if(t!=null)return t;foreach(var a in AppDomain.CurrentDomain.GetAssemblies()){t=a.GetType(n,false);if(t!=null)return t;}throw new TypeLoadException(n);}
 static object Get(object o,string n){var f=o.GetType().GetField(n,F);return f!=null?f.GetValue(o):o.GetType().GetProperty(n,F).GetValue(o,null);}
 static void Set(object o,string n,object v){o.GetType().GetField(n,F).SetValue(o,v);}
 static object Call(object o,string n,params object[] a){var t=o as Type??o.GetType();try{return t.GetMethods(F).Single(m=>m.Name==n&&m.GetParameters().Length==a.Length).Invoke(o is Type?null:o,a);}catch(TargetInvocationException e){throw e.InnerException??e;}}
 static object New(string n,params object[] a){return Activator.CreateInstance(T(n),F,null,a,null);}
 static object Await(object task){((Task)task).GetAwaiter().GetResult();return task.GetType().GetProperty("Result").GetValue(task,null);}
 static void Need(bool b,string m){if(!b)throw new IOException(m);}
 static string Hash(string p){using(var h=SHA256.Create())using(var f=File.OpenRead(p))return BitConverter.ToString(h.ComputeHash(f)).Replace("-","");}
 static void Save(string p,object o){File.WriteAllText(p,json.Serialize(o));}
 static Dictionary<string,object> Fields(object o){return o.GetType().GetFields(F).Where(f=>!f.IsStatic).ToDictionary(f=>f.Name,f=>f.GetValue(o));}
 static object[] Catalog(){using(var card=(IDisposable)New("CE32_console.NpDownloadStream",PathUsb,false)){return ((IEnumerable)Call(T("CE32_console.NpDownloadCatalog"),"Read",card)).Cast<object>().ToArray();}}
 static string[] Identities(object[] records){return records.Select(r=>(string)Call(T("USB512_interface.NpSdUsbTestController"),"CatalogIdentity",r)).ToArray();}
 static void Selftest(string folder){
  Need(Hash("C:/Frank/Code/USB_PCconsole/_artifacts/sd_usb_test_host/enabled248-bleready/WILDX_console.exe")=="364BE7FF77B45C4B959FB72FE9CB657E8F04CEDBCF4C21E3F8F2AC22890DAF30","Host248 differs");app=Assembly.LoadFrom("C:/Frank/Code/USB_PCconsole/_artifacts/sd_usb_test_host/enabled248-bleready/WILDX_console.exe");
  Need(T("CE32_console.NpDownloadStream").GetConstructor(F,null,new[]{typeof(string),typeof(bool)},null)!=null,"Download constructor binding");
  Need(T("USB512_interface.NpUsbDeleteLast").GetConstructor(F,null,new[]{typeof(string),typeof(Func<bool>)},null)!=null,"Delete constructor binding");
  Need(T("USB512_interface.NpSdUsbTestController+Control").GetConstructor(F,null,new[]{typeof(string)},null)!=null,"SD control constructor binding");
  var profile=New("USB512_interface.NpSdUsbProfileResult");Need(profile.GetType().GetField("PreviousStarts",F).FieldType==typeof(long[])&&profile.GetType().GetField("PreviousEnds",F).FieldType==typeof(long[]),"Catalog LBA array types");Need(Get(profile,"Gaps")!=null,"Profile gap object");
  var methods=new[]{"Inspect:1","RequireReady:2","Inner:4","PlanForProfile:5","WaitForResult:3","Verify:4","CatalogIdentity:1"};foreach(var pair in methods){var p=pair.Split(':');Need(T("USB512_interface.NpSdUsbTestController").GetMethods(F).Count(m=>m.Name==p[0]&&m.GetParameters().Length==int.Parse(p[1]))==1,"Unique production API "+pair);}
  Directory.CreateDirectory(folder);Save(folder+"/result.json",new{status="PASS",host_sha256=Hash("C:/Frank/Code/USB_PCconsole/_artifacts/sd_usb_test_host/enabled248-bleready/WILDX_console.exe"),hardware_calls=0,profile_writes=0,api_methods=methods,scope="Exact248 reflection signatures and LBA widths; no enumeration, device open, command or card action"});Console.WriteLine("PASS selftest");
 }
 static void Guard(){Need(Hash("C:/Frank/Code/USB_PCconsole/_artifacts/sd_usb_test_host/enabled248-bleready/WILDX_console.exe")=="364BE7FF77B45C4B959FB72FE9CB657E8F04CEDBCF4C21E3F8F2AC22890DAF30","Actual248 host changed");var d=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(Root+"/owner/lease.json"));Need((string)d["status"]=="active"&&(string)d["uid"]==Uid,"Exact active lease required");System.Diagnostics.Process.GetProcessById(Convert.ToInt32(d["pid"]));app=Assembly.LoadFrom("C:/Frank/Code/USB_PCconsole/_artifacts/sd_usb_test_host/enabled248-bleready/WILDX_console.exe");}
 static void Info(string folder,bool active){var result=Call(T("USB512_interface.NpSystemInfo"),active?"ReadCard":"Read",PathUsb,"NP V2");var sd=Get(result,"Sd");if(sd!=null)File.WriteAllBytes(folder+"/sdif384.bin",(byte[])Get(sd,"Raw"));File.WriteAllText(folder+"/report.txt",(string)Call(result,"Report","1.0.0.248"));Save(folder+"/result.json",Fields(result));if(active)Need(sd!=null&&Convert.ToUInt32(Get(sd,"State"))==2U,"SD Info query did not complete READY");}
 static void Inspect(string folder){using(var d=(IDisposable)New("USB512_interface.NpUsbDeleteLast",PathUsb,Yes)){var r=Call(d,"Inspect");File.WriteAllBytes(folder+"/receipt128.bin",(byte[])Get(r,"Bytes"));Save(folder+"/result.json",Fields(r));}}
 static void Quality(string folder){var r=Call(T("USB512_interface.UsbQualityTest"),"RunDevice",PathUsb,false,No,null,false);Save(folder+"/result.json",Fields(r));File.WriteAllText(folder+"/report.txt",(string)Get(r,"Report"));Need((string)Get(r,"Outcome")=="completed"&&Get(r,"Error")==null&&Convert.ToInt64(Get(r,"Blocks"))>0,"USB quality did not complete cleanly");}
 static void RunSd(string folder){
  var controller=New("USB512_interface.NpSdUsbTestController",PathUsb);var type=T("USB512_interface.NpSdUsbTestController");
  var prior=Catalog();var before=Await(Call(controller,"Inspect",CancellationToken.None));Call(type,"RequireReady",before,true);
  Need((bool)Call(before,"Supports",7U,20000U),"3P20k SD job not advertised");
  byte[] inner=(byte[])Call(controller,"Inner",before,7U,20000U,10U),plan=(byte[])Call(type,"PlanForProfile",before,inner,10U,true,null);
  var profile=New("USB512_interface.NpSdUsbProfileResult");Set(profile,"Folder",folder);Set(profile,"SampleHz",20000U);Set(profile,"PreviousCatalog",Identities(prior));
  Set(profile,"PreviousSessions",prior.Select(r=>Convert.ToUInt32(Get(r,"Session"))).ToArray());Set(profile,"PreviousStarts",prior.Select(r=>Convert.ToInt64(Get(r,"Start"))).ToArray());Set(profile,"PreviousEnds",prior.Select(r=>Convert.ToInt64(Get(r,"End"))).ToArray());
  File.WriteAllBytes(folder+"/request128.bin",plan);File.WriteAllBytes(folder+"/before256.bin",(byte[])Get(before,"Raw"));Save(folder+"/previous-catalog.json",Identities(prior));
  using(var control=(IDisposable)New("USB512_interface.NpSdUsbTestController+Control",PathUsb)){var latest=Call(control,"Report",2,Uid);Need(((byte[])Call(type,"PlanForProfile",latest,inner,10U,true,null)).SequenceEqual(plan),"SD admission changed; no submit");Call(control,"Submit",plan);}
  var terminal=Await(Call(controller,"WaitForResult",plan,10U,null));File.WriteAllBytes(folder+"/after256.bin",(byte[])Get(terminal,"Raw"));
  Call(Get(profile,"Gaps"),"Device",terminal);Call(controller,"Verify",terminal,profile,No,null);Save(folder+"/result.json",Fields(profile));
  Need((bool)Get(profile,"ReadbackCompleted")&&Get(profile,"Evidence").ToString()=="VerifiedPass","Actual SD controller readback did not pass");
  var after=Catalog();Need(after.Length==prior.Length+1,"Expected exactly one own test session");Need(Identities(after.Take(prior.Length).ToArray()).SequenceEqual(Identities(prior)),"Previous catalog changed");var last=after.Last();
  Save(folder+"/own-verified.json",new{status="verified_full_readback",uid=Uid,start=Get(last,"Start"),end=Get(last,"End"),session=Get(last,"Session"),previous=Identities(prior),post=Identities(after)});
 }
 static object CompletedReport(object report){return typeof(Task).GetMethods(BindingFlags.Public|BindingFlags.Static).Single(m=>m.Name=="FromResult").MakeGenericMethod(report.GetType()).Invoke(null,new[]{report});}
 static Delegate Producer(Type delegateType,Func<object> factory){var call=System.Linq.Expressions.Expression.Call(System.Linq.Expressions.Expression.Constant(factory),typeof(Func<object>).GetMethod("Invoke"));return System.Linq.Expressions.Expression.Lambda(delegateType,System.Linq.Expressions.Expression.Convert(call,delegateType.GetMethod("Invoke").ReturnType)).Compile();}
 static void ResumeSd(string folder,string original){
  Need(System.IO.Path.GetFullPath(original).StartsWith(System.IO.Path.GetFullPath(Root)+System.IO.Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase),"Only own completed job receipt permitted");
  var type=T("USB512_interface.NpSdUsbTestController");var wire=T("USB512_interface.NpSdUsbTestWire");var controller=New("USB512_interface.NpSdUsbTestController",PathUsb);
  byte[] plan=File.ReadAllBytes(original+"/request128.bin");var before=Call(wire,"ParseReport",File.ReadAllBytes(original+"/before256.bin"),2,Uid);var terminal=Call(wire,"ParseReport",File.ReadAllBytes(original+"/after256.bin"),2,Uid);
  var method=type.GetMethods(F).Single(m=>m.Name=="RefreshTerminal"&&m.GetParameters().Length==6);var ps=method.GetParameters();
  var inspect=Producer(ps[3].ParameterType,()=>CompletedReport(Call(controller,"FreshReport",CancellationToken.None)));
  var observe=Producer(ps[4].ParameterType,()=>{using(var c=(IDisposable)New("USB512_interface.NpSdUsbTestController+Control",PathUsb))return CompletedReport(Call(c,"Report",2,Uid));});
  var fresh=Await(Call(type,"RefreshTerminal",plan,terminal,before,inspect,observe,50));File.WriteAllBytes(folder+"/fresh-after256.bin",(byte[])Get(fresh,"Raw"));
  var prior=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(original+"/result.json"));var profile=New("USB512_interface.NpSdUsbProfileResult");Set(profile,"Folder",folder);Set(profile,"SampleHz",20000U);
  Set(profile,"PreviousCatalog",((IEnumerable)prior["PreviousCatalog"]).Cast<object>().Select(Convert.ToString).ToArray());
  Set(profile,"PreviousSessions",((IEnumerable)prior["PreviousSessions"]).Cast<object>().Select(Convert.ToUInt32).ToArray());Set(profile,"PreviousStarts",((IEnumerable)prior["PreviousStarts"]).Cast<object>().Select(Convert.ToInt64).ToArray());Set(profile,"PreviousEnds",((IEnumerable)prior["PreviousEnds"]).Cast<object>().Select(Convert.ToInt64).ToArray());
  Set(profile,"SubmitEntered",true);Set(profile,"SubmitAcknowledged",true);Set(profile,"SafeToContinue",(bool)Call(type,"SafeTerminal",fresh));Call(Get(profile,"Gaps"),"Device",fresh);
  Call(controller,"Verify",fresh,profile,No,null);Save(folder+"/result.json",Fields(profile));
  Need((bool)Get(profile,"ReadbackCompleted")&&Get(profile,"Evidence").ToString()=="VerifiedPass","Same-session actual refreshed controller readback did not pass");
  var after=Catalog();var ids=(string[])Get(profile,"PreviousCatalog");Need(after.Length==ids.Length+1&&Identities(after.Take(ids.Length).ToArray()).SequenceEqual(ids),"Previous catalog changed");var last=after.Last();
  Save(folder+"/own-verified.json",new{status="verified_full_readback",uid=Uid,start=Get(last,"Start"),end=Get(last,"End"),session=Get(last,"Session"),previous=ids,post=Identities(after),original_job_folder=original,refresh_scope="Same completed ticket; actual RefreshTerminal and Verify; no second Submit or Start"});
 }
 static void InspectAfterCatalog(string folder){var prior=Catalog();Save(folder+"/catalog.json",Identities(prior));var c=New("USB512_interface.NpSdUsbTestController",PathUsb);var r=Await(Call(c,"Inspect",CancellationToken.None));File.WriteAllBytes(folder+"/report256.bin",(byte[])Get(r,"Raw"));using(var control=(IDisposable)New("USB512_interface.NpSdUsbTestController+Control",PathUsb))File.WriteAllBytes(folder+"/a1-inspection64.bin",(byte[])Call(control,"Read",(byte)0xa0,64));Save(folder+"/result.json",new{status="PASS",scope="Production completed catalog bulk-read then actual SD-controller Inspect/A1; no new SD test submitted",records=prior.Length});}
 static void DeleteOwn(string folder,string proofPath){
  Need(System.IO.Path.GetFullPath(proofPath).StartsWith(System.IO.Path.GetFullPath(Root)+System.IO.Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase),"Only this workpackage proof permitted");
  var p=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(proofPath));Need((string)p["status"]=="verified_full_readback"&&(string)p["uid"]==Uid,"Own verified recording proof required");
  var before=Catalog();Need(before.Length>0&&Convert.ToUInt32(Get(before.Last(),"Start"))==Convert.ToUInt32(p["start"])&&Convert.ToUInt32(Get(before.Last(),"End"))==Convert.ToUInt32(p["end"])&&Convert.ToUInt32(Get(before.Last(),"Session"))==Convert.ToUInt32(p["session"]),"Own test is not exact last record; no deletion");
  using(var d=(IDisposable)New("USB512_interface.NpUsbDeleteLast",PathUsb,Yes)){var confirmed=Call(d,"Inspect");Need((uint)Get(confirmed,"Start")==Convert.ToUInt32(p["start"])&&(uint)Get(confirmed,"End")==Convert.ToUInt32(p["end"]),"Inspection targets another record");File.WriteAllBytes(folder+"/confirmed128.bin",(byte[])Get(confirmed,"Bytes"));var done=Call(d,"Delete",confirmed);File.WriteAllBytes(folder+"/complete128.bin",(byte[])Get(done,"Bytes"));Save(folder+"/result.json",Fields(done));}
  var after=Catalog();Need(after.Length+1==before.Length&&Identities(after).SequenceEqual(Identities(before.Take(before.Length-1).ToArray())),"Prior records changed during own test deletion");Save(folder+"/preserved.json",new{status="PASS",before=Identities(before),after=Identities(after),scope="Only own verified last complete test entry journal removed; no old recording deleted"});
 }
 static void Fingerprint(string folder){
  using(var obj=(IDisposable)New("CE32_console.NpDownloadStream",PathUsb,false)){
   var card=(Stream)obj;var records=((IEnumerable)Call(T("CE32_console.NpDownloadCatalog"),"Read",card)).Cast<object>().ToArray();
   var entries=new List<object>();int ordinal=0;
   foreach(long lba in new long[]{16,112,113,114,115,116,128}){byte[] raw=new byte[512];card.Position=lba*512L;int at=0;while(at<512){int n=card.Read(raw,at,512-at);Need(n>0,"Short metadata snapshot");at+=n;}File.WriteAllBytes(folder+"/sector-"+lba+".bin",raw);}

   foreach(var r in records){long first=Convert.ToInt64(Get(r,"Start")),last=Convert.ToInt64(Get(r,"End"));Need(first>=8192&&last>first+16,"Bounded closed extent required");var pieces=new List<object>();
    foreach(var q in new[]{new long[]{first,16},new long[]{first+32,4},new long[]{first+(last-first)/2,4},new long[]{last-4,4}}){long lba=q[0];int n=checked((int)q[1]*512);Need(lba>=first&&lba+q[1]<=last,"Fingerprint within stored extent");byte[] b=new byte[n];card.Position=checked(lba*512L);int at=0;while(at<n){int k=card.Read(b,at,n-at);Need(k>0,"Short fingerprint read");at+=k;}string name="record-"+ordinal.ToString("D5")+"-"+lba+".bin";File.WriteAllBytes(folder+"/"+name,b);pieces.Add(new{lba=lba,sectors=q[1],sha256=Hash(folder+"/"+name),file=name});}
    entries.Add(new{ordinal=ordinal++,identity=(string)Call(T("USB512_interface.NpSdUsbTestController"),"CatalogIdentity",r),pieces=pieces});
   }
   Save(folder+"/fingerprint.json",new{status="READ_ONLY_BOUNDED_FINGERPRINT",uid=Uid,count=records.Length,entries=entries});Save(folder+"/catalog.json",Identities(records));
  }
 }
 static int Main(string[] a){try{Need(a.Length>=2,"action fresh-folder [own-proof]");if(a[0]=="selftest"){Selftest(a[1]);return 0;}Guard();Need(!Directory.Exists(a[1]),"Fresh output required");Directory.CreateDirectory(a[1]);switch(a[0]){case "info":Info(a[1],true);break;case "passive":Info(a[1],false);break;case "inspect":Inspect(a[1]);break;case "quality":Quality(a[1]);break;case "fingerprint":Fingerprint(a[1]);break;case "catalog":Save(a[1]+"/catalog.json",Identities(Catalog()));break;case "sdjob":RunSd(a[1]);break;case "resume-sd-readback":Need(a.Length==3,"Existing completed job only");ResumeSd(a[1],a[2]);break;case "a1-after-catalog":InspectAfterCatalog(a[1]);break;case "delete-own":Need(a.Length==3,"Explicit own proof required");DeleteOwn(a[1],a[2]);break;default:throw new ArgumentException("Unknown action");}Console.WriteLine("PASS "+a[0]);return 0;}catch(Exception e){Console.Error.WriteLine(e);return 1;}}
}
