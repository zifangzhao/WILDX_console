"""Generate an actual-source USB admission fixture; caller owns compile/run."""
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
SRC = HERE / "Core/Src"


def function(text, name):
    match = re.search(r"(?m)^static[^\n]*\b" + re.escape(name) + r"\(", text)
    if not match:
        raise ValueError(name)
    opening = text.index("{", match.end())
    depth = 1
    cursor = opening + 1
    while depth:
        depth += (text[cursor] == "{") - (text[cursor] == "}")
        cursor += 1
    return text[match.start():cursor]


MODEL = r'''
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define __attribute__(x)
#define SD_CONTEXT_NONE 0U
#define SD_CONTEXT_WRITE_SINGLE_BLOCK 2U
#define SDMMC_STA_BUSYD0 1U
#define SDMMC_CLKCR_CLKDIV 1023U
#define HAL_OK 0
#define XE_NP_USB_CATALOG_REPAIR 0xA2U
#define XE_NP_USB_SD_FORMAT_COMMAND 0x7AU
#define XE_NP_USB_SD_FORMAT_ENABLE 1
#define XE_NP_USB_DOWNLOAD_IDMA_READ_ENABLE 1
#define XE_NP_USB_CATALOG_RUNNING 2U
#define XE_NP_USB_CATALOG_QUEUED 1U
#define XE_NP_USB_CATALOG_COMPLETE 3U
#define XE_NP_USB_CATALOG_FAILED 4U
enum {USB_CAT_OWNER=1,USB_CAT_IDENTITY,USB_CAT_IO,USB_CAT_CATALOG,
 USB_CAT_CANCELLED,USB_CAT_CLOCK,USB_CAT_DELETE_RECONCILE=0x100};
static struct {uint32_t STA,CLKCR;} sd_regs;
#define SDMMC1 (&sd_regs)
static struct {uint32_t CID[4];} hsd1;
static struct {uint32_t configured;void *hpcd;} xe_np_usb_state;
static struct {
 uint32_t running,queued,sector_owned,cancel_generation,operation,epoch,generation,last_nonce;
 uint32_t capacity,cid[4],error,inspected,saved_clock,metadata_clock,clock_held;
} xe_np_usb_catalog;
static uint32_t xe_np_usb_catalog_report[16];
static uint8_t xe_np_usb_catalog_write[512];
static uint8_t xe_np_usb_catalog_read[512];
static int hdcache1,clean_result,dma_result;
static uint32_t clean_calls,dma_calls;
static uint32_t xe_np_usb_delete_writes_allowed,xe_np_usb_delete_directory_lba;
static uint32_t np_download_state,np_download_epoch,xe_np_selftest_dirty;
static uint32_t primask,ipsr,basepri,faultmask,download,capacity,owner_idle,quiet;
static uint32_t external_busy,test_busy,active_test,cache_calls,abort_calls;
static uint32_t reconcile_calls,hal_writes,authenticated_target,cancel_reconcile,write_reconcile,active_reconcile;
static int reconcile_result;
#define __get_PRIMASK() primask
#define __get_IPSR() ipsr
#define __get_BASEPRI() basepri
#define __get_FAULTMASK() faultmask
#define __disable_irq() (primask=1U)
#define __set_PRIMASK(x) (primask=(x))
#define __DMB() ((void)0)
#define __DSB() ((void)0)
static int XE_NP_UsbUnified_IsDownload(void){return (int)download;}
static uint32_t NP_SD_DownloadCapacity(void){return download?capacity:0U;}
static int xe_np_usb_catalog_busy(void){return external_busy || xe_np_usb_catalog.running || xe_np_usb_catalog.sector_owned;}
static int xe_np_usb_sd_test_busy(void){return (int)test_busy;}
static int XE_NP_UsbSdTest_Active(void){return (int)active_test;}
static void NP_SD_UsbService(void){assert(np_download_state==4U);abort_calls++;np_download_state=0U;}
static int xe_np_usb_catalog_host_idle(uint32_t context){return owner_idle && !context && !np_download_state;}
static int xe_np_usb_catalog_physical_quiet(void){return (int)quiet;}
static int xe_np_usb_catalog_reconcile_idle_cache(void){cache_calls++;return xe_np_usb_catalog_host_idle(0U);}
static int xe_np_usb_catalog_identity(void){return capacity==xe_np_usb_catalog.capacity && !memcmp(hsd1.CID,xe_np_usb_catalog.cid,16U);}
static int xe_np_usb_catalog_current(uint32_t context){return
 xe_np_usb_catalog_identity() && xe_np_usb_catalog_host_idle(context) &&
 np_download_epoch==xe_np_usb_catalog.epoch &&
 xe_np_usb_catalog.cancel_generation==xe_np_usb_catalog.generation &&
 sd_regs.CLKCR==xe_np_usb_catalog.metadata_clock;}
static int xe_np_usb_catalog_retire(uint32_t context){assert(context==SD_CONTEXT_WRITE_SINGLE_BLOCK || context==SD_CONTEXT_NONE);xe_np_usb_catalog.sector_owned=0U;return 0;}
static int HAL_DCACHE_CleanByAddr(void *cache,const uint32_t *p,uint32_t n){assert(cache==&hdcache1 && p==(const uint32_t *)xe_np_usb_catalog_read && n==512U);clean_calls++;return clean_result;}
static int XE_NP_Board_SdReadBlocksDmaPolling(void *card,uint8_t *p,uint32_t lba,uint32_t blocks,uint32_t ms){assert(card==&hsd1&&p==xe_np_usb_catalog_read&&lba<capacity&&blocks==1U&&ms==1000U&&xe_np_usb_catalog.sector_owned);dma_calls++;if(dma_result)return dma_result;memset(p,0xA5,512U);return HAL_OK;}
static int HAL_SD_WriteBlocks(void *h,uint8_t *in,uint32_t lba,uint32_t blocks,uint32_t timeout){
 assert(!ipsr && !primask && h==&hsd1 && in==xe_np_usb_catalog_write && blocks==1U && timeout==1000U);
 (void)lba;hal_writes++;return HAL_OK;
}
static uint32_t XE_NP_Np2DualSdCatalog_DeleteTarget(void){return authenticated_target;}
static uint32_t XE_NP_Np2DualSd_Crc32(const uint8_t *p,uint32_t n){uint32_t c=0;while(n--)c=c*33U+*p++;return c;}
static int xe_np_usb_catalog_read_sector(void *u,uint32_t lba,uint8_t out[512]);
static int xe_np_usb_catalog_no_command(void *u,uint32_t a){(void)u;(void)a;assert(0);return -1;}
typedef struct {void *user;int (*read_sector)(void *,uint32_t,uint8_t *);
 int (*write_sector)(void *,uint32_t,const uint8_t *);int (*stopped_command)(void *,uint32_t);
 uint32_t card_blocks,cid[4];} XE_NP_Np2DualSdCatalogIo;
static XE_NP_Np2DualSdCatalogIo bound_io;
static void xe_np_usb_catalog_cancel(void);
static void usb_maintenance_cancel(void){}
static void xe_np_usb_catalog_format_cancel(void){}
static int XE_NP_Np2DualSdCatalog_Bind(const XE_NP_Np2DualSdCatalogIo *io){assert(!ipsr&&!primask);bound_io=*io;return 0;}
static int XE_NP_Np2DualSdCatalog_ReconcileDelete(uint32_t *next){
 assert(!ipsr&&!primask&&xe_np_usb_catalog.running);reconcile_calls++;
 assert(bound_io.card_blocks==capacity && !memcmp(bound_io.cid,hsd1.CID,16U));
 if(write_reconcile){uint8_t zero[512]={0};const uint32_t lbas[]={129U,112U,115U,116U};
  for(unsigned i=0;i<4;i++)assert(!bound_io.write_sector(NULL,lbas[i],zero));*next=8192U;}
 if(cancel_reconcile){np_download_epoch++;xe_np_usb_catalog_cancel();}
 if(active_reconcile)quiet=0U;
 return reconcile_result;
}
'''

CASES = r'''
static void reset(void){
 memset(&xe_np_usb_catalog,0,sizeof(xe_np_usb_catalog));memset(xe_np_usb_catalog_report,0,sizeof(xe_np_usb_catalog_report));
 xe_np_usb_catalog_report[0]=0x3152434eU;xe_np_usb_catalog_report[1]=1U;
 memset(&sd_regs,0,sizeof(sd_regs));sd_regs.CLKCR=0x2B4011U;
 xe_np_usb_state.configured=1U;xe_np_usb_state.hpcd=&hsd1;
 for(unsigned i=0;i<4;i++)hsd1.CID[i]=i+1U;
 primask=ipsr=basepri=faultmask=0U;download=owner_idle=quiet=1U;capacity=131072U;
 external_busy=test_busy=active_test=cache_calls=abort_calls=0U;
 clean_result=dma_result=0;clean_calls=dma_calls=0U;
 reconcile_calls=hal_writes=cancel_reconcile=write_reconcile=active_reconcile=0U;reconcile_result=0;
 np_download_state=np_download_epoch=xe_np_selftest_dirty=0U;authenticated_target=129U;
 xe_np_usb_delete_writes_allowed=0U;xe_np_usb_delete_directory_lba=130U;
 usb_delete_reconcile_pending=0U;usb_delete_reconcile_hook=usb_delete_reconcile_done;
}
int main(void){
 reset();download=0U;usb_delete_reconcile_arm();assert(!usb_delete_reconcile_pending&&!reconcile_calls);
 reset();xe_np_usb_catalog.last_nonce=17U;usb_delete_reconcile_arm();assert(usb_delete_reconcile_pending&&!reconcile_calls&&!hal_writes);
 uint32_t *irq_guards[]={&ipsr,&primask,&basepri,&faultmask};
 for(unsigned i=0;i<4;i++){*irq_guards[i]=1U;assert(!usb_delete_reconcile_hook()&&!reconcile_calls);*irq_guards[i]=0U;}
 np_download_state=4U;assert(usb_delete_reconcile_hook()&&abort_calls==1U&&!reconcile_calls&&usb_delete_reconcile_pending);
 owner_idle=0U;assert(!usb_delete_reconcile_hook()&&!reconcile_calls&&usb_delete_reconcile_pending);owner_idle=1U;
 uint32_t clock=sd_regs.CLKCR;assert(usb_delete_reconcile_hook()&&reconcile_calls==1U&&!hal_writes);
 assert(!usb_delete_reconcile_pending&&sd_regs.CLKCR==clock&&xe_np_usb_catalog_report[3]==0U);
 assert(xe_np_usb_catalog_report[2]==0U&&xe_np_usb_catalog_report[4]==0U&&xe_np_usb_catalog.last_nonce==17U);
 assert(!usb_delete_reconcile_hook()&&reconcile_calls==1U&&!primask);
 reset();capacity=1024U;usb_delete_reconcile_arm();assert(!usb_delete_reconcile_hook()&&!usb_delete_reconcile_pending&&!reconcile_calls);
 reset();reconcile_result=-1;usb_delete_reconcile_arm();assert(usb_delete_reconcile_hook());
 assert(!usb_delete_reconcile_pending&&xe_np_usb_catalog_report[3]==0U&&xe_np_usb_catalog_report[2]==0U&&xe_np_usb_catalog.error==USB_CAT_CATALOG&&NP_SD_DownloadCapacity()==capacity);
 assert(!usb_delete_reconcile_hook()&&reconcile_calls==1U);
 reset();write_reconcile=1U;usb_delete_reconcile_arm();clock=sd_regs.CLKCR;assert(usb_delete_reconcile_hook()&&hal_writes==4U&&sd_regs.CLKCR==clock);
 reset();cancel_reconcile=1U;usb_delete_reconcile_arm();assert(usb_delete_reconcile_hook()&&usb_delete_reconcile_pending);
 assert(xe_np_usb_catalog.error==USB_CAT_CANCELLED&&xe_np_usb_catalog_report[3]==0U&&xe_np_usb_catalog_report[2]==0U);cancel_reconcile=0U;usb_delete_reconcile_arm();assert(usb_delete_reconcile_hook()&&!usb_delete_reconcile_pending&&reconcile_calls==2U);
 reset();active_reconcile=1U;reconcile_result=-1;usb_delete_reconcile_arm();assert(usb_delete_reconcile_hook());
 assert(!usb_delete_reconcile_pending&&xe_np_usb_catalog.clock_held&&xe_np_usb_catalog.sector_owned&&sd_regs.CLKCR==xe_np_usb_catalog.metadata_clock);
 /* Exercise the actual adapter write whitelist independently of replay. */
 reset();xe_np_usb_catalog.running=1U;xe_np_usb_catalog.capacity=capacity;memcpy(xe_np_usb_catalog.cid,hsd1.CID,16U);
 xe_np_usb_catalog.metadata_clock=sd_regs.CLKCR;xe_np_usb_catalog.operation=USB_CAT_DELETE_RECONCILE;
 uint8_t zero[512]={0};const uint32_t forbidden[]={16U,113U,114U,128U,130U,1152U,8192U};
 for(unsigned i=0;i<7;i++)assert(xe_np_usb_catalog_write_sector(NULL,forbidden[i],zero));
 assert(!xe_np_usb_catalog_write_sector(NULL,129U,zero));authenticated_target=UINT32_MAX;
 assert(xe_np_usb_catalog_write_sector(NULL,129U,zero));
 xe_np_usb_catalog.operation=0xA7U;assert(xe_np_usb_catalog_write_sector(NULL,114U,zero));xe_np_usb_delete_writes_allowed=1U;
 for(uint32_t lba=112U;lba<=116U;lba++)assert(!xe_np_usb_catalog_write_sector(NULL,lba,zero));
 assert(!xe_np_usb_catalog_write_sector(NULL,130U,zero)&&xe_np_usb_catalog_write_sector(NULL,129U,zero));
 xe_np_usb_catalog.operation=XE_NP_USB_CATALOG_REPAIR;
 for(uint32_t lba=114U;lba<=116U;lba++)assert(!xe_np_usb_catalog_write_sector(NULL,lba,zero));
 xe_np_usb_catalog.operation=XE_NP_USB_SD_FORMAT_COMMAND;
 for(uint32_t lba=114U;lba<=116U;lba++)assert(!xe_np_usb_catalog_write_sector(NULL,lba,zero));
 /* Actual metadata read uses the existing IDMA reader, not a USB-IRQ-sensitive
  * CPU FIFO loop. Admission/cache/failed-transfer ownership stays explicit. */
 reset();xe_np_usb_catalog.running=1U;xe_np_usb_catalog.capacity=capacity;memcpy(xe_np_usb_catalog.cid,hsd1.CID,16U);xe_np_usb_catalog.metadata_clock=sd_regs.CLKCR;
 uint8_t data[512]={0};assert(!xe_np_usb_catalog_read_sector(NULL,115U,data));
 assert(clean_calls==1U&&dma_calls==1U&&!xe_np_usb_catalog.sector_owned);
 for(unsigned i=0;i<512U;i++)assert(data[i]==0xA5U);
 clean_result=-1;assert(xe_np_usb_catalog_read_sector(NULL,115U,data));assert(dma_calls==1U&&!xe_np_usb_catalog.sector_owned);
 clean_result=0;dma_result=-1;assert(xe_np_usb_catalog_read_sector(NULL,115U,data));assert(dma_calls==2U&&xe_np_usb_catalog.sector_owned);
 xe_np_usb_catalog.sector_owned=0U;assert(xe_np_usb_catalog_read_sector(NULL,capacity,data));assert(dma_calls==2U);
 puts("PASS actual USB cold admission, A0/cancellation, IDMA metadata read/cache/error ownership, no IRQ IO, exact-target writes");return 0;
}
'''


def main():
    texts = {name: (SRC / name).read_text() for name in (
        "xe_np_usb_stream.c", "xe_np_usb_unified.inc", "xe_np_usb_catalog.inc",
        "xe_np_usb_maintenance.inc", "xe_np_usb_sd_format.inc")}
    stream = texts["xe_np_usb_stream.c"]
    start = stream.index("static int usb_delete_reconcile_service(void);")
    declarations = stream[start:stream.index("\n#endif", start)]
    # Actual lifecycle/admission placements are also part of the integration.
    assert "configured = 1U;\n#if XE_NP_USB_UNIFIED_ENABLE && XE_NP_USB_CATALOG_REPAIR_ENABLE\n                    usb_delete_reconcile_arm();" in stream
    assert "if(XE_NP_UsbUnified_IsDownload()){\n#if XE_NP_USB_CATALOG_REPAIR_ENABLE\n        if(usb_delete_reconcile_hook())return;" in stream
    assert "usb_delete_reconcile_pending &&\n       !(req->bmRequest&0x80U) && req->bRequest!=0x6FU" in stream
    assert "if(xe_np_usb_card_ready)usb_delete_reconcile_arm();" in texts["xe_np_usb_unified.inc"]
    assert "clear[]={16U,112U,113U,114U,115U,116U," in texts["xe_np_usb_sd_format.inc"]
    fixture = MODEL + declarations + "\n" + function(texts["xe_np_usb_catalog.inc"], "xe_np_usb_catalog_write_sector")
    fixture += "\n" + function(texts["xe_np_usb_catalog.inc"], "xe_np_usb_catalog_cancel")
    fixture += "\n" + function(texts["xe_np_usb_catalog.inc"], "xe_np_usb_catalog_read_sector")
    fixture += "\n" + function(texts["xe_np_usb_maintenance.inc"], "usb_delete_reconcile_service") + "\n" + CASES
    output = HERE / "usb_reconcile_fixture.c"
    output.write_text(fixture)
    pins = {name: hashlib.sha256((SRC / name).read_bytes()).hexdigest().upper() for name in texts}
    (HERE / "usb_reconcile_fixture_inputs.json").write_text(json.dumps({
        "source_sha256": pins, "fixture": str(output),
        "scope": "Actual cold hook and whitelist with mocked HAL/shared reconcile outcomes; no persistence or physical power-loss claim."
    }, indent=2) + "\n")
    print(output)


if __name__ == "__main__":
    main()
