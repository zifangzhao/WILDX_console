from pathlib import Path
import hashlib,json
T=Path(__file__).resolve().parent
source=Path('C:/Frank/Code/XE_NP/_artifacts/v2_delete_last_recovery_prep_20261106/generated')
old='C:/Frank/Code/XE_NP/_artifacts/v2_delete_last_20261105/runtime/WILDX_console.exe'
host='C:/Frank/Code/USB_PCconsole/_artifacts/sd_usb_test_host/enabled248-bleready/WILDX_console.exe'
oldsha='FA744968A3DE0AC9A87F6FD77F8F3ED40BFAB3FBD062ABD9B33BEE3E233E8953'
newsha='364BE7FF77B45C4B959FB72FE9CB657E8F04CEDBCF4C21E3F8F2AC22890DAF30'
assert hashlib.sha256(Path(host).read_bytes()).hexdigest().upper()==newsha
inputs={}
for name in ['NpV2DeleteTail','NpV2DeleteBleRecord','NpV2BleLinkProbe']:
 p=(T if name=='NpV2BleLinkProbe' else source)/(name+'.cs');s=p.read_text()
 assert old in s and oldsha in s
 s=s.replace(old,host).replace(oldsha,newsha)
 if name=='NpV2DeleteBleRecord':
  needle='Call(T("USB512_interface.NpBleConnection"),"ReadDevice",x,(Func<uint>)Next)'
  assert s.count(needle)==1
  s=s.replace(needle,'Call(connection,"ReadInitialDevice",(Func<uint>)Next)')
 else:
  needle='await Await(method.Invoke(connection,new[]{(object)address,observed}));}'
  assert s.count(needle)==1
  s=s.replace(needle,'await Await(method.Invoke(connection,new[]{(object)address,observed}));var ready=await Await(Invoke(connection,"ReadInitialDevice",(Func<uint>)Next));Need(Convert.ToInt32(Get(ready,"Item1"))==2,"Actual initial readiness must discover V2");}')
 if name=='NpV2BleLinkProbe':
  assert s.count('await Task.Delay(500);')==1
  s=s.replace('await Task.Delay(500);','/* Actual248 owns initial readiness; no external wait/retry. */')
 o=T/(name+'248.cs');o.write_text(s)
 inputs[name]=dict(input_sha256=hashlib.sha256(p.read_bytes()).hexdigest().upper(),output_sha256=hashlib.sha256(o.read_bytes()).hexdigest().upper())
(T/'host248-helper-pins.json').write_text(json.dumps(dict(host=host,host_sha256=newsha,actual_initial_method='NpBleConnection.ReadInitialDevice',external_settling_delay=False,sources=inputs),indent=2)+'\n')
