from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, sys
O=Path(__file__).resolve().parent; R=Path('D:/Code/XE_NP_V2'); T=O.parent
out=O/'run1';out.mkdir(exist_ok=True)
assert not (out/'receipt.json').exists(), 'Do not rerun a passed check without a new change'
model=Path('C:/Frank/Code/USB_PCconsole/_artifacts/v2_delete_last_native_20261105/run1/sparse_model.inc').read_text()
model=model.replace('assert(lba==112U||lba==113U||lba==allowed_directory);',
                    'assert((lba>=112U&&lba<=116U)||lba==allowed_directory);')
(out/'sparse_model.inc').write_text(model)
(out/'fixture.c').write_bytes((O/'fixture.c').read_bytes())
vc='C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat'
sources=[out/'fixture.c',T/'Core/Src/xe_np_np2_dual_sd_catalog.c',R/'Core/Src/xe_np_np2_dual_sd_meta.c',R/'Core/Src/xe_np_np2_dual_sd_run.c']
includes=[T/'Core/Inc',R/'Core/Inc',R/'Drivers/STM32U5xx_HAL_Driver/Inc']
cmd='@echo off\ncall "'+vc+'" >nul\ncl /nologo /std:c11 /W4 /WX /TC /O2 '+f'/Fo"{out}/" /Fe"{out}/delete.exe" '
cmd+=' /DXE_NP_NP2_SD_CATALOG_ENABLE=1U /DXE_NP_NP2_SD_APPEND_ORDER_TEST=1U '
cmd+=' '.join('/I"'+str(p)+'"' for p in includes)+' '+' '.join('"'+str(p)+'"' for p in sources)+'\n'
(out/'compile.cmd').write_text(cmd)
p=subprocess.run(['cmd','/d','/c',str(out/'compile.cmd')],cwd=out,capture_output=True,text=True)
(out/'compile.log').write_text(p.stdout+p.stderr)
assert p.returncode==0,(p.stdout+p.stderr)
p=subprocess.run([str(out/'delete.exe')],cwd=out,capture_output=True,text=True,timeout=180)
(out/'result.log').write_text(p.stdout+p.stderr)
print(p.stdout+p.stderr,flush=True)
assert p.returncode==0,p.returncode
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
receipt={'status':'ACTUAL_CATALOG_INTERRUPTED_DELETE_RECOVERY_PASS','utc':datetime.now(timezone.utc).isoformat(),
 'source_sha256':{str(p):sha(p) for p in [*sources,T/'Core/Src/xe_np_np2_delete_journal.inc',T/'Core/Inc/xe_np_np2_dual_sd_catalog.h',out/'sparse_model.inc']},
 'result':p.stdout,'scope':'Actual isolated shared V2 catalog; prefix persistence model, no hardware/firmware timing or physical power-loss claim.'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('receipt',out/'receipt.json',sha(out/'receipt.json'))
