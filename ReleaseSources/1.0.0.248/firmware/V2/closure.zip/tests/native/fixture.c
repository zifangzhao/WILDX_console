#include "sparse_model.inc"
static CardModel saved,pending_card;
static uint32_t checks,cases,recovery_cases,old_views,new_views,append_ok,negatives;
#define CHECK(x) do{checks++;if(!(x)){fprintf(stderr,"FAIL line%u: %s\n",__LINE__,#x);return 1;}}while(0)
static void bind_card(uint32_t changed)
{
 XE_NP_Np2DualSdCatalogIo io={0};io.read_sector=read_sector;io.write_sector=write_sector;
 io.stopped_command=command;io.card_blocks=card.capacity;
 for(unsigned i=0;i<4U;i++)io.cid[i]=i+1U;
 io.cid[0]^=changed;assert(!XE_NP_Np2DualSdCatalog_Bind(&io));
}
static uint8_t *sector(uint32_t lba)
{for(uint32_t i=0U;i<card.count;i++)if(card.slot[i].lba==lba)return card.slot[i].bytes;return NULL;}
static void seal_intent(uint8_t *p)
{np_put32(p+508U,crc32(p,508U));}
static int seed(uint32_t count,uint32_t *last_start)
{
 memset(&card,0,sizeof(card));card.capacity=8388608U;card.failed_lba=card.failed_read_lba=UINT32_MAX;
 mutation_writes=forbid_commands=0U;bind_card(0U);
 uint8_t ident[512]={0},zero[512]={0},config[2048]={0};
 memcpy(ident,"CE_FILESYSTEM_V1",16U);memcpy(ident+32U,XE_NP_NP2_DUAL_SD_CARD_IDENT,9U);
 CHECK(!write_sector(NULL,16U,ident));CHECK(!write_sector(NULL,112U,zero));
 CHECK(!write_sector(NULL,113U,zero));CHECK(!write_sector(NULL,128U,zero));
 uint32_t next;CHECK(!XE_NP_Np2DualSdCatalog_Mount(&next));
 for(uint32_t i=0U;i<count;i++){
  XE_NP_Np2DualSdMeta m;CHECK(!XE_NP_Np2DualSdCatalog_Plan(20000U,8U,1000U+i,crc32(config,2048U),&m));
  CHECK(!XE_NP_Np2DualSdCatalog_Reserve(&m,config));
  CHECK(!XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0U,4U));
  memset(zero,(int)(0x51U+i),512U);CHECK(!write_sector(NULL,m.run.payload_start_lba+1U,zero));
  *last_start=m.reservation_start_lba;CHECK(!XE_NP_Np2DualSdCatalog_Mount(&next));
 }
 return 0;
}
static int retained(int before_append,uint32_t last_start)
{
 uint8_t actual[512];
 for(uint32_t i=0U;i<saved.count;i++){
  uint32_t lba=saved.slot[i].lba;
  if(lba>=8192U && (before_append || lba<last_start))
   CHECK(!read_sector(NULL,lba,actual) && !memcmp(actual,saved.slot[i].bytes,512U));
  if(lba>=128U && lba<allowed_directory)
   CHECK(!read_sector(NULL,lba,actual) && !memcmp(actual,saved.slot[i].bytes,512U));
 }
 return 0;
}
static int start_cut(uint32_t count,uint32_t cut,uint32_t prefix)
{
 card=saved;bind_card(0U);uint32_t next;
 CHECK(!XE_NP_Np2DualSdCatalog_Mount(&next));
 XE_NP_Np2DualSdCatalogInfo info;CHECK(!XE_NP_Np2DualSdCatalog_Info(&info));CHECK(info.count==count);
 XE_NP_Np2DualSdCatalogDelete d={info.token,info.count,info.last_ordinal,info.last_start,info.last_end,info.last_cookie};
 allowed_directory=128U+(count-1U)/63U;mutation_writes=forbid_commands=1U;
 fault_prefix=prefix;card.failed_write=card.writes+cut;
 CHECK(XE_NP_Np2DualSdCatalog_DeleteLast(&d,&next)!=0);
 card.failed_write=0U;return 0;
}
static int recover_append(uint32_t count,uint32_t last_start,int automatic)
{
 bind_card(0U);uint32_t next,writes=card.writes,commands=card.commands;
 CHECK(!XE_NP_Np2DualSdCatalog_Mount(&next));CHECK(card.writes==writes);
 XE_NP_Np2DualSdCatalogInfo info;CHECK(!XE_NP_Np2DualSdCatalog_Info(&info));CHECK(card.writes==writes);
 CHECK(info.count==count || info.count==count-1U);
 if(XE_NP_Np2DualSdCatalog_DeleteTarget()!=UINT32_MAX){
  uint8_t blocked_config[2048]={0};XE_NP_Np2DualSdMeta blocked_meta={0};
  CHECK(info.flags&XE_NP_NP2_CATALOG_RECOVERY);
  CHECK(!XE_NP_Np2DualSdCatalog_MountAvailable(&next));CHECK(card.writes==writes);
  CHECK(XE_NP_Np2DualSdCatalog_Status()&XE_NP_NP2_CATALOG_RECOVERY);
  CHECK(XE_NP_Np2DualSdCatalog_Plan(20000U,4U,4444U,0U,&blocked_meta)!=0);
  CHECK(XE_NP_Np2DualSdCatalog_Reserve(&blocked_meta,blocked_config)!=0);
  CHECK(card.writes==writes);
 }
 if(info.count==count)old_views++;else new_views++;
 if(automatic)CHECK(!XE_NP_Np2DualSdCatalog_ReconcileDelete(&next));
 else CHECK(!XE_NP_Np2DualSdCatalog_Recover(&next));
 CHECK(card.commands==commands);CHECK(!retained(1,last_start));
 CHECK(!XE_NP_Np2DualSdCatalog_Info(&info));CHECK(!(info.flags&XE_NP_NP2_CATALOG_RECOVERY));
 CHECK(XE_NP_Np2DualSdCatalog_DeleteTarget()==UINT32_MAX);
 uint8_t b[512];CHECK(!read_sector(NULL,112U,b));
 for(unsigned i=0U;i<512U;i++)CHECK(!b[i]);
 if(!automatic)for(uint32_t lba=115U;lba<=116U;lba++){
  CHECK(!read_sector(NULL,lba,b));for(unsigned i=0U;i<512U;i++)CHECK(!b[i]);
 }
 /* Earlier records are checked before and after reclaim/append. */
 uint8_t config[2048]={0};XE_NP_Np2DualSdMeta fresh;mutation_writes=forbid_commands=0U;
 CHECK(!XE_NP_Np2DualSdCatalog_Plan(20000U,4U,9999U,crc32(config,2048U),&fresh));
 CHECK(!XE_NP_Np2DualSdCatalog_Reserve(&fresh,config));
 CHECK(!XE_NP_Np2DualSdCatalog_Finish(XE_NP_NP2_DUAL_SD_META_COMPLETE,0U,4U));
 CHECK(!retained(0,last_start));append_ok++;return 0;
}
static int recovery_cuts(uint32_t count,uint32_t last_start)
{
 CHECK(!start_cut(count,6U,257U));pending_card=card;
 for(uint32_t cut=1U;cut<=4U;cut++)for(uint32_t prefix=0U;prefix<=512U;prefix++){
  card=pending_card;bind_card(0U);uint32_t next,writes=card.writes;
  CHECK(!XE_NP_Np2DualSdCatalog_Mount(&next));CHECK(card.writes==writes);
  mutation_writes=forbid_commands=1U;fault_prefix=prefix;card.failed_write=card.writes+cut;
  CHECK(XE_NP_Np2DualSdCatalog_Recover(&next)!=0);CHECK(!retained(1,last_start));
  card.failed_write=0U;CHECK(!recover_append(count,last_start,0));recovery_cases++;
 }
 return 0;
}
static int bad_proof(uint32_t count,uint32_t last_start,uint32_t bad)
{
 CHECK(!start_cut(count,6U,257U));uint32_t next,writes=card.writes;
 uint8_t *a=sector(115U),*b=sector(116U);CHECK(a && b);
 if(bad==0U)bind_card(0x100U);
 else if(bad==1U){card.capacity--;bind_card(0U);}
 else {
  if(bad==2U)sector(114U)[17]^=1U;
  if(bad==3U)sector(113U)[17]^=1U;
  if(bad==4U){np_put32(a+28U,np_get32(a+28U)^1U);seal_intent(a);}
  if(bad==5U){a[117U]=1U;seal_intent(a);memcpy(b,a,512U);}
  if(bad==6U)sector(last_start+3U)[16U]^=1U;
  if(bad==7U)sector(last_start+4U)[16U]^=1U;
  if(bad==8U)sector(allowed_directory)[4U]^=1U;
  if(bad==9U)sector(112U)[37U]=0x5AU;
  if(bad>=10U){const uint32_t lba[]={113U,114U,115U,116U};card.failed_read_lba=lba[bad-10U];}
  bind_card(0U);
 }
 CHECK(XE_NP_Np2DualSdCatalog_Mount(&next)!=0);
 CHECK(XE_NP_Np2DualSdCatalog_ReconcileDelete(&next)!=0);CHECK(card.writes==writes);
 negatives++;return 0;
}
static int residue_and_format(uint32_t last_start)
{
 card=saved;bind_card(0U);uint32_t next;
 uint8_t b[512],config[2048]={0};memset(b,0x6DU,512U);mutation_writes=0U;
 CHECK(!write_sector(NULL,115U,b));CHECK(!write_sector(NULL,116U,b));
 uint32_t writes=card.writes;CHECK(!XE_NP_Np2DualSdCatalog_Mount(&next));CHECK(card.writes==writes);
 CHECK(!XE_NP_Np2DualSdCatalog_ReconcileDelete(&next));CHECK(card.writes==writes);
 CHECK(!retained(1,last_start));
 forbid_commands=0U; /* Explicit FORMAT's existing stopped command is separate. */
 CHECK(!XE_NP_Np2DualSdCatalog_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,config));
 for(uint32_t lba=114U;lba<=116U;lba++){
  CHECK(!read_sector(NULL,lba,b));for(unsigned i=0U;i<512U;i++)CHECK(!b[i]);
 }
 return 0;
}
int main(void)
{
 const uint32_t counts[]={1U,3U,63U,64U};
 for(unsigned c=0U;c<4U;c++){
  uint32_t last_start;CHECK(!seed(counts[c],&last_start));saved=card;
  uint32_t old=cases,rc=recovery_cases;
  for(uint32_t cut=1U;cut<=9U;cut++)for(uint32_t prefix=0U;prefix<=512U;prefix++){
   CHECK(!start_cut(counts[c],cut,prefix));CHECK(!retained(1,last_start));
   CHECK(!recover_append(counts[c],last_start,(int)(prefix&1U)));cases++;
  }
  if(c!=2U)CHECK(!recovery_cuts(counts[c],last_start));
  printf("PASS count%u deletecuts%u recoverycuts%u\n",counts[c],cases-old,recovery_cases-rc);fflush(stdout);
  if(c==1U){for(uint32_t bad=0U;bad<14U;bad++)CHECK(!bad_proof(counts[c],last_start,bad));
   CHECK(!residue_and_format(last_start));}
 }
 printf("PASS checks%u deletecuts%u recoverycuts%u oldviews%u newviews%u append%u proofrejects%u; readonly Mount/Info; protected earlier metadata/payload sentinels unchanged\n",
        checks,cases,recovery_cases,old_views,new_views,append_ok,negatives);
 return 0;
}
