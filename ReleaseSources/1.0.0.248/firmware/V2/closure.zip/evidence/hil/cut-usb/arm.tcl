init
targets stm32u5.cpu
set u [read_memory 0x0bfa0700 32 3]
if {[format "%08X%08X%08X" [lindex $u 0] [lindex $u 1] [lindex $u 2]] ne "001A0004434250062039314E"} {error "WrongFreshUID"}
if {[lindex [read_memory 0xe000ed08 32 1] 0]!=0x8180000 || [lindex [read_memory 0x817e020 32 1] 0]!=0x16f3aedd} {error "WrongExactNewImage"}
proc quiet {} {
 if {[lindex [read_memory 0x420c8034 32 1] 0]&0x103000 || [lindex [read_memory 0x420c8050 32 1] 0] || [lindex [read_memory 0x420c802c 32 1] 0]&1} {error "SDnotphysicallyquiet"}
 for {set i 0} {$i<16} {incr i} {if {[lindex [read_memory [expr {0x40020064+$i*0x80}] 32 1] 0]&1} {error "DMAactive"}}
}
proc crcbuf {addr n} {
 set c 0xffffffff
 foreach b [read_memory $addr 8 $n] {set c [expr {$c^$b}];for {set i 0} {$i<8} {incr i} {if {$c&1} {set c [expr {(($c>>1)^0xedb88320)&0xffffffff}]} else {set c [expr {($c>>1)&0xffffffff}]}}}
 return [expr {$c^0xffffffff}]
}
quiet
halt
wait_halt 3000
bp 0x81cf0e8 2 hw
resume
set f [open {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/cut-usb/armed.ready} w];puts $f "Exact map/UID/own-proof bound first112 publication breakpoint armed";close $f
set history {};set found 0
for {set i 0} {$i<12000} {incr i} {
 sleep 5
 poll
 if {[stm32u5.cpu curstate] eq "halted"} {
  set regs [get_reg {pc r0 r1 r2 sp lr}];set lba [expr {[dict get $regs r1]+0}]
  lappend history $lba
  set f [open {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/cut-usb/write-entry-history.txt} a];puts $f $regs;close $f
  if {$lba==112} {
   if {$history ne {114 113 115 116 112}} {error "UnexpectedWriteHistoryBeforeIntentCut"}
   quiet
   set intent 0x2001238c;set before 0x20011f8c;set after 0x2001218c;set verify 0x200b8cbc
   set iw [read_memory $intent 32 128]
   if {[lindex $iw 0]!=0x4544324e || [lindex $iw 1]!=0x3130304c || [lindex $iw 2]!=1 || [lindex $iw 3]!=1} {error "WrongN2DEL001Envelope"}
   if {[lindex $iw 127]!=[crcbuf $intent 508]} {error "NewIntentCRCInvalid"}
   set target [lindex $iw 5]
   if {$target<128 || $target>=1152 || [lindex $iw 6]!=23 || [lindex $iw 12]!=22 || [lindex $iw 13]!=36462592 || [lindex $iw 14]!=37246044} {error "IntentNotExactFreshOwnTail"}
   if {[lindex [read_memory $before 32 1] 0]!=[lindex [read_memory $after 32 1] 0]+1 || [lindex $iw 20]!=[crcbuf $before 512] || [lindex $iw 21]!=[crcbuf $after 512]} {error "BeforeAfterNotIntentBound"}
   if {[read_memory $verify 32 128] ne $iw} {error "LatestReadback116DoesNotMatchIntent"}
   dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/cut-usb/before114-RAM.bin} $before 512
   dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/cut-usb/after113-RAM.bin} $after 512
   dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/cut-usb/intent-RAM.bin} $intent 512
   dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/cut-usb/verified116-readback.bin} $verify 512
   dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/cut-usb/sdmmc-before.bin} 0x420c8000 96
   set f [open {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/cut-usb/boundary.txt} w];puts $f "target=$target original_total=22 own_session=2585883389 history=$history RAMimagesAreNotDirectCardReads verified116IsLatestDurableReadback beforeFirst112Write noTornSectorClaim";puts $f $regs;close $f
   if {([lindex [read_memory 0x42021400 32 1] 0]>>4&3)!=1 || !([lindex [read_memory 0x42021414 32 1] 0]&4)} {error "PF2NotOwnedOutputHigh"}
   write_memory 0x42021418 32 {262144}
   if {[lindex [read_memory 0x42021414 32 1] 0]&4} {error "PF2OffReadbackFailed"}
   dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/cut-usb/vee-off-gpio.bin} 0x42021400 40
   set f [open {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/cut-usb/vee-low.ready} w];puts $f "CommandedPF2lowOnly noSDrail0Vproof noGPIOdischarge";close $f
   sleep 5000
   rbp 0x81cf0e8
   reset run
   sleep 500
   poll off
   write_memory 0xe000edf0 32 {0xa05f0000}
   if {[lindex [read_memory 0xe000edf0 32 1] 0]&1} {error "DebugStillEnabledAfterReset"}
   set f [open {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/cut-usb/reset-performed.txt} w];puts $f "Quiet committed-mirror boundary, VEEenablelow5s, MCUreset, no torn-sector/physical-zero/full-power claim. Automatic recovery still UNVERIFIED.";close $f
   set found 1
   break
  }
  if {[llength $history]>5} {error "UnexpectedExtraWriteBeforeCut"}
  step
  resume
 }
}
if {!$found} {halt;error "NoCutObserved; inspect delivery/state before any replay/reset"}
shutdown
