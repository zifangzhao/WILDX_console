init
targets stm32u5.cpu
set u [read_memory 0x0bfa0700 32 3]
if {[format "%08X%08X%08X" [lindex $u 0] [lindex $u 1] [lindex $u 2]] ne "001A0004434250062039314E"} {error "WrongFreshUID"}
if {[lindex [read_memory 0xe000ed08 32 1] 0]!=0x08180000 || [lindex [read_memory 0x0817e020 32 1] 0]!=0x16f3aedd || [lindex [read_memory 0x0801e020 32 1] 0]!=0x7e463c83} {error "NotExactIdleUSBWithCheckedAPP"}
proc quiet {} {
 if {[lindex [read_memory 0x420c8034 32 1] 0]&0x103000 || [lindex [read_memory 0x420c8050 32 1] 0] || [lindex [read_memory 0x420c802c 32 1] 0]&1} {error "SDnotphysicallyquiet"}
 for {set i 0} {$i<16} {incr i} {if {[lindex [read_memory [expr {0x40020064+$i*0x80}] 32 1] 0]&1} {error "DMAactive"}}
}
proc crcbuf {addr n} {
 set c 0xffffffff
 foreach b [read_memory $addr 8 $n] {set c [expr {$c^$b}];for {set i 0} {$i<8} {incr i} {if {$c&1} {set c [expr {(($c>>1)^0xedb88320)&0xffffffff}]} else {set c [expr {($c>>1)&0xffffffff}]}}}
 return [expr {$c^0xffffffff}]
}
quiet
halt
wait_halt 3000
bp 0x803dfd4 2 hw
resume
set f [open {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/observe-app-auto/armed.ready} w];puts $f "APP ReconcileDelete observer armed while exactUSBstream; owner may issue productionSdMode once";close $f
set entered 0;set returned 0;set history {};set expectedIntent {1162097230 825241676 1 1 501301248 128 23 3952691689 1480868932 1145261645 1624900210 1073846506 22 36462592 37241299 1678458168 21 35676160 36460342 2649201716 3575743219 2204262480 2271510054 3556068913 2425487976 2725363493 37241299 36460342 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 63363277};set expectedAfter {22 2046514 6403139 8688448 10940639 11733966 12506528 13297381 14070997 14867690 15618352 17799531 20019118 22243327 24450016 26661897 28851107 31077223 33291577 34098897 34878718 35670990 36460342 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2046514 6403139 8688448 10940639 11733966 12506528 13297381 14070997 14867690 15618352 17799531 20019118 22243327 24450016 26661897 28851107 31077223 33291577 34098897 34878718 35670990 36460342 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0}
for {set i 0} {$i<18000} {incr i} {
 sleep 5
 poll
 if {[stm32u5.cpu curstate] ne "halted"} {continue}
 set regs [get_reg {pc r0 r1 r2 sp lr xpsr}]
 set pc [expr {[dict get $regs pc]+0}];set sp [expr {[dict get $regs sp]+0}]
 set f [open {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/observe-app-auto/register-history.txt} a];puts $f $regs;close $f
 if {!$entered} {
  if {$pc!=0x803dfd4 || ([dict get $regs xpsr]&0x1ff)} {error "UnexpectedEntryOrNonThreadOwner"}
  if {[lindex [read_memory 0xe000ed08 32 1] 0]!=0x08020000 || [lindex [read_memory 0x0801e020 32 1] 0]!=0x7e463c83} {error "WrongAPPAtEntry"}
  set returnPC [expr {[dict get $regs lr]&~1}];set entrySP $sp;set nextPointer [expr {[dict get $regs r0]+0}]
  if {$returnPC<0x08020000 || $returnPC>=0x0817e000 || $nextPointer<0x20000000 || $nextPointer>=0x202a0000} {error "UnownedReturnOrNextPointer"}
  set f [open {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/observe-app-auto/entry.txt} w];puts $f "LRreturn=$returnPC entrySP=$entrySP nextPointer=$nextPointer";puts $f $regs;close $f
  rbp 0x803dfd4
  bp 0x8074cbc 2 hw
  bp $returnPC 2 hw
  set entered 1
  step
  resume
  continue
 }
 if {$pc==0x8074cbc} {
  set lba [expr {[dict get $regs r1]+0}];set data [expr {[dict get $regs r2]+0}]
  if {$lba!=128 && $lba!=112 && $lba!=115 && $lba!=116} {error "APPWroteOutsideConfirmedOwnIntent"}
  quiet
  # Compare words numerically: OpenOCD versions may print hexadecimal strings.
  set current [read_memory 0x20001d00 32 128];set n 0
  foreach actual $current wanted $expectedIntent {if {[expr {$actual+0}]!=$wanted} {error "APPIntentDiffersFromCapturedOwnIntent"};incr n}
  if {$n!=128} {error "IncompleteAPPIntent"}
  if {[lindex $current 20]!=[crcbuf 0x20001900 512] || [lindex $current 21]!=[crcbuf 0x20001b00 512]} {error "APPBeforeAfterCRCNotIntentBound"}
  if {$lba==128} {set expected $expectedAfter} else {set expected [lrepeat 128 0]}
  set n 0;foreach actual [read_memory $data 32 128] wanted $expected {if {[expr {$actual+0}]!=$wanted} {error "APPMetadataWriteNotConfirmedAfterOrClear"};incr n}
  if {$n!=128} {error "IncompleteAPPWrite"}
  lappend history $lba
  dump_image [format {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/observe-app-auto/write-%02d-lba-%d-RAM.bin} [llength $history] $lba] $data 512
  step
  resume
  continue
 }
 if {$pc==$returnPC && $sp==$entrySP} {
  quiet
  set result [expr {[dict get $regs r0]+0}]
  set pending [expr {[lindex [read_memory 0x20001f00 32 1] 0]+0}]
  set residue [expr {[lindex [read_memory 0x20001f04 32 1] 0]+0}]
  set retiredTarget [expr {[lindex [read_memory 0x20001f08 32 1] 0]+0}]
  dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/observe-app-auto/return-journal-RAM.bin} 0x20001900 1548
  set f [open {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/observe-app-auto/return-proof.txt} w];puts $f "r0=$result pending=$pending residue=$residue retiredTarget=$retiredTarget history=$history";puts $f $regs;close $f
  if {$result || $pending || $residue || $retiredTarget!=0xffffffff} {error "APPAutomaticCompletionFailed"}
  if {$history ne {128 115 116} && $history ne {128 112 115 116}} {error "APPReplayNotObserved;USBMayAlreadyHaveReconciledOrUnexpectedWriteOrder"}
  rbp 0x8074cbc
  rbp $returnPC
  resume
  sleep 50
  poll off
  write_memory 0xe000edf0 32 {0xa05f0000}
  set f [open {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/observe-app-auto/app-replay-observed.txt} w];puts $f "ExactAPPReconcileDelete returned0, own-target/clear writes observed, pending/residue0 and targetMAX BEFORE USBdownload. These are CPU/RAM/source-return observations; separate persisted-card count/journals/readback/preservation still required.";close $f
  set returned 1
  break
 }
 error "UnexpectedHalt;NoAutomaticResetOrReplay"
}
if {!$returned} {halt;error "APPObserverTimeout;InspectStateBeforeCleanupOrReplay"}
shutdown
