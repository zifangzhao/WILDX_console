init
targets stm32u5.cpu
set u [read_memory 0x0bfa0700 32 3]
if {[format "%08X%08X%08X" [lindex $u 0] [lindex $u 1] [lindex $u 2]] ne "001A0004434250062039314E"} {error "WrongUID"}
if {!([lindex [read_memory 0xe000edf0 32 1] 0]&0x20000)} {error "NotOriginalHaltedReturn"}
poll
get_reg {pc r0 r1 r2 sp lr}
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/observe-usb-auto-r3/failed-sd.bin} 0x420c8000 128
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/observe-usb-auto-r3/failed-hsd.bin} 0x20012c28 128
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/observe-usb-auto-r3/failed-catalog-owner.bin} 0x200b9458 104
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/observe-usb-auto-r3/failed-sector-read.bin} 0x2001cae0 512
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/observe-usb-auto-r3/failed-journal.bin} 0x20011f8c 1548
dump_image {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/observe-usb-auto-r3/failed-core.bin} 0xe000ed04 60
shutdown
