init
targets stm32u5.cpu
set u [read_memory 0x0bfa0700 32 3]
if {[format "%08X%08X%08X" [lindex $u 0] [lindex $u 1] [lindex $u 2]] ne "001A0004434250062039314E"} {error "WrongUID"}
if {[lindex [read_memory 0x0817e020 32 1] 0]!=0x16f3aedd} {error "WrongFailedImage"}
if {!([lindex [read_memory 0xe000edf0 32 1] 0]&0x20000)} {error "FailedReadNoLongerHalted"}
poll
set regs [get_reg {pc r0}]
if {[dict get $regs pc]!=0x081cb742 || [dict get $regs r0]!=0xffffffff} {error "NotCapturedFailedReadReturn"}
# No metadata write was issued. A controlled MCU reset retires the captured
# failed read; do not clear/rewrite the pending delete intents or replay A7.
reset run
sleep 500
poll off
write_memory 0xe000edf0 32 {0xa05f0000}
set f [open {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/observe-usb-auto-r3/failed-read-reset.txt} w];puts $f "One controlled reset after preserved failed read evidence. No metadata write/delete replay. Pending intent still belongs to the same own tail.";close $f
shutdown
