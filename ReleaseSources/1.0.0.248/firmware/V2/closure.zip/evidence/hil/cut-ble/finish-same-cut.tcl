init
targets stm32u5.cpu
set u [read_memory 0x0bfa0700 32 3]
if {[format "%08X%08X%08X" [lindex $u 0] [lindex $u 1] [lindex $u 2]] ne "001A0004434250062039314E"} {error "WrongUID"}
if {[lindex [read_memory 0xe000ed08 32 1] 0]!=0x08020000 || [lindex [read_memory 0x0801e020 32 1] 0]!=0x7e463c83} {error "WrongImage"}
if {!([lindex [read_memory 0xe000edf0 32 1] 0]&0x20000)} {error "NoLongerHalted; noReset"}
poll
set regs [get_reg {pc r1}]
if {[dict get $regs pc]!=0x08074cbc || [dict get $regs r1]!=112} {error "NotSamePendingWrite"}
if {[lindex [read_memory 0x42021414 32 1] 0]&4} {error "VEEWasNotHeldLow"}
if {![file exists {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/cut-ble/vee-low.ready}]} {error "NoBoundPriorCutReceipt"}
reset run
sleep 500
poll off
write_memory 0xe000edf0 32 {0xa05f0000}
if {[lindex [read_memory 0xe000edf0 32 1] 0]&1} {error "DebugStillEnabled"}
set f [open {C:/Frank/Code/XE_NP/_artifacts/v2_torn_journal_fix_20261105/hil/cut-ble/reset-performed.txt} w]
puts $f "Same delivered first112 transaction. VEE low5s was completed before stale-breakpoint removal failed; this fresh guarded continuation performed the only MCU reset. No replay, measured-zero or torn-sector claim."
close $f
shutdown
