C:\Frank\Code\USB_PCconsole\_artifacts\closed_loop_20261102\V2\build-app\np_cl_kernel.o: \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\np_cl_kernel.c \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Inc\np_cl_kernel.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\stdint.h \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Inc\np_cl_cycle_probe.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\math.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\string.h
