C:\Frank\Code\XE_NP\_artifacts\v2_usb_imu100_20261105\build\xe_np_sensors.o: \
  C:\Frank\Code\XE_NP\_artifacts\v2_usb_imu100_20261105\Core\Src\xe_np_sensors.c \
  D:\Code\XE_NP_V2\Core\Inc\xe_np_sensors.h \
  D:\Code\XE_NP_V2\Core\Inc\..\..\Middlewares\Bosch\BME280_SensorAPI\bme280.h \
  D:\Code\XE_NP_V2\Core\Inc\..\..\Middlewares\Bosch\BME280_SensorAPI\bme280_defs.h \
  D:\Code\XE_NP_V2\Core\Inc\..\..\Middlewares\Bosch\BMM150_SensorAPI\bmm150.h \
  D:\Code\XE_NP_V2\Core\Inc\..\..\Middlewares\Bosch\BMM150_SensorAPI\bmm150_defs.h
