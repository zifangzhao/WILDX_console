"""Inventory the accepted incremental object graphs; never compile or package."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import zipfile

T = Path(__file__).resolve().parent
R = Path("D:/Code/XE_NP_V2")
PARENT = Path("C:/Frank/Code/USB_PCconsole/_artifacts/v2_gui_support_source_freeze_20261105/source-freeze.zip")
OUTPUT = T / "source-provenance-inventory.json"


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().upper()


def norm(path):
    return str(Path(path).resolve()).replace("\\", "/").casefold()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def identity(path):
    p = Path(path)
    return {"path": str(p.resolve()), "bytes": p.stat().st_size, "sha256": sha(p)}


def logical(path):
    s = str(Path(path).resolve()).replace("\\", "/")
    low = s.casefold()
    for marker in ("/firmware/v1/", "/core/", "/drivers/", "/shared/", "/bootloader/", "/tools/"):
        at = low.rfind(marker)
        if at >= 0:
            return s[at + 1:]
    if "/neuropixels/closedloop/" in low:
        return "ConsoleClosedLoop/" + s[low.index("/neuropixels/closedloop/") + len("/neuropixels/closedloop/"):]
    if "/keil_v5/" in low:
        return "Toolchain/" + s[low.index("/keil_v5/") + len("/keil_v5/"):]
    return Path(s).name


def dependencies(path):
    # ARMclang's Windows makefile output: drive colon is not the rule colon;
    # one dependency per continued line, with escaped spaces when necessary.
    text = Path(path).read_text(encoding="utf-8-sig")
    match = re.search(r":\s+\\?\s*\r?\n", text)
    if not match:
        return [], "unrecognized_make_rule"
    text = re.sub(r"\\\r?\n", " ", text[match.end():])
    text = text.replace(r"\ ", "\0")
    tokens = [x.replace("\0", " ") for x in text.split()]
    result = []
    for token in tokens:
        if token.endswith(":") or token == "\\":
            continue
        p = Path(token)
        if not p.is_absolute():
            return tokens, "relative_paths_require_original_working_directory"
        result.append(p.resolve())
    return list(dict.fromkeys(result)), None


def command_output(command):
    return norm(command[command.index("-o") + 1]) if "-o" in command else None


def hash_maps(node, pointer=""):
    result = []
    if isinstance(node, dict):
        for key, value in node.items():
            if isinstance(value, str) and re.fullmatch(r"[0-9a-fA-F]{64}", value) and re.match(r"^[A-Za-z]:[/\\]", key):
                result.append((norm(key), value.upper(), pointer + "/" + key))
            elif isinstance(value, (dict, list)):
                result.extend(hash_maps(value, pointer + "/" + key))
    elif isinstance(node, list):
        for i, value in enumerate(node):
            if isinstance(value, (dict, list)):
                result.extend(hash_maps(value, pointer + "/" + str(i)))
    return result


def main():
    with zipfile.ZipFile(PARENT) as archive:
        manifest = json.loads(archive.read("manifest.json"))
        parent_files = {norm(x["origin"]): x for x in manifest["files"] if x.get("origin")}
        parent_sources = []
        for item in manifest["files"]:
            if not item["path"].startswith("source/"):
                continue
            raw = archive.read(item["path"])
            actual = hashlib.sha256(raw).hexdigest().upper()
            if actual != item["sha256"].upper():
                raise ValueError("Parent archive source hash mismatch: " + item["path"])
            parent_sources.append({**item, "archive_entry_sha256_verified": True})
        parent_manifest_sha = hashlib.sha256(archive.read("manifest.json")).hexdigest().upper()
    parent_objects = {norm(k): v.upper() for k, v in manifest["retained_object_identities"].items()}
    docs, dep_pool, objects, roles = {}, {}, [], {}
    dependency_cache = {}
    pin_candidates = defaultdict(list)
    limitations = []
    source_variants = defaultdict(lambda: defaultdict(list))

    def document(path):
        p = Path(path)
        key = norm(p)
        if key not in docs:
            data = read_json(p)
            docs[key] = {"identity": identity(p), "data": data}
        return docs[key]

    for role, build, expected in (("app", T / "build-app", "7E463C83"), ("usb", T / "build-usb-r3", "067D89A2")):
        receipt_doc = document(build / "receipt.json")
        receipt = receipt_doc["data"]
        if receipt["crc32"] != expected:
            raise ValueError("Unexpected final CRC for " + role)
        linked = [Path(x).resolve() for x in re.findall(r'"([^"\r\n]+\.o)"', (build / "application.lnp").read_text())]
        retained = {norm(k): v.upper() for k, v in receipt["retained_objects"].items()}
        changed = {command_output(c): name for name, c in receipt["compiler_commands"].items()}
        counts = Counter()
        role_objects = []
        for index, obj in enumerate(linked):
            object_id = role + ":" + str(index)
            obj_key = norm(obj)
            actual_hash = sha(obj)
            kind = "directly_rebuilt" if obj_key in changed else "retained"
            if kind == "retained" and retained.get(obj_key) != actual_hash:
                raise ValueError("Retained object identity mismatch: " + str(obj))
            counts[kind] += 1
            row = {"id": object_id, "role": role, "kind": kind, **identity(obj),
                   "accepted_hash_evidence": str(build / "receipt.json") if kind == "retained" else None,
                   "parent_archive_object_identity_match": parent_objects.get(obj_key) == actual_hash}
            if row["parent_archive_object_identity_match"]:
                counts["parent_archive_object_identity_matches"] += 1
            # Search only adjacent, named build evidence, never whole histories.
            evidence = []
            for candidate in (obj.with_suffix(".compile.json"), obj.parent / "receipt.json", obj.parent / "incremental-build.json"):
                if not candidate.is_file():
                    continue
                doc = document(candidate)
                data = doc["data"]
                cache_key = data.get("key", {})
                command = cache_key.get("command") if isinstance(cache_key, dict) else None
                command_map = data.get("compiler_commands", {})
                commands = [command] if command else list(command_map.values()) if isinstance(command_map, dict) else []
                matching = [c for c in commands if isinstance(c, list) and command_output(c) == obj_key]
                pinned_object = data.get("object_sha256", "").upper() == actual_hash
                if not matching and not pinned_object:
                    continue
                if "object_sha256" in data and not pinned_object:
                    raise ValueError("Compile cache object hash mismatch: " + str(candidate))
                evidence.append({"document": str(candidate), "sha256": doc["identity"]["sha256"],
                                 "object_hash_matches": pinned_object, "command_output_matches": bool(matching)})
                for dep_key, digest, pointer in hash_maps(data):
                    pin_candidates[(object_id, dep_key)].append({"sha256": digest, "document": str(candidate), "json_pointer": pointer})
                if matching:
                    row.setdefault("compiler_commands", matching)
                if pinned_object:
                    row["accepted_hash_evidence"] = str(candidate)
            row["adjacent_compile_evidence"] = evidence
            dep_file = obj.with_suffix(".d")
            row["dependency_ids"] = []
            if dep_file.is_file():
                dep_key = norm(dep_file)
                if dep_key not in dependency_cache:
                    items, problem = dependencies(dep_file)
                    dependency_cache[dep_key] = (identity(dep_file), items, problem)
                dep_identity, items, problem = dependency_cache[dep_key]
                row["dependency_file"] = dep_identity
                if problem:
                    row["dependency_limit"] = problem
                    row["unresolved_dependency_paths"] = [str(p) for p in items]
                    counts["dependency_resolution_missing"] += 1
                else:
                    counts["dependency_file_available"] += 1
                    for dep in items:
                        key = norm(dep)
                        if key not in dep_pool:
                            dep_pool[key] = {"id": "dependency:" + str(len(dep_pool)), "path": str(dep),
                                             "logical_path": logical(dep), "exists": dep.is_file(),
                                             "toolchain_file": "/keil_v5/" in key, "usages": []}
                            if dep.is_file():
                                dep_pool[key].update({"bytes": dep.stat().st_size, "observed_sha256": sha(dep)})
                        entry = dep_pool[key]
                        current = entry.get("observed_sha256")
                        proofs = [x for x in pin_candidates[(object_id, key)] if x["sha256"] == current]
                        archived = parent_files.get(key)
                        archive_match = archived and archived["sha256"].upper() == current
                        usage = {"object_id": object_id, "role": role, "object_kind": kind,
                                 "build_pin_matches": proofs,
                                 "parent_exact_entry": archived["path"] if archive_match else None}
                        if proofs:
                            usage["source_status"] = "current_bytes_match_object_associated_build_pin"
                        elif archive_match:
                            usage["source_status"] = "exact_parent_archive_origin_and_hash_match"
                        else:
                            usage["source_status"] = "observed_dependency_only_not_build_time_proven"
                        entry["usages"].append(usage)
                        row["dependency_ids"].append(entry["id"])
                        if not entry["toolchain_file"]:
                            source_variants[(role, entry["logical_path"])][current or "MISSING"].append(entry["id"])
            else:
                row["dependency_limit"] = "retained_object_dependency_file_missing" if kind == "retained" else "rebuilt_object_dependency_file_missing"
                counts["dependency_file_missing"] += 1
            if kind == "directly_rebuilt" and not row["accepted_hash_evidence"]:
                limitations.append({"object_id": object_id, "gap": "No adjacent compile-cache object digest; final direct object hash is observed only."})
            if not evidence:
                counts["adjacent_compile_evidence_missing"] += 1
            objects.append(row)
            role_objects.append(object_id)
        roles[role] = {"crc32": expected, "body_sha256": receipt["body_sha256"],
                       "expected_app_crc32": receipt["expected_app_crc32"],
                       "build_receipt": receipt_doc["identity"], "linker_inputs": identity(build / "application.lnp"),
                       "scatter_file": identity(build / "application.sct"), "counts": dict(counts),
                       "objects": role_objects}

    dep_by_id = {d["id"]: d for d in dep_pool.values()}
    for row in objects:
        sources = []
        for dep_id in row["dependency_ids"]:
            dep = dep_by_id[dep_id]
            if Path(dep["path"]).suffix.casefold() not in (".c", ".s", ".asm", ".cpp", ".cxx"):
                continue
            usage = next(u for u in dep["usages"] if u["object_id"] == row["id"])
            sources.append({"dependency_id": dep_id, "source_status": usage["source_status"]})
        row["primary_source_dependencies"] = sources
        if not sources:
            row["primary_source_limit"] = "No resolved primary-source dependency evidence available."
        elif not any(s["source_status"] != "observed_dependency_only_not_build_time_proven" for s in sources):
            row["primary_source_limit"] = "Primary-source location/hash observed; no object-associated historical byte pin or exact accepted parent source entry found."
    variants = []
    for (role, name), hashes in sorted(source_variants.items()):
        if len(hashes) > 1:
            variants.append({"role": role, "logical_path": name,
                             "variants": [{"sha256": h, "dependency_ids": sorted(set(ids))} for h, ids in hashes.items()],
                             "resolution": "Preserve each object-bound variant; never flatten or replace retained source by a newer overlay."})
    overlay_selections = []
    for role in roles:
        used = {key: dep for key, dep in dep_pool.items() if any(u["role"] == role for u in dep["usages"])}
        for key, dep in sorted(used.items()):
            consumers = [u for u in dep["usages"] if u["role"] == role]
            local_overlay = key.startswith(norm(T / "Core") + "/") or key.startswith(norm(T / "usb/Core") + "/")
            archive_entries = sorted({u["parent_exact_entry"] for u in consumers if u["parent_exact_entry"]})
            if local_overlay or archive_entries:
                overlay_selections.append({"role": role, "logical_path": dep["logical_path"],
                                           "dependency_id": dep["id"], "path": dep["path"],
                                           "sha256": dep.get("observed_sha256"),
                                           "origin": "current_checked_overlay" if local_overlay else "exact_accepted_parent_archive_entry",
                                           "parent_archive_entries": archive_entries,
                                           "matching_build_pin_objects": [u["object_id"] for u in consumers if u["build_pin_matches"]],
                                           "suggested_archive_path": "roles/" + role + "/" + dep["logical_path"]})
    recipes = [identity(p) for p in (T / "build.py", T / "prepare.py", T / "integrate-source.py",
                                   T / "preimage-pins.json", T / "source-integration.json", Path(__file__)) if p.is_file()]
    parent_builds = []
    for path in (T / "build-usb/receipt.json", T / "build-usb-r2/receipt.json",
                 Path("C:/Frank/Code/XE_NP/_artifacts/v2_spi_selected_detectors_20261104/build-r7/receipt.json")):
        if path.is_file():
            data = read_json(path)
            parent_builds.append({**identity(path), "crc32": data.get("crc32"),
                                  "parent_crc32": data.get("parent_crc32"),
                                  "body_sha256": data.get("body_sha256"),
                                  "purpose": "Immediate incremental image lineage; referenced receipt only, no build tree copy."})
    used_docs = [{**v["identity"], "purpose": "Bounded adjacent object/compile provenance; reference only."} for _, v in sorted(docs.items())]
    dependency_rows = list(dep_pool.values())
    usage_statuses = Counter(u["source_status"] for d in dependency_rows for u in d["usages"])
    result = {
        "schema": 1, "status": "BOUNDED_INCREMENTAL_SOURCE_PROVENANCE_INVENTORY",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Final explicit linker object graphs only. No compilation, packaging, hardware or release acceptance performed.",
        "parent_closure": {**identity(PARENT), "manifest_sha256": parent_manifest_sha,
                           "manifest_status": manifest["status"], "usb_crc32": manifest["usb_crc32"],
                           "expected_app_crc32": manifest["expected_app_crc32"],
                           "published_ancestor_references": manifest.get("published_parent", {}),
                           "source_entries_verified": parent_sources, "limits": manifest.get("limits", [])},
        "roles": roles, "objects": objects, "dependencies": dependency_rows,
        "role_specific_checked_overlay_selections": overlay_selections,
        "duplicate_logical_path_variants": variants, "build_recipe_references": recipes,
        "incremental_parent_build_references": parent_builds,
        "object_provenance_document_references": used_docs,
        "summary": {"explicit_object_instances": len(objects), "distinct_objects": len({norm(x["path"]) for x in objects}),
                    "unique_dependency_files": len(dependency_cache), "unique_dependency_paths": len(dependency_rows),
                    "missing_dependency_paths": sum(not d["exists"] for d in dependency_rows),
                    "dependency_usage_statuses": dict(usage_statuses), "role_overlay_selections": len(overlay_selections),
                    "role_logical_paths_with_multiple_hashes": len(variants),
                    "retained_objects_without_pinned_primary_source": sum(x["kind"] == "retained" and "primary_source_limit" in x for x in objects)},
        "limitations": limitations + [
            "A .d file proves named dependencies, not their historical bytes. An observed current hash without an object-associated pin or exact parent archive origin/hash remains explicitly unproven.",
            "Current canonical files are inventoried only as observed dependency locations. They are never authorized substitutes for retained accepted source or object bytes.",
            "The accepted parent archive preserves a scoped prior USB overlay/evidence closure, not a complete clean APP or USB rebuild tree.",
            "Role and object-bound variants remain separate. Broad receipt source_pins can include unused files from the other role; only actual .d dependencies select overlays here.",
            "Implicit toolchain runtime/library resolution and original working directories for any relative .d entries are outside the explicit object graph.",
            "No device flash, option bytes, preferences, recording DATs, object payloads or whole build trees are copied into this inventory."
        ]
    }
    OUTPUT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"inventory": str(OUTPUT), "sha256": sha(OUTPUT), "summary": result["summary"],
                      "role_counts": {k: v["counts"] for k, v in roles.items()}}, indent=2))


if __name__ == "__main__":
    main()
