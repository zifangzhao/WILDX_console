"""Integrate only pinned shared APP sources; keep USB's isolated accepted graph."""
from pathlib import Path
import hashlib,json
T=Path(__file__).resolve().parent;R=Path('D:/Code/XE_NP_V2')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
pins=json.loads((T/'preimage-pins.json').read_text())
for rel,h in pins.items():assert sha(R/rel)==h,('Unrelated change: do not overwrite',rel)
new=R/'Core/Src/xe_np_np2_delete_journal.inc';assert not new.exists()
changed=[]
for rel in [*pins,'Core/Src/xe_np_np2_delete_journal.inc']:
 s=(T/rel).read_text()
 s=s.replace('"D:/Code/XE_NP_V2/Tools/V2SdLogger/SharedV1/np_ce64.h"','"../../Tools/V2SdLogger/SharedV1/np_ce64.h"')
 s=s.replace('"D:/Code/XE_NP_V2/Firmware/V1/Core/Inc/np_media_metadata.h"','"../../Firmware/V1/Core/Inc/np_media_metadata.h"')
 (R/rel).write_bytes(s.encode())
 changed.append(dict(path=rel,overlay_sha256=sha(T/rel),integrated_sha256=sha(R/rel)))
(T/'source-integration.json').write_text(json.dumps(dict(status='EXACT_PINNED_SHARED_SOURCE_INTEGRATION',changed=changed,usb='Accepted USB graph remains isolated; five changed sources retained with build receipts and release source freeze. No generic camera/SD/IRQ source graph overwritten.'),indent=2)+'\n')
print('Integrated five pinned shared APP/catalog source files; unrelated work preserved')
