"""Prepare isolated V2 source overlays; never build or access hardware."""
from pathlib import Path
import hashlib, json

O = Path(__file__).resolve().parent
R = Path('D:/Code/XE_NP_V2')
sha = lambda b: hashlib.sha256(b).hexdigest().upper()
pins = {}
def source(rel, expected):
    b = (R / rel).read_bytes()
    assert sha(b) == expected, (rel, sha(b), expected)
    pins[rel] = expected
    p = O / 'preimages' / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists(): assert p.read_bytes() == b
    else: p.write_bytes(b)
    return b.decode().replace('\r\n', '\n')
def once(s, old, new):
    assert s.count(old) == 1, old[:100]
    return s.replace(old, new)

s = source('Core/Src/xe_np_np2_dual_sd_catalog.c',
 'FE15B601D5FC34C88002279E1DFAA6C4488A9EE89F1044DE9845570F0D17CDD7')
s = s.replace('"../../Tools/V2SdLogger/SharedV1/np_ce64.h"',
 '"D:/Code/XE_NP_V2/Tools/V2SdLogger/SharedV1/np_ce64.h"')
s = s.replace('"../../Firmware/V1/Core/Inc/np_media_metadata.h"',
 '"D:/Code/XE_NP_V2/Firmware/V1/Core/Inc/np_media_metadata.h"')
s = once(s, 'int XE_NP_Np2DualSdCatalog_Bind(',
 '#include "xe_np_np2_delete_journal.inc"\n\nint XE_NP_Np2DualSdCatalog_Bind(')
s = once(s, 'memset(&catalog,0,sizeof(catalog));catalog.io=*io;catalog.bound=1U;',
 'memset(&catalog,0,sizeof(catalog));catalog.io=*io;catalog.bound=1U;\n'
 '#if XE_NP_NP2_SD_CATALOG_ENABLE\n'
 '    delete_journal.pending=delete_journal.residue=0U;delete_journal.target=UINT32_MAX;\n#endif')
s = once(s, 'write_sector(113U,zero) || write_sector(128U,zero) ||',
 'write_sector(113U,zero) ||\n#if XE_NP_NP2_SD_CATALOG_ENABLE\n'
 '       write_sector(114U,zero) || write_sector(115U,zero) || write_sector(116U,zero) ||\n#endif\n'
 '       write_sector(128U,zero) ||')
old = '''    if(read_sector(112U,sector_buffer))return -1;
    for(unsigned i=0U;i<512U;i++)if(sector_buffer[i]){'''
new = '''#if XE_NP_NP2_SD_CATALOG_ENABLE
    int delete_pending=delete_inspect();
    if(delete_pending<0)return -1;
    if(delete_pending){
        pending=delete_journal.target-128U;
        memcpy(journal_shadow,delete_journal.after,512U);
        catalog.journal_pending=1U;catalog.status|=XE_NP_NP2_CATALOG_RECOVERY;
    }else
#endif
    {
    if(read_sector(112U,sector_buffer))return -1;
    for(unsigned i=0U;i<512U;i++)if(sector_buffer[i]){'''
s = once(s, old, new)
s = once(s, '''    memset(&catalog.directory,0,sizeof(catalog.directory));
    for(uint32_t block=0U;block<NP_CE64_MAX_LOG_BLOCKS;block++){''',
 '''    }
    memset(&catalog.directory,0,sizeof(catalog.directory));
    for(uint32_t block=0U;block<NP_CE64_MAX_LOG_BLOCKS;block++){''')
s = once(s, '''    catalog.mounted=1U;*next_start_lba=catalog.directory.start;return 0;
}''', '''#if XE_NP_NP2_SD_CATALOG_ENABLE
    if(delete_journal.pending)catalog.status|=XE_NP_NP2_CATALOG_RECOVERY|XE_NP_NP2_CATALOG_RECOVERABLE;
#endif
    catalog.mounted=1U;*next_start_lba=catalog.directory.start;return 0;
}''')
assert s.count('if(!result && catalog.pending_empty)return 0;') == 2
s = s.replace('if(!result && catalog.pending_empty)return 0;',
 'if(!result && (catalog.pending_empty || delete_journal.pending))return 0;')
old = '''    NpCe64Directory trimmed={0};trimmed.block=catalog.last_block;trimmed.log=catalog.last_log;
    uint32_t index=catalog.last_index;
    trimmed.log.count=index;trimmed.log.end[index]=0U;trimmed.log.event_end[index]=0U;
    if(!index)memset(&trimmed.log,0,sizeof(trimmed.log));
    catalog.mounted=0U;snapshot_valid=0U;
    /* Existing readback-verified metadata journal only. Descriptor/footer and
     * payload are retained; no stopped CMD20, erase, or automatic retry. */
    if(np_ce64_publish(&trimmed,write_sector))return 10;'''
new = '''    catalog.mounted=0U;snapshot_valid=0U;
    /* Exact immutable images and mirrored same-card redo intent precede the
     * legacy journal/directory mutation. No erase, payload copy or retry. */
    if(delete_publish(r))return 10;'''
s = once(s, old, new)
s = once(s, '''    if(XE_NP_Np2DualSdCatalog_Mount(next_start_lba))return -1;
    if(!(catalog.status&XE_NP_NP2_CATALOG_RECOVERY))return 0;''',
 '''    if(XE_NP_Np2DualSdCatalog_Mount(next_start_lba))return -1;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    if(delete_journal.pending){
        if(delete_redo())return -1;
        return XE_NP_Np2DualSdCatalog_Mount(next_start_lba);
    }
    /* Non-authoritative orphan fragments need no directory rollback. Explicit
     * Recover may clear only the owned extension intents after a valid mount. */
    if(delete_journal.residue && delete_clear())return -1;
#endif
    if(!(catalog.status&XE_NP_NP2_CATALOG_RECOVERY))return 0;''')
p = O / 'Core/Src/xe_np_np2_dual_sd_catalog.c'
p.write_text(s, newline='\n')
h = (R / 'Core/Inc/xe_np_np2_dual_sd_catalog.h').read_bytes()
pins['Core/Inc/xe_np_np2_dual_sd_catalog.h'] = sha(h)
q = O/'preimages/Core/Inc/xe_np_np2_dual_sd_catalog.h'; q.parent.mkdir(parents=True,exist_ok=True)
if q.exists(): assert q.read_bytes()==h
else: q.write_bytes(h)
s = h.decode().replace('\r\n','\n')
s = once(s, 'int XE_NP_Np2DualSdCatalog_CheckDelete(',
 '''/* Stopped startup/admission only. No general quarantine or writes from
 * read-only Mount/Info. Absent a new authenticated intent is a no-op. */
int XE_NP_Np2DualSdCatalog_ReconcileDelete(uint32_t *next_start_lba);
/* Exact verified target for the automatic metadata IO whitelist, else MAX. */
uint32_t XE_NP_Np2DualSdCatalog_DeleteTarget(void);
int XE_NP_Np2DualSdCatalog_CheckDelete(''')
p = O/'Core/Inc/xe_np_np2_dual_sd_catalog.h';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,newline='\n')
(O/'preimage-pins.json').write_text(json.dumps(pins,indent=2)+'\n')

s = source('Core/Src/xe_np_np2_dual_sd_catalog_port.c',
 'DF87D15ECFAD6444DFB2509581A945324B791A6F37D17C8C166FE8D490A17E94')
s = once(s, '''int XE_NP_Np2DualSdCatalogPort_MountAvailable(uint32_t *next_start_lba)
{
    if(enter())return -1;
    int result=XE_NP_Np2DualSdCatalog_MountAvailable(next_start_lba);''',
 '''int XE_NP_Np2DualSdCatalogPort_MountAvailable(uint32_t *next_start_lba)
{
    if(enter())return -1;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    /* Stopped startup/Start admission only; Info and read-only Mount do not
     * write. Never general Recover/quarantine an unauthenticated catalog. */
    int result=XE_NP_Np2DualSdCatalog_ReconcileDelete(next_start_lba);
    if(!result)result=XE_NP_Np2DualSdCatalog_MountAvailable(next_start_lba);
#else
    int result=XE_NP_Np2DualSdCatalog_MountAvailable(next_start_lba);
#endif''')
(O/'Core/Src/xe_np_np2_dual_sd_catalog_port.c').write_text(s,newline='\n')
s = source('Core/Src/xe_np_np2_dual_sd_app.c',
 'EE86516F89B0845C0320CC31A2AFA028A0712A2FEF80C6C38BA76E9193F6E06A')
s = once(s, '''    uint32_t session=HAL_GetTick()^card->CID[0]^card->CID[3]^nonce;''',
 '''#if XE_NP_NP2_SD_CATALOG_ENABLE
    /* A same-boot interrupted delete can follow Init. Reconcile once before
     * every new allocation, never in the recording service path. */
    uint32_t reconciled_next=0U;
    if(XE_NP_Np2DualSdCatalogPort_MountAvailable(&reconciled_next))return -1;
    xe_np_np2_dual_sd_app_mailbox.next_start_lba=reconciled_next;
#endif
    uint32_t session=HAL_GetTick()^card->CID[0]^card->CID[3]^nonce;''')
(O/'Core/Src/xe_np_np2_dual_sd_app.c').write_text(s,newline='\n')
(O/'preimage-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
print('Prepared catalog/API overlays; canonical source unchanged')
