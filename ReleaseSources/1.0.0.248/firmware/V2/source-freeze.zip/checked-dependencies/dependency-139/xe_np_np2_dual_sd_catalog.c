#include "xe_np_np2_sd_fine_clock.h"
#if NP_FINE_COUNTER64_ENABLE
#include "np_rtc_start_wire.h"
#endif
#include "xe_np_np2_dual_sd_catalog.h"
#include "xe_np_sd_record_plan.h"
#include "D:/Code/XE_NP_V2/Tools/V2SdLogger/SharedV1/np_ce64.h"
#include "D:/Code/XE_NP_V2/Firmware/V1/Core/Inc/np_media_metadata.h"
#include <string.h>
#include "xe_np_np2_closed_loop_sd.h"
#include "xe_np_np2_grid16_meta.h"
#if XE_NP_NP2_SD_GRID16_ENABLE
#include "xe_np_np2_usb_wire.h"
#endif

static struct {
    XE_NP_Np2DualSdCatalogIo io;
    NpCe64Directory directory;
    XE_NP_Np2DualSdMeta meta;
    uint8_t bound,mounted,reserved,shared_media;
#if XE_NP_NP2_SD_GRID16_ENABLE
    XE_NP_Grid16Meta grid16;
    uint8_t reserved_grid16;
#endif
#if NP_FINE_COUNTER64_ENABLE
    uint8_t optional_metadata_ready;
#endif
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    const XE_NP_Np2ClCarrier *cl_carrier; /* Explicit caller lifetime through Stop. */
    uint32_t cl_crc,cl_generation;
    uint8_t cl_base;
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    uint8_t reserved_append;
#endif
    uint8_t scan_valid,repair_pending,journal_pending;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    uint8_t pending_empty;
#endif
    uint32_t status,last_block,last_index,last_start,sealed_end,quarantine_end;
    NpCe64SysLog last_log;
} catalog;
static uint8_t sector_buffer[512],verify_buffer[512],journal_shadow[512];
#if XE_NP_NP2_SD_CATALOG_ENABLE
static XE_NP_Np2DualSdCatalogInfo snapshot;
static uint32_t snapshot_tail_lba,snapshot_tail_crc;
static uint8_t snapshot_valid;
#endif
/* Stopped-only evidence, copied only after sector readback matches. */
uint8_t xe_np_np2_dual_sd_last_footer[512],xe_np_np2_dual_sd_last_time[512];

static int decode_descriptor(const uint8_t in[512],XE_NP_Np2DualSdMeta *out)
{
#if XE_NP_NP2_SD_GRID16_ENABLE
    if(np_get32(in+8U)==16U){
        XE_NP_Grid16Meta m;XE_NP_Np2DualSdMeta d={0};
        if(!out || XE_NP_Grid16_DecodeDescriptor(in,&m))return -1;
        d.session_id=m.session;d.config_crc=m.config_crc;d.card_blocks=m.card_blocks;
        d.reservation_start_lba=m.reservation_start;d.reservation_end_lba=m.reservation_end;
        memcpy(d.cid,m.cid,sizeof(d.cid));
        d.au_blocks=m.base==12U?m.au:0U;d.legacy_au_blocks=m.base==13U?m.au:0U;
        d.run.probe_mask=m.mask;d.run.sample_hz=m.sample_hz;d.run.mclk_hz=m.sample_hz*1600U;
        d.run.payload_start_lba=m.payload_start;d.run.payload_end_lba=m.payload_end;
        d.run.max_rus=m.max_groups;d.run.max_blocks=m.max_groups*4U;
        d.run.max_source_ticks=(uint64_t)d.run.max_blocks*XE_NP_Np2DualSd_ProfileTicks(m.mask,m.sample_hz);
        d.run.max_duration_ms=d.run.max_source_ticks*1000U/d.run.mclk_hz;
        *out=d;return 0;
    }
#endif
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    if(np_get32(in+8U)==XE_NP_NP2_CL_SD_VERSION){
        uint32_t base,crc;return XE_NP_Np2ClSd_DecodeDescriptor(in,out,&base,&crc);
    }
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    if(np_get32(in+8U)==XE_NP_NP2_SD_APPEND_VERSION)
        return XE_NP_Np2SdAppend_DecodeDescriptor(in,out);
#endif
    return XE_NP_Np2DualSd_DecodeDescriptor(in,out);
}
static int decode_footer(const uint8_t descriptor[512],const uint8_t footer[512],
                         uint32_t *state,uint32_t *error,uint32_t *physical_blocks)
{
#if XE_NP_NP2_SD_GRID16_ENABLE
    if(np_get32(descriptor+8U)==16U){
        XE_NP_Grid16Footer f;int grid_quality,cl_quality;
        if(!state || !error || !physical_blocks ||
           XE_NP_Grid16_DecodeFooter(descriptor,footer,&f,&grid_quality,&cl_quality))return -1;
        /* Optional grid/CL qualification is independent of intact NN metadata. */
        *state=f.state;*error=f.error;*physical_blocks=f.np_blocks;return 0;
    }
#endif
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    if(np_get32(descriptor+8U)==XE_NP_NP2_CL_SD_VERSION){
        XE_NP_Np2SdAppendCounts counts;XE_NP_Np2ClCarrierStatus summary;int unknown;
        if(XE_NP_Np2ClSd_DecodeFooter(descriptor,footer,0,state,error,&counts,&summary,&unknown))return -1;
        *physical_blocks=counts.physical_blocks;return 0;
    }
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    if(np_get32(descriptor+8U)==XE_NP_NP2_SD_APPEND_VERSION){
        XE_NP_Np2SdAppendCounts counts;
        if(XE_NP_Np2SdAppend_DecodeFooter(descriptor,footer,state,error,&counts))return -1;
        *physical_blocks=counts.physical_blocks;return 0;
    }
#endif
    return XE_NP_Np2DualSd_DecodeFooter(descriptor,footer,state,error,physical_blocks);
}
static int is_grid16(const uint8_t descriptor[512])
{
#if XE_NP_NP2_SD_GRID16_ENABLE
    return np_get32(descriptor+8U)==16U;
#else
    (void)descriptor;return 0;
#endif
}
/* Only use after the descriptor has passed the strict SD16 decoder. */
static int is_grid16_append(const uint8_t descriptor[512])
{
#if XE_NP_NP2_SD_GRID16_ENABLE
    return is_grid16(descriptor) && np_get32(descriptor+216U)==3U;
#else
    (void)descriptor;return 0;
#endif
}
/* Called only after strict descriptor/footer decoding. */
static uint32_t confirmed_end(const uint8_t descriptor[512],const uint8_t footer[512],
                              const XE_NP_Np2DualSdMeta *m,uint32_t blocks)
{
#if XE_NP_NP2_SD_GRID16_ENABLE
    if(np_get32(descriptor+8U)==16U)return np_get32(footer+116U);
#else
    (void)descriptor;(void)footer;
#endif
    return m->run.payload_start_lba+blocks*XE_NP_NP2_DUAL_SD_SECTORS_PER_BLOCK;
}

static int read_sector(uint32_t lba,uint8_t *out)
{
    return catalog.bound && lba<catalog.io.card_blocks && out &&
        catalog.io.read_sector(catalog.io.user,lba,out)==0?0:-1;
}
static int write_sector(uint32_t lba,const uint8_t *in)
{
#if XE_NP_NP2_SD_CATALOG_ENABLE
    snapshot_valid=0U;
#endif
    if(!catalog.bound || !in || lba>=catalog.io.card_blocks ||
       catalog.io.write_sector(catalog.io.user,lba,in) ||
       read_sector(lba,verify_buffer) || memcmp(in,verify_buffer,512U))return -1;
    return 0;
}
static int clear_old_slots(void)
{
    for(uint32_t slot=0U;slot<8U;slot++)
        if(catalog.io.stopped_command(catalog.io.user,0x88000000U|(slot<<24U)))return -1;
    return 0;
}

/* The canonical V1 common v8 header has no CID/capacity field. Admit only
 * its finalized dedicated 50-Hz/200-kHz form, with the whole-card bound and
 * exact published end; this is metadata/append safety, not payload validation.
 * Unknown/incomplete foreign tails never enter neural recovery/quarantine. */
static int finalized_media_tail(const uint8_t h[512],const uint8_t f[512],
                                uint32_t start,uint32_t end,uint32_t event_end)
{
    if(memcmp(h,"NPSDLOG1",8U) || memcmp(f,"NPSDEND1",8U) ||
       np_get32(h+8U)!=8U || np_get32(f+8U)!=8U ||
       np_get32(h+508U)!=XE_NP_Np2DualSd_Crc32(h,508U) ||
       np_get32(f+508U)!=XE_NP_Np2DualSd_Crc32(f,508U) ||
       !np_get32(h+12U) || memcmp(h+12U,f+12U,40U) ||
       np_get32(h+16U) || np_get32(h+20U)!=1U || np_get32(h+24U) || np_get32(h+28U) ||
       np_get32(h+32U)!=15360U || np_get32(h+36U)!=128U ||
       np_get32(h+40U)!=start || np_get32(h+44U)!=(catalog.io.card_blocks&~1023U) ||
       np_get32(h+60U)!=1U || np_get32(h+64U) || np_get32(h+68U) ||
       np_get32(f+60U)!=3U || np_get32(f+64U) || end!=event_end)return -1;
    for(unsigned n=0U;n<2U;n++){
        const uint8_t *b=n?f:h;
        if(np_get32(b+52U) || np_get32(b+56U) || np_get32(b+80U)!=2U ||
           np_get32(b+88U) || np_get32(b+92U) || np_get32(b+96U)!=61632U ||
           np_get32(b+100U) || np_get32(b+104U) || np_get32(b+108U) ||
           np_get32(b+112U)!=50U || np_get32(b+116U)!=200000U ||
           np_get32(b+120U)!=1U || np_get32(b+124U) ||
           memcmp(b+128U,"NPMEDX1",8U) || np_get32(b+136U)!=NP_MEDIA_METADATA_VERSION ||
           (np_get32(b+140U)&~31U) || (np_get32(b+140U)&24U)!=24U ||
           ((np_get32(b+140U)&NP_MEDIA_META_FOOTER)!=0U)!=(n!=0U) ||
           np_get32(b+168U)!=50U || np_get32(b+220U)!=200000U ||
           np_get32(b+196U) || np_get32(b+200U) || np_get32(b+204U) ||
           np_get32(b+212U) || np_get32(b+216U) || np_get32(b+244U) || np_get32(b+248U))return -1;
    }
    uint32_t header=8192U+((0U-(start+8192U))&16383U),chunks=np_get32(f+68U);
    uint64_t committed=(uint64_t)start+header+(uint64_t)chunks*128U;
    uint32_t frames=np_get32(f+176U);
    if(start<8192U || start%8192U || np_get32(h+48U)!=header || !chunks || chunks%8U ||
       committed!=end || committed>np_get32(h+44U) || !frames ||
       np_get32(f+172U)!=frames || np_get32(f+184U)-np_get32(f+180U)+1U!=frames ||
       !(np_get32(f+236U)|np_get32(f+240U)) || memcmp(f+228U,f+236U,8U))return -1;
    return 0;
}

#include "xe_np_np2_delete_journal.inc"

int XE_NP_Np2DualSdCatalog_Bind(const XE_NP_Np2DualSdCatalogIo *io)
{
#if XE_NP_NP2_SD_CATALOG_ENABLE
    snapshot_valid=0U;
#endif
    if(!io || !io->read_sector || !io->write_sector || !io->stopped_command ||
       io->card_blocks<32768U)return -1;
    memset(&catalog,0,sizeof(catalog));catalog.io=*io;catalog.bound=1U;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    delete_journal.pending=delete_journal.residue=0U;delete_journal.target=UINT32_MAX;
#endif
    return 0;
}

int XE_NP_Np2DualSdCatalog_Format(uint32_t key,const uint8_t system_sector[512])
{
#if NP_FINE_COUNTER64_ENABLE
    catalog.optional_metadata_ready=0U;
#endif
    if(!catalog.bound || catalog.reserved || key!=XE_NP_NP2_DUAL_SD_FORMAT_KEY ||
       !system_sector || clear_old_slots())return -1;
    catalog.mounted=0U;
    uint8_t zero[512]={0};
    /* Identity last: an interrupted format cannot advertise a ready v11 card
     * before the directory, system sector and journal have been reset. */
    if(write_sector(16U,zero) || write_sector(112U,zero) ||
       write_sector(113U,zero) ||
#if XE_NP_NP2_SD_CATALOG_ENABLE
       write_sector(114U,zero) || write_sector(115U,zero) || write_sector(116U,zero) ||
#endif
       write_sector(128U,zero) ||
       write_sector(17U,system_sector) || write_sector(18U,zero) ||
       write_sector(19U,zero))return -1;
    memcpy(zero,"CE_FILESYSTEM_V1",16U);
    memcpy(zero+32U,XE_NP_NP2_DUAL_SD_CARD_IDENT,9U);
    if(write_sector(16U,zero))return -1;
    catalog.mounted=0U;return 0;
}

int XE_NP_Np2DualSdCatalog_Mount(uint32_t *next_start_lba)
{
#if XE_NP_NP2_SD_CATALOG_ENABLE
    snapshot_valid=0U;
#endif
    if(!catalog.bound || catalog.reserved || !next_start_lba)return -1;
    catalog.mounted=0U;catalog.shared_media=0U;catalog.status=0U;catalog.sealed_end=0U;catalog.quarantine_end=0U;
    catalog.scan_valid=catalog.repair_pending=catalog.journal_pending=0U;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    catalog.pending_empty=0U;catalog.last_block=catalog.last_index=catalog.last_start=0U;
    memset(&catalog.last_log,0,sizeof(catalog.last_log));
#endif
    uint32_t pending=UINT32_MAX,previous=8192U,have_last=0U;
    if(read_sector(16U,sector_buffer) || memcmp(sector_buffer,"CE_FILESYSTEM_V1",16U) ||
       (memcmp(sector_buffer+32U,XE_NP_NP2_DUAL_SD_CARD_IDENT,9U) &&
        memcmp(sector_buffer+32U,"NP_PSSI_6",9U) &&
        memcmp(sector_buffer+32U,"NP_CE64_1",9U)))return -1;
    catalog.shared_media=(uint8_t)!memcmp(sector_buffer+32U,"NP_CE64_1",9U);
#if XE_NP_NP2_SD_CATALOG_ENABLE
    int delete_pending=delete_inspect();
    if(delete_pending<0)return -1;
    if(delete_pending){
        pending=delete_journal.target-128U;
        memcpy(journal_shadow,delete_journal.after,512U);
        catalog.journal_pending=1U;catalog.status|=XE_NP_NP2_CATALOG_RECOVERY;
    }else
#endif
    {
    if(read_sector(112U,sector_buffer))return -1;
    for(unsigned i=0U;i<512U;i++)if(sector_buffer[i]){
        uint32_t target=np_get32(sector_buffer+8U);
        if(memcmp(sector_buffer,"NPC64TX1",8U) || target<128U || target>=1152U ||
           np_get32(sector_buffer+508U)!=XE_NP_Np2DualSd_Crc32(sector_buffer,508U) ||
           read_sector(113U,journal_shadow) ||
           np_get32(sector_buffer+12U)!=XE_NP_Np2DualSd_Crc32(journal_shadow,512U))return -1;
        pending=target-128U;catalog.journal_pending=1U;catalog.status|=XE_NP_NP2_CATALOG_RECOVERY;break;
    }
    }
    memset(&catalog.directory,0,sizeof(catalog.directory));
    for(uint32_t block=0U;block<NP_CE64_MAX_LOG_BLOCKS;block++){
        NpCe64Directory *d=&catalog.directory;d->block=block;
        if(block==pending)memcpy(&d->log,journal_shadow,512U);
        else if(read_sector(128U+block,(uint8_t *)&d->log))return -1;
        if(np_ce64_valid_log(&d->log,previous,catalog.io.card_blocks))return -1;
        for(uint32_t i=0U;i<d->log.count;i++){
            catalog.last_start=(previous+8191U)&~8191U;
            previous=d->log.end[i];catalog.last_index=i;catalog.last_block=block;
            have_last=1U;
        }
        if(d->log.count)catalog.last_log=d->log;
        if(previous>UINT32_MAX-8191U)return -1;
        d->start=(previous+8191U)&~8191U;d->index=d->log.count;
        if(d->index<63U || block==NP_CE64_MAX_LOG_BLOCKS-1U)break;
    }
#if XE_NP_NP2_SD_CATALOG_ENABLE
    /* A sole-entry/page deletion may journal only a canonical zero page. */
    if(pending==catalog.directory.block && !catalog.directory.log.count){
        for(unsigned i=0U;i<512U;i++)if(journal_shadow[i])return -1;
        catalog.pending_empty=1U;catalog.status&=~XE_NP_NP2_CATALOG_RECOVERY;
    }else
#endif
    /* A journal outside the traversed directory is not a repair candidate. */
    if(pending!=UINT32_MAX && (!have_last || pending!=catalog.last_block))return -1;
    uint32_t tail_pending=pending!=UINT32_MAX;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    tail_pending=tail_pending && !catalog.pending_empty;
#endif
    catalog.scan_valid=1U;
    if(have_last){
        uint8_t descriptor[512],footer[512];XE_NP_Np2DualSdMeta meta;
        uint32_t state,error,blocks;
        if(read_sector(catalog.last_start+3U,descriptor) ||
           read_sector(catalog.last_start+4U,footer))return -1;
        if(!memcmp(descriptor,"NPSDLOG1",8U)){
            if(!catalog.shared_media || tail_pending || finalized_media_tail(descriptor,footer,catalog.last_start,
                previous,catalog.last_log.event_end[catalog.last_index]))
                catalog.status|=XE_NP_NP2_CATALOG_RECOVERY;
        }else if(decode_descriptor(descriptor,&meta) ||
           meta.reservation_start_lba!=catalog.last_start || meta.card_blocks!=catalog.io.card_blocks ||
           memcmp(meta.cid,catalog.io.cid,sizeof(meta.cid)) ||
           decode_footer(descriptor,footer,&state,&error,&blocks)){
            catalog.status|=XE_NP_NP2_CATALOG_RECOVERY;
        }else if(!is_grid16(descriptor) && state==XE_NP_NP2_DUAL_SD_META_FAILED &&
                 error==XE_NP_NP2_DUAL_SD_META_CANCELLED_EMPTY && !blocks){
            /* A retained metadata-only cancellation, not a dropped recording.
             * The producer never armed; only its original header must survive. */
            catalog.sealed_end=meta.run.payload_start_lba;
            if(catalog.last_log.event_end[catalog.last_index]!=previous ||
               (previous!=catalog.sealed_end && previous!=meta.reservation_end_lba))
                catalog.status|=XE_NP_NP2_CATALOG_RECOVERY;
            else if(previous!=catalog.sealed_end || tail_pending)
                catalog.status|=XE_NP_NP2_CATALOG_RECOVERY|XE_NP_NP2_CATALOG_RECOVERABLE;
        }else if(is_grid16_append(descriptor) && state==XE_NP_NP2_DUAL_SD_META_FAILED){
            /* Schema 3 seals a card-confirmed physical prefix, not the
             * logical high-water or the whole allocation. No payload scan. */
            catalog.sealed_end=confirmed_end(descriptor,footer,&meta,blocks);
            if(catalog.last_log.event_end[catalog.last_index]!=previous ||
               (previous!=meta.run.payload_start_lba && previous!=meta.reservation_end_lba &&
                previous!=catalog.sealed_end))catalog.status|=XE_NP_NP2_CATALOG_RECOVERY;
            else if(previous!=catalog.sealed_end || tail_pending)
                catalog.status|=XE_NP_NP2_CATALOG_RECOVERY|XE_NP_NP2_CATALOG_RECOVERABLE;
        }else if(state==XE_NP_NP2_DUAL_SD_META_RESERVED ||
                 state==XE_NP_NP2_DUAL_SD_META_FAILED){
            /* FAILED may contain completed OOO writes beyond its sealed
             * contiguous prefix. Neither incomplete state frees that tail.
             * Recognize only the original payload fence, a legacy exact FAILED
             * prefix, or the complete allocation; ambiguous bounds stay closed.
             * Mount is read-only; Recover publishes only the validated fence,
             * without changing the incomplete footer or its sample count. */
            uint32_t committed_end=confirmed_end(descriptor,footer,&meta,blocks);
            if(catalog.last_log.event_end[catalog.last_index]!=previous ||
               (previous!=meta.run.payload_start_lba && previous!=meta.reservation_end_lba &&
                !(state==XE_NP_NP2_DUAL_SD_META_FAILED && previous==committed_end))){
                catalog.status|=XE_NP_NP2_CATALOG_RECOVERY;
            }else if(previous!=meta.reservation_end_lba || tail_pending){
                catalog.quarantine_end=meta.reservation_end_lba;
                catalog.status|=XE_NP_NP2_CATALOG_RECOVERY|XE_NP_NP2_CATALOG_QUARANTINABLE;
            }
        }else{
            catalog.sealed_end=confirmed_end(descriptor,footer,&meta,blocks);
            if(catalog.sealed_end!=previous)catalog.status|=XE_NP_NP2_CATALOG_RECOVERY;
            if(catalog.status&XE_NP_NP2_CATALOG_RECOVERY)catalog.status|=XE_NP_NP2_CATALOG_RECOVERABLE;
        }
    }else if(tail_pending)return -1;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    if(catalog.pending_empty){
        /* Replay the empty page only when its retained prefix is valid. */
        catalog.status=catalog.status?XE_NP_NP2_CATALOG_RECOVERY:
            XE_NP_NP2_CATALOG_RECOVERY|XE_NP_NP2_CATALOG_RECOVERABLE;
    }
#endif
    uint64_t payload=((uint64_t)catalog.directory.start+8192U+16383U)&~UINT64_C(16383);
    uint64_t end=catalog.io.card_blocks&~UINT64_C(16383);
    if(payload+XE_NP_NP2_DUAL_SD_SECTORS_PER_RU>end || catalog.directory.index>=63U)
        catalog.status|=XE_NP_NP2_CATALOG_FULL;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    if(delete_journal.pending)catalog.status|=XE_NP_NP2_CATALOG_RECOVERY|XE_NP_NP2_CATALOG_RECOVERABLE;
#endif
    catalog.mounted=1U;*next_start_lba=catalog.directory.start;return 0;
}
uint32_t XE_NP_Np2DualSdCatalog_Status(void){return catalog.status;}
#if XE_NP_NP2_SD_CATALOG_ENABLE
uint32_t XE_NP_Np2DualSdCatalog_Reserved(void){return catalog.reserved;}

static uint32_t words_crc(const uint32_t words[15])
{
    uint8_t bytes[60];
    for(unsigned i=0U;i<15U;i++)np_put32(bytes+4U*i,words[i]);
    return XE_NP_Np2DualSd_Crc32(bytes,sizeof(bytes));
}
static int catalog_log(uint32_t block,uint8_t out[512])
{
    if(read_sector(128U+block,out))return 10;
    /* Read the same logical prefix/allocation staged by MountAvailable.
     * A rewind offer must never resurrect its discarded last_log suffix. */
    if(block==catalog.directory.block && (catalog.pending_empty ||
       (catalog.status&(XE_NP_NP2_CATALOG_DEGRADED|XE_NP_NP2_CATALOG_RECOVERY))))
        memcpy(out,&catalog.directory.log,512U);
    else if(block==catalog.last_block &&
            (catalog.status&(XE_NP_NP2_CATALOG_DEGRADED|XE_NP_NP2_CATALOG_RECOVERY)) &&
            !(catalog.status&XE_NP_NP2_CATALOG_REWIND_AVAILABLE))
        memcpy(out,&catalog.last_log,512U);
    return 0;
}
static int catalog_entry(uint32_t ordinal,XE_NP_Np2DualSdCatalogEntry *out)
{
    NpCe64SysLog log;
    uint32_t block=ordinal/63U,index=ordinal%63U,previous=8192U;
    if(catalog_log(block,(uint8_t *)&log))return 10;
    if(block){
        NpCe64SysLog before;
        if(read_sector(127U+block,(uint8_t *)&before))return 10;
        if(before.count!=63U)return 8;
        previous=before.end[62];
    }
    if(np_ce64_valid_log(&log,previous,catalog.io.card_blocks) || index>=log.count)return 8;
    if(index)previous=log.end[index-1U];
    if(previous>UINT32_MAX-8191U)return 8;
    uint32_t start=(previous+8191U)&~8191U,end=log.end[index];
    if(start<8192U || end<=(uint64_t)start+4U || end>catalog.io.card_blocks)return 8;
    uint8_t descriptor[512],footer[512];
    if(read_sector(start+3U,descriptor) || read_sector(start+4U,footer))return 10;
    XE_NP_Np2DualSdCatalogEntry e={0};
    e.ordinal=ordinal;e.start=start;e.end=end;
    /* Exclude the embedded checksum at508: CRC over a sealed512-byte sector
     * is a constant residue and cannot fingerprint re-sealed metadata. */
    uint32_t cookie[15]={0x4543324EU,catalog.io.card_blocks,
        catalog.io.cid[0],catalog.io.cid[1],catalog.io.cid[2],catalog.io.cid[3],
        ordinal,start,end,log.event_end[index],XE_NP_Np2DualSd_Crc32(descriptor,508U),
        XE_NP_Np2DualSd_Crc32(footer,508U),np_get32(descriptor+8U),np_get32(footer+8U),0U};
    e.cookie=words_crc(cookie);
    XE_NP_Np2DualSdMeta meta;uint32_t state,error,blocks;
    if(!decode_descriptor(descriptor,&meta) &&
       meta.reservation_start_lba==start && meta.card_blocks==catalog.io.card_blocks &&
       !memcmp(meta.cid,catalog.io.cid,sizeof(meta.cid)) &&
       !decode_footer(descriptor,footer,&state,&error,&blocks)){
        uint32_t prefix=confirmed_end(descriptor,footer,&meta,blocks);
        int bounds=log.event_end[index]==end &&
            (state==XE_NP_NP2_DUAL_SD_META_COMPLETE?end==prefix:
             end==meta.reservation_end_lba || end==meta.run.payload_start_lba ||
             (state==XE_NP_NP2_DUAL_SD_META_FAILED && end==prefix));
        if(bounds){
            e.session=meta.session_id;e.sample_hz=meta.run.sample_hz;e.probe_mask=meta.run.probe_mask;
            e.flags=np_get32(descriptor+8U)|(state<<8U)|XE_NP_NP2_CATALOG_METADATA_VALID;
            if(state!=XE_NP_NP2_DUAL_SD_META_COMPLETE)e.flags|=XE_NP_NP2_CATALOG_INCOMPLETE;
        }
    }else if(catalog.shared_media && !finalized_media_tail(descriptor,footer,start,end,log.event_end[index])){
        e.session=np_get32(descriptor+12U);
        e.flags=8U|(3U<<8U)|XE_NP_NP2_CATALOG_METADATA_VALID;
    }
    *out=e;return 0;
}
int XE_NP_Np2DualSdCatalog_Info(XE_NP_Np2DualSdCatalogInfo *out)
{
    if(!out || !catalog.bound || catalog.reserved)return 8;
    uint32_t next;
    if(XE_NP_Np2DualSdCatalog_MountAvailable(&next) || !next){
        catalog.status|=XE_NP_NP2_CATALOG_RECOVERY;return 10;
    }
    XE_NP_Np2DualSdCatalogInfo info={0};
    info.count=catalog.directory.block*63U+catalog.directory.log.count;
    info.next=next;info.card_blocks=catalog.io.card_blocks;info.flags=catalog.status;
    uint8_t cid[16];
    for(unsigned i=0U;i<4U;i++)np_put32(cid+4U*i,catalog.io.cid[i]);
    info.cid_crc=XE_NP_Np2DualSd_Crc32(cid,sizeof(cid));info.last_ordinal=UINT32_MAX;
    snapshot_tail_lba=128U;
    if(info.count){
        XE_NP_Np2DualSdCatalogEntry last;
        int result=catalog_entry(info.count-1U,&last);if(result)return result;
        info.last_ordinal=last.ordinal;info.last_start=last.start;
        info.last_end=last.end;info.last_cookie=last.cookie;
        if(last.end>UINT32_MAX-8191U || next!=((last.end+8191U)&~8191U))return 8;
        snapshot_tail_lba=128U+(info.count-1U)/63U;
        if(catalog_log(snapshot_tail_lba-128U,sector_buffer))return 10;
    }else{
        if(next!=8192U)return 8;
        memcpy(sector_buffer,&catalog.directory.log,512U);
    }
    uint32_t logical_tail_crc=XE_NP_Np2DualSd_Crc32(sector_buffer,512U);
    /* Snapshot raw freshness separately from the read-only logical overlay. */
    if(read_sector(snapshot_tail_lba,sector_buffer))return 10;
    snapshot_tail_crc=XE_NP_Np2DualSd_Crc32(sector_buffer,512U);
    uint32_t words[15]={0x5343324EU,catalog.io.card_blocks,
        catalog.io.cid[0],catalog.io.cid[1],catalog.io.cid[2],catalog.io.cid[3],
        info.count,next,snapshot_tail_lba,logical_tail_crc,info.last_ordinal,
        info.last_start,info.last_end,info.last_cookie,info.flags};
    info.token=words_crc(words);snapshot=info;snapshot_valid=1U;*out=info;return 0;
}
int XE_NP_Np2DualSdCatalog_Entry(uint32_t token,uint32_t count,uint32_t ordinal,
                                XE_NP_Np2DualSdCatalogEntry *out)
{
    if(!out || !catalog.mounted || catalog.reserved)return 8;
    if(!snapshot_valid || token!=snapshot.token || count!=snapshot.count)return 9;
    if(ordinal>=count)return 3;
    if(read_sector(snapshot_tail_lba,sector_buffer))return 10;
    if(XE_NP_Np2DualSd_Crc32(sector_buffer,512U)!=snapshot_tail_crc){snapshot_valid=0U;return 9;}
    XE_NP_Np2DualSdCatalogEntry e;
    int result=catalog_entry(ordinal,&e);if(result)return result;
    e.token=token;e.count=count;
    if(ordinal==count-1U){
        if(e.start!=snapshot.last_start || e.end!=snapshot.last_end || e.cookie!=snapshot.last_cookie){
            snapshot_valid=0U;return 9;
        }
        e.flags|=XE_NP_NP2_CATALOG_LAST;
        uint32_t state=(e.flags>>8U)&255U;
        if(!(snapshot.flags&~XE_NP_NP2_CATALOG_FULL) &&
           (e.flags&XE_NP_NP2_CATALOG_METADATA_VALID) && (e.flags&255U)!=8U &&
           state==XE_NP_NP2_DUAL_SD_META_COMPLETE)
            e.flags|=XE_NP_NP2_CATALOG_DELETE_ALLOWED;
    }
    *out=e;return 0;
}
int XE_NP_Np2DualSdCatalog_CheckDelete(const XE_NP_Np2DualSdCatalogDelete *r)
{
    if(!r)return 3;
    XE_NP_Np2DualSdCatalogInfo info;
    int result=XE_NP_Np2DualSdCatalog_Info(&info);if(result)return result;
    if(info.flags&~XE_NP_NP2_CATALOG_FULL)return 8;
    if(!info.count || r->token!=info.token || r->count!=info.count ||
       r->ordinal!=info.last_ordinal || r->start!=info.last_start ||
       r->end!=info.last_end || r->cookie!=info.last_cookie)return 9;
    XE_NP_Np2DualSdCatalogEntry e;
    result=XE_NP_Np2DualSdCatalog_Entry(info.token,info.count,info.last_ordinal,&e);
    return result?result:(e.flags&XE_NP_NP2_CATALOG_DELETE_ALLOWED)?0:8;
}
int XE_NP_Np2DualSdCatalog_DeleteLast(const XE_NP_Np2DualSdCatalogDelete *r,uint32_t *next)
{
#if NP_FINE_COUNTER64_ENABLE
    catalog.optional_metadata_ready=0U;
#endif
    if(!next)return 3;
    int result=XE_NP_Np2DualSdCatalog_CheckDelete(r);if(result)return result;
    catalog.mounted=0U;snapshot_valid=0U;
    /* Exact immutable images and mirrored same-card redo intent precede the
     * legacy journal/directory mutation. No erase, payload copy or retry. */
    if(delete_publish(r))return 10;
    return XE_NP_Np2DualSdCatalog_Mount(next)?10:0;
}
#endif
static int mount_available(uint32_t *next_start_lba)
{
    if(!catalog.bound || catalog.reserved || !next_start_lba)return -1;
    int result=XE_NP_Np2DualSdCatalog_Mount(next_start_lba);
    if(!result && !(catalog.status&XE_NP_NP2_CATALOG_RECOVERY))return 0;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    /* A delete's empty target is not the retained tail page. Only explicit
     * Recover may replay it; staging the older tail would resurrect entries. */
    if(!result && (catalog.pending_empty || delete_journal.pending))return 0;
#endif
    catalog.mounted=1U;
    catalog.status|=XE_NP_NP2_CATALOG_DEGRADED|XE_NP_NP2_CATALOG_RECOVERY;
    *next_start_lba=0U; /* Mounted for reading, not an invented write frontier. */
    if(!catalog.scan_valid || !catalog.last_log.count)return 0;

    /* Reuse stopped-time sector buffers: no new capture RAM or stack arrays.
     * The footer mirrors the descriptor, so either CRC-valid copy can prove
     * an allocation. Never repair the original descriptor/footer in place. */
    int have_header=read_sector(catalog.last_start+3U,sector_buffer)==0;
    int have_footer=read_sector(catalog.last_start+4U,verify_buffer)==0;
    XE_NP_Np2DualSdMeta m;uint32_t state=0U,error=0U,blocks=0U;
    uint8_t *header=sector_buffer;
    if(!have_header || decode_descriptor(header,&m)){
        if(!have_footer || memcmp(verify_buffer,"N2SDEND1",8U) ||
           np_get32(verify_buffer+508U)!=XE_NP_Np2DualSd_Crc32(verify_buffer,508U))return 0;
#if XE_NP_NP2_SD_GRID16_ENABLE
        /* No v16 footer-to-descriptor reconstruction: extension and CL
         * information are not a proven reversible descriptor copy. */
        if(np_get32(verify_buffer+8U)==16U)return 0;
#endif
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
        if(np_get32(verify_buffer+8U)==XE_NP_NP2_CL_SD_VERSION)return 0;
#endif
        memcpy(journal_shadow,verify_buffer,512U);memcpy(journal_shadow,"N2SDLOG1",8U);
        memset(journal_shadow+100U,0,28U);np_put32(journal_shadow+100U,XE_NP_NP2_DUAL_SD_META_RESERVED);
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
        if(np_get32(journal_shadow+8U)==XE_NP_NP2_SD_APPEND_VERSION)
            memset(journal_shadow+XE_NP_NP2_SD_APPEND_PREFIX_OFFSET,0,8U);
#endif
        np_put32(journal_shadow+508U,XE_NP_Np2DualSd_Crc32(journal_shadow,508U));
        header=journal_shadow;
        if(decode_descriptor(header,&m) ||
           decode_footer(header,verify_buffer,&state,&error,&blocks))return 0;
    }else if(have_footer){
        if(decode_footer(header,verify_buffer,&state,&error,&blocks))state=0U;
    }
    if(m.reservation_start_lba!=catalog.last_start || m.card_blocks!=catalog.io.card_blocks ||
       memcmp(m.cid,catalog.io.cid,sizeof(m.cid)))return 0;

    uint32_t end=m.reservation_end_lba;
    uint32_t empty_cancel=!is_grid16(header) && state==XE_NP_NP2_DUAL_SD_META_FAILED &&
        error==XE_NP_NP2_DUAL_SD_META_CANCELLED_EMPTY && !blocks;
    uint32_t sealed_grid_append=is_grid16_append(header) && state==XE_NP_NP2_DUAL_SD_META_FAILED;
    if(empty_cancel || sealed_grid_append || state==XE_NP_NP2_DUAL_SD_META_COMPLETE ||
       (!is_grid16(header) && state==XE_NP_NP2_DUAL_SD_META_FAILED &&
        error==XE_NP_NP2_DUAL_SD_META_VERIFY_PENDING && blocks)){
        /* Empty cancellation proves no payload was armed/written. VERI proves
         * ALL issued writes drained, unlike an ordinary sparse FAILED tail. */
        end=confirmed_end(header,verify_buffer,&m,blocks);
    }
    uint32_t old_end=catalog.last_log.end[catalog.last_index];
    uint32_t event_end=catalog.last_log.event_end[catalog.last_index];
    if(old_end>m.reservation_end_lba || event_end>m.reservation_end_lba)return 0;
    if(empty_cancel){
        if(old_end!=event_end || (old_end!=m.run.payload_start_lba && old_end!=m.reservation_end_lba))return 0;
    }else if(sealed_grid_append){
        if(old_end!=event_end || (old_end!=m.run.payload_start_lba &&
           old_end!=m.reservation_end_lba && old_end!=end))return 0;
    }else{
        if(end<old_end)end=old_end;
        if(end<event_end)end=event_end; /* Other incomplete tails never reclaim published padding. */
    }
    catalog.repair_pending=(uint8_t)(catalog.journal_pending || old_end!=end || event_end!=end);
    catalog.last_log.end[catalog.last_index]=catalog.last_log.event_end[catalog.last_index]=end;
    if(catalog.directory.block==catalog.last_block)catalog.directory.log=catalog.last_log;
    catalog.directory.start=(end+8191U)&~8191U;
    catalog.status=XE_NP_NP2_CATALOG_DEGRADED;
    uint64_t payload=((uint64_t)catalog.directory.start+8192U+16383U)&~UINT64_C(16383);
    if(payload+XE_NP_NP2_DUAL_SD_SECTORS_PER_RU>(catalog.io.card_blocks&~UINT64_C(16383)) ||
       catalog.directory.index>=63U)catalog.status|=XE_NP_NP2_CATALOG_FULL;
    *next_start_lba=catalog.directory.start;return 0;
}
/* This is an OFFER, never free-space proof. A confirmed rewind may discard
 * everything after this readable prefix, including unindexed recordings.
 * Keep only coherent prefix entries; do not hunt beyond the first gap. */
static int offer_rewind(uint32_t limit)
{
    if(read_sector(16U,sector_buffer) || memcmp(sector_buffer,"CE_FILESYSTEM_V1",16U) ||
       (memcmp(sector_buffer+32U,XE_NP_NP2_DUAL_SD_CARD_IDENT,9U) &&
        memcmp(sector_buffer+32U,"NP_PSSI_6",9U) &&
        memcmp(sector_buffer+32U,"NP_CE64_1",9U)))return -1;
    catalog.shared_media=(uint8_t)!memcmp(sector_buffer+32U,"NP_CE64_1",9U);
    uint32_t pending=UINT32_MAX,previous=8192U;
    /* A good pending shadow is readable evidence. An invalid journal cannot
     * establish free space, but need not hide the raw prefix for this opt-in. */
    if(!read_sector(112U,sector_buffer) && !memcmp(sector_buffer,"NPC64TX1",8U) &&
       np_get32(sector_buffer+508U)==XE_NP_Np2DualSd_Crc32(sector_buffer,508U)){
        uint32_t target=np_get32(sector_buffer+8U),shadow_crc=np_get32(sector_buffer+12U);
        if(target>=128U && target<128U+NP_CE64_MAX_LOG_BLOCKS &&
           !read_sector(113U,journal_shadow) && shadow_crc==XE_NP_Np2DualSd_Crc32(journal_shadow,512U))
            pending=target-128U;
    }
    memset(&catalog.directory,0,sizeof(catalog.directory));
    NpCe64Directory *d=&catalog.directory;
    for(d->block=0U;d->block<NP_CE64_MAX_LOG_BLOCKS;d->block++){
        int readable=1;
        if(d->block==pending)memcpy(&d->log,journal_shadow,512U);
        else readable=read_sector(128U+d->block,(uint8_t *)&d->log)==0;
        uint32_t count=readable && d->log.count<=63U?d->log.count:0U;
        for(d->index=0U;d->index<count;d->index++){
            uint64_t start=((uint64_t)previous+8191U)&~UINT64_C(8191);
            uint32_t end=d->log.end[d->index];
            if(start>=limit || end<=start+4U || end>catalog.io.card_blocks ||
               d->log.event_end[d->index]!=end)break;
            previous=end;
        }
        if(d->index<63U){
            d->log.count=d->index;d->log.continued=0U;
            for(uint32_t i=d->index;i<63U;i++)d->log.end[i]=d->log.event_end[i]=0U;
            uint64_t start=((uint64_t)previous+8191U)&~UINT64_C(8191);
            uint64_t payload=(start+8192U+16383U)&~UINT64_C(16383);
            if(start>UINT32_MAX || payload+XE_NP_NP2_DUAL_SD_SECTORS_PER_RU>
               (catalog.io.card_blocks&~UINT64_C(16383)))return -1;
            d->start=(uint32_t)start;return 0;
        }
    }
    return -1;
}
int XE_NP_Np2DualSdCatalog_MountAvailable(uint32_t *next_start_lba)
{
    int result=mount_available(next_start_lba);
#if XE_NP_NP2_SD_CATALOG_ENABLE
    if(!result && (catalog.pending_empty || delete_journal.pending))return 0;
#endif
    if(!result && (catalog.status&XE_NP_NP2_CATALOG_RECOVERY)){
        uint32_t limit=catalog.scan_valid && catalog.last_log.count?catalog.last_start:UINT32_MAX;
        if(!offer_rewind(limit)){
            catalog.status=XE_NP_NP2_CATALOG_DEGRADED|XE_NP_NP2_CATALOG_RECOVERY|
                           XE_NP_NP2_CATALOG_REWIND_AVAILABLE;
            *next_start_lba=catalog.directory.start; /* Proposed discard boundary, NOT writable. */
        }
    }
    return result;
}
int XE_NP_Np2DualSdCatalog_Rewind(uint32_t key,uint32_t expected_start_lba,
                                 uint32_t *next_start_lba)
{
#if NP_FINE_COUNTER64_ENABLE
    catalog.optional_metadata_ready=0U;
#endif
    if(!catalog.bound || !catalog.mounted || catalog.reserved || !next_start_lba ||
       key!=XE_NP_NP2_CATALOG_REWIND_KEY ||
       !(catalog.status&XE_NP_NP2_CATALOG_REWIND_AVAILABLE) ||
       expected_start_lba!=catalog.directory.start)return -1;
    uint32_t fresh=0U;
    if(XE_NP_Np2DualSdCatalog_MountAvailable(&fresh) ||
       !(catalog.status&XE_NP_NP2_CATALOG_REWIND_AVAILABLE) || fresh!=expected_start_lba)return -1;
    /* Truncate only one directory page, with the existing durable journal.
     * Count<63 hides the discarded suffix; later reserve already clears the
     * next page before filling entry63. Raw payload/header/footer are untouched. */
    catalog.mounted=0U;
    if(np_ce64_publish(&catalog.directory,write_sector))return -1;
    catalog.mounted=1U;catalog.repair_pending=catalog.journal_pending=0U;
    catalog.status=XE_NP_NP2_CATALOG_DEGRADED;
    *next_start_lba=fresh;return 0;
}
int XE_NP_Np2DualSdCatalog_Recover(uint32_t *next_start_lba)
{
#if NP_FINE_COUNTER64_ENABLE
    catalog.optional_metadata_ready=0U;
#endif
    if(XE_NP_Np2DualSdCatalog_Mount(next_start_lba))return -1;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    if(delete_journal.pending){
        if(delete_redo())return -1;
        return XE_NP_Np2DualSdCatalog_Mount(next_start_lba);
    }
    /* Non-authoritative orphan fragments need no directory rollback. Explicit
     * Recover may clear only the owned extension intents after a valid mount. */
    if(delete_journal.residue && delete_clear())return -1;
#endif
    if(!(catalog.status&XE_NP_NP2_CATALOG_RECOVERY))return 0;
    if(!(catalog.status&(XE_NP_NP2_CATALOG_RECOVERABLE|XE_NP_NP2_CATALOG_QUARANTINABLE)))return -1;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    if(catalog.pending_empty){
        NpCe64Directory empty={0};empty.block=catalog.directory.block;
        catalog.mounted=0U;
        if(np_ce64_publish(&empty,write_sector))return -1;
        return XE_NP_Np2DualSdCatalog_Mount(next_start_lba);
    }
#endif
    NpCe64Directory repaired={0};repaired.block=catalog.last_block;repaired.log=catalog.last_log;
    uint32_t end=(catalog.status&XE_NP_NP2_CATALOG_QUARANTINABLE)?
                 catalog.quarantine_end:catalog.sealed_end;
    repaired.log.end[catalog.last_index]=end;
    repaired.log.event_end[catalog.last_index]=end;
    /* COMPLETE recovery uses its durable seal. Incomplete quarantine publishes
     * the whole descriptor allocation without touching metadata/sample data;
     * RESERVED/FAILED are never relabeled COMPLETE or assigned extra samples. */
    catalog.mounted=0U;
    if(np_ce64_publish(&repaired,write_sector))return -1;
    return XE_NP_Np2DualSdCatalog_Mount(next_start_lba);
}

int XE_NP_Np2DualSdCatalog_Plan(uint32_t sample_hz,uint32_t blocks,
                               uint32_t session_id,uint32_t config_crc,
                               XE_NP_Np2DualSdMeta *out)
{return XE_NP_Np2DualSdCatalog_PlanAu(sample_hz,blocks,session_id,config_crc,0U,out);}

int XE_NP_Np2DualSdCatalog_PlanAu(uint32_t sample_hz,uint32_t blocks,
                                 uint32_t session_id,uint32_t config_crc,
                                 uint32_t au_blocks,XE_NP_Np2DualSdMeta *out)
{return XE_NP_Np2DualSdCatalog_PlanAuProfile(3U,sample_hz,blocks,session_id,config_crc,au_blocks,out);}

int XE_NP_Np2DualSdCatalog_PlanProfile(uint32_t mask,uint32_t sample_hz,uint32_t blocks,
                                      uint32_t session_id,uint32_t config_crc,
                                      XE_NP_Np2DualSdMeta *out)
{return XE_NP_Np2DualSdCatalog_PlanAuProfile(mask,sample_hz,blocks,session_id,config_crc,0U,out);}

int XE_NP_Np2DualSdCatalog_PlanAuProfile(uint32_t mask,uint32_t sample_hz,uint32_t blocks,
                                        uint32_t session_id,uint32_t config_crc,
                                        uint32_t au_blocks,XE_NP_Np2DualSdMeta *out)
{
    if(!catalog.mounted || catalog.reserved || (catalog.status&~XE_NP_NP2_CATALOG_DEGRADED) || !out || !session_id ||
       !XE_NP_Np2DualSd_ProfileTicks(mask,sample_hz) || blocks<4U || blocks%4U)return -1;
    uint64_t start=catalog.directory.start;
    uint64_t payload=(start+8192U+16383U)&~UINT64_C(16383);
    if(au_blocks){
        if(au_blocks<1024U || au_blocks%1024U)return -1;
        payload=((payload+au_blocks-1U)/au_blocks)*au_blocks;
    }
    uint64_t required_end=payload+(uint64_t)blocks*XE_NP_NP2_DUAL_SD_SECTORS_PER_BLOCK;
    uint64_t au_end=au_blocks?((required_end+au_blocks-1U)/au_blocks)*au_blocks:required_end;
    uint64_t reservation_end=(au_end+16383U)&~UINT64_C(16383);
    if(start<8192U || start%8192U || reservation_end>catalog.io.card_blocks ||
       reservation_end>UINT32_MAX ||
       (au_blocks && (payload/1024U>0x3FFFFFU || (au_end-au_blocks)/1024U>0x3FFFFFU)))return -1;
    XE_NP_Np2DualSdMeta m={0};
    if(XE_NP_Np2DualSd_PlanProfile(mask,sample_hz,(uint32_t)payload,
                                   (uint32_t)(au_blocks?required_end:reservation_end),catalog.io.card_blocks,&m.run) ||
       m.run.max_blocks<blocks)return -1;
    m.session_id=session_id;m.reservation_start_lba=(uint32_t)start;
    m.reservation_end_lba=(uint32_t)reservation_end;
    m.card_blocks=catalog.io.card_blocks;m.config_crc=config_crc;
    m.au_blocks=au_blocks;
    memcpy(m.cid,catalog.io.cid,sizeof(m.cid));*out=m;return 0;
}

int XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(uint32_t mask,uint32_t sample_hz,uint32_t blocks,
                                             uint32_t session_id,uint32_t config_crc,
                                             uint32_t au_blocks,XE_NP_Np2DualSdMeta *out)
{
    XE_NP_Np2DualSdMeta m;
    if(!out || !XE_NP_SdIsUhsAuBlocks(au_blocks) ||
       XE_NP_Np2DualSdCatalog_PlanAuProfile(mask,sample_hz,blocks,
                       session_id,config_crc,au_blocks,&m))return -1;
    m.au_blocks=0U;m.legacy_au_blocks=au_blocks;*out=m;return 0;
}

#if XE_NP_NP2_SD_GRID16_ENABLE
int XE_NP_Np2DualSdCatalog_PlanGrid16(uint32_t mask,uint32_t hz,uint32_t blocks,
    uint32_t session,uint32_t crc,uint32_t base,uint32_t au,XE_NP_Grid16Meta *out)
{
    uint32_t k=XE_NP_Grid16_K(mask,hz);
    if(!catalog.mounted || catalog.reserved || (catalog.status&~XE_NP_NP2_CATALOG_DEGRADED) ||
       !out || !session || !k || (blocks && (blocks<4U || blocks%4U)) ||
       (base==11U && au) || (base==12U && (au<1024U || au%1024U)) ||
       (base==13U && !XE_NP_SdIsUhsAuBlocks(au)) || (base!=11U && base!=12U && base!=13U))return -1;
    uint64_t start=catalog.directory.start,payload=(start+8192U+16383U)&~UINT64_C(16383);
    if(au)payload=((payload+au-1U)/au)*au;
    uint64_t limit=(uint64_t)catalog.io.card_blocks&~UINT64_C(16383);
    if(au)limit=(limit/au)*au;
    if(payload>=limit)return -1;
    uint64_t max=(limit-payload)/(364U+k),groups=blocks?blocks/4U:max;
    if(!groups || groups>max || groups>UINT32_MAX/4U)return -1;
    uint64_t end=payload+groups*(364U+k),au_end=au?((end+au-1U)/au)*au:end;
    uint64_t allocation=(au_end+16383U)&~UINT64_C(16383);
    if(payload>UINT32_MAX || end>UINT32_MAX || allocation>UINT32_MAX || allocation>catalog.io.card_blocks)return -1;
    XE_NP_Grid16Meta m={0};m.session=session;m.mask=mask;m.sample_hz=hz;m.config_crc=crc;
    m.reservation_start=(uint32_t)start;m.payload_start=(uint32_t)payload;m.payload_end=(uint32_t)end;
    m.reservation_end=(uint32_t)allocation;m.card_blocks=catalog.io.card_blocks;m.base=base;m.au=au;
    m.max_groups=(uint32_t)groups;memcpy(m.cid,catalog.io.cid,sizeof(m.cid));
    uint8_t sector[512];if(XE_NP_Grid16_EncodeDescriptor(sector,&m))return -1;
    *out=m;return 0;
}
int XE_NP_Np2DualSdCatalog_ReserveGrid16(const XE_NP_Grid16Meta *m,
    const uint8_t config[2048],const struct XE_NP_Np2ClCarrierTag *cl)
{
#if NP_FINE_COUNTER64_ENABLE
    catalog.optional_metadata_ready=0U;
#endif
    if(!catalog.mounted || catalog.reserved || (catalog.status&~XE_NP_NP2_CATALOG_DEGRADED) ||
       !m || !config || m->reservation_start!=catalog.directory.start ||
       !XE_NP_Grid16_MatchesCard(m,catalog.io.cid,catalog.io.card_blocks) ||
       m->config_crc!=XE_NP_Np2DualSd_Crc32(config,2048U) ||
       memcmp(config,"N2SDCFG1",8U) || np_get32(config+8U)!=1U ||
       np_get32(config+16U)!=m->sample_hz || np_get32(config+20U)!=m->sample_hz*1600U ||
       np_get32(config+24U)!=m->mask || np_get32(config+28U)!=XE_NP_Np2UsbV3_WireMask(m->mask) ||
       np_get32(config+32U)!=(m->mask==7U?6U:4U) ||
       np_get32(config+36U)!=(m->mask==1U?3U:m->mask==3U?6U:9U) ||
       np_get32(config+40U)!=XE_NP_NP2_DUAL_SD_BYTES_PER_BLOCK ||
       np_get32(config+44U)!=m->max_groups*4U ||
       memcmp(config+48U,m->cid,sizeof(m->cid)))return -1;
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    if(m->cl_enabled){
        XE_NP_Np2ClConfigMeta cm;uint8_t confirmed[64];
        if(!cl || !cl->initialized || cl->stopped || cl->session!=m->session || cl->config_crc!=m->cl_crc ||
           XE_NP_Np2ClCarrier_ConfigDecode(config,1,&cm,confirmed)!=1 ||
           cm.session!=m->session || cm.native_hz!=m->sample_hz ||
           memcmp(confirmed,cl->confirmed_config,64U))return -1;
    }else if(cl)return -1;
#else
    if(m->cl_enabled || cl)return -1;
#endif
    if(catalog.shared_media && (read_sector(16U,sector_buffer) || memcmp(sector_buffer+32U,"NP_CE64_1",9U)))return -1;
    uint8_t descriptor[512],footer[512];XE_NP_Np2DualSdMeta compatible;
    XE_NP_Grid16Footer empty={0};empty.state=XE_NP_NP2_DUAL_SD_META_RESERVED;empty.error=1U;
    empty.final_exclusive=UINT64_MAX;
    if(m->schema==3U)empty.admitted_blocks=UINT32_MAX;
    if(XE_NP_Grid16_EncodeDescriptor(descriptor,m) || decode_descriptor(descriptor,&compatible) ||
       XE_NP_Grid16_EncodeFooter(footer,descriptor,&empty))return -1;
    if(catalog.repair_pending){
        NpCe64Directory repaired={0};repaired.block=catalog.last_block;repaired.log=catalog.last_log;
        catalog.mounted=0U;if(np_ce64_publish(&repaired,write_sector))return -1;
        catalog.repair_pending=0U;catalog.mounted=1U;
    }
    if(clear_old_slots())return -1;
    catalog.mounted=0U;
    if(write_sector(m->reservation_start+4U,footer) || write_sector(m->reservation_start+3U,descriptor))return -1;
    for(uint32_t i=0U;i<4U;i++)if(write_sector(m->reservation_start+8U+i,config+i*512U))return -1;
    if(!catalog.shared_media){
        if(read_sector(16U,sector_buffer))return -1;
        memcpy(sector_buffer+32U,XE_NP_NP2_DUAL_SD_CARD_IDENT,9U);
        if(write_sector(16U,sector_buffer))return -1;
    }
    if(np_ce64_reserve(&catalog.directory,m->payload_start,m->session,catalog.io.card_blocks,write_sector))return -1;
    catalog.directory.reserved_end=m->reservation_end;catalog.grid16=*m;catalog.meta=compatible;
    catalog.reserved=catalog.reserved_grid16=1U;
#if NP_FINE_COUNTER64_ENABLE
    catalog.optional_metadata_ready=0U;
#endif
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    catalog.cl_carrier=cl;catalog.cl_base=0U;catalog.cl_crc=cl?cl->config_crc:0U;
    catalog.cl_generation=cl?cl->generation:0U;
#endif
    return 0;
}
#endif

static int reserve(const XE_NP_Np2DualSdMeta *m,
                    const uint8_t configuration[2048],uint32_t append
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
                    ,const XE_NP_Np2ClCarrier *cl
#endif
                    )
{
    if(!catalog.mounted || catalog.reserved || (catalog.status&~XE_NP_NP2_CATALOG_DEGRADED) || !m || !configuration ||
       m->reservation_start_lba!=catalog.directory.start ||
       m->card_blocks!=catalog.io.card_blocks ||
       memcmp(m->cid,catalog.io.cid,sizeof(m->cid)) ||
       m->config_crc!=XE_NP_Np2DualSd_Crc32(configuration,2048U))return -1;
    /* A shared CE64 card stays readable by the camera role. Check its admitted
     * tag before any reservation write or stopped CMD20 mutates the card. */
    if(catalog.shared_media && (read_sector(16U,sector_buffer) ||
                               memcmp(sector_buffer+32U,"NP_CE64_1",9U)))return -1;
    uint8_t descriptor[512],footer[512];
    int invalid;
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    uint32_t cl_base=0U;
    if(cl){
        XE_NP_Np2ClConfigMeta cm;uint8_t confirmed_snapshot[64];
        if(!cl->initialized || cl->stopped || cl->session!=m->session_id ||
           XE_NP_Np2ClCarrier_ConfigDecode(configuration,1,&cm,confirmed_snapshot)!=1 ||
           cm.session!=m->session_id || cm.native_hz!=m->run.sample_hz ||
           memcmp(confirmed_snapshot,cl->confirmed_config,64U))return -1;
        cl_base=append?14U:m->au_blocks?12U:m->legacy_au_blocks?13U:11U;
        const XE_NP_Np2SdAppendCounts empty={0};
        invalid=XE_NP_Np2ClSd_EncodeDescriptor(descriptor,m,cl_base,cl->config_crc) ||
            XE_NP_Np2ClSd_EncodeFooter(footer,descriptor,XE_NP_NP2_DUAL_SD_META_RESERVED,1U,&empty,0,1);
    }else
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    if(append){
        const XE_NP_Np2SdAppendCounts empty={0};
        invalid=XE_NP_Np2SdAppend_EncodeDescriptor(descriptor,m) ||
            XE_NP_Np2SdAppend_EncodeFooter(footer,m,XE_NP_NP2_DUAL_SD_META_RESERVED,1U,&empty);
    }else
#else
    (void)append;
#endif
    invalid=XE_NP_Np2DualSd_EncodeDescriptor(descriptor,m) ||
        XE_NP_Np2DualSd_EncodeFooter(footer,m,XE_NP_NP2_DUAL_SD_META_RESERVED,1U,0U);
    if(invalid)return -1;
    if(catalog.repair_pending){
        /* START owns this ordinary journaled publication. Mount itself never
         * writes. Publish before CMD20 or ANY new-allocation mutation. */
        NpCe64Directory repaired={0};repaired.block=catalog.last_block;repaired.log=catalog.last_log;
        catalog.mounted=0U;
        if(np_ce64_publish(&repaired,write_sector))return -1;
        catalog.repair_pending=0U;catalog.mounted=1U;
    }
    if(clear_old_slots())return -1; /* Invalid geometry must not issue CMD20. */
    catalog.mounted=0U;
    uint32_t start=m->reservation_start_lba;
    if(write_sector(start+4U,footer) || write_sector(start+3U,descriptor))return -1;
    for(uint32_t i=0U;i<4U;i++)
        if(write_sector(start+8U+i,configuration+i*512U))return -1;
    /* Native neural cards retain their writer-tag upgrade. Shared media cards
     * retain NP_CE64_1; each descriptor still declares its own format. */
    if(!catalog.shared_media){
        if(read_sector(16U,sector_buffer))return -1;
        memcpy(sector_buffer+32U,XE_NP_NP2_DUAL_SD_CARD_IDENT,9U);
        if(write_sector(16U,sector_buffer))return -1;
    }
    if(np_ce64_reserve(&catalog.directory,m->run.payload_start_lba,m->session_id,
                       catalog.io.card_blocks,write_sector))return -1;
    catalog.directory.reserved_end=m->reservation_end_lba; /* RAM-only write limit */
#if NP_FINE_COUNTER64_ENABLE
    catalog.optional_metadata_ready=0U;
#endif
    catalog.meta=*m;catalog.reserved=1U;
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    catalog.cl_carrier=cl;catalog.cl_base=(uint8_t)cl_base;
    catalog.cl_crc=cl?cl->config_crc:0U;catalog.cl_generation=cl?cl->generation:0U;
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    catalog.reserved_append=(uint8_t)(append!=0U);
#endif
    return 0;
}
int XE_NP_Np2DualSdCatalog_Reserve(const XE_NP_Np2DualSdMeta *m,
                                  const uint8_t configuration[2048])
{
#if NP_FINE_COUNTER64_ENABLE
    catalog.optional_metadata_ready=0U;
#endif
    return reserve(m,configuration,0U
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    ,0
#endif
);}
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
int XE_NP_Np2DualSdCatalog_ReserveClosedLoop(const XE_NP_Np2DualSdMeta *m,
    const uint8_t configuration[2048],uint32_t append,const XE_NP_Np2ClCarrier *cl)
{
#if NP_FINE_COUNTER64_ENABLE
    catalog.optional_metadata_ready=0U;
#endif
    if(!cl || append>1U)return -1;
#if !XE_NP_NP2_SD_APPEND_ORDER_TEST
    if(append)return -1;
#endif
    return reserve(m,configuration,append,cl);
}
static int cl_footer(uint8_t footer[512],uint32_t state,uint32_t error,const XE_NP_Np2SdAppendCounts *counts)
{
    uint8_t descriptor[512],summary[64];
    if(!catalog.cl_base || XE_NP_Np2ClSd_EncodeDescriptor(descriptor,&catalog.meta,catalog.cl_base,catalog.cl_crc))return -1;
    const XE_NP_Np2ClCarrier *owner=catalog.cl_carrier;
    int known=owner && owner->initialized && owner->stopped && owner->session==catalog.meta.session_id &&
        owner->config_crc==catalog.cl_crc && owner->generation==catalog.cl_generation;
    if(known){if(XE_NP_Np2ClCarrier_SummaryEncode(owner,state!=XE_NP_NP2_DUAL_SD_META_COMPLETE,summary))return -1;}
    else{
        /* Neural finalization must not fail just because CL state was lost.
         * Zero counters are explicitly UNKNOWN, never proof of zero drops. */
        if(XE_NP_Np2ClCarrier_SummaryUnknown(catalog.meta.session_id,catalog.cl_crc,catalog.cl_generation,summary))return -1;
    }
    return XE_NP_Np2ClSd_EncodeFooter(footer,descriptor,state,error,counts,summary,0);
}
#endif

static int checkpoint_footer(const uint8_t footer[512])
{
    if(write_sector(catalog.meta.reservation_start_lba+4U,footer))return -1;
    memcpy(xe_np_np2_dual_sd_last_footer,footer,512U);
    /* Keep ownership and the original directory intact while verification
     * runs. Only Finish may release/publish and only successful full-media
     * verification may replace this INCOMPLETE footer with COMPLETE. */
    return 0;
}
int XE_NP_Np2DualSdCatalog_CheckpointWritten(uint32_t blocks)
{
    if(!catalog.reserved || !blocks)return -1;
#if XE_NP_NP2_SD_GRID16_ENABLE
    if(catalog.reserved_grid16)return -1;
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    if(catalog.reserved_append)return -1;
#endif
    uint8_t footer[512];
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    if(catalog.cl_base){
        XE_NP_Np2SdAppendCounts c={blocks,blocks,blocks};
        if(cl_footer(footer,XE_NP_NP2_DUAL_SD_META_FAILED,XE_NP_NP2_DUAL_SD_META_VERIFY_PENDING,&c))return -1;
    }else
#endif
    if(XE_NP_Np2DualSd_EncodeFooter(footer,&catalog.meta,
        XE_NP_NP2_DUAL_SD_META_FAILED,XE_NP_NP2_DUAL_SD_META_VERIFY_PENDING,blocks))return -1;
    return checkpoint_footer(footer);
}
static int finish_footer(uint32_t state,uint32_t blocks,const uint8_t footer[512])
{
    uint32_t committed_end=catalog.meta.run.payload_start_lba+
                           (blocks/4U)*XE_NP_NP2_DUAL_SD_SECTORS_PER_RU;
    uint32_t empty_cancel=state==XE_NP_NP2_DUAL_SD_META_FAILED && !blocks &&
        np_get32(footer+104U)==XE_NP_NP2_DUAL_SD_META_CANCELLED_EMPTY;
    uint32_t allocation_end=state==XE_NP_NP2_DUAL_SD_META_FAILED && !empty_cancel?
                            catalog.meta.reservation_end_lba:committed_end;
    /* Seal the contiguous count BEFORE publication. FAILED fences every
     * possible OOO write, not just that prefix; only a proven never-armed empty
     * cancellation retains its header alone. COMPLETE still trims normally.
     * Readers use the unchanged footer count/end, never allocation padding. */
    if(write_sector(catalog.meta.reservation_start_lba+4U,footer) ||
       np_ce64_finish(&catalog.directory,allocation_end,1,write_sector))return -1;
    memcpy(xe_np_np2_dual_sd_last_footer,footer,512U);
    catalog.reserved=0U;catalog.mounted=0U;
#if NP_FINE_COUNTER64_ENABLE
    catalog.optional_metadata_ready=state==XE_NP_NP2_DUAL_SD_META_COMPLETE;
#endif
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    catalog.cl_carrier=0;catalog.cl_base=0U;catalog.cl_crc=catalog.cl_generation=0U;
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    catalog.reserved_append=0U;
#endif
    return 0;
}
int XE_NP_Np2DualSdCatalog_Finish(uint32_t state,uint32_t error,uint32_t blocks)
{
    if(!catalog.reserved)return -1;
#if XE_NP_NP2_SD_GRID16_ENABLE
    if(catalog.reserved_grid16)return -1;
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    if(catalog.reserved_append)return -1;
#endif
    uint8_t footer[512];
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    if(catalog.cl_base){
        XE_NP_Np2SdAppendCounts c={blocks,blocks,blocks};
        if(cl_footer(footer,state,error,&c))return -1;
    }else
#endif
    if(XE_NP_Np2DualSd_EncodeFooter(footer,&catalog.meta,state,error,blocks))return -1;
    return finish_footer(state,blocks,footer);
}
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
int XE_NP_Np2DualSdCatalog_ReserveAppend(const XE_NP_Np2DualSdMeta *m,
                                        const uint8_t configuration[2048])
{
#if NP_FINE_COUNTER64_ENABLE
    catalog.optional_metadata_ready=0U;
#endif
    return reserve(m,configuration,1U
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    ,0
#endif
);}
int XE_NP_Np2DualSdCatalog_CheckpointAppend(const XE_NP_Np2SdAppendCounts *counts)
{
    if(!catalog.reserved || !catalog.reserved_append)return -1;
#if XE_NP_NP2_SD_GRID16_ENABLE
    if(catalog.reserved_grid16)return -1;
#endif
    uint8_t footer[512];
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    if(catalog.cl_base){
        if(cl_footer(footer,XE_NP_NP2_DUAL_SD_META_FAILED,XE_NP_NP2_DUAL_SD_META_VERIFY_PENDING,counts))return -1;
    }else
#endif
    if(XE_NP_Np2SdAppend_EncodeFooter(footer,&catalog.meta,
        XE_NP_NP2_DUAL_SD_META_FAILED,XE_NP_NP2_DUAL_SD_META_VERIFY_PENDING,counts))return -1;
    return checkpoint_footer(footer);
}
int XE_NP_Np2DualSdCatalog_FinishAppend(uint32_t state,uint32_t error,
                                       const XE_NP_Np2SdAppendCounts *counts)
{
    if(!catalog.reserved || !catalog.reserved_append ||
       (state!=XE_NP_NP2_DUAL_SD_META_COMPLETE && state!=XE_NP_NP2_DUAL_SD_META_FAILED))return -1;
#if XE_NP_NP2_SD_GRID16_ENABLE
    if(catalog.reserved_grid16)return -1;
#endif
    uint8_t footer[512];
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    if(catalog.cl_base){if(cl_footer(footer,state,error,counts))return -1;}else
#endif
    if(XE_NP_Np2SdAppend_EncodeFooter(footer,&catalog.meta,state,error,counts))return -1;
    return finish_footer(state,counts->physical_blocks,footer);
}
#endif

#if XE_NP_NP2_SD_GRID16_ENABLE
int XE_NP_Np2DualSdCatalog_FinishGrid16(const XE_NP_Grid16Footer *input)
{
    if(!catalog.reserved || !catalog.reserved_grid16 || !input ||
       (input->state!=XE_NP_NP2_DUAL_SD_META_COMPLETE && input->state!=XE_NP_NP2_DUAL_SD_META_FAILED))return -1;
    XE_NP_Grid16Footer f=*input;uint8_t descriptor[512],footer[512];
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    if(catalog.grid16.cl_enabled){
        const XE_NP_Np2ClCarrier *cl=catalog.cl_carrier;
        int known=cl && cl->initialized && cl->stopped && cl->session==catalog.grid16.session &&
            cl->config_crc==catalog.cl_crc && cl->generation==catalog.cl_generation;
        if(known){if(XE_NP_Np2ClCarrier_SummaryEncode(cl,f.state!=XE_NP_NP2_DUAL_SD_META_COMPLETE,f.cl_summary))return -1;}
        else if(XE_NP_Np2ClCarrier_SummaryUnknown(catalog.grid16.session,catalog.cl_crc,catalog.cl_generation,f.cl_summary))return -1;
    }
#endif
    if(XE_NP_Grid16_EncodeDescriptor(descriptor,&catalog.grid16) || XE_NP_Grid16_EncodeFooter(footer,descriptor,&f))return -1;
    uint32_t end=(f.state==XE_NP_NP2_DUAL_SD_META_COMPLETE || catalog.grid16.schema==3U)?
        np_get32(footer+116U):catalog.grid16.reservation_end;
    if(write_sector(catalog.grid16.reservation_start+4U,footer) || np_ce64_finish(&catalog.directory,end,1,write_sector))return -1;
    memcpy(xe_np_np2_dual_sd_last_footer,footer,512U);
    catalog.reserved=catalog.reserved_grid16=0U;catalog.mounted=0U;
#if NP_FINE_COUNTER64_ENABLE
    catalog.optional_metadata_ready=f.state==XE_NP_NP2_DUAL_SD_META_COMPLETE;
#endif
#if XE_NP_NP2_CLOSED_LOOP_SD_FORMAT_ENABLE
    catalog.cl_carrier=0;catalog.cl_base=0U;catalog.cl_crc=catalog.cl_generation=0U;
#endif
    return 0;
}
#endif

#if NP_FINE_COUNTER64_ENABLE
/* Stopped optional metadata only. One existing scratch sector, no payload
 * walk. Callers keep optional failures separate from the primary footer. */
static int counter64_time_pair(const uint8_t utc2[512],const uint8_t anchor[64],
    const uint32_t uid[3],uint64_t token,NpRtcStartBinding *binding)
{
    NpFirstSdBound bound;
    if(!catalog.optional_metadata_ready || !utc2 || !anchor || !uid || !token ||
       !np_first_sd_sector_read(utc2,512U,2U,catalog.meta.session_id,
           catalog.meta.run.sample_hz,uid,token,&bound) ||
       bound.receipt[48]!=catalog.meta.run.probe_mask ||
       !np_fine_sd_companion_fine_counter64_pack(sector_buffer,utc2,anchor,2U,uid,token))return 0;
    if(binding){
        if(!np_rtc_start_binding_sd(binding,utc2,sector_buffer,2U,catalog.meta.session_id,
            catalog.meta.run.sample_hz,uid,token))return 0;
        /* The exact checked anchor was just copied by the companion packer;
         * keep the external immutable owner when scratch is reused for +7. */
        binding->anchor=anchor;
    }
    return 1;
}
int XE_NP_Np2DualSdCatalog_FineCounter64Time(const uint8_t utc2[512],const uint8_t anchor[64],
    const uint32_t uid[3],uint64_t token)
{
    if(catalog.meta.reservation_start_lba>UINT32_MAX-6U ||
       catalog.meta.reservation_start_lba+6U>=catalog.meta.run.payload_start_lba ||
       !counter64_time_pair(utc2,anchor,uid,token,NULL))return -1;
    return write_sector(catalog.meta.reservation_start_lba+6U,sector_buffer);
}
int XE_NP_Np2DualSdCatalog_RtcTime(const uint8_t utc2[512],const uint8_t anchor[64],
    const uint8_t rtc[128],const uint32_t uid[3],uint64_t token)
{
    NpRtcStartBinding binding;
    if(!rtc || catalog.meta.reservation_start_lba>UINT32_MAX-7U ||
       catalog.meta.reservation_start_lba+7U>=catalog.meta.run.payload_start_lba ||
       !counter64_time_pair(utc2,anchor,uid,token,&binding) ||
       !np_rtc_start_sector_pack(sector_buffer,rtc,&binding))return -1;
    catalog.optional_metadata_ready=0U;
    return write_sector(catalog.meta.reservation_start_lba+7U,sector_buffer);
}
#endif

int XE_NP_Np2DualSdCatalog_Time(const uint8_t sector[512])
{
    if(!catalog.reserved || !sector ||
       !((!memcmp(sector,"N2SDUTC1",8U) && np_get32(sector+8U)==1U) ||
         (!memcmp(sector,"N2SDUTC2",8U) && np_get32(sector+8U)==2U)) ||
       np_get32(sector+12U)!=catalog.meta.session_id ||
       np_get32(sector+508U)!=XE_NP_Np2DualSd_Crc32(sector,508U))return -1;
    if(write_sector(catalog.meta.reservation_start_lba+5U,sector))return -1;
    memcpy(xe_np_np2_dual_sd_last_time,verify_buffer,512U);return 0;
}
