#include "xe_np_np2_dual_sd_catalog_port.h"
#if XE_NP_NP2_DUAL_SD_CATALOG_PORT_ENABLE

#include "main.h"
#include "xe_np_board.h"
#include "xe_np_np2_capture_port.h"
#if XE_NP_NP2_SD_CATALOG_ENABLE
#include "xe_np_np2_usb_source.h"
#endif
#include "xe_np_sd_record_plan.h"
#include <string.h>

#if !XE_NP_NP2_CAPTURE_PORT_ENABLE
#error "Dual-NP2 SD catalog port requires the V2 PSSI capture port"
#endif

#define SD_ERRORS (SDMMC_FLAG_DCRCFAIL|SDMMC_FLAG_DTIMEOUT|SDMMC_FLAG_RXOVERR|\
                   SDMMC_FLAG_TXUNDERR|SDMMC_FLAG_IDMATE)
#define SD_BUSY (SDMMC_STA_DPSMACT|SDMMC_STA_CPSMACT)
#define CMD_FLAGS (SDMMC_FLAG_CMDREND|SDMMC_FLAG_CCRCFAIL|\
                   SDMMC_FLAG_CTIMEOUT|SDMMC_FLAG_CMDSENT)

static SD_HandleTypeDef *card;
static uint32_t live_clock,metadata_clock,card_cid[4];
#if XE_NP_NP2_SD_CATALOG_ENABLE
static uint32_t card_blocks;
#endif
static uint8_t bound,metadata_mode;
static __attribute__((aligned(32))) uint8_t read_buffer[512],write_buffer[512];

static uint32_t stopped_metadata_clock(void)
{
    uint32_t divider=2U;
#if XE_NP_NP2_DUAL_SD_APP_ENABLE && XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
    /* HAL polling assembles FIFO words on the CPU. CPU48 and CPU96 have
     * underrun under BLE IRQs; keep6.75MHz margin through CPU96, including
     * raw20's CPU64. Live DMA writes and verification keep their own clock. */
    if(HAL_RCC_GetHCLKFreq()<=96000000U)divider=8U;
#endif
    return (live_clock&~SDMMC_CLKCR_CLKDIV)|divider;
}
static int source_idle(void)
{
    return !(PSSI->CR&PSSI_CR_ENABLE) && !(GPDMA1_Channel12->CCR&DMA_CCR_EN) &&
           !XE_NP_Np2CapturePort_Armed();
}
static int bus_idle(void)
{
    return card && card->State==HAL_SD_STATE_READY && !card->ErrorCode &&
           !(card->Instance->STA&(SD_BUSY|SD_ERRORS)) && !card->Instance->IDMACTRL;
}
static int identity(void)
{
    if(!bound || !card || card->Instance!=SDMMC1 ||
       card->SdCard.CardType!=CARD_SDHC_SDXC)return 0;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    if(card->SdCard.LogBlockNbr!=card_blocks)return 0;
#endif
    for(uint32_t i=0U;i<4U;i++)if(card->CID[i]!=card_cid[i])return 0;
    return 1;
}
static int wait_ready(uint32_t timeout_ms)
{
    uint32_t start=HAL_GetTick();
    for(;;){
        HAL_SD_CardStateTypeDef state=HAL_SD_GetCardState(card);
        if(card->ErrorCode || state==HAL_SD_CARD_ERROR)return -1;
        if(state==HAL_SD_CARD_TRANSFER)return 0;
        if(HAL_GetTick()-start>=timeout_ms)return -1;
    }
}
static int retire_metadata(uint32_t context)
{
    /* Polling HAL leaves Context set even after a successful DATAEND. Retire
     * only our completed single-sector transfer, after CMD13 confirms ready;
     * an active/error/foreign context must remain visible to startup guards. */
    if(!source_idle() || !bus_idle() ||
       (card->Instance->DCTRL&SDMMC_DCTRL_DTEN) || card->Context!=context)return -1;
    card->Context=SD_CONTEXT_NONE;return 0;
}
static int read_sector(void *user,uint32_t lba,uint8_t out[512])
{
    (void)user;
    if(!metadata_mode || !identity() || !source_idle() || !bus_idle() || !out ||
       card->Instance->CLKCR!=metadata_clock ||
       lba>=card->SdCard.LogBlockNbr)return -1;
    if(HAL_SD_ReadBlocks(card,read_buffer,lba,1U,1000U)!=HAL_OK ||
       wait_ready(1000U) || retire_metadata(SD_CONTEXT_READ_SINGLE_BLOCK))return -1;
    memcpy(out,read_buffer,512U);return 0;
}
static int write_sector(void *user,uint32_t lba,const uint8_t in[512])
{
    (void)user;
    if(!metadata_mode || !identity() || !source_idle() || !bus_idle() || !in ||
       card->Instance->CLKCR!=metadata_clock ||
       lba>=card->SdCard.LogBlockNbr)return -1;
    memcpy(write_buffer,in,512U);
    return HAL_SD_WriteBlocks(card,write_buffer,lba,1U,1000U)==HAL_OK &&
           wait_ready(1000U)==0 && retire_metadata(SD_CONTEXT_WRITE_SINGLE_BLOCK)==0?0:-1;
}
static int stopped_command(void *user,uint32_t argument)
{
    (void)user;
    if(!metadata_mode || !identity() || !source_idle() || !bus_idle())return -1;
    SDMMC_CmdInitTypeDef cmd={0};
    cmd.Argument=argument;cmd.CmdIndex=20U;cmd.Response=SDMMC_RESPONSE_SHORT;
    cmd.CPSM=SDMMC_CPSM_ENABLE;
    __SDMMC_CMDTRANS_DISABLE(card->Instance);
    __HAL_SD_CLEAR_FLAG(card,CMD_FLAGS);
    return SDMMC_SendCommand(card->Instance,&cmd)==HAL_OK &&
           !SDMMC_GetCmdResp1(card->Instance,20U,10U) && !wait_ready(1200U)?0:-1;
}
static int enter(void)
{
    if(metadata_mode || !identity() || !source_idle() || !bus_idle())return -1;
    HAL_NVIC_DisableIRQ(SDMMC1_IRQn);card->Instance->MASK=0U;
    HAL_NVIC_ClearPendingIRQ(SDMMC1_IRQn);
    /* Post-record verification may have lowered CLKDIV. Preserve the actual
     * stopped clock rather than assuming the original capture setting. */
    live_clock=card->Instance->CLKCR;
    metadata_clock=stopped_metadata_clock();
    card->Instance->CLKCR=metadata_clock;
    __DSB();metadata_mode=1U;return 0;
}
static int leave(void)
{
    if(!metadata_mode || !source_idle() || !bus_idle())return -1;
    metadata_mode=0U;card->Instance->CLKCR=live_clock;__DSB();
    return card->Instance->CLKCR==live_clock?0:-1;
}

int XE_NP_Np2DualSdCatalogPort_Bind(SD_HandleTypeDef *input)
{
    if(bound || !input || input->Instance!=SDMMC1 ||
       !XE_NP_Board_SdUhsReadyForNpRaw() ||
       input->SdCard.CardType!=CARD_SDHC_SDXC)return -1;
    card=input;
    if(card->Context!=SD_CONTEXT_NONE && bus_idle())card->Context=SD_CONTEXT_NONE;
    if(!source_idle() || !bus_idle())return -1;
    live_clock=card->Instance->CLKCR;
    memcpy(card_cid,card->CID,sizeof(card_cid));bound=1U;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    card_blocks=card->SdCard.LogBlockNbr;
#endif
    XE_NP_Np2DualSdCatalogIo io={0};
    io.read_sector=read_sector;io.write_sector=write_sector;
    io.stopped_command=stopped_command;
    io.card_blocks=card->SdCard.LogBlockNbr;memcpy(io.cid,card_cid,sizeof(io.cid));
    if(XE_NP_Np2DualSdCatalog_Bind(&io)){bound=0U;return -1;}
    return 0;
}
#if XE_NP_NP2_SD_CATALOG_ENABLE
int XE_NP_Np2DualSdCatalogPort_Ready(void)
{
    if(metadata_mode || !identity() || !source_idle() || !bus_idle() ||
       card->Context!=SD_CONTEXT_NONE || (card->Instance->DCTRL&SDMMC_DCTRL_DTEN) ||
       (card->Instance->STA&SDMMC_STA_BUSYD0) || (SPI1->CR1&SPI_CR1_SPE) ||
       (SPI2->CR1&SPI_CR1_SPE) || XE_NP_Np2UsbSource_IsBusy() || XE_NP_Np2UsbSource_IsReady())return 0;
    for(uint32_t ch=0U;ch<16U;ch++){
        const DMA_Channel_TypeDef *dma=(const DMA_Channel_TypeDef *)((uintptr_t)GPDMA1_Channel0+0x80U*ch);
        if(dma->CCR&(DMA_CCR_EN|DMA_CCR_SUSP|DMA_CCR_RESET))return 0;
    }
    return 1;
}
int XE_NP_Np2DualSdCatalogPort_Info(XE_NP_Np2DualSdCatalogInfo *out)
{
    if(!XE_NP_Np2DualSdCatalogPort_Ready() || enter())return 2;
    int result=XE_NP_Np2DualSdCatalog_Info(out);
    if(leave())result=10;return result;
}
int XE_NP_Np2DualSdCatalogPort_Entry(uint32_t token,uint32_t count,uint32_t ordinal,
                                    XE_NP_Np2DualSdCatalogEntry *out)
{
    if(!XE_NP_Np2DualSdCatalogPort_Ready() || enter())return 2;
    int result=XE_NP_Np2DualSdCatalog_Entry(token,count,ordinal,out);
    if(leave())result=10;return result;
}
int XE_NP_Np2DualSdCatalogPort_CheckDelete(const XE_NP_Np2DualSdCatalogDelete *request)
{
    if(!XE_NP_Np2DualSdCatalogPort_Ready() || enter())return 2;
    int result=XE_NP_Np2DualSdCatalog_CheckDelete(request);
    if(leave())result=10;return result;
}
int XE_NP_Np2DualSdCatalogPort_DeleteLast(const XE_NP_Np2DualSdCatalogDelete *request,uint32_t *next)
{
    if(!XE_NP_Np2DualSdCatalogPort_Ready() || enter())return 2;
    int result=XE_NP_Np2DualSdCatalog_DeleteLast(request,next);
    if(leave())result=10;return result;
}
#endif
int XE_NP_Np2DualSdCatalogPort_Format(uint32_t key,const uint8_t system_sector[512])
{
    if(enter())return -1;
    int result=XE_NP_Np2DualSdCatalog_Format(key,system_sector);
    if(leave())result=-1;return result;
}
int XE_NP_Np2DualSdCatalogPort_Mount(uint32_t *next_start_lba)
{
    if(enter())return -1;
    int result=XE_NP_Np2DualSdCatalog_Mount(next_start_lba);
    if(leave())result=-1;return result;
}
int XE_NP_Np2DualSdCatalogPort_Recover(uint32_t *next_start_lba)
{
    if(enter())return -1;
    int result=XE_NP_Np2DualSdCatalog_Recover(next_start_lba);
    if(leave())result=-1;return result;
}
int XE_NP_Np2DualSdCatalogPort_MountAvailable(uint32_t *next_start_lba)
{
    if(enter())return -1;
    int result=XE_NP_Np2DualSdCatalog_MountAvailable(next_start_lba);
    if(leave())result=-1;return result;
}
int XE_NP_Np2DualSdCatalogPort_Rewind(uint32_t key,uint32_t expected_start_lba,
                                     uint32_t *next_start_lba)
{
    if(enter())return -1;
    int result=XE_NP_Np2DualSdCatalog_Rewind(key,expected_start_lba,next_start_lba);
    if(leave())result=-1;return result;
}
int XE_NP_Np2DualSdCatalogPort_Plan(uint32_t sample_hz,uint32_t blocks,
                                   uint32_t session_id,uint32_t config_crc,
                                   XE_NP_Np2DualSdMeta *out)
{return XE_NP_Np2DualSdCatalogPort_PlanProfile(3U,sample_hz,blocks,session_id,config_crc,out);}
int XE_NP_Np2DualSdCatalogPort_PlanProfile(uint32_t mask,uint32_t sample_hz,
                                          uint32_t blocks,uint32_t session_id,
                                          uint32_t config_crc,XE_NP_Np2DualSdMeta *out)
{return XE_NP_Np2DualSdCatalog_PlanProfile(mask,sample_hz,blocks,session_id,config_crc,out);}
#if XE_NP_NP2_LIVE_SD_VSC_TEST
extern volatile uint32_t xe_np_sd_status_raw[16];
int XE_NP_Np2DualSdCatalogPort_PlanVsc(uint32_t sample_hz,uint32_t blocks,
                                      uint32_t session_id,uint32_t config_crc,
                                      XE_NP_Np2DualSdMeta *out)
{return XE_NP_Np2DualSdCatalogPort_PlanVscProfile(3U,sample_hz,blocks,session_id,config_crc,out);}
int XE_NP_Np2DualSdCatalogPort_PlanVscProfile(uint32_t mask,uint32_t sample_hz,
                                             uint32_t blocks,uint32_t session_id,
                                             uint32_t config_crc,XE_NP_Np2DualSdMeta *out)
{
    if(!XE_NP_Np2DualSd_ProfileTicks(mask,sample_hz))return -1;
    if(enter())return -1;
    HAL_SD_CardStatusTypeDef status={0};
    int result=-1;
    if(HAL_SD_GetCardStatus(card,&status)==HAL_OK && status.VideoSpeedClass>=30U && bus_idle()){
        const volatile uint8_t *raw=(const volatile uint8_t *)xe_np_sd_status_raw;
        uint32_t au=(((uint32_t)(raw[16]&3U)<<8U)|raw[17])*2048U;
        if(au && au<=1048576U)
            result=XE_NP_Np2DualSdCatalog_PlanAuProfile(mask,sample_hz,blocks,session_id,config_crc,au,out);
    }
    if(leave())result=-1;
    return result;
}
#if XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST
/* CARD_AU_PLANNER_BEGIN */
#if XE_NP_NP2_SD_CARD_AU_POLICY_TEST
int XE_NP_Np2DualSdCatalogPort_PlanCardAuProfile(uint32_t mask,uint32_t sample_hz,
                                                uint32_t blocks,uint32_t session_id,
                                                uint32_t config_crc,XE_NP_Np2DualSdMeta *out)
{
    if(!out || !XE_NP_Np2DualSd_ProfileTicks(mask,sample_hz) || enter())return -1;
    HAL_SD_CardStatusTypeDef status={0};
    int result=-1;
    if(HAL_SD_GetCardStatus(card,&status)==HAL_OK && bus_idle()){
        if(XE_NP_Np2LiveSd_UsesVscProfile(mask,sample_hz) && status.VideoSpeedClass>=30U){
            const volatile uint8_t *raw=(const volatile uint8_t *)xe_np_sd_status_raw;
            uint32_t au=(((uint32_t)(raw[16]&3U)<<8U)|raw[17])*2048U;
            if(au && au<=1048576U)
                result=XE_NP_Np2DualSdCatalog_PlanAuProfile(mask,sample_hz,blocks,session_id,config_crc,au,out);
        }else if(status.UhsSpeedGrade){
            uint32_t au=XE_NP_SdAuBlocks(status.UhsAllocationUnitSize);
            if(XE_NP_SdIsUhsAuBlocks(au))
                result=XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(mask,sample_hz,blocks,session_id,config_crc,au,out);
        }
    }
    if(leave())result=-1;
    return result;
}
#endif
/* CARD_AU_PLANNER_END */
int XE_NP_Np2DualSdCatalogPort_PlanLegacyAuProfile(uint32_t mask,uint32_t sample_hz,
                                                  uint32_t blocks,uint32_t session_id,
                                                  uint32_t config_crc,XE_NP_Np2DualSdMeta *out)
{
    if(!out || !XE_NP_Np2DualSd_ProfileTicks(mask,sample_hz) ||
       XE_NP_Np2LiveSd_UsesVscProfile(mask,sample_hz) || enter())return -1;
    HAL_SD_CardStatusTypeDef status={0};
    int result=-1;
    if(HAL_SD_GetCardStatus(card,&status)==HAL_OK && status.UhsSpeedGrade && bus_idle()){
        uint32_t au=XE_NP_SdAuBlocks(status.UhsAllocationUnitSize);
        if(XE_NP_SdIsUhsAuBlocks(au))
            result=XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(mask,sample_hz,blocks,session_id,config_crc,au,out);
    }
    if(leave())result=-1;
    return result;
}
#endif
static int prepare_directory(const XE_NP_Np2DualSdMeta *meta,uint32_t vsc)
{
    if(!meta || (vsc?(!meta->au_blocks || meta->legacy_au_blocks ||
                       meta->run.payload_start_lba%meta->au_blocks):
                      (meta->au_blocks || (meta->legacy_au_blocks &&
                       (!XE_NP_SdIsUhsAuBlocks(meta->legacy_au_blocks) ||
                        meta->run.payload_start_lba%meta->legacy_au_blocks)))) || enter())return -1;
    uint32_t lba=meta->reservation_start_lba+3U;
    int result=-1;
    /* Both legacy and Video Speed Class require UpdateDIR before Start.
     * Bind only the existing descriptor, without changing its bytes. VSC
     * Reserve already released all eight retained slots. Never called live. */
    if(lba>=meta->reservation_start_lba && lba<meta->run.payload_start_lba &&
       !read_sector(NULL,lba,read_buffer)){
        if(!stopped_command(NULL,vsc?0x18000000U:0x10000000U) && !write_sector(NULL,lba,read_buffer) &&
           !read_sector(NULL,lba,read_buffer) && !memcmp(write_buffer,read_buffer,512U))result=0;
    }
    /* Do not leave an uncertain UpdateDIR binding for the caller's failure
     * footer in VSC. Legacy has no ReleaseDIR; never send a VSC command or
     * retry a failed mutation there. Keep HAL/owner errors visible. */
    if(result && vsc && bus_idle())(void)stopped_command(NULL,0x88000000U);
    if(leave())result=-1;
    return result;
}
int XE_NP_Np2DualSdCatalogPort_PrepareVsc(const XE_NP_Np2DualSdMeta *meta)
{return prepare_directory(meta,1U);}
#if XE_NP_NP2_SD_VSC_FEED_TEST
int XE_NP_Np2DualSdCatalogPort_PrepareStoppedVscFeed(uint32_t catalog_front)
{
    const uint32_t start=XE_NP_NP2_SD_VSC_FEED_START;
    const uint32_t au=XE_NP_NP2_SD_VSC_FEED_AU;
    /* Reserve's retained-DIR cleanup without Reserve's real catalog writes.
     * The complete scratch range includes the preceding DIR-only AU. */
    if(!catalog_front || catalog_front>start-au || !identity() ||
       card->SdCard.LogBlockNbr!=1001390080U ||
       XE_NP_NP2_SD_VSC_FEED_END>card->SdCard.LogBlockNbr || enter())return -1;
    HAL_SD_CardStatusTypeDef status={0};
    int result=-1;
    if(HAL_SD_GetCardStatus(card,&status)==HAL_OK && status.VideoSpeedClass>=30U && bus_idle()){
        const volatile uint8_t *raw=(const volatile uint8_t *)xe_np_sd_status_raw;
        uint32_t reported=(((uint32_t)(raw[16]&3U)<<8U)|raw[17])*2048U;
        if(reported==au){
            result=0;
            for(uint32_t slot=0U;slot<8U;slot++)
                if(stopped_command(NULL,0x88000000U|(slot<<24U))){result=-1;break;}
        }
    }
    if(leave())result=-1;
    if(result)return -1;
    XE_NP_Np2DualSdMeta scratch={0};
    scratch.reservation_start_lba=start-au;scratch.run.payload_start_lba=start;
    scratch.au_blocks=au;
    /* Reads/rewrites only start-au+3 unchanged, never a real descriptor. */
    return prepare_directory(&scratch,1U);
}
#endif
int XE_NP_Np2DualSdCatalogPort_PrepareClassic(const XE_NP_Np2DualSdMeta *meta)
{return prepare_directory(meta,0U);}
#endif
int XE_NP_Np2DualSdCatalogPort_Reserve(const XE_NP_Np2DualSdMeta *meta,
                                      const uint8_t configuration[2048])
{
    if(enter())return -1;
    int result=XE_NP_Np2DualSdCatalog_Reserve(meta,configuration);
    if(leave())result=-1;return result;
}
int XE_NP_Np2DualSdCatalogPort_CheckpointWritten(uint32_t blocks)
{
    if(enter())return -1;
    int result=XE_NP_Np2DualSdCatalog_CheckpointWritten(blocks);
    if(leave())result=-1;return result;
}
int XE_NP_Np2DualSdCatalogPort_Finish(uint32_t state,uint32_t error,uint32_t blocks)
{
    if(enter())return -1;
    int result=XE_NP_Np2DualSdCatalog_Finish(state,error,blocks);
    if(leave())result=-1;return result;
}
int XE_NP_Np2DualSdCatalogPort_Time(const uint8_t sector[512])
{
    if(enter())return -1;
    int result=XE_NP_Np2DualSdCatalog_Time(sector);
    if(leave())result=-1;return result;
}
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
int XE_NP_Np2DualSdCatalogPort_ReserveAppend(const XE_NP_Np2DualSdMeta *meta,const uint8_t config[2048])
{
    if(!meta || !config || enter())return -1;
    int result=XE_NP_Np2DualSdCatalog_ReserveAppend(meta,config);
    if(leave())result=-1;return result;
}
int XE_NP_Np2DualSdCatalogPort_CheckpointAppend(const XE_NP_Np2SdAppendCounts *counts)
{
    if(!counts || enter())return -1;
    int result=XE_NP_Np2DualSdCatalog_CheckpointAppend(counts);
    if(leave())result=-1;return result;
}
int XE_NP_Np2DualSdCatalogPort_FinishAppend(uint32_t state,uint32_t error,const XE_NP_Np2SdAppendCounts *counts)
{
    if(!counts || enter())return -1;
    int result=XE_NP_Np2DualSdCatalog_FinishAppend(state,error,counts);
    if(leave())result=-1;return result;
}
#endif
#endif
