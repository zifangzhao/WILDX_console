#include "xe_np_np2_sd_control.h"
#include "xe_np_np2_dual_sd_app.h"
#include "xe_np_np2_live_sd.h"
#include "xe_np_np2_dual_sd_run.h"
#include "xe_np_np2_dual_sd_catalog.h"
#if XE_NP_NP2_SD_CATALOG_ENABLE
#include "xe_np_np2_dual_sd_catalog_port.h"
#endif
#include <string.h>
#if XE_NP_NP2_DUAL_SD_APP_ENABLE
static uint32_t selected_hz,last_id,pending_mode;
static uint8_t last_request[64];
static uint32_t last_error;
static uint32_t start_nonce,start_state,start_blocks,start_hz,start_mask;
static uint32_t get(const uint8_t *p)
{return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static void put(uint8_t *p,uint32_t v)
{for(unsigned i=0;i<4;i++)p[i]=(uint8_t)(v>>(i*8));}
static uint32_t crc(const uint8_t *p)
{
    uint32_t c=~0U;
    for(unsigned n=0;n<60;n++){c^=p[n];for(unsigned b=0;b<8;b++)c=(c>>1)^((0U-(c&1U))&0xEDB88320U);}
    return ~c;
}
void XE_NP_Np2SdControl_Init(void)
{selected_hz=20000U;last_id=last_error=pending_mode=start_nonce=0U;memset(last_request,0,sizeof(last_request));}
uint32_t XE_NP_Np2SdControl_PendingMode(void){return pending_mode;}
uint32_t XE_NP_Np2SdControl_TakeMode(void){uint32_t mode=pending_mode;pending_mode=0;return mode;}
void XE_NP_Np2SdControl_CancelMode(void)
{if(pending_mode){pending_mode=0;if(!last_error && get(last_request+8)==5U)last_error=7U;}}
uint32_t XE_NP_Np2SdControl_PendingStart(void)
{
    const volatile XE_NP_Np2DualSdAppMailbox *m=&xe_np_np2_dual_sd_app_mailbox;
    /* Once accepted/replaced, this receipt cannot acquire ownership again.
     * The original idle state excludes PREPARING/ARMED/RECORDING work. */
    if(start_nonce && (m->command!=XE_NP_NP2_DUAL_SD_CMD_START || m->nonce!=start_nonce ||
       m->accepted_nonce==start_nonce || m->state!=start_state || m->error ||
       m->key!=XE_NP_NP2_DUAL_SD_START_KEY || m->requested_blocks!=start_blocks || m->sample_hz!=start_hz ||
       XE_NP_Np2DualSdApp_ProfileMask()!=start_mask))
        start_nonce=0U;
    return start_nonce;
}
void XE_NP_Np2SdControl_CancelStart(uint32_t nonce)
{
    if(!nonce || XE_NP_Np2SdControl_PendingStart()!=nonce)return;
    XE_NP_Np2DualSdApp_CancelSchedule();
    xe_np_np2_dual_sd_app_mailbox.command=XE_NP_NP2_DUAL_SD_CMD_NONE;
    start_nonce=0U;
    /* Match the mode timeout receipt, not a sticky recording/device fault.
     * A later rejected mutation may already supersede this cached receipt. */
    if(last_id==nonce && !last_error && (get(last_request+8)==2U || get(last_request+8)==4U))last_error=7U;
}
static void response(uint8_t *out,uint32_t op,uint32_t id,uint32_t error)
{
    const volatile XE_NP_Np2DualSdAppMailbox *m=&xe_np_np2_dual_sd_app_mailbox;
    uint32_t state=m->state;
    uint32_t flags=128U|256U|512U|1024U|2048U|4096U|8192U|16384U|32768U;
    flags|=XE_NP_NP2_SD_CAP_STORED_7500;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    flags|=XE_NP_NP2_SD_CAP_CATALOG;
#endif
    if(XE_NP_Np2LiveSd_SupportsProfile(1U,7500U))flags|=XE_NP_NP2_SD_CAP_RATE_7500;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    flags|=XE_NP_Np2DualSdCatalog_Status()&~XE_NP_NP2_CATALOG_REWIND_AVAILABLE;
#else
    flags|=XE_NP_Np2DualSdCatalog_Status(); /* cached stopped-time state, no SD I/O */
#endif
    if(state!=XE_NP_NP2_DUAL_SD_UNMOUNTED && state!=XE_NP_NP2_DUAL_SD_FAILED)flags|=17U;
    if((state>=2U && state<=4U) || state==6U)flags|=4U;
    if(m->command || pending_mode)flags|=8U;
    if(state==255U)flags|=64U;
    uint32_t blocks=m->committed_blocks;
    uint32_t rate=(state>=2U && state<=4U) || state==6U?m->sample_hz:selected_hz;
    if(state>=2U && state<=4U)blocks=xe_np_np2_live_sd_mailbox.written_rus*4U;
    uint32_t words[15]={XE_NP_NP2_SD_CONTROL_REPLY,2U,op,id,error,state,
        m->error?m->error:m->command_error,XE_NP_Np2DualSdApp_ProfileMask(),rate,blocks,m->next_start_lba,m->reservation_end_lba,
        m->card_blocks,flags,last_id};
    for(unsigned i=0;i<15;i++)put(out+i*4,words[i]);
    put(out+60,crc(out));
}
#if XE_NP_NP2_SD_CATALOG_ENABLE
static uint32_t catalog_admission(void)
{
    const volatile XE_NP_Np2DualSdAppMailbox *m=&xe_np_np2_dual_sd_app_mailbox;
    if(m->command || pending_mode)return 2U;
    if(m->state!=1U && m->state!=5U && m->state!=7U)
        return m->state==0U || m->state==255U?8U:2U;
    if(m->error)return 8U;
    return XE_NP_Np2DualSdApp_CatalogReady()?0U:2U;
}
static void catalog_response(uint8_t out[64],uint32_t op,uint32_t id,const uint32_t fields[10])
{
    put(out,XE_NP_NP2_SD_CONTROL_REPLY);put(out+4,2U);put(out+8,op);put(out+12,id);put(out+16,0U);
    for(unsigned i=0U;i<10U;i++)put(out+20U+4U*i,fields[i]);
    put(out+60,crc(out));
}
#endif
int XE_NP_Np2SdControl_Exchange(const uint8_t in[64],uint8_t out[64])
{
    if(!in || !out || get(in)!=XE_NP_NP2_SD_CONTROL_REQUEST ||
       get(in+4)!=2U || !get(in+12) || get(in+60)!=crc(in))return -1;
    uint32_t op=get(in+8),id=get(in+12),error=0U;
    volatile XE_NP_Np2DualSdAppMailbox *m=&xe_np_np2_dual_sd_app_mailbox;
    /* STATUS is read-only and does not consume mutation IDs. */
    if(op==0U){response(out,op,id,0U);return 0;}
#if XE_NP_NP2_SD_CATALOG_ENABLE
    /* Catalog reads likewise never advance/reject against the mutation ID. */
    if(op==9U || op==10U){
        for(unsigned i=op==9U?16U:28U;i<60U;i++)if(in[i])error=1U;
        if(!error)error=catalog_admission();
        if(!error && op==9U){
            XE_NP_Np2DualSdCatalogInfo info;
            error=(uint32_t)XE_NP_Np2DualSdCatalogPort_Info(&info);
            if(!error){
                uint32_t fields[10]={info.token,info.count,info.next,info.card_blocks,info.cid_crc,
                    info.flags&~XE_NP_NP2_CATALOG_REWIND_AVAILABLE,
                    info.last_ordinal,info.last_start,info.last_end,info.last_cookie};
                catalog_response(out,op,id,fields);return 0;
            }
        }else if(!error){
            XE_NP_Np2DualSdCatalogEntry e;
            error=(uint32_t)XE_NP_Np2DualSdCatalogPort_Entry(get(in+16),get(in+20),get(in+24),&e);
            if(!error){
                uint32_t fields[10]={e.token,e.count,e.ordinal,e.start,e.end,e.cookie,e.session,
                    e.sample_hz,e.probe_mask,e.flags};
                catalog_response(out,op,id,fields);return 0;
            }
        }
        response(out,op,id,error);return 0;
    }
#endif
    if(id==last_id){
        response(out,op,id,memcmp(in,last_request,64)?6U:last_error);return 0;
    }
    if(last_id && (int32_t)(id-last_id)<=0){response(out,op,id,6U);return 0;}
    if(id==m->accepted_nonce){response(out,op,id,6U);return 0;}
#if XE_NP_NP2_SD_CATALOG_ENABLE
    for(unsigned i=op==11U?44U:op==4U?36U:28U;i<60;i++)if(in[i])error=1U;
#else
    for(unsigned i=op==4U?36U:28U;i<60;i++)if(in[i])error=1U;
#endif
    if(m->command || pending_mode)error=2U;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    if(!error && op==11U){
        error=catalog_admission();
        if(!error && get(in+40)!=XE_NP_NP2_CATALOG_DELETE_KEY)error=3U;
        if(!error){
            XE_NP_Np2DualSdCatalogDelete r={get(in+16),get(in+20),get(in+24),get(in+28),get(in+32),get(in+36)};
            error=(uint32_t)XE_NP_Np2DualSdApp_QueueDelete(id,&r);
        }
    }else
#endif
    if(!error && (op==1U || op==2U || op==4U)){
        if(m->state!=1U && m->state!=5U && m->state!=7U && !(op==1U && m->state==0U))error=2U;
        else if(!XE_NP_Np2DualSd_ProfileTicks(get(in+16),get(in+20)) ||
                !XE_NP_Np2LiveSd_SupportsProfile(get(in+16),get(in+20)))error=3U;
        else if(op==1U){
            if(get(in+24) || XE_NP_Np2DualSdApp_SelectProfile(get(in+16),get(in+20)))error=3U;
            else selected_hz=get(in+20);
        }else{
            if(XE_NP_Np2DualSdCatalog_Status()&~XE_NP_NP2_CATALOG_DEGRADED){
                error=8U;goto done; /* Mounted but full or recovery required. */
            }
            uint32_t blocks=get(in+24);
            uint64_t payload=((uint64_t)m->next_start_lba+8192U+16383U)&~UINT64_C(16383);
            uint64_t end=m->card_blocks&~UINT64_C(16383);
            uint64_t available=end>payload?(end-payload)/XE_NP_NP2_DUAL_SD_SECTORS_PER_RU*4U:0U;
            if(!blocks)blocks=(uint32_t)available; /* continuous: until Stop or card capacity */
            if(get(in+16)!=XE_NP_Np2DualSdApp_ProfileMask() || get(in+20)!=selected_hz || blocks<4U || blocks%4U ||
               m->next_start_lba<8192U || blocks>available)error=3U;
            else if(op==4U && !get(in+28) && !get(in+32))error=3U;
            else if(XE_NP_Np2DualSdApp_Schedule(op==4U?
                (uint64_t)get(in+28)|((uint64_t)get(in+32)<<32U):0U))error=3U;
            else{
                m->nonce=id;m->key=XE_NP_NP2_DUAL_SD_START_KEY;
                m->requested_blocks=blocks;m->sample_hz=selected_hz;
                m->command=XE_NP_NP2_DUAL_SD_CMD_START;
                start_nonce=id;start_state=m->state;start_blocks=blocks;start_hz=selected_hz;
                start_mask=XE_NP_Np2DualSdApp_ProfileMask();
            }
        }
    }else if(!error && op==3U){
        if(get(in+16) || get(in+20) || get(in+24))error=1U;
        else if(m->state==XE_NP_NP2_DUAL_SD_PREPARING || m->state==XE_NP_NP2_DUAL_SD_RECORDING ||
                m->state==XE_NP_NP2_DUAL_SD_ARMED){
            m->nonce=id;m->key=0;m->command=XE_NP_NP2_DUAL_SD_CMD_STOP;
        }else if(m->state!=XE_NP_NP2_DUAL_SD_UNMOUNTED && m->state!=XE_NP_NP2_DUAL_SD_IDLE &&
                 m->state!=XE_NP_NP2_DUAL_SD_FINALIZING && m->state!=XE_NP_NP2_DUAL_SD_COMPLETE &&
                 m->state!=XE_NP_NP2_DUAL_SD_CANCELLED)error=2U;
        /* Like V1, Stop while draining/stopped is an accepted no-op. The
         * response retains the actual state, counters and any device fault. */
    }else if(!error && op==5U){
        uint32_t mode=get(in+16);
        /* Updating firmware must not require a mounted recording catalog. */
        if(m->state!=0U && m->state!=1U && m->state!=5U && m->state!=7U)error=2U;
        else if(m->error || m->command_error)error=2U;
        else if(mode<1U || mode>3U || get(in+20) || get(in+24))error=3U;
        else if(!XE_NP_Np2SdBle_ModeAvailable(mode))error=7U;
        else pending_mode=mode; /* Execute only AFTER this ACK drains. */
    }else if(!error && (op==6U || op==7U || op==8U)){
        /* Mount is read-only. Format requires its explicit destructive key.
           Both queue once, outside interrupt/recording services. */
        if((m->state!=0U && m->state!=1U) || m->error || !m->card_blocks)error=2U;
        else if(get(in+16)!=(op==7U?XE_NP_NP2_DUAL_SD_FORMAT_KEY:0U) || get(in+20) || get(in+24))error=3U;
        else {m->nonce=id;m->key=get(in+16);
            m->command=op==7U?XE_NP_NP2_DUAL_SD_CMD_FORMAT:op==8U?
                XE_NP_NP2_DUAL_SD_CMD_RECOVER:XE_NP_NP2_DUAL_SD_CMD_MOUNT;}
    }else if(!error)error=4U;
done:
    last_id=id;last_error=error;memcpy(last_request,in,64);
    response(out,op,id,error);return 0;
}
#endif
