#ifndef XE_NP_NP2_DUAL_SD_RUN_H
#define XE_NP_NP2_DUAL_SD_RUN_H

#include <stdint.h>

/* Prefix masks 1/3/7 at 15/20/30 kHz share sector/RU geometry. One/two
 * probes use packed PSSI; three preserve raw PSSI8 plus SPI2 D8. Profile
 * admission describes the format, not sustained hardware qualification. */
#define XE_NP_NP2_SINGLE_SD_TICKS_PER_BLOCK 122880U
#define XE_NP_NP2_DUAL_SD_TICKS_PER_BLOCK 61440U
#define XE_NP_NP2_TRIPLE_SD_TICKS_PER_BLOCK 40960U
#define XE_NP_NP2_DUAL_SD_BYTES_PER_BLOCK 46592U
#define XE_NP_NP2_DUAL_SD_SECTORS_PER_BLOCK 91U
#define XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU 4U
#define XE_NP_NP2_DUAL_SD_SECTORS_PER_RU 364U

typedef struct {
    uint32_t probe_mask,sample_hz,mclk_hz;
    uint32_t payload_start_lba,payload_end_lba;
    uint32_t max_rus,max_blocks;
    uint64_t max_source_ticks,max_duration_ms;
} XE_NP_Np2DualSdRun;

/* Closed mask/rate admission; zero means unsupported, never a default. */
uint32_t XE_NP_Np2DualSd_ProfileTicks(uint32_t probe_mask,uint32_t sample_hz);

/* The caller owns reservation and metadata. This only admits a whole-RU
 * payload extent on one card; end is exclusive. No card access occurs. */
int XE_NP_Np2DualSd_PlanProfile(uint32_t probe_mask,uint32_t sample_hz,
                               uint32_t payload_start_lba,uint32_t payload_end_lba,
                               uint32_t card_blocks,XE_NP_Np2DualSdRun *out);
/* Legacy API remains a packed dual-probe wrapper. */
int XE_NP_Np2DualSd_Plan(uint32_t sample_hz,uint32_t payload_start_lba,
                        uint32_t payload_end_lba,uint32_t card_blocks,
                        XE_NP_Np2DualSdRun *out);

/* Stop after the current whole RU (or one RU if stopped before the first
 * block). Include an in-progress pack block and all source ticks already
 * published by PSSI DMA, even if packing trails the acquisition ring.
 * Zero means invalid/out of bounds, never a successful empty run. */
uint32_t XE_NP_Np2DualSd_StopTarget(uint32_t produced_blocks,uint32_t partial_block,
                                    uint64_t sampled_ticks,
                                    const XE_NP_Np2DualSdRun *run);

#endif
