#ifndef XE_NP_NP2_SESSION_H
#define XE_NP_NP2_SESSION_H
#include "xe_np_np2_control.h"
#include "xe_np_np2_phase.h"

/* Foreground-only dual-NP2 control -> warmup -> unique phase -> packed stream.
 * Does not own the SD scheduler or publish COMPLETE recording metadata. The
 * app must finish stopped-only storage setup BEFORE starting this session.
 * The cold power/MCO/shared-NRST sequence is an explicit external prerequisite.
 * No initialized session may be reset/reused to hide a producer discontinuity. */
#define XE_NP_NP2_SESSION_CONFIG_TIMEOUT_MS 360000U
#define XE_NP_NP2_SESSION_START_TIMEOUT_MS 2000U
#define XE_NP_NP2_SESSION_SPAN_TIMEOUT_MS 10U
enum { XE_NP_NP2_SESSION_EMPTY=0, XE_NP_NP2_SESSION_CONFIGURING,
       XE_NP_NP2_SESSION_STARTING, XE_NP_NP2_SESSION_PRELUDE,
       XE_NP_NP2_SESSION_ALIGNING, XE_NP_NP2_SESSION_READY,
       XE_NP_NP2_SESSION_RECORDING, XE_NP_NP2_SESSION_FAILED,
       XE_NP_NP2_SESSION_STOPPED };
enum { XE_NP_NP2_SESSION_ERROR_NONE=0, XE_NP_NP2_SESSION_ERROR_ARGUMENT,
       XE_NP_NP2_SESSION_ERROR_CONTROL, XE_NP_NP2_SESSION_ERROR_ARM,
       XE_NP_NP2_SESSION_ERROR_SOURCE, XE_NP_NP2_SESSION_ERROR_RETENTION,
       XE_NP_NP2_SESSION_ERROR_PHASE, XE_NP_NP2_SESSION_ERROR_WIRE,
       XE_NP_NP2_SESSION_ERROR_PACK, XE_NP_NP2_SESSION_ERROR_TIMEOUT,
       XE_NP_NP2_SESSION_ERROR_CANCELLED };

typedef struct {
    const uint8_t *data;
    uint32_t ticks; /* logical PSSI clock ticks */
    uint32_t bytes; /* immutable bytes owned by this span */
    uint64_t source_end;
} XE_NP_Np2Span;

typedef struct {
    void *user;
    /* Arm exact 48 MHz, rising-edge, mask3 one-byte PSSI and its lossless export
     * BEFORE either REC reset release. Initialize producer accounting/export
     * before DMA starts. Return its absolute first source tick (normally zero).
     * Must not arm an already active producer or touch SD/I2C/clock/reset. */
    int (*arm)(void *, uint64_t *first_source);
    /* Fresh monotonic producer total and clock/hardware/IRQ/queue health. Zero only
     * when still armed with no latched error. Caller must not fabricate a
     * contiguous counter over missed/duplicated DMA notifications. */
    int (*status)(void *, uint64_t *produced);
    /* Conservative UPPER bound on ticks captured before this call, including
     * an active partial DMA block and pending IRQ publication. Called after
     * both reset releases complete. A completed-block counter alone is NOT
     * sufficient. The port may add a proven unpublished-node bound only after
     * rejecting ambiguous/missed DMA progress; never guess or reset counters. */
    int (*post_release_barrier)(void *, uint64_t *barrier);
    /* 1=borrowed span, 0=none, <0=fault. Bound by maximum ticks, in 128-tick
     * quanta, contiguous in memory. Hold ownership until release or safe_stop.
     * Check fresh source health/retention before either lending or returning
     * no data; callers need not duplicate status() immediately before take().
     * The driver's independent recording guard also enforces all source spans. */
    int (*take)(void *, uint32_t maximum, XE_NP_Np2Span *);
    int (*retained)(void *, const XE_NP_Np2Span *);
    void (*invalidate)(void *, const uint8_t *, uint32_t);
    /* Commit consumer position under the same lock as IRQ fault publication.
     * Zero only if the held span was released with no latched source fault. */
    int (*release)(void *);
    uint32_t (*now_ms)(void *);
    /* After control.safe_stop: final stopped producer health/committed total.
     * Must retain faults observed while quiescing; an unconditional success
     * here would hide the race between the last live check and source stop. */
    int (*stopped_status)(void *, uint64_t *produced);
} XE_NP_Np2ProducerIo;

typedef struct {
    XE_NP_Np2Control control; /* immutable configuration and I2C lifetime */
    XE_NP_Np2Phase phase;    /* private prelude, no additional raw staging */
    XE_NP_Np2Wire wire;
    XE_NP_Np2ProducerIo producer;
    uint64_t source_origin, next_source, last_produced, running_barrier;
    uint64_t warmup_ticks, packed_ticks;
    uint32_t began_ms, armed_ms, max_span_ms;
    uint8_t state, error, armed, admission_requested;
} XE_NP_Np2Session;

/* Fresh zero-initialized session. Validates all callbacks before accepting
 * ownership; images are snapshotted by the actual control engine. Invalid
 * accepted startup triggers its mandatory hardware safe_stop hook. */
int XE_NP_Np2Session_Begin(XE_NP_Np2Session *, const XE_NP_Np2ControlIo *,
                         const XE_NP_Np2ProducerIo *, const XE_NP_Np2ProbeImage[2],
                         const XE_NP_Np2Startup *, uint8_t digital_test);
/* One control start/poll and at most one <=65536-tick warmup span plus 256
 * phase steps per call. Continuously call this during slow reset release.
 * READY drains warmup until the first Pack request. That request stops further
 * warmup discards even if no completed DMA span is available until later.
 * RECORDING never discards data or performs control-bus transactions. */
void XE_NP_Np2Session_Service(XE_NP_Np2Session *);
/* 1=packed owned span; 0=not ready/no data; -1=terminal fault. Only after return1
 * may the scheduler publish written bytes/source extent. Destination MUST be
 * scheduler-owned, disjoint from live ring/state, with capacity >=maximum*3/4.
 * Output pointers must also be caller-owned and disjoint from all data/state.
 * Validation + packing + retention/deadline checks precede guard publication.
 * On failure the private destination may contain uncommitted bytes: never
 * submit them to SD or retry the span. Max input must be 128..65536, /128. */
int XE_NP_Np2Session_Pack(XE_NP_Np2Session *, uint32_t maximum,
                        uint8_t *destination,uint32_t capacity,
                        uint32_t *written, uint64_t *source_start);
/* Stop after the SD scheduler finishes admitting its last full RU. This stops
 * only the source; storage must still drain/finalize independently. It does
 * not declare a recording complete. Abort latches an incomplete session. */
void XE_NP_Np2Session_Stop(XE_NP_Np2Session *);
void XE_NP_Np2Session_Abort(XE_NP_Np2Session *);
#endif
