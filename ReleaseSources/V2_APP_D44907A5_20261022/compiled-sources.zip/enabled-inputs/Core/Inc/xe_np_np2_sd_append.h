#ifndef XE_NP_NP2_SD_APPEND_H
#define XE_NP_NP2_SD_APPEND_H

#include "xe_np_np2_dual_sd_meta.h"

/* Explicit opt-in metadata, not a native NP2USB03 header or BLE status flag.
 * Legacy v11/v12/v13 codecs and their ABI deliberately remain unchanged. */
#define XE_NP_NP2_SD_APPEND_VERSION 14U
#define XE_NP_NP2_SD_APPEND_FLAG 0x40U
#define XE_NP_NP2_SD_APPEND_PREFIX_OFFSET 132U
#define XE_NP_NP2_SD_APPEND_HIGH_WATER_OFFSET 136U

typedef struct {
    uint32_t physical_blocks;
    uint32_t logical_prefix_blocks;
    uint32_t logical_high_water_blocks;
} XE_NP_Np2SdAppendCounts;

/* Cold/stopped metadata only. Keep each original native sequence/source tick.
 * Footer108/112/116 describe the dense durable physical extent; 120 is stored
 * tick QUANTITY, not logical elapsed time. Prefix132 is the gap-free logical
 * block count; high-water136 is the exclusive largest stored sequence + 1.
 * All counts are whole four-block RUs. COMPLETE and VERI require equal counts,
 * but callers must independently prove unique payload coverage/readback.
 * A failed physical RU order0,2 has counts {8,4,12}, never prefix8.
 * Descriptor132..507 and footer140..507 are zero. CRC remains at508.
 * No application/catalog/host path opts in merely by linking these functions. */
int XE_NP_Np2SdAppend_EncodeDescriptor(uint8_t out[512],const XE_NP_Np2DualSdMeta *meta);
int XE_NP_Np2SdAppend_DecodeDescriptor(const uint8_t sector[512],XE_NP_Np2DualSdMeta *out);
int XE_NP_Np2SdAppend_EncodeFooter(uint8_t out[512],const XE_NP_Np2DualSdMeta *meta,
                                  uint32_t state,uint32_t error,
                                  const XE_NP_Np2SdAppendCounts *counts);
int XE_NP_Np2SdAppend_DecodeFooter(const uint8_t descriptor[512],const uint8_t footer[512],
                                  uint32_t *state,uint32_t *error,
                                  XE_NP_Np2SdAppendCounts *counts);

#endif
