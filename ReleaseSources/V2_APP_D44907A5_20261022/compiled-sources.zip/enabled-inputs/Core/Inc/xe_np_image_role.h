#ifndef XE_NP_IMAGE_ROLE_H
#define XE_NP_IMAGE_ROLE_H
#define XE_NP_IMAGE_COMBINED 0U /* compatibility/bring-up image only */
#define XE_NP_IMAGE_SD_APP 1U
#define XE_NP_IMAGE_USB_SERVICE 2U
#ifndef XE_NP_IMAGE_ROLE
#define XE_NP_IMAGE_ROLE XE_NP_IMAGE_COMBINED
#endif
#if (XE_NP_IMAGE_ROLE > XE_NP_IMAGE_USB_SERVICE)
#error "Invalid XE_NP image role"
#endif
#endif
