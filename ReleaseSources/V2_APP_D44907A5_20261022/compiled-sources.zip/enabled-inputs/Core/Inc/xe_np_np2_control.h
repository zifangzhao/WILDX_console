#ifndef XE_NP_NP2_CONTROL_H
#define XE_NP_NP2_CONTROL_H
#include <stdint.h>
#include "xe_np_np2_transport.h"

/* NP2 generation only. imec V1.2 pp.30-45,49-52. Fig.17/19 send
 * 00100000 / 00100001: the 7-bit address is 0x10, HAL DevAddress is 0x20.
 * This driver never writes PROBE_ID, reserved registers or EEPROM. It writes
 * SOFT_RESET only as the required 0xFF/0x00 pair before each SR pass. */
#define XE_NP_NP2_I2C_ADDRESS7 0x10U
#define XE_NP_NP2_I2C_ADDRESS_WIRE (XE_NP_NP2_I2C_ADDRESS7 << 1U)
#define XE_NP_NP2_SHANK_BYTES 161U
#define XE_NP_NP2_BASE_BYTES 96U
#define XE_NP_NP2_SYNC_BYTES 12U
#define XE_NP_NP2_I2C_TIMEOUT_MS 100U
#define XE_NP_NP2_ANALOG_SETTLE_MS 10000U /* conservative startup policy */
#define XE_NP_NP2_DIGITAL_SETTLE_MS 1U

typedef struct {
    /* Exactly 1 or 4 shanks. All installed shanks AND both base chains must
     * be explicitly configured: NRST does not clear these shift registers.
     * Bytes are in transmitted order, not channel/electrode order. The driver
     * checks transfer integrity, NOT the scientific validity of this mapping. */
    uint8_t shank_count;
    uint8_t shank[4][XE_NP_NP2_SHANK_BYTES];
    uint8_t base_even[XE_NP_NP2_BASE_BYTES];
    uint8_t base_odd[XE_NP_NP2_BASE_BYTES];
    /* Byte n contains SS[8n+7:8n]. Host chronological bit i is
     * (supersync[i/8] >> (i%8)) & 1, NOT MSB-first byte unpacking. */
    uint8_t supersync[XE_NP_NP2_SYNC_BYTES];
} XE_NP_Np2ProbeImage;

enum { XE_NP_NP2_BUS_FIRST = 2, XE_NP_NP2_BUS_SECOND = 3 };
enum { XE_NP_NP2_IO_DONE = 0, XE_NP_NP2_IO_BUSY = 1 };
enum { XE_NP_NP2_CTL_IDLE = 0, XE_NP_NP2_CTL_CONFIGURING,
       XE_NP_NP2_CTL_SETTLING, XE_NP_NP2_CTL_READY,
       XE_NP_NP2_CTL_STARTING, XE_NP_NP2_CTL_RUNNING, XE_NP_NP2_CTL_FAULT };
enum { XE_NP_NP2_ERR_NONE = 0, XE_NP_NP2_ERR_ARGUMENT,
       XE_NP_NP2_ERR_PRECONDITION, XE_NP_NP2_ERR_I2C_START,
       XE_NP_NP2_ERR_I2C_COMPLETE, XE_NP_NP2_ERR_TIMEOUT,
       XE_NP_NP2_ERR_READBACK, XE_NP_NP2_ERR_SHIFT_COMPARE,
       XE_NP_NP2_ERR_CAPTURE_NOT_ARMED, XE_NP_NP2_ERR_CANCELLED };

typedef struct {
    uint8_t bus; /* actual I2C peripheral number: 2=U$1, 3=U$3 */
    uint8_t address_wire;
    uint8_t reg;
    uint8_t write; /* 0: one-byte register read with repeated START; 1: write */
    uint8_t value;
} XE_NP_Np2Transaction;

typedef struct {
    void *user;
    /* Must be NONBLOCKING. start: DONE=accepted, BUSY=not accepted, <0=error.
     * poll: BUSY=pending, DONE=completed (read value set), <0=error.
     * Single in-flight operation; request lifetime extends to completion/abort.
     * Each shift byte is a separate addressed transaction. Never auto-increment
     * a multi-byte write past an SRCHAIN register into a different register. */
    int (*start)(void *, const XE_NP_Np2Transaction *);
    int (*poll)(void *, uint8_t *read_value);
    /* Called once on terminal failure/cancel: synchronously abort pending I2C,
     * stop/invalidate acquisition, and assert the SHARED PE13 NRST for BOTH
     * probes. Must not wait for an I2C command to make the system safe. */
    void (*safe_stop)(void *);
    /* Must confirm DMA/PSSI armed AND its service remains active. Checked on
     * every STARTING service, including between the two reset releases.
     * Does not establish wire frame phase or producer continuity. */
    int (*capture_armed)(void *);
} XE_NP_Np2ControlIo;

typedef struct {
    uint32_t mclk_hz;
    uint32_t hclk_hz;
    /* External coordinator attests the guide p.50 sequence has completed:
     * stable 1.8 V >=10 ms BEFORE 48 MHz MCLK; >=10 clocks before NRST low,
     * >=10 clocks held low, then high. Must also establish the fitted PDCK
     * route and high-speed/voltage setup before arming actual capture.
     * This is a software prerequisite, not a physical voltage/clock test. */
    uint8_t hardware_startup_complete;
    /* Zero preserves the historical dual-probe behavior. A single-probe
     * caller must select FIRST or SECOND explicitly. */
    uint8_t active_probe_mask;
} XE_NP_Np2Startup;

typedef struct {
    XE_NP_Np2ControlIo io;
    XE_NP_Np2ProbeImage image[2]; /* private immutable snapshot after Begin */
    XE_NP_Np2Transaction transaction;
    uint32_t operation_since_ms;
    uint32_t settle_since_ms;
    uint32_t completed_transactions;
    uint16_t byte_index;
    uint8_t state, error, probe, step, chain, pass, sync_index, active_mask;
    uint8_t operation_pending, operation_accepted, expected, compare_mask;
    uint8_t last_read, digital_test, initialized;
} XE_NP_Np2Control;

/* Requires a ZERO-INITIALIZED object; rejects reinitialization. Never clear or
 * reuse the object while a request could still own it. For another session:
 * Stop, detach/abort the port, repeat external hardware startup, then create
 * a fresh zero-initialized controller and bind the reinitialized HAL handles. */
int XE_NP_Np2Control_Init(XE_NP_Np2Control *, const XE_NP_Np2ControlIo *);
int XE_NP_Np2Control_Begin(XE_NP_Np2Control *, const XE_NP_Np2ProbeImage images[2],
                         const XE_NP_Np2Startup *, uint8_t digital_test);
/* At most one nonblocking I2C start OR poll per call; no loops/delays. No I2C
 * at all in READY/RUNNING. Continually service acquisition/SD between calls. */
void XE_NP_Np2Control_Service(XE_NP_Np2Control *, uint32_t now_ms);
/* Both probes must be READY and capture armed. Releases are sequential, NOT
 * a shared phase-aligned start. Initial phase must be independently acquired
 * per probe; never label the first captured byte as frame zero by assumption. */
int XE_NP_Np2Control_Start(XE_NP_Np2Control *);
void XE_NP_Np2Control_Stop(XE_NP_Np2Control *);
#endif
