#ifndef XE_NP_NP2_PHASE_H
#define XE_NP_NP2_PHASE_H
#include <stdint.h>
#include "xe_np_np2_transport.h"

/* Startup-only alignment of the exact two-NP2, six-low-wire stream. These
 * objects do not own PSSI, SD or the clock and do not qualify recording.
 * SUPERSYNC bytes have the control driver's SS[8n+7:8n] bit ordering.
 * Single foreground owner; never call these APIs concurrently from IRQs.
 * The word-check fast path targets the little-endian STM32U595 platform. */
#define XE_NP_NP2_PHASE_WINDOW_TICKS 6400U
#define XE_NP_NP2_PHASE_SERVICE_STEPS 256U
/* The PSSI ring has 15 ms of retained raw data at 48 MB/s.  A 64 KiB
 * foreground span is only 1.37 ms of that stream, while avoiding the
 * scheduler/CRC overhead of repeatedly handling 16 KiB fragments. */
#define XE_NP_NP2_WIRE_MAX_SPAN 65536U
enum { XE_NP_NP2_PHASE_EMPTY=0, XE_NP_NP2_PHASE_SEARCHING,
       XE_NP_NP2_PHASE_LOCKED, XE_NP_NP2_PHASE_ADMITTED, XE_NP_NP2_PHASE_FAULT,
       XE_NP_NP2_PHASE_LOADING };
enum { XE_NP_NP2_PHASE_ERROR_NONE=0, XE_NP_NP2_PHASE_ERROR_ARGUMENT,
       XE_NP_NP2_PHASE_ERROR_NO_MATCH, XE_NP_NP2_PHASE_ERROR_AMBIGUOUS,
       XE_NP_NP2_PHASE_ERROR_ABORTED };
enum { XE_NP_NP2_WIRE_ERROR_NONE=0, XE_NP_NP2_WIRE_ERROR_ARGUMENT,
       XE_NP_NP2_WIRE_ERROR_SPAN, XE_NP_NP2_WIRE_ERROR_SYNC,
       XE_NP_NP2_WIRE_ERROR_DIGITAL };

typedef struct {
    uint64_t reference_start;
    uint32_t total_steps, last_service_steps;
    uint16_t candidate, cursor, match[2];
    uint8_t state, error, probe, digital_test, active_mask;
    uint8_t expected[2][64]; /* 16 frames x four three-wire SYNC fields */
    uint8_t window[XE_NP_NP2_PHASE_WINDOW_TICKS]; /* immutable private prelude */
} XE_NP_Np2Phase;

typedef struct {
    uint64_t source_start, next_source, accepted_ticks, fault_source;
    uint32_t last_comparisons;
    uint16_t first_phase[2], next_phase[2];
    uint8_t initialized, error, digital_test, fault_probe, active_mask;
    uint8_t fault_expected, fault_observed;
    uint8_t expected[2][64];
} XE_NP_Np2Wire;

/* Requires a fresh ZERO-INITIALIZED object and exactly four superframes of
 * retained input captured AFTER both probes reached RUNNING. Copies the input
 * and expected configuration, never learns sync from received data. The caller
 * MUST check DMA retention before AND after this copy, abort on overwrite,
 * and continue draining/accounting warmup input while Service yields. Warmup
 * is explicitly excluded from recording; no admitted byte may be discarded.
 * Inactive D6/D7 are ignored consistently with the six-wire packer. */
int XE_NP_Np2Phase_Begin(XE_NP_Np2Phase *, const uint8_t *source, uint32_t ticks,
                       uint64_t source_start, const uint8_t supersync[2][12],
                       uint8_t digital_test);
/* Same immutable four-superframe prelude, assembled across retained DMA spans
 * without an extra 6400-byte scratch buffer. Append must be contiguous and fit
 * the remaining prelude. Search starts only after the full prelude is copied.
 * Caller must abort on its post-copy retention failure BEFORE calling Service. */
int XE_NP_Np2Phase_BeginLoad(XE_NP_Np2Phase *, uint64_t source_start,
                           const uint8_t supersync[2][12], uint8_t digital_test);
int XE_NP_Np2Phase_BeginLoadMasked(XE_NP_Np2Phase *, uint64_t source_start,
                           const uint8_t supersync[2][12], uint8_t digital_test,
                           uint8_t active_probe_mask);
int XE_NP_Np2Phase_Append(XE_NP_Np2Phase *, const uint8_t *, uint32_t ticks,
                        uint64_t source_start);
/* At most 256 constant-size steps per call, including payload skips. Scans ALL
 * 1600 candidates independently for both probes, requiring exactly one match.
 * No peripheral access, sleeping or hidden unbounded candidate loop. */
void XE_NP_Np2Phase_Service(XE_NP_Np2Phase *);
void XE_NP_Np2Phase_Abort(XE_NP_Np2Phase *);
/* One-shot admission at/after the prelude end. Advances each phase using the
 * absolute source delta; does not reset DMA, trim data, or assume common frame
 * boundaries. Caller must independently prove producer continuity throughout
 * warmup and preserve the expected config/reference/admitted origin in metadata.
 * A stopped/restarted producer requires a new session, not another admission. */
int XE_NP_Np2Phase_Admit(XE_NP_Np2Phase *, XE_NP_Np2Wire *, uint64_t source_start);

/* Explicit known-origin initialization, including for strict readback tests.
 * This is NOT phase discovery/relock. Requires a fresh zero-initialized object. */
int XE_NP_Np2Wire_Init(XE_NP_Np2Wire *, const uint8_t supersync[2][12],
                     const uint16_t first_phase[2], uint64_t source_start,
                     uint8_t digital_test);
int XE_NP_Np2Wire_InitMasked(XE_NP_Np2Wire *, const uint8_t supersync[2][12],
                     const uint16_t first_phase[2], uint64_t source_start,
                     uint8_t digital_test,uint8_t active_probe_mask);
/* Checks partial frames and arbitrary contiguous spans up to 65536 ticks.
 * Normal mode touches only the four SYNC ticks/frame, NOT every ADC bit.
 * Digital-test mode checks every active wire tick and is a slower diagnostic.
 * Faults are sticky; accepted extent/phase advances only after the WHOLE span
 * passes. Caller retains source ownership before/after validation AND packing.
 * Neither static SUPERSYNC nor this API proves live DMA continuity or detects
 * arbitrary normal ADC corruption/whole-superframe loss. Full readback remains
 * required; this is not a replacement for producer and storage fault guards. */
int XE_NP_Np2Wire_Check(XE_NP_Np2Wire *, const uint8_t *, uint32_t ticks,
                      uint64_t source_start);
#endif
