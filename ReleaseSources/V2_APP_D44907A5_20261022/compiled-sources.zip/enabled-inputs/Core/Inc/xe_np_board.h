#ifndef XE_NP_BOARD_H
#define XE_NP_BOARD_H

#include <stddef.h>
#include <stdint.h>

#define XE_NP_BOARD_NAME "USB384_NP_V2_PSSI"
#define XE_NP_FW_VERSION 0x0002U
#define XE_NP_HW_VERSION 0x0200U

#ifndef XE_NP_V2_MEDIA_ENABLE
#define XE_NP_V2_MEDIA_ENABLE 0U
#endif

/*
 * V2 routes the Neuropixels parallel serial bus to the STM32U595 PSSI.
 * The first bring-up target is one NP1 probe on PSSI D0..D7; NP2 support
 * remains disabled until its three-lane packing has been qualified.
 */
#define XE_NP_BOARD_V2_PSSI_NP1_ENABLE 1U
#define XE_NP_BOARD_HAS_NP_REC_NRST 0U

/* The older PSSI_NP1_ENABLE name selects the V2 physical PSSI backend rather
 * than V1 GPIO capture. Generation-specific behavior is selected separately.
 * The application has a hard compile gate until its NP2 coordinator is wired. */
#ifndef XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE
#define XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE 0U
#endif
/* Every production image uses the 24 MHz HSE as its sole frequency reference.
 * SYSCLK uses HSE-fed PLL1; MCO uses PLL1R or direct HSE. SDMMC uses
 * HSE-fed PLL1/PLL2, USBPHY and ADC
 * use HSE directly, and I2C/SPI/timer kernels use HSE-derived bus clocks. */
#ifndef XE_NP_BOARD_HSE_ONLY_CLOCKS
#define XE_NP_BOARD_HSE_ONLY_CLOCKS 1U
#endif
#if (XE_NP_BOARD_HSE_ONLY_CLOCKS != 1U)
#error "Production firmware requires the HSE-only clock contract"
#endif
#if XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE && !XE_NP_BOARD_HSE_ONLY_CLOCKS
#error "NP2 firmware requires the HSE-only functional clock contract"
#endif
#ifndef XE_NP_BOARD_EXPERIMENTAL_NP2_192MHZ_CORE
#define XE_NP_BOARD_EXPERIMENTAL_NP2_192MHZ_CORE 0U
#endif
#ifndef XE_NP_BOARD_EXPERIMENTAL_NP2_128MHZ_20KHZ_CORE
#define XE_NP_BOARD_EXPERIMENTAL_NP2_128MHZ_20KHZ_CORE 0U
#endif
/* Private stopped-only power trial. Ordinary/USB/multi-probe clocks stay intact. */
#ifndef XE_NP_NP2_SD_SINGLE20_CORE64_TEST
#define XE_NP_NP2_SD_SINGLE20_CORE64_TEST 0U
#endif
/* Private20k raw THREE-probe trial; retain PCLK64/MCO32/PSRAM128.
 * Packed dual20 failed atCPU64: never opt mask3 into this experiment. */
#ifndef XE_NP_NP2_SD_MULTI20_CORE64_TEST
#define XE_NP_NP2_SD_MULTI20_CORE64_TEST 0U
#endif
/* Private raw THREE-probe20k CPU/AHB discriminator; retain the mask-aware
 * preparation route and PCLK64/MCO32/PSRAM128, not a pure-CPU comparison. */
#ifndef XE_NP_NP2_SD_RAW20_CORE128_TEST
#define XE_NP_NP2_SD_RAW20_CORE128_TEST 0U
#endif
#if (XE_NP_NP2_SD_RAW20_CORE128_TEST!=0U && XE_NP_NP2_SD_RAW20_CORE128_TEST!=1U) || \
    (XE_NP_NP2_SD_RAW20_CORE128_TEST && \
     (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
      !XE_NP_NP2_SD_MULTI20_CORE64_TEST))
#error "Raw20 core128 requires the runtime SD APP multi20/core64 control"
#endif
/* Private SD-only throughput discriminator, NOT a supported operating point.
 * Only raw THREE-probe20k selects CPU/AHB256; external data clocks stay put.
 * Keep mask0 startup and the protected USB service outside this opt-in. */
#ifndef XE_NP_NP2_SD_RAW20_CORE256_TEST
#define XE_NP_NP2_SD_RAW20_CORE256_TEST 0U
#endif
#if (XE_NP_NP2_SD_RAW20_CORE256_TEST!=0U && XE_NP_NP2_SD_RAW20_CORE256_TEST!=1U) || \
    (XE_NP_NP2_SD_RAW20_CORE256_TEST && \
     (!defined(XE_NP_IMAGE_ROLE) || XE_NP_IMAGE_ROLE!=1U || \
      !XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
      !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_PSRAM_OVERFLOW_PLL1Q128 || \
      !XE_NP_NP2_SD_MULTI20_CORE64_TEST || !XE_NP_NP2_SD_RAW20_CORE128_TEST || \
      XE_NP_NP2_SD_SINGLE20_CORE64_TEST || XE_NP_NP2_SD_IDLE_HCLK_TEST || \
      XE_NP_NP2_SD_SINGLE7500_FLASH1_TEST || XE_NP_V2_MEDIA_ENABLE || \
      XE_NP_V2_AUX_ENABLE || XE_NP_BOARD_SENSOR_SERVICE_ENABLE))
#error "Raw20 core256 requires the neural-only runtime SD APP and checked core128 control"
#endif
/* Private raw THREE-probe15k trial: CPU48/PCLK48/MCO24/PSRAM96.
 * Does not lower packed,7.5k,20k or30k clocks; keep the checked raw20 policy. */
#ifndef XE_NP_NP2_SD_RAW15_CORE48_TEST
#define XE_NP_NP2_SD_RAW15_CORE48_TEST 0U
#endif
/* Private raw THREE-probe7.5k classic-writer trial. Keep PCLK24/MCO12/
 * PSRAM96; CPU96 gives the existing copied writer more service margin. */
#ifndef XE_NP_NP2_SD_CLASSIC7500_CORE96_TEST
#define XE_NP_NP2_SD_CLASSIC7500_CORE96_TEST 0U
#endif
/* Private stopped-only packed SD trial: masks1/3 at7.5/15k use CPU40/80,
 * direct-HSE MCO12/24 and unchanged PLL1Q96 PSRAM. Other profiles stay intact. */
#ifndef XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST
#define XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST 0U
#endif
#if (XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST != 0U) && (XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST != 1U)
#error "Packed-low HSE-MCO trial is boolean"
#endif
/* Second packed-only trial: retain VCO384/Q4=PSRAM96; R10/R6 select
 * CPU38.4/64 while direct-HSE MCO remains12/24. The first trial stays intact. */
#ifndef XE_NP_NP2_SD_PACKED_LOW_VCO384_TEST
#define XE_NP_NP2_SD_PACKED_LOW_VCO384_TEST 0U
#endif
#if (XE_NP_NP2_SD_PACKED_LOW_VCO384_TEST != 0U) && (XE_NP_NP2_SD_PACKED_LOW_VCO384_TEST != 1U)
#error "Packed-low VCO384 trial is boolean"
#endif
#if XE_NP_NP2_SD_PACKED_LOW_VCO384_TEST && !XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST
#error "Packed-low VCO384 requires the explicit packed-low HSE-MCO trial"
#endif
/* Private single7.5k-only control: reuse VCO480/Q5/R12 and HSE MCO12.
 * CPU40/PCLK20; every other stopped profile keeps its existing selection. */
#ifndef XE_NP_NP2_SD_SINGLE7500_CORE40_TEST
#define XE_NP_NP2_SD_SINGLE7500_CORE40_TEST 0U
#endif
#if XE_NP_NP2_SD_SINGLE7500_CORE40_TEST!=0U && XE_NP_NP2_SD_SINGLE7500_CORE40_TEST!=1U
#error "Single7500 core40 trial is boolean"
#endif
/* Private 1p7.5k trial: halve PLL1 VCO, retain CPU48/PCLK24/MCO12/PSRAM96. */
#ifndef XE_NP_NP2_SD_SINGLE7500_VCO192_TEST
#define XE_NP_NP2_SD_SINGLE7500_VCO192_TEST 0U
#endif
#if XE_NP_NP2_SD_SINGLE7500_VCO192_TEST!=0U && XE_NP_NP2_SD_SINGLE7500_VCO192_TEST!=1U
#error "Single7500 VCO192 trial is boolean"
#endif
/* SQR linear-burst trial: only 1p7.5k uses VCO384/Q5=76.8MHz.
 * CPU48/PCLK24/MCO12 and SD108 remain unchanged; no Wrap32 toggle. */
#ifndef XE_NP_NP2_SD_SINGLE7500_SQR_LINEAR_TEST
#define XE_NP_NP2_SD_SINGLE7500_SQR_LINEAR_TEST 0U
#endif
#if (XE_NP_NP2_SD_SINGLE7500_SQR_LINEAR_TEST!=0U && XE_NP_NP2_SD_SINGLE7500_SQR_LINEAR_TEST!=1U) || \
    (XE_NP_NP2_SD_SINGLE7500_SQR_LINEAR_TEST && \
     (!XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
      !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_PSRAM_OVERFLOW_PLL1Q128 || \
      !XE_NP_NP2_SD_MULTI20_CORE64_TEST || XE_NP_NP2_SD_RAW15_CORE48_TEST || \
      XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST || XE_NP_NP2_SD_SINGLE7500_CORE40_TEST || \
      XE_NP_NP2_SD_SINGLE7500_VCO192_TEST || XE_NP_NP2_SD_IDLE_HCLK_TEST || \
      XE_NP_NP2_SD_DUAL30_PSRAM_Q128_TEST))
#error "SQR linear trial requires the unchanged-core mask-aware runtime PLL1Q SD APP"
#endif
static inline int XE_NP_Board_Np2Single7500SqrLinear(uint32_t sample_hz,uint32_t probe_mask)
{
    (void)sample_hz;(void)probe_mask;
    return XE_NP_NP2_SD_SINGLE7500_SQR_LINEAR_TEST && sample_hz==7500U && probe_mask==1U;
}
/* Private 1p7.5k trial: retain VOS1/clocks/cache, trim only Flash latency. */
#ifndef XE_NP_NP2_SD_SINGLE7500_FLASH1_TEST
#define XE_NP_NP2_SD_SINGLE7500_FLASH1_TEST 0U
#endif
#if XE_NP_NP2_SD_SINGLE7500_FLASH1_TEST!=0U && XE_NP_NP2_SD_SINGLE7500_FLASH1_TEST!=1U
#error "Single7500 Flash1 trial is boolean"
#endif
/* Private DSP-assisted P1/7.5k only: VCO384/Q4=PSRAM96, R12=CPU32.
 * HSE/2 keeps MCO12 independent; VOS1, SD108 and other profiles stay intact. */
#ifndef XE_NP_NP2_SD_SINGLE7500_CORE32_TEST
#define XE_NP_NP2_SD_SINGLE7500_CORE32_TEST 0U
#endif
#if (XE_NP_NP2_SD_SINGLE7500_CORE32_TEST!=0U && XE_NP_NP2_SD_SINGLE7500_CORE32_TEST!=1U) || \
    (XE_NP_NP2_SD_SINGLE7500_CORE32_TEST && \
     (!XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
      !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_PSRAM_OVERFLOW_PLL1Q128 || \
      !XE_NP_NP2_SD_MULTI20_CORE64_TEST || !XE_NP_NP2_PACK_DSP_TEST || \
      XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST || XE_NP_NP2_SD_SINGLE7500_CORE40_TEST || \
      XE_NP_NP2_SD_SINGLE7500_VCO192_TEST || XE_NP_NP2_SD_SINGLE7500_SQR_LINEAR_TEST || \
      XE_NP_NP2_SD_SINGLE7500_FLASH1_TEST || XE_NP_NP2_SD_SINGLE15_CORE64_TEST || \
      XE_NP_NP2_SD_SINGLE15_APB24_TEST || XE_NP_NP2_SD_IDLE_HCLK_TEST))
#error "Single7500 core32 requires the DSP mask-aware runtime PLL1Q SD APP without conflicting clock trials"
#endif
/* Private 1p15k trial: keep CPU/AHB96 and all functional data clocks. */
#ifndef XE_NP_NP2_SD_SINGLE15_APB24_TEST
#define XE_NP_NP2_SD_SINGLE15_APB24_TEST 0U
#endif
#if XE_NP_NP2_SD_SINGLE15_APB24_TEST!=0U && XE_NP_NP2_SD_SINGLE15_APB24_TEST!=1U
#error "Single15 APB24 trial is boolean"
#endif
/* Private P1/20k APB-only trial: preserve HCLK128/MCO32/PSRAM128/SD108. */
#ifndef XE_NP_NP2_SD_SINGLE20_APB32_TEST
#define XE_NP_NP2_SD_SINGLE20_APB32_TEST 0U
#endif
#if XE_NP_NP2_SD_SINGLE20_APB32_TEST!=0U && XE_NP_NP2_SD_SINGLE20_APB32_TEST!=1U
#error "Single20 APB32 trial is boolean"
#endif
/* Private P1/30k APB-only trial: HCLK192/MCO48/PSRAM96/SD108 unchanged. */
#ifndef XE_NP_NP2_SD_SINGLE30_APB24_TEST
#define XE_NP_NP2_SD_SINGLE30_APB24_TEST 0U
#endif
#if XE_NP_NP2_SD_SINGLE30_APB24_TEST!=0U && XE_NP_NP2_SD_SINGLE30_APB24_TEST!=1U
#error "Single30 APB24 trial is boolean"
#endif
/* SINGLE15_CORE64_GUARDS_BEGIN */
/* Private P1/15k only: VCO384/Q4=PSRAM96, R6=CPU64, direct HSE MCO24.
 * PCLK32 is sufficient without SPI2-D8; keep VOS1/SD108 and every other tuple. */
#ifndef XE_NP_NP2_SD_SINGLE15_CORE64_TEST
#define XE_NP_NP2_SD_SINGLE15_CORE64_TEST 0U
#endif
#if (XE_NP_NP2_SD_SINGLE15_CORE64_TEST!=0U && XE_NP_NP2_SD_SINGLE15_CORE64_TEST!=1U) || \
    (XE_NP_NP2_SD_SINGLE15_CORE64_TEST && \
     (!XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
      !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_PSRAM_OVERFLOW_PLL1Q128 || \
      !XE_NP_NP2_SD_MULTI20_CORE64_TEST || XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST || \
      XE_NP_NP2_SD_SINGLE7500_CORE40_TEST || XE_NP_NP2_SD_SINGLE15_APB24_TEST || \
      XE_NP_NP2_SD_IDLE_HCLK_TEST))
#error "Single15 core64 requires the mask-aware runtime PLL1Q SD APP without conflicting clock trials"
#endif
/* SINGLE15_CORE64_GUARDS_END */
/* TRIPLE7500_CORE64_GUARDS_BEGIN */
/* Private stopped 3p7.5k whole-profile trial: VCO384/Q4/R6 gives CPU64,
 * PSRAM96; HSE/2 retains MCO12. APB/2 gives PCLK32, not baseline96/24. */
#ifndef XE_NP_NP2_SD_TRIPLE7500_CORE64_TEST
#define XE_NP_NP2_SD_TRIPLE7500_CORE64_TEST 0U
#endif
#if (XE_NP_NP2_SD_TRIPLE7500_CORE64_TEST!=0U && XE_NP_NP2_SD_TRIPLE7500_CORE64_TEST!=1U) || \
    (XE_NP_NP2_SD_TRIPLE7500_CORE64_TEST && \
     (!defined(XE_NP_IMAGE_ROLE) || XE_NP_IMAGE_ROLE!=1U || \
      !XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
      !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_PSRAM_OVERFLOW_PLL1Q128 || \
      !XE_NP_NP2_SD_CLASSIC7500_CORE96_TEST || !XE_NP_BOARD_HSE_ONLY_CLOCKS || \
      XE_NP_PSRAM_OVERFLOW_PLL2Q108 || \
      (defined(XE_NP_BOARD_SD_PLL2Q_HZ) && XE_NP_BOARD_SD_PLL2Q_HZ!=108000000UL) || \
      (defined(HSE_VALUE) && HSE_VALUE!=24000000UL) || \
      XE_NP_NP2_SD_SINGLE15_CORE64_TEST || XE_NP_NP2_SD_SINGLE20_CORE64_TEST || \
      XE_NP_NP2_SD_RAW15_CORE48_TEST || XE_NP_NP2_SD_RAW20_CORE256_TEST || \
      XE_NP_NP2_SD_CLASSIC15_CORE192_TEST || XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST || \
      XE_NP_NP2_SD_PACKED_LOW_VCO384_TEST || XE_NP_NP2_SD_SINGLE7500_CORE32_TEST || \
      XE_NP_NP2_SD_SINGLE7500_CORE40_TEST || XE_NP_NP2_SD_SINGLE7500_VCO192_TEST || \
      XE_NP_NP2_SD_SINGLE7500_SQR_LINEAR_TEST || XE_NP_NP2_SD_SINGLE7500_FLASH1_TEST || \
      XE_NP_NP2_SD_DUAL30_PSRAM_Q128_TEST || XE_NP_NP2_SD_DUAL30_PSRAM_SYSCLK192_TEST || \
      XE_NP_NP2_SD_SINGLE15_APB24_TEST || XE_NP_NP2_SD_SINGLE20_APB32_TEST || \
      XE_NP_NP2_SD_SINGLE30_APB24_TEST || XE_NP_NP2_SD_IDLE_HCLK_TEST || \
      XE_NP_NP2_SD_KERNEL96_POWER_TEST || XE_NP_NP2_SD_KERNEL80_POWER_TEST || \
      XE_NP_NP2_SD_HIGH_RATE_KERNEL120_TEST))
#error "Triple7500 core64 requires the checked core96 HSE/PLL1Q runtime SD APP without conflicting clock trials"
#endif
/* TRIPLE7500_CORE64_GUARDS_END */
#if XE_NP_NP2_SD_CLASSIC7500_CORE96_TEST > 1U
#error "Classic7500 core96 trial is boolean"
#endif
/* Private two/three-probe15k classic trial: CPU192, PCLK48/MCO24/PSRAM96.
 * Reuse the checked192MHz level; never raise an acquisition/peripheral clock. */
#ifndef XE_NP_NP2_SD_CLASSIC15_CORE192_TEST
#define XE_NP_NP2_SD_CLASSIC15_CORE192_TEST 0U
#endif
#if XE_NP_NP2_SD_CLASSIC15_CORE192_TEST > 1U || \
    (XE_NP_NP2_SD_CLASSIC15_CORE192_TEST && XE_NP_NP2_SD_RAW15_CORE48_TEST)
#error "Classic15 core192 is boolean and excludes the raw15 core48 trial"
#endif
#if XE_NP_NP2_SD_RAW15_CORE48_TEST > 1U || \
    (XE_NP_NP2_SD_RAW15_CORE48_TEST && !XE_NP_NP2_SD_MULTI20_CORE64_TEST)
#error "Raw15 core48 requires the checked raw20 core64 SD policy"
#endif
/* Private setup-only trial: unused probes share VCC/MCLK with selected ones. */
#ifndef XE_NP_NP2_SD_UNUSED_PROBE_POWERDOWN_TEST
#define XE_NP_NP2_SD_UNUSED_PROBE_POWERDOWN_TEST 0U
#endif
/* Rejected private HCLK/4 trial: 3p20 completed, but all five sync heartbeats
 * failed. Keep default0; do not enable without phase-continuous timekeeping. */
#ifndef XE_NP_NP2_SD_IDLE_HCLK_TEST
#define XE_NP_NP2_SD_IDLE_HCLK_TEST 0U
#endif
#if XE_NP_NP2_SD_IDLE_HCLK_TEST > 1U
#error "Idle HCLK trial is boolean"
#endif
#if XE_NP_NP2_SD_IDLE_HCLK_TEST
#define XE_NP_NP2_BLE_UART_CLOCK_SOURCE RCC_USART2CLKSOURCE_SYSCLK
#else
#define XE_NP_NP2_BLE_UART_CLOCK_SOURCE RCC_USART2CLKSOURCE_PCLK1
#endif
/* CPU-budget comparison only: synthetic arrivals retain their 20 kS/s rate,
 * but there is NO physical 32 MHz MCO at 120 MHz with the current /4 plan.
 * This override is forbidden outside the no-probe storage diagnostic. */
#ifndef XE_NP_NP2_SYNTHETIC_SD_120MHZ_CPU
#define XE_NP_NP2_SYNTHETIC_SD_120MHZ_CPU 0U
#endif
#ifndef XE_NP_NP2_LIVE_SD_ENABLE
#define XE_NP_NP2_LIVE_SD_ENABLE 0U
#endif
/* Bounded standalone HIL of the production overflow backend, not a catalog
 * allocator or release mode. Its pre-erase gate preserves the media card. */
#ifndef XE_NP_NP2_LIVE_SD_DUAL_SCRATCH_OVERFLOW_DMA
#define XE_NP_NP2_LIVE_SD_DUAL_SCRATCH_OVERFLOW_DMA 0U
#endif
#if XE_NP_NP2_LIVE_SD_DUAL_SCRATCH_OVERFLOW_DMA != 0U && \
    XE_NP_NP2_LIVE_SD_DUAL_SCRATCH_OVERFLOW_DMA != 1U
#error "Standalone dual overflow scratch selection must be boolean"
#endif
#if XE_NP_NP2_LIVE_SD_DUAL_SCRATCH_OVERFLOW_DMA && \
    (!XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_NP2_LIVE_SD_ENABLE || \
     XE_NP_V2_MEDIA_ENABLE || XE_NP_NP2_DUAL_SD_APP_ENABLE || XE_NP_NP2_SD_BLE_ENABLE || \
     !XE_NP_NP2_USB_PACKED_DUAL || XE_NP_NP2_LIVE_SD_PROBE_MASK != 3U || \
     !XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS || !XE_NP_NP2_LIVE_SD_COPIED_DUAL_ADAPTIVE || \
     !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || \
     XE_NP_NP2_LIVE_SD_OVERFLOW_DMA_BURST_WORDS != 1U || \
     !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || XE_NP_NP2_LIVE_SD_WRITE_RUS != 4U || \
     XE_NP_NP2_LIVE_SD_MIN_WRITE_RUS != 1U || \
     !XE_NP_PSRAM_OVERFLOW_PLL2Q108 || XE_NP_PSRAM_OVERFLOW_PRESCALER != 1U || \
     !XE_NP_PSRAM_PAD_HSLV_ENABLE || !XE_NP_SD_CMD11_PIN_COMPAT_ENABLE || \
     XE_NP_BOARD_SD_PLL2Q_HZ != 108000000UL || XE_NP_BOARD_SD_RX_CLOCK_TEST != 2U || \
     (XE_NP_NP2_LIVE_SD_DURATION_SECONDS != 10U && \
      XE_NP_NP2_LIVE_SD_DURATION_SECONDS != 60U) || XE_NP_NP2_LIVE_SD_BLOCK_LIMIT || \
     (XE_NP_NP2_LIVE_SD_SAMPLE_HZ != 20000U && XE_NP_NP2_LIVE_SD_SAMPLE_HZ != 30000U))
#error "Standalone scratch requires the closed real dual20/30 10-or-60-second SD108/PSRAM108 overflow profile"
#endif
/* Stopped-only diagnostic: keep the existing CPU/MCO PLL1R profiles, but
 * supply overflow PSRAM from PLL1Q at128MHz rather than SYSCLK. */
#ifndef XE_NP_PSRAM_OVERFLOW_PLL1Q128
#define XE_NP_PSRAM_OVERFLOW_PLL1Q128 0U
#endif
/* Private strict SDR10496 trial; dual15 keeps its existing /2 bus policy.
 * CPU/MCO and the independent PLL1Q PSRAM feed are unchanged. */
#ifndef XE_NP_NP2_SD_KERNEL96_POWER_TEST
#define XE_NP_NP2_SD_KERNEL96_POWER_TEST 0U
#endif
/* Private card-mode comparison at the same96MHz bus; admission is dual20 only. */
#ifndef XE_NP_NP2_SD_DUAL20_SDR50_96_TEST
#define XE_NP_NP2_SD_DUAL20_SDR50_96_TEST 0U
#endif
/* Private cold SDR104/80 comparison; PLL1Q PSRAM and acquisition stay unchanged. */
#ifndef XE_NP_NP2_SD_KERNEL80_POWER_TEST
#define XE_NP_NP2_SD_KERNEL80_POWER_TEST 0U
#endif
#if XE_NP_NP2_SD_KERNEL80_POWER_TEST!=0U && XE_NP_NP2_SD_KERNEL80_POWER_TEST!=1U
#error "SD kernel80 power trial is boolean"
#endif
/* Private source-free SRAM12 comparator, never a live recording profile. */
#ifndef XE_NP_NP2_SD_STOPPED_SDR50_100_TEST
#define XE_NP_NP2_SD_STOPPED_SDR50_100_TEST 0U
#endif
#ifndef XE_NP_NP2_SD_STOPPED_SDR104_120_TEST
#define XE_NP_NP2_SD_STOPPED_SDR104_120_TEST 0U
#endif
#ifndef XE_NP_NP2_SD_STOPPED_DDR50_40_TEST
#define XE_NP_NP2_SD_STOPPED_DDR50_40_TEST 0U
#endif
#if (XE_NP_NP2_SD_KERNEL96_POWER_TEST != 0U) && (XE_NP_NP2_SD_KERNEL96_POWER_TEST != 1U)
#error "SD kernel96 power trial is boolean"
#endif
/* Private high-rate-only SDR104 boundary trial; never admits low profiles. */
#ifndef XE_NP_NP2_SD_HIGH_RATE_KERNEL120_TEST
#define XE_NP_NP2_SD_HIGH_RATE_KERNEL120_TEST 0U
#endif
#if XE_NP_NP2_SD_HIGH_RATE_KERNEL120_TEST!=0U && XE_NP_NP2_SD_HIGH_RATE_KERNEL120_TEST!=1U
#error "High-rate kernel120 trial is boolean"
#endif
/* STOPPED_VSC114_GUARDS_BEGIN */
/* Closed intermediate target for the existing stopped high-rate experiment.
 * The legacy120 flag keeps its original target unless this opt-in is set. */
#ifndef XE_NP_NP2_SD_STOPPED_VSC114_TEST
#define XE_NP_NP2_SD_STOPPED_VSC114_TEST 0U
#endif
#if (XE_NP_NP2_SD_STOPPED_VSC114_TEST!=0U && XE_NP_NP2_SD_STOPPED_VSC114_TEST!=1U) || \
    (XE_NP_NP2_SD_STOPPED_VSC114_TEST && \
     (!XE_NP_NP2_SD_HIGH_RATE_KERNEL120_TEST || !XE_NP_NP2_SD_VSC_FEED_TEST || \
      !XE_NP_NP2_SD_STOPPED_FEED_TEST || !XE_NP_NP2_SD_VSC_PREERASE60_TEST || \
      XE_NP_BOARD_SD_PLL2Q_HZ!=114000000UL))
#error "Stopped VSC114 requires the divided-preerase private high-rate feeder"
#endif
/* STOPPED_VSC114_GUARDS_END */
/* Stopped diagnostic: change only the 30-kHz PSRAM feed, not CPU/MCO/SD.
 * Default Q3 remains128MHz; Q4 gives96MHz on the same384MHz VCO. */
#ifndef XE_NP_PSRAM_OVERFLOW_PLL1Q_30KHZ_DIV
#define XE_NP_PSRAM_OVERFLOW_PLL1Q_30KHZ_DIV 3U
#endif
/* DUAL30_PSRAM_Q128_BEGIN */
#ifndef XE_NP_NP2_SD_DUAL30_PSRAM_Q128_TEST
#define XE_NP_NP2_SD_DUAL30_PSRAM_Q128_TEST 0U
#endif
#if (XE_NP_NP2_SD_DUAL30_PSRAM_Q128_TEST!=0U && XE_NP_NP2_SD_DUAL30_PSRAM_Q128_TEST!=1U) || \
    (XE_NP_NP2_SD_DUAL30_PSRAM_Q128_TEST && \
     (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
      !XE_NP_PSRAM_OVERFLOW_PLL1Q128 || XE_NP_PSRAM_OVERFLOW_PLL2Q108 || \
      XE_NP_PSRAM_OVERFLOW_PLL1Q_30KHZ_DIV!=4U || XE_NP_PSRAM_OVERFLOW_PRESCALER!=1U || \
      XE_NP_NP2_SD_DUAL30_PSRAM_SYSCLK192_TEST))
#error "Dual30 Q128 requires the runtime SD APP with default Q96 and OSPI /1"
#endif
static inline uint32_t XE_NP_Board_Np2Dual30PsramQ128(uint32_t sample_hz,uint32_t probe_mask)
{
    (void)sample_hz;(void)probe_mask;
    return XE_NP_NP2_SD_DUAL30_PSRAM_Q128_TEST && sample_hz==30000U && probe_mask==3U;
}
/* DUAL30_PSRAM_Q128_END */
#if (XE_NP_PSRAM_OVERFLOW_PLL1Q_30KHZ_DIV != 3U) && (XE_NP_PSRAM_OVERFLOW_PLL1Q_30KHZ_DIV != 4U)
#error "30-kHz PLL1Q PSRAM divider must be3 or4"
#endif
#if !XE_NP_PSRAM_OVERFLOW_PLL1Q128 && XE_NP_PSRAM_OVERFLOW_PLL1Q_30KHZ_DIV != 3U
#error "30-kHz PSRAM divider control requires the explicit PLL1Q overflow route"
#endif
#ifndef XE_NP_PSRAM_OVERFLOW_PLL2Q108
#define XE_NP_PSRAM_OVERFLOW_PLL2Q108 0U
#endif
#if (XE_NP_PSRAM_OVERFLOW_PLL2Q108 != 0U) && (XE_NP_PSRAM_OVERFLOW_PLL2Q108 != 1U)
#error "PLL2Q108 overflow control is a boolean opt-in"
#endif
#if XE_NP_PSRAM_OVERFLOW_PLL1Q128 && XE_NP_PSRAM_OVERFLOW_PLL2Q108
#error "Select only one overflow PSRAM kernel control"
#endif
#if (XE_NP_PSRAM_OVERFLOW_PLL1Q128 != 0U) && (XE_NP_PSRAM_OVERFLOW_PLL1Q128 != 1U)
#error "PLL1Q128 overflow control is a boolean opt-in"
#endif
#if XE_NP_PSRAM_OVERFLOW_PLL1Q128 && \
    (!XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_NP2_LIVE_SD_ENABLE || \
     !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
     !XE_NP_SD_CMD11_PIN_COMPAT_ENABLE || \
     (XE_NP_BOARD_SD_PLL2Q_HZ != 108000000UL && \
      (!XE_NP_NP2_SD_STOPPED_SDR50_100_TEST || XE_NP_BOARD_SD_PLL2Q_HZ != 100000000UL) && \
      (!XE_NP_NP2_SD_KERNEL96_POWER_TEST || XE_NP_BOARD_SD_PLL2Q_HZ != 96000000UL) && \
      (!XE_NP_NP2_SD_KERNEL80_POWER_TEST || XE_NP_BOARD_SD_PLL2Q_HZ != 80000000UL) && \
      (!XE_NP_NP2_SD_STOPPED_DDR50_40_TEST || XE_NP_BOARD_SD_PLL2Q_HZ != 80000000UL) && \
      (!XE_NP_NP2_SD_HIGH_RATE_KERNEL120_TEST || \
       XE_NP_BOARD_SD_PLL2Q_HZ != (XE_NP_NP2_SD_STOPPED_VSC114_TEST?114000000UL:120000000UL))) || \
     XE_NP_PSRAM_OVERFLOW_PRESCALER != 1U || !XE_NP_PSRAM_PAD_HSLV_ENABLE)
#error "PLL1Q128 requires the explicit NP2 catalog overflow /1 HSLV SD108 control"
#endif
#if XE_NP_PSRAM_OVERFLOW_PLL2Q108 && \
    (!XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_NP2_LIVE_SD_ENABLE || \
     !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || \
     (!XE_NP_NP2_DUAL_SD_APP_ENABLE && !XE_NP_NP2_LIVE_SD_DUAL_SCRATCH_OVERFLOW_DMA) || \
     !XE_NP_SD_CMD11_PIN_COMPAT_ENABLE || XE_NP_BOARD_SD_PLL2Q_HZ != 108000000UL || \
     XE_NP_PSRAM_OVERFLOW_PRESCALER != 1U || !XE_NP_PSRAM_PAD_HSLV_ENABLE)
#error "PLL2Q108 requires the explicit NP2 catalog or bounded scratch overflow /1 HSLV SD108 control"
#endif
#if XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST && \
    (!XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
     !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_PSRAM_OVERFLOW_PLL1Q128 || \
     XE_NP_NP2_SD_CLASSIC15_CORE192_TEST || XE_NP_NP2_SD_IDLE_HCLK_TEST)
#error "Packed-low HSE-MCO requires the runtime-profile PLL1Q SD APP without another packed15/idle clock trial"
#endif
#if XE_NP_NP2_SD_SINGLE7500_CORE40_TEST && \
    (!XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
     !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_PSRAM_OVERFLOW_PLL1Q128 || \
     XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST || XE_NP_NP2_SD_IDLE_HCLK_TEST)
#error "Single7500 core40 requires the runtime-profile PLL1Q SD APP without another packed-low/idle trial"
#endif
#if XE_NP_NP2_SD_SINGLE7500_FLASH1_TEST && \
    (!XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
     !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_PSRAM_OVERFLOW_PLL1Q128 || \
     !(XE_NP_NP2_SD_SINGLE20_CORE64_TEST || XE_NP_NP2_SD_MULTI20_CORE64_TEST) || \
     XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST || XE_NP_NP2_SD_SINGLE7500_CORE40_TEST || \
     XE_NP_NP2_SD_IDLE_HCLK_TEST)
#error "Single7500 Flash1 requires the unchanged-clock runtime PLL1Q SD APP"
#endif
#if XE_NP_NP2_SD_SINGLE15_APB24_TEST && \
    (!XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
     !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_PSRAM_OVERFLOW_PLL1Q128 || \
     !(XE_NP_NP2_SD_SINGLE20_CORE64_TEST || XE_NP_NP2_SD_MULTI20_CORE64_TEST) || \
     XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST || XE_NP_NP2_SD_SINGLE7500_CORE40_TEST || \
     XE_NP_NP2_SD_SINGLE7500_FLASH1_TEST || XE_NP_NP2_SD_IDLE_HCLK_TEST)
#error "Single15 APB24 requires the unchanged-core runtime PLL1Q SD APP"
#endif
#if XE_NP_NP2_SD_SINGLE20_APB32_TEST && \
    (!XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
     !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_PSRAM_OVERFLOW_PLL1Q128 || \
     !XE_NP_NP2_SD_MULTI20_CORE64_TEST || !XE_NP_NP2_SD_RAW20_CORE128_TEST || \
     XE_NP_NP2_SD_SINGLE20_CORE64_TEST || XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST || \
     XE_NP_NP2_SD_SINGLE7500_CORE40_TEST || XE_NP_NP2_SD_SINGLE15_APB24_TEST || \
     XE_NP_NP2_SD_IDLE_HCLK_TEST)
#error "Single20 APB32 requires the unchanged-core mask-aware runtime PLL1Q SD APP"
#endif
#if XE_NP_NP2_SD_SINGLE30_APB24_TEST && \
    (!XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
     !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_PSRAM_OVERFLOW_PLL1Q128 || \
     !XE_NP_NP2_SD_MULTI20_CORE64_TEST || !XE_NP_NP2_SD_RAW20_CORE128_TEST || \
     XE_NP_NP2_SD_SINGLE20_CORE64_TEST || XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST || \
     XE_NP_NP2_SD_SINGLE7500_CORE40_TEST || XE_NP_NP2_SD_SINGLE15_APB24_TEST || \
     XE_NP_NP2_SD_SINGLE20_APB32_TEST || XE_NP_NP2_SD_IDLE_HCLK_TEST || \
     XE_NP_BOARD_SENSOR_SERVICE_ENABLE || XE_NP_V2_MEDIA_ENABLE || XE_NP_V2_AUX_ENABLE)
#error "Single30 APB24 requires the unchanged-core neural runtime PLL1Q SD APP"
#endif
#if XE_NP_NP2_SD_SINGLE7500_VCO192_TEST && \
    (!XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
     !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_PSRAM_OVERFLOW_PLL1Q128 || \
     !XE_NP_NP2_SD_MULTI20_CORE64_TEST || XE_NP_NP2_SD_RAW15_CORE48_TEST || \
     XE_NP_NP2_SD_PACKED_LOW_HSE_MCO_TEST || XE_NP_NP2_SD_SINGLE7500_CORE40_TEST || \
     XE_NP_NP2_SD_SINGLE7500_FLASH1_TEST || XE_NP_NP2_SD_SINGLE15_APB24_TEST || \
     XE_NP_NP2_SD_IDLE_HCLK_TEST)
#error "Single7500 VCO192 requires the unchanged-clock mask-aware runtime PLL1Q SD APP"
#endif
#if XE_NP_NP2_SYNTHETIC_SD_120MHZ_CPU && \
    (!defined(XE_NP_NP2_TRIPLE_SYNTHETIC_SD_ENABLE) || \
     !XE_NP_NP2_TRIPLE_SYNTHETIC_SD_ENABLE || \
     !XE_NP_BOARD_EXPERIMENTAL_NP2_128MHZ_20KHZ_CORE)
#error "120 MHz CPU override is restricted to the no-probe triple SD diagnostic"
#endif
/* NP2 has deliberately separate clock profiles.  The original one-probe
 * application uses 192 MHz CPU / 48 MHz MCO for 30 kS/s.  The future
 * three-probe application must select this 128 MHz CPU / 32 MHz MCO profile
 * for 20 kS/s; it must never decimate a 30 kS/s PSSI stream after capture.
 * Both selections retain four HCLK cycles per PSSI edge. */
#define XE_NP_BOARD_NP2_CAPTURE_PROFILE_COUNT \
    (XE_NP_BOARD_EXPERIMENTAL_NP2_192MHZ_CORE + \
     XE_NP_BOARD_EXPERIMENTAL_NP2_128MHZ_20KHZ_CORE)
#if (XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE != XE_NP_BOARD_NP2_CAPTURE_PROFILE_COUNT)
#error "NP2 requires the explicit experimental 30 kS/s or 20 kS/s capture clock profile"
#endif
#if XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE && defined(XE_NP_BOARD_EVEN_PLL1R_TEST) && XE_NP_BOARD_EVEN_PLL1R_TEST
#error "NP2 cannot use the NP1 even-divider clock experiment"
#endif
#if XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE
#if XE_NP_BOARD_EXPERIMENTAL_NP2_128MHZ_20KHZ_CORE
#define XE_NP_BOARD_PSSI_PROBE_MASK 7U
#else
#define XE_NP_BOARD_PSSI_PROBE_MASK 3U
#endif
#define XE_NP_BOARD_DEFER_PROBE_MCO_START 1U
#else
#define XE_NP_BOARD_PSSI_PROBE_MASK 1U
#define XE_NP_BOARD_DEFER_PROBE_MCO_START 0U
#endif

/* The connected 004B NP2 unit was qualified on PD9/AF10: its 96-bit
 * Supersync stream is exact there, while PA6 produces no PSSI samples.
 * PA6/AF4 remains selectable for a separately wired cable/board. */
#ifndef XE_NP_BOARD_NP1_PSSI_PDCK_USE_PA6
#define XE_NP_BOARD_NP1_PSSI_PDCK_USE_PA6 0U
#endif

/* The 1.8 V V2 board requires PA8 HSLV for reliable 93.6 MHz MCLK.
 * IO_VDD_HSLV must be explicitly provisioned for a VDD <= 2.7 V board;
 * application firmware never changes option bytes automatically. */
#ifndef XE_NP_BOARD_NP_MCO_HSLV_ENABLE
#define XE_NP_BOARD_NP_MCO_HSLV_ENABLE XE_NP_BOARD_V2_PSSI_NP1_ENABLE
#endif

/* NP control buses have only the internal pull-ups. HSE-only production uses
 * PCLK1/PCLK3 and the slowest practical TIMINGR profile (about 7.8 kHz at
 * 64 MHz PCLK and 11.7 kHz at 96 MHz PCLK), so weak pull-ups still have
 * generous rise time. The MSIK branch is retained only for nonproduction
 * clock-isolation experiments. */
#ifndef XE_NP_BOARD_NP_I2C_MSIK_ENABLE
#define XE_NP_BOARD_NP_I2C_MSIK_ENABLE \
    (XE_NP_BOARD_V2_PSSI_NP1_ENABLE && !XE_NP_BOARD_HSE_ONLY_CLOCKS)
#endif
#if XE_NP_BOARD_HSE_ONLY_CLOCKS && XE_NP_BOARD_NP_I2C_MSIK_ENABLE
#error "HSE-only firmware cannot select MSIK for probe I2C"
#endif
#if (XE_NP_BOARD_NP_I2C_MSIK_ENABLE != 0U)
#define XE_NP_BOARD_NP_I2C_TIMING 0xF0F01F1FUL
#else
#define XE_NP_BOARD_NP_I2C_TIMING 0xF0F0FFFFUL
#endif

/*
 * Passive closed-loop listener fitted by the V2 schematic:
 *   PA5 = NP1 PSB_CLK = SPI1_SCK (AF5)
 *   PB5 = NP1 PSB_DATA3 = SPI1_MOSI (AF5)
 *
 * SPI1 is always configured as a receive-only slave, so neither pin is ever
 * driven by the MCU. SPI2/SPI3 have candidate MOSI data nets on V2, but their
 * SCK pins are not connected to NP1 PSB_CLK and therefore remain disabled.
 */
#ifndef XE_NP_BOARD_NP1_SPI_TAP_ENABLE
#define XE_NP_BOARD_NP1_SPI_TAP_ENABLE (XE_NP_BOARD_V2_PSSI_NP1_ENABLE && !XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE)
#endif
#if XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE && XE_NP_BOARD_NP1_SPI_TAP_ENABLE
#error "The NP1 auxiliary SPI listener is not an NP2 decoder"
#endif
#define XE_NP_BOARD_NP1_SPI_TAP_DATA_LINE 3U
#define XE_NP_BOARD_NP1_SPI_TAP_PACKED_RATE_HZ \
    (XE_NP_NEUROPIXELS_PSB_CLK_HZ / 8UL)

#define XE_NP_NEUROPIXELS_MAX_PROBES 3U
#define XE_NP_NEUROPIXELS_CHANNELS_PER_PROBE 384U
#if XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE
#if XE_NP_BOARD_EXPERIMENTAL_NP2_128MHZ_20KHZ_CORE
#define XE_NP_NEUROPIXELS_SAMPLE_RATE_HZ 20000U
#define XE_NP_NEUROPIXELS_MCLK_HZ 32000000UL
#define XE_NP_NEUROPIXELS_MCLK_TOLERANCE_HZ 64000UL
#define XE_NP_NEUROPIXELS_PSB_CLK_FULL_HZ 32000000UL
#else
#define XE_NP_NEUROPIXELS_SAMPLE_RATE_HZ 30000U
#define XE_NP_NEUROPIXELS_MCLK_HZ 48000000UL
#define XE_NP_NEUROPIXELS_MCLK_TOLERANCE_HZ 96000UL
#define XE_NP_NEUROPIXELS_PSB_CLK_FULL_HZ 48000000UL
#endif
#define XE_NP_NEUROPIXELS_PSB_CLK_HALF_HZ 0UL /* no NP1 half-rate mode */
#define XE_NP_NEUROPIXELS_PSB_DATA_LINES 3U
#else
#define XE_NP_NEUROPIXELS_SAMPLE_RATE_HZ 30000U
#define XE_NP_NEUROPIXELS_MCLK_HZ 93600000UL
#define XE_NP_NEUROPIXELS_MCLK_TOLERANCE_HZ 5000UL
#define XE_NP_NEUROPIXELS_PSB_CLK_FULL_HZ 23400000UL
#define XE_NP_NEUROPIXELS_PSB_CLK_HALF_HZ 11700000UL
#define XE_NP_NEUROPIXELS_PSB_DATA_LINES 7U
#endif
#define XE_NP_NEUROPIXELS_PSB_CLK_HZ XE_NP_NEUROPIXELS_PSB_CLK_FULL_HZ

/*
 * USB-only benchmark path: run SYSCLK/HCLK at the STM32U5 VOS1 limit of
 * 160 MHz. PA8/MCO is disabled in this mode because it cannot simultaneously
 * provide the 93.6 MHz Neuropixels MCLK from the same PLL1R system clock.
 */
#ifndef XE_NP_BOARD_USB_BENCH_160MHZ_CORE
#define XE_NP_BOARD_USB_BENCH_160MHZ_CORE 0U
#endif

/*
 * Experimental overclock path: keep SYSCLK/HCLK at 187.2 MHz from PLL1R while
 * prescaling MCO so the Neuropixels MCLK on PA8 remains 93.6 MHz.
 *
 * PLL1P is dedicated to the SDMMC kernel.  Keep it at 93.6 MHz, which is a
 * valid SDR104 clock point and lets the host use CLKDIV=0 below the SDR104
 * 208 MHz clock ceiling.  PLL1R remains the independent
 * 187.2 MHz SYSCLK/MCO source. This remains outside the STM32U5 VOS1 160 MHz
 * datasheet limit.
 */
#ifndef XE_NP_BOARD_EXPERIMENTAL_1872MHZ_CORE
#define XE_NP_BOARD_EXPERIMENTAL_1872MHZ_CORE 0U
#endif

/* Exact 20 kS/s qualification: PLL1R/HCLK = 124.8 MHz and PA8/MCO /2 =
 * 62.4 MHz. This intentionally preserves the 8 HCLK cycles per 15.6 MHz PSB
 * edge used by the 30 kS/s profile while reducing aggregate request traffic. */
#ifndef XE_NP_BOARD_EXPERIMENTAL_1248MHZ_CORE
#define XE_NP_BOARD_EXPERIMENTAL_1248MHZ_CORE 0U
#endif

/* Extreme, SWD-recoverable 20 kS/s timing experiment: retain the 62.4 MHz
 * probe MCLK via MCO /4 but raise HCLK to 249.6 MHz, providing 16 HCLK cycles
 * per raw PSB edge. This is well outside the 160 MHz VOS1 data-sheet limit. */
#ifndef XE_NP_BOARD_EXPERIMENTAL_2496MHZ_CORE
#define XE_NP_BOARD_EXPERIMENTAL_2496MHZ_CORE 0U
#endif

/* SWD-only bracketing sweep. With the 24 MHz HSE and PLLM=5, PLL1R is
 * 2.4 MHz times this N value. MCO /4 keeps exactly 16 HCLK cycles per PSB
 * edge throughout the sweep. Zero leaves this profile disabled. */
#ifndef XE_NP_BOARD_EXPERIMENTAL_PLL1N_CORE
#define XE_NP_BOARD_EXPERIMENTAL_PLL1N_CORE 0U
#endif

#if ((XE_NP_V2_MEDIA_ENABLE + XE_NP_BOARD_USB_BENCH_160MHZ_CORE + XE_NP_BOARD_EXPERIMENTAL_1872MHZ_CORE + \
      XE_NP_BOARD_EXPERIMENTAL_1248MHZ_CORE + XE_NP_BOARD_EXPERIMENTAL_2496MHZ_CORE + \
      XE_NP_BOARD_EXPERIMENTAL_NP2_192MHZ_CORE + XE_NP_BOARD_EXPERIMENTAL_NP2_128MHZ_20KHZ_CORE + \
      ((XE_NP_BOARD_EXPERIMENTAL_PLL1N_CORE != 0U) ? 1U : 0U)) > 1U)
#error "Select only one core clock profile."
#endif

#if XE_NP_V2_MEDIA_ENABLE
/* Dedicated MCU ADC/camera role: HSE24/6*75/2=150 MHz, SPI1 /2=75 MHz.
 * No Neuropixels MCO. SD continues on its independent PLL2Q kernel. */
#define XE_NP_BOARD_PLL1_M 6U
#define XE_NP_BOARD_PLL1_N 75U
#define XE_NP_BOARD_PLL1_FRACN 0U
#define XE_NP_BOARD_PLL1P_DIV 6U
#define XE_NP_BOARD_PLL1Q_DIV 2U
#define XE_NP_BOARD_PLL1R_DIV 2U
#define XE_NP_BOARD_SYSCLK_HZ 150000000UL
#define XE_NP_BOARD_HCLK_HZ 150000000UL
#define XE_NP_BOARD_MCO_DISABLED 1U
#define XE_NP_BOARD_MCO_DIVIDER 1U
#define XE_NP_BOARD_EXPECTED_MCO_HZ 0UL
#define XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ 0UL
#define XE_NP_BOARD_EXPECTED_PSB_CLK_HALF_HZ 0UL
#define XE_NP_BOARD_APB_CLK_DIVIDER 1U
#elif XE_NP_BOARD_EXPERIMENTAL_NP2_192MHZ_CORE
/* Explicit CPU overclock, NOT qualified: 24 MHz /6 *96 =384 MHz VCO.
 * PLL1R /2 =192 MHz HCLK, MCO /4 =48 MHz NP2 clock. SD remains on PLL2Q.
 * MCO is held OFF by SystemClock_Config until the NP2 power/reset coordinator
 * allows it; never expose the initial NP1 93.6 MHz MCO to an NP2 probe. */
#define XE_NP_BOARD_PLL1_M 6U
#define XE_NP_BOARD_PLL1_N 96U
#define XE_NP_BOARD_PLL1_FRACN 0U
#define XE_NP_BOARD_PLL1P_DIV 4U
#if XE_NP_PSRAM_OVERFLOW_PLL1Q128
#define XE_NP_BOARD_PLL1Q_DIV XE_NP_PSRAM_OVERFLOW_PLL1Q_30KHZ_DIV
#else
#define XE_NP_BOARD_PLL1Q_DIV 4U
#endif
#define XE_NP_BOARD_PLL1R_DIV 2U
#define XE_NP_BOARD_SYSCLK_HZ 192000000UL
#define XE_NP_BOARD_HCLK_HZ 192000000UL
#define XE_NP_BOARD_MCO_DISABLED 0U
#define XE_NP_BOARD_MCO_DIVIDER 4U
#define XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ 48000000UL
#define XE_NP_BOARD_EXPECTED_PSB_CLK_HALF_HZ 0UL
#define XE_NP_BOARD_EXPECTED_MCO_HZ 48000000UL
#define XE_NP_BOARD_APB_CLK_DIVIDER 2U
#elif XE_NP_BOARD_EXPERIMENTAL_NP2_128MHZ_20KHZ_CORE
/* 24 MHz /6 *64 =256 MHz VCO; PLL1R /2 =128 MHz HCLK and MCO /4 =32 MHz.
 * This is within the 160 MHz VOS1 core limit, preserves the proven four CPU
 * cycles per PSSI tick, and establishes the physical 20 kS/s sampling clock
 * for the 16-bit extended-PSSI three-NP2 path.  It is a distinct future
 * image, not a supported flag for the existing single-NP2 recorder. */
#define XE_NP_BOARD_PLL1_M 6U
#if XE_NP_NP2_SYNTHETIC_SD_120MHZ_CPU
#define XE_NP_BOARD_PLL1_N 60U
#define XE_NP_BOARD_SYSCLK_HZ 120000000UL
#define XE_NP_BOARD_HCLK_HZ 120000000UL
#define XE_NP_BOARD_MCO_DISABLED 1U
#define XE_NP_BOARD_EXPECTED_MCO_HZ 0UL
#else
#define XE_NP_BOARD_PLL1_N 64U
#define XE_NP_BOARD_SYSCLK_HZ 128000000UL
#define XE_NP_BOARD_HCLK_HZ 128000000UL
#define XE_NP_BOARD_MCO_DISABLED 0U
#define XE_NP_BOARD_EXPECTED_MCO_HZ 32000000UL
#endif
#define XE_NP_BOARD_PLL1_FRACN 0U
#define XE_NP_BOARD_PLL1P_DIV 4U
#if XE_NP_PSRAM_OVERFLOW_PLL1Q128
#define XE_NP_BOARD_PLL1Q_DIV 2U
#else
#define XE_NP_BOARD_PLL1Q_DIV 4U
#endif
#define XE_NP_BOARD_PLL1R_DIV 2U
#define XE_NP_BOARD_MCO_DIVIDER 4U
#define XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ 32000000UL
#define XE_NP_BOARD_EXPECTED_PSB_CLK_HALF_HZ 0UL
#define XE_NP_BOARD_APB_CLK_DIVIDER 2U
#elif XE_NP_BOARD_USB_BENCH_160MHZ_CORE
#define XE_NP_BOARD_USB_BENCH_PLL1_N 80U
#define XE_NP_BOARD_PLL1_M 6U
#define XE_NP_BOARD_SYSCLK_HZ (2000000UL * XE_NP_BOARD_USB_BENCH_PLL1_N)
#define XE_NP_BOARD_HCLK_HZ XE_NP_BOARD_SYSCLK_HZ
#define XE_NP_BOARD_PLL1_N XE_NP_BOARD_USB_BENCH_PLL1_N
#define XE_NP_BOARD_PLL1_FRACN 0U
#define XE_NP_BOARD_PLL1P_DIV 6U
#define XE_NP_BOARD_PLL1Q_DIV 2U
#define XE_NP_BOARD_PLL1R_DIV 2U
#define XE_NP_BOARD_MCO_DISABLED 1U
#define XE_NP_BOARD_MCO_DIVIDER 1U
#define XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ XE_NP_NEUROPIXELS_PSB_CLK_FULL_HZ
#define XE_NP_BOARD_EXPECTED_PSB_CLK_HALF_HZ XE_NP_NEUROPIXELS_PSB_CLK_HALF_HZ
#if (XE_NP_BOARD_USB_BENCH_PLL1_N > 80U)
#define XE_NP_BOARD_APB_CLK_DIVIDER 2U
#else
#define XE_NP_BOARD_APB_CLK_DIVIDER 1U
#endif
#define XE_NP_BOARD_EXPECTED_MCO_HZ 0UL
#elif XE_NP_BOARD_EXPERIMENTAL_1248MHZ_CORE
#define XE_NP_BOARD_SYSCLK_HZ 124800000UL
#define XE_NP_BOARD_HCLK_HZ 124800000UL
#define XE_NP_BOARD_PLL1_M 5U
#define XE_NP_BOARD_PLL1_N 52U
#define XE_NP_BOARD_PLL1_FRACN 0U
#define XE_NP_BOARD_PLL1P_DIV 4U
#define XE_NP_BOARD_PLL1Q_DIV 2U
#define XE_NP_BOARD_PLL1R_DIV 2U
#define XE_NP_BOARD_MCO_DISABLED 0U
#define XE_NP_BOARD_MCO_DIVIDER 2U
#define XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ 15600000UL
#define XE_NP_BOARD_EXPECTED_PSB_CLK_HALF_HZ 7800000UL
#define XE_NP_BOARD_APB_CLK_DIVIDER 2U
#define XE_NP_BOARD_EXPECTED_MCO_HZ 62400000UL
#elif XE_NP_BOARD_EXPERIMENTAL_2496MHZ_CORE
#define XE_NP_BOARD_SYSCLK_HZ 249600000UL
#define XE_NP_BOARD_HCLK_HZ 249600000UL
#define XE_NP_BOARD_PLL1_M 5U
#define XE_NP_BOARD_PLL1_N 104U
#define XE_NP_BOARD_PLL1_FRACN 0U
#define XE_NP_BOARD_PLL1P_DIV 4U
#define XE_NP_BOARD_PLL1Q_DIV 2U
#define XE_NP_BOARD_PLL1R_DIV 2U
#define XE_NP_BOARD_MCO_DISABLED 0U
#define XE_NP_BOARD_MCO_DIVIDER 4U
#define XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ 15600000UL
#define XE_NP_BOARD_EXPECTED_PSB_CLK_HALF_HZ 7800000UL
#define XE_NP_BOARD_APB_CLK_DIVIDER 2U
#define XE_NP_BOARD_EXPECTED_MCO_HZ 62400000UL
#elif (XE_NP_BOARD_EXPERIMENTAL_PLL1N_CORE != 0U)
#define XE_NP_BOARD_SYSCLK_HZ (2400000UL * XE_NP_BOARD_EXPERIMENTAL_PLL1N_CORE)
#define XE_NP_BOARD_HCLK_HZ XE_NP_BOARD_SYSCLK_HZ
#define XE_NP_BOARD_PLL1_M 5U
#define XE_NP_BOARD_PLL1_N XE_NP_BOARD_EXPERIMENTAL_PLL1N_CORE
#define XE_NP_BOARD_PLL1_FRACN 0U
#define XE_NP_BOARD_PLL1P_DIV 4U
#define XE_NP_BOARD_PLL1Q_DIV 2U
#define XE_NP_BOARD_PLL1R_DIV 2U
#define XE_NP_BOARD_MCO_DISABLED 0U
#define XE_NP_BOARD_MCO_DIVIDER 4U
#define XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ (XE_NP_BOARD_SYSCLK_HZ / 16UL)
#define XE_NP_BOARD_EXPECTED_PSB_CLK_HALF_HZ (XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ / 2UL)
#define XE_NP_BOARD_APB_CLK_DIVIDER 2U
#define XE_NP_BOARD_EXPECTED_MCO_HZ (XE_NP_BOARD_SYSCLK_HZ / 4UL)
#elif XE_NP_BOARD_EXPERIMENTAL_1872MHZ_CORE
#define XE_NP_BOARD_SYSCLK_HZ 187200000UL
#define XE_NP_BOARD_HCLK_HZ 187200000UL
#define XE_NP_BOARD_PLL1_M 5U
#define XE_NP_BOARD_PLL1_N 78U
#define XE_NP_BOARD_PLL1_FRACN 0U
#define XE_NP_BOARD_PLL1P_DIV 4U
#define XE_NP_BOARD_PLL1Q_DIV 2U
#define XE_NP_BOARD_PLL1R_DIV 2U
#define XE_NP_BOARD_MCO_DISABLED 0U
#define XE_NP_BOARD_MCO_DIVIDER 2U
#define XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ XE_NP_NEUROPIXELS_PSB_CLK_FULL_HZ
#define XE_NP_BOARD_EXPECTED_PSB_CLK_HALF_HZ XE_NP_NEUROPIXELS_PSB_CLK_HALF_HZ
#define XE_NP_BOARD_APB_CLK_DIVIDER 2U
#define XE_NP_BOARD_EXPECTED_MCO_HZ XE_NP_NEUROPIXELS_MCLK_HZ
#elif defined(XE_NP_BOARD_EVEN_PLL1R_TEST) && (XE_NP_BOARD_EVEN_PLL1R_TEST != 0U)
/* Same CPU/MCO frequency, even PLL1R divider for clock-margin isolation. */
#define XE_NP_BOARD_PLL1_M 5U
#define XE_NP_BOARD_SYSCLK_HZ 93600000UL
#define XE_NP_BOARD_HCLK_HZ 93600000UL
#define XE_NP_BOARD_PLL1_N 78U
#define XE_NP_BOARD_PLL1_FRACN 0U
#define XE_NP_BOARD_PLL1P_DIV 2U
#define XE_NP_BOARD_PLL1Q_DIV 2U
#define XE_NP_BOARD_PLL1R_DIV 4U
#define XE_NP_BOARD_MCO_DISABLED 0U
#define XE_NP_BOARD_MCO_DIVIDER 1U
#define XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ XE_NP_NEUROPIXELS_PSB_CLK_FULL_HZ
#define XE_NP_BOARD_EXPECTED_PSB_CLK_HALF_HZ XE_NP_NEUROPIXELS_PSB_CLK_HALF_HZ
#define XE_NP_BOARD_APB_CLK_DIVIDER 1U
#define XE_NP_BOARD_EXPECTED_MCO_HZ XE_NP_NEUROPIXELS_MCLK_HZ
#else
/*
 * Full-rate NP1 plus faster SDMMC, without overclocking the CPU:
 *
 *   HSE / M = 24 MHz / 6 = 4 MHz
 *   PLL1 VCO = 4 MHz * 117 = 468 MHz
 *   PLL1R / 5 = SYSCLK = PA8/MCO = 93.6 MHz
 *   PLL1P / 3 = SDMMC kernel = 156 MHz
 *
 * Keeping PLL1R and MCO at exactly 93.6 MHz is mandatory: the probe derives
 * its full-rate 23.4 MHz PSB clock from this MCLK.  The higher, integer VCO is
 * used only to give SDMMC more transport headroom.
 */
#define XE_NP_BOARD_PLL1_M 6U
#define XE_NP_BOARD_SYSCLK_HZ 93600000UL
#define XE_NP_BOARD_HCLK_HZ 93600000UL
#define XE_NP_BOARD_PLL1_N 117U
#define XE_NP_BOARD_PLL1_FRACN 0U
#define XE_NP_BOARD_PLL1P_DIV 3U
#define XE_NP_BOARD_PLL1Q_DIV 3U
#define XE_NP_BOARD_PLL1R_DIV 5U
#define XE_NP_BOARD_MCO_DISABLED 0U
#define XE_NP_BOARD_MCO_DIVIDER 1U
#define XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ XE_NP_NEUROPIXELS_PSB_CLK_FULL_HZ
#define XE_NP_BOARD_EXPECTED_PSB_CLK_HALF_HZ XE_NP_NEUROPIXELS_PSB_CLK_HALF_HZ
#define XE_NP_BOARD_APB_CLK_DIVIDER 1U
#define XE_NP_BOARD_EXPECTED_MCO_HZ XE_NP_NEUROPIXELS_MCLK_HZ
#endif

/*
 * Bench tooling may explicitly override the selected profile's MCO plan. Do
 * not install a nominal default override here: doing so would silently change
 * the 187.2 MHz profile from its required MCO /2 to MCO /1.
 */
#if defined(XE_NP_BOARD_EXPERIMENT_MCO_DIVIDER) || \
    defined(XE_NP_BOARD_EXPERIMENT_EXPECTED_MCO_HZ)
#define XE_NP_BOARD_EXPERIMENT_MCO_OVERRIDE_ACTIVE 1U
#else
#define XE_NP_BOARD_EXPERIMENT_MCO_OVERRIDE_ACTIVE 0U
#endif

#ifndef XE_NP_BOARD_EXPERIMENT_MCO_DIVIDER
#define XE_NP_BOARD_EXPERIMENT_MCO_DIVIDER XE_NP_BOARD_MCO_DIVIDER
#endif
#ifndef XE_NP_BOARD_EXPERIMENT_EXPECTED_MCO_HZ
#define XE_NP_BOARD_EXPERIMENT_EXPECTED_MCO_HZ XE_NP_BOARD_EXPECTED_MCO_HZ
#endif

#if XE_NP_BOARD_EXPERIMENT_MCO_OVERRIDE_ACTIVE
#if XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE
#error "NP2 does not permit the NP1 MCO/rate override"
#endif
#define XE_NP_BOARD_EFFECTIVE_MCO_DIVIDER XE_NP_BOARD_EXPERIMENT_MCO_DIVIDER
#define XE_NP_BOARD_EFFECTIVE_EXPECTED_MCO_HZ XE_NP_BOARD_EXPERIMENT_EXPECTED_MCO_HZ
#define XE_NP_BOARD_EFFECTIVE_EXPECTED_PSB_CLK_FULL_HZ (XE_NP_BOARD_EFFECTIVE_EXPECTED_MCO_HZ / 4UL)
#define XE_NP_BOARD_EFFECTIVE_EXPECTED_PSB_CLK_HALF_HZ (XE_NP_BOARD_EFFECTIVE_EXPECTED_PSB_CLK_FULL_HZ / 2UL)
#else
#define XE_NP_BOARD_EFFECTIVE_MCO_DIVIDER XE_NP_BOARD_MCO_DIVIDER
#define XE_NP_BOARD_EFFECTIVE_EXPECTED_MCO_HZ XE_NP_BOARD_EXPECTED_MCO_HZ
#define XE_NP_BOARD_EFFECTIVE_EXPECTED_PSB_CLK_FULL_HZ XE_NP_BOARD_EXPECTED_PSB_CLK_FULL_HZ
#define XE_NP_BOARD_EFFECTIVE_EXPECTED_PSB_CLK_HALF_HZ XE_NP_BOARD_EXPECTED_PSB_CLK_HALF_HZ
#endif

/* Boot MCO1 selects PLL1R, the same PLL output used by SYSCLK. Stopped-only
 * runtime NP2 profiles may select direct HSE instead. */
#if (XE_NP_BOARD_MCO_DISABLED == 0U) && \
    ((XE_NP_BOARD_EFFECTIVE_EXPECTED_MCO_HZ * XE_NP_BOARD_EFFECTIVE_MCO_DIVIDER) != \
     XE_NP_BOARD_SYSCLK_HZ)
#error "The declared MCO frequency/divider does not match the PLL1R source clock"
#endif

/*
 * Production NP1 PSSI images are locked to 30 kS/s. Reduced-rate and USB-only
 * characterization images must explicitly opt out on their compiler command
 * line; they are not valid full-rate recording firmware.
 */
#ifndef XE_NP_BOARD_ALLOW_NON_30KSPS_MCO
#define XE_NP_BOARD_ALLOW_NON_30KSPS_MCO 0U
#endif

#if (XE_NP_BOARD_V2_PSSI_NP1_ENABLE != 0U) && \
    (XE_NP_V2_MEDIA_ENABLE == 0U) && \
    (XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE == 0U) && \
    (XE_NP_BOARD_ALLOW_NON_30KSPS_MCO == 0U)
#define XE_NP_BOARD_NP1_30KSPS_CLOCK_LOCK 1U
#else
#define XE_NP_BOARD_NP1_30KSPS_CLOCK_LOCK 0U
#endif

#if XE_NP_BOARD_NP1_30KSPS_CLOCK_LOCK
#if (XE_NP_BOARD_MCO_DISABLED != 0U)
#error "NP1 30 kS/s requires PA8/MCO to drive the probe clock"
#endif
#if (XE_NP_BOARD_EFFECTIVE_EXPECTED_MCO_HZ != XE_NP_NEUROPIXELS_MCLK_HZ)
#error "NP1 30 kS/s requires an exact 93.6 MHz PA8/MCO clock"
#endif
#if (XE_NP_BOARD_EFFECTIVE_EXPECTED_PSB_CLK_FULL_HZ != XE_NP_NEUROPIXELS_PSB_CLK_FULL_HZ)
#error "NP1 30 kS/s requires the 23.4 MHz full-rate PSB clock"
#endif
#endif

/*
 * USB OTG HS internal DMA is experimental. Earlier real NP stream tests stalled
 * with PCD tx_busy stuck; keep disabled unless explicitly benchmarking.
 */
#ifndef XE_NP_BOARD_USB_OTG_HS_INTERNAL_DMA
#define XE_NP_BOARD_USB_OTG_HS_INTERNAL_DMA 0U
#endif

#if (XE_NP_BOARD_V2_PSSI_NP1_ENABLE != 0U) && \
    ((XE_NP_BOARD_HCLK_HZ * 2UL) < (XE_NP_NEUROPIXELS_PSB_CLK_FULL_HZ * 5UL))
#error "PSSI requires HCLK to be at least 2.5 times the NP PSB clock"
#endif

/* Diagnostic/recording option: make OTG-HS IDMA yield the system bus after
 * each SRAM1 beat instead of its default INCR4 burst. */
#ifndef XE_NP_BOARD_USB_OTG_HS_IDMA_SINGLE_BURST
#define XE_NP_BOARD_USB_OTG_HS_IDMA_SINGLE_BURST 0U
#endif

/* Bulk endpoint completion must preempt capture bookkeeping.  GPIO requests
 * remain GPDMA-high-priority; their IRQ only accounts completed blocks. */
#ifndef XE_NP_BOARD_USB_OTG_HS_IRQ_PREEMPT_PRIO
#define XE_NP_BOARD_USB_OTG_HS_IRQ_PREEMPT_PRIO 1U
#endif

/*
 * Clock/USB isolation mode: keep the NP MCLK clock tree active but pause
 * automatic NP bring-up, capture, and storage servicing. Use only while
 * characterizing USB throughput with the synthetic source.
 */
#define XE_NP_BOARD_USB_SYNTHETIC_CLOCK_BENCH_ISOLATION 0U

/*
 * Temporary storage characterization image. This runs a raw SD write benchmark
 * at boot and reclaims some NP capture SRAM for a larger SDMMC IDMA buffer.
 * Disable before returning to normal NP USB streaming firmware.
 */
#ifndef XE_NP_BOARD_SD_WRITE_BENCH_IMAGE
#define XE_NP_BOARD_SD_WRITE_BENCH_IMAGE 0U
#endif

/*
 * Clock-isolation experiment: skip SD host initialization and keep the app's
 * runtime SD handle unbound so the USB/NP path can be validated without any
 * SD/UHS/DLYB side effects.  V2 normally initializes SD so either the USB or
 * raw-SD recorder can own the PSSI byte stream.
 */
#ifndef XE_NP_BOARD_EXPERIMENT_DISABLE_SD_INIT
#define XE_NP_BOARD_EXPERIMENT_DISABLE_SD_INIT 0U
#endif

/* SD benchmark diagnostic markers visible from SWD parser tooling */
#define XE_NP_SD_BENCH_DIAG_DISABLED 0x64697361U
#define XE_NP_SD_BENCH_STATUS_MAIN_ENTRY 9U
#define XE_NP_SD_BENCH_STATUS_NOT_RUN 0U
#define XE_NP_SD_BENCH_STATUS_RUNNING 1U
#define XE_NP_SD_BENCH_STATUS_OK 2U
#define XE_NP_SD_BENCH_STATUS_SKIPPED 3U
#define XE_NP_SD_BENCH_STATUS_HAL_START_FAIL 4U
#define XE_NP_SD_BENCH_STATUS_TIMEOUT 5U
#define XE_NP_SD_BENCH_STATUS_CARD_ERROR 6U
#define XE_NP_SD_BENCH_STATUS_LL_BUILD_FAIL 7U
#define XE_NP_SD_BENCH_STATUS_DISABLED 8U
#define XE_NP_SD_BENCH_STATUS_PRE_MAIN 10U
#define XE_NP_SD_BENCH_STATUS_UNEXPECTED 11U
#define XE_NP_SD_BENCH_STATUS_DISPATCHED 12U
#define XE_NP_SD_BENCH_STATUS_ZERO 13U
#define XE_NP_SD_BENCH_STATUS_INTEGRITY_FAIL 14U

#define XE_NP_MISC_SAMPLE_RATE_HZ 1250U

/* U11 as drawn has CSB grounded and PF0 on SDO. Do not drive that pin as
 * I2C SDA until CSB/SDI/SDO wiring is corrected/physically confirmed. */
#ifndef XE_NP_BOARD_BME280_I2C_WIRING_CONFIRMED
#define XE_NP_BOARD_BME280_I2C_WIRING_CONFIRMED 0U
#endif
#ifndef XE_NP_BOARD_SENSOR_SERVICE_ENABLE
#define XE_NP_BOARD_SENSOR_SERVICE_ENABLE 1U
#endif
/* Conservative ~50 kHz with the normal 46.8 MHz HSE-derived PCLK1. */
#if XE_NP_BOARD_HSE_ONLY_CLOCKS
#define XE_NP_BOARD_SENSOR_I2C_TIMING 0x6030344DUL
#else
#define XE_NP_BOARD_SENSOR_I2C_TIMING 0x00303D5BUL
#endif

/* Qualified separately from CPU/MCO. Zero retains the PLL1P control profile.
 * PLL2Q reaches SDMMC through ICLK; OSPI must not reprogram that shared PLL.
 * This is the STM32U5 SDMMC kernel-clock ceiling, independent of the card
 * signalling mode or CPU frequency. A faster PLL may exist, but it must not
 * be routed to SDMMC. */
#define XE_NP_BOARD_SDMMC_KERNEL_MAX_HZ 120000000UL
#ifndef XE_NP_BOARD_SD_PLL2Q_HZ
#define XE_NP_BOARD_SD_PLL2Q_HZ 0UL
#endif
#ifndef XE_NP_BOARD_SD_PLL2Q_OVERCLOCK
#define XE_NP_BOARD_SD_PLL2Q_OVERCLOCK 0U
#endif
/* Out-of-spec 3.3-V High-Speed bus overclock. Kept off in normal images and
 * enabled only by the bounded raw-process test; the SD spec ceiling remains
 * 50 MHz. Kernel and bus are matched to the explicitly admitted test points. */
#ifndef XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ
#define XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ 0UL
#endif
#ifndef XE_NP_BOARD_SD_HIGHSPEED_RX_CLOCK
#define XE_NP_BOARD_SD_HIGHSPEED_RX_CLOCK 0U
#endif
#ifndef XE_NP_BOARD_SD_HIGHSPEED_FALLING_EDGE
#define XE_NP_BOARD_SD_HIGHSPEED_FALLING_EDGE 0U
#endif
#ifndef XE_NP_SD_ALLOW_HIGH_SPEED_RAW_PROCESS_TEST
#define XE_NP_SD_ALLOW_HIGH_SPEED_RAW_PROCESS_TEST 0U
#endif
#ifndef XE_NP_SD_ALLOW_HIGH_SPEED_BASIC_TEST
#define XE_NP_SD_ALLOW_HIGH_SPEED_BASIC_TEST 0U
#endif
#if XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ != 0UL
#if (!XE_NP_SD_ALLOW_HIGH_SPEED_RAW_PROCESS_TEST && !XE_NP_SD_ALLOW_HIGH_SPEED_BASIC_TEST) || \
    ((XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ != 80000000UL) && \
     (XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ != 86000000UL) && \
     (XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ != 88000000UL) && \
     (XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ != 90000000UL) && \
     (XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ != 100000000UL) && \
     (XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ != 104000000UL) && \
     (XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ != 106000000UL) && \
     (XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ != 108000000UL) && \
     (XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ != 110000000UL) && \
     (XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ != 112000000UL) && \
     (XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ != 114000000UL) && \
     (XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ != 116000000UL) && \
     (XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ != 118000000UL) && \
     (XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ != 120000000UL)) || \
    (XE_NP_BOARD_SD_PLL2Q_HZ != XE_NP_BOARD_SD_HIGHSPEED_OVERCLOCK_HZ) || \
    (XE_NP_BOARD_SD_HIGHSPEED_RX_CLOCK > 1U) || \
    (XE_NP_BOARD_SD_HIGHSPEED_FALLING_EDGE > 1U)
#error "High-Speed bus overclock is restricted to bounded diagnostic tests at admitted matched PLL2Q clocks and known receive timing"
#endif
#elif (XE_NP_BOARD_SD_HIGHSPEED_RX_CLOCK != 0U) || (XE_NP_BOARD_SD_HIGHSPEED_FALLING_EDGE != 0U)
#error "Experimental High-Speed receive timing requires the bounded overclock test"
#endif
/* Private SDR50 card-bus overclock; never enabled by normal builds.
 * The bounded 102/104 MHz tests use PLL2Q directly, below the 120 MHz
 * STM32U5 SDMMC kernel limit. */
#ifndef XE_NP_BOARD_SD_SDR50_TARGET_HZ
#define XE_NP_BOARD_SD_SDR50_TARGET_HZ 100000000UL
#endif
#ifndef XE_NP_BOARD_SD_SDR50_BUS_OVERCLOCK
#define XE_NP_BOARD_SD_SDR50_BUS_OVERCLOCK 0U
#endif
#ifndef XE_NP_NP2_TRIPLE_SYNTHETIC_SD_ENABLE
#define XE_NP_NP2_TRIPLE_SYNTHETIC_SD_ENABLE 0U
#endif
#if (XE_NP_BOARD_SD_SDR50_TARGET_HZ < 100000000UL)
#if XE_NP_SD_BASIC_DIAG_ENABLE && XE_NP_SD_BASIC_SDR50 && (XE_NP_SD_BASIC_CLOCK_DIV == 1U) && \
    (XE_NP_BOARD_SD_SDR50_TARGET_HZ == (XE_NP_BOARD_SD_PLL2Q_HZ / 2U))
/* Isolated divided-clock UHS regression diagnostic, not a logger profile. */
#else
#if (!XE_NP_PSSI_LOGGER_ENABLE && !XE_NP_USB_UNIFIED_ENABLE && !XE_NP_NP2_SD_APP_ENABLE && !XE_NP_NP2_TRIPLE_SYNTHETIC_SD_ENABLE && !XE_NP_NP2_LIVE_SD_ENABLE) || \
    ((XE_NP_BOARD_SD_SDR50_TARGET_HZ != 64000000UL) && (XE_NP_BOARD_SD_SDR50_TARGET_HZ != 80000000UL)) || \
    (XE_NP_BOARD_SD_PLL2Q_HZ != XE_NP_BOARD_SD_SDR50_TARGET_HZ)
#error "Lower SDR50 targets require an explicit 64/80 MHz PLL2Q logger profile"
#endif
#endif
#elif (XE_NP_BOARD_SD_SDR50_TARGET_HZ != 100000000UL) && \
    ((!XE_NP_BOARD_SD_SDR50_BUS_OVERCLOCK) || \
     ((XE_NP_BOARD_SD_SDR50_TARGET_HZ != 102000000UL) && (XE_NP_BOARD_SD_SDR50_TARGET_HZ != 104000000UL)) || \
     (XE_NP_BOARD_SD_PLL2Q_HZ != XE_NP_BOARD_SD_SDR50_TARGET_HZ))
#error "SDR50 above 100 MHz requires an explicit bounded 102/104 MHz bypass experiment"
#endif
#ifndef XE_NP_BOARD_SD_RISING_EDGE_FIRST
#define XE_NP_BOARD_SD_RISING_EDGE_FIRST 0U
#endif
#ifndef XE_NP_BOARD_SD_SDR50_ONLY
/* Recording baseline stays SDR50 until a faster path is write-qualified.
 * A supply upgrade alone does not qualify SDR104 signal timing. */
#define XE_NP_BOARD_SD_SDR50_ONLY 1U
#endif
#ifndef XE_NP_BOARD_SD_SDR104_ONLY
#define XE_NP_BOARD_SD_SDR104_ONLY 0U
#endif
#ifndef XE_NP_BOARD_SD_TEST_CLKDIV
#define XE_NP_BOARD_SD_TEST_CLKDIV 0U
#endif
#ifndef XE_NP_BOARD_SD_DMA_READ_POLLING_ENABLE
#define XE_NP_BOARD_SD_DMA_READ_POLLING_ENABLE 0U
#endif
#ifndef XE_NP_BOARD_SD_DLYB_EXHAUSTIVE
#define XE_NP_BOARD_SD_DLYB_EXHAUSTIVE 0U
#endif
#ifndef XE_NP_BOARD_SD_DISABLE_HWFC
#define XE_NP_BOARD_SD_DISABLE_HWFC 0U
#endif
/* Private SD signal-integrity controls. Keep the production defaults intact. */
#ifndef XE_NP_BOARD_SD_PULLUPS
/* Host-side 1.8 V internal pull-ups: bit0=PD2 CMD, bit1=PC8..11 DAT.
 * CK/CKIN remain unpulled. Opt-in qualification only; default is unchanged. */
#define XE_NP_BOARD_SD_PULLUPS 0U
#endif
#if XE_NP_BOARD_SD_PULLUPS > 3U
#error "Invalid SD CMD/DAT pull-up selection"
#endif
#ifndef XE_NP_BOARD_SD_GPIO_SPEED
#define XE_NP_BOARD_SD_GPIO_SPEED GPIO_SPEED_FREQ_VERY_HIGH
#endif
#ifndef XE_NP_BOARD_SD_CLK_GPIO_SPEED
#define XE_NP_BOARD_SD_CLK_GPIO_SPEED XE_NP_BOARD_SD_GPIO_SPEED
#endif
/* 0: existing mode policy, 1: direct CKIN, 2: tuned DLYB (SDR50 tests). */
#ifndef XE_NP_BOARD_SD_RX_CLOCK_TEST
#define XE_NP_BOARD_SD_RX_CLOCK_TEST 0U
#endif
#if XE_NP_BOARD_SD_RX_CLOCK_TEST > 2U
#error "Invalid SD receive-clock test selection"
#endif
#if (XE_NP_BOARD_SD_PLL2Q_HZ != 0UL) && \
    ((XE_NP_BOARD_SD_PLL2Q_HZ < 64000000UL) || \
      (XE_NP_BOARD_SD_PLL2Q_HZ > XE_NP_BOARD_SDMMC_KERNEL_MAX_HZ) || \
      ((XE_NP_BOARD_SD_PLL2Q_HZ % 2000000UL) != 0UL))
#error "STM32U5 SDMMC PLL2Q kernel requires 64..120 MHz in 2 MHz steps"
#endif
/* STOPPED_SDR50_100_GUARDS_BEGIN */
#if (XE_NP_NP2_SD_STOPPED_SDR50_100_TEST!=0U && XE_NP_NP2_SD_STOPPED_SDR50_100_TEST!=1U) || \
    (XE_NP_NP2_SD_STOPPED_SDR50_100_TEST && \
     (XE_NP_IMAGE_ROLE!=1U || !XE_NP_BOARD_HSE_ONLY_CLOCKS || \
      !XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
      !XE_NP_NP2_SD_STOPPED_FEED_TEST || !XE_NP_NP2_SD_STOPPED_SRAM6_TEST || \
      !XE_NP_NP2_SD_STOPPED_SRAM12_TEST || !XE_NP_PSRAM_OVERFLOW_PLL1Q128 || \
      XE_NP_PSRAM_OVERFLOW_PLL2Q108 || XE_NP_PSRAM_OVERFLOW_PLL1Q_30KHZ_DIV!=4U || \
      XE_NP_PSRAM_OVERFLOW_PRESCALER!=1U || !XE_NP_PSRAM_PAD_HSLV_ENABLE || \
      XE_NP_BOARD_SD_PLL2Q_HZ!=100000000UL || !XE_NP_BOARD_SD_SDR104_ONLY || \
      XE_NP_BOARD_SD_SDR50_ONLY || XE_NP_BOARD_SD_TEST_CLKDIV!=0U || \
      XE_NP_BOARD_SD_RX_CLOCK_TEST!=2U || !XE_NP_SD_ALLOW_S18R || \
      !XE_NP_SD_CMD11_PIN_COMPAT_ENABLE || XE_NP_BOARD_SD_SDR50_TARGET_HZ!=100000000UL || \
      XE_NP_BOARD_SD_SDR50_BUS_OVERCLOCK || XE_NP_NP2_SD_KERNEL96_POWER_TEST || \
      XE_NP_NP2_SD_HIGH_RATE_KERNEL120_TEST || XE_NP_NP2_SD_SDR50_POWER_TEST || \
      XE_NP_NP2_SD_VSC_FEED_TEST || XE_NP_NP2_SD_FEED_SOURCE_CHECK_TEST || \
      XE_NP_NP2_SD_FEED_DMA_CHECK_TEST || XE_NP_NP2_SD_DUAL30_PSRAM_SYSCLK192_TEST || \
      XE_NP_NP2_SD_DUAL30_PSRAM_Q128_TEST))
#error "Stopped SDR50/100 requires the exclusive HSE SRAM12/Q96 comparator"
#endif
/* STOPPED_SDR50_100_GUARDS_END */
/* STOPPED_DDR50_40_GUARDS_BEGIN */
#if (XE_NP_NP2_SD_STOPPED_DDR50_40_TEST!=0U && XE_NP_NP2_SD_STOPPED_DDR50_40_TEST!=1U) || \
    (XE_NP_NP2_SD_STOPPED_DDR50_40_TEST && \
     (XE_NP_IMAGE_ROLE!=1U || !XE_NP_BOARD_HSE_ONLY_CLOCKS || HSE_VALUE!=24000000UL || \
      !XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
      !XE_NP_NP2_SD_STOPPED_FEED_TEST || !XE_NP_NP2_SD_STOPPED_SRAM6_TEST || \
      !XE_NP_NP2_SD_STOPPED_SRAM12_TEST || !XE_NP_PSRAM_OVERFLOW_PLL1Q128 || \
      XE_NP_PSRAM_OVERFLOW_PLL2Q108 || XE_NP_PSRAM_OVERFLOW_PLL1Q_30KHZ_DIV!=4U || \
      XE_NP_PSRAM_OVERFLOW_PRESCALER!=1U || !XE_NP_PSRAM_PAD_HSLV_ENABLE || \
      XE_NP_BOARD_SD_PLL2Q_HZ!=80000000UL || !XE_NP_BOARD_SD_SDR104_ONLY || \
      !XE_NP_SD_PAD_HSLV_DISABLE || XE_NP_BOARD_SD_GPIO_SPEED!=GPIO_SPEED_FREQ_HIGH || \
      XE_NP_BOARD_SD_CLK_GPIO_SPEED!=GPIO_SPEED_FREQ_MEDIUM || \
      XE_NP_BOARD_SD_SDR50_ONLY || XE_NP_BOARD_SD_TEST_CLKDIV!=1U || \
      XE_NP_BOARD_SD_RX_CLOCK_TEST!=2U || !XE_NP_SD_ALLOW_S18R || \
      !XE_NP_SD_CMD11_PIN_COMPAT_ENABLE || XE_NP_NP2_SD_STOPPED_SDR50_100_TEST || \
      XE_NP_NP2_SD_STOPPED_SDR104_120_TEST || XE_NP_NP2_SD_STOPPED_MIXED12_TEST || \
      XE_NP_NP2_SD_STOPPED_MIXED12_20_TEST || XE_NP_NP2_SD_KERNEL96_POWER_TEST || \
      XE_NP_NP2_SD_HIGH_RATE_KERNEL120_TEST || XE_NP_NP2_SD_SDR50_POWER_TEST || \
      XE_NP_NP2_SD_VSC_FEED_TEST || XE_NP_NP2_SD_FEED_SOURCE_CHECK_TEST || \
      XE_NP_NP2_SD_FEED_DMA_CHECK_TEST || XE_NP_NP2_SD_DUAL30_PSRAM_SYSCLK192_TEST || \
      XE_NP_NP2_SD_DUAL30_PSRAM_Q128_TEST))
#error "Stopped DDR50/40 requires the exclusive HSE80/div1 HSLV-off SRAM12/Q96 comparator"
#endif
/* STOPPED_DDR50_40_GUARDS_END */
/* STOPPED_SDR104_120_GUARDS_BEGIN */
/* Inherit the strict HIGH_RATE_KERNEL120 clock/pin/geometry admission below;
 * this exception can only call the existing source-free SRAM12 comparator. */
#if (XE_NP_NP2_SD_STOPPED_SDR104_120_TEST!=0U && XE_NP_NP2_SD_STOPPED_SDR104_120_TEST!=1U) || \
    (XE_NP_NP2_SD_STOPPED_SDR104_120_TEST && \
     (!XE_NP_NP2_SD_HIGH_RATE_KERNEL120_TEST || \
      !XE_NP_NP2_SD_STOPPED_FEED_TEST || !XE_NP_NP2_SD_STOPPED_SRAM6_TEST || \
      !XE_NP_NP2_SD_STOPPED_SRAM12_TEST || XE_NP_BOARD_SD_PLL2Q_HZ!=120000000UL || \
      !XE_NP_SD_ALLOW_S18R || !XE_NP_SD_CMD11_PIN_COMPAT_ENABLE || \
      XE_NP_NP2_SD_STOPPED_VSC114_TEST || XE_NP_NP2_SD_STOPPED_SDR50_100_TEST || \
      XE_NP_NP2_SD_VSC_FEED_TEST || XE_NP_NP2_SD_VSC_PREERASE60_TEST || \
      XE_NP_NP2_SD_FEED_SOURCE_CHECK_TEST || XE_NP_NP2_SD_FEED_DMA_CHECK_TEST || \
      XE_NP_NP2_SD_DUAL30_PSRAM_Q128_TEST))
#error "Stopped SDR104/120 requires the exclusive high-rate SRAM12/Q96 comparator"
#endif
/* STOPPED_SDR104_120_GUARDS_END */
/* KERNEL80_GUARD_BEGIN */
#if XE_NP_NP2_SD_KERNEL80_POWER_TEST && \
    (XE_NP_IMAGE_ROLE!=1U || !XE_NP_BOARD_HSE_ONLY_CLOCKS || \
     !XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_NP2_LIVE_SD_ENABLE || \
     !XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
     !XE_NP_PSRAM_OVERFLOW_PLL1Q128 || XE_NP_BOARD_SD_PLL2Q_HZ!=80000000UL || \
     !XE_NP_NP2_SD_PROFILE_BUS54_TEST || !XE_NP_NP2_SD_DUAL15_BUS54_TEST || \
     !XE_NP_NP2_LIVE_SD_VSC_TEST || XE_NP_NP2_LIVE_SD_DIRECT || \
     !XE_NP_BOARD_SD_SDR104_ONLY || XE_NP_BOARD_SD_SDR50_ONLY || \
     XE_NP_BOARD_SD_RX_CLOCK_TEST!=2U || XE_NP_BOARD_SD_TEST_CLKDIV!=0U || \
     XE_NP_NP2_SD_KERNEL96_POWER_TEST || XE_NP_NP2_SD_HIGH_RATE_KERNEL120_TEST || \
     XE_NP_NP2_SD_STOPPED_DDR50_40_TEST || XE_NP_NP2_SD_STOPPED_SDR50_100_TEST || \
     XE_NP_NP2_SD_SDR50_POWER_TEST || XE_NP_NP2_SD_DUAL20_BUS54_TEST || \
     XE_NP_NP2_SD_DUAL20_STATUS_SLOW_QUERY_TEST)
#error "SD kernel80 power trial requires the strict runtime PLL1Q SDR10480/RX2 APP"
#endif
/* KERNEL80_GUARD_END */
#if XE_NP_NP2_SD_KERNEL96_POWER_TEST && \
    (XE_NP_IMAGE_ROLE != 1U || !XE_NP_BOARD_HSE_ONLY_CLOCKS || \
     !XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_NP2_LIVE_SD_ENABLE || \
     !XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
     !XE_NP_PSRAM_OVERFLOW_PLL1Q128 || XE_NP_BOARD_SD_PLL2Q_HZ != 96000000UL || \
     !XE_NP_NP2_SD_PROFILE_BUS54_TEST || !XE_NP_NP2_SD_DUAL15_BUS54_TEST || \
     !XE_NP_NP2_LIVE_SD_VSC_TEST || XE_NP_NP2_LIVE_SD_DIRECT || \
     !XE_NP_BOARD_SD_SDR104_ONLY || XE_NP_BOARD_SD_SDR50_ONLY || \
     XE_NP_NP2_SD_SDR50_POWER_TEST || XE_NP_BOARD_SD_RX_CLOCK_TEST != 2U || \
     XE_NP_BOARD_SD_TEST_CLKDIV != 0U)
#error "SD kernel96 power trial requires the strict runtime PLL1Q SDR10496/RX2 APP with dual15 divided-bus policy"
#endif
/* SDR50_96_GUARDS_BEGIN */
#if (XE_NP_NP2_SD_DUAL20_SDR50_96_TEST!=0U && XE_NP_NP2_SD_DUAL20_SDR50_96_TEST!=1U) || \
    (XE_NP_NP2_SD_DUAL20_SDR50_96_TEST && \
     (!XE_NP_NP2_SD_KERNEL96_POWER_TEST || !XE_NP_BOARD_HSE_ONLY_CLOCKS || \
      !XE_NP_SD_CMD11_PIN_COMPAT_ENABLE || !XE_NP_SD_ALLOW_S18R || \
      XE_NP_SD_CARD_MAX_CURRENT_MA!=200U || XE_NP_BOARD_SD_PLL2Q_HZ!=96000000UL || \
      !XE_NP_BOARD_SD_SDR104_ONLY || XE_NP_BOARD_SD_SDR50_ONLY || \
      XE_NP_BOARD_SD_TEST_CLKDIV!=0U || XE_NP_BOARD_SD_RX_CLOCK_TEST!=2U || \
      XE_NP_BOARD_SD_RISING_EDGE_FIRST || XE_NP_SD_BASIC_DIRECT_CKIN || \
      !XE_NP_SD_PAD_HSLV_DISABLE || XE_NP_NP2_SD_SDR50_POWER_TEST || \
      XE_NP_NP2_SD_STOPPED_DDR50_40_TEST || XE_NP_NP2_SD_STOPPED_SDR50_100_TEST || \
      XE_NP_NP2_SD_STOPPED_SDR104_120_TEST || XE_NP_NP2_SD_KERNEL80_POWER_TEST || \
      XE_NP_NP2_SD_HIGH_RATE_KERNEL120_TEST || XE_NP_NP2_SD_DUAL20_BUS54_TEST || \
      XE_NP_NP2_SD_DUAL20_STATUS_SLOW_QUERY_TEST))
#error "SDR50/96 comparison requires the unchanged HSE kernel96/RX2/div0/200mA dual20 APP"
#endif
/* SDR50_96_GUARDS_END */
#if XE_NP_NP2_SD_HIGH_RATE_KERNEL120_TEST && \
    (XE_NP_IMAGE_ROLE!=1U || !XE_NP_BOARD_HSE_ONLY_CLOCKS || \
     !XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE || !XE_NP_NP2_LIVE_SD_ENABLE || \
     !XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
     !XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS || !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || \
     !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || \
     !XE_NP_NP2_LIVE_SD_VSC_TEST || XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U || \
     !XE_NP_NP2_LIVE_SD_COUNTED_WRITES || XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_V2_MEDIA_ENABLE || \
     !XE_NP_PSRAM_OVERFLOW_PLL1Q128 || XE_NP_PSRAM_OVERFLOW_PLL2Q108 || \
     XE_NP_PSRAM_OVERFLOW_PLL1Q_30KHZ_DIV!=4U || XE_NP_PSRAM_OVERFLOW_PRESCALER!=1U || \
     !XE_NP_PSRAM_PAD_HSLV_ENABLE || !XE_NP_NP2_SD_MULTI20_CORE64_TEST || \
     !XE_NP_NP2_SD_RAW20_CORE128_TEST || !XE_NP_NP2_SD_PROFILE_BUS54_TEST || \
     !XE_NP_NP2_SD_ACTIVE_CLOCK_SAVE_TEST || !XE_NP_NP2_SD_PROFILE_CLASSIC_TEST || \
     XE_NP_BOARD_SD_PLL2Q_HZ!=(XE_NP_NP2_SD_STOPPED_VSC114_TEST?114000000UL:120000000UL) || \
     !XE_NP_BOARD_SD_SDR104_ONLY || \
     XE_NP_BOARD_SD_SDR50_ONLY || XE_NP_BOARD_SD_RX_CLOCK_TEST!=2U || \
     XE_NP_BOARD_SD_TEST_CLKDIV!=0U || XE_NP_NP2_SD_SDR50_POWER_TEST || \
     XE_NP_NP2_SD_KERNEL96_POWER_TEST || XE_NP_NP2_SD_DUAL30_PSRAM_SYSCLK192_TEST || \
     XE_NP_NP2_LIVE_SD_VSC_PRESSURE_PREFIX_TEST || XE_NP_NP2_LIVE_SD_LAST_FREE_PREFETCH_TEST)
#error "High-rate kernel120 requires the unchanged copied runtime PLL1Q SDR104120/RX2 APP"
#endif
#if XE_NP_BOARD_HSE_ONLY_CLOCKS && \
    (XE_NP_NP2_SD_APP_ENABLE || XE_NP_NP2_TRIPLE_SYNTHETIC_SD_ENABLE || XE_NP_NP2_LIVE_SD_ENABLE) && \
    !XE_NP_NP2_LIVE_SD_PSRAM_PROBE && \
    (XE_NP_BOARD_SD_PLL2Q_HZ == 0UL)
#error "NP2 SD images require an HSE-fed PLL2Q SDMMC kernel"
#endif
#define XE_NP_PREVIEW_SAMPLE_RATE_HZ 625U
#define XE_NP_CAMERA_FRAME_RATE_HZ 16U
#define XE_NP_ADC_SAMPLE_RATE_HZ 160000U
#define XE_NP_STREAM_TYPE_COUNT 6U

typedef struct
{
    const char *signal;
    const char *mcu_pin;
} XE_NP_PinMapEntry;

typedef struct
{
    uint32_t mclk_hz;
    uint32_t psb_clk_hz;
    uint32_t sample_rate_hz;
    uint8_t psb_data_lines;
} XE_NP_NeuropixelsClockPlan;

typedef struct
{
    uint32_t negotiated_speed_mode;
    uint32_t card_speed;
    uint32_t card_speed_raw;
    uint32_t card_type;
    uint32_t last_speed_mode_attempt;
    uint32_t last_speed_mode_error;
    uint32_t last_speed_mode_card_state;
    uint8_t init_failed;
    uint8_t signal_1v8_enabled;
    uint8_t signal_1v8_seen;
    uint8_t last_speed_mode_status;
    uint32_t last_speed_mode_clock_div;
    uint32_t last_speed_mode_clock_edge;
    uint32_t last_speed_mode_selclkrx;
    uint32_t last_speed_mode_sdmmc_clock_source;
    uint32_t last_speed_mode_iclk_clock_source;
    uint32_t last_speed_mode_sdmmc_kernel_hz;
    uint32_t last_speed_mode_sdmmc_bus_hz;
    uint32_t last_speed_mode_sdmmc_target_bus_hz;
} XE_NP_BoardSdDiag;

typedef struct
{
    uint32_t magic;
    uint32_t version;
    uint32_t status;
    uint32_t speed_mode;
    uint32_t sdmmc_kernel_hz;
    uint32_t clock_div;
    uint32_t card_speed;
    uint32_t card_type;
    uint32_t start_block;
    uint32_t total_blocks;
    uint32_t chunk_blocks;
    uint32_t blocks_written;
    uint32_t elapsed_ms;
    uint32_t bytes_per_sec;
    uint32_t worst_chunk_us;
    uint32_t last_chunk_us;
    uint32_t error_code;
    uint32_t card_state;
    uint32_t hal_state;
    uint32_t hal_context;
    uint32_t sdmmc_sta;
    uint32_t sdmmc_dctrl;
    uint32_t fail_block;
    uint32_t fail_status;
    uint32_t signal_1v8_enabled;
    uint32_t signal_1v8_seen;
    uint32_t method;
    uint32_t ll_node_blocks;
    uint32_t ll_node_bytes;
    uint32_t ll_node_count;
    uint32_t ll_node_irq_count;
    uint32_t ll_build_status;
    uint32_t ll_cmd23_error;
    uint32_t sdmmc_idmabsize;
    uint32_t sdmmc_idmabar;
    uint32_t sdmmc_idmalar;
    uint32_t sdmmc_idmactrl;
    uint32_t ll_acmd23_error;
    uint32_t prep_flags;
    uint32_t cmd20_error;
    uint32_t sd_status_speed_class;
    uint32_t sd_status_perf_move;
    uint32_t sd_status_au_size;
    uint32_t sd_status_erase_size;
    uint32_t sd_status_uhs_grade;
    uint32_t sd_status_uhs_au_size;
    uint32_t sd_status_video_class;
    uint64_t bytes_written;
    uint32_t sdmmc_bus_hz;
    uint32_t sdmmc_clkcr;
    uint32_t dlyb_cr;
    uint32_t dlyb_cfgr;
    uint32_t gpio_hslv_enabled;
    uint32_t gpio_c_hslvr;
    uint32_t gpio_d_hslvr;
    uint32_t gpio_b_hslvr;
    uint32_t range_erase_ms;
    uint32_t ll_build_ms;
    uint32_t cmd20_ms;
    uint32_t chunk_count;
    uint32_t last_setup_ms;
    uint32_t worst_setup_ms;
    uint32_t total_setup_ms;
    uint32_t last_transfer_ms;
    uint32_t worst_transfer_ms;
    uint32_t total_transfer_ms;
    uint32_t last_busy_ms;
    uint32_t worst_busy_ms;
    uint32_t total_busy_ms;
    uint32_t dataend_count;
    uint32_t cmd13_poll_count;
    uint32_t wait_loop_count;
    uint32_t dlyb_tune_status;
    uint32_t dlyb_tune_units;
    uint32_t dlyb_tune_period_phase;
    uint32_t dlyb_tune_pass_mask;
    uint32_t dlyb_tune_selected_phase;
    uint32_t last_speed_mode_clock_div;
    uint32_t last_speed_mode_clock_edge;
    uint32_t last_speed_mode_selclkrx;
    uint32_t last_speed_mode_sdmmc_clock_source;
    uint32_t last_speed_mode_iclk_clock_source;
    uint32_t last_speed_mode_sdmmc_kernel_hz;
    uint32_t last_speed_mode_sdmmc_bus_hz;
    uint32_t last_speed_mode_sdmmc_target_bus_hz;
    uint32_t retarget_test_enabled;
    uint32_t retarget_rearm_count;
    uint32_t retarget_verified_segments;
    uint32_t retarget_verify_fail;
} XE_NP_BoardSdBenchDiag;

const XE_NP_NeuropixelsClockPlan *XE_NP_GetNeuropixelsClockPlan(void);
const XE_NP_PinMapEntry *XE_NP_GetPinMap(size_t *count);
uint32_t XE_NP_Board_GetRuntimeMcoDivider(void);
uint32_t XE_NP_Board_GetRuntimeExpectedMcoHz(void);
uint32_t XE_NP_Board_GetRuntimeExpectedPsbClkHz(void);
uint32_t XE_NP_Board_GetRuntimeExpectedPsbClkHalfHz(void);
uint32_t XE_NP_Board_GetRuntimeMcoRegisterBits(void);
uint32_t XE_NP_Board_GetNp2SampleRateHz(void);
uint32_t XE_NP_Board_GetRuntimeCoreClockHz(void);
uint32_t XE_NP_Board_GetRuntimeMcoApplyCount(void);
uint32_t XE_NP_Board_GetRuntimeMcoLastApplyStatus(void);
int XE_NP_Board_SetRuntimeMcoDivider(uint32_t divider);
#if XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE
/* Coordinator only; the ordinary runtime-divider command cannot enable NP2.
 * supply_stable_ms attests the board's >=10 ms power-before-clock interval.
 * These inspect nominal register clocks, not the waveform at the connector. */
int XE_NP_Board_StartNp2Mco(uint32_t supply_stable_ms);
void XE_NP_Board_StopNp2Mco(void);
/* Select the complete physical NP2 clock profile while MCO is stopped.
 * Both 20 and 30 kS/s use HSE-derived PLL1R/4 (32 and 48 MHz respectively).
 * This never changes a running probe clock. */
int XE_NP_Board_SetNp2SampleRateHz(uint32_t sample_hz);
int XE_NP_Board_SetNp2SampleRateProfile(uint32_t sample_hz,uint32_t probe_mask);
uint32_t XE_NP_Board_Np2ProfileCoreHz(uint32_t sample_hz,uint32_t probe_mask);
#if XE_NP_PSRAM_OVERFLOW_PLL2Q108
int XE_NP_Board_Np2Pll2Q108Ready(void);
#endif
int XE_NP_Board_InitNp2OverflowMemory(uint32_t sample_hz);
int XE_NP_Board_InitNp2OverflowMemoryProfile(uint32_t sample_hz,uint32_t probe_mask);
#endif
int XE_NP_Board_SdUhsReadyForNpRaw(void);
uint32_t XE_NP_Board_SdNegotiatedSpeedMode(void);
uint32_t XE_NP_Board_SdEstimatedWriteBudgetBytesPerSec(void);
const volatile XE_NP_BoardSdDiag *XE_NP_Board_SdDiag(void);
const volatile XE_NP_BoardSdBenchDiag *XE_NP_Board_SdBenchDiag(void);
void XE_NP_Board_EnsureSdPowerRail(void);

#endif


