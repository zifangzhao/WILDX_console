#ifndef XE_NP_NP2_TRANSPORT_H
#define XE_NP_NP2_TRANSPORT_H
#include <stdint.h>

/* Neuropixels 2.0 generation, NOT the legacy name for probe connector 2.
 * V2 schematic: U$1 DATA[2:0] -> PSSI[2:0], U$3 -> PSSI[5:3],
 * U$4 -> PSSI[8:6].
 * Both probes must use the SAME 48 MHz MCLK also routed to PSSI_PDCK.
 * No peripheral initialization or change to the NP1 image is done here. */
#define XE_NP_NP2_MCLK_HZ 48000000U
#define XE_NP_NP2_SAMPLE_HZ 30000U
#define XE_NP_NP2_FRAME_TICKS 100U
#define XE_NP_NP2_FRAMES_PER_SUPERFRAME 16U
#define XE_NP_NP2_ADC_BITS 12U
#define XE_NP_NP2_ADCS_PER_PROBE 24U
#define XE_NP_NP2_DUAL_MASK 0x3FU
#define XE_NP_NP2_DUAL_PSSI_BYTES_PER_SEC 48000000U
#define XE_NP_NP2_DUAL_PACKED_BYTES_PER_SEC 36000000U
/* Legacy 48 MHz/30 kS/s extended-PSSI codec constants. Production three-probe
 * 20 kS/s capture uses PSSI D7:D0 plus SPI2 D8 as defined in
 * xe_np_np2_triple_20k.h; these 16-bit helpers remain for tests/fallbacks. */
#define XE_NP_NP2_TRIPLE_MASK 0x01FFU
#define XE_NP_NP2_TRIPLE_PSSI_BITS 9U
#define XE_NP_NP2_TRIPLE_PSSI_SOURCE_BYTES_PER_SEC 96000000U
#define XE_NP_NP2_TRIPLE_PACKED_BYTES_PER_SEC 54000000U
/* 34 complete 1,600-tick superframes fit both the 128-tick pack quantum and
 * the 64 KiB container. */
#define XE_NP_NP2_TRIPLE_CHUNK_INPUT_TICKS 54400U
#define XE_NP_NP2_TRIPLE_CHUNK_PACKED_BYTES 61200U
/* Includes the full 64 KiB recording chunk, not merely its packed payload. */
#define XE_NP_NP2_TRIPLE_CONTAINER_BYTES_PER_SEC 57825883U
/* The admission floor is deliberately above the exact container rate: it
 * reserves time for packer/SD-DMA contention and card-ready variation. It is
 * an engineering gate, not a claim that a card can sustain this rate. */
#define XE_NP_NP2_TRIPLE_MIN_SD_BYTES_PER_SEC 66000000U
/* ST DS13633 PSSI receive PDCK/HCLK <= 0.4. Not a clock configuration. */
#define XE_NP_NP2_MIN_HCLK_HZ 120000000U

#ifndef XE_NP_NP2_SINGLE_LANE_3BIT
#define XE_NP_NP2_SINGLE_LANE_3BIT 0U
#endif

/* 128 source ticks -> 96 bytes, both whole cache lines. 83200 input ticks
 * -> 62400 payload bytes = 52 complete superframes per probe. Leaves 3136
 * bytes in a 64 KiB chunk for versioned metadata/sensors/misc. A future NP2
 * container must NOT reuse the NP1 v5/v6 headers or frame validators. */
#if (XE_NP_NP2_SINGLE_LANE_3BIT != 0U)
/* The V2 single-probe recorder owns U$3 only, wired to PSSI[5:3]. It records
 * exactly those three pins, including all sync bits, as eight 3-bit ticks per
 * three output bytes. This is lossless for that declared mask and halves the
 * media rate; it is not a dual-probe container. */
#define XE_NP_NP2_PACK_INPUT_QUANTUM 128U
#define XE_NP_NP2_PACK_OUTPUT_QUANTUM 48U
#define XE_NP_NP2_CHUNK_INPUT_TICKS 166400U
#define XE_NP_NP2_CHUNK_PACKED_BYTES 62400U
#define XE_NP_NP2_DUAL_CONTAINER_BYTES_PER_SEC 18904616U
#else
#define XE_NP_NP2_PACK_INPUT_QUANTUM 128U
#define XE_NP_NP2_PACK_OUTPUT_QUANTUM 96U
#define XE_NP_NP2_CHUNK_INPUT_TICKS 83200U
#define XE_NP_NP2_CHUNK_PACKED_BYTES 62400U
#define XE_NP_NP2_DUAL_CONTAINER_BYTES_PER_SEC 37809231U /* ceil(36M*65536/62400) */
#endif

/* Bit0/bit1 identify the first/second three-wire NP2 connector. Kept in the
 * wire contract so phase, metadata and storage can use the same identity. */
enum { XE_NP_NP2_PROBE_FIRST = 1U, XE_NP_NP2_PROBE_SECOND = 2U,
       XE_NP_NP2_PROBE_THIRD = 4U,
       XE_NP_NP2_PROBE_BOTH = XE_NP_NP2_PROBE_FIRST | XE_NP_NP2_PROBE_SECOND,
       XE_NP_NP2_PROBE_ALL = XE_NP_NP2_PROBE_BOTH | XE_NP_NP2_PROBE_THIRD };

enum { XE_NP_NP2_PACK_OK=0, XE_NP_NP2_PACK_ARGUMENT=-1,
       XE_NP_NP2_PACK_CAPACITY=-2, XE_NP_NP2_PACK_OVERLAP=-3 };

/* Lossless for all six active wires, INCLUDING all synchronization bits.
 * Little-endian stream: four six-bit ticks a,b,c,d become a|(b<<6)|
 * (c<<12)|(d<<18), serialized least-significant byte first.
 * Inactive PSSI[7:6] are intentionally not part of this two-probe format.
 *
 * Source/destination must be 4-byte aligned, disjoint and input_bytes must
 * be a nonzero multiple of128. No modification occurs on rejected input.
 * The caller MUST retain producer ownership until conversion completes and
 * check it both before/after; this routine does not make a live DMA ring safe.
 * Keep cache maintenance and publication outside the kernel. */
int XE_NP_Np2Pack6(const uint8_t *source,uint32_t input_bytes,
                  uint8_t *destination,uint32_t capacity_bytes);
/* Lossless U$3-only codec: source bits[5:3] become bits[2:0] in the packed
 * stream. It has the same alignment, non-overlap and 128-tick contract as
 * Pack6. The v9 single-lane container advertises codec=3 and wire mask 0x38. */
int XE_NP_Np2Pack3Shift3(const uint8_t *source,uint32_t input_bytes,
                         uint8_t *destination,uint32_t capacity_bytes);

/* Compact a non-empty subset of the two byte-wide PSSI lanes. Probe-mask bit
 * 0 selects U$1/D[2:0] and bit 1 selects U$3/D[5:3]. Selected lanes remain in
 * connector order and are packed without padding. This is the byte-ingress
 * counterpart of PackSelectedFrom16 and has the same 128-tick/alignment rules
 * as Pack6. */
int XE_NP_Np2PackSelectedFrom8(const uint8_t *source,uint32_t input_ticks,
                               uint8_t probe_mask,uint8_t *destination,
                               uint32_t capacity_bytes);

/* Lossless three-probe codec for extended-PSSI samples. Each little-endian
 * uint16_t source word represents one 48 MHz PSSI tick: source bits [8:0]
 * are U$4/U$3/U$1 DATA[2:0], respectively. Eight ticks become nine bytes,
 * least-significant bit first. Bits [15:9] are not probe wires and are never
 * serialized. source and destination must be 4-byte aligned, non-overlapping
 * and input_ticks must be a non-zero multiple of 128. */
int XE_NP_Np2Pack9From16(const uint16_t *source,uint32_t input_ticks,
                         uint8_t *destination,uint32_t capacity_bytes);

/* Compact an arbitrary non-empty subset of the three physical NP2 connectors
 * from the same 16-bit extended-PSSI source. Probe-mask bits are U$1/U$3/U$4
 * in that order. Selected three-bit lanes are serialized in ascending connector
 * order, with no padding between them. The result therefore contains 3, 6, or
 * 9 bits per source tick and preserves every selected wire bit. Alignment,
 * ownership, overlap and 128-tick requirements match Pack9From16. */
int XE_NP_Np2PackSelectedFrom16(const uint16_t *source,uint32_t input_ticks,
                                uint8_t probe_mask,uint8_t *destination,
                                uint32_t capacity_bytes);

/* NP2USB03 three-probe performance layout. The payload begins with one raw
 * PSSI D[7:0] byte per tick; the final total_ticks/8 bytes contain D8 in
 * chronological LSB-first order. This helper is a bring-up fallback for the
 * existing 16-bit PSSI source. Production three-probe capture feeds the two
 * regions independently from PSSI DMA and SPI2 RX DMA, eliminating this CPU
 * loop. Offsets/counts must be multiples of eight and remain inside the one
 * fixed-size payload. */
int XE_NP_Np2SplitPssi8D8From16(const uint16_t *source,uint32_t input_ticks,
                                uint8_t *payload,uint32_t total_ticks,
                                uint32_t tick_offset);
#endif
