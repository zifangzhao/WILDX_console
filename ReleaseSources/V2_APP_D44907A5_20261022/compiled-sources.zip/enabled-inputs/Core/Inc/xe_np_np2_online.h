#ifndef XE_NP_NP2_ONLINE_H
#define XE_NP_NP2_ONLINE_H
#include "xe_np_online.h"
/* A PC-time mapping, NOT a change to acquisition clocks or a CE64 RTC image.
 * B9/64-byte frames, independent magic from recorder mutations and preview. */
#define NP2_ONLINE_REQUEST NP_ONLINE_REQUEST
#define NP2_ONLINE_REPLY   NP_ONLINE_REPLY
typedef XE_NP_OnlineClock XE_NP_Np2OnlineClock;
void XE_NP_Np2Online_Init(XE_NP_Np2OnlineClock *clock);
uint64_t XE_NP_Np2Online_Utc(const XE_NP_Np2OnlineClock *clock,uint32_t now);
/* op 0: measure RX/TX millisecond ticks; op 1: commit measured PC anchor.
 * Calibration is idle-only. Read-only measurement remains available while
 * recording. Host must never claim sub-ms precision from this clock. */
int XE_NP_Np2Online_Exchange(XE_NP_Np2OnlineClock *clock,const uint8_t in[64],
    uint8_t out[64],uint32_t received_ms,uint32_t sent_ms,uint32_t state);
#endif
