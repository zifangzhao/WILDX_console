#ifndef XE_NP_NP2_DUAL_SD_APP_H
#define XE_NP_NP2_DUAL_SD_APP_H

#include <stdint.h>
#ifndef XE_NP_NP2_DUAL_SD_APP_ENABLE
#define XE_NP_NP2_DUAL_SD_APP_ENABLE 0U
#endif

#if XE_NP_NP2_DUAL_SD_APP_ENABLE
#include "xe_np_hal.h"
#include "xe_np_np2_dual_sd_catalog.h"
#define XE_NP_NP2_DUAL_SD_APP_MAGIC 0x4144324EU /* N2DA */
#define XE_NP_NP2_DUAL_SD_APP_VERSION 1U
#define XE_NP_NP2_DUAL_SD_START_KEY 0x4E325253U /* N2RS */
enum {XE_NP_NP2_DUAL_SD_CMD_NONE=0U,XE_NP_NP2_DUAL_SD_CMD_FORMAT=1U,
      XE_NP_NP2_DUAL_SD_CMD_START=2U,XE_NP_NP2_DUAL_SD_CMD_STOP=3U,
      XE_NP_NP2_DUAL_SD_CMD_MOUNT=4U,XE_NP_NP2_DUAL_SD_CMD_RECOVER=5U,
      XE_NP_NP2_DUAL_SD_CMD_REWIND=6U,XE_NP_NP2_DUAL_SD_CMD_DELETE_LAST=7U};
enum {XE_NP_NP2_DUAL_SD_UNMOUNTED=0U,XE_NP_NP2_DUAL_SD_IDLE=1U,
      XE_NP_NP2_DUAL_SD_PREPARING=2U,XE_NP_NP2_DUAL_SD_RECORDING=3U,
      XE_NP_NP2_DUAL_SD_FINALIZING=4U,XE_NP_NP2_DUAL_SD_COMPLETE=5U,
      XE_NP_NP2_DUAL_SD_ARMED=6U,XE_NP_NP2_DUAL_SD_CANCELLED=7U,
      XE_NP_NP2_DUAL_SD_FAILED=255U};
enum {XE_NP_NP2_DUAL_SD_ERROR_NONE=0U,XE_NP_NP2_DUAL_SD_ERROR_BIND=1U,
      XE_NP_NP2_DUAL_SD_ERROR_FORMAT=2U,XE_NP_NP2_DUAL_SD_ERROR_MOUNT=3U,
      XE_NP_NP2_DUAL_SD_ERROR_PLAN=4U,XE_NP_NP2_DUAL_SD_ERROR_RESERVE=5U,
      XE_NP_NP2_DUAL_SD_ERROR_WRITER=6U,XE_NP_NP2_DUAL_SD_ERROR_FINALIZE=7U};

/* SWD command commit word is written last. Invalid commands leave the app
 * idle and update command_error; media/source faults are sticky FAILED. The
 * app starts no recording automatically. COMPLETE/CANCELLED may append again. */
typedef struct {
    uint32_t magic,version;
    volatile uint32_t command,nonce,key,requested_blocks,sample_hz;
    uint32_t accepted_nonce,state,error,command_error;
    uint32_t card_blocks,cid[4],next_start_lba;
    uint32_t session_id,reservation_start_lba,reservation_end_lba;
    uint32_t payload_start_lba,target_blocks,committed_blocks;
    uint32_t writer_state,writer_error,writer_verified_blocks;
} XE_NP_Np2DualSdAppMailbox;
extern volatile XE_NP_Np2DualSdAppMailbox xe_np_np2_dual_sd_app_mailbox;
int XE_NP_Np2DualSdApp_Init(SD_HandleTypeDef *card,DCACHE_HandleTypeDef *cache);
/* Cold selection only, subject to the actual compiled writer capability.
 * Kept outside the 104-byte diagnostic/SWD mailbox; Init defaults to mask3. */
int XE_NP_Np2DualSdApp_SelectProfile(uint32_t probe_mask,uint32_t sample_hz);
uint32_t XE_NP_Np2DualSdApp_ProfileMask(void);
#if XE_NP_NP2_SD_CATALOG_ENABLE
int XE_NP_Np2DualSdApp_CatalogReady(void);
int XE_NP_Np2DualSdApp_QueueDelete(uint32_t nonce,const XE_NP_Np2DualSdCatalogDelete *request);
#endif
void XE_NP_Np2DualSdApp_Service(void);
/* Private idle-clock trial: restore normal HCLK before command side effects. */
void XE_NP_Np2DualSdApp_WakeClock(void);
int XE_NP_Np2DualSdApp_Schedule(uint64_t utc_us);
/* Cancel only an unaccepted foreground schedule; a started session is untouched. */
void XE_NP_Np2DualSdApp_CancelSchedule(void);
int XE_NP_Np2DualSdApp_ArmGate(void);
void XE_NP_Np2DualSdApp_ArmStamp(uint32_t before,uint32_t after);
#endif
#endif
