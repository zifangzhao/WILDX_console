#ifndef XE_NP_NP2_SD_APPEND_COVERAGE_H
#define XE_NP_NP2_SD_APPEND_COVERAGE_H
#include <stdint.h>
#include <string.h>

/* STOPPED readback only: the caller proves PSSI/SPI/SD/C14 and all RU/spill
 * owners drained before borrowing the bitmap. This helper owns no hardware.
 * Add only after all four native header/tick/wire blocks of an RU verify. */
typedef struct {
    uint8_t *seen;
    uint32_t target_rus,seen_rus,logical_prefix_rus,logical_high_water_rus,error;
} XE_NP_Np2SdAppendCoverage;

static inline int XE_NP_Np2SdAppendCoverage_Init(XE_NP_Np2SdAppendCoverage *ctx,
    uint8_t *bits,uint32_t capacity_bytes,uint32_t target_blocks)
{
    if(!ctx)return -1;
    if(!bits || !target_blocks || (target_blocks&3U) ||
       capacity_bytes<(target_blocks/4U+7U)/8U){ctx->error=1U;return -1;}
    uint32_t rus=target_blocks/4U;
    memset(bits,0,(rus+7U)/8U);
    ctx->seen=bits;ctx->target_rus=rus;ctx->seen_rus=0U;
    ctx->logical_prefix_rus=ctx->logical_high_water_rus=ctx->error=0U;
    return 0;
}

static inline int XE_NP_Np2SdAppendCoverage_Add(XE_NP_Np2SdAppendCoverage *ctx,
    uint64_t first_block_sequence)
{
    if(!ctx)return -1;
    uint64_t logical_ru=first_block_sequence/4U;
    if(ctx->error || !ctx->seen || !ctx->target_rus ||
       (first_block_sequence&3U) || logical_ru>=ctx->target_rus ||
       ctx->seen_rus>=ctx->target_rus ||
       ctx->logical_prefix_rus>ctx->target_rus ||
       ctx->logical_high_water_rus>ctx->target_rus){ctx->error=1U;return -1;}
    uint32_t ru=(uint32_t)logical_ru;
    uint8_t mask=(uint8_t)(1U<<(ru&7U));
    if(ctx->seen[ru/8U]&mask){ctx->error=1U;return -1;}
    ctx->seen[ru/8U]=(uint8_t)(ctx->seen[ru/8U]|mask);ctx->seen_rus++;
    if(ru+1U>ctx->logical_high_water_rus)ctx->logical_high_water_rus=ru+1U;
    while(ctx->logical_prefix_rus<ctx->target_rus &&
          (ctx->seen[ctx->logical_prefix_rus/8U]&
           (1U<<(ctx->logical_prefix_rus&7U))))ctx->logical_prefix_rus++;
    return 0;
}

/* Terminal-only. Re-read the bitmap: matching counters cannot certify holes.
 * Unused high bits of the last byte are outside the requested extent. */
static inline int XE_NP_Np2SdAppendCoverage_Complete(XE_NP_Np2SdAppendCoverage *ctx)
{
    if(!ctx)return -1;
    if(ctx->error || !ctx->seen || !ctx->target_rus ||
       ctx->seen_rus!=ctx->target_rus ||
       ctx->logical_prefix_rus!=ctx->target_rus ||
       ctx->logical_high_water_rus!=ctx->target_rus){ctx->error=1U;return -1;}
    uint32_t whole=ctx->target_rus/8U,tail=ctx->target_rus&7U;
    for(uint32_t i=0U;i<whole;i++)
        if(ctx->seen[i]!=UINT8_MAX){ctx->error=1U;return -1;}
    uint32_t mask=(1U<<tail)-1U;
    if(tail && (ctx->seen[whole]&mask)!=mask){ctx->error=1U;return -1;}
    return 0;
}
#endif
