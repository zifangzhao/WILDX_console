#ifndef XE_NP_NP2_SD_CONTROL_H
#define XE_NP_NP2_SD_CONTROL_H
#include <stdint.h>
#include "xe_np_np2_dual_sd_catalog.h"
/* B9 transport, separate version/magic from V1. Never interpret a V1 request
 * as a V2 mutation. Integrity applies only to infrequent control packets. */
#define XE_NP_NP2_SD_CONTROL_REQUEST 0x32444C4EU
#define XE_NP_NP2_SD_CONTROL_REPLY 0x32524C4EU
#define XE_NP_NP2_SD_CONTROL_VERSION 2U
/* STATUS Flags: recording capability is separate from stored-format reading.
 * Clock-limited roles may still safely inspect/recover a 7.5-kHz catalog. */
#define XE_NP_NP2_SD_CAP_RATE_7500 0x00100000U
#define XE_NP_NP2_SD_CAP_STORED_7500 0x00200000U
#define XE_NP_NP2_SD_CAP_CATALOG 0x00400000U
enum {XE_NP_NP2_MODE_UPDATE=1U,XE_NP_NP2_MODE_USB=2U,XE_NP_NP2_MODE_DFU=3U};
uint32_t XE_NP_Np2SdControl_PendingMode(void);
uint32_t XE_NP_Np2SdControl_TakeMode(void);
/* Failed ACK handoff: cancel once; an exact replay must not rearm the reset. */
void XE_NP_Np2SdControl_CancelMode(void);
/* Only a newly queued BLE START owns this handoff, never a SWD command.
 * Error7 also denotes an unavailable/cancelled ACK handoff; no wire ABI change. */
uint32_t XE_NP_Np2SdControl_PendingStart(void);
void XE_NP_Np2SdControl_CancelStart(uint32_t nonce);
int XE_NP_Np2SdBle_ModeAvailable(uint32_t mode);
void XE_NP_Np2SdControl_Init(void);
int XE_NP_Np2SdControl_Exchange(const uint8_t request[64],uint8_t reply[64]);
#endif
