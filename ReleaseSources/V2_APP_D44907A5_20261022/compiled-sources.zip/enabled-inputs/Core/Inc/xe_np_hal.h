#ifndef XE_NP_HAL_H
#define XE_NP_HAL_H

#include <stddef.h>
#include <stdint.h>
#include <string.h>

#if defined(__has_include)
#if __has_include("stm32u5xx_hal.h")
#include "stm32u5xx_hal.h"
#elif __has_include("stm32f4xx_hal.h")
#include "stm32f4xx_hal.h"
#else
#define XE_NP_HAL_FALLBACK 1
#endif
#else
#include "stm32u5xx_hal.h"
#endif

#if defined(XE_NP_HAL_FALLBACK)
typedef struct UART_HandleTypeDef UART_HandleTypeDef;
typedef struct DMA_HandleTypeDef DMA_HandleTypeDef;
typedef struct I2C_HandleTypeDef I2C_HandleTypeDef;
typedef struct TIM_HandleTypeDef TIM_HandleTypeDef;
typedef struct ADC_HandleTypeDef ADC_HandleTypeDef;
typedef struct SD_HandleTypeDef SD_HandleTypeDef;
typedef struct GPIO_TypeDef GPIO_TypeDef;

typedef enum
{
    HAL_OK = 0U,
    HAL_ERROR = 1U,
    HAL_BUSY = 2U,
    HAL_TIMEOUT = 3U
} HAL_StatusTypeDef;

#ifndef RTC_FORMAT_BIN
#define RTC_FORMAT_BIN 0U
#endif

#ifndef RTC_DAYLIGHTSAVING_NONE
#define RTC_DAYLIGHTSAVING_NONE 0U
#endif

#ifndef RTC_STOREOPERATION_RESET
#define RTC_STOREOPERATION_RESET 0U
#endif

#ifndef assert_param
#define assert_param(expr) ((void)0)
#endif
#endif

#ifndef __IO
#define __IO volatile
#endif

#if defined(__GNUC__) || defined(__clang__)
#define CE32_FORCE_INLINE static inline __attribute__((always_inline))
#define CE32_ALIGN(bytes) __attribute__((aligned(bytes)))
#else
#define CE32_FORCE_INLINE __forceinline
#define CE32_ALIGN(bytes) __align(bytes)
#endif

#if !defined(HAL_RTC_MODULE_ENABLED)
typedef struct RTC_HandleTypeDef RTC_HandleTypeDef;

typedef struct
{
    uint8_t Hours;
    uint8_t Minutes;
    uint8_t Seconds;
    uint8_t TimeFormat;
    uint32_t SubSeconds;
    uint32_t SecondFraction;
    uint32_t DayLightSaving;
    uint32_t StoreOperation;
} RTC_TimeTypeDef;

typedef struct
{
    uint8_t WeekDay;
    uint8_t Month;
    uint8_t Date;
    uint8_t Year;
} RTC_DateTypeDef;

#ifndef RTC_FORMAT_BIN
#define RTC_FORMAT_BIN 0U
#endif

#ifndef RTC_DAYLIGHTSAVING_NONE
#define RTC_DAYLIGHTSAVING_NONE 0U
#endif

#ifndef RTC_STOREOPERATION_RESET
#define RTC_STOREOPERATION_RESET 0U
#endif

CE32_FORCE_INLINE HAL_StatusTypeDef HAL_RTC_GetTime(RTC_HandleTypeDef *hrtc, RTC_TimeTypeDef *sTime, uint32_t format)
{
    (void)hrtc;
    (void)format;

    if(sTime != NULL)
    {
        memset(sTime, 0, sizeof(*sTime));
        sTime->SecondFraction = 9999U;
    }

    return HAL_ERROR;
}

CE32_FORCE_INLINE HAL_StatusTypeDef HAL_RTC_GetDate(RTC_HandleTypeDef *hrtc, RTC_DateTypeDef *sDate, uint32_t format)
{
    (void)hrtc;
    (void)format;

    if(sDate != NULL)
    {
        memset(sDate, 0, sizeof(*sDate));
    }

    return HAL_ERROR;
}

CE32_FORCE_INLINE HAL_StatusTypeDef HAL_RTC_SetTime(RTC_HandleTypeDef *hrtc, RTC_TimeTypeDef *sTime, uint32_t format)
{
    (void)hrtc;
    (void)sTime;
    (void)format;
    return HAL_ERROR;
}

CE32_FORCE_INLINE HAL_StatusTypeDef HAL_RTC_SetDate(RTC_HandleTypeDef *hrtc, RTC_DateTypeDef *sDate, uint32_t format)
{
    (void)hrtc;
    (void)sDate;
    (void)format;
    return HAL_ERROR;
}
#endif

#endif
