#ifndef XE_NP_SD_RECORD_PLAN_H
#define XE_NP_SD_RECORD_PLAN_H
#include <stdint.h>
/* SD Physical Layer AU_SIZE codes, in 512-byte sectors. */
static inline uint32_t XE_NP_SdAuBlocks(uint32_t code)
{
    static const uint32_t blocks[16]={0,32,64,128,256,512,1024,2048,4096,8192,16384,24576,32768,49152,65536,131072};
    return code<16?blocks[code]:0;
}
/* Legacy UHS Speed Grade accepts codes7..15, not the smaller SDSC units. */
static inline int XE_NP_SdIsUhsAuBlocks(uint32_t blocks)
{
    for(uint32_t code=7U;code<16U;code++)if(XE_NP_SdAuBlocks(code)==blocks)return 1;
    return 0;
}
/* Stopped-only legacy erase bound. The persisted allocation, not the exact
 * recording end, owns the unused AU tail. Never round backwards into headers. */
static inline uint32_t XE_NP_SdLegacyAuEraseEnd(uint32_t start,uint64_t end,
                                               uint32_t au,uint32_t allocation_end,
                                               uint32_t capacity)
{
    if(!XE_NP_SdIsUhsAuBlocks(au) || start<8192U || start%au ||
       end<=start || end>capacity || allocation_end>capacity)return 0U;
    uint64_t erase_end=((end+au-1U)/au)*au;
    uint64_t allocation=(erase_end+16383U)&~UINT64_C(16383);
    return allocation==allocation_end && erase_end<=capacity?(uint32_t)erase_end:0U;
}
static inline int XE_NP_SdWholeAuRange(uint32_t start,uint32_t count,uint32_t au,uint32_t capacity)
{ return au && count && start<capacity && count<=capacity-start && start%au==0 && count%au==0; }
static inline int XE_NP_SdVscFreeAuArgument(uint32_t start,uint32_t count,uint32_t au,uint32_t capacity,uint32_t *argument)
{
    if(!argument || !XE_NP_SdWholeAuRange(start,count,au,capacity) || start%1024 ||
       count/au>8 || start/1024>0x3fffffU)return -1;
    *argument=0x78000000U|((count/au-1U)<<24U)|(start/1024U);return 0;
}
#endif
