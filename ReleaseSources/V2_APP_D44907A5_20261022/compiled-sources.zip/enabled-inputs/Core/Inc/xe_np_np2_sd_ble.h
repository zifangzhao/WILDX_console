#ifndef XE_NP_NP2_SD_BLE_H
#define XE_NP_NP2_SD_BLE_H
#ifndef XE_NP_NP2_SD_BLE_ENABLE
#define XE_NP_NP2_SD_BLE_ENABLE 0U
#endif
#if XE_NP_NP2_SD_BLE_ENABLE
#include <stdint.h>
#include "xe_np_np2_online.h"
void XE_NP_Np2SdBle_ClockSnapshot(XE_NP_Np2OnlineClock *out);
extern uint32_t xe_np_np2_preview_active;
void XE_NP_Np2SdBle_PreviewTap(const uint8_t *,uint32_t,uint64_t,int);
void XE_NP_Np2SdBle_PreviewVerify(const uint8_t *,uint64_t,uint32_t);
void XE_NP_Np2SdBle_Init(void);
void XE_NP_Np2SdBle_EarlyDfu(void);
void XE_NP_Np2SdBle_Irq(void);
void XE_NP_Np2SdBle_Service(void);
void XE_NP_Np2SdBle_Reclock(void);
/* Stopped accepted PREPARING only; cold pre-Init calls are no-ops. Begin drains
 * for at most 1s and returns 0 with USART2 disabled/its IRQ masked, or -1 without
 * acquiring it. After every successful Begin, call End on ALL clock outcomes
 * before further BLE service; End uses actual PCLK and discards ambiguous RX. */
int XE_NP_Np2SdBle_BeginClockChange(void);
void XE_NP_Np2SdBle_EndClockChange(void);
int XE_NP_Np2SdBle_CommandReady(void);
/* Read-only stopped-state sleep fence. UART RX/rescue IRQs remain enabled. */
int XE_NP_Np2SdBle_IdleQuiet(void);
#endif
#endif
