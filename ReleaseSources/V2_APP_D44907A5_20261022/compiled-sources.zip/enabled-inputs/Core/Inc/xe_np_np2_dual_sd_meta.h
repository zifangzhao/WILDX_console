#ifndef XE_NP_NP2_DUAL_SD_META_H
#define XE_NP_NP2_DUAL_SD_META_H

#include "xe_np_np2_dual_sd_run.h"

#define XE_NP_NP2_DUAL_SD_CARD_IDENT "NP_PSSI_7"
/* Same v11 payload/metadata layout; new writer semantics. Old firmware must
 * not append over an open actual-end record. Legacy NP_PSSI_6 is readable. */
#define XE_NP_NP2_DUAL_SD_META_VERSION 11U
#define XE_NP_NP2_DUAL_SD_META_AU_VERSION 12U
/* Private legacy UHS allocation trial: AU geometry without VSC commands. */
#define XE_NP_NP2_DUAL_SD_META_LEGACY_AU_VERSION 13U
#define XE_NP_NP2_DUAL_SD_META_SECTOR_BYTES 512U
#define XE_NP_NP2_DUAL_SD_META_RESERVED 1U
#define XE_NP_NP2_DUAL_SD_META_COMPLETE 3U
#define XE_NP_NP2_DUAL_SD_META_FAILED 4U
/* A stopped/drained write checkpoint, NOT verified recording data. Uses the
 * existing incomplete footer state so all current readers refuse promotion. */
#define XE_NP_NP2_DUAL_SD_META_VERIFY_PENDING 0x56455249U /* VERI */

typedef struct {
    XE_NP_Np2DualSdRun run;
    uint32_t session_id,reservation_start_lba,reservation_end_lba;
    uint32_t card_blocks,config_crc;
    uint32_t cid[4];
    /* Zero retains the exact v11 layout/geometry. Nonzero selects v12,
     * reported-AU-aligned sequential VSC payload with bounded whole AUs. */
    uint32_t au_blocks;
    /* Nonzero selects v13 instead: reported UHS_AU_SIZE, not VSC_AU_SIZE.
     * Never set together with au_blocks. Word128 stores the selected unit;
     * v13 flags47 have legacy-AU bit5, not v12's VSC bit4. */
    uint32_t legacy_au_blocks;
} XE_NP_Np2DualSdMeta;

/* Stopped-time configuration/metadata checksum only; never call per sample. */
uint32_t XE_NP_Np2DualSd_Crc32(const uint8_t *data,uint32_t bytes);

/* Stopped/configuration-time only. Descriptor lives at reservation+3,
 * terminal footer at reservation+4; configuration occupies +8..+11.
 * v11 payload starts on the next 16,384-sector boundary; v12 aligns that
 * header area to a reported VSC AU; v13 uses the distinct legacy UHS AU.
 * Fields24..52 declare the closed dual20/30 or
 * triple15/20 tuple; both store unchanged NP2USB03 blocks. CRC protects only
 * the 512-byte metadata, never the sample stream. */
int XE_NP_Np2DualSd_EncodeDescriptor(uint8_t out[512],const XE_NP_Np2DualSdMeta *meta);
int XE_NP_Np2DualSd_DecodeDescriptor(const uint8_t sector[512],XE_NP_Np2DualSdMeta *out);
int XE_NP_Np2DualSd_EncodeFooter(uint8_t out[512],const XE_NP_Np2DualSdMeta *meta,
                                 uint32_t state,uint32_t error,uint32_t committed_blocks);
int XE_NP_Np2DualSd_DecodeFooter(const uint8_t descriptor[512],const uint8_t footer[512],
                                 uint32_t *state,uint32_t *error,uint32_t *committed_blocks);

#endif
