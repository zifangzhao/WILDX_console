#ifndef XE_NP_NP2_DIRECT_LAYOUT_H
#define XE_NP_NP2_DIRECT_LAYOUT_H
#include <stdint.h>
#include <string.h>
#ifndef XE_NP_NP2_LIVE_SD_DIRECT
#define XE_NP_NP2_LIVE_SD_DIRECT 0U
#endif
#ifndef XE_NP_NP2_DIRECT_SPI_WORD_DMA
#define XE_NP_NP2_DIRECT_SPI_WORD_DMA 0U
#endif
#ifndef XE_NP_NP2_DIRECT_SPI_FIFO_WORD_DMA
/* Default-off four-frame FIFO access trial; direct or copied-runtime SD only. */
#define XE_NP_NP2_DIRECT_SPI_FIFO_WORD_DMA 0U
#endif
#ifndef XE_NP_NP2_LIVE_SD_EXTENDED_RING
#define XE_NP_NP2_LIVE_SD_EXTENDED_RING 0U
#endif
#ifndef XE_NP_NP2_STAGED_CAPTURE
#define XE_NP_NP2_STAGED_CAPTURE 0U
#endif
#ifndef XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
#define XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST 0U
#endif
#if (XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST!=0U && XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST!=1U) || \
    (XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST && \
     (XE_NP_IMAGE_ROLE!=1U || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
      !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || XE_NP_NP2_LIVE_SD_DIRECT || \
      XE_NP_NP2_STAGED_CAPTURE || XE_NP_NP2_LIVE_SD_EXTENDED_RING || \
      XE_NP_NP2_SD_RAW_INGRESS_RU_TEST))
#error "Runtime direct PSSI is a separate copied-profile SD APP experiment"
#endif
#if XE_NP_NP2_STAGED_CAPTURE && (!XE_NP_NP2_LIVE_SD_DIRECT || !XE_NP_NP2_LIVE_SD_EXTENDED_RING)
#error "Staged acquisition uses the direct 13-RU SRAM image"
#endif

#define NP2_DIRECT_TICKS 40960U
#define NP2_DIRECT_D8_BYTES 5120U
#define NP2_DIRECT_D8_LANE_OFFSET (512U+NP2_DIRECT_TICKS)
#define NP2_DIRECT_SLOT_BYTES 46592U
#define NP2_DIRECT_SLOTS_PER_BANK 16U
#define NP2_RUNTIME_DIRECT_CAPTURE_RUS 8U
#define NP2_RUNTIME_DIRECT_RESTORE_RUS 3U
#define NP2_RUNTIME_DIRECT_RESTORE_BASE 0x200D0000UL
/* Cold selection only. Private RAW9 bridge/power trial at 15/20 kHz;
 * every other profile retains copied acquisition. */
static inline uint32_t XE_NP_Np2RuntimeDirectPssiProfile(uint32_t mask,uint32_t rate)
{
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    return mask==7U && (rate==15000U || rate==20000U);
#else
    (void)mask;(void)rate;return 0U;
#endif
}
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
/* Existing eight RAW9 record RUs. Physical RU4 remains the independent D8
 * capture ring; this layout never aliases its DMA or BLE/configuration tail.
 * Only PSSI is direct: D8 still needs the copied path's phase/ready handoff. */
#define NP2_DIRECT_SLOTS 32U
#define NP2_DIRECT_CAPTURE_BANK_COUNT 2U
#define NP2_DIRECT_EXTENDED_BASE 0xFFFFFFFFUL
#define NP2_DIRECT_BANK2_BASE 0x201A0000UL
#elif XE_NP_NP2_STAGED_CAPTURE
/* RU0..3 alone belong to PSSI/SPI. RU4..12 are immutable SD/restore slots.
 * The producer still gets a logical token at 0x200D0000; DMA destinations
 * and DAR decoding are deliberately restricted to SRAM bank 0. */
#define NP2_DIRECT_SLOTS 16U
#define NP2_DIRECT_CAPTURE_BANK_COUNT 1U
#define NP2_DIRECT_EXTENDED_BASE 0x20186000UL
#define NP2_DIRECT_BANK2_BASE 0x201B3800UL
#elif XE_NP_NP2_LIVE_SD_EXTENDED_RING
#define NP2_DIRECT_SLOTS 52U
#define NP2_DIRECT_CAPTURE_BANK_COUNT 3U
#define NP2_DIRECT_EXTENDED_BASE 0x20186000UL
#define NP2_DIRECT_BANK2_BASE 0x201B3800UL
#else
#define NP2_DIRECT_SLOTS 48U
#define NP2_DIRECT_CAPTURE_BANK_COUNT 3U
#define NP2_DIRECT_EXTENDED_BASE 0xFFFFFFFFUL
#define NP2_DIRECT_BANK2_BASE 0x201A0000UL
#endif
#define NP2_DIRECT_D8_PHASE_OFFSET 176U
#define NP2_DIRECT_D8_LOOKAHEAD_BYTES_OFFSET 180U
#define NP2_DIRECT_D8_LOOKAHEAD_OFFSET 184U
#define NP2_DIRECT_D8_LOOKAHEAD_MAX 200U
#define NP2_DIRECT_BANK_BYTES (NP2_DIRECT_SLOT_BYTES*NP2_DIRECT_SLOTS_PER_BANK)
#define NP2_DIRECT_RING_TICKS (NP2_DIRECT_TICKS*NP2_DIRECT_SLOTS)
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
_Static_assert(NP2_DIRECT_SLOTS==4U*NP2_RUNTIME_DIRECT_CAPTURE_RUS,
               "runtime capture RUs must tile the direct PSSI ring");
_Static_assert(NP2_RUNTIME_DIRECT_RESTORE_BASE+
               NP2_RUNTIME_DIRECT_RESTORE_RUS*4U*NP2_DIRECT_SLOT_BYTES<=0x20184000UL,
               "restore aliases must not reach the retained BLE/configuration tail");
#endif
_Static_assert(NP2_DIRECT_RING_TICKS+NP2_DIRECT_D8_LOOKAHEAD_MAX*8U+64U<0x80000000UL,
               "modular D8 readiness requires a producer/consumer distance below half range");
_Static_assert(NP2_DIRECT_D8_LOOKAHEAD_OFFSET+NP2_DIRECT_D8_LOOKAHEAD_MAX<=508U,
               "D8 phase lookahead must fit before the header CRC field");
static inline uintptr_t XE_NP_Np2DirectBank(uint32_t bank)
{
    return bank==0U?0x20004000UL:bank==1U?
        (XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST?0x201BA000UL:0x200D0000UL):NP2_DIRECT_BANK2_BASE;
}
static inline uint8_t *XE_NP_Np2DirectBlock(uint32_t slot)
{
#if XE_NP_NP2_LIVE_SD_EXTENDED_RING && !XE_NP_NP2_STAGED_CAPTURE
    if(slot>=48U)return (uint8_t *)(uintptr_t)(NP2_DIRECT_EXTENDED_BASE+(slot-48U)*NP2_DIRECT_SLOT_BYTES);
#endif
    return (uint8_t *)(XE_NP_Np2DirectBank(slot/16U)+(slot%16U)*NP2_DIRECT_SLOT_BYTES);
}
static inline int XE_NP_Np2DirectContains(const void *data,uint32_t bytes)
{
    uintptr_t start=(uintptr_t)data,end=start+bytes;
    if(!data || !bytes || end<start)return 0;
    for(uint32_t bank=0U;bank<NP2_DIRECT_CAPTURE_BANK_COUNT;bank++){
        uintptr_t base=XE_NP_Np2DirectBank(bank);
        if(start>=base && end<=base+NP2_DIRECT_BANK_BYTES)return 1;
    }
#if XE_NP_NP2_LIVE_SD_EXTENDED_RING && !XE_NP_NP2_STAGED_CAPTURE
    if(start>=NP2_DIRECT_EXTENDED_BASE &&
       end<=NP2_DIRECT_EXTENDED_BASE+4U*NP2_DIRECT_SLOT_BYTES)return 1;
#endif
    return 0;
}
/* Convert a physical DAR (including a completed node's exclusive end)
 * to the logical tick ring. Headers and the other DMA lane are not samples. */
static inline uint32_t XE_NP_Np2DirectOffset(uintptr_t address,uint32_t spi)
{
    uint32_t lane=spi?512U+NP2_DIRECT_TICKS:512U;
    uint32_t bytes=spi?NP2_DIRECT_D8_BYTES:NP2_DIRECT_TICKS;
    for(uint32_t bank=0U;bank<NP2_DIRECT_CAPTURE_BANK_COUNT;bank++){
        uintptr_t base=XE_NP_Np2DirectBank(bank);
        if(address<base+lane || address>base+NP2_DIRECT_BANK_BYTES)continue;
        uint32_t relative=(uint32_t)(address-base-lane);
        uint32_t slot=relative/NP2_DIRECT_SLOT_BYTES,within=relative%NP2_DIRECT_SLOT_BYTES;
        if(slot>=16U || within>bytes)return UINT32_MAX;
        return ((bank*16U+slot)*NP2_DIRECT_TICKS+within*(spi?8U:1U))%NP2_DIRECT_RING_TICKS;
    }
#if XE_NP_NP2_LIVE_SD_EXTENDED_RING && !XE_NP_NP2_STAGED_CAPTURE
    if(address>=NP2_DIRECT_EXTENDED_BASE+lane &&
       address<=NP2_DIRECT_EXTENDED_BASE+4U*NP2_DIRECT_SLOT_BYTES){
        uint32_t relative=(uint32_t)(address-NP2_DIRECT_EXTENDED_BASE-lane);
        uint32_t slot=relative/NP2_DIRECT_SLOT_BYTES,within=relative%NP2_DIRECT_SLOT_BYTES;
        if(slot>=4U || within>bytes)return UINT32_MAX;
        return ((48U+slot)*NP2_DIRECT_TICKS+within*(spi?8U:1U))%NP2_DIRECT_RING_TICKS;
    }
#endif
    return UINT32_MAX;
}
/* The direct recorder reads SPI2-D8's DAR once per stream block. Keep this
 * specialized mapping off the generic PSSI/SPI path so the hot caller does
 * not pay for a runtime lane selector or per-tick stride selection. */
static inline uint32_t XE_NP_Np2DirectD8Offset(uintptr_t address)
{
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    /* SPI2 still targets its independent circular ring, not these slots. */
    (void)address;return UINT32_MAX;
#elif XE_NP_NP2_STAGED_CAPTURE
    const uintptr_t base=0x20004000UL;
    if(address<base+NP2_DIRECT_D8_LANE_OFFSET ||
       address>base+NP2_DIRECT_BANK_BYTES)return UINT32_MAX;
    uint32_t relative=(uint32_t)(address-(base+NP2_DIRECT_D8_LANE_OFFSET));
    uint32_t slot=relative/NP2_DIRECT_SLOT_BYTES,within=relative%NP2_DIRECT_SLOT_BYTES;
    if(slot>=NP2_DIRECT_SLOTS || within>NP2_DIRECT_D8_BYTES)return UINT32_MAX;
    uint32_t offset=slot*NP2_DIRECT_TICKS+(within<<3U);
    return offset==NP2_DIRECT_RING_TICKS?0U:offset;
#else
    const uintptr_t bank0=0x20004000UL,bank1=0x200D0000UL,bank2=NP2_DIRECT_BANK2_BASE;
    uintptr_t base;uint32_t bank;
    if(address>=bank0+NP2_DIRECT_D8_LANE_OFFSET && address<=bank0+NP2_DIRECT_BANK_BYTES){base=bank0;bank=0U;}
    else if(address>=bank1+NP2_DIRECT_D8_LANE_OFFSET && address<=bank1+NP2_DIRECT_BANK_BYTES){base=bank1;bank=1U;}
    else if(address>=bank2+NP2_DIRECT_D8_LANE_OFFSET && address<=bank2+NP2_DIRECT_BANK_BYTES){base=bank2;bank=2U;}
    else {
#if XE_NP_NP2_LIVE_SD_EXTENDED_RING
        if(address>=NP2_DIRECT_EXTENDED_BASE+NP2_DIRECT_D8_LANE_OFFSET &&
           address<=NP2_DIRECT_EXTENDED_BASE+4U*NP2_DIRECT_SLOT_BYTES){
            uint32_t relative=(uint32_t)(address-(NP2_DIRECT_EXTENDED_BASE+NP2_DIRECT_D8_LANE_OFFSET));
            uint32_t slot=relative/NP2_DIRECT_SLOT_BYTES,within=relative%NP2_DIRECT_SLOT_BYTES;
            if(slot>=4U || within>NP2_DIRECT_D8_BYTES)return UINT32_MAX;
            uint32_t offset=((48U+slot)*NP2_DIRECT_TICKS)+(within<<3U);
            return offset==NP2_DIRECT_RING_TICKS?0U:offset;
        }
#endif
        return UINT32_MAX;
    }
    uint32_t relative=(uint32_t)(address-(base+NP2_DIRECT_D8_LANE_OFFSET));
    uint32_t slot=relative/NP2_DIRECT_SLOT_BYTES,within=relative%NP2_DIRECT_SLOT_BYTES;
    if(slot>=NP2_DIRECT_SLOTS_PER_BANK || within>NP2_DIRECT_D8_BYTES)return UINT32_MAX;
    uint32_t offset=((bank*NP2_DIRECT_SLOTS_PER_BANK+slot)*NP2_DIRECT_TICKS)+(within<<3U);
    return offset==NP2_DIRECT_RING_TICKS?0U:offset;
#endif
}
static inline uint32_t XE_NP_Np2DirectD8LookaheadBytes(uint32_t offset)
{return (offset+7U)/8U;}
static inline void XE_NP_Np2DirectD8Put32(uint8_t *p,uint32_t value)
{p[0]=(uint8_t)value;p[1]=(uint8_t)(value>>8U);p[2]=(uint8_t)(value>>16U);p[3]=(uint8_t)(value>>24U);}
/* Opt-in no-shift record layout. Keep the SPI plane raw in the payload and
 * preserve just enough next-block bits in reserved header space for a reader
 * to reconstruct the aligned tail. PSSI8 and the 9-bit wire geometry are unchanged. */
static inline void XE_NP_Np2DirectD8PrepareRawPhase(uint8_t *block,
    const uint8_t *next_lane,uint32_t offset)
{
    uint32_t bytes=XE_NP_Np2DirectD8LookaheadBytes(offset);
    XE_NP_Np2DirectD8Put32(block+NP2_DIRECT_D8_PHASE_OFFSET,offset);
    XE_NP_Np2DirectD8Put32(block+NP2_DIRECT_D8_LOOKAHEAD_BYTES_OFFSET,bytes);
    if(bytes)memcpy(block+NP2_DIRECT_D8_LOOKAHEAD_OFFSET,next_lane,bytes);
}
static inline uint32_t XE_NP_Np2DirectD8RawBit(const uint8_t *block,
    uint32_t tick,uint32_t offset)
{
    uint32_t bit=tick+offset;
    if(bit<NP2_DIRECT_TICKS)
        return (block[512U+NP2_DIRECT_TICKS+(bit>>3U)]>>(bit&7U))&1U;
    bit-=NP2_DIRECT_TICKS;
    return (block[NP2_DIRECT_D8_LOOKAHEAD_OFFSET+(bit>>3U)]>>(bit&7U))&1U;
}
/* Positive SPI launch offset, in-place forward correction. Only the small
 * serial lane moves; the PSSI body is never copied. next is still raw.
 * Record fields are word aligned; memcpy keeps aliasing defined on M33.
 * The caller supplies the uniquely calibrated offset in [0,1599]. */
static inline void XE_NP_Np2DirectShiftD8(uint8_t *current,const uint8_t *next,uint32_t offset)
{
    if(!offset)return;
    uint32_t index=(offset/32U)*4U,shift=offset%32U,out=0U;
    if(!shift){
        /* Byte-aligned phase still needs an overlapping forward copy. Load
         * each four-word group before storing it so small offsets cannot
         * overwrite a source word in the same group. */
        for(;index+16U<=NP2_DIRECT_D8_BYTES;index+=16U,out+=16U){
            uint32_t w0,w1,w2,w3;
            memcpy(&w0,current+index,4U);memcpy(&w1,current+index+4U,4U);
            memcpy(&w2,current+index+8U,4U);memcpy(&w3,current+index+12U,4U);
            memcpy(current+out,&w0,4U);memcpy(current+out+4U,&w1,4U);
            memcpy(current+out+8U,&w2,4U);memcpy(current+out+12U,&w3,4U);
        }
        for(;out<NP2_DIRECT_D8_BYTES;index+=4U,out+=4U){
            uint32_t value;memcpy(&value,next+index-NP2_DIRECT_D8_BYTES,4U);memcpy(current+out,&value,4U);
        }
        return;
    }
    /* One new ALIGNED word read and one write per four output bytes. Carry
     * the previous source word in a register instead of repeatedly doing
     * unaligned reads plus a fifth byte from non-cacheable SRAM. */
    uint32_t low;memcpy(&low,current+index,4U);index+=4U;
    uint32_t left=32U-shift;
    /* The D8 plane is only 5 KiB, but is prepared once per stream block.
     * Four-word unrolling reduces loop/control overhead while keeping all
     * source words loaded before stores (the forward in-place ranges overlap
     * when the calibrated offset is less than 16 bits). */
    for(;index+16U<=NP2_DIRECT_D8_BYTES;index+=16U,out+=16U){
        uint32_t h0,h1,h2,h3,v0,v1,v2,v3;
        memcpy(&h0,current+index,4U);memcpy(&h1,current+index+4U,4U);
        memcpy(&h2,current+index+8U,4U);memcpy(&h3,current+index+12U,4U);
        v0=(low>>shift)|(h0<<left);v1=(h0>>shift)|(h1<<left);
        v2=(h1>>shift)|(h2<<left);v3=(h2>>shift)|(h3<<left);
        memcpy(current+out,&v0,4U);memcpy(current+out+4U,&v1,4U);
        memcpy(current+out+8U,&v2,4U);memcpy(current+out+12U,&v3,4U);
        low=h3;
    }
    for(;index<NP2_DIRECT_D8_BYTES;index+=4U,out+=4U){
        uint32_t high,value;memcpy(&high,current+index,4U);
        value=(low>>shift)|(high<<left);memcpy(current+out,&value,4U);low=high;
    }
#if defined(__clang__)
#pragma clang loop unroll(disable)
#endif
    for(;out<NP2_DIRECT_D8_BYTES;index+=4U,out+=4U){
        uint32_t high,value;memcpy(&high,next+index-NP2_DIRECT_D8_BYTES,4U);
        value=(low>>shift)|(high<<(32U-shift));memcpy(current+out,&value,4U);low=high;
    }
}
#endif
