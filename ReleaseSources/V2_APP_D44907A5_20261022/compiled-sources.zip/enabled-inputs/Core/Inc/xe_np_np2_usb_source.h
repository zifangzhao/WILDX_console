#ifndef XE_NP_NP2_USB_SOURCE_H
#define XE_NP_NP2_USB_SOURCE_H

#include <stdint.h>
#include "xe_np_np2_session.h"

/* Explicitly opt-in NP2013 raw-source bring-up for the resident USB image.
 * U$1/I2C2, U$3/I2C3 and U$4/I2C4 are configured concurrently before their
 * parallel PSSI lanes are released together. */
#ifndef XE_NP_NP2_USB_SOURCE_ENABLE
#define XE_NP_NP2_USB_SOURCE_ENABLE 0U
#endif

/* Setup-only power trial; keep sensor I2C5/6 and all data clocks unchanged. */
#ifndef XE_NP_NP2_SD_SINGLE7500_I2C_CLOCK_GATE_TEST
#define XE_NP_NP2_SD_SINGLE7500_I2C_CLOCK_GATE_TEST 0U
#endif

/* HIL-only known-pattern image. This changes the startup OP_MODE write,
 * not capture, packing, DMA, SD service, or the ordinary recording format.
 * Normal builds always leave it off. Do not publish a diagnostic package. */
#ifndef XE_NP_NP2_SD_DIGITAL_PATTERN_TEST
#define XE_NP_NP2_SD_DIGITAL_PATTERN_TEST 0U
#endif
#if XE_NP_NP2_SD_DIGITAL_PATTERN_TEST > 1U
#error "Invalid NP2 SD digital-pattern diagnostic selection"
#endif
#if XE_NP_NP2_SD_DIGITAL_PATTERN_TEST && (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_SD_BLE_ENABLE)
#error "NP2 SD digital-pattern diagnostic requires the explicit-start catalog BLE image"
#endif

#define XE_NP_NP2_USB_SOURCE_MAGIC 0x3153324EUL /* N2S1 */
#define XE_NP_NP2_USB_SOURCE_VERSION 1U
/* Each probe keeps the conservative 200 ms operation fault bound. With the
 * current internal-pullup timing, three concurrent buses complete 5,559
 * verified operations in about 8 s; the separate analog settle is 10 s. */
#define XE_NP_NP2_USB_SOURCE_I2C_TIMEOUT_MS 200U
#define XE_NP_NP2_USB_SOURCE_CONFIG_TIMEOUT_MS 300000U

enum {
    XE_NP_NP2_USB_SOURCE_IDLE = 0U,
    XE_NP_NP2_USB_SOURCE_PREPARE, XE_NP_NP2_USB_SOURCE_POWER_WAIT,
    XE_NP_NP2_USB_SOURCE_CLOCK_WAIT, XE_NP_NP2_USB_SOURCE_RESET_WAIT,
    XE_NP_NP2_USB_SOURCE_IDENTIFY, XE_NP_NP2_USB_SOURCE_EEPROM,
    XE_NP_NP2_USB_SOURCE_CONFIGURE, XE_NP_NP2_USB_SOURCE_SETTLING,
    XE_NP_NP2_USB_SOURCE_RELEASE, XE_NP_NP2_USB_SOURCE_READY,
    XE_NP_NP2_USB_SOURCE_STOPPED, XE_NP_NP2_USB_SOURCE_FAILED = 0xFFU
};
enum {
    XE_NP_NP2_USB_SOURCE_ERROR_NONE = 0U,
    XE_NP_NP2_USB_SOURCE_ERROR_ARGUMENT, XE_NP_NP2_USB_SOURCE_ERROR_CLOCK,
    XE_NP_NP2_USB_SOURCE_ERROR_HSLV, XE_NP_NP2_USB_SOURCE_ERROR_I2C_INIT,
    XE_NP_NP2_USB_SOURCE_ERROR_I2C, XE_NP_NP2_USB_SOURCE_ERROR_ID,
    XE_NP_NP2_USB_SOURCE_ERROR_IDENTITY, XE_NP_NP2_USB_SOURCE_ERROR_SHIFT,
    XE_NP_NP2_USB_SOURCE_ERROR_CAPTURE_BIND, XE_NP_NP2_USB_SOURCE_ERROR_CANCELLED,
    XE_NP_NP2_USB_SOURCE_ERROR_I2C_TIMEOUT,
    XE_NP_NP2_USB_SOURCE_ERROR_CONFIG_TIMEOUT
};
enum {
    XE_NP_NP2_USB_SOURCE_FLAG_IDENTITY = 1U,
    XE_NP_NP2_USB_SOURCE_FLAG_CHAINS = 2U,
    XE_NP_NP2_USB_SOURCE_FLAG_READY = 4U,
    XE_NP_NP2_USB_SOURCE_FLAG_CAPTURE_BOUND = 8U,
    /* A shank did not compare; base/control passed. chain_fail_mask retains
     * per-probe failures. Applied receipt distinguishes verified selected
     * chains from best-effort unverified mapping. Not analog proof. */
    XE_NP_NP2_USB_SOURCE_FLAG_DEGRADED = 16U
};
/* Fault-only context in the existing flags word: ABI/size unchanged. Probe3
 * is shared/unknown; step255 is unavailable. Never updated in capture IRQs. */
#define XE_NP_NP2_USB_SOURCE_FLAG_FAULT_CONTEXT 0x100U
#define XE_NP_NP2_USB_SOURCE_FAULT_PROBE_SHIFT 9U
#define XE_NP_NP2_USB_SOURCE_FAULT_STATE_SHIFT 16U
#define XE_NP_NP2_USB_SOURCE_FAULT_STEP_SHIFT 24U
#define XE_NP_NP2_USB_SOURCE_FAULT_FIELDS 0xFFFF0700UL

/* Stable foreground-owned status for EP0. EEPROM bytes are deliberately not
 * exported here; they are an identity gate, not a host-writeable profile. */
typedef struct {
    uint32_t magic, version, state, error, flags;
    uint32_t started_ms, state_since_ms, i2c_error, i2c_operations;
    uint32_t i2c_deadline_ms, config_deadline_ms;
    uint32_t hclk_hz, sysclk_hz, rcc_cfgr1, id, op, rec, cal;
    uint32_t chain, chain_pass, chain_index, chain_fail_mask;
    uint32_t chain_status[6];
    uint32_t eeprom_reads, eeprom_match, ring_address, ring_bytes;
    uint8_t serial[8];
    uint8_t model[8];
} XE_NP_Np2UsbSourceStatus;

/* Init and Start perform no I2C transfer and do not arm PSSI/DMA. Start is
 * accepted once per boot only. Service performs at most one I2C start/poll or
 * one bounded hardware state transition; call it from the foreground. */
int XE_NP_Np2UsbSource_Init(void);
/* Select probe control buses before Start. Bit0=I2C2/PSSI[2:0],
 * bit1=I2C3/PSSI[5:3], bit2=I2C4/PSSI[8:6]. A running/used source cannot be
 * rebound. */
int XE_NP_Np2UsbSource_SelectProbeMask(uint32_t probe_mask);
int XE_NP_Np2UsbSource_Start(void);
void XE_NP_Np2UsbSource_Service(void);
int XE_NP_Np2UsbSource_IsReady(void);
int XE_NP_Np2UsbSource_IsBusy(void);
/* Safe in every state: abort I2C, stop capture if bound, assert shared reset,
 * stop NP2 MCO and remove probe power. The source cannot restart afterwards. */
void XE_NP_Np2UsbSource_Stop(void);
/* Available only in READY. USB owns arm/status/take/release; it must stop via
 * XE_NP_Np2UsbSource_Stop on any terminal consumer/source error. */
const XE_NP_Np2ProducerIo *XE_NP_Np2UsbSource_GetProducerIo(void);
void XE_NP_Np2UsbSource_GetStatus(XE_NP_Np2UsbSourceStatus *out);
int XE_NP_Np2UsbSource_GetProbeIdentity(uint32_t probe_index,
                                       uint8_t serial[8],uint8_t model[8]);
/* Main image IRQ vectors pass probe index 0/1/2 for I2C2/I2C3/I2C4. Each bus is
 * delegated only while that probe has a request in flight. No ISR runs
 * configuration policy or starts a transfer. */
void XE_NP_Np2UsbSource_I2cEventIrq(uint32_t probe_index);
void XE_NP_Np2UsbSource_I2cErrorIrq(uint32_t probe_index);

#endif
