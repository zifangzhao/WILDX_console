"""Seal checked APP only and merge unchanged B609 USB/recovery; no publication."""
import copy
import hashlib
import json
from pathlib import Path
import shutil
import struct
import sys
import zipfile
import zlib

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'Tools'))
import package_xe_np_firmware as package
from verify_xe_np_installed_image import verify

WORK = ROOT/'_artifacts/v2_ble_catalog_restore_20261022'
LATEST = ROOT/'LATEST_FIRMWARE/V2_NP2'
PARENT = LATEST/'V2_fused_RECOVERY_6408DBB8_USB_B6099A0E_APP_660A6DA4_GUARDED_FORMAT_20261022.hex'
INDEX = Path('D:/Code/WILDX_console/WILDX_console/Firmware/releases.json')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def main():
    out,build = WORK/'delivery',WORK/'build'
    if out.exists():
        raise ValueError('One fresh packaging pass; preserve sealed bytes')
    receipt = json.loads((build/'incremental-build.json').read_text())
    body = (build/'application.bin').read_bytes()
    if (receipt['parent_crc32']!='660A6DA4' or receipt['body_sha256']!=sha(build/'application.bin') or
            receipt['body_bytes']!=len(body) or not receipt['capture_writer_ble_objects_unchanged'] or
            sha(PARENT)!='E0683376C7DAB7F36ACBB8D5E67EAD31840C9258402A9FEA7A0D57451B88193A'):
        raise ValueError('Exact checked build and current full fused required')
    for p,h in receipt['source_inputs'].items():
        if sha(Path(p))!=h:
            raise ValueError('Frozen input changed: '+p)
    package.LOADER_ABI_VERSION=4
    manifest = package.build_manifest(body,generation=4)
    verify(manifest,body,manifest,body)
    app = package.sealed_slot_memory(body,manifest)
    old = package.read_intel_hex(PARENT)
    fused = {a:(0xFF if package.MANIFEST_BASE<=a<package.APP_LIMIT else b) for a,b in old.items()}
    fused.update(app)
    expected = package.USB_LIMIT-package.FLASH_BASE-(package.MANIFEST_BASE-package.CONFIG_BASE)
    if (len(fused)!=expected or any(a not in fused for a in range(package.FLASH_BASE,package.USB_LIMIT)
            if not package.CONFIG_BASE<=a<package.MANIFEST_BASE) or
            any(package.CONFIG_BASE<=a<package.MANIFEST_BASE for a in fused) or
            {a:b for a,b in fused.items() if not package.MANIFEST_BASE<=a<package.APP_LIMIT} !=
            {a:b for a,b in old.items() if not package.MANIFEST_BASE<=a<package.APP_LIMIT}):
        raise ValueError('Complete explicit FF coverage, retained settings or nonAPP byte identity failed')
    crc=f'{zlib.crc32(body):08X}'
    out.mkdir()
    apphex=out/f'V2_logger_APP_only_{crc}_BLE_CATALOG_20261022.hex'
    update=out/f'V2_logger_APP_update_{crc}_BLE_CATALOG_20261022.xenp'
    full=out/f'V2_fused_RECOVERY_6408DBB8_USB_B6099A0E_APP_{crc}_BLE_CATALOG_20261022.hex'
    for path,memory in ((apphex,app),(full,fused)):
        package.write_intel_hex(path,memory)
        path.write_bytes(path.read_bytes().replace(b'\r\n',b'\n'))
        if b'\r' in path.read_bytes() or package.read_intel_hex(path)!=memory:
            raise ValueError('Exact LF HEX roundtrip failed')
    update.write_bytes(manifest+body)
    archive=out/'compiled-sources.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as bundle:
        for folder in ('enabled-inputs','baseline-inputs'):
            for path in sorted((WORK/folder).rglob('*')):
                if path.is_file():
                    bundle.write(path,path.relative_to(WORK).as_posix())
        for path in (WORK/'freeze-receipt.json',build/'incremental-build.json',
                     build/'application.lnp',build/'application.map',
                     WORK/'native/source-inputs.json',WORK/'native/capability0/run.log',
                     WORK/'native-enabled-r4/source-inputs.json',WORK/'native-enabled-r4/capability1/run.log'):
            bundle.write(path,path.relative_to(WORK).as_posix())
        for path in sorted(build.glob('*.o'))+sorted(build.glob('*.compile.log')):
            bundle.write(path,path.relative_to(WORK).as_posix())
        for relative in ('Tools/V2SdLogger/build_ble_catalog_restore.py','Tools/V2SdLogger/package_ble_catalog_restore.py',
                         'Tools/V2SdLogger/tests/test_np2_ble_catalog.c','Tools/V2SdLogger/tests/test_np2_ble_catalog.ps1'):
            bundle.write(ROOT/relative,relative)
    current=json.loads((LATEST/'package-receipt.json').read_text())
    retained=[name for name in current['files'] if 'APP' not in name and 'fused' not in name]
    for name in retained:
        if sha(LATEST/name)!=current['files'][name]['sha256']:
            raise ValueError('Retained component changed')
        shutil.copyfile(LATEST/name,out/name)
    files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in (apphex,update,full)}
    files.update({name:current['files'][name] for name in retained})
    scope=('Stopped BLE catalog INFO/ENTRY and explicitly confirmed last-COMPLETE delete checked with '
           'actual control/APP/catalog/port native fakes, journal power cuts and degraded/v14 read-only views. '
           'APP660 capture/Stop source and59 other objects retained. No hardware access, flash, new recording, '
           'all-card/all-mode or installed-pair qualification. USB B6099A0E/recovery6408DBB8 byte-identical; '
           'full fused explicit FF except retained settings. GUI92 retains the pending-Stop display fix.')
    result=dict(app_crc32=crc,usb_crc32='B6099A0E',recovery_crc32='6408DBB8',
        gui_version='1.0.0.92',gui_sha256='84FA65044A61F7E7DF5A08DDA3DF2B0745863FA2EAEEFA3FDD5D86975DE30851',
        files=files,body_sha256=sha(build/'application.bin'),body_bytes=len(body),
        build_receipt_sha256=sha(build/'incremental-build.json'),freeze_receipt_sha256=sha(WORK/'freeze-receipt.json'),
        catalog_capability_bit=22,info_flags_mask='048F0000',settings_omitted=True,
        all_non_app_bytes_preserved=True,logical_flash_complete_except_settings=True,
        firmware_source_archive_sha256=sha(archive),
        firmware_source_archive_path=f'ReleaseSources/V2_APP_{crc}_20261022/compiled-sources.zip',
        source_freeze=str(WORK/'enabled-inputs'),scope=scope,pair_hardware_validated=False,flashed=False,published=False)
    (out/'package-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    (out/'source-manifest.json').write_text(json.dumps(dict(**result,build=receipt,
        frozen_source=json.loads((WORK/'freeze-receipt.json').read_text())),indent=2)+'\n')
    (out/'SHA256SUMS.txt').write_text(''.join(v['sha256']+'  '+n+'\n' for n,v in files.items()))
    (out/'README.md').write_text(f'# V2 BLE catalog / WILD-X1.0.0.92\n\nAPP{crc} enables BLE Recordings on the checked APP660 recording/Stop baseline.\n'
        'USB B6099A0E and recovery6408DBB8 are unchanged. INFO/ENTRY are stopped-only and read-only;\n'
        'degraded/rewind views never offer Delete or silently repair/discard data.\n\n'
        f'Use `{update.name}` for an APP-only recovery update, or `{full.name}` through guarded ROM DFU/SWD.\n'
        'HEX excludes retained settings and includes all other logical flash bytes explicitly.\n\n'
        'Stop acknowledges once, then drains and verifies stored data before Complete. GUI90+ observes\n'
        'this asynchronously without a false30-second failure. Keep power until Complete.\n\n'+scope+'\n')
    index=json.loads(INDEX.read_text(encoding='utf-8-sig'))
    v2,=[r for r in index['releases'] if r['family']==2]
    original=copy.deepcopy(v2)
    v2.update(release=f'V2_BLE_CATALOG_APP{crc}_USB_B6099A0E_20261022',
        stage='BLE_CATALOG_SOFTWARE_CHECKED_HARDWARE_VALIDATION_PENDING',
        appVersion=f'build{crc} (BLE catalog; APP660 capture/Stop retained)',appCrc32=crc,
        app=dict(path='V2/'+update.name,sha256=sha(update)),
        full=dict(path='V2/'+full.name,sha256=sha(full)),
        files=[dict(path='V2/'+n,sha256=v['sha256']) for n,v in files.items()],limits=scope)
    v2['previousApps']=[original['appIdentity']]+original['previousApps']
    v2['appIdentity']=dict(imageId=package.IMAGE_ID_APPLICATION,baseAddress=package.APP_BASE,
        bytes=len(body),codeCrc32=crc,buildIdHex=manifest[44:76].hex().upper(),
        manifestFlags=0,minimumLoaderAbi=4,generation=4)
    if any(r!=oldr for r,oldr in zip(index['releases'],json.loads(INDEX.read_text(encoding='utf-8-sig'))['releases']) if r['family']!=2):
        raise ValueError('V1 release entries changed')
    (out/'releases.json').write_text(json.dumps(index,indent=2)+'\n')
    print(json.dumps(dict(directory=str(out),app_crc32=crc,files=files),indent=2))


if __name__=='__main__':
    main()
