param([string]$OutputDirectory='_artifacts/v2_ble_catalog_native_20261019',[switch]$EnabledOnly,[string]$SourceDirectory='')
$ErrorActionPreference='Stop'
$taskRoot=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$taskOut=if([IO.Path]::IsPathRooted($OutputDirectory)){[IO.Path]::GetFullPath($OutputDirectory)}else{[IO.Path]::GetFullPath((Join-Path $taskRoot $OutputDirectory))}
if(Test-Path -LiteralPath $taskOut){throw 'Use a fresh catalog fixture output directory'}
New-Item -ItemType Directory -Path $taskOut | Out-Null
$taskVc='C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat'
$taskStub=Join-Path $PSScriptRoot 'catalog_native'
$taskOriginal=Join-Path $PSScriptRoot 'test_np2_ble_catalog.c'
$taskTest=$taskOriginal
$taskSource=if($SourceDirectory){[IO.Path]::GetFullPath($SourceDirectory)}else{Join-Path $taskRoot 'Core/Src'}
$taskUnits=@('xe_np_np2_dual_sd_app.c','xe_np_np2_sd_control.c','xe_np_np2_dual_sd_catalog_port.c','xe_np_np2_dual_sd_catalog.c')
$taskInputs=@([ordered]@{path=$taskOriginal;sha256=(Get-FileHash -LiteralPath $taskOriginal -Algorithm SHA256).Hash})
foreach($taskUnit in $taskUnits){
    $taskInput=Join-Path $taskSource $taskUnit
    if(!(Test-Path -LiteralPath $taskInput -PathType Leaf)){throw ('Missing catalog source: '+$taskInput)}
    $taskInputs+=([ordered]@{path=$taskInput;sha256=(Get-FileHash -LiteralPath $taskInput -Algorithm SHA256).Hash})
}
if($SourceDirectory){
    # Mechanical fixture preparation only: no quoted /D path through cmd.exe.
    $taskText=[IO.File]::ReadAllText($taskOriginal)
    $taskMarker='#define NP_BLE_CATALOG_APP_SOURCE "../../../Core/Src/xe_np_np2_dual_sd_app.c"'
    if(([regex]::Matches($taskText,[regex]::Escape($taskMarker))).Count -ne 1){throw 'APP include override marker changed'}
    $taskApp=(Join-Path $taskSource 'xe_np_np2_dual_sd_app.c').Replace('\','/')
    # The retained ARM snapshot ends with three target-pointer ABI assertions.
    # Native x64 cannot establish ARM layout; armclang retains all three.
    $taskAppText=[IO.File]::ReadAllText($taskApp)
    $taskArmProof='(?m)^_Static_assert\(sizeof\(XE_NP_Np2(?:Producer|ProducerIo|SdLoss)\)==(?:176|40)U,"(?:Drain producer ABI176|Unchanged ProducerIo ABI40|Drain loss ABI40)"\);\r?\n?'
    $taskArmMatches=[regex]::Matches($taskAppText,$taskArmProof)
    if($taskArmMatches.Count -ne 3){throw 'Exact three retained ARM-only ABI checks required'}
    $taskNativeApp=Join-Path $taskOut 'xe_np_np2_dual_sd_app_native.c'
    [IO.File]::WriteAllText($taskNativeApp,([regex]::Replace($taskAppText,$taskArmProof,'')),[Text.UTF8Encoding]::new($false))
    $taskApp=$taskNativeApp.Replace('\','/')
    $taskInputs+=([ordered]@{path=$taskNativeApp;sha256=(Get-FileHash -LiteralPath $taskNativeApp -Algorithm SHA256).Hash;translation='Only3 target-specific ARM ABI assertions omitted; firmware retains them'})
    $taskText=$taskText.Replace($taskMarker,('#define NP_BLE_CATALOG_APP_SOURCE "'+$taskApp+'"'))
    $taskTest=Join-Path $taskOut 'test_np2_ble_catalog_frozen.c'
    [IO.File]::WriteAllText($taskTest,$taskText,[Text.UTF8Encoding]::new($false))
}
$taskInputs | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $taskOut 'source-inputs.json') -Encoding UTF8
# Same actual APP/header parent admission as the existing append APP fixture.
# Capture/writer/SSR endpoints are modeled; no peripheral or payload execution.
$taskFlags=@(
    'XE_NP_NP2_SD_APPEND_ORDER_TEST=1U','XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE=1U',
    'XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES=1U','XE_NP_NP2_LIVE_SD_WRITE_RUS=6U',
    'XE_NP_NP2_LIVE_SD_WRITE_CAP_RUS=6U','XE_NP_NP2_LIVE_SD_MIN_WRITE_RUS=1U',
    'XE_NP_NP2_LIVE_SD_OVERFLOW_DMA=1U','XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER=1U',
    'XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST=1024U','XE_NP_NP2_LIVE_SD_VSC_TEST=1U',
    'XE_NP_NP2_SD_PROFILE_CLASSIC_TEST=1U','XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST=1U',
    'XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST=1U','XE_NP_NP2_SD_CARD_AU_POLICY_TEST=1U',
    'XE_NP_NP2_CLASSIC_RUNTIME_PROFILES_TEST=1U','XE_NP_NP2_CLASSIC_FIXED_RUNTIME_PROFILES_TEST=1U',
    'XE_NP_NP2_MIXED_SEQUENTIAL_POWER_RUNTIME_PROFILES_TEST=1U',
    'XE_NP_NP2_LIVE_SD_BLOCK_LIMIT=32U'
)
$taskDefs=($taskFlags|ForEach-Object {'/D'+$_}) -join ' '
if($SourceDirectory){$taskDefs+=' /DNP_BLE_CATALOG_NO_WIRE_REWIND=1'}
$taskFrozenInclude=if($SourceDirectory){' /I"'+$taskSource+'" /I"'+([IO.Path]::GetFullPath((Join-Path $taskSource '../Inc')))+'"'}else{''}
$taskVariants=if($EnabledOnly){@(1)}else{@(0,1)}
foreach($taskEnabled in $taskVariants){
    $taskConfig=Join-Path $taskOut ('capability'+$taskEnabled)
    New-Item -ItemType Directory -Path $taskConfig|Out-Null
    $taskExe=Join-Path $taskConfig 'test_np2_ble_catalog.exe'
    $taskDefine=if($taskEnabled){'/DXE_NP_NP2_SD_CATALOG_ENABLE=1U '}else{''}
    $taskCommand='call "'+$taskVc+'" >nul && cl /nologo /std:c11 /W4 /WX /TC /O2 '+$taskDefs+' '+$taskDefine+
        '/FI"'+$taskStub+'/hardware.h" /I"'+$taskStub+'"'+$taskFrozenInclude+' /I"'+$taskRoot+'/Core/Inc" '+
        '"'+$taskTest+'" '+
        '"'+$taskSource+'/xe_np_np2_sd_control.c" '+
        '"'+$taskSource+'/xe_np_np2_dual_sd_catalog_port.c" '+
        '"'+$taskSource+'/xe_np_np2_dual_sd_catalog.c" '+
        '"'+$taskRoot+'/Core/Src/xe_np_np2_dual_sd_meta.c" '+
        '"'+$taskRoot+'/Core/Src/xe_np_np2_dual_sd_run.c" '+
        '/Fo"'+$taskConfig+'/" /Fe"'+$taskExe+'"'
    & $env:ComSpec /d /c $taskCommand 2>&1 | Tee-Object -FilePath (Join-Path $taskConfig 'compile.log')
    if($LASTEXITCODE){throw ('BLE catalog compile failed: capability'+$taskEnabled)}
    & $taskExe 2>&1 | Tee-Object -FilePath (Join-Path $taskConfig 'run.log')
    if($LASTEXITCODE){throw ('BLE catalog regression failed: capability'+$taskEnabled)}
}
