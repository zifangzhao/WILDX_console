#include <assert.h>
#include <stdio.h>
#include <string.h>
#ifndef NP_BLE_CATALOG_APP_SOURCE
#define NP_BLE_CATALOG_APP_SOURCE "../../../Core/Src/xe_np_np2_dual_sd_app.c"
#endif
#include NP_BLE_CATALOG_APP_SOURCE
#include "xe_np_np2_sd_control.h"
#ifndef NP_BLE_CATALOG_NO_WIRE_REWIND
#define NP_BLE_CATALOG_NO_WIRE_REWIND 0
#endif
#define PREFIX_FLAGS (XE_NP_NP2_CATALOG_DEGRADED|XE_NP_NP2_CATALOG_RECOVERY| \
    (NP_BLE_CATALOG_NO_WIRE_REWIND?0U:XE_NP_NP2_CATALOG_REWIND_AVAILABLE))

SDMMC_TypeDef native_sd;
PSSI_TypeDef native_pssi;
SPI_TypeDef native_spi[2];
DMA_Channel_TypeDef native_dma[16];
volatile XE_NP_Np2LiveSdMailbox xe_np_np2_live_sd_mailbox;
volatile uint32_t xe_np_sd_status_raw[16];
static SD_HandleTypeDef model_card;
static DCACHE_HandleTypeDef model_cache;
static uint32_t model_cid[4]={1U,2U,3U,4U};
#define CAPACITY 8388608U
#define SECTORS 1024U
static struct {uint32_t lba;uint8_t bytes[512];} media[SECTORS];
static uint32_t used,reads,writes,commands,armed,source_busy,source_ready;
static uint32_t failed_read=UINT32_MAX,failed_write,fail_after,delete_only;
static uint8_t request[64],reply[64];
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
static XE_NP_Np2SdAppendCounts model_counts;
int XE_NP_Np2LiveSd_GetAppendCounts(XE_NP_Np2SdAppendCounts *out){*out=model_counts;return 0;}
int XE_NP_Np2LiveSd_InitExtentAppendProfile(SD_HandleTypeDef *c,DCACHE_HandleTypeDef *dc,
    uint32_t lba,uint32_t blocks,uint32_t mask,uint32_t hz,uint32_t au,uint32_t end)
{(void)c;(void)dc;(void)lba;(void)blocks;(void)mask;(void)hz;(void)au;(void)end;assert(0);return -1;}
void XE_NP_Np2LiveSd_InitExtentClassicAuProfile(SD_HandleTypeDef *c,DCACHE_HandleTypeDef *dc,
    uint32_t lba,uint32_t blocks,uint32_t mask,uint32_t hz,uint32_t au,uint32_t end)
{(void)c;(void)dc;(void)lba;(void)blocks;(void)mask;(void)hz;(void)au;(void)end;assert(0);}
void XE_NP_Np2LiveSd_InitExtentAuProfile(SD_HandleTypeDef *c,DCACHE_HandleTypeDef *dc,
    uint32_t lba,uint32_t blocks,uint32_t mask,uint32_t hz,uint32_t au)
{(void)c;(void)dc;(void)lba;(void)blocks;(void)mask;(void)hz;(void)au;assert(0);}
#endif
static uint32_t u32(const uint8_t *p)
{return (uint32_t)p[0]|((uint32_t)p[1]<<8U)|((uint32_t)p[2]<<16U)|((uint32_t)p[3]<<24U);}
static uint8_t *sector(uint32_t lba)
{
    for(uint32_t i=0U;i<used;i++)if(media[i].lba==lba)return media[i].bytes;
    assert(used<SECTORS);media[used].lba=lba;memset(media[used].bytes,0,512U);return media[used++].bytes;
}
uint32_t HAL_GetTick(void){return 123U;}
uint32_t HAL_RCC_GetHCLKFreq(void){return 192000000U;}
uint32_t HAL_SD_GetCardState(SD_HandleTypeDef *c){assert(c==&model_card);return HAL_SD_CARD_TRANSFER;}
uint32_t HAL_SD_GetCardStatus(SD_HandleTypeDef *c,HAL_SD_CardStatusTypeDef *s)
{assert(c==&model_card);memset(s,0,sizeof(*s));s->UhsSpeedGrade=1U;s->UhsAllocationUnitSize=10U;return HAL_OK;}
uint32_t HAL_SD_ReadBlocks(SD_HandleTypeDef *c,uint8_t *out,uint32_t lba,uint32_t count,uint32_t timeout)
{
    assert(c==&model_card && count==1U && timeout==1000U && lba<CAPACITY);reads++;
    if(lba==failed_read)return 1U;
    memcpy(out,sector(lba),512U);c->Context=SD_CONTEXT_READ_SINGLE_BLOCK;return HAL_OK;
}
uint32_t HAL_SD_WriteBlocks(SD_HandleTypeDef *c,const uint8_t *in,uint32_t lba,uint32_t count,uint32_t timeout)
{
    assert(c==&model_card && count==1U && timeout==1000U && lba<CAPACITY);writes++;
    if(delete_only)assert(lba==112U || lba==113U || (lba>=128U && lba<1152U));
    if(writes==failed_write && !fail_after)return 1U;
    memcpy(sector(lba),in,512U);c->Context=SD_CONTEXT_WRITE_SINGLE_BLOCK;
    if(writes==failed_write && fail_after){c->Context=SD_CONTEXT_NONE;return 1U;}
    return HAL_OK;
}
uint32_t SDMMC_SendCommand(SDMMC_TypeDef *sd,const SDMMC_CmdInitTypeDef *cmd)
{assert(sd==SDMMC1 && cmd->CmdIndex==20U && !delete_only);commands++;return HAL_OK;}
uint32_t SDMMC_GetCmdResp1(SDMMC_TypeDef *sd,uint32_t cmd,uint32_t timeout)
{assert(sd==SDMMC1 && cmd==20U && timeout==10U);return 0U;}
void HAL_NVIC_DisableIRQ(uint32_t irq){assert(irq==SDMMC1_IRQn);}
void HAL_NVIC_ClearPendingIRQ(uint32_t irq){assert(irq==SDMMC1_IRQn);}
int XE_NP_Board_SdUhsReadyForNpRaw(void){return 1;}
int XE_NP_Np2CapturePort_Armed(void){return (int)armed;}
int XE_NP_Np2UsbSource_IsBusy(void){return (int)source_busy;}
int XE_NP_Np2UsbSource_IsReady(void){return (int)source_ready;}
int XE_NP_Np2SdBle_ModeAvailable(uint32_t mode){return mode>=1U && mode<=3U;}
void XE_NP_Np2SdBle_ClockSnapshot(XE_NP_Np2OnlineClock *out){memset(out,0,sizeof(*out));}
uint64_t XE_NP_Np2Online_Utc(const XE_NP_Np2OnlineClock *clock,uint32_t now)
{(void)clock;(void)now;return 0U;}
const uint8_t *XE_NP_Np2Config_Selection(uint32_t port){(void)port;return NULL;}
uint32_t XE_NP_Np2Config_Crc(const uint8_t *p,uint32_t n){return XE_NP_Np2DualSd_Crc32(p,n);}
int XE_NP_Np2LiveSd_SupportsProfile(uint32_t mask,uint32_t hz)
{return XE_NP_Np2DualSd_ProfileTicks(mask,hz)!=0U;}
void XE_NP_Np2LiveSd_InitExtentProfile(SD_HandleTypeDef *c,DCACHE_HandleTypeDef *dc,
                                       uint32_t lba,uint32_t blocks,uint32_t mask,uint32_t hz)
{(void)c;(void)dc;(void)lba;(void)blocks;(void)mask;(void)hz;assert(0);}
void XE_NP_Np2LiveSd_Service(void){assert(0);}
int XE_NP_Np2LiveSd_RequestStop(void){assert(0);return -1;}
int XE_NP_Np2LiveSd_CancelPrepared(void){assert(0);return -1;}
static void frame(uint32_t op,uint32_t id)
{
    memset(request,0,sizeof(request));put32(request,XE_NP_NP2_SD_CONTROL_REQUEST);
    put32(request+4U,2U);put32(request+8U,op);put32(request+12U,id);
}
static uint32_t send(void)
{
    put32(request+60U,XE_NP_Np2DualSd_Crc32(request,60U));
    assert(!XE_NP_Np2SdControl_Exchange(request,reply));
    assert(u32(reply)==XE_NP_NP2_SD_CONTROL_REPLY && u32(reply+4U)==2U &&
        u32(reply+8U)==u32(request+8U) && u32(reply+12U)==u32(request+12U) &&
        u32(reply+60U)==XE_NP_Np2DualSd_Crc32(reply,60U));
    return u32(reply+16U);
}
static void reset_model(void)
{
    memset(media,0,sizeof(media));used=reads=writes=commands=0U;
    failed_read=UINT32_MAX;failed_write=fail_after=delete_only=0U;
    memset(&native_sd,0,sizeof(native_sd));native_sd.CLKCR=1U;
    memset(&native_pssi,0,sizeof(native_pssi));memset(native_spi,0,sizeof(native_spi));
    memset(native_dma,0,sizeof(native_dma));armed=source_busy=source_ready=0U;
    model_card.Instance=SDMMC1;model_card.State=HAL_SD_STATE_READY;
    model_card.ErrorCode=0U;model_card.Context=0U;model_card.SdCard.LogBlockNbr=CAPACITY;
    model_card.SdCard.CardType=CARD_SDHC_SDXC;
    memcpy(model_card.CID,model_cid,sizeof(model_cid));
    started=stop_pending=finished=0U;scheduled_utc=0U;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    delete_nonce=0U;
#endif
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
    reservation_append=append_writer_bound=0U;
#endif
    memset((void *)&xe_np_np2_live_sd_mailbox,0,sizeof(xe_np_np2_live_sd_mailbox));
    memset((void *)&xe_np_np2_dual_sd_app_mailbox,0,sizeof(xe_np_np2_dual_sd_app_mailbox));
    xe_np_np2_dual_sd_app_mailbox.card_blocks=CAPACITY;
    static const uint8_t system[512]="native only";
    assert(!XE_NP_Np2DualSdCatalogPort_Format(XE_NP_NP2_DUAL_SD_FORMAT_KEY,system));
    uint32_t next;
    assert(!XE_NP_Np2DualSdCatalogPort_Mount(&next));
    xe_np_np2_dual_sd_app_mailbox.state=1U;xe_np_np2_dual_sd_app_mailbox.next_start_lba=next;
    XE_NP_Np2SdControl_Init();
}
static void append(uint32_t ordinal,uint32_t state,uint32_t full)
{
    uint8_t configuration[2048]={0};XE_NP_Np2DualSdMeta m;
    uint32_t blocks=4U;
    if(full){
        uint32_t next=xe_np_np2_dual_sd_app_mailbox.next_start_lba;
        uint32_t payload=(next+8192U+16383U)&~16383U;
        blocks=(CAPACITY-payload)/XE_NP_NP2_DUAL_SD_SECTORS_PER_RU*4U;
    }
    assert(!XE_NP_Np2DualSdCatalogPort_PlanProfile(3U,20000U,blocks,ordinal+1U,
        XE_NP_Np2DualSd_Crc32(configuration,sizeof(configuration)),&m));
    assert(!XE_NP_Np2DualSdCatalogPort_Reserve(&m,configuration));
    assert(!XE_NP_Np2DualSdCatalogPort_Finish(state,state==4U?8U:0U,blocks));
    uint32_t next;assert(!XE_NP_Np2DualSdCatalogPort_Mount(&next));
    xe_np_np2_dual_sd_app_mailbox.next_start_lba=next;
}
#if XE_NP_NP2_SD_CATALOG_ENABLE
static uint32_t test_words_crc(const uint32_t words[15])
{
    uint8_t bytes[60];for(unsigned i=0U;i<15U;i++)put32(bytes+4U*i,words[i]);
    return XE_NP_Np2DualSd_Crc32(bytes,sizeof(bytes));
}
static uint32_t cid_crc(void)
{
    uint8_t bytes[16];for(unsigned i=0U;i<4U;i++)put32(bytes+4U*i,model_cid[i]);
    return XE_NP_Np2DualSd_Crc32(bytes,sizeof(bytes));
}
/* Solve the 32-bit linear CRC patch, not a production CRC override. */
static void zero_patch(uint8_t span[4],uint32_t (*calculate)(void))
{
    uint32_t basis[32]={0},masks[32]={0},base=calculate();
    for(unsigned bit=0U;bit<32U;bit++){
        span[bit/8U]^=(uint8_t)(1U<<(bit%8U));uint32_t value=calculate()^base,mask=1U<<bit;
        span[bit/8U]^=(uint8_t)(1U<<(bit%8U));
        for(int top=31;top>=0;top--)if(value&(1U<<(unsigned)top)){
            if(basis[top]){value^=basis[top];mask^=masks[top];}
            else{basis[top]=value;masks[top]=mask;break;}
        }
    }
    uint32_t patch=0U;
    for(int top=31;top>=0;top--)if(base&(1U<<(unsigned)top)){
        assert(basis[top]);base^=basis[top];patch^=masks[top];
    }
    for(unsigned bit=0U;bit<32U;bit++)if(patch&(1U<<bit))span[bit/8U]^=(uint8_t)(1U<<(bit%8U));
    assert(calculate()==0U);
}
static uint32_t empty_token_crc(void)
{
    uint32_t words[15]={0x5343324EU,CAPACITY,model_cid[0],model_cid[1],model_cid[2],model_cid[3],
        0U,8192U,128U,XE_NP_Np2DualSd_Crc32(sector(128U),512U),UINT32_MAX,0U,0U,0U,0U};
    return test_words_crc(words);
}
static uint32_t cookie_crc(void)
{
    uint32_t end=u32(sector(128U)+4U);
    uint32_t words[15]={0x4543324EU,CAPACITY,model_cid[0],model_cid[1],model_cid[2],model_cid[3],
        0U,8192U,end,end,XE_NP_Np2DualSd_Crc32(sector(8195U),508U),
        XE_NP_Np2DualSd_Crc32(sector(8196U),508U),u32(sector(8195U)+8U),u32(sector(8196U)+8U),0U};
    return test_words_crc(words);
}
static XE_NP_Np2DualSdCatalogInfo info(void)
{
    frame(9U,1U);uint32_t error=send();
    if(error)fprintf(stderr,"INFO error%u state%u command%u started%u stop%u schedule%llu writer%u ready%d reads%u writes%u\n",
        error,xe_np_np2_dual_sd_app_mailbox.state,xe_np_np2_dual_sd_app_mailbox.command,started,stop_pending,
        (unsigned long long)scheduled_utc,xe_np_np2_live_sd_mailbox.state,XE_NP_Np2DualSdCatalogPort_Ready(),reads,writes);
    if(error)fprintf(stderr,"raw directory count%u end%u event%u\n",u32(sector(128U)),u32(sector(128U)+4U),u32(sector(128U)+256U));
    assert(!error);
    XE_NP_Np2DualSdCatalogInfo i={u32(reply+20U),u32(reply+24U),u32(reply+28U),u32(reply+32U),
        u32(reply+36U),u32(reply+40U),u32(reply+44U),u32(reply+48U),u32(reply+52U),u32(reply+56U)};
    return i;
}
static void entry(XE_NP_Np2DualSdCatalogInfo i,uint32_t ordinal)
{
    frame(10U,2U);put32(request+16U,i.token);put32(request+20U,i.count);put32(request+24U,ordinal);
    assert(!send());assert(u32(reply+20U)==i.token && u32(reply+24U)==i.count && u32(reply+28U)==ordinal);
}
static void deletion(XE_NP_Np2DualSdCatalogInfo i,uint32_t id)
{
    frame(11U,id);put32(request+16U,i.token);put32(request+20U,i.count);put32(request+24U,i.last_ordinal);
    put32(request+28U,i.last_start);put32(request+32U,i.last_end);put32(request+36U,i.last_cookie);
    put32(request+40U,XE_NP_NP2_CATALOG_DELETE_KEY);
}
static void list_delete(void)
{
    static const uint32_t counts[]={0U,1U,3U,63U,64U};
    for(unsigned n=0U;n<sizeof(counts)/sizeof(counts[0]);n++){
        reset_model();uint32_t count=counts[n];
        for(uint32_t k=0U;k<count;k++)append(k,3U,0U);
        frame(1U,100U);put32(request+16U,3U);put32(request+20U,20000U);assert(!send());
        XE_NP_Np2DualSdCatalogInfo i=info();assert(i.count==count);
        if(!count){assert(i.last_ordinal==UINT32_MAX && !i.last_start && !i.last_end && !i.last_cookie && i.next==8192U);continue;}
        uint32_t previous=8192U,prefix_crc=0U;
        for(uint32_t k=0U;k<count;k++){
            entry(i,k);assert(u32(reply+32U)==previous);
            previous=(u32(reply+36U)+8191U)&~8191U;
            assert(((u32(reply+56U)&XE_NP_NP2_CATALOG_LAST)!=0U)==(k==count-1U));
            if(k==count-1U)assert(u32(reply+56U)&XE_NP_NP2_CATALOG_DELETE_ALLOWED);
            else prefix_crc^=u32(reply+40U);
        }
        assert(previous==i.next);
        xe_np_np2_dual_sd_app_mailbox.command_error=10U;
        deletion(i,101U);uint32_t before=writes,cmds=commands;delete_only=1U;
        assert(!send() && writes==before && (u32(reply+52U)&8U) && u32(reply+56U)==101U && !u32(reply+24U));
        assert(xe_np_np2_dual_sd_app_mailbox.command==XE_NP_NP2_DUAL_SD_CMD_DELETE_LAST && sizeof(XE_NP_Np2DualSdAppMailbox)==104U);
        assert(!send() && writes==before); /* Exact ACK replay never requeues. */
        uint8_t exact[64];memcpy(exact,request,sizeof(exact));
        XE_NP_Np2DualSdApp_Service();
        assert(!xe_np_np2_dual_sd_app_mailbox.command && !xe_np_np2_dual_sd_app_mailbox.command_error && commands==cmds);
        assert(writes==before+4U);before=writes;
        assert(!send() && !xe_np_np2_dual_sd_app_mailbox.command && writes==before);
        put32(request+36U,i.last_cookie^1U);assert(send()==6U && writes==before);
        memcpy(request,exact,sizeof(exact));assert(!send() && writes==before);
        XE_NP_Np2DualSdCatalogInfo after=info();assert(after.count==count-1U && after.card_blocks==i.card_blocks && after.cid_crc==i.cid_crc);
        uint32_t after_crc=0U;
        for(uint32_t k=0U;k<after.count;k++){entry(after,k);after_crc^=u32(reply+40U);}
        assert(after_crc==prefix_crc);
        frame(0U,1U);assert(!send() && u32(reply+56U)==101U && !(u32(reply+52U)&8U));
    }
    puts("PASS actual B9/app/port/catalog: empty, sole, COMPLETE, 63/64 boundaries, queued ACK, immutable prefix, replay/conflict and 104-byte ABI");
}
static void owner(uint32_t which)
{
    if(which<48U){native_dma[which/3U].CCR=1U<<(which%3U);return;}
    switch(which){
    case 48U:native_pssi.CR=1U;break;case 49U:native_spi[0].CR1=1U;break;case 50U:native_spi[1].CR1=1U;break;
    case 51U:armed=1U;break;case 52U:source_busy=1U;break;case 53U:source_ready=1U;break;
    case 54U:native_sd.IDMACTRL=1U;break;case 55U:native_sd.DCTRL=1U;break;
    case 56U:native_sd.STA=SDMMC_STA_BUSYD0;break;case 57U:native_sd.STA=SDMMC_STA_DPSMACT;break;
    case 58U:native_sd.STA=SDMMC_STA_CPSMACT;break;case 59U:model_card.Context=9U;break;
    case 60U:model_card.State=0U;break;case 61U:model_card.ErrorCode=1U;break;
    case 62U:model_card.CID[0]^=1U;break;case 63U:model_card.SdCard.LogBlockNbr--;break;
    case 64U:started=1U;break;case 65U:stop_pending=1U;break;case 66U:scheduled_utc=1U;break;
    case 67U:xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_CONFIGURING;break;
    case 68U:xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_CAPTURING;break;
    case 69U:xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_DRAINING;break;
    case 70U:xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_VERIFYING;break;
    default:assert(0);
    }
}
static void owners(void)
{
    for(uint32_t which=0U;which<71U;which++){
        reset_model();append(0U,3U,0U);XE_NP_Np2DualSdCatalogInfo i=info();owner(which);
        uint32_t before=reads,write_before=writes;
        frame(9U,3U);assert(send()==2U && reads==before && writes==write_before && u32(reply+20U)==1U);
        frame(10U,4U);put32(request+16U,i.token);put32(request+20U,i.count);assert(send()==2U && reads==before);
        deletion(i,5U);assert(send()==2U && !xe_np_np2_dual_sd_app_mailbox.command && reads==before);
        reset_model();append(0U,3U,0U);i=info();deletion(i,6U);assert(!send());
        owner(which);before=reads;write_before=writes;
        command(); /* Actual foreground executor; do not advance unrelated modeled recording services. */
        assert(!xe_np_np2_dual_sd_app_mailbox.command && xe_np_np2_dual_sd_app_mailbox.command_error && reads==before && writes==write_before);
        uint32_t fault=xe_np_np2_dual_sd_app_mailbox.command_error;assert(!send() && u32(reply+24U)==fault && reads==before);
    }
    reset_model();append(0U,3U,0U);
    static const uint32_t states[]={0U,2U,3U,4U,6U,255U};
    for(unsigned k=0U;k<sizeof(states)/sizeof(states[0]);k++){
        xe_np_np2_dual_sd_app_mailbox.state=states[k];uint32_t before=reads;
        frame(9U,10U);assert(send() && reads==before);
    }
    for(unsigned k=0U;k<sizeof(states)/sizeof(states[0]);k++){
        reset_model();append(0U,3U,0U);XE_NP_Np2DualSdCatalogInfo i=info();
        deletion(i,10U);assert(!send());xe_np_np2_dual_sd_app_mailbox.state=states[k];uint32_t before=reads;
        XE_NP_Np2DualSdApp_Service();
        assert(!xe_np_np2_dual_sd_app_mailbox.command && xe_np_np2_dual_sd_app_mailbox.command_error==9U && reads==before);
    }
    reset_model();append(0U,3U,0U);
    frame(5U,11U);put32(request+16U,2U);assert(!send());uint32_t before=reads;
    frame(9U,12U);assert(send()==2U && reads==before);XE_NP_Np2SdControl_CancelMode();
    xe_np_np2_dual_sd_app_mailbox.command=XE_NP_NP2_DUAL_SD_CMD_MOUNT;
    frame(9U,13U);assert(send()==2U && reads==before);
    puts("PASS 71 physical/software owner fences before any SD I/O at admission and execution, active/unmounted states and pending mode/command");
}
static void errors_and_cache(void)
{
    reset_model();append(0U,3U,0U);XE_NP_Np2DualSdCatalogInfo i=info();
    uint8_t valid[64];memcpy(valid,request,sizeof(valid));
    for(unsigned at=0U;at<5U;at++){
        static const unsigned offsets[]={0U,4U,12U,60U,63U};
        memcpy(request,valid,sizeof(valid));request[offsets[at]]^=1U;
        uint32_t before=reads;assert(XE_NP_Np2SdControl_Exchange(request,reply)<0 && reads==before);
    }
    for(uint32_t op=9U;op<=11U;op++){
        frame(op,20U+op);request[op==9U?16U:op==10U?28U:44U]=1U;
        uint32_t before=reads;assert(send()==1U && reads==before && u32(reply+20U)==1U && u32(reply+48U)==CAPACITY);
    }
    frame(10U,40U);put32(request+16U,i.token^1U);put32(request+20U,i.count);assert(send()==9U);
    frame(10U,41U);put32(request+16U,i.token);put32(request+20U,i.count);put32(request+24U,i.count);assert(send()==3U);
    deletion(i,42U);put32(request+40U,0U);uint32_t before=reads;assert(send()==3U && reads==before);
    deletion(i,43U);put32(request+36U,i.last_cookie^1U);assert(send()==9U && !xe_np_np2_dual_sd_app_mailbox.command);
    failed_read=i.last_start+3U;frame(9U,44U);assert(send()==10U && u32(reply+20U)==1U);failed_read=UINT32_MAX;
    uint32_t remounted;assert(!XE_NP_Np2DualSdCatalogPort_Mount(&remounted));
    i=info();sector(i.last_start+3U)[400]^=1U;
    frame(10U,45U);put32(request+16U,i.token);put32(request+20U,i.count);assert(send()==9U);
    reset_model();append(0U,3U,0U);i=info();deletion(i,50U);assert(!send());
    sector(i.last_start+4U)[400]^=1U;before=writes;command();
    assert(xe_np_np2_dual_sd_app_mailbox.command_error && writes==before);
    reset_model();append(0U,3U,0U);i=info();append(1U,3U,0U);
    frame(10U,51U);put32(request+16U,i.token);put32(request+20U,i.count);assert(send()==9U);
    i=info();deletion(i,52U);assert(!send());append(2U,3U,0U);before=writes;command();
    assert(xe_np_np2_dual_sd_app_mailbox.command_error==9U && writes==before);
    reset_model();append(0U,3U,1U);i=info();assert(i.flags==XE_NP_NP2_CATALOG_FULL);
    deletion(i,53U);assert(!send());command();assert(!xe_np_np2_dual_sd_app_mailbox.command_error && info().count==0U);
    reset_model();append(0U,3U,0U);i=info();sector(i.last_start+4U)[400]^=1U;
    i=info();assert(i.flags==XE_NP_NP2_CATALOG_DEGRADED);entry(i,0U);assert(!(u32(reply+56U)&XE_NP_NP2_CATALOG_DELETE_ALLOWED));
    deletion(i,54U);before=writes;assert(send()==8U && writes==before);
    /* A damaged directory fence with intact metadata stages the known
     * allocation, not healthy empty/free space or an unnecessary rewind. */
    reset_model();append(0U,3U,0U);i=info();put32(sector(128U)+4U,8193U);
    before=writes;frame(9U,55U);
    assert(!send() && u32(reply+24U)==i.count && u32(reply+28U)==i.next &&
        u32(reply+52U)==i.last_end && u32(reply+40U)==XE_NP_NP2_CATALOG_DEGRADED && writes==before);
    puts("PASS reserved/envelope validation, STATUS errors, stale token/cookie/count, I/O, mutation invalidation, execution revalidation, FULL deletion and recovery refusal");
}
static void power_cuts(void)
{
    for(uint32_t count=1U;count<=64U;count+=63U)for(uint32_t stage=1U;stage<=4U;stage++)for(uint32_t after=0U;after<=1U;after++){
        reset_model();for(uint32_t n=0U;n<count;n++)append(n,3U,0U);
        XE_NP_Np2DualSdCatalogInfo i=info();deletion(i,60U);assert(!send());
        uint32_t cmds=commands,before=writes;delete_only=1U;failed_write=before+stage;fail_after=after;command();
        assert(xe_np_np2_dual_sd_app_mailbox.command_error==10U && !xe_np_np2_dual_sd_app_mailbox.command && commands==cmds);
        failed_write=0U;model_card.Context=SD_CONTEXT_NONE;
        before=writes;assert(!send() && writes==before); /* Failed ACK never retries. */
        uint32_t next;assert(!XE_NP_Np2DualSdCatalogPort_Mount(&next));
        uint32_t flags=XE_NP_Np2DualSdCatalog_Status();
        if(flags&XE_NP_NP2_CATALOG_RECOVERY){
            assert(flags&XE_NP_NP2_CATALOG_RECOVERABLE);
            uint32_t unchanged=writes;
            assert(!XE_NP_Np2DualSdCatalogPort_MountAvailable(&next) && writes==unchanged);
            assert(XE_NP_Np2DualSdCatalog_Status()&XE_NP_NP2_CATALOG_RECOVERY);
            XE_NP_Np2DualSdCatalogInfo pending=info();
            assert(pending.count==(stage==1U || (stage==2U && !after)?count:count-1U) &&
                (pending.flags&XE_NP_NP2_CATALOG_RECOVERY) && writes==unchanged && commands==cmds);
            if(pending.count){entry(pending,pending.count-1U);
                assert(!(u32(reply+56U)&XE_NP_NP2_CATALOG_DELETE_ALLOWED));}
            assert(writes==unchanged); /* INFO/ENTRY must not replay the empty-page journal. */
            assert(!XE_NP_Np2DualSdCatalogPort_Recover(&next));
        }
        xe_np_np2_dual_sd_app_mailbox.next_start_lba=next;
        XE_NP_Np2DualSdCatalogInfo result=info();
        assert(result.count==(stage==1U || (stage==2U && !after)?count:count-1U));
        assert(!(result.flags&XE_NP_NP2_CATALOG_RECOVERY) && commands==cmds);
        for(uint32_t n=0U;n<result.count;n++){entry(result,n);assert(u32(reply+44U)==n+1U);}
    }
    puts("PASS 16 delete publication cuts around sole-entry and 63-entry page transition; read-only mount/explicit journal recovery; no payload write/CMD20/erase");
}
static void zero_values(void)
{
    reset_model();zero_patch(sector(128U)+4U,empty_token_crc);
    XE_NP_Np2DualSdCatalogInfo i=info();assert(i.token==0U && i.cid_crc==0U && i.count==0U);
    frame(10U,80U);put32(request+16U,0U);assert(send()==3U); /* Valid token, ordinal out of range. */
    reset_model();append(0U,3U,0U);zero_patch(sector(8195U)+400U,cookie_crc);
    i=info();assert(i.last_cookie==0U && i.cid_crc==0U);entry(i,0U);assert(u32(reply+40U)==0U);
    puts("PASS actual zero-valued token, cookie and CID CRC via linear CRC patches; frozen 15-word LE formulas");
}
static void sealed_metadata_fingerprint(void)
{
    reset_model();append(0U,3U,0U);XE_NP_Np2DualSdCatalogInfo before=info();
    deletion(before,90U);assert(!send()); /* Snapshot queued before a valid metadata edit. */
    uint8_t *descriptor=sector(8195U),*footer=sector(8196U);
    uint32_t residue=XE_NP_Np2DualSd_Crc32(descriptor,512U);
    assert(residue==0x2144DF1CU && XE_NP_Np2DualSd_Crc32(footer,512U)==residue);
    put32(descriptor+12U,2U);put32(descriptor+508U,XE_NP_Np2DualSd_Crc32(descriptor,508U));
    put32(footer+12U,2U);put32(footer+508U,XE_NP_Np2DualSd_Crc32(footer,508U));
    uint32_t writes_before=writes;command();
    assert(!xe_np_np2_dual_sd_app_mailbox.command && xe_np_np2_dual_sd_app_mailbox.command_error==9U && writes==writes_before);
    assert(!send() && writes==writes_before && u32(reply+24U)==9U); /* Receipt replay never requeues. */
    XE_NP_Np2DualSdCatalogInfo after=info();entry(after,0U);
    assert(u32(reply+44U)==2U && (u32(reply+56U)&XE_NP_NP2_CATALOG_METADATA_VALID));
    assert(after.token!=before.token && after.last_cookie!=before.last_cookie &&
        after.count==before.count && after.last_start==before.last_start && after.last_end==before.last_end &&
        XE_NP_Np2DualSd_Crc32(descriptor,512U)==residue && XE_NP_Np2DualSd_Crc32(footer,512U)==residue);
    assert(after.last_cookie==cookie_crc()); /* Independent explicit first508-byte formula. */
    deletion(before,91U);assert(send()==9U && !xe_np_np2_dual_sd_app_mailbox.command && writes==writes_before);
    frame(10U,92U);put32(request+16U,before.token);put32(request+20U,before.count);assert(send()==9U);
    puts("PASS corrected first508-byte fingerprint: CRC-valid re-sealed same-extent metadata changes cookie/token; stale ENTRY/DELETE and already-queued DELETE refuse without writes/replay; full512 residue remains2144DF1C");
}

static void incomplete_read_only(void)
{
    for(uint32_t version=11U;version<=14U;version++)for(uint32_t state=1U;state<=4U;state+=3U){
        reset_model();uint8_t configuration[2048]={0},reserved_footer[512];
        XE_NP_Np2DualSdMeta m;
        uint32_t crc=XE_NP_Np2DualSd_Crc32(configuration,sizeof(configuration));
        if(version==11U)assert(!XE_NP_Np2DualSdCatalogPort_PlanProfile(3U,20000U,16U,700U,crc,&m));
        else if(version==12U)assert(!XE_NP_Np2DualSdCatalog_PlanAuProfile(3U,20000U,16U,700U,crc,16384U,&m));
        else assert(!XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(3U,20000U,16U,700U,crc,16384U,&m));
        if(version==14U){
            assert(!XE_NP_Np2DualSdCatalogPort_ReserveAppend(&m,configuration));
            memcpy(reserved_footer,sector(m.reservation_start_lba+4U),512U);
            const XE_NP_Np2SdAppendCounts gap={8U,4U,12U};
            assert(!XE_NP_Np2DualSdCatalogPort_FinishAppend(4U,9U,&gap));
        }else{
            assert(!XE_NP_Np2DualSdCatalogPort_Reserve(&m,configuration));
            memcpy(reserved_footer,sector(m.reservation_start_lba+4U),512U);
            assert(!XE_NP_Np2DualSdCatalogPort_Finish(4U,9U,8U));
        }
        /* Model an intact RESERVED footer from a prior interrupted boot, not
         * an active reservation/loan. Directory retains its whole allocation. */
        if(state==1U)memcpy(sector(m.reservation_start_lba+4U),reserved_footer,512U);
        uint32_t next;assert(!XE_NP_Np2DualSdCatalogPort_MountAvailable(&next));
        xe_np_np2_dual_sd_app_mailbox.next_start_lba=next;
        XE_NP_Np2DualSdCatalogInfo i=info();assert(i.count==1U);
        entry(i,0U);uint32_t flags=u32(reply+56U);
        assert((flags&255U)==version && ((flags>>8U)&255U)==state &&
            (flags&XE_NP_NP2_CATALOG_METADATA_VALID) && (flags&XE_NP_NP2_CATALOG_INCOMPLETE) &&
            !(flags&XE_NP_NP2_CATALOG_DELETE_ALLOWED) && i.last_end==m.reservation_end_lba);
        deletion(i,200U);uint32_t before=writes,cmds=commands;
        memcpy(reserved_footer,sector(m.reservation_start_lba+4U),512U);
        assert(send()==8U && writes==before && commands==cmds && !xe_np_np2_dual_sd_app_mailbox.command);
        assert(!memcmp(sector(m.reservation_start_lba+4U),reserved_footer,512U));
    }
    puts("PASS actual v11/v12/v13/v14 RESERVED/FAILED directory entries visible but read-only; full unused allocation retained");
}
static void terminal_catalog_refresh(void)
{
    for(uint32_t append_mode=0U;append_mode<=1U;append_mode++)for(uint32_t cancelled=0U;cancelled<=1U;cancelled++){
        reset_model();uint8_t configuration[2048]={0};uint32_t crc=XE_NP_Np2DualSd_Crc32(configuration,2048U);
        assert(!XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(3U,30000U,16U,801U,crc,16384U,&reservation));
        if(append_mode)assert(!XE_NP_Np2DualSdCatalogPort_ReserveAppend(&reservation,configuration));
        else assert(!XE_NP_Np2DualSdCatalogPort_Reserve(&reservation,configuration));
        reservation_append=(uint8_t)append_mode;append_writer_bound=(uint8_t)append_mode;
        model_counts.physical_blocks=model_counts.logical_prefix_blocks=model_counts.logical_high_water_blocks=8U;
        started=1U;finished=0U;stop_pending=1U;
        xe_np_np2_dual_sd_app_mailbox.sample_hz=30000U;
        xe_np_np2_live_sd_mailbox.written_rus=2U;xe_np_np2_live_sd_mailbox.verified_blocks=8U;
        xe_np_np2_live_sd_mailbox.target_blocks=8U;xe_np_np2_live_sd_mailbox.state=XE_NP_NP2_LIVE_SD_COMPLETE;
        terminal(cancelled?4U:3U,cancelled?8U:0U);
        assert(!started && !stop_pending && !xe_np_np2_dual_sd_app_mailbox.error &&
            xe_np_np2_dual_sd_app_mailbox.state==(cancelled?7U:5U));
        XE_NP_Np2DualSdCatalogInfo i=info();entry(i,0U);
        assert(i.count==1U && i.last_start==reservation.reservation_start_lba &&
            (u32(reply+56U)&255U)==(append_mode?14U:13U) &&
            i.next==((i.last_end+8191U)&~8191U));
        uint32_t expected_end=cancelled?reservation.reservation_end_lba:reservation.run.payload_start_lba+8U*91U;
        assert(i.last_end==expected_end && ((u32(reply+56U)&XE_NP_NP2_CATALOG_DELETE_ALLOWED)!=0U)==!cancelled);
    }
    puts("PASS actual legacy/v14 terminal Complete/Stop finalization then fresh physical INFO/ENTRY count/frontier");
}
static void unsafe_empty_and_rewind_surface(void)
{
    reset_model();append(0U,3U,0U);XE_NP_Np2DualSdCatalogInfo i=info();
    sector(16U)[0]^=1U;uint32_t before=writes;frame(9U,300U);
    assert(send()==10U && writes==before && !xe_np_np2_dual_sd_app_mailbox.command);
    reset_model();append(0U,3U,0U);i=info();
    /* A cache that previously held records cannot turn an unprovable physical
     * directory into a healthy empty response on Refresh. */
    put32(sector(128U),64U);before=writes;frame(9U,301U);
    assert(!send() && !u32(reply+24U) && u32(reply+28U)==8192U && writes==before &&
        u32(reply+40U)==PREFIX_FLAGS);
    reset_model();append(0U,3U,0U);i=info();
    frame(12U,302U);put32(request+16U,XE_NP_NP2_CATALOG_REWIND_KEY);
    put32(request+20U,i.next);put32(request+24U,CAPACITY);
    uint32_t rewind_error=send();
    assert((rewind_error==2U || rewind_error==4U) && !xe_np_np2_dual_sd_app_mailbox.command);
    /* APP660 has no op12; the separate current-source candidate refuses it. */
    frame(9U,1U);assert(!send()); /* Catalog reads do not consume mutation IDs. */
    frame(1U,303U);put32(request+16U,3U);put32(request+20U,20000U);assert(!send());
    frame(1U,302U);put32(request+16U,3U);put32(request+20U,20000U);assert(send()==6U);
    puts("PASS unknown bounds never healthy empty; op12 unsupported/refused and independent read/mutation ID surface");
}
static void read_only_snapshot(uint32_t count,uint32_t next,uint32_t flags)
{
    uint32_t before=writes,cmds=commands,prior_sectors=used;
    uint32_t media_crc=XE_NP_Np2DualSd_Crc32((const uint8_t *)media,prior_sectors*(uint32_t)sizeof(media[0]));
    XE_NP_Np2DualSdCatalogInfo i=info(),again=info();
    assert(!memcmp(&i,&again,sizeof(i)) && i.count==count && i.next==next && i.flags==flags);
#if NP_BLE_CATALOG_NO_WIRE_REWIND
    frame(0U,503U);assert(!send() && !(u32(reply+52U)&XE_NP_NP2_CATALOG_REWIND_AVAILABLE));
#endif
    uint32_t previous=8192U;
    for(uint32_t ordinal=0U;ordinal<count;ordinal++){
        entry(i,ordinal);uint32_t entry_flags=u32(reply+56U);
        assert(u32(reply+32U)==previous && (entry_flags&XE_NP_NP2_CATALOG_METADATA_VALID) &&
            !(entry_flags&XE_NP_NP2_CATALOG_DELETE_ALLOWED));
        assert(((entry_flags&XE_NP_NP2_CATALOG_LAST)!=0U)==(ordinal==count-1U));
        previous=(u32(reply+36U)+8191U)&~8191U;
    }
    assert(previous==next);
    if(!count){
        assert(i.last_ordinal==UINT32_MAX && !i.last_start && !i.last_end && !i.last_cookie);
        frame(10U,501U);put32(request+16U,i.token);assert(send()==3U);
    }
    deletion(i,502U);assert(send()==8U && !xe_np_np2_dual_sd_app_mailbox.command);
    assert(writes==before && commands==cmds &&
        media_crc==XE_NP_Np2DualSd_Crc32((const uint8_t *)media,prior_sectors*(uint32_t)sizeof(media[0])));
}
static void degraded_and_rewind_listing(void)
{
    /* Keep one valid prefix entry and a v14 FAILED tail whose physical
     * directory still has the older header fence. INFO stages its whole
     * known allocation without publishing quarantine or changing the footer. */
    reset_model();append(0U,3U,0U);uint8_t configuration[2048]={0};XE_NP_Np2DualSdMeta m;
    assert(!XE_NP_Np2DualSdCatalog_PlanLegacyAuProfile(3U,20000U,16U,901U,
        XE_NP_Np2DualSd_Crc32(configuration,sizeof(configuration)),16384U,&m));
    assert(!XE_NP_Np2DualSdCatalogPort_ReserveAppend(&m,configuration));
    const XE_NP_Np2SdAppendCounts gap={8U,4U,12U};
    assert(!XE_NP_Np2DualSdCatalogPort_FinishAppend(4U,9U,&gap));
    put32(sector(128U)+8U,m.run.payload_start_lba);put32(sector(128U)+260U,m.run.payload_start_lba);
    xe_np_np2_dual_sd_app_mailbox.state=5U;
    read_only_snapshot(2U,(m.reservation_end_lba+8191U)&~8191U,XE_NP_NP2_CATALOG_DEGRADED);
    XE_NP_Np2DualSdCatalogInfo i=info();entry(i,1U);
    assert((u32(reply+56U)&65535U)==(14U|(4U<<8U)) &&
        (u32(reply+56U)&XE_NP_NP2_CATALOG_INCOMPLETE) && u32(reply+36U)==m.reservation_end_lba);

    /* An unknown final allocation may expose only the coherent readable
     * prefix, including empty and a full63-entry preceding page. No hunt,
     * implicit Recover/Rewind, mutation permission or fabricated free space. */
    static const uint32_t counts[]={0U,1U,63U,64U};
    for(unsigned n=0U;n<sizeof(counts)/sizeof(counts[0]);n++){
        reset_model();uint32_t count=counts[n];
        for(uint32_t ordinal=0U;ordinal<count;ordinal++)append(ordinal,3U,0U);
        uint32_t offered=xe_np_np2_dual_sd_app_mailbox.next_start_lba;
        append(count,3U,0U);uint32_t tail=info().last_start;
        sector(tail+3U)[508]^=1U;sector(tail+4U)[508]^=1U;
        xe_np_np2_dual_sd_app_mailbox.state=5U;
        read_only_snapshot(count,offered,PREFIX_FLAGS);
    }
    puts("PASS actual stopped B9 INFO/ENTRY: stable read-only v14 known-allocation overlay and zero/1/63/64-entry rewind prefixes; contiguous next geometry, delete disabled, all prior sectors/CMD20 unchanged");
}
static void foreign_media_read_only(void)
{
    reset_model();memcpy(sector(16U)+32U,"NP_CE64_1",9U);
    /* Small synthetic finalized v8 metadata admitted by the existing strict
     * camera-tail validator; this does not claim camera payload validation. */
    for(uint32_t footer=0U;footer<=1U;footer++){
        uint8_t *b=sector(8195U+footer);memset(b,0,512U);
        memcpy(b,footer?"NPSDEND1":"NPSDLOG1",8U);
        put32(b+8U,8U);put32(b+12U,91U);put32(b+20U,1U);
        put32(b+32U,15360U);put32(b+36U,128U);put32(b+40U,8192U);
        put32(b+44U,CAPACITY);put32(b+48U,8192U);put32(b+60U,footer?3U:1U);
        put32(b+68U,footer?8U:0U);put32(b+80U,2U);put32(b+96U,61632U);
        put32(b+112U,50U);put32(b+116U,200000U);put32(b+120U,1U);
        memcpy(b+128U,"NPMEDX1",8U);put32(b+136U,1U);put32(b+140U,footer?28U:24U);
        put32(b+168U,50U);put32(b+220U,200000U);
        if(footer){put32(b+172U,1U);put32(b+176U,1U);put32(b+180U,1U);
            put32(b+184U,1U);put32(b+228U,1U);put32(b+236U,1U);}
        put32(b+508U,XE_NP_Np2DualSd_Crc32(b,508U));
    }
    put32(sector(128U),1U);put32(sector(128U)+4U,17408U);put32(sector(128U)+256U,17408U);
    uint32_t before=writes;XE_NP_Np2DualSdCatalogInfo i=info();entry(i,0U);
    assert(i.count==1U && !i.flags && i.next==24576U && i.last_end==17408U &&
        u32(reply+56U)==(8U|(3U<<8U)|XE_NP_NP2_CATALOG_METADATA_VALID|XE_NP_NP2_CATALOG_LAST));
    deletion(i,401U);assert(send()==8U && writes==before && !xe_np_np2_dual_sd_app_mailbox.command);
    puts("PASS shared-card finalized foreign v8 listed read-only, no relabel/delete or metadata writes");
}
#endif
int main(void)
{
    model_card.Instance=SDMMC1;model_card.State=HAL_SD_STATE_READY;
    model_card.SdCard.LogBlockNbr=CAPACITY;model_card.SdCard.CardType=CARD_SDHC_SDXC;
#if XE_NP_NP2_SD_CATALOG_ENABLE
    zero_patch((uint8_t *)&model_cid[3],cid_crc);
#endif
    memcpy(model_card.CID,model_cid,sizeof(model_cid));
    assert(!XE_NP_Np2DualSdApp_Init(&model_card,&model_cache));reset_model();
    assert(XE_NP_NP2_DUAL_SD_CMD_REWIND==6U && XE_NP_NP2_DUAL_SD_CMD_DELETE_LAST==7U);
    assert(sizeof(XE_NP_Np2DualSdAppMailbox)==104U && offsetof(XE_NP_Np2DualSdAppMailbox,writer_verified_blocks)==100U);
    frame(0U,1U);assert(!send());
#if XE_NP_NP2_SD_CATALOG_ENABLE
    assert(u32(reply+52U)&XE_NP_NP2_SD_CAP_CATALOG);
    list_delete();owners();errors_and_cache();power_cuts();zero_values();sealed_metadata_fingerprint();
    incomplete_read_only();terminal_catalog_refresh();unsafe_empty_and_rewind_surface();
    foreign_media_read_only();degraded_and_rewind_listing();
#else
    assert(!(u32(reply+52U)&XE_NP_NP2_SD_CAP_CATALOG));
    append(0U,3U,0U);uint32_t before=reads;
    for(uint32_t op=9U;op<=11U;op++){frame(op,op);assert(send()==4U && reads==before && !xe_np_np2_dual_sd_app_mailbox.command);}
    puts("PASS compile-default OFF: bit22 absent, ops9/10/11 unsupported before I/O, unchanged104-byte mailbox");
#endif
    return 0;
}
