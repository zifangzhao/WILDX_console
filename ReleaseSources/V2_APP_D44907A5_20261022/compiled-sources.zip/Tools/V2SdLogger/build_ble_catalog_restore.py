"""Enable stopped BLE catalog on exact APP660 objects; no hardware or GUI build."""
import json
from pathlib import Path
import re
import struct
import subprocess
import sys
import zlib

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT/'Tools/V2Usb'), str(ROOT/'Tools/Power')]
from build_usb_rate_fix import BIN, digest, relink
from build_sd_dual20_window1536 import ram_map, sections, semantic_vectors, vector_order

WORK = ROOT/'_artifacts/v2_ble_catalog_restore_20261022'
BASE = ROOT/'_artifacts/v2_sd_copied_counted_window_20261021/app-append-pipeline16-ready-first-r1'
UNITS = ('xe_np_np2_sd_control', 'xe_np_np2_dual_sd_catalog',
         'xe_np_np2_dual_sd_catalog_port', 'xe_np_np2_dual_sd_app')
BODY = '81BEA00F23F856948484AB72D4CF99843CA5BE1C59B3EE35E3FE276C772A863F'


def main():
    out = WORK/'build'
    if out.exists():
        raise ValueError('One fresh four-unit build only; inspect failures before retry')
    freeze = json.loads((WORK/'freeze-receipt.json').read_text())
    parent = json.loads((BASE/'incremental-build.json').read_text())
    if parent['body_crc32'] != '660A6DA4' or digest(BASE/'application.bin') != BODY:
        raise ValueError('Exact checked APP660 required')
    link = (BASE/'application.lnp').read_text()
    objects = re.findall(r'(?m)^"([^"\r\n]+\.o)"\r?$', link)
    frozen = {p:digest(p) for p in objects}
    known = dict(parent['reused_checked_object_sha256'])
    writer, = [p for p in objects if Path(p).stem=='xe_np_np2_live_sd']
    known[writer] = parent['writer_sha256']
    if len(objects) != 63 or len(frozen) != 63 or any(known.get(p) != h for p,h in frozen.items()):
        raise ValueError('Exact63-object checked graph required')
    source_inputs = dict(freeze['frozen_dependency_sha256'])
    source_inputs.update({freeze['source_paths'][u]:freeze['source_sha256'][u] for u in UNITS})
    if any(digest(p) != h for p,h in source_inputs.items()):
        raise ValueError('Frozen compile input changed')
    native = WORK/'native-enabled-r4'
    native_off = WORK/'native'
    evidence = json.loads((native/'source-inputs.json').read_text(encoding='utf-8-sig'))
    tested = {x['path'].replace('\\','/'):x['sha256'] for x in evidence}
    if any(tested.get(Path(freeze['source_paths'][u]).as_posix()) != freeze['source_sha256'][u]
           for u in UNITS) or 'PASS' not in (native/'capability1/run.log').read_text() or \
            'PASS' not in (native_off/'capability0/run.log').read_text():
        raise ValueError('Matching focused OFF/ON native regression required before build')
    out.mkdir()
    replacements, flags_by_unit = {}, {}
    for unit in UNITS:
        flags = freeze['compiler_args_by_unit'][unit][:]
        if '-O3' not in flags or any(x.startswith('-DXE_NP_NP2_SD_CATALOG_ENABLE=') for x in flags):
            raise ValueError('Original O3 unit flags plus one catalog opt-in required')
        flags.append('-DXE_NP_NP2_SD_CATALOG_ENABLE=1U')
        flags_by_unit[unit] = flags
        original, = [p for p in objects if Path(p).stem == unit]
        obj = out/(unit+'.o')
        run = subprocess.run([str(BIN/'armclang.exe'), *flags, freeze['source_paths'][unit],
                              '-o', str(obj)], cwd=ROOT/'MDK-ARM', capture_output=True, text=True, timeout=60)
        (out/(unit+'.compile.log')).write_text(run.stdout+run.stderr)
        if run.returncode:
            raise RuntimeError('Inspect failed unit log: '+unit)
        link = link.replace('"'+original+'"','"'+obj.as_posix()+'"')
        replacements[original] = dict(path=str(obj), sha256=digest(obj))
    image = relink(link,out,'application')
    body = image.with_suffix('.bin').read_bytes()
    old_map, mapped = (BASE/'application.map').read_text(), image.with_suffix('.map').read_text()
    old_sections = {Path(p).name:sections(Path(p)) for p in objects}
    new_sections = dict(old_sections)
    for old,entry in replacements.items():
        new_sections[Path(old).name] = sections(Path(entry['path']))
    a,old_symbols,old_rows = ram_map(old_map,old_sections)
    b,new_symbols,new_rows = ram_map(mapped,new_sections)
    if [(n,p,m) for n,p,_,m in a] != [(n,p,m) for n,p,_,m in b]:
        raise ValueError('Fourteen RAM reservations must stay bounded and unchanged')
    ordinary = {r[4] for r in old_rows if r[3]=='STACK' or r[3].startswith(('.data','.bss'))}
    if [r for r in old_rows if r[4] not in ordinary] != [r for r in new_rows if r[4] not in ordinary]:
        raise ValueError('Capture/record/DMA/NOINIT memory changed')
    stack, = [r for r in new_symbols if r['name']=='Stack_Mem' and r['object']=='startup_stm32u595xx.o']
    mailbox, = [r for r in new_symbols if r['name']=='xe_np_np2_dual_sd_app_mailbox']
    sp,entry = struct.unpack_from('<II',body)
    if (stack['bytes']!=8192 or sp!=stack['address']+8192 or sp&7 or
            mailbox['address']!=0x200BE1C0 or mailbox['bytes']!=104 or
            not entry&1 or not 0x08020000 <= (entry&~1) < 0x08020000+len(body) <= 0x0817E000):
        raise ValueError('APP vector/stack/104-byte mailbox contract changed')
    adjusted,n = re.subn(r'(?m)^(\s+__initial_sp\s+)0x[0-9a-f]+(\s+Data\s+0\s+startup_stm32u595xx.o\(STACK\))',
                        lambda m:m[1]+f'0x{sp:08x}'+m[2],old_map)
    if n!=1:
        raise ValueError('Unambiguous baseline stack vector required')
    baseline = (BASE/'application.bin').read_bytes()
    startup, = [Path(p) for p in objects if Path(p).stem=='startup_stm32u595xx']
    vectors = semantic_vectors(vector_order(startup),struct.pack('<I',sp)+baseline[4:],adjusted,body,mapped)
    vectors['original_initial_sp'] = struct.unpack_from('<I',baseline)[0]
    for symbol in ('XE_NP_Np2DualSdCatalog_Info','XE_NP_Np2DualSdCatalog_Entry',
                   'XE_NP_Np2DualSdCatalogPort_Info','XE_NP_Np2DualSdCatalogPort_Entry',
                   'XE_NP_Np2DualSdApp_CatalogReady'):
        if not re.search(r'(?m)^\s+'+symbol+r'\s+0x',mapped):
            raise ValueError('Required compiled catalog handler absent: '+symbol)
    if any(digest(p)!=h for p,h in {**source_inputs,**frozen}.items()):
        raise ValueError('Input changed during single build')
    result = dict(role='APP',parent_crc32='660A6DA4',baseline_body_sha256=BODY,
        body_crc32=f'{zlib.crc32(body):08X}',body_sha256=digest(image.with_suffix('.bin')),body_bytes=len(body),
        rebuilt_units=UNITS,compiler_args_by_unit=flags_by_unit,source_inputs=source_inputs,
        frozen_object_sha256=frozen,replaced_objects=replacements,
        reused_checked_object_sha256={p:h for p,h in frozen.items() if p not in replacements},
        freeze_receipt_sha256=digest(WORK/'freeze-receipt.json'),
        native_evidence={str(p):digest(p) for p in (native/'source-inputs.json',native_off/'capability0/run.log',native/'capability1/run.log')},
        vector_semantics=vectors,ram_reservations=14,stack_bytes=8192,mailbox_bytes=104,
        ordinary_ram_growth=sum(s for n,p,s,m in b if n in ordinary)-sum(s for n,p,s,m in a if n in ordinary),
        catalog_capability_bit=22,catalog_info_flags_mask='048F0000',capture_writer_ble_objects_unchanged=True,
        hardware_validated=False,new_recording_qualified=False,published=False)
    (out/'incremental-build.json').write_text(json.dumps(result,indent=2)+'\n')
    print('PASS APP'+result['body_crc32']+': four catalog units once,59 checked objects retained;14 RAM regions/148 vectors, no hardware')


if __name__=='__main__':
    main()
