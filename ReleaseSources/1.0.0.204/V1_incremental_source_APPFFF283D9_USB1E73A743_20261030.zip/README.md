# V1 incremental production source archive

This archive preserves the exact five changed production C units and their 426 unique resolved source/dependency files for APP FFF283D9 and USB 1E73A743. `mapping.json` maps every original absolute path to its archive entry and SHA-256; numbered entries avoid Windows extraction path-length collisions.

Production compiler arguments, generated dependency files, link responses, static-fit receipts and sealed component identities are under `metadata/`. The component manifest and acceptance sidecars bind these sources to the qualified USB60 and SD30 artifacts.

This is an incremental source/dependency archive, not a complete historical clean-build source tree. Retained RTC and other unchanged linked objects retain their recorded identities and recipes; their historical source/dependency closure is not asserted. No dirty Git revision is used as proof. Compiler-provided and third-party headers retain their original contents and notices.

No object files, firmware binaries/HEX, debug/maps, device backups/options, recordings or recursively collected trees are included. This archive is for repository/ReleaseSources publication only; it is outside the installer and firmware-update allowlists.
