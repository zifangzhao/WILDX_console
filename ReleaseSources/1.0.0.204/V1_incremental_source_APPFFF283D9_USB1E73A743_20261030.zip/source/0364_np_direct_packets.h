#ifndef NP_DIRECT_PACKETS_H
#define NP_DIRECT_PACKETS_H
#include <stddef.h>
#include <stdint.h>

/* Metadata-only scatter planner. Production callbacks build DMA nodes; this
 * function never dereferences a source or copies live capture bytes. Preserve
 * the existing format, or the paired 8-byte header / 504-byte payload.
 */
#define NP_DIRECT_LANES 4U
#ifndef NP_DIRECT_GROUPS
#define NP_DIRECT_GROUPS 14U
#endif
#define NP_DIRECT_PAYLOAD 506U
#define NP_DIRECT_PACKET 512U
#define NP_DIRECT_HEADER 6U
#define NP_DIRECT_LANE_BYTES (NP_DIRECT_GROUPS * NP_DIRECT_PAYLOAD)
#define NP_DIRECT_WIRE_BYTES (NP_DIRECT_GROUPS * NP_DIRECT_LANES * NP_DIRECT_PACKET)
#define NP_DIRECT_MAX_NODES (NP_DIRECT_GROUPS * NP_DIRECT_LANES + NP_DIRECT_LANES)

typedef int (*NpDirectEmit)(void *context, const uint8_t *src, uint8_t *dst, uint32_t bytes);

/* The generic SD helper deliberately accepts no more than eight descriptors.
 * Direct USB scatter needs one payload node per packet plus a
 * possible wrap split per lane, while retaining the same STM32U5 CLLR and
 * 64-KiB link-bank checks. */
static inline int NpDirectChainValid(const void *storage, unsigned count, uint32_t address)
{
    const uint32_t (*nodes)[9] = (const uint32_t (*)[9])storage;
    if (!storage || !count || count > NP_DIRECT_MAX_NODES || (address & 3U) ||
        (address >> 16) != ((address + count * 36U - 1U) >> 16)) return 0;
    for (unsigned n = 0; n < count; ++n) {
        uint32_t expected = n + 1U < count ?
            0xf8010000U | ((address + (n + 1U) * 36U) & 0xfffcU) : 0U;
        if (nodes[n][5] != expected) return 0;
    }
    return 1;
}

/* Optional O(n) finalizer for HAL-built, static GPDMA linear nodes. The HAL
 * tail-insertion API rescans the whole list for each packet (O(n squared)).
 * Only CLLR is changed, and only after checking all node types and the bank.
 * Caller must own an idle list and publish its HAL queue metadata afterward.
 */
static inline int NpDirectLinkStatic(void *storage, unsigned count, uint32_t address)
{
    uint32_t (*nodes)[9] = (uint32_t (*)[9])storage;
    if (!storage || !count || count > NP_DIRECT_MAX_NODES || (address & 3U) ||
        address > UINT32_MAX - count * 36U ||
        (address >> 16) != ((address + count * 36U - 1U) >> 16)) return 0;
    for (unsigned n = 0; n < count; ++n)
        if (nodes[n][8] != 0x521U) return 0; /* GPDMA linear, CLLR index5. */
    for (unsigned n = 0; n < count; ++n)
        nodes[n][5] = n + 1U < count ?
            0xf8010000U | ((address + (n + 1U) * 36U) & 0xfffcU) : 0U;
    return 1;
}

static inline int NpDirectVisitFormat(const uint8_t *const source[4][2],
    const uint16_t sizes[4][2], const uint8_t counts[4], uint8_t *destination,
    uint32_t capacity, NpDirectEmit emit, void *context, uint32_t *emitted, unsigned stride, int paired)
{
    uintptr_t d = (uintptr_t)destination;
    uint32_t nodes = 0;
    const unsigned output_stride=paired?2U:1U;
    const unsigned payload=paired?504U:NP_DIRECT_PAYLOAD;
    const unsigned samples=payload/output_stride;
    const unsigned header=NP_DIRECT_PACKET-payload;
    if (emitted) *emitted = 0;
    if ((paired && stride!=2U) || (stride!=1U && stride!=2U) || !source || !sizes || !counts || !destination || !emit || !emitted ||
        (d & 31U) || capacity < NP_DIRECT_WIRE_BYTES ||
        d > UINTPTR_MAX - NP_DIRECT_WIRE_BYTES) return -1;
    /* Validate the complete claim before invoking even the first callback. */
    for (unsigned lane = 0; lane < 4; ++lane) {
        uint32_t total = 0;
        if (!counts[lane] || counts[lane] > 2) return -1;
        for (unsigned segment = 0; segment < counts[lane]; ++segment) {
            uintptr_t s = (uintptr_t)source[lane][segment];
            uint32_t n = sizes[lane][segment];
            if (!s || !n || (paired && (s & 3U)) || ((s | n) & 1U) || s > UINTPTR_MAX - n*stride ||
                (s < d + NP_DIRECT_WIRE_BYTES && d < s + n*stride)) return -1;
            total += n;
        }
        if (total != NP_DIRECT_GROUPS*samples) return -1;
    }
    for (unsigned lane = 0; lane < 4; ++lane) {
        unsigned segment = 0;
        uint32_t used = 0;
        for (unsigned group = 0; group < NP_DIRECT_GROUPS; ++group) {
            uint8_t *dst = destination + (group * 4U + lane) * NP_DIRECT_PACKET + header;
            uint32_t remaining = samples;
            while (remaining) {
                if (used == sizes[lane][segment]) { ++segment; used = 0; }
                if (segment >= counts[lane] || nodes == NP_DIRECT_MAX_NODES) return -1;
                uint32_t bytes = sizes[lane][segment] - used;
                if (bytes > remaining) bytes = remaining;
                if (emit(context, source[lane][segment] + used*stride, dst, bytes*output_stride)) return -2;
                ++nodes; used += bytes; dst += bytes*output_stride; remaining -= bytes;
            }
        }
    }
    *emitted = nodes;
    return 0;
}
static inline int NpDirectVisitStride(const uint8_t *const source[4][2],
    const uint16_t sizes[4][2], const uint8_t counts[4], uint8_t *destination,
    uint32_t capacity, NpDirectEmit emit, void *context, uint32_t *emitted, unsigned stride)
{
    return NpDirectVisitFormat(source,sizes,counts,destination,capacity,emit,context,emitted,stride,0);
}
static inline int NpDirectVisit(const uint8_t *const source[4][2],
    const uint16_t sizes[4][2], const uint8_t counts[4], uint8_t *destination,
    uint32_t capacity, NpDirectEmit emit, void *context, uint32_t *emitted)
{
    return NpDirectVisitStride(source,sizes,counts,destination,capacity,emit,context,emitted,1U);
}
#endif
