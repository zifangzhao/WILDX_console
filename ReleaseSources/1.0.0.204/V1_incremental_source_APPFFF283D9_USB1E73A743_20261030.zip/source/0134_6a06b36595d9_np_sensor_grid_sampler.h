#ifndef NP_SENSOR_GRID_SAMPLER_H
#define NP_SENSOR_GRID_SAMPLER_H
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/app_grid_r7_source/xe_np_sensors_port/Inc/np_sensor_grid.h"
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/app_grid_racefix_incremental_r2/np_sensor_grid_timer/0ae611fcfc94_np_sensor_grid_clock.h"

/* One producer; owner provides a monotonic, HSE-derived counter and a coherent
 * cache copy. The owner must also prove that the copied cache represents the
 * scheduled edge; a short service window alone does not establish that fact.
 * No physical edge/phase or sensor freshness is inferred here. */
typedef uint32_t (*NpSensorGridCounter)(void *context);
typedef int (*NpSensorGridCopy)(void *context,XE_NP_SensorSnapshot *out);

/* Return 1 for a published slot, 0 for an early/missing/overflow slot, -1 for
 * invalid state or clock discontinuity. Both timer reads and the cache copy
 * must finish within max_lateness_ticks of the scheduled slot. Counter reads
 * must be monotonic and less than 2^31 ticks apart; owner retires on reset. */
static inline int np_sensor_grid_sample(NpSensorGrid *g,NpSensorGridClock *clock,
    NpSensorGridCounter counter,NpSensorGridCopy copy,void *context)
{
    XE_NP_SensorSnapshot snapshot;
    uint64_t ordinal;
    if(!g || !clock || !counter || !copy)return -1;
    uint32_t before=counter(context);
    int admitted=np_sensor_grid_clock_observe(clock,before,&ordinal);
    if(admitted<=0)return admitted;
    const uint32_t deadline=clock->next_tick-clock->period_ticks;
    int copied=copy(context,&snapshot);
    uint32_t after=counter(context),elapsed=after-before;
    if(elapsed>=0x80000000U){clock->missing++;clock->active=0U;return -1;}
    clock->last_tick=after; /* Next IRQ must not move behind the completed copy. */
    if(!copied || (uint32_t)(after-deadline)>clock->max_lateness_ticks){
        clock->missing++;return 0;
    }
    int pushed=np_sensor_grid_push(g,&snapshot,ordinal);
    if(pushed<=0){clock->missing++;if(pushed<0)clock->active=0U;}
    return pushed;
}
#endif
