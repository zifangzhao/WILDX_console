#ifndef NP_SD_TRANSACTION_H
#define NP_SD_TRANSACTION_H
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/app_grid_r7_source/xe_np_app/closure/_artifacts/v1_ble_compact_preview_20261025/app_source/Core/Inc/np_sd_log.h"
#ifndef NP_TX_UNIT
#define NP_TX_UNIT 8U
#endif
#ifndef NP_TX_PRIME_CHUNKS
#define NP_TX_PRIME_CHUNKS 16U
#endif
_Static_assert(NP_TX_UNIT==1U || NP_TX_UNIT==8U,"Invalid ownership unit");
_Static_assert(NP_TX_PRIME_CHUNKS==4U || NP_TX_PRIME_CHUNKS==8U || NP_TX_PRIME_CHUNKS==16U,"Invalid command priming");
static inline unsigned np_tx_initial(uint32_t chunks)
{return chunks<NP_TX_PRIME_CHUNKS?(unsigned)chunks:NP_TX_PRIME_CHUNKS;}

/* Finite card transaction over the real CE64 staging FIFO. RAM retirement is
 * deliberately separate from card commitment. No descriptor or data pointer
 * is inferred from a slot after retirement: that slot may already be reused. */
typedef struct {
    uint32_t active, chunks, published, retired, sequence, lba, started_ms;
} NpSdTransaction;

static inline int np_tx_ready(const NpSdLog *s,unsigned offset)
{
    if(s->fault || offset+NP_TX_UNIT>s->count)return 0;
    for(unsigned n=0;n<NP_TX_UNIT;n++)
        if(s->slots[(s->head+offset+n)&(NP_SD_SLOTS-1U)].state!=NP_SD_READY)return 0;
    return 1;
}
static inline int np_tx_begin(NpSdLog *s,NpSdTransaction *t,uint32_t chunks,uint32_t now)
{
    if(t->active || s->fault || s->writing!=NP_SD_NONE || !chunks || (chunks&7U) ||
       chunks>128U || (s->state!=NP_SD_RUNNING && s->state!=NP_SD_DRAINING))return -1;
    unsigned initial=np_tx_initial(chunks);
    for(unsigned n=0;n<initial;n+=NP_TX_UNIT)if(!np_tx_ready(s,n))return -1;
    uint32_t lba=s->slots[s->head].lba;
    if(lba>s->config.end_lba || chunks>(s->config.end_lba-lba)/NP_SD_CHUNK_SECTORS ||
       s->slots[s->head].sequence!=s->committed_chunks)return np_sd_fail(s,NP_SD_PROTOCOL);
    memset(t,0,sizeof(*t));t->active=1;t->chunks=chunks;t->lba=lba;
    t->sequence=s->committed_chunks;t->started_ms=now;
    s->writing=s->head; /* active sentinel only; never dereference for ownership */
    s->drain_sequence=t->sequence+chunks;
    return 0;
}
static inline int np_tx_next(const NpSdLog *s,const NpSdTransaction *t)
{
    if(!t->active || s->fault || t->published==t->chunks || t->published-t->retired>=16U)return -1;
    unsigned offset=t->published-t->retired;
    return np_tx_ready(s,offset)?(int)((s->head+offset)&(NP_SD_SLOTS-1U)):-1;
}
static inline int np_tx_publish(NpSdLog *s,NpSdTransaction *t,unsigned slot)
{
    if(np_tx_next(s,t)!=(int)slot)return np_sd_fail(s,NP_SD_PROTOCOL);
    for(unsigned n=0;n<NP_TX_UNIT;n++) {
        NpSdSlot *p=&s->slots[(slot+n)&(NP_SD_SLOTS-1U)];
        if(p->sequence!=t->sequence+t->published+n ||
           p->lba!=t->lba+(t->published+n)*NP_SD_CHUNK_SECTORS)return np_sd_fail(s,NP_SD_PROTOCOL);
    }
    for(unsigned n=0;n<NP_TX_UNIT;n++)s->slots[(slot+n)&(NP_SD_SLOTS-1U)].state=NP_SD_WRITING;
    t->published+=NP_TX_UNIT;return 0;
}
/* Call once per ownership unit (one chunk or an eight-chunk RU), with a
 * monotonic hardware consumed count. Free physical storage only on success. */
static inline int np_tx_retire(NpSdLog *s,NpSdTransaction *t,uint32_t consumed)
{
    if(!t->active || s->fault || consumed<t->retired || consumed>t->published)
        return np_sd_fail(s,NP_SD_PROTOCOL);
    if(consumed-t->retired<NP_TX_UNIT)return -1;
    unsigned slot=s->head;
    for(unsigned n=0;n<NP_TX_UNIT;n++) {
        const NpSdSlot *p=&s->slots[(slot+n)&(NP_SD_SLOTS-1U)];
        if(p->state!=NP_SD_WRITING || p->sequence!=t->sequence+t->retired+n)
            return np_sd_fail(s,NP_SD_PROTOCOL);
    }
    for(unsigned n=0;n<NP_TX_UNIT;n++)s->slots[(slot+n)&(NP_SD_SLOTS-1U)].state=NP_SD_FREE;
    s->head=(uint8_t)((s->head+NP_TX_UNIT)&(NP_SD_SLOTS-1U));s->count-=NP_TX_UNIT;
    t->retired+=NP_TX_UNIT;return (int)slot;
}
static inline int np_tx_commit(NpSdLog *s,NpSdTransaction *t,int dataend,int card_ready,uint32_t now)
{
    if(!t->active || s->fault || !dataend || !card_ready ||
       t->published!=t->chunks || t->retired!=t->chunks || s->committed_chunks!=t->sequence)
        return np_sd_fail(s,NP_SD_PROTOCOL);
    uint32_t elapsed=now-t->started_ms;
    if(elapsed>=s->config.write_timeout_ms)return np_sd_fail(s,NP_SD_TIMEOUT);
    if(elapsed>s->max_write_ms)s->max_write_ms=elapsed;
    s->total_write_ms+=elapsed;s->committed_chunks+=t->chunks;
    s->writing=NP_SD_NONE;s->drain_sequence=0;t->active=0;
    if(s->state==NP_SD_DRAINING && !s->count)s->state=NP_SD_COMPLETE;
    return 0;
}
static inline int np_tx_deadlines(NpSdLog *s,const NpSdTransaction *t,uint32_t now)
{
    if(s->fault)return -1;
    if((s->staging<NP_SD_SLOTS && now-s->slots[s->staging].started_ms>=s->config.stage_timeout_ms) ||
       (t->active && now-t->started_ms>=s->config.write_timeout_ms))return np_sd_fail(s,NP_SD_TIMEOUT);
    return 0;
}
#endif
