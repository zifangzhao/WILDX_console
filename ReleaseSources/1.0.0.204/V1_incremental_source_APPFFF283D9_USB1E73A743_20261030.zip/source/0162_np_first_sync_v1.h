#ifndef NP_FIRST_SYNC_V1_H
#define NP_FIRST_SYNC_V1_H
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/usb_grid_r7_source/xe_np_app/Inc/np_first_sync_wire.h"

/* Completed private bytes only. The owner selects the layout-specific reader
 * once; this helper neither borrows a live ring nor retains its context. */
typedef uint8_t (*NpFirstV1Byte)(const void *,uint32_t);
typedef struct {
    NpFirstV1Byte read;
    const void *context;
    uint32_t ticks,limit,reads,failed;
} NpFirstV1Reader;
static inline uint8_t np_first_v1_byte(NpFirstV1Reader *r,uint32_t at)
{
    if(r->failed)return 0U;
    if(at>=r->ticks || r->reads>=r->limit){r->failed=1U;return 0U;}
    r->reads++;return r->read(r->context,at);
}
static inline uint32_t np_first_v1_word(NpFirstV1Reader *r,uint32_t at,uint32_t bit)
{
    uint32_t value=0U;
    for(unsigned i=0U;i<10U && !r->failed;i++)
        value=(value<<1)|((np_first_v1_byte(r,at+i)>>bit)&1U);
    return value;
}
static inline int np_first_v1_frame(NpFirstV1Reader *r,uint32_t at,
                                    uint32_t sync,uint32_t fixed,uint32_t counter)
{
    uint32_t changes=0U;
    if(np_first_v1_word(r,at,0U)!=sync ||
       np_first_v1_word(r,at+20U,7U)!=fixed ||
       ((np_first_v1_word(r,at+30U,7U)<<10)|np_first_v1_word(r,at+40U,7U))!=
           (counter&UINT32_C(0xfffff)) || r->failed)return 0;
    uint8_t previous=np_first_v1_byte(r,at+10U)&1U;
    for(unsigned i=11U;i<60U && !r->failed;i++){
        uint8_t current=np_first_v1_byte(r,at+i);
        changes+=(current&1U)!=previous;previous=current&1U;
        if(i>=50U && (current&0xfeU))return 0;
    }
    return !r->failed && changes<=1U;
}
/* At most the first780 candidate positions, rolling MSB-first sync0x330.
 * Prove BOTH complete superframes and all26 expected20-bit native counters.
 * Retain CL's reset/half-epoch restrictions; never learn arbitrary framing.
 * max_reads is a hard callback limit (zero permits no reads), not CPU WCET.
 * On every failure out remains selected/pending with explicit unknowns.
 * All candidate positions with two complete superframes must be exhausted
 * before publication, so a second valid position or budget expiry fails shut. */
static inline int np_first_v1_scan(NpFirstV1Byte read,const void *context,
    uint32_t ticks,uint64_t first_tick,uint32_t max_reads,int reset_qualified,
    NpFirstSyncProbe *out,uint32_t *reads)
{
    NpFirstV1Reader r={read,context,ticks,max_reads,0U,0U};
    NpFirstSyncProbe found={NP_FIRST_SYNC_UNKNOWN_TICK,NP_FIRST_SYNC_UNKNOWN_COUNTER,
        NP_FIRST_PROBE_SELECTED,NP_FIRST_SYNC_UNKNOWN_PHASE,780U};
    uint32_t sync=0U,have=0U;
    if(reads)*reads=0U;
    if(out)*out=found;
    if(!out || !read || !max_reads || !reset_qualified || ticks<1560U ||
       first_tick>UINT64_MAX-ticks || first_tick>=UINT64_C(0x80000)*60U)return 0;
    for(unsigned i=0U;i<9U;i++)sync=(sync<<1)|(np_first_v1_byte(&r,i)&1U);
    for(uint32_t at=0U;at<780U && at<=ticks-1560U && !r.failed;at++){
        sync=((sync<<1)|(np_first_v1_byte(&r,at+9U)&1U))&0x3ffU;
        if(r.failed || sync!=0x330U)continue;
        uint32_t fixed=np_first_v1_word(&r,at+20U,7U);
        if(fixed!=0x11U && fixed!=0x22U)continue;
        uint32_t counter=(np_first_v1_word(&r,at+30U,7U)<<10)|
            np_first_v1_word(&r,at+40U,7U);
        unsigned frame;
        for(frame=0U;frame<26U && !r.failed;frame++)
            if(!np_first_v1_frame(&r,at+frame*60U,frame%13U?0xcfU:0x330U,
                                  fixed,counter+frame))break;
        if(r.failed)break;
        if(frame!=26U)continue;
        uint64_t absolute=first_tick+at;
        if(have || counter%13U || counter>=0x80000U ||
           absolute>=UINT64_C(0x80000)*60U){r.failed=1U;break;}
        found.first_tick=absolute;found.counter=counter;
        found.phase=(uint16_t)((780U-(absolute%780U))%780U);
        found.flags=NP_FIRST_PROBE_SELECTED|NP_FIRST_PROBE_FRAMED|NP_FIRST_PROBE_COUNTER|
            NP_FIRST_PROBE_PHASE|NP_FIRST_PROBE_CONTINUOUS;
        have=1U;
    }
    if(reads)*reads=r.reads;
    if(r.failed || !have)return 0;
    *out=found;return 1;
}
#endif
