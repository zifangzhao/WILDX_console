#ifndef NP_SENSOR_GRID_H
#define NP_SENSOR_GRID_H
#include "C:/Frank/Code/XE_NP/_artifacts/v1_fine_counter64_20261029/app_source/Core/Inc/xe_np_sensors.h"
#include <string.h>

/* Private ISR-to-foreground queue, not a recording/wire format. The timer
 * owner must assign the actual slot ordinal and submit only a cache snapshot
 * observed in its proven service window. Skipped ordinals remain skipped. */
/* 64 slots hold 51.2 ms at 1,250 Hz; the power-of-two ring remains O(1). */
#define NP_SENSOR_GRID_CAPACITY 64U
/* Private status bit; the NSG1 encoder maps this to its per-slot error mask. */
#define NP_SENSOR_GRID_ERROR UINT32_C(0x80000000)
#ifndef NP_SENSOR_GRID_BARRIER
#define NP_SENSOR_GRID_BARRIER() __DMB()
#endif
typedef struct {
    int32_t axes[9];
    uint32_t valid,imu_sequence,mag_sequence;
    uint64_t ordinal;
} NpSensorGridSlot;
typedef struct {
    NpSensorGridSlot slots[NP_SENSOR_GRID_CAPACITY];
    volatile uint32_t head,tail;
    uint32_t overflow,invalid_order;
    uint64_t last_ordinal;
    uint32_t have_ordinal;
} NpSensorGrid;
_Static_assert((NP_SENSOR_GRID_CAPACITY & (NP_SENSOR_GRID_CAPACITY-1U))==0U,"grid capacity must be a power of two");

/* Begin only while both producer and consumer are stopped. */
static inline void np_sensor_grid_begin(NpSensorGrid *g){memset(g,0,sizeof(*g));}
/* One ISR producer, one foreground consumer. No I2C, clock, CRC or storage. */
static inline int np_sensor_grid_push(NpSensorGrid *g,const XE_NP_SensorSnapshot *s,uint64_t ordinal)
{
    if(g->have_ordinal && ordinal<=g->last_ordinal){
        if(g->invalid_order!=UINT32_MAX)g->invalid_order++;
        return -1;
    }
    g->last_ordinal=ordinal;g->have_ordinal=1U;
    uint32_t head=g->head,tail=g->tail;NP_SENSOR_GRID_BARRIER();
    if(head-tail>=NP_SENSOR_GRID_CAPACITY){
        if(g->overflow!=UINT32_MAX)g->overflow++;
        return 0;
    }
    NpSensorGridSlot *slot=&g->slots[head&(NP_SENSOR_GRID_CAPACITY-1U)];
    memcpy(slot->axes,s->accel_micro_g,sizeof(s->accel_micro_g));
    memcpy(slot->axes+3U,s->gyro_milli_dps,sizeof(s->gyro_milli_dps));
    memcpy(slot->axes+6U,s->mag_nano_tesla,sizeof(s->mag_nano_tesla));
    slot->valid=XE_NP_Sensors_StreamMask(s)|(s->error[0]?NP_SENSOR_GRID_ERROR:0U);
    slot->imu_sequence=s->imu_sequence;slot->mag_sequence=s->mag_sequence;
    slot->ordinal=ordinal;NP_SENSOR_GRID_BARRIER();g->head=head+1U;return 1;
}
static inline int np_sensor_grid_pop(NpSensorGrid *g,NpSensorGridSlot *out)
{
    uint32_t tail=g->tail,head=g->head;NP_SENSOR_GRID_BARRIER();
    if(tail==head)return 0;
    *out=g->slots[tail&(NP_SENSOR_GRID_CAPACITY-1U)];
    NP_SENSOR_GRID_BARRIER();g->tail=tail+1U;return 1;
}
#endif
