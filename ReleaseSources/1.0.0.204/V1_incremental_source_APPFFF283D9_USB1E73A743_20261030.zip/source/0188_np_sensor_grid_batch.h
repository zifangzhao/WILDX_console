#ifndef NP_SENSOR_GRID_BATCH_H
#define NP_SENSOR_GRID_BATCH_H
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/usb_grid_r7_source/xe_np_usb_stream/Inc/np_sensor_grid.h"
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/usb_grid_r7_source/xe_np_usb_stream/Inc/np_imu_grid_wire.h"

/* Foreground single-consumer packetizer. Producer and queue must not be reset
 * during a transaction; no other code may pop this queue. The queue's head
 * snapshot bounds the transaction and keeps its unread entries immutable.
 * Producer-reported BMX errors use NP_SENSOR_GRID_ERROR; a set bit reports
 * the cached error condition, not an independently measured sampling fault. */
typedef struct {
    uint64_t next_slot, revision;
    uint32_t generation, ag_sequence, mag_sequence;
    uint8_t have_ag, have_mag;
} NpSensorGridBatchState;
typedef struct {
    NpSensorGrid *queue;
    NpSensorGridBatchState *owner;
    uint64_t revision, next_slot;
    uint32_t generation, original_tail, head, cursor, frames, ag_sequence, mag_sequence;
    uint8_t have_ag, have_mag;
} NpSensorGridBatch;

/* first_slot is the independently established capture-grid origin, not a
 * timestamp inferred from a sensor observation. Call only while stopped. */
static inline int np_sensor_grid_batch_init(NpSensorGridBatchState *s,
                                            uint32_t generation, uint64_t first_slot)
{
    if(!s || !generation || first_slot==UINT64_MAX) return 0;
    memset(s,0,sizeof(*s));s->generation=generation;s->next_slot=first_slot;return 1;
}
static inline int np_sensor_grid_batch_begin(NpSensorGrid *q, NpSensorGridBatchState *s,
                                             NpSensorGridBatch *tx)
{
    uint32_t tail,head;
    if(!q || !s || !tx || !s->generation || s->revision==UINT64_MAX) return 0;
    tail=q->tail;head=q->head;NP_SENSOR_GRID_BARRIER();
    if(head-tail>NP_SENSOR_GRID_CAPACITY) return 0;
    memset(tx,0,sizeof(*tx));tx->queue=q;tx->owner=s;tx->revision=s->revision;
    tx->generation=s->generation;tx->original_tail=tail;tx->head=head;tx->cursor=tail;
    tx->next_slot=s->next_slot;tx->ag_sequence=s->ag_sequence;tx->mag_sequence=s->mag_sequence;
    tx->have_ag=s->have_ag;tx->have_mag=s->have_mag;return 1;
}
/* Returns positive encoded bytes, 0 if snapshot has no further slots, -1 on
 * malformed/stale state. Scratch is caller-owned foreground storage. Neither
 * a successful peek nor a failure changes queue tail or committed state.
 * Success advances only tx, so repeated next calls produce distinct frames.
 * Never synthesize trailing gaps beyond the last visible queued ordinal.
 * A gap of at least one full frame is a first_slot discontinuity, avoiding
 * unbounded empty-frame production; shorter gaps remain absent mask bits. */
static inline int np_sensor_grid_batch_next(NpSensorGridBatch *tx, uint8_t *out,
    size_t capacity, int32_t scratch[NP_IMU_GRID_MAX_SLOTS][9])
{
    NpSensorGridBatch local;NpImuGridHeader h={0};size_t rows=0U,bytes;
    if(!tx || !tx->queue || !tx->owner || !out || !scratch ||
       tx->owner->revision!=tx->revision || tx->owner->generation!=tx->generation ||
       tx->queue->tail!=tx->original_tail || tx->head-tx->original_tail>NP_SENSOR_GRID_CAPACITY ||
       tx->cursor-tx->original_tail>tx->head-tx->original_tail ||
       np_imu_grid_overlap(out,capacity,scratch,NP_IMU_GRID_MAX_SLOTS*36U) ||
       np_imu_grid_overlap(out,capacity,tx,sizeof(*tx)) ||
       np_imu_grid_overlap(out,capacity,tx->queue,sizeof(*tx->queue)) ||
       np_imu_grid_overlap(out,capacity,tx->owner,sizeof(*tx->owner)) ||
       np_imu_grid_overlap(scratch,NP_IMU_GRID_MAX_SLOTS*36U,tx,sizeof(*tx)) ||
       np_imu_grid_overlap(scratch,NP_IMU_GRID_MAX_SLOTS*36U,tx->queue,sizeof(*tx->queue)) ||
       np_imu_grid_overlap(scratch,NP_IMU_GRID_MAX_SLOTS*36U,tx->owner,sizeof(*tx->owner))) return -1;
    if(tx->cursor==tx->head)return 0;
    if(tx->frames==UINT32_MAX)return -1;
    local=*tx;h.first_slot=local.next_slot;h.capture_generation=local.generation;
    {
        uint64_t next=local.queue->slots[local.cursor&(NP_SENSOR_GRID_CAPACITY-1U)].ordinal;
        if(next<h.first_slot)return -1;
        if(next-h.first_slot>=NP_IMU_GRID_MAX_SLOTS)h.first_slot=next;
    }
    for(unsigned i=0U;i<NP_IMU_GRID_MAX_SLOTS && local.cursor!=local.head;i++){
        NpSensorGridSlot entry=local.queue->slots[local.cursor&(NP_SENSOR_GRID_CAPACITY-1U)];
        uint64_t ordinal;
        if(h.first_slot>UINT64_MAX-(uint64_t)i-1U)return -1;
        ordinal=h.first_slot+i;
        if(entry.ordinal<ordinal)return -1;
        h.slot_count=(uint16_t)(i+1U);
        if(entry.ordinal!=ordinal)continue;
        uint16_t bit=(uint16_t)(1U<<i);
        h.observed_mask|=bit;
        memcpy(scratch[rows++],entry.axes,sizeof(entry.axes));
        if(entry.valid&NP_SENSOR_GRID_ERROR)h.error_mask|=bit;
        if(entry.valid&XE_NP_SENSOR_VALID_AG){
            h.ag_valid|=bit;
            if(local.have_ag && local.ag_sequence==entry.imu_sequence)h.ag_repeat|=bit;
            local.ag_sequence=entry.imu_sequence;local.have_ag=1U;
        }
        if(entry.valid&XE_NP_SENSOR_VALID_MAG){
            h.mag_valid|=bit;
            if(local.have_mag && local.mag_sequence==entry.mag_sequence)h.mag_repeat|=bit;
            local.mag_sequence=entry.mag_sequence;local.have_mag=1U;
        }
        local.cursor++;
    }
    if(!h.slot_count)return -1;
    bytes=np_imu_grid_pack(out,capacity,&h,(const int32_t (*)[9])scratch,rows);
    if(!bytes)return -1;
    local.next_slot=h.first_slot+h.slot_count;local.frames++;
    *tx=local;return (int)bytes;
}
/* Commit the entire staged prefix only once after sink publication. This is
 * O(1), so it may execute in the queue's existing short publication guard. */
static inline int np_sensor_grid_batch_commit(NpSensorGridBatch *tx, uint32_t frame_count)
{
    NpSensorGridBatchState *s;
    if(!tx || !tx->owner || !tx->queue || !frame_count || frame_count!=tx->frames ||
       tx->owner->revision!=tx->revision || tx->owner->generation!=tx->generation ||
       tx->queue->tail!=tx->original_tail || tx->cursor-tx->original_tail>tx->head-tx->original_tail)
        return 0;
    s=tx->owner;s->next_slot=tx->next_slot;s->ag_sequence=tx->ag_sequence;s->mag_sequence=tx->mag_sequence;
    s->have_ag=tx->have_ag;s->have_mag=tx->have_mag;s->revision++;
    NP_SENSOR_GRID_BARRIER();tx->queue->tail=tx->cursor;tx->owner=NULL;return 1;
}
#endif
