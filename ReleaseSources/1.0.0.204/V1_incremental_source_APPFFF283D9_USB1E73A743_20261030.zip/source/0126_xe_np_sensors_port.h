#ifndef XE_NP_SENSORS_PORT_H
#define XE_NP_SENSORS_PORT_H
#include "C:/Frank/Code/XE_NP/_artifacts/v1_ble_compact_preview_20261025/app_source/Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal.h"
#include "C:/Frank/Code/XE_NP/_artifacts/v1_rtc_20261029/app_source/Core/Inc/xe_np_sensors.h"
void XE_NP_SensorsPort_Init(I2C_HandleTypeDef *imu,I2C_HandleTypeDef *environment);
void XE_NP_SensorsPort_Service(uint8_t recording_active);
int XE_NP_SensorsPort_Complete(I2C_HandleTypeDef *,uint32_t error);
const XE_NP_SensorSnapshot *XE_NP_SensorsPort_GetSnapshot(void);
/* Opt-in only while the grid timer owns TIM6; legacy publication is default. */
void XE_NP_SensorsPort_GridGuard(int enabled);
void XE_NP_SensorsPort_RecordBegin(void);
#if defined(NP_FIRST_SYNC_ENABLE) && NP_FIRST_SYNC_ENABLE
/* New-client opt-in only. No legacy runtime or wire-format change. */
void XE_NP_SensorsPort_RecordWaitForNp(void);
void XE_NP_SensorsPort_RecordReleaseAfterNp(uint32_t release_ms);
void XE_NP_SensorsPort_RecordLegacy(void);
void XE_NP_SensorsPort_RecordFallback(void);
#endif
void XE_NP_SensorsPort_RecordEnd(void);
uint32_t XE_NP_SensorsPort_RecordFault(void);
const XE_NP_SensorSnapshot *XE_NP_SensorsPort_RecordSnapshot(void);
/* USB has four observation slots per 10 ms batch. Unlike the SD latest-value
 * path, consume them in order and report genuine observation-queue overflow. */
const XE_NP_SensorSnapshot *XE_NP_SensorsPort_RecordOrderedSnapshot(void);
uint32_t XE_NP_SensorsPort_RecordOverflow(void);
/* SWD-visible copy: atomic index into two foreground-published buffers. */
extern XE_NP_SensorSnapshot xe_np_sensor_snapshot[2];
extern volatile uint32_t xe_np_sensor_snapshot_index;
extern XE_NP_SensorFault xe_np_sensor_fault[2];
#endif
