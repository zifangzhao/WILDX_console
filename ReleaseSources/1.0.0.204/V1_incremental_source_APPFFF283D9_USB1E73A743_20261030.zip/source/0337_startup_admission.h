#ifndef NP_STARTUP_ADMISSION_H
#define NP_STARTUP_ADMISSION_H
#include <stdint.h>
#include <string.h>
/* Startup only. Never called by capture DMA or the streaming exporter. */
typedef struct {
    volatile uint32_t state,requested,accepted,rejected,released;
    volatile uint32_t reason[3],error[3],hal[3];
} NP_StartupAdmission;
static inline void np_admission_begin(NP_StartupAdmission *a,uint32_t mask) {
    memset(a,0,sizeof(*a));a->requested=mask;a->accepted=mask;
    a->state=(mask && !(mask&~7U))?1U:3U;
}
static inline int np_admission_reject(NP_StartupAdmission *a,uint32_t port,
                                    uint32_t reason,uint32_t hal,uint32_t error) {
    if(a->state!=1U || port>2U || !(a->accepted&(1U<<port)))return -1;
    a->accepted&=~(1U<<port);a->rejected|=1U<<port;
    a->reason[port]=reason;a->hal[port]=hal;a->error[port]=error;
    if(!a->accepted)a->state=3U;
    return a->accepted?1:0;
}
static inline int np_admission_ready(NP_StartupAdmission *a) {
    if(a->state!=1U || !a->accepted)return -1;
    a->state=2U;return 0;
}
static inline int np_admission_release(NP_StartupAdmission *a,uint32_t session,uint32_t actual) {
    if(a->state!=2U || !a->accepted || !session || session!=actual)return -1;
    a->released=1U;return 0;
}
#endif
