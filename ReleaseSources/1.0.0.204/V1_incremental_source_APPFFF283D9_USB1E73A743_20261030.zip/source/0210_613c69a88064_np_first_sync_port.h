#ifndef NP_FIRST_SYNC_PORT_H
#define NP_FIRST_SYNC_PORT_H
#ifndef NP_FIRST_SYNC_ENABLE
#define NP_FIRST_SYNC_ENABLE 0
#endif
#if NP_FIRST_SYNC_ENABLE
#include "C:/Frank/Code/XE_NP/_artifacts/v1_rtc_20261029/usb_source/Core/Inc/np_cl_source.h"
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/usb_grid_r7_source/xe_np_app/Inc/np_capture_start_diag.h"
enum { NP_FIRST_SD8=1U,NP_FIRST_USB8=2U,NP_FIRST_USB16=3U };
enum { NP_FIRST_REJECT_UNKNOWN=1U,NP_FIRST_REJECT_COMMIT=2U,
       NP_FIRST_REJECT_PRIVATE=3U,NP_FIRST_REJECT_CLOCK=4U,
       NP_FIRST_REJECT_CANCEL=5U,NP_FIRST_REJECT_FINAL=6U,
       NP_FIRST_REJECT_OBSERVE=7U };
/* New-client policy owns Enable. No existing client calls it. */
void NP_FirstCaptureEnable(int enabled);
void NP_FirstCaptureStart(uint32_t session,uint32_t layout);
#if defined(NP_SENSOR_GRID_ENABLE) && NP_SENSOR_GRID_ENABLE
/* Set by the selected transport while idle, before capture admission. */
void NP_FirstCaptureGridMode(int enabled);
#endif
int NP_FirstCaptureClockWanted(void); /* Final startup only; no sample-path use. */
/* A reset write withdraws any old pre-DMA assertion proof; it is not pad-low
 * evidence. The existing settled START_CAPTURE boundary observes actual low. */
void NP_FirstCaptureResetWrite(void);
void NP_FirstCaptureResetAssert(uint32_t low);
void NP_FirstCaptureResetRelease(uint32_t high,uint32_t now);
void NP_FirstCaptureResetAdmission(void);
void NP_FirstCaptureResetArm(uint32_t generation);
void NP_FirstCaptureResetStop(void);
void NP_FirstCaptureResetPsbProbe(void);
void NP_FirstCaptureLoss(void);
void NP_FirstCaptureLossReason(uint32_t reason);
/* One rejection per owner: reason (published last), revision, reset stage,
 * capture generation, final generation, source epoch, pending mask, flags. */
extern volatile uint32_t np_first_sync_reject_diag[8];
#if NP_SD_APP
/* Internal APP CPU-trace layout v1, 16x32-bit words, NOT a wire record or an
 * ARM address contract. version is published last; zero means no snapshot. */
enum { NP_FIRST_FINAL_DIAG_VERSION=1U,
       NP_FIRST_FINAL_ANCHOR_PRESENT=1U,NP_FIRST_FINAL_ANCHOR_VALID=2U,
       NP_FIRST_FINAL_GENERATION_KNOWN=4U,NP_FIRST_FINAL_RESET_TOKEN_KNOWN=8U };
enum { NP_FIRST_FD_VERSION,NP_FIRST_FD_KNOWN,NP_FIRST_FD_REVISION,
       NP_FIRST_FD_FINAL_GENERATION,NP_FIRST_FD_ANCHOR_GENERATION,
       NP_FIRST_FD_ANCHOR_HZ,NP_FIRST_FD_ANCHOR_FLAGS,NP_FIRST_FD_EXPECTED_HZ,
       NP_FIRST_FD_RESET_STAGE,NP_FIRST_FD_RESET_TOKEN,NP_FIRST_FD_RESET_GENERATION,
       NP_FIRST_FD_RESET_ADMISSION,NP_FIRST_FD_ACTIVE,NP_FIRST_FD_PENDING,
       NP_FIRST_FD_SOURCE_EPOCH,NP_FIRST_FD_SOURCE_FACTS,NP_FIRST_FD_WORDS };
/* ANCHOR_VALID means cached NPAR ROOT|SOURCE validity, not STARTBYTE proof.
 * source facts: bit0 valid, bit1 seeded, bit2 lost, bit3 record sealed.
 * Nonzero final generation is actual admitted evidence, never a guessed ID. */
extern volatile uint32_t np_first_final_diag[NP_FIRST_FD_WORDS];
/* Same64B storage, version3 observes the first startup guard rejection
 * BEFORE invalidate; after-state is not observed or inferred. Only an active
 * pre-FINAL owner is eligible. SOURCE_FACTS bit4 means the observed token/
 * profile/stage identify its live reset witness; otherwise this is an already
 * absent/invalid witness, NOT a proven first clear. All raw zero values are
 * observed values, not UNKNOWN substitutes. Version1 is the fallback if no
 * guard rejection was captured.
 * Args: ASSERT(low,0), ASSERT_WRITE(0,1), RELEASE(high,now), ADMISSION(seeded,0),
 * ARM(generation,seeded), STOP(seeded,0), PSB(seeded,lost). No GPIO reread. */
enum { NP_FIRST_CLEAR_DIAG_VERSION=3U,NP_FIRST_CLEAR_ASSERT=NP_CL_RESET_SITE_ASSERT,
       NP_FIRST_CLEAR_RELEASE=NP_CL_RESET_SITE_RELEASE,NP_FIRST_CLEAR_ADMISSION=NP_CL_RESET_SITE_ADMISSION,
       NP_FIRST_CLEAR_ARM=NP_CL_RESET_SITE_ARM,NP_FIRST_CLEAR_STOP=NP_CL_RESET_SITE_STOP,
       NP_FIRST_CLEAR_PSB=NP_CL_RESET_SITE_PSB };
enum { NP_FIRST_GUARD_LIVE_WITNESS=16U };
enum { NP_FIRST_CD_VERSION,NP_FIRST_CD_EVENT,NP_FIRST_CD_ARG0,NP_FIRST_CD_ARG1,
       NP_FIRST_CD_BEFORE_STAGE,NP_FIRST_CD_BEFORE_TOKEN,NP_FIRST_CD_BEFORE_GENERATION,
       NP_FIRST_CD_BEFORE_ADMISSION,NP_FIRST_CD_RELEASE_MS,NP_FIRST_CD_LAST_MS,
       NP_FIRST_CD_WINDOW_CLOSED,NP_FIRST_CD_SOURCE_FACTS,NP_FIRST_CD_FINAL_GENERATION,
       NP_FIRST_CD_ACTIVE,NP_FIRST_CD_PENDING,NP_FIRST_CD_REVISION,NP_FIRST_CD_WORDS };
#endif
void NP_FirstCaptureStop(void);
void NP_FirstCaptureService(void);
void NP_FirstCaptureBegin(NpClSourceReceipt *,uint32_t mask,uint32_t ticks);
void NP_FirstCaptureCommit(const NpClSourceReceipt *);
void NP_FirstCapturePrivate(const uint8_t *,uint32_t bytes,const NpClSourceReceipt *);
/* A foreground caller supplies the exact snapshot already accepted by its
 * archive/USB queue, not the current live cache. No pointer is retained. */
void NP_FirstCaptureSensor(const void *snapshot,uint32_t ms,uint32_t cycles);
/* Caller must have retained the first actual slot in the private queue;
 * transport delivery is not implied and must be checked by the host. */
int NP_FirstCaptureGridAccepted(uint64_t ordinal,uint32_t ms,uint32_t cycles,
    uint32_t domain,uint32_t hz,uint32_t generation);
void NP_FirstCaptureStageSensor(const uint8_t record[164],uint32_t record_sequence,uint32_t publication_key);
void NP_FirstCapturePublished(uint32_t publication_key);
int NP_FirstCaptureFrozen(uint8_t out[328]);
void NP_FirstCaptureContext(uint32_t out[4]);
#endif
#endif
