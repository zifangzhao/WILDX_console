#ifndef NP_USB_CAPTURE_MODES_H
#define NP_USB_CAPTURE_MODES_H
#include <stdint.h>
#include "np_usb20_release.h"
/* These are admitted implementation modes, not a hardware qualification list. */
static inline int np_mode_valid(uint32_t mask,uint32_t hz) {
    if(!mask && !hz)return 1; /* camera-only */
    return mask>=1U && mask<=7U &&
        (hz==7500U || hz==15000U || (hz==30000U && mask!=7U) ||
         (hz==20000U && (mask==1U || mask==2U || mask==3U || mask==4U)));
}
extern volatile uint32_t np_mode_mask,np_mode_hz;
unsigned NP_Triple_Probe(void);
#endif
