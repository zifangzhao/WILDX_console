#ifndef XE_NP_USB_STREAM_H
#define XE_NP_USB_STREAM_H

#include "xe_np_hal.h"

#define XE_NP_USB_STREAM_VENDOR_ID 0x1209U
#define XE_NP_USB_STREAM_PRODUCT_ID 0xB386U
#define XE_NP_USB_STREAM_IN_EP 0x81U
#define XE_NP_USB_STREAM_OUT_EP 0x01U
#define XE_NP_USB_STREAM_PACKET_MAGIC 0xA512U
#define XE_NP_USB_STREAM_PACKET_VERSION 1U
#define XE_NP_USB_STREAM_HEADER_BYTES 6U
#define XE_NP_USB_STREAM_PACKET_BYTES 512U
#define XE_NP_USB_STREAM_PAYLOAD_BYTES \
    (XE_NP_USB_STREAM_PACKET_BYTES - XE_NP_USB_STREAM_HEADER_BYTES)
/*
 * Aggregate a private SRAM1 transfer before starting USB DMA.  This keeps
 * endpoint scheduling independent of the 512-byte capture producer cadence
 * while the GPIO DMA remains isolated in SRAM3.
 */
/* ~31.5 KiB is the normal USB capture aggregation size.  The paired DDR
 * exporter has its own guard-aware admission policy and must not be used as
 * the baseline 7.5 kHz recorder until its capture schedule is qualified. */
#ifndef XE_NP_USB_STREAM_PACKETS_PER_TRANSFER
#define XE_NP_USB_STREAM_PACKETS_PER_TRANSFER 63U
#endif
/* Bounded foreground reconstruction quantum for the paired 15 kHz path.
 * This is deliberately much smaller than a complete USB aggregation. */
#ifndef XE_NP_USB_STREAM_INTERLEAVED_COPY_PACKETS_PER_SERVICE
/* One complete 0->1->2->3 lane group.  Keeping the foreground SRAM3 read
 * burst at 2,024 bytes prevents the exporter from monopolising SRAM3 long
 * enough to disturb a 5.85 MHz capture lane. */
#define XE_NP_USB_STREAM_INTERLEAVED_COPY_PACKETS_PER_SERVICE 4U
#endif
#define XE_NP_USB_STREAM_TRANSFER_BYTES \
    (XE_NP_USB_STREAM_PACKET_BYTES * XE_NP_USB_STREAM_PACKETS_PER_TRANSFER)
#define XE_NP_USB_STREAM_TRANSFER_PAYLOAD_BYTES \
    (XE_NP_USB_STREAM_PAYLOAD_BYTES * XE_NP_USB_STREAM_PACKETS_PER_TRANSFER)
#define XE_NP_USB_STREAM_ID_CAMERA 3U
#define XE_NP_USB_STREAM_MASK_CAMERA (1U << 2U)
#define XE_NP_USB_STREAM_ID_NEUROPIXELS 6U
#define XE_NP_USB_STREAM_MASK_NEUROPIXELS (1U << 5U)
#define XE_NP_USB_STREAM_FLAG_PAYLOAD_LENGTH_IN_SEQUENCE 0x04U
/* Compact packet carries a contiguous physical DDR lane; clear=A, set=B. */
#define XE_NP_USB_STREAM_FLAG_INTERLEAVED_LANE_B 0x08U
#define XE_NP_USB_STREAM_FLAG_INTERLEAVED_LANES 0x20U
/* A compact interleaved record contains one of four consecutive physical
 * lanes.  The lane number is its position in the strictly consecutive USB
 * packet sequence: 0, 1, 2, 3. */
#define XE_NP_USB_STREAM_FLAG_QUAD_INTERLEAVED_LANES 0x40U
#define XE_NP_USB_STREAM_LANE_VALIDATOR_TAIL_BYTES 59U
#ifndef XE_NP_USB_STREAM_INTERLEAVED_STAGING_DMA_CHANNEL
/* Channel 14 is retained for the legacy two-lane/SD experiment.  The
 * four-lane recorder selects channel 10, leaving 12..15 entirely private to
 * the edge-triggered GPIO producers. */
#define XE_NP_USB_STREAM_INTERLEAVED_STAGING_DMA_CHANNEL 14U
#endif

typedef struct
{
    uint32_t magic;
    uint32_t version;
    uint32_t tick_ms;
    uint32_t flags;
    uint32_t configured;
    uint32_t streaming;
    uint32_t port_index;
    uint32_t tx_busy;
    uint32_t sequence;
    uint32_t packets_sent;
    uint32_t payload_bytes_low;
    uint32_t dropped_bytes_low;
    uint32_t mgr_available_bytes;
    uint32_t mgr_log_state;
    uint32_t pcd_state;
    uint32_t pcd_error;
    uint32_t last_setup;
    uint32_t last_request;
    uint32_t last_status;
    uint32_t negotiated_speed;
    uint32_t reset_count;
    uint32_t setup_count;
    uint32_t ep0_in_count;
    uint32_t ep0_out_count;
    uint32_t ep0_last_in_len;
    uint32_t ep0_last_out_count;
    uint32_t ep0_flags;
    uint32_t lane_validator_frames_seen;
    uint32_t lane_validator_first_error_flags;
    uint32_t lane_validator_first_error_packet;
    uint32_t lane_validator_first_error_payload_offset;
    uint32_t lane_validator_first_error_stream_offset_low;
    uint32_t lane_validator_lock_offset;
    uint32_t lane_validator_lock_clean_frames;
    uint32_t lane_validator_packets_checked;
    uint32_t lane_validator_tail_len;
    uint32_t lane_validator_status;
    uint32_t seam_probe_status;
    uint32_t seam_probe_packet_sequence;
    uint32_t seam_probe_compare_after_packets_sent;
    uint32_t seam_probe_ring_offset;
    uint32_t seam_probe_payload_offset;
    uint32_t seam_probe_tail_offset;
    uint32_t seam_probe_payload_bytes;
    uint32_t seam_probe_before_hash;
    uint32_t seam_probe_after_hash;
    uint32_t seam_probe_mismatch_count;
    uint32_t start_request_count;
    uint32_t start_try_count;
    uint32_t start_try_fail_count;
    uint32_t last_start_try_status;
    uint32_t disarm_count;
    uint32_t last_disarm_reason;
    uint32_t real_start_pending;
    uint32_t real_start_port_index;
    uint32_t app_capture_requested;
    uint32_t app_capture_port_index;
    uint32_t app_export_enabled;
    uint32_t app_export_port_index;
    uint32_t app_port_active;
    uint32_t app_pending_read_idx;
    uint32_t app_pending_write_idx;
    uint32_t app_usb_active_window_valid;
    uint32_t app_stable_window_valid;
    uint32_t app_active_probe_mask;
    uint32_t mco_divider;
    uint32_t expected_mclk_hz;
    uint32_t expected_psb_clk_hz;
    uint32_t mco_apply_count;
    uint32_t mco_last_apply_status;
    uint32_t otg_gintsts;
    uint32_t otg_daint;
    uint32_t otg_diepctl1;
    uint32_t otg_diepint1;
    uint32_t otg_dieptsiz1;
    uint32_t otg_dtxfsts1;
#if defined(XE_NP_APP_QUAD_USB_WORD_EXPORT) && (XE_NP_APP_QUAD_USB_WORD_EXPORT != 0U)
    /* VSR1 extension; retain all legacy version-5 offsets above. */
    uint32_t v1_recovery_magic;
    uint32_t v1_recovery_capabilities;
    uint32_t v1_session_id;
    uint32_t v1_previous_fault;
    uint32_t v1_session_reset_count;
    uint32_t v1_latched_fault;
#endif
} XE_NP_UsbStreamDiag;

void XE_NP_UsbStream_Init(PCD_HandleTypeDef *hpcd);
void XE_NP_UsbStream_Service(void);
void XE_NP_UsbStream_RearmConsumer(void);
void XE_NP_UsbStream_Stop(void);
void XE_NP_UsbStream_StagingDmaIrqHandler(void);
int XE_NP_UsbStream_IsStreaming(void);
int XE_NP_UsbStream_IsConfigured(void);
int XE_NP_UsbStream_IsSyntheticActive(void);
const volatile XE_NP_UsbStreamDiag *XE_NP_UsbStream_GetDiag(void);

#endif
