#ifndef NP_SENSOR_GRID_TIMER_H
#define NP_SENSOR_GRID_TIMER_H
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/app_grid_r7_source/xe_np_app/Inc/np_sensor_grid.h"
#include "C:/Frank/Code/XE_NP/_artifacts/v1_rtc_20261029/app_source/Core/Inc/np_v1_fine_clock.h"
#ifndef NP_SENSOR_GRID_ENFORCED
#define NP_SENSOR_GRID_ENFORCED 0
#endif
#if NP_SENSOR_GRID_ENFORCED && !NP_FINE_COUNTER64_ENABLE
#error Enforced grid requires the continuous 64-bit NP fine-counter owner
#endif
#ifndef NP_GRID_LIFETIME_DIAG
#define NP_GRID_LIFETIME_DIAG 0
#endif
#ifndef NP_GRID_STOP_DIAG
#define NP_GRID_STOP_DIAG 0
#endif
#if NP_GRID_STOP_DIAG
/* Private HIL-only, first active stop; never part of the recorded format. */
typedef struct {
    uint64_t next_ordinal,missing;
    uint32_t seen,caller,clock_active,last_tick,counter,next_tick,domain;
} NpGridStopDiagnostic;
extern volatile NpGridStopDiagnostic np_grid_stop_diag;
#endif
#if NP_GRID_LIFETIME_DIAG
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/app_grid_r7_source/xe_np_app/Inc/np_grid_lifetime_guard.h"
/* Private stopped-HIL evidence only; never a terminal or delivery claim. */
enum { NP_GRID_DIAG_OPEN=1U, NP_GRID_DIAG_CLOCK=2U, NP_GRID_DIAG_UIF=4U };
typedef struct {
    NpGridLifetimeGuard guard;
    uint64_t stop_accounted_next;
    uint32_t stop_owner,stop_domain,stop_flags;
    volatile uint32_t owner,domain,pending,fresh,bound,rejected_owner;
} NpGridLifetimeDiagnostic;
extern NpGridLifetimeDiagnostic np_grid_lifetime_diag;
int NP_GridTimerDiagArm(uint32_t owner,uint32_t domain);
/* Foreground only. Returns nonzero once this owner has been retired. */
int NP_GridTimerDiagService(const NpGridLifetimeIdentity *identity);
#endif

/* Private, opt-in timer owner. No selector advertises it until timer, cache
 * publication guard, packetizer, sinks and their lifecycle are integrated. */
typedef struct {
    NpV1FinePoint point;
    uint64_t ordinal;
    /* Legacy: one-time bound for admitted software cache copies, max of sampled
     * early latency and the per-slot admission ceiling, in 1.2 MHz ticks.
     * The separate start bracket includes timer-phase quantization. Neither
     * bounds the physical sensor's I2C conversion phase or freshness. */
    uint32_t max_lateness_ticks,start_bracket_ticks,has_slot,valid;
#if NP_SENSOR_GRID_ENFORCED
    /* Actual first successful cached-copy end (full counter), and its measured
     * before/after width. No native conversion time or HAL phase is inferred. */
    uint64_t counter64;
    uint32_t copy_ticks,enforced;
#endif
} NpGridFirstPoint;
int NP_GridTimerStart(uint32_t lateness_limit_ticks);
/* Read-only idle/owner preflight; not a recording or HIL qualification. */
int NP_GridTimerAvailable(void);
void NP_GridTimerOpen(void);
void NP_GridTimerStop(void);
int NP_GridTimerFirst(NpGridFirstPoint *out);
/* Foreground, once per session: ownership/domain check, not hardware qualification. */
int NP_GridTimerProofReady(void);
#if NP_SENSOR_GRID_ENFORCED
/* Foreground observation only; a detected fault retires grid, never NP. */
int NP_GridTimerService(void);
#endif
NpSensorGrid *NP_GridTimerQueue(void);
void TIM6_IRQHandler(void);
#endif
