#ifndef NP_V1_RTC_CONTROL_H
#define NP_V1_RTC_CONTROL_H
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/app_rtc_pending_incremental_r1/xe_np_app/cd24eca5cfda_np_v1_rtc.h"
#include "C:/Frank/Code/XE_NP/_artifacts/v1_rtc_20261029/app_source/Core/Inc/np_v1_rtc_calendar.h"
#include "C:/Frank/Code/XE_NP/_artifacts/v1_rtc_20261029/app_source/Core/Inc/xe_np_online_impl.h"
#ifndef NP_V1_RTC_CONTROL_MS
#define NP_V1_RTC_CONTROL_MS() HAL_GetTick()
#endif

/* Foreground-owned accepted mutation receipt, not a clock or a transport.
 * Pending is acceptance(error0), confirmed later by readonly provider status.
 * An accepted hardware failure(error5) is retained too: never replay a write. */
typedef struct {
    uint8_t last_request[64];
    uint32_t last_id,last_result;
} NpV1RtcControl;
static inline void np_v1_rtc_control_reset(NpV1RtcControl *c)
{if(c)memset(c,0,sizeof(*c));}

/* 0 means unhandled version/magic only. Every recognized v2 request is handled,
 * including errors; a caller must never fall back to the legacy mutation path.
 * can_commit/can_read come from the authoritative stopped/ownership adapter. */
static inline int np_v1_rtc_control_exchange(NpV1RtcControl *c,const uint8_t in[64],
    uint8_t out[64],uint32_t received_ms,uint32_t state,int can_commit,int can_read)
{
    uint8_t request[64];NpV1RtcPoint point={0};
    uint32_t op,id,error=0U,flags=0U,reply_pc_uncertainty=0U;uint64_t utc=0U;
    int duplicate=0;
    if(!in || xe_np_online_word(in)!=NP_ONLINE_REQUEST || xe_np_online_word(in+4U)!=2U)return 0;
    if(!out)return 1; /* A missing reply buffer must not authorize a mutation. */
    memcpy(request,in,sizeof(request));op=xe_np_online_word(request+8U);id=xe_np_online_word(request+12U);
    if(!c || !id || xe_np_online_word(request+60U)!=xe_np_online_crc(request))error=1U;
    for(unsigned i=36U;i<60U;i++)if(request[i])error=1U;
    if(!error && c->last_id==id){
        if(memcmp(request,c->last_request,sizeof(request)))error=6U;
        else {duplicate=1;error=c->last_result;}
    }
    if(!error && !duplicate){
        if(op==0U){for(unsigned i=16U;i<36U;i++)if(request[i])error=1U;}
        else if(op==1U){
            uint32_t reference=xe_np_online_word(request+16U),uncertainty=xe_np_online_word(request+28U);
            uint64_t epoch=(uint64_t)xe_np_online_word(request+20U)|((uint64_t)xe_np_online_word(request+24U)<<32U);
            if((uint32_t)(received_ms-reference)>10000U ||
               epoch<NP_V1_RTC_CALENDAR_FIRST_US || epoch>=NP_V1_RTC_CALENDAR_END_US ||
               uncertainty<1000U || uncertainty>500000U ||
               xe_np_online_word(request+32U)!=NP_V1Rtc_Generation())error=3U;
            else if(!can_commit || !can_read)error=2U;
            else {
                int result=NP_V1Rtc_Commit(epoch,reference,uncertainty,xe_np_online_word(request+32U));
                if(result==NP_V1_RTC_COMMIT_REJECTED)error=3U;
                else {
                    /* Any unexpected nonzero provider result is also an
                     * accepted-but-unknown failure, never a replay license. */
                    error=(result==NP_V1_RTC_COMMIT_COMPLETE || result==NP_V1_RTC_COMMIT_PENDING)?0U:5U;
                    memcpy(c->last_request,request,sizeof(request));c->last_id=id;c->last_result=error;
                }
            }
        }else error=4U;
        if(!error && op==0U && !can_read)error=2U;
    }
    if(can_read && NP_V1Rtc_Read(&point)){
        flags=point.flags&(NP_V1_RTC_HARDWARE|NP_V1_RTC_CALENDAR|NP_V1_RTC_CALIBRATED);
        if(!(flags&NP_V1_RTC_HARDWARE))flags=0U;
        else {
            flags|=16U; /* This provider's hardware source is HSE/32. */
            if(!(flags&NP_V1_RTC_CALENDAR))flags&=~NP_V1_RTC_CALIBRATED;
            else utc=point.lower_us;
            if(flags&NP_V1_RTC_CALIBRATED)reply_pc_uncertainty=point.declared_pc_uncertainty_us;
        }
    }
    if(!can_commit)flags|=8U;
    uint32_t reply_generation=NP_V1Rtc_Generation();
    /* Latch after all actual provider work: UTC is a sample inside Rx..Tx,
     * not extrapolated to Tx and not a physical BLE/USB departure timestamp. */
    uint32_t sent_ms=NP_V1_RTC_CONTROL_MS();
    const uint32_t reply[15]={NP_ONLINE_REPLY,2U,op,id,error,received_ms,sent_ms,
        reply_generation,reply_pc_uncertainty,(flags&NP_V1_RTC_CALENDAR)?1U:0U,
        (uint32_t)utc,(uint32_t)(utc>>32U),state,
        (flags&NP_V1_RTC_HARDWARE)?NP_V1_RTC_QUANTUM_US:0U,flags};
    for(unsigned i=0U;i<15U;i++)xe_np_online_put(out+4U*i,reply[i]);
    xe_np_online_put(out+60U,xe_np_online_crc(out));return 1;
}
#endif
