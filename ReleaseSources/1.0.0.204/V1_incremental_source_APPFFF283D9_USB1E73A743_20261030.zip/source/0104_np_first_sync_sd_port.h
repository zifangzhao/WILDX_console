#ifndef NP_FIRST_SYNC_SD_PORT_H
#define NP_FIRST_SYNC_SD_PORT_H
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/app_grid_r7_source/xe_np_app/Inc/np_first_sync_port.h"
#if NP_FIRST_SYNC_ENABLE
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/app_grid_r7_source/xe_np_app/closure/_artifacts/v1_rtc_20261029/app_source/Core/Inc/np_first_sync_sd.h"
int NP_FirstSdCommand(const uint8_t request[64],uint8_t reply[64]);
int NP_FirstSdSubmit(const uint8_t request[64],unsigned length);
void NP_FirstSdAdmitted(void);
void NP_FirstSdLegacyAccepted(const uint8_t request[64],const uint8_t reply[64]);
void NP_FirstSdCancelQueued(void);
uint32_t NP_FirstSdAttempt(void);
void NP_FirstSdRejectQueued(uint32_t attempt);
void NP_FirstSdStart(uint32_t session,uint32_t start,uint32_t end,uint32_t mask,uint32_t hz);
int NP_FirstSdBindClock(uint8_t sector[512],uint32_t session,uint32_t ap_hz);
int NP_FirstSdFineClock(uint8_t out[512],const uint8_t clock[512],uint32_t session,uint32_t ap_hz);
#if NP_HARDWARE_RTC_ENABLE
int NP_FirstSdRtcBody(uint8_t out[128],const uint8_t clock[512],const uint8_t companion[512]);
#endif
#endif
#endif
