#ifndef NP_SENSOR_GRID_SD_ADAPTER_H
#define NP_SENSOR_GRID_SD_ADAPTER_H
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/app_grid_r7_source/xe_np_app/Inc/np_sensor_grid_batch.h"
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/app_grid_enforced_incremental_r1/xe_np_app/f2400f22a67e_np_sensor_grid_sd.h"

/* One foreground consumer; initialize only a zeroed, new session adapter.
 * Its queue and batch state must not be reset or consumed by another owner. */
typedef struct {
    NpGridSdPhaseState phase;
    NpSensorGrid *queue;
    NpSensorGridBatchState *batch;
    uint32_t busy;
} NpGridSdAdapter;
typedef struct {
    NpGridSdAdapter *owner;
    NpSensorGridBatch batch;
    NpGridSdPhaseTxn phase;
    uint32_t valid;
} NpGridSdAdapterTxn;
typedef struct {
    NpSensorGridBatch current,previous;
    uint8_t *frame;
    int32_t (*scratch)[9];
    unsigned generated;
} NpGridSdAdapterPeek;

static inline int np_grid_sd_adapter_init(NpGridSdAdapter *a,NpSensorGrid *q,
    NpSensorGridBatchState *batch,const NpGridSdIdentity *identity)
{
    if(!a || !q || !batch || !identity || a->busy || a->phase.valid ||
       batch->generation!=identity->generation || !batch->generation ||
       np_imu_grid_overlap(a,sizeof(*a),q,sizeof(*q)) ||
       np_imu_grid_overlap(a,sizeof(*a),batch,sizeof(*batch)) ||
       np_imu_grid_overlap(a,sizeof(*a),identity,sizeof(*identity)))return 0;
    if(!np_grid_sd_phase_begin(&a->phase,identity))return 0;
    a->queue=q;a->batch=batch;return 1;
}

/* One extra frame may be peeked then rejected for lack of chunk room. Keep
 * its pre-peek checkpoint so it remains in the queue for the next stage. */
static inline int np_grid_sd_adapter_peek(void *context,unsigned index,const uint8_t **frame,size_t *bytes)
{
    NpGridSdAdapterPeek *p=(NpGridSdAdapterPeek *)context;
    if(!p || index!=p->generated)return -1;
    p->previous=p->current;
    int n=np_sensor_grid_batch_next(&p->current,p->frame,NP_IMU_GRID_MAX_BYTES,p->scratch);
    if(n<=0)return n;
    p->generated++;*frame=p->frame;*bytes=(size_t)n;return 1;
}

/* Frame buffer and row scratch are caller-owned foreground workspaces; they
 * must not overlap chunk, queue, states, txn, each other, or the NSGP bytes.
 * Returns 1 staged, -1 optional evidence failure (neural stage unaffected),
 * 0 invalid/busy arguments. Legacy recording must not call this adapter. */
static inline int np_grid_sd_adapter_stage(NpGridSdAdapter *a,uint8_t chunk[65536],
    const uint8_t *phase,size_t phase_bytes,uint8_t frame[NP_IMU_GRID_MAX_BYTES],
    int32_t scratch[NP_IMU_GRID_MAX_SLOTS][9],NpGridSdAdapterTxn *txn)
{
    NpGridSdAdapterPeek p;NpGridSdPhaseTxn staged;int result;
    if(!a || !chunk || !frame || !scratch || !txn || !a->phase.valid || !a->queue || !a->batch ||
       a->busy || a->phase.pending || a->batch->generation!=a->phase.identity.generation ||
       np_imu_grid_overlap(chunk,65536U,a,sizeof(*a)) || np_imu_grid_overlap(chunk,65536U,txn,sizeof(*txn)) ||
       np_imu_grid_overlap(chunk,65536U,a->queue,sizeof(*a->queue)) || np_imu_grid_overlap(chunk,65536U,a->batch,sizeof(*a->batch)) ||
       np_imu_grid_overlap(frame,NP_IMU_GRID_MAX_BYTES,chunk,65536U) ||
       np_imu_grid_overlap(frame,NP_IMU_GRID_MAX_BYTES,a,sizeof(*a)) ||
       np_imu_grid_overlap(frame,NP_IMU_GRID_MAX_BYTES,txn,sizeof(*txn)) ||
       np_imu_grid_overlap(frame,NP_IMU_GRID_MAX_BYTES,scratch,NP_IMU_GRID_MAX_SLOTS*36U) ||
       np_imu_grid_overlap(scratch,NP_IMU_GRID_MAX_SLOTS*36U,chunk,65536U) ||
       np_imu_grid_overlap(scratch,NP_IMU_GRID_MAX_SLOTS*36U,a,sizeof(*a)) ||
       np_imu_grid_overlap(scratch,NP_IMU_GRID_MAX_SLOTS*36U,txn,sizeof(*txn)) ||
       np_imu_grid_overlap(txn,sizeof(*txn),a,sizeof(*a)) ||
       np_imu_grid_overlap(txn,sizeof(*txn),a->queue,sizeof(*a->queue)) ||
       np_imu_grid_overlap(txn,sizeof(*txn),a->batch,sizeof(*a->batch)) ||
       (phase && (np_imu_grid_overlap(phase,phase_bytes,frame,NP_IMU_GRID_MAX_BYTES) ||
                  np_imu_grid_overlap(phase,phase_bytes,scratch,NP_IMU_GRID_MAX_SLOTS*36U))))return 0;
    memset(&p,0,sizeof(p));memset(&staged,0,sizeof(staged));
    if(!np_sensor_grid_batch_begin(a->queue,a->batch,&p.current))return -1;
    p.frame=frame;p.scratch=scratch;
    result=np_grid_sd_chunk_phase(chunk,&a->phase,phase,phase_bytes,np_grid_sd_adapter_peek,&p,&staged);
    if(result!=1)return result;
    if(staged.consumed==p.generated)p.previous=p.current;
    else if(!p.generated || staged.consumed!=p.generated-1U){
        (void)np_grid_sd_phase_finish(&a->phase,&staged,0);
        memset(chunk+NP_GRID_SD_BEGIN,0,NP_GRID_SD_CAPACITY);
        np_imu_grid_put32(chunk+NP_GRID_SD_DESCRIPTOR+124U,0U);
        np_imu_grid_put32(chunk+NP_GRID_SD_DESCRIPTOR+508U,np_grid_sd_crc(chunk+NP_GRID_SD_DESCRIPTOR,508U));
        return -1;
    }
    memset(txn,0,sizeof(*txn));txn->owner=a;txn->batch=p.previous;txn->phase=staged;txn->valid=1U;
    a->busy=1U;return 1;
}

/* Must execute under the caller's short exclusive consumer/lifecycle guard,
 * after the private chunk is accepted. The producer may only advance head.
 * Abort releases the phase reservation and changes neither queue nor batch. */
static inline int np_grid_sd_adapter_finish(NpGridSdAdapter *a,NpGridSdAdapterTxn *txn,int commit)
{
    NpSensorGridBatch *b;NpGridSdPhaseTxn *p;
    if(!a || !txn || !a->busy || !txn->valid || txn->owner!=a)return 0;
    b=&txn->batch;p=&txn->phase;
    if(!p->valid || !a->phase.valid || !a->phase.pending || a->phase.pending!=p->ticket ||
       a->phase.revision!=p->revision || !np_grid_sd_identity_equal(&a->phase.identity,&p->identity))return 0;
    if(!commit){if(!np_grid_sd_phase_finish(&a->phase,p,0))return 0;a->busy=0U;txn->valid=0U;return 1;}
    if(a->phase.revision==UINT32_MAX || !b->owner || b->owner!=a->batch || b->queue!=a->queue ||
       b->owner->revision!=b->revision || b->owner->generation!=b->generation ||
       b->queue->tail!=b->original_tail || b->cursor-b->original_tail>b->head-b->original_tail ||
       b->frames!=p->consumed)return 0;
    if(b->frames && !np_sensor_grid_batch_commit(b,b->frames))return 0;
    if(!np_grid_sd_phase_finish(&a->phase,p,1))return 0;
    a->busy=0U;txn->valid=0U;return 1;
}
#endif
