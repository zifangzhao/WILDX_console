#ifndef NP_USB20_RELEASE_H
#define NP_USB20_RELEASE_H
#include <stdint.h>

/* Selectable clock profile, NOT a recording/dual-probe qualification. */
#define NP_USB20_CORE_HZ 124800000U
#define NP_USB20_PCLK_HZ 62400000U
#define NP_USB20_EDGE 0U
#define NP_USB20_DELAY_TICKS 2U
#define NP_USB20_COOKIE 0x3155504eU /* NPU1: USB-only, BKP24..27 */

unsigned NP_USB20_Scaled(void);
unsigned NP_USB20_CameraOnly(void);
void NP_USB20_Restore(void);
void NP_USB20_QueueSelection(uint32_t mask,uint32_t hz);
unsigned NP_USB20_SelectionPending(void);
void NP_USB20_CancelSelection(void);
int NP_USB20_CommitSelection(void);

static inline uint32_t NP_USB20_CaptureDivider(uint32_t hz)
{
    return !hz?0U:hz==20000U?2U:60000U/hz;
}
#endif
