#ifndef NP_SD_CONTROL_H
#define NP_SD_CONTROL_H
#include <stdint.h>
#include <string.h>
#include "C:/Frank/Code/XE_NP/_artifacts/v1_ble_compact_preview_20261025/app_source/Core/Inc/np_modes.h"
enum {NPL_STATUS=0,NPL_SELECT=1,NPL_START=2,NPL_STOP=3,NPL_MODE=4,NPL_FORMAT=5,NPL_SCHEDULE_START=6,NPL_USB_MODE=7,NPL_MOUNT=8,NPL_RECOVER=9,NPL_GRID_SELECT=10};
enum {NPL_OK=0,NPL_FRAME=1,NPL_BUSY=2,NPL_RANGE=3,NPL_DISABLED=4,NPL_UNQUALIFIED=5,NPL_ORDER=6,NPL_IO=7};
enum {NPL_WRITES=1,NPL_QUALIFIED=2,NPL_ACTIVE=4,NPL_PENDING=8,NPL_CARD=16};
/* Known NP card with an uncertain directory/allocation: native94 browsing
 * only. NPL_CARD remains clear; START, DELETE and recovery writes stay gated. */
enum {NPL_CATALOG_READ_ONLY=0x01000000U};
/* Filesystem2 is a V1 storage layout, not the V2 board. Requests must opt in
 * using command version2, FORMAT, layout2 and a fresh64-bit format epoch. */
enum {NPL_STORE_V2=0x02000000U,NPL_STORE_V2_SELECTED=0x04000000U};
/* Capability is advertised only when the timer and storage sink are ready. */
enum {NPL_GRID_CAPABILITY=0x20000000U,NPL_GRID_SELECTED=0x40000000U};
static inline int npl_grid_select(uint32_t *selected,uint32_t value,int ready,int idle){
 if(value>1U)return NPL_RANGE;
 if(!idle)return NPL_BUSY;
 if(value && !ready)return NPL_DISABLED;
 *selected=value;return NPL_OK;
}
typedef struct {uint32_t state,fault,mask,hz,chunks,start,end,capacity,flags;} NplStatus;
typedef struct {
 void *context;
 void (*status)(void *,NplStatus *);
 int (*apply)(void *,const uint32_t *);
} NplIo;
typedef struct {NplIo io;uint32_t last_id;uint8_t last_request[64],last_reply[64];} NplControl;
int NP_SD_ControlTransferPending(void);
#if NP_FIRST_SYNC_ENABLE
/* Called only after full frame/payload and mutation-ID validation. It admits
 * ordinary STOP over one exact, still-queued NPSD STAR; it never cancels it. */
int NP_FirstSdPendingStop(const void *controller,const uint32_t *words);
#endif
static inline uint32_t npl_u32(const uint8_t *p){return p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static inline void npl_put(uint8_t *p,uint32_t v){p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);p[2]=(uint8_t)(v>>16);p[3]=(uint8_t)(v>>24);}
static inline uint32_t npl_crc(const uint8_t *p,unsigned n){uint32_t c=~0U;while(n--){c^=*p++;for(unsigned i=0;i<8;i++)c=(c>>1)^(0xedb88320U&(0U-(c&1U)));}return ~c;}
static inline unsigned npl_count(uint32_t mask){return (mask&1U)+((mask>>1)&1U)+((mask>>2)&1U);}
static inline unsigned npl_probe(uint32_t mask,uint32_t sequence){
 unsigned count=npl_count(mask);if(!count)return 0;unsigned ordinal=sequence%count;
 for(unsigned p=0;p<3;p++)if(mask&(1U<<p)){if(!ordinal--)return p+1;}return 0;
}
static inline uint32_t npl_card_rate(uint32_t mask,uint32_t hz){return hz*832U*npl_count(mask);}
/* Same transport-independent64-byte engine is used by the BLE adapter/tests.
 * All callbacks execute in foreground. STATUS never mutates recorder state.
 * Mutation IDs are monotonic modulo32 bits; exact last-command retries return
 * the cached receipt without repeating writes or START. Read last_id in STATUS
 * when opening a new client. No automatic retry of an uncertain FORMAT. */
static inline void npl_command(NplControl *c,const uint8_t request[64],uint8_t reply[64]){
 uint32_t w[16];for(unsigned i=0;i<16;i++)w[i]=npl_u32(request+4*i);
 int error=NPL_OK;NplStatus s={0};c->io.status(c->io.context,&s);
 int format2=w[1]==2U && w[2]==NPL_FORMAT;
 if(w[0]!=0x31444c4eU || (w[1]!=1U && !format2) || !w[3] || w[2]>NPL_GRID_SELECT ||
    (w[2]!=NPL_SCHEDULE_START && !format2 && (w[11] || w[12])) || w[13] || w[14] || w[15]!=npl_crc(request,60))error=NPL_FRAME;
 if(!error){
  /* Reject ignored arguments as well as malformed geometry. */
  if((w[2]==NPL_STATUS || w[2]==NPL_STOP || w[2]==NPL_MOUNT || w[2]==NPL_RECOVER) && (w[4]|w[5]|w[6]|w[7]|w[8]|w[9]|w[10]))error=NPL_FRAME;
  if(w[2]==NPL_SELECT && (!np_mode_valid(w[4],w[5]) || (w[6]|w[7]|w[8]|w[9]|w[10])))error=NPL_RANGE;
  if(w[2]==NPL_GRID_SELECT && (w[4]>1U || (w[5]|w[6]|w[7]|w[8]|w[9]|w[10])))error=NPL_RANGE;
  if((w[2]==NPL_START || w[2]==NPL_SCHEDULE_START) && (!np_mode_valid(w[4],w[5]) || !w[8] || (w[9]&~1U) || w[10] ||
      !w[7] || w[7]>s.capacity || (w[6] && w[6]<8192U)))error=NPL_RANGE;
  if(w[2]==NPL_MODE && ((w[4]|w[5]|w[6]|w[7]|w[8]|w[9]) || w[10]<2 || w[10]>4))error=NPL_RANGE;
  if(w[2]==NPL_USB_MODE && ((w[5]|w[6]|w[7]|w[8]|w[9]|w[10]) || w[4]<1 || w[4]>4))error=NPL_RANGE;
  if(w[2]==NPL_FORMAT && ((w[5]|w[6]|w[7]|w[8]|w[10]) || w[9]!=0x46524d54U ||
      (format2?(w[4]!=2U || !(w[11]|w[12])):w[4]!=0U)))error=NPL_RANGE;
 }
 if(!error && w[2]!=NPL_STATUS){
  if(c->last_id && w[3]==c->last_id){
   if(!memcmp(request,c->last_request,64)){memcpy(reply,c->last_reply,64);return;}
   error=NPL_ORDER;
  }else if(c->last_id && (uint32_t)(w[3]-c->last_id)>=0x80000000U)error=NPL_ORDER;
  if(!error && (s.flags&NPL_PENDING)){
#if NP_FIRST_SYNC_ENABLE
   if(w[2]!=NPL_STOP || !NP_FirstSdPendingStop(c,w))
#endif
    error=NPL_BUSY;
  }
  if(!error && w[2]!=NPL_STOP && (s.flags&NPL_ACTIVE))error=NPL_BUSY;
  if(!error && (w[2]==NPL_START || w[2]==NPL_SCHEDULE_START || w[2]==NPL_FORMAT || w[2]==NPL_RECOVER) && !(s.flags&NPL_WRITES))error=NPL_DISABLED;
  if(!error && format2 && !(s.flags&NPL_STORE_V2))error=NPL_DISABLED;
  if(!error)error=c->io.apply(c->io.context,w);
 }
 c->io.status(c->io.context,&s);memset(reply,0,64);
 const uint32_t words[15]={0x31524c4eU,1,w[2],w[3],(uint32_t)error,s.state,s.fault,s.mask,s.hz,s.chunks,s.start,s.end,s.capacity,s.flags,c->last_id};
 for(unsigned i=0;i<15;i++)npl_put(reply+4*i,words[i]);
 if(!error && w[2]!=NPL_STATUS){c->last_id=w[3];npl_put(reply+56,c->last_id);}
 npl_put(reply+60,npl_crc(reply,60));
 if(!error && w[2]!=NPL_STATUS){memcpy(c->last_request,request,64);memcpy(c->last_reply,reply,64);}
}
#endif
