#ifndef NP_V1_RTC_START_H
#define NP_V1_RTC_START_H
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/app_rtc_pending_incremental_r1/xe_np_app/cd24eca5cfda_np_v1_rtc.h"
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/app_grid_r7_source/xe_np_app/closure/_artifacts/v1_rtc_20261029/app_source/Core/Inc/np_rtc_start_wire.h"

/* Startup/control boundaries only. The optional cache never gates capture.
 * Begin drops the previous session; Crossstamp attempts once. Freeze needs an
 * independently valid final receipt/anchor and is immutable until next Begin. */
void NP_V1RtcStartBegin(int enabled);
void NP_V1RtcStartCrossstamp(void);
int NP_V1RtcStartFreeze(const NpRtcStartBinding *binding);
int NP_V1RtcStartRead(uint8_t out[128],const NpRtcStartBinding *binding);
#endif
