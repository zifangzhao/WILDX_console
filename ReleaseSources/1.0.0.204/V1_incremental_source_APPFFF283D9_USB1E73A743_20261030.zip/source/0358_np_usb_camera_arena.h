#ifndef NP_USB_CAMERA_ARENA_H
#define NP_USB_CAMERA_ARENA_H

#include "main.h"

#include <stdint.h>

#define NP_USB_CAMERA_WIDTH             320U
#define NP_USB_CAMERA_CAPTURE_ROWS      492U
#define NP_USB_CAMERA_LOGICAL_ROWS      500U
#define NP_USB_CAMERA_FRAME_BYTES       (NP_USB_CAMERA_WIDTH * NP_USB_CAMERA_LOGICAL_ROWS)
#define NP_USB_CAMERA_SYNC_BYTES        (NP_USB_CAMERA_CAPTURE_ROWS * 2U)
#define NP_USB_CAMERA_BUFFER_COUNT      2U
#define NP_USB_CAMERA_DMA_NODE_COUNT    3U
#define NP_USB_CAMERA_TX_PACKETS        32U
#define NP_USB_CAMERA_TX_BYTES          (NP_USB_CAMERA_TX_PACKETS * 512U)
#define NP_USB_CAMERA_SHARED_ARENA_BYTES 0x80000U

typedef struct
{
    uint8_t frame[NP_USB_CAMERA_BUFFER_COUNT][NP_USB_CAMERA_FRAME_BYTES]
        __attribute__((aligned(32)));
    uint8_t sync[NP_USB_CAMERA_SYNC_BYTES] __attribute__((aligned(32)));
    DMA_NodeTypeDef nodes[NP_USB_CAMERA_DMA_NODE_COUNT]
        __attribute__((aligned(32)));
    uint8_t tx[NP_USB_CAMERA_TX_BYTES] __attribute__((aligned(32)));
} NP_UsbCameraStorage;

/* USB download and camera capture are different boot personalities.  Overlay
 * their large buffers so optional video costs no additional physical SRAM. */
typedef union
{
    uint8_t download[NP_USB_CAMERA_SHARED_ARENA_BYTES];
    NP_UsbCameraStorage camera;
} NP_UsbCameraArena;

_Static_assert(sizeof(NP_UsbCameraStorage) <= NP_USB_CAMERA_SHARED_ARENA_BYTES,
               "Camera storage exceeds the mutually-exclusive download arena");
_Static_assert(sizeof(NP_UsbCameraArena) == NP_USB_CAMERA_SHARED_ARENA_BYTES,
               "Shared camera/download arena ABI changed");

extern NP_UsbCameraArena np_usb_camera_arena;

#endif
