#ifndef XE_NP_ACQUISITION_ANCHOR_H
#define XE_NP_ACQUISITION_ANCHOR_H
#include "C:/Frank/Code/XE_NP/_artifacts/v1_rtc_20261029/usb_source/Core/Inc/xe_np_online_impl.h"

/* Optional NPAQ/NPAR v1 query. All words are little-endian. This brackets
 * receiver enable, NOT the probe's first analog conversion or an RTC latch.
 * NPAR alone has a millisecond epoch. Optional NPHR can separately prove a
 * continuous DWT domain; it does not calibrate HALms phase or ADC latency.
 * origin is exported source tick zero's physical offset AFTER receiver enable.
 * Add the decoder's first-row offset in the declared source domain, then /Hz.
 * Do not infer origin when SOURCE_VALID is clear (e.g. ambiguous DMA laps). */
#define NP_ANCHOR_REQUEST       0x5141504eUL /* NPAQ */
#define NP_ANCHOR_REPLY         0x5241504eUL /* NPAR */
#define NP_ANCHOR_ROOT_VALID    1U
#define NP_ANCHOR_CYCLES_VALID  2U
#define NP_ANCHOR_SOURCE_VALID  4U
#define NP_ANCHOR_SOFTWARE      8U
#define NP_ANCHOR_FIRST_SOURCE_VALID 0x10U
/* With this bit, before/after enclose the first actual source read after a
 * proven empty final-arm epoch (<=100us measured); not just receiver enable.
 * SOURCE_VALID and the fine root-domain/PC mapping remain independent. */
#define NP_ANCHOR_V1_GPIO_EDGE  0x100U
#define NP_ANCHOR_V2_PSSI_TICK  0x200U

/* Optional fresh USB7F snapshot; HALms selects wraps, never fine-clock phase.
 * The first valid query latches its fresh nonzero host ID as domain token.
 * IDs must not repeat across reconnect/reset or equal an earlier token.
 * A root with token0 has no high-resolution association. BLE/SD stay coarse. */
#define NP_CLOCK_REPLY          0x5248504eUL /* NPHR */
#define NP_CLOCK_VALID          1U
#define NP_CLOCK_CONTINUOUS     2U
#define NP_CLOCK_ANCHOR_DOMAIN  4U
typedef struct {
    uint32_t flags,domain,generation,before_ms,after_ms,before_cycles,after_cycles;
    uint32_t counter_hz,anchor_domain,uid[3];
} XE_NP_CaptureClock;
static inline void XE_NP_CaptureClock_Reply(const XE_NP_CaptureClock *c,
    uint32_t id,uint8_t out[64])
{
    const uint32_t words[15]={NP_CLOCK_REPLY,1U,id,c->flags,c->domain,c->generation,
        c->before_ms,c->after_ms,c->before_cycles,c->after_cycles,c->counter_hz,
        c->anchor_domain,c->uid[0],c->uid[1],c->uid[2]};
    for(unsigned i=0U;i<15U;i++)xe_np_online_put(out+4U*i,words[i]);
    xe_np_online_put(out+60U,xe_np_online_crc(out));
}

typedef struct {
    uint32_t flags,generation,before_ms,after_ms,before_cycles,after_cycles;
    uint32_t counter_hz,source_hz,origin_lo,origin_hi,sample_hz;
} XE_NP_AcquisitionAnchor;

static inline int XE_NP_AcquisitionAnchor_Request(const uint8_t in[64])
{
    if(xe_np_online_word(in)!=NP_ANCHOR_REQUEST || xe_np_online_word(in+4)!=1U ||
       !xe_np_online_word(in+8) || xe_np_online_word(in+60)!=xe_np_online_crc(in))return 0;
    for(unsigned i=12U;i<60U;i++)if(in[i])return 0;
    return 1;
}
static inline void XE_NP_AcquisitionAnchor_Reply(const XE_NP_AcquisitionAnchor *a,
    uint32_t id,uint8_t out[64])
{
    const uint32_t words[15]={NP_ANCHOR_REPLY,1U,id,a->flags,a->generation,
        a->before_ms,a->after_ms,a->before_cycles,a->after_cycles,a->counter_hz,
        a->source_hz,a->origin_lo,a->origin_hi,a->sample_hz,1000U};
    for(unsigned i=0U;i<15U;i++)xe_np_online_put(out+4U*i,words[i]);
    xe_np_online_put(out+60U,xe_np_online_crc(out));
}
#endif
