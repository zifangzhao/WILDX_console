#ifndef NP_SD_USB_IDENTITY_H
#define NP_SD_USB_IDENTITY_H
#include <stdint.h>
/* Stable per-MCU identity, never the shared legacy XENP0004 serial. */
static inline void np_sd_usb_serial(char out[30], uint32_t a, uint32_t b, uint32_t c)
{
    static const char hex[] = "0123456789ABCDEF";
    const uint32_t words[3] = {a,b,c};
    out[0]='N';out[1]='P';out[2]='V';out[3]='1';out[4]='-';
    for(unsigned w=0;w<3;w++)for(unsigned n=0;n<8;n++)
        out[5+w*8+n]=hex[(words[w]>>(28-4*n))&15U];
    out[29]=0;
}
#endif
