#ifndef NP_SENSOR_GRID_SESSION_H
#define NP_SENSOR_GRID_SESSION_H
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/usb_grid_enforced_incremental_r1/xe_np_usb_stream/228a653e62b3_np_sensor_grid_timer.h"
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/usb_grid_enforced_incremental_r1/xe_np_usb_stream/4cc1dc0f937c_np_sensor_grid_phase.h"
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/usb_grid_r7_source/xe_np_usb_stream/Inc/np_sensor_grid_phase_wire.h"
#include "C:/Frank/Code/XE_NP/_artifacts/v1_rtc_20261029/usb_source/Core/Inc/np_cl_source.h"
#include "C:/Frank/Code/XE_NP/_artifacts/v1_rtc_20261029/usb_source/frozen/Firmware/V1/Core/Inc/xe_np_acquisition_anchor.h"

#ifndef NP_GRID_FIRST_PHASE_ENABLE
#define NP_GRID_FIRST_PHASE_ENABLE 0
#endif
#define NP_GRID_SESSION_UNKNOWN 0
#define NP_GRID_SESSION_FULL 1
#define NP_GRID_SESSION_FIRST_ONLY 2

/* One foreground/session-time calculation. No sensor observation receives
 * a timestamp. first.start_bracket_ticks already includes the TIM5/TIM6
 * prescaler-phase guard tick (np_sensor_grid_timer.c); do not add it twice. */
static inline int np_grid_session_ms_consistent(uint32_t ms,uint32_t ticks,uint32_t hz)
{
    uint64_t expected=(uint64_t)ticks*1000U/hz;
    return expected<=UINT32_MAX && (ms>expected?ms-expected:expected-ms)<=2U;
}
/* identity is supplied independently of evidence. reference_tick is an
 * already validated NPSTART source-relative tick and independently validated
 * NPSTART source frequency. The caller must attest the actual first-event
 * bracket; full additionally attests later jitter. Neither mode establishes
 * oscillator lifetime or physical sensor conversion phase.
 * Unknown or ambiguous phase returns a valid unknown companion when the
 * actual first ordinal is available. No first slot means no companion yet;
 * neither case may cause the NP capture to fail. */
static inline int np_sensor_grid_session_pack(uint8_t out[NP_GRID_PHASE_BYTES],
    const NpGridPhaseWire *identity,const NpGridFirstPoint *first,
    const NpV1FineRoot *root,const NpClAnchorReceipt *anchor,
    uint64_t reference_tick,uint32_t reference_source_hz,int phase_proven)
{
    NpGridPhaseWire result;NpGridPhaseBounds bounds;
    if(!out || !identity || !first || !first->has_slot || np_imu_grid_overlap(out,NP_GRID_PHASE_BYTES,identity,sizeof(*identity)) ||
       (first && np_imu_grid_overlap(out,NP_GRID_PHASE_BYTES,first,sizeof(*first))) ||
       (root && np_imu_grid_overlap(out,NP_GRID_PHASE_BYTES,root,sizeof(*root))) ||
       (anchor && np_imu_grid_overlap(out,NP_GRID_PHASE_BYTES,anchor,sizeof(*anchor))))return 0;
    result=*identity;
    result.first_slot=first->ordinal;
    result.flags=0U;result.low_num=result.high_num=NP_GRID_PHASE_UNKNOWN;
    result.den=0U;result.jitter=UINT32_MAX;
#if NP_SENSOR_GRID_ENFORCED
    if(phase_proven==NP_GRID_SESSION_FULL){
        /* Explicit v2 producer contract: actual first copy, continuous64 root
         * with high-word-zero BEFORE, and fixed window enforced at EVERY
         * retained copy. HAL milliseconds never choose an alias or phase. */
        const uint32_t source_quantum=1250U*780U;
        uint32_t divisor=reference_source_hz/source_quantum;
        if(first->valid && first->enforced && root && anchor && first->point.hz==1200000U &&
           first->point.generation==result.generation && first->point.source_epoch==result.source_epoch &&
           first->point.domain==result.domain && root->generation==result.generation &&
           root->domain==result.domain && root->hz==first->point.hz &&
           (uint32_t)first->counter64==first->point.counter &&
           first->copy_ticks<=first->max_lateness_ticks && first->max_lateness_ticks>=2U &&
           first->max_lateness_ticks<960U && first->counter64>=first->copy_ticks &&
           (anchor->flags&(NP_ANCHOR_ROOT_VALID|NP_ANCHOR_CYCLES_VALID|NP_ANCHOR_SOURCE_VALID|NP_ANCHOR_FIRST_SOURCE_VALID))==
               (NP_ANCHOR_ROOT_VALID|NP_ANCHOR_CYCLES_VALID|NP_ANCHOR_SOURCE_VALID|NP_ANCHOR_FIRST_SOURCE_VALID) &&
           anchor->generation==result.generation && anchor->source_hz==reference_source_hz &&
           !(reference_source_hz%source_quantum) && (divisor==6U || divisor==12U || divisor==16U || divisor==24U) &&
           reference_tick<=UINT64_MAX-anchor->origin_ticks){
            uint32_t span=root->after_counter-root->before_counter;
            uint64_t end=(uint64_t)root->before_counter+span;
            /* One counter quantum at each accepted-copy endpoint. The start
             * prescaler phase is constant and cancels in relative jitter. */
            uint64_t n=((uint64_t)first->max_lateness_ticks+2U)*anchor->source_hz;
            uint64_t jitter=n/root->hz+(n%root->hz!=0U);
            if(span && span<=root->hz/10000U && root->after_ms-root->before_ms<=1U &&
               jitter<UINT32_MAX && np_grid_phase_copy_bounds(&bounds,
                   first->counter64-first->copy_ticks,first->counter64,root->before_counter,end,
                   anchor->origin_ticks+reference_tick,anchor->source_hz,root->hz) &&
               bounds.low_num<=INT64_MAX && bounds.high_num<=INT64_MAX){
                result.low_num=bounds.low_num;result.high_num=bounds.high_num;result.den=bounds.den;
                result.jitter=(uint32_t)jitter;result.flags=NP_GRID_PHASE_INTERVAL|NP_GRID_PHASE_JITTER;
            }
        }
        return np_grid_phase_wire_pack(out,&result);
    }
#endif
    if((phase_proven==NP_GRID_SESSION_FULL || phase_proven==NP_GRID_SESSION_FIRST_ONLY) &&
       first && first->has_slot && first->valid && root && anchor &&
       first->point.generation==result.generation && first->point.source_epoch==result.source_epoch &&
       first->point.domain==result.domain && first->point.hz &&
       root->generation==result.generation && root->domain==result.domain && root->hz==first->point.hz &&
       (anchor->flags&(NP_ANCHOR_ROOT_VALID|NP_ANCHOR_SOURCE_VALID))==(NP_ANCHOR_ROOT_VALID|NP_ANCHOR_SOURCE_VALID) &&
       anchor->generation==result.generation && anchor->source_hz && anchor->source_hz==reference_source_hz &&
       reference_tick<=UINT64_MAX-anchor->origin_ticks){
        uint32_t span=root->after_counter-root->before_counter;
        uint32_t arrival=first->point.counter-root->before_counter;
        uint32_t span_ms=root->after_ms-root->before_ms,arrival_ms=first->point.ms-root->before_ms;
        uint64_t latency=(uint64_t)first->max_lateness_ticks+first->start_bracket_ticks;
        if(span<UINT32_C(0x80000000) && arrival<UINT32_C(0x80000000) && arrival>=span &&
           span_ms<UINT32_C(0x80000000) && arrival_ms<UINT32_C(0x80000000) && arrival_ms>=span_ms &&
           np_grid_session_ms_consistent(span_ms,span,root->hz) &&
           np_grid_session_ms_consistent(arrival_ms,arrival,root->hz) && latency<=UINT32_MAX &&
           np_grid_phase_bounds(&bounds,arrival,(uint32_t)latency,0U,span,
               anchor->origin_ticks+reference_tick,anchor->source_hz,root->hz) &&
           bounds.low_num<=INT64_MAX && bounds.high_num<=INT64_MAX){
            uint64_t n=latency*anchor->source_hz;
            uint64_t jitter=n/root->hz+(n%root->hz!=0U);
            if(phase_proven==NP_GRID_SESSION_FIRST_ONLY || jitter<UINT32_MAX){
                result.low_num=bounds.low_num;result.high_num=bounds.high_num;result.den=bounds.den;
                result.flags=NP_GRID_PHASE_INTERVAL;
                if(phase_proven==NP_GRID_SESSION_FULL){result.jitter=(uint32_t)jitter;result.flags|=NP_GRID_PHASE_JITTER;}
            }
        }
    }
    return np_grid_phase_wire_pack(out,&result);
}
#endif
