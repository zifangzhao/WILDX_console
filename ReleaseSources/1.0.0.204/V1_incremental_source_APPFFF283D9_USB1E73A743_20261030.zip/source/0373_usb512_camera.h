#ifndef USB512_CAMERA_H
#define USB512_CAMERA_H

#include "main.h"

#include <stdint.h>

/* NanEye serial image stream used by the CE64 reference design. */
#define USB512_CAMERA_WIDTH              320U
#define USB512_CAMERA_CAPTURE_ROWS       492U
#define USB512_CAMERA_LOGICAL_ROWS       500U
#define USB512_CAMERA_CAPTURE_BYTES      ((USB512_CAMERA_WIDTH * USB512_CAMERA_CAPTURE_ROWS) + 12U)
#define USB512_CAMERA_FRAME_BYTES        (USB512_CAMERA_WIDTH * USB512_CAMERA_LOGICAL_ROWS)

#define USB512_CAMERA_PHASE_IDLE         0U
#define USB512_CAMERA_PHASE_CONFIG       1U
#define USB512_CAMERA_PHASE_SYNC         2U
#define USB512_CAMERA_PHASE_CAPTURE      3U
#define USB512_CAMERA_PHASE_FRAME_READY  4U
#define USB512_CAMERA_PHASE_ERROR        5U

/* The safe profile trades raster SPI speed for signal margin.  It is intended
 * for marginal cables/modules and is paired with a 30 Hz host frame rate. */
#define USB512_CAMERA_PROFILE_NORMAL_50HZ 0U
#define USB512_CAMERA_PROFILE_SAFE_30HZ   1U

/* Stable failure-source values, exported in the WinUSB status response. */
#define USB512_CAMERA_FAILURE_NONE                 0U
#define USB512_CAMERA_FAILURE_START_RASTER_DMA     1U
#define USB512_CAMERA_FAILURE_CONFIGURE            2U
#define USB512_CAMERA_FAILURE_START_SYNC_DMA       3U
#define USB512_CAMERA_FAILURE_BOOTSTRAP            4U
#define USB512_CAMERA_FAILURE_LINK_PROBE           5U
#define USB512_CAMERA_FAILURE_RESTORE_RX_DMA       6U
#define USB512_CAMERA_FAILURE_SYNC_TIMEOUT         7U
#define USB512_CAMERA_FAILURE_SYNC_INVALID_STAGE   8U
#define USB512_CAMERA_FAILURE_START_LINKED_DMA     9U
#define USB512_CAMERA_FAILURE_CAPTURE_INVALID      10U
#define USB512_CAMERA_FAILURE_SPI_ERROR_CALLBACK   11U

HAL_StatusTypeDef USB512_Camera_Init(SPI_HandleTypeDef *hspi);
/* Retry the complete power/bootstrap sequence after an optional camera was
 * absent or unstable during MCU boot. */
HAL_StatusTypeDef USB512_Camera_Reinitialize(void);
HAL_StatusTypeDef USB512_Camera_StartFrame(void);
/* Queue CE64-compatible NanEye REG0 exposure fields for the next frame.
 * rows_in_reset is 0..255; ramp_gain is 0..3 (80%, 100%, 133%, 200%). */
HAL_StatusTypeDef USB512_Camera_SetExposure(uint8_t rows_in_reset, uint8_t ramp_gain);
/* Queue a capture-link profile for the next idle frame boundary. */
HAL_StatusTypeDef USB512_Camera_SetProfile(uint8_t profile);
/* Run deferred alignment work from the main loop, never a DMA interrupt. */
void USB512_Camera_Service(void);
/* Stop capture DMA while retaining already completed frames for USB drain. */
void USB512_Camera_StopCapture(void);
HAL_StatusTypeDef USB512_Camera_Recover(void);
void USB512_Camera_Stop(void);

uint8_t USB512_Camera_IsReady(void);
uint8_t USB512_Camera_IsBusy(void);
uint8_t USB512_Camera_IsFrameReady(void);
const uint8_t *USB512_Camera_GetFrame(void);
uint32_t USB512_Camera_GetFrameSize(void);
uint32_t USB512_Camera_GetFrameCount(void);
uint32_t USB512_Camera_GetLastCompleteTick(void);
uint32_t USB512_Camera_GetError(void);
uint32_t USB512_Camera_GetLastStatus(void);
uint32_t USB512_Camera_GetFailureCount(void);
uint32_t USB512_Camera_GetFailureOrigin(void);
uint32_t USB512_Camera_GetFailurePhase(void);
uint32_t USB512_Camera_GetFailureSpiState(void);
uint32_t USB512_Camera_GetFailureSpiError(void);
uint32_t USB512_Camera_GetFailureDmaState(void);
uint32_t USB512_Camera_GetFailureDmaError(void);
uint32_t USB512_Camera_GetFailureSpiStatus(void);
uint32_t USB512_Camera_GetFailureSpiCfg1(void);
uint8_t USB512_Camera_GetPhase(void);
uint8_t USB512_Camera_GetProfile(void);
void USB512_Camera_ConsumeFrame(void);

/* Call these from the shared STM32 HAL SPI callbacks. */
void USB512_Camera_OnRxComplete(SPI_HandleTypeDef *hspi);
void USB512_Camera_OnError(SPI_HandleTypeDef *hspi);

#endif /* USB512_CAMERA_H */
