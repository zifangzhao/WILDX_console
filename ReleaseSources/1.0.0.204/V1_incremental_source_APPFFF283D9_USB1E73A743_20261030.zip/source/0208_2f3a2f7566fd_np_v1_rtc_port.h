#ifndef NP_V1_RTC_PORT_H
#define NP_V1_RTC_PORT_H
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/usb_rtc_settled_incremental_r1/xe_np_app/069d17a6128b_np_v1_rtc.h"
/* Lifecycle-owned, foreground initialization; Ready never accesses hardware.
 * Freeze precedes any queued capture/preparation, not a later status poll. */
void NP_V1RtcPortReady(void);
void NP_V1RtcPortFreeze(void);
void NP_V1RtcPortService(void);
int NP_V1RtcPortInitializing(void); /* Control-admission fence only; not a sample check. */
/* Existing64-byte control transport only. mailbox_owned excludes just this
 * worker's own pending flag, never the staged probe-configuration owner. */
int NP_V1RtcPortExchange(const uint8_t request[64],uint8_t reply[64],
    uint32_t received_ms,int mailbox_owned);
int NP_ConfigRtcPending(void);
void NP_V1RtcCaptureFrozen(const uint8_t receipt[328]); /* Foreground, once only. */
#endif
