#ifndef XE_NP_APP_H
#define XE_NP_APP_H

#include "xe_np_runtime.h"
#define NP_STARTUP_BOOT_OFF_MS 50U
void XE_NP_App_ColdPowerOff(void);
void XE_NP_App_SetCameraPowerOwner(uint8_t owned);

#if defined(XE_NP_APP_QUAD_USB_WORD_EXPORT) && (XE_NP_APP_QUAD_USB_WORD_EXPORT != 0U)
void XE_NP_App_ResetUsbWordSession(void);
uint32_t XE_NP_App_UsbWordFault(void);
#endif

#if defined(XE_NP_APP_QUAD_DMA_CPU_GUARD) && (XE_NP_APP_QUAD_DMA_CPU_GUARD != 0U)
void XE_NP_App_QuadCpuGuardFault(void);
#endif

#define XE_NP_APP_LEGACY_BLE_NAME "XENP_UA01"
#define XE_NP_APP_BLE_BOOT_CONFIG_ENABLE 0U
#define XE_NP_APP_BLE_BOOT_RENAME_ENABLE 0U
#define XE_NP_APP_BLE_EARLY_BLIND_RENAME_ENABLE 0U

typedef struct
{
    /*
     * version 10 keeps the 28-byte CE64-friendly wire size but changes how some
     * counters are interpreted in raw-only builds:
     * - foreground queue build: live-decode counters
     * - post-hoc raw-only build:
     *   ok/fail = PSB sync-watchdog counters
     *   windows_processed = recorder backlog blocks (512 B units)
     *   pending_overflows = legacy filesystem speed/fail counters
     *   selftest_probe_mask[5:4] = GPIOE/GPIOD rate-fault latch
     *   selftest_probe_mask[6] = all-active-probe calibration ready
     *   selftest_probe_mask[7] = active probes present but calibration missing
     *   live_decode_probe_mask[5:4] = GPIOE rate bad-sample count (clamped)
     *   live_decode_probe_mask[7:6] = GPIOD rate bad-sample count (clamped)
     *   gpio*_log_state[9:0] = raw manager logState low bits
     *   gpio*_log_state[15:10] = measured/raw expected rate ratio in 2% units
     *   gpioe_windows_processed_low[9:0] = GPIOE recorder backlog blocks (512 B units)
     *   gpioe_windows_processed_low[11:10] = negotiated SD mode
     *     0 = default/unknown, 1 = SDR25/high, 2 = SDR50, 3 = SDR104
     *   gpioe_windows_processed_low[12] = raw NP transport budget accepted
     *   gpiod_pending_overflows_low[12:0] = recorder fail count low
     *   gpiod_pending_overflows_low[14:13] = recorder underspeed bad-sample count
     *   gpiod_pending_overflows_low[15] = recorder underspeed fault latch
     */
    uint8_t version;
    /* bits0..2 = per-probe self-test pass, bit3 = shared GPIOE NP1+NP2 pass */
    uint8_t selftest_probe_mask;
    uint8_t live_decode_probe_mask;
    uint8_t pending_peak_packed;
    uint16_t gpioe_alignment_ticks;
    uint16_t gpiod_alignment_ticks;
    uint16_t gpioe_log_state;
    uint16_t gpiod_log_state;
    uint16_t gpioe_live_decode_ok_low;
    uint16_t gpiod_live_decode_ok_low;
    uint16_t gpioe_live_decode_fail_low;
    uint16_t gpiod_live_decode_fail_low;
    uint16_t gpioe_windows_processed_low;
    uint16_t gpiod_windows_processed_low;
    uint16_t gpioe_pending_overflows_low;
    uint16_t gpiod_pending_overflows_low;
} XE_NP_AppCaptureDiagWire;

typedef char xe_np_app_capture_diag_wire_size_check[
    (sizeof(XE_NP_AppCaptureDiagWire) == 28U) ? 1 : -1];

typedef struct
{
    uint8_t shank_configured_mask;
    uint8_t base_override_mask;
    uint8_t calibration_override_mask;
} XE_NP_AppProbeConfigState;

typedef struct
{
    const uint8_t *data;
    uint32_t size_bytes;
    uint32_t ring_offset_bytes;
    uint64_t total_bytes_end;
} XE_NP_AppUsbCaptureWindow;

typedef struct
{
    uint32_t capture_requested;
    uint32_t capture_port_index;
    uint32_t export_enabled;
    uint32_t export_port_index;
    uint32_t port_active;
    uint32_t pending_read_idx;
    uint32_t pending_write_idx;
    uint32_t usb_active_window_valid;
    uint32_t stable_window_valid;
    uint32_t active_probe_mask;
} XE_NP_AppUsbExportDiag;

/* A claimed, contiguous piece of the paired DDR capture rings.  The caller
 * owns the claim until it either commits it after a successful private-memory
 * DMA copy or cancels it.  No CPU read of SRAM3 is required. */
typedef struct
{
    const uint8_t *lane_a;
    const uint8_t *lane_b;
    uint32_t lane_a_packet_count;
    uint32_t lane_b_packet_count;
    uint32_t packet_count;
    uint32_t payload_bytes_per_packet;
    uint8_t starts_with_lane_b;
} XE_NP_AppUsbInterleavedDmaBatch;

#define XE_NP_APP_USB_QUAD_DMA_LANE_COUNT 4U
#define XE_NP_APP_USB_QUAD_DMA_MAX_SEGMENTS 2U
typedef struct
{
    const uint8_t *source[XE_NP_APP_USB_QUAD_DMA_LANE_COUNT]
                         [XE_NP_APP_USB_QUAD_DMA_MAX_SEGMENTS];
    uint16_t source_bytes[XE_NP_APP_USB_QUAD_DMA_LANE_COUNT]
                         [XE_NP_APP_USB_QUAD_DMA_MAX_SEGMENTS];
    uint8_t source_segment_count[XE_NP_APP_USB_QUAD_DMA_LANE_COUNT];
    uint16_t payload_bytes_per_lane;
} XE_NP_AppUsbQuadDmaBatch;

#define XE_NP_APP_CAPTURE_DIAG_LOG_STATE_MASK 0x03FFU
#define XE_NP_APP_CAPTURE_DIAG_RATE_RATIO_SHIFT 10U
#define XE_NP_APP_CAPTURE_DIAG_RATE_RATIO_MASK 0xFC00U
#define XE_NP_APP_CAPTURE_DIAG_RECORDER_FAIL_MASK 0x1FFFU
#define XE_NP_APP_CAPTURE_DIAG_RECORDER_RATE_BAD_SHIFT 13U
#define XE_NP_APP_CAPTURE_DIAG_RECORDER_RATE_BAD_MASK 0x6000U
#define XE_NP_APP_CAPTURE_DIAG_RECORDER_RATE_FAULT_MASK 0x8000U
#define XE_NP_APP_CAPTURE_DIAG_BACKLOG_BLOCKS_MASK 0x03FFU
#define XE_NP_APP_CAPTURE_DIAG_SD_MODE_SHIFT 10U
#define XE_NP_APP_CAPTURE_DIAG_SD_MODE_MASK 0x0C00U
#define XE_NP_APP_CAPTURE_DIAG_SD_TRANSPORT_READY_MASK 0x1000U

#define XE_NP_APP_CAPTURE_DIAG_SD_MODE_DEFAULT 0U
#define XE_NP_APP_CAPTURE_DIAG_SD_MODE_HIGH 1U
#define XE_NP_APP_CAPTURE_DIAG_SD_MODE_SDR50 2U
#define XE_NP_APP_CAPTURE_DIAG_SD_MODE_SDR104 3U

CE32_FORCE_INLINE const XE_NP_AppCaptureDiagWire *XE_NP_App_GetCaptureDiagWire(
    const CE32_systemParam *sys_param)
{
    return (const XE_NP_AppCaptureDiagWire *)(const void *)sys_param->unassigned;
}

CE32_FORCE_INLINE uint8_t XE_NP_AppCaptureDiag_GpioePendingPeak(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return (diag != NULL) ? (uint8_t)(diag->pending_peak_packed & 0x0FU) : 0U;
}

CE32_FORCE_INLINE uint8_t XE_NP_AppCaptureDiag_GpiodPendingPeak(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return (diag != NULL) ? (uint8_t)((diag->pending_peak_packed >> 4U) & 0x0FU) : 0U;
}

CE32_FORCE_INLINE int XE_NP_AppCaptureDiag_GpioeDualLaneSelfTestPassed(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return ((diag != NULL) &&
            ((diag->selftest_probe_mask & XE_NP_CAPTURE_SELFTEST_GPIOE_DUAL_MASK) != 0U)) ?
               1 :
               0;
}

CE32_FORCE_INLINE int XE_NP_AppCaptureDiag_GpioeRateFaulted(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return ((diag != NULL) &&
            (diag->version >= 6U) &&
            ((diag->selftest_probe_mask & 0x10U) != 0U)) ? 1 : 0;
}

CE32_FORCE_INLINE int XE_NP_AppCaptureDiag_GpiodRateFaulted(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return ((diag != NULL) &&
            (diag->version >= 6U) &&
            ((diag->selftest_probe_mask & 0x20U) != 0U)) ? 1 : 0;
}

CE32_FORCE_INLINE int XE_NP_AppCaptureDiag_CalibrationReady(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return ((diag != NULL) &&
            (diag->version >= 8U) &&
            ((diag->selftest_probe_mask & 0x40U) != 0U)) ? 1 : 0;
}

CE32_FORCE_INLINE int XE_NP_AppCaptureDiag_CalibrationMissing(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return ((diag != NULL) &&
            (diag->version >= 8U) &&
            ((diag->selftest_probe_mask & 0x80U) != 0U)) ? 1 : 0;
}

CE32_FORCE_INLINE uint8_t XE_NP_AppCaptureDiag_GpioeRateBadSamples(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return (diag != NULL) && (diag->version >= 6U) ?
               (uint8_t)((diag->live_decode_probe_mask >> 4U) & 0x03U) :
               0U;
}

CE32_FORCE_INLINE uint8_t XE_NP_AppCaptureDiag_GpiodRateBadSamples(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return (diag != NULL) && (diag->version >= 6U) ?
               (uint8_t)((diag->live_decode_probe_mask >> 6U) & 0x03U) :
               0U;
}

CE32_FORCE_INLINE uint16_t XE_NP_AppCaptureDiag_GpioeLogState(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return (diag != NULL) ?
               (uint16_t)(diag->gpioe_log_state & XE_NP_APP_CAPTURE_DIAG_LOG_STATE_MASK) :
               0U;
}

CE32_FORCE_INLINE uint16_t XE_NP_AppCaptureDiag_GpiodLogState(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return (diag != NULL) ?
               (uint16_t)(diag->gpiod_log_state & XE_NP_APP_CAPTURE_DIAG_LOG_STATE_MASK) :
               0U;
}

CE32_FORCE_INLINE uint8_t XE_NP_AppCaptureDiag_GpioeMeasuredRatePct(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return (diag != NULL) && (diag->version >= 7U) ?
               (uint8_t)(((diag->gpioe_log_state & XE_NP_APP_CAPTURE_DIAG_RATE_RATIO_MASK) >>
                          XE_NP_APP_CAPTURE_DIAG_RATE_RATIO_SHIFT) *
                         2U) :
               0U;
}

CE32_FORCE_INLINE uint8_t XE_NP_AppCaptureDiag_GpiodMeasuredRatePct(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return (diag != NULL) && (diag->version >= 7U) ?
               (uint8_t)(((diag->gpiod_log_state & XE_NP_APP_CAPTURE_DIAG_RATE_RATIO_MASK) >>
                          XE_NP_APP_CAPTURE_DIAG_RATE_RATIO_SHIFT) *
                         2U) :
               0U;
}

CE32_FORCE_INLINE uint16_t XE_NP_AppCaptureDiag_GpioeStreamOkLow(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return (diag != NULL) ? diag->gpioe_live_decode_ok_low : 0U;
}

CE32_FORCE_INLINE uint16_t XE_NP_AppCaptureDiag_GpiodStreamOkLow(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return (diag != NULL) ? diag->gpiod_live_decode_ok_low : 0U;
}

CE32_FORCE_INLINE uint16_t XE_NP_AppCaptureDiag_GpioeStreamFailLow(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return (diag != NULL) ? diag->gpioe_live_decode_fail_low : 0U;
}

CE32_FORCE_INLINE uint16_t XE_NP_AppCaptureDiag_GpiodStreamFailLow(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return (diag != NULL) ? diag->gpiod_live_decode_fail_low : 0U;
}

CE32_FORCE_INLINE uint16_t XE_NP_AppCaptureDiag_GpioeRecorderBacklogBlocks(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return (diag != NULL) ?
               ((diag->version >= 10U) ?
                    (uint16_t)(diag->gpioe_windows_processed_low &
                               XE_NP_APP_CAPTURE_DIAG_BACKLOG_BLOCKS_MASK) :
                    diag->gpioe_windows_processed_low) :
               0U;
}

CE32_FORCE_INLINE uint16_t XE_NP_AppCaptureDiag_GpiodRecorderBacklogBlocks(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return (diag != NULL) ? diag->gpiod_windows_processed_low : 0U;
}

CE32_FORCE_INLINE uint8_t XE_NP_AppCaptureDiag_SdModeCode(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return (diag != NULL) && (diag->version >= 10U) ?
               (uint8_t)((diag->gpioe_windows_processed_low &
                          XE_NP_APP_CAPTURE_DIAG_SD_MODE_MASK) >>
                         XE_NP_APP_CAPTURE_DIAG_SD_MODE_SHIFT) :
               XE_NP_APP_CAPTURE_DIAG_SD_MODE_DEFAULT;
}

CE32_FORCE_INLINE int XE_NP_AppCaptureDiag_SdTransportReady(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return ((diag != NULL) &&
            (diag->version >= 10U) &&
            ((diag->gpioe_windows_processed_low &
              XE_NP_APP_CAPTURE_DIAG_SD_TRANSPORT_READY_MASK) != 0U)) ? 1 : 0;
}

CE32_FORCE_INLINE uint16_t XE_NP_AppCaptureDiag_RecorderSpeedCentiMBs(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return (diag != NULL) ? diag->gpioe_pending_overflows_low : 0U;
}

CE32_FORCE_INLINE uint16_t XE_NP_AppCaptureDiag_RecorderFailCountLow(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return (diag != NULL) ?
               ((diag->version >= 9U) ?
                    (uint16_t)(diag->gpiod_pending_overflows_low &
                               XE_NP_APP_CAPTURE_DIAG_RECORDER_FAIL_MASK) :
                    diag->gpiod_pending_overflows_low) :
               0U;
}

CE32_FORCE_INLINE uint8_t XE_NP_AppCaptureDiag_RecorderRateBadSamples(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return (diag != NULL) && (diag->version >= 9U) ?
               (uint8_t)((diag->gpiod_pending_overflows_low &
                          XE_NP_APP_CAPTURE_DIAG_RECORDER_RATE_BAD_MASK) >>
                         XE_NP_APP_CAPTURE_DIAG_RECORDER_RATE_BAD_SHIFT) :
               0U;
}

CE32_FORCE_INLINE int XE_NP_AppCaptureDiag_RecorderRateFaulted(
    const XE_NP_AppCaptureDiagWire *diag)
{
    return ((diag != NULL) &&
            (diag->version >= 9U) &&
            ((diag->gpiod_pending_overflows_low &
              XE_NP_APP_CAPTURE_DIAG_RECORDER_RATE_FAULT_MASK) != 0U)) ? 1 : 0;
}

void XE_NP_App_Init(void);
void XE_NP_App_Service(void);
const XE_NP_Runtime *XE_NP_App_GetRuntime(void);
XE_NP_CapturePort *XE_NP_App_GetCapturePortForUsb(uint8_t port_index);
int XE_NP_App_StartUsbCapture(uint8_t port_index);
void XE_NP_App_StopUsbCapture(void);
int XE_NP_App_SetRuntimeMcoDivider(uint32_t divider);
int XE_NP_App_IsUsbCaptureReady(uint8_t port_index);
int XE_NP_App_EnableUsbWindowExport(uint8_t port_index);
void XE_NP_App_DisableUsbWindowExport(void);
int XE_NP_App_DequeueUsbCaptureWindow(uint8_t port_index, XE_NP_AppUsbCaptureWindow *window);
int XE_NP_App_DequeueUsbCaptureWindowLimited(
    uint8_t port_index,
    XE_NP_AppUsbCaptureWindow *window,
    uint32_t max_bytes);
int XE_NP_App_IsUsbInterleavedCapture(void);
int XE_NP_App_IsUsbQuadInterleavedCapture(void);
int XE_NP_App_IsUsbQuadInterleavedCaptureConfigured(void);
uint32_t XE_NP_App_CopyUsbInterleavedPayload(uint8_t *dst, uint32_t max_bytes);
/* Copy one contiguous physical lane for the USB-only DDR recorder.  The
 * caller receives whether the packet belongs to lane B; lane A/B packets are
 * paired by their common absolute cursor on the host. */
uint32_t XE_NP_App_CopyUsbInterleavedLanePayload(
    uint8_t *dst,
    uint32_t max_bytes,
    uint8_t *lane_b);
/* Copy one guarded physical lane from the full-rate four-lane capture.  Calls
 * rotate 0 -> 1 -> 2 -> 3; compact USB sequence preserves that lane identity. */
uint32_t XE_NP_App_CopyUsbQuadInterleavedLanePayload(
    uint8_t *dst,
    uint32_t max_bytes,
    uint8_t *lane_index);
int XE_NP_App_BeginUsbQuadDmaBatch(
    uint32_t payload_bytes_per_lane,
    XE_NP_AppUsbQuadDmaBatch *batch);
int XE_NP_App_CommitUsbQuadDmaBatch(const XE_NP_AppUsbQuadDmaBatch *batch);
void XE_NP_App_CancelUsbQuadDmaBatch(void);
int XE_NP_App_CheckUsbQuadDmaRetention(void);
int XE_NP_App_BeginUsbInterleavedDmaBatch(
    uint32_t payload_bytes_per_packet,
    uint32_t max_packet_count,
    XE_NP_AppUsbInterleavedDmaBatch *batch);
int XE_NP_App_CommitUsbInterleavedDmaBatch(
    const XE_NP_AppUsbInterleavedDmaBatch *batch);
void XE_NP_App_CancelUsbInterleavedDmaBatch(void);
/* Copy a complete paired GPIO capture transfer into packetised private USB
 * memory.  The packet headers are deliberately left untouched for the USB
 * layer to stamp after the capture bytes are safely copied. */
uint32_t XE_NP_App_CopyUsbInterleavedPacketPayloads(
    uint8_t *packet_base,
    uint32_t packet_count,
    uint32_t packet_bytes,
    uint32_t header_bytes);
uint32_t XE_NP_App_GetUsbInterleavedExportDebug(void);
void XE_NP_App_ReleaseUsbActiveWindow(uint8_t port_index);
uint32_t XE_NP_App_GetUsbWindowPendingBytes(uint8_t port_index);
uint32_t XE_NP_App_GetUsbWindowPacketHeaderBytes(uint8_t port_index);
void XE_NP_App_GetUsbExportDiag(uint8_t port_index, XE_NP_AppUsbExportDiag *diag);
void XE_NP_App_GpioeDmaIrqHandler(void);
void XE_NP_App_GpiodDmaIrqHandler(void);
/* Optional raw-SD staging owns GPDMA1 Channel 14 only while the SD recorder
 * is active.  Kept separate from the GPIO capture IRQs so its completion can
 * never preempt an edge-triggered capture lane. */
void XE_NP_App_SdStageDmaIrqHandler(void);
/* Called by the board-level SDMMC linked-list completion callback. */
void XE_NP_App_SdLinkedListNodeComplete(SD_HandleTypeDef *hsd);
/* Bind static probe configuration images before init or before the next probe bring-up retry. */
void XE_NP_App_ResetProbeConfigs(void);
int XE_NP_App_SetProbeShankConfig(uint8_t probe_index, const uint8_t *chain1, uint16_t chain1_bytes);
int XE_NP_App_SetProbeBaseConfig(
    uint8_t probe_index,
    const uint8_t *chain2,
    uint16_t chain2_bytes,
    const uint8_t *chain3,
    uint16_t chain3_bytes,
    int includes_calibration);
int XE_NP_App_SetProbeSyncValue(uint8_t probe_index, uint8_t sync_value);
XE_NP_AppProbeConfigState XE_NP_App_GetProbeConfigState(void);
int XE_NP_App_StartRawSdSink(void);
void XE_NP_App_StopRawSdSink(void);
int XE_NP_App_IsRawSdSinkActive(void);
int XE_NP_App_SetProbeCalDacRaw(uint16_t dac_code);
uint16_t XE_NP_App_GetProbeCalDacRaw(void);

#endif
