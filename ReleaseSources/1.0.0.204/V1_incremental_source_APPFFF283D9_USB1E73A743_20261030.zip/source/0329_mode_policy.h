#ifndef NP_V1_MODE_POLICY_H
#define NP_V1_MODE_POLICY_H
#include <stdint.h>
enum { NP_V1_SD=1, NP_V1_STREAM=2, NP_V1_DOWNLOAD=3, NP_V1_RECOVERY=4, NP_V1_ROM_DFU=5 };
typedef struct { volatile uint32_t target, acknowledged, tick; } NpV1Mode;
static inline int np_v1_mode_arm(NpV1Mode *m,uint32_t target,int busy,uint32_t tick)
{
    if(busy || m->target || target<NP_V1_SD || target>NP_V1_ROM_DFU)return 0;
    m->acknowledged=0;m->tick=tick;m->target=target;return 1;
}
static inline void np_v1_mode_cancel(NpV1Mode *m){m->target=0;m->acknowledged=0;}
static inline void np_v1_mode_ack(NpV1Mode *m){if(m->target)m->acknowledged=1;}
static inline int np_v1_mode_ready(NpV1Mode *m,uint32_t now)
{
    if(!m->target)return 0;
    if(now-m->tick>=2000U){np_v1_mode_cancel(m);return 0;}
    return m->acknowledged && now-m->tick>=50U;
}
#endif
