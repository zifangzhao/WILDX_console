#include "C:/Frank/Code/XE_NP/_artifacts/v1_ble_compact_preview_20261025/app_source/Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal.h"
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/app_grid_racefix_incremental_r2/np_sensor_grid_timer/80ba90af143a_np_sensor_grid_timer.h"
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/app_grid_racefix_incremental_r2/np_sensor_grid_timer/6a06b36595d9_np_sensor_grid_sampler.h"
#include "C:/Frank/Code/XE_NP/_artifacts/v1_deterministic_20261029/app_grid_r7_source/xe_np_sensors_port/Inc/xe_np_sensors_port.h"
#include <string.h>

/* TIM6 is not slaved to TIM2: its one-time phase is measured in the same
 * TIM5/HSE domain and must be bound to the NPSTART receipt by the caller.
 * The first-point latency is bounded, not an exact physical edge claim. */
#define NP_GRID_TIMER_HZ 1200000U
#define NP_GRID_PERIOD 960U
#if defined(NP_SD_APP) && NP_SD_APP
#define NP_GRID_TIMER_STORAGE __attribute__((section("NP_SD_TRACE"),aligned(8)))
#else
#define NP_GRID_TIMER_STORAGE __attribute__((aligned(8)))
#endif
static struct {
    NpSensorGrid queue;
    NpSensorGridClock clock;
    NpGridFirstPoint first;
    void (*first_point)(uint32_t scheduled);
    NpSensorGridCopy copy;
    uint32_t domain,start_bracket,maximum_lateness,old_sleep,old_debug;
#if NP_SENSOR_GRID_ENFORCED
    uint32_t generation,source_epoch,copy_before,copy_after;
#endif
    volatile uint32_t active,opened;
} np_grid_timer NP_GRID_TIMER_STORAGE;
#if NP_GRID_STOP_DIAG
#ifndef NP_GRID_DIAG_RETURN_ADDRESS
#define NP_GRID_DIAG_RETURN_ADDRESS() __builtin_return_address(0)
#endif
volatile NpGridStopDiagnostic np_grid_stop_diag NP_GRID_TIMER_STORAGE;
#endif
#if NP_GRID_LIFETIME_DIAG
/* Kept outside the timer state, which is cleared on every start. */
NpGridLifetimeDiagnostic np_grid_lifetime_diag NP_GRID_TIMER_STORAGE;
int NP_GridTimerDiagArm(uint32_t owner,uint32_t domain)
{
    uint32_t key=__get_PRIMASK();__disable_irq();
    int ok=owner && domain && np_grid_timer.active && domain==np_grid_timer.domain &&
        !np_grid_lifetime_diag.owner && !np_grid_lifetime_diag.pending;
    if(ok){np_grid_lifetime_diag.owner=owner;np_grid_lifetime_diag.domain=domain;
        np_grid_lifetime_diag.fresh=1U;np_grid_lifetime_diag.bound=0U;}
    else if(owner)np_grid_lifetime_diag.rejected_owner=owner;
    __set_PRIMASK(key);return ok;
}
int NP_GridTimerDiagService(const NpGridLifetimeIdentity *id)
{
    /* Guard processing is foreground-only. Keep the owner reserved through
     * close, so an interrupt cannot rearm while the old close is in flight. */
    uint32_t key=__get_PRIMASK();__disable_irq();
    uint32_t owner=np_grid_lifetime_diag.owner,domain=np_grid_lifetime_diag.domain;
    uint32_t pending=np_grid_lifetime_diag.pending;
    __set_PRIMASK(key);
    if(!owner)return 1;
    if(np_grid_lifetime_diag.fresh){
        np_grid_lifetime_reset(&np_grid_lifetime_diag.guard);
        np_grid_lifetime_diag.fresh=0U;
    }
    if(!np_grid_lifetime_diag.bound && np_grid_lifetime_identity_valid(id) &&
       id->epoch==owner && id->domain==domain){
        np_grid_lifetime_diag.bound=(uint32_t)np_grid_lifetime_begin(&np_grid_lifetime_diag.guard,id);
    }
    if(!pending)return 0;
    if(np_grid_lifetime_diag.bound){
        /* UIF and health snapshots do not independently prove the lifetime. */
        (void)np_grid_lifetime_close(&np_grid_lifetime_diag.guard,
            &np_grid_lifetime_diag.guard.identity,np_grid_lifetime_diag.stop_accounted_next,0,0);
    }else np_grid_lifetime_diag.guard.faults|=NP_GRID_LIFE_IDENTITY|NP_GRID_LIFE_GAP_UNKNOWN|NP_GRID_LIFE_BOUNDARY;
    key=__get_PRIMASK();__disable_irq();
    if(np_grid_lifetime_diag.owner==owner && np_grid_lifetime_diag.pending){
        np_grid_lifetime_diag.owner=0U;np_grid_lifetime_diag.pending=0U;
    }
    __set_PRIMASK(key);return 1;
}
#endif

static int np_grid_timer_copy_active(void *context,XE_NP_SensorSnapshot *out);
static void np_grid_timer_first_none(uint32_t scheduled){(void)scheduled;}
static void np_grid_timer_first_capture(uint32_t scheduled)
{
#if NP_SENSOR_GRID_ENFORCED
    NpV1FinePoint64 p;
    np_grid_timer.first_point=np_grid_timer_first_none;
    np_grid_timer.copy=np_grid_timer_copy_active;
    np_grid_timer.copy_after=np_grid_timer.clock.last_tick;
    np_grid_timer.first.ordinal=np_grid_timer.clock.next_ordinal-1U;
    np_grid_timer.first.start_bracket_ticks=np_grid_timer.start_bracket;
    __DMB();np_grid_timer.first.has_slot=1U;
    /* One full-counter observation, after a retained copy. Translate back to
     * its actual latched copy end; proof-read latency is NOT copy jitter. The
     * root provider admits its before-counter only while its high word is 0. */
    if(NP_V1FineClockRead64(&p) && p.domain==np_grid_timer.domain && p.hz==NP_GRID_TIMER_HZ &&
       p.generation==np_grid_timer.generation && p.source_epoch==np_grid_timer.source_epoch){
        uint32_t delay=(uint32_t)p.counter-np_grid_timer.copy_after;
        uint32_t width=np_grid_timer.copy_after-np_grid_timer.copy_before;
        uint32_t late=np_grid_timer.copy_after-scheduled;
        if(delay>=UINT32_C(0x80000000) || p.counter<delay || width>late ||
           late>np_grid_timer.clock.max_lateness_ticks)return;
        np_grid_timer.first.counter64=p.counter-delay;
        np_grid_timer.first.copy_ticks=width;
        np_grid_timer.first.point=(NpV1FinePoint){HAL_GetTick(),np_grid_timer.copy_after,
            p.domain,p.hz,p.generation,p.source_epoch};
        np_grid_timer.first.enforced=1U;
        __DMB();np_grid_timer.first.valid=1U;
    }
#else
    NpV1FinePoint p;
    /* A failed one-time proof stays unknown; do not repeat health scans. */
    np_grid_timer.first_point=np_grid_timer_first_none;
    np_grid_timer.first.ordinal=np_grid_timer.clock.next_ordinal-1U;
    np_grid_timer.first.start_bracket_ticks=np_grid_timer.start_bracket;
    __DMB();np_grid_timer.first.has_slot=1U;
    if(NP_V1FineClockRead(&p) && p.domain==np_grid_timer.domain && p.hz==NP_GRID_TIMER_HZ){
        uint32_t point_late=p.counter-scheduled;
        if(point_late>=UINT32_C(0x80000000))return;
        if(point_late>np_grid_timer.maximum_lateness)np_grid_timer.maximum_lateness=point_late;
        np_grid_timer.first.point=p;
        __DMB();np_grid_timer.first.valid=1U;
    }
#endif
}

static uint32_t np_grid_timer_counter(void *context)
{(void)context;return TIM5->CNT;}
static int np_grid_timer_copy_active(void *context,XE_NP_SensorSnapshot *out)
{
    (void)context;
    const XE_NP_SensorSnapshot *p=XE_NP_SensorsPort_GetSnapshot();
    if(!p)return 0;
    memcpy(out,p,sizeof(*out));
    /* A stalled foreground must not leave old cached data marked valid. */
    XE_NP_Sensors_RefreshValidity(out,HAL_GetTick());return 1;
}
#if NP_SENSOR_GRID_ENFORCED
/* The sampler already latched BEFORE into last_tick and will latch AFTER
 * before publishing a successful slot. Preserve only this first bracket;
 * the accepted callback selects the ordinary steady copy function once. */
static int np_grid_timer_copy_first(void *context,XE_NP_SensorSnapshot *out)
{
    np_grid_timer.copy_before=np_grid_timer.clock.last_tick;
    return np_grid_timer_copy_active(context,out);
}
#endif
static int np_grid_timer_copy_closed(void *context,XE_NP_SensorSnapshot *out)
{(void)context;(void)out;return 0;}
/* The first serviced on-time edge after installing the publication guard is
 * deliberately unavailable: it may have been pending before that guard. */
static int np_grid_timer_copy_arming(void *context,XE_NP_SensorSnapshot *out)
{(void)context;(void)out;
#if NP_SENSOR_GRID_ENFORCED
 np_grid_timer.copy=np_grid_timer_copy_first;
#else
 np_grid_timer.copy=np_grid_timer_copy_active;
#endif
 return 0;}
int NP_GridTimerAvailable(void)
{
    uint32_t key=__get_PRIMASK();__disable_irq();
    const int active=np_grid_timer.active!=0U;
    const int owned=active && np_grid_timer.clock.active && (RCC->APB1ENR1&RCC_APB1ENR1_TIM6EN) &&
        (RCC->APB1SMENR1&RCC_APB1SMENR1_TIM6SMEN) &&
        !(DBGMCU->APB1FZR1&DBGMCU_APB1FZR1_DBG_TIM6_STOP) && TIM6->CR1==TIM_CR1_CEN &&
        TIM6->DIER==TIM_DIER_UIE && TIM6->PSC==TIM5->PSC && TIM6->ARR==NP_GRID_PERIOD-1U &&
        NVIC_GetEnableIRQ(TIM6_IRQn) && NVIC_GetPriority(TIM6_IRQn)==6U;
    const int free_timer=!active && !(RCC->APB1ENR1&RCC_APB1ENR1_TIM6EN) && !NVIC_GetEnableIRQ(TIM6_IRQn);
    uint32_t cfgr=RCC->CFGR2&(RCC_CFGR2_HPRE|RCC_CFGR2_PPRE1);
    unsigned apb=(cfgr&RCC_CFGR2_PPRE1)>>RCC_CFGR2_PPRE1_Pos;
    uint32_t kernel=apb>=4U?SystemCoreClock>>(apb-4U):SystemCoreClock;
    const int okay=(owned || free_timer) && !(cfgr&RCC_CFGR2_HPRE) &&
        (RCC->CR&(RCC_CR_HSERDY|RCC_CR_PLL1RDY))==(RCC_CR_HSERDY|RCC_CR_PLL1RDY) &&
        (RCC->CFGR1&RCC_CFGR1_SWS)==RCC_SYSCLKSOURCE_STATUS_PLLCLK &&
        (RCC->PLL1CFGR&RCC_PLL1CFGR_PLL1SRC)==RCC_PLLSOURCE_HSE &&
        SystemCoreClock && HAL_RCC_GetSysClockFreq()==SystemCoreClock &&
        kernel>=NP_GRID_TIMER_HZ && !(kernel%NP_GRID_TIMER_HZ) && kernel/NP_GRID_TIMER_HZ<=65536U &&
        !(CoreDebug->DHCSR&CoreDebug_DHCSR_C_DEBUGEN_Msk);
    __set_PRIMASK(key);return okay;
}
int NP_GridTimerStart(uint32_t lateness_limit_ticks)
{
    NpV1FinePoint p;
    if(lateness_limit_ticks<2U || lateness_limit_ticks>=NP_GRID_PERIOD || np_grid_timer.active ||
       !NP_V1FineClockRead(&p) || p.hz!=NP_GRID_TIMER_HZ || !p.domain ||
       (RCC->APB1ENR1&RCC_APB1ENR1_TIM6EN) || NVIC_GetEnableIRQ(TIM6_IRQn))return 0;
#if NP_SENSOR_GRID_ENFORCED
    if(!p.generation || !p.source_epoch || !NP_GridTimerAvailable())return 0;
#endif
    uint32_t key=__get_PRIMASK();__disable_irq();
    /* Refuse to steal a timer if another owner appeared after preflight. */
    if((RCC->APB1ENR1&RCC_APB1ENR1_TIM6EN) || NVIC_GetEnableIRQ(TIM6_IRQn)){
        __set_PRIMASK(key);return 0;
    }
#if NP_SENSOR_GRID_ENFORCED
    NpV1FinePoint locked;
    if(!NP_V1FineClockRead(&locked) || locked.domain!=p.domain || locked.hz!=p.hz ||
       locked.generation!=p.generation || locked.source_epoch!=p.source_epoch || !NP_GridTimerAvailable()){
        __set_PRIMASK(key);return 0;
    }
#endif
    memset(&np_grid_timer,0,sizeof(np_grid_timer));
#if NP_GRID_STOP_DIAG
    memset((void *)&np_grid_stop_diag,0,sizeof(np_grid_stop_diag));
#endif
    np_sensor_grid_begin(&np_grid_timer.queue);np_grid_timer.domain=p.domain;
#if NP_SENSOR_GRID_ENFORCED
    np_grid_timer.generation=p.generation;np_grid_timer.source_epoch=p.source_epoch;
#endif
    np_grid_timer.first_point=np_grid_timer_first_capture;
    np_grid_timer.copy=np_grid_timer_copy_closed;
    np_grid_timer.old_sleep=RCC->APB1SMENR1&RCC_APB1SMENR1_TIM6SMEN;
    np_grid_timer.old_debug=DBGMCU->APB1FZR1&DBGMCU_APB1FZR1_DBG_TIM6_STOP;
    RCC->APB1ENR1|=RCC_APB1ENR1_TIM6EN;__DSB();
    RCC->APB1SMENR1|=RCC_APB1SMENR1_TIM6SMEN;
    DBGMCU->APB1FZR1&=~DBGMCU_APB1FZR1_DBG_TIM6_STOP;
    TIM6->CR1=0U;TIM6->DIER=0U;TIM6->PSC=TIM5->PSC;TIM6->ARR=NP_GRID_PERIOD-1U;
    TIM6->CNT=0U;TIM6->EGR=TIM_EGR_UG;TIM6->SR=0U;
    NVIC_ClearPendingIRQ(TIM6_IRQn);NVIC_SetPriority(TIM6_IRQn,6U);
    uint32_t before=TIM5->CNT;TIM6->CR1=TIM_CR1_CEN;__DSB();uint32_t after=TIM5->CNT;
    uint32_t bracket=after-before;
    /* TIM5 and TIM6 use the same kernel and divider, but their prescaler
     * phases may differ by one fine-counter tick. Start with the earliest
     * possible edge so an early IRQ cannot permanently shift the grid. */
    if(bracket>=lateness_limit_ticks-1U || !np_sensor_grid_clock_begin(&np_grid_timer.clock,
        before+NP_GRID_PERIOD-1U,NP_GRID_PERIOD,lateness_limit_ticks,0U)){
        TIM6->CR1=0U;RCC->APB1ENR1&=~RCC_APB1ENR1_TIM6EN;
        RCC->APB1SMENR1=(RCC->APB1SMENR1&~RCC_APB1SMENR1_TIM6SMEN)|np_grid_timer.old_sleep;
        DBGMCU->APB1FZR1=(DBGMCU->APB1FZR1&~DBGMCU_APB1FZR1_DBG_TIM6_STOP)|np_grid_timer.old_debug;
        __set_PRIMASK(key);return 0;
    }
    np_grid_timer.start_bracket=bracket+1U;np_grid_timer.active=1U;
    TIM6->DIER=TIM_DIER_UIE;NVIC_EnableIRQ(TIM6_IRQn);__set_PRIMASK(key);return 1;
}
void NP_GridTimerOpen(void)
{
    uint32_t key=__get_PRIMASK();__disable_irq();
    if(np_grid_timer.active && !np_grid_timer.opened){
        XE_NP_SensorsPort_GridGuard(1);np_grid_timer.copy=np_grid_timer_copy_arming;np_grid_timer.opened=1U;
    }
    __set_PRIMASK(key);
}
void NP_GridTimerStop(void)
{
    uint32_t key=__get_PRIMASK();__disable_irq();
    if(np_grid_timer.active){
#if NP_GRID_STOP_DIAG
        if(!np_grid_stop_diag.seen){
            np_grid_stop_diag.caller=(uint32_t)(uintptr_t)NP_GRID_DIAG_RETURN_ADDRESS();
            np_grid_stop_diag.clock_active=np_grid_timer.clock.active;
            np_grid_stop_diag.last_tick=np_grid_timer.clock.last_tick;
            np_grid_stop_diag.counter=TIM5->CNT;
            np_grid_stop_diag.next_tick=np_grid_timer.clock.next_tick;
            np_grid_stop_diag.domain=np_grid_timer.domain;
            np_grid_stop_diag.next_ordinal=np_grid_timer.clock.next_ordinal;
            np_grid_stop_diag.missing=np_grid_timer.clock.missing;
            __DMB();np_grid_stop_diag.seen=1U;
        }
#endif
#if NP_GRID_LIFETIME_DIAG
        if(np_grid_lifetime_diag.owner && !np_grid_lifetime_diag.pending){
            np_grid_lifetime_diag.stop_owner=np_grid_lifetime_diag.owner;
            np_grid_lifetime_diag.stop_domain=np_grid_timer.domain;
            np_grid_lifetime_diag.stop_accounted_next=np_grid_timer.clock.next_ordinal;
            np_grid_lifetime_diag.stop_flags=(np_grid_timer.opened?NP_GRID_DIAG_OPEN:0U)|
                (np_grid_timer.clock.active?NP_GRID_DIAG_CLOCK:0U)|
                ((TIM6->SR&TIM_SR_UIF)?NP_GRID_DIAG_UIF:0U);
            __DMB();np_grid_lifetime_diag.pending=1U;
        }
#endif
        np_grid_timer.copy=np_grid_timer_copy_closed;XE_NP_SensorsPort_GridGuard(0);
        np_grid_timer.active=0U;TIM6->DIER=0U;NVIC_DisableIRQ(TIM6_IRQn);
        TIM6->CR1=0U;TIM6->SR=0U;NVIC_ClearPendingIRQ(TIM6_IRQn);RCC->APB1ENR1&=~RCC_APB1ENR1_TIM6EN;
        RCC->APB1SMENR1=(RCC->APB1SMENR1&~RCC_APB1SMENR1_TIM6SMEN)|np_grid_timer.old_sleep;
        DBGMCU->APB1FZR1=(DBGMCU->APB1FZR1&~DBGMCU_APB1FZR1_DBG_TIM6_STOP)|np_grid_timer.old_debug;
    }
    __set_PRIMASK(key);
}
NpSensorGrid *NP_GridTimerQueue(void){return &np_grid_timer.queue;}
int NP_GridTimerFirst(NpGridFirstPoint *out)
{
    if(!out)return 0;uint32_t key=__get_PRIMASK();__disable_irq();
    *out=np_grid_timer.first;
#if NP_SENSOR_GRID_ENFORCED
    /* This configured ceiling is enforced for EVERY retained copy. Never
     * replace it with an observed early maximum or proof-call latency. */
    out->max_lateness_ticks=np_grid_timer.clock.max_lateness_ticks;
#else
    out->max_lateness_ticks=np_grid_timer.maximum_lateness>np_grid_timer.clock.max_lateness_ticks?
        np_grid_timer.maximum_lateness:np_grid_timer.clock.max_lateness_ticks;
#endif
    __set_PRIMASK(key);return out->has_slot!=0U;
}
int NP_GridTimerProofReady(void)
{
    NpV1FinePoint now;uint32_t key=__get_PRIMASK();__disable_irq();
    int owned=np_grid_timer.active && np_grid_timer.opened && np_grid_timer.clock.active &&
        np_grid_timer.first.valid && np_grid_timer.first.point.generation &&
        np_grid_timer.first.point.source_epoch && (RCC->APB1ENR1&RCC_APB1ENR1_TIM6EN) &&
        (RCC->APB1SMENR1&RCC_APB1SMENR1_TIM6SMEN) &&
        !(DBGMCU->APB1FZR1&DBGMCU_APB1FZR1_DBG_TIM6_STOP) && TIM6->CR1==TIM_CR1_CEN &&
        TIM6->DIER==TIM_DIER_UIE && TIM6->PSC==TIM5->PSC && TIM6->ARR==NP_GRID_PERIOD-1U &&
        NVIC_GetEnableIRQ(TIM6_IRQn) && NVIC_GetPriority(TIM6_IRQn)==6U;
    __set_PRIMASK(key);
    return owned && NP_V1FineClockRead(&now) && now.domain==np_grid_timer.domain &&
        now.hz==NP_GRID_TIMER_HZ && now.generation==np_grid_timer.first.point.generation &&
        now.source_epoch==np_grid_timer.first.point.source_epoch;
}
#if NP_SENSOR_GRID_ENFORCED
int NP_GridTimerService(void)
{
    NpV1FinePoint p;
    if(!np_grid_timer.active)return 0;
    /* The ISR may advance last_tick during the following health read. Take
     * the earlier reference first so a normal interrupt is not a reset. */
    uint32_t last_tick=np_grid_timer.clock.last_tick;
    /* Existing fine-owner health checks cover its frozen HSE/PLL/register,
     * sleep/debug and domain lifetime. No health scan or CRC enters the ISR.
     * This is detection of observed faults, not universal oscillator proof. */
    if(!NP_GridTimerAvailable() || !NP_V1FineClockRead(&p) ||
       p.domain!=np_grid_timer.domain || p.hz!=NP_GRID_TIMER_HZ ||
       p.generation!=np_grid_timer.generation || p.source_epoch!=np_grid_timer.source_epoch ||
       p.counter-last_tick>=UINT32_C(0x80000000)){
        NP_GridTimerStop();return 0;
    }
    return 1;
}
#endif
void TIM6_IRQHandler(void)
{
    if(!(TIM6->SR&TIM_SR_UIF))return;
    TIM6->SR=~TIM_SR_UIF;__DSB();
    if(!np_grid_timer.active)return;
    int result=np_sensor_grid_sample(&np_grid_timer.queue,&np_grid_timer.clock,
        np_grid_timer_counter,np_grid_timer.copy,0);
    uint32_t now=TIM5->CNT,scheduled=np_grid_timer.clock.next_tick-NP_GRID_PERIOD;
    if(result==1){
        uint32_t late=now-scheduled;
        if(late>np_grid_timer.maximum_lateness)np_grid_timer.maximum_lateness=late;
        np_grid_timer.first_point(scheduled);
    }else if(result<0)NP_GridTimerStop(); /* Optional grid only; NP keeps running. */
}
