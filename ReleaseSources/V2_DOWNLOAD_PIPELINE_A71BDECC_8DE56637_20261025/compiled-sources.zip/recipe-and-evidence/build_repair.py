"""Focused cache-range/speculation repair only; one stream build, no hardware."""
import hashlib,json,shutil,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];HERE=Path(__file__).parent
PARENT=HERE.parent;BASE=PARENT/'build/usb';TREE=HERE/'inputs'
FROZEN=ROOT/'_artifacts/v2_usb_format_20261022/source-freeze'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def emit(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
assert not TREE.exists()
native=load(PARENT/'native-repair/result.json');source=ROOT/'Core/Src/xe_np_usb_download_pipeline.inc'
assert native['status']=='PASS' and native['pipeline_sha256']==sha(source)
shutil.copytree(PARENT/'inputs',TREE);shutil.copyfile(source,TREE/'Core/Src'/source.name)
index={p.relative_to(TREE).as_posix():sha(p) for p in sorted(TREE.rglob('*')) if p.is_file()}
emit(HERE/'source-inputs.json',{'files':index,'parent_usb':'90822A54','scope':'Only pipeline module changes:32B header clean, proven sequential/bounded depth, debugger-only counters','source_proof':'SD destination pre-cleaned, full payload invalidated after IDMA; CPU CRC reads only; eight header words are sole CPU writes','hardware_access':False})
sys.path[:0]=[str(ROOT/'Tools/V2Usb'),str(ROOT/'Tools/V2SdLogger'),str(ROOT/'Tools/Power')]
from build_np_start_anchor import build
from build_checked_np_start_anchor import seal
import validate_np2_live_sd_memory as ram
r=load(BASE/'incremental-build.json');assert r['body_crc32']=='90822A54'
flags=r['compiler_args_by_unit']['xe_np_usb_stream'];filtered=[];i=0
while i<len(flags):
 if flags[i] in ('-I','-iquote'):
  key=flags[i];folder=Path(flags[i+1]).resolve();i+=2
  if folder in ((PARENT/'inputs/Core/Src').resolve(),(ROOT/'Core/Src').resolve()):continue
  filtered += [key,str(folder)]
 else:filtered.append(flags[i]);i+=1
ram.CMSIS=FROZEN/'Drivers/CMSIS/Device/ST/STM32U5xx/Include/stm32u595xx.h'
build('USB',str(BASE.relative_to(ROOT)),r['body_sha256'],{'xe_np_usb_stream':filtered},sources={'xe_np_usb_stream':TREE/'Core/Src/xe_np_usb_stream.c'},includes=[TREE/'Core/Src',FROZEN/'Core/Inc',FROZEN/'Core/Src'],work=HERE/'build')
out=HERE/'build/usb';seal(out,'USB');p=out/'timing_candidate.hex';p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
r=load(out/'incremental-build.json');r.update(hex_sha256=sha(p),manifest_sha256=sha(out/'application.manifest.bin'),source_inputs_sha256=sha(HERE/'source-inputs.json'),native_receipt_sha256=sha(PARENT/'native-repair/result.json'),exact_main_retained=True,hardware_validated=False,installed=False,published=False,scope='Focused32B header clean and conservative metadata speculation; all non-stream objects/8RAM reservations retained; no clocks/pins/NP/IMU/APP/recovery/settings changes')
emit(out/'incremental-build.json',r)
print('Private focused repair '+r['body_crc32']+' bodySHA '+r['body_sha256']+' HEXSHA '+r['hex_sha256']+'; not installed or hardware accepted')
