"""Package the accepted sealed A71 components once; no build or hardware access."""
import copy,hashlib,json,shutil,struct,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
LATEST=ROOT/'LATEST_FIRMWARE/V2_NP2';BUILD=HERE/'repair/build/usb';OUT=HERE/'delivery'
SOURCE='ReleaseSources/V2_BURST_A71BDECC_8DE56637_20261025/compiled-sources.zip'
sys.path.insert(0,str(ROOT/'Tools'));import package_xe_np_firmware as pack
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def emit(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
assert not OUT.exists()
old=load(LATEST/'package-receipt.json');assert (old['usb_crc32'],old['app_crc32'],old['recovery_crc32'])==('13ED1F8E','8DE56637','6408DBB8')
comparison=load(HERE/'final-comparison.json');assert comparison['decision']=='accept_A71_actual141_bounded_download_and_short_capture'
assert comparison['all_six_hash_dictionaries_match'] and comparison['all_catalog_metadata_match'] and comparison['firmware_errors']==0
for n,want in {'application.bin':'B75D8D19C83A0A9E325BF45B54F19DCC976B41114EAEB1996A7AEAD0DD228B09','application.manifest.bin':'92A3C1CB7F67903A6620A62AD01034C1B9421DB2CD0EFD619BC95B59E630A674','timing_candidate.hex':'FF89382337AC75918FE12979F0A659B2E4F5499427304F60A780676521CD93F6'}.items():assert sha(BUILD/n)==want
body=(BUILD/'application.bin').read_bytes();manifest=(BUILD/'application.manifest.bin').read_bytes();assert len(body)==187716
usb=pack.sealed_slot_memory(body,manifest);assert pack.read_intel_hex(BUILD/'timing_candidate.hex')==usb
assert all(0x0817E000<=a<0x0817E080 or 0x08180000<=a<0x081FD000 for a in usb)
parent=LATEST/next(n for n in old['files'] if 'fused' in n);assert sha(parent)==old['files'][parent.name]['sha256']
previous=pack.read_intel_hex(parent);fused={a:b for a,b in previous.items() if a<0x0817E000}
fused.update(dict.fromkeys(range(0x0817E000,0x081FD000),0xff));fused.update(usb)
assert {a:b for a,b in previous.items() if a<0x0817E000}=={a:b for a,b in fused.items() if a<0x0817E000}
assert not any(0x0801C000<=a<0x0801E000 or 0x081FD000<=a<0x08200000 for a in fused)
loader={a:b for a,b in fused.items() if a<pack.CONFIG_BASE};pack.validate_loader(loader)
sp,reset=struct.unpack('<II',bytes(loader[pack.FLASH_BASE+i] for i in range(8)))
assert pack.valid_initial_stack_pointer(sp) and reset&1 and pack.FLASH_BASE<=(reset&~1)<pack.LOADER_LIMIT
OUT.mkdir()
usbhex='V2_USB_only_A71BDECC_BURST_DOWNLOAD_20261025.hex';usbxenp='V2_USB_update_A71BDECC_BURST_DOWNLOAD_20261025.xenp'
fusedname='V2_fused_RECOVERY_6408DBB8_USB_A71BDECC_APP_8DE56637_BURST_DOWNLOAD_20261025.hex'
shutil.copyfile(BUILD/'timing_candidate.hex',OUT/usbhex);(OUT/usbxenp).write_bytes(manifest+body)
pack.write_intel_hex(OUT/fusedname,fused);(OUT/fusedname).write_bytes((OUT/fusedname).read_bytes().replace(b'\r\n',b'\n'))
assert pack.read_intel_hex(OUT/fusedname)==fused
for n,identity in old['files'].items():
 if 'logger_APP' in n or 'recovery_only' in n:
  assert sha(LATEST/n)==identity['sha256'];shutil.copyfile(LATEST/n,OUT/n)
for p in (OUT/usbhex,OUT/fusedname):assert b'\r' not in p.read_bytes()
appfile=next(OUT.glob('*logger_APP_update*.xenp'));appbytes=appfile.read_bytes();app=pack.sealed_slot_memory(appbytes[128:],appbytes[:128]);assert all(fused[k]==v for k,v in app.items())
acceptance={'accepted_usb_crc32':'A71BDECC','unchanged_app_crc32':'8DE56637','unchanged_recovery_crc32':'6408DBB8','comparison':comparison,'usb_install_readback':load(HERE/'hil/install-repair/readback.json'),'native_pipeline':load(HERE/'native-repair/result.json'),'baseline_pair_validation':old['validation'],'scope':comparison['scope'],'hardware_lease_returned':True,'fused_whole_flash_tested':False,'new_build_or_hardware_during_packaging':False,'learning':'Device overlap alone exposed per-packet host command latency. Explicit bounded batches plus a single native read worker overlapping CRC/decoding improved actual GUI exports. Preserve checksums and physical loan retirement.'}
emit(OUT/'acceptance.json',acceptance)
bench=load(HERE/'benchmark141-A71-r1/benchmark.json');bench.pop('catalog',None);emit(OUT/'benchmark-selected.json',bench)
archivefiles={}
def inc(p,n):assert p.is_file(),str(p);archivefiles[n]=p
for p in sorted((HERE/'repair/inputs').rglob('*')):
 if p.is_file():inc(p,'compiled-inputs/'+p.relative_to(HERE/'repair/inputs').as_posix())
for n in ('incremental-build.json','application.lnp','application.map','application.htm','xe_np_usb_stream.o'):inc(BUILD/n,'build/'+n)
for n in ('source-inputs.json','private-provenance.json','build_repair.py'):inc(HERE/'repair'/n,'recipe-and-evidence/'+n)
for n in ('build_pipeline.py','prepared-inputs.json','package_checked.py','final-comparison.json'):inc(HERE/n,'recipe-and-evidence/'+n)
inc(ROOT/'Tools/V2Usb/tests/test_usb_download_pipeline.py','regression/test_usb_download_pipeline.py')
inc(HERE/'native-repair/result.json','regression/result.json');inc(HERE/'hil/install-repair/readback.json','acceptance/readback.json')
for n in ('acceptance.json','benchmark-selected.json'):inc(OUT/n,'acceptance/'+n)
index={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in sorted(archivefiles.items())}
with zipfile.ZipFile(OUT/'compiled-sources.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for n,p in sorted(archivefiles.items()):z.write(p,n)
 z.writestr('archive-index.json',json.dumps(index,indent=2)+'\n')
source={'usb_crc32':'A71BDECC','app_crc32':'8DE56637','source_scope':'Exact scoped incremental pipeline input snapshots, retained-object identities, final stream object, recipe/maps, native and hardware receipts; not a clean-tree reconstruction. Unchanged historical inputs are referenced by the parent source archive/build identities.','parent_release_commit':'c8b10f8e4ac831c86732627305c249faa6b9ae4a','parent_source_archive_path':old['firmware_source_archive_path'],'parent_source_archive_sha256':old['firmware_source_archive_sha256'],'source_archive_path':SOURCE,'source_archive_sha256':sha(OUT/'compiled-sources.zip'),'archive_inputs':index,'usb_build_receipt':load(BUILD/'incremental-build.json'),'canonical_source_equivalence_claimed':False,'retained_main_object_sha256':'4DFDB1A929FFE48BAD5A8B9470BF3346D1350895B85EFEDD99F5E3D660B570C4','retained_main_source_limit':'Historical main source preimage unavailable; exact checked main.o reused unchanged.','build_time_flags_are_historical':'Build receipt hardware_validated=false remains immutable; subsequent acceptance is separate.'}
emit(OUT/'source-manifest.json',source)
files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.iterdir() if p.suffix in ('.hex','.xenp')}
receipt={'release':'V2_BURST_DOWNLOAD_USBA71BDECC_APP8DE56637_20261025','usb_crc32':'A71BDECC','app_crc32':'8DE56637','recovery_crc32':'6408DBB8','files':files,'firmware_source_archive_path':SOURCE,'firmware_source_archive_sha256':sha(OUT/'compiled-sources.zip'),'acceptance_sha256':sha(OUT/'acceptance.json'),'source_manifest_sha256':sha(OUT/'source-manifest.json'),'previous_usb_crc32':'13ED1F8E','parent_fused_sha256':sha(parent),'packaging':'Direct merge of exact sealed A71 USB into checked13ED fused. APP/recovery copied byte-for-byte, all non-USB addresses unchanged, settings omitted. No rebuild/reseal/hardware access.','settings_omitted':True,'omitted_ranges':['0801C000-0801DFFF','081FD000-081FFFFF'],'validation_scope':comparison['scope'],'validation':{'download_and_capture':comparison,'prior_unchanged_app':old['validation']},'installer_target':'WILDX1.0.0.141; canonical owner includes exact assets directly','standalone_update_zip':False,'fused_whole_flash_tested':False,'published':False,'line_endings':'New USB/fused HEX LF; exact legacy recovery HEX retains CRLF.'}
emit(OUT/'package-receipt.json',receipt)
(OUT/'SHA256SUMS.txt').write_text(''.join(f"{v['sha256']}  {n}\n" for n,v in sorted(files.items())),encoding='utf-8',newline='\n')
(OUT/'README.md').write_text('''# V2 bounded SD download release - 2026-10-25

Recovery 6408DBB8 / USB A71BDECC / BLE-SD APP 8DE56637.

Actual WILD-X141 buffered export median: 43.3317 MB/s versus previous 31.4195 MB/s
(+37.91%). Six exports matched the reference DAT, descriptor and footer hashes;
all 296 catalog entries matched; firmware errors 0, CRC self-test 1. The selected
record contained no IMRO file. Legacy serial median was 31.1702 MB/s.

Short three-probe/20 kHz USB capture on the unchanged actual140 capture graph:
7280 received and verified blocks, zero raw/decoded drops, fresh AG and MAG in
all 186 retained IMU observations. This is bounded qualification, not all-mode,
all-card, endurance, analog-quality, physical-time or installed-UI qualification.

Fused HEX directly merges exact checked components and omits configuration.
APP/recovery stay byte-for-byte unchanged. New USB/fused HEX use LF; legacy
recovery HEX retains CRLF. The fused image was not separately flashed as a whole.

The source ZIP contains incremental source/object/build/evidence provenance,
not a standalone updater or full clean-tree reproduction. Historical main source
preimage is unavailable; exact retained main.o is pinned. Existing APP limits
and prior evidence remain in acceptance.json and package-receipt.json.
''',encoding='utf-8',newline='\n')
catalog=load(Path('D:/Code/WILDX_console/WILDX_console/Firmware/releases.json'));entry=next(e for e in catalog['releases'] if e['family']==2)
assert entry['usbCrc32']=='13ED1F8E' and entry['appCrc32']=='8DE56637'
entry['previousUsb'].insert(0,copy.deepcopy(entry['usbIdentity']))
entry.update(release=receipt['release'],sourceCommit=None,stage='BOUNDED_ACTUAL141_EXPORT_P12320K_IMU_CHECKED',usbVersion='build A71BDECC (bounded pipelined SD download)',usbCrc32='A71BDECC',limits=comparison['scope']+' Existing APP timing/BLE limits retained in acceptance.json; fused not separately flashed as a whole.')
entry['usbIdentity']={'imageId':struct.unpack_from('<I',manifest,16)[0],'baseAddress':struct.unpack_from('<I',manifest,24)[0],'bytes':len(body),'codeCrc32':'A71BDECC','buildIdHex':manifest[44:76].hex().upper(),'manifestFlags':struct.unpack_from('<I',manifest,76)[0],'minimumLoaderAbi':struct.unpack_from('<I',manifest,80)[0],'generation':struct.unpack_from('<I',manifest,20)[0]}
entry['full']={'path':'V2/'+fusedname,'sha256':sha(OUT/fusedname)}
entry['files']=[{'path':'V2/'+n,'sha256':v['sha256']} for n,v in sorted(files.items())]
entry['sourceProvenance']={'publishedRepository':'zifangzhao/XE_NP','publishedBranch':'V2','publishedCommit':None,'parentPublishedCommit':'c8b10f8e4ac831c86732627305c249faa6b9ae4a','ownerManifest':'V2/source-manifest.json','ownerManifestSha256':sha(OUT/'source-manifest.json'),'packageReceiptSha256':sha(OUT/'package-receipt.json'),'acceptance':'V2/acceptance.json','acceptanceSha256':sha(OUT/'acceptance.json'),'sourceArchive':SOURCE,'sourceArchiveSha256':sha(OUT/'compiled-sources.zip'),'canonicalSourceEquivalenceClaimed':False}
emit(OUT/'releases.json',catalog)
print(json.dumps({'delivery':str(OUT),'files':files,'source_archive_sha256':sha(OUT/'compiled-sources.zip'),'package_receipt_sha256':sha(OUT/'package-receipt.json'),'catalog_sha256':sha(OUT/'releases.json')},indent=2))
