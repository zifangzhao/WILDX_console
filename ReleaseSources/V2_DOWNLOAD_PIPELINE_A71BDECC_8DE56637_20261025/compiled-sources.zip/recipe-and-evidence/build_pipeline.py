"""One private opt-in stream candidate; source preparation and build are separate."""
import hashlib,json,re,shutil,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
BASE=ROOT/'_artifacts/v2_download_crc_20261025/build-r2-interleaved/usb'
INPUTS=ROOT/'_artifacts/v2_download_crc_20261025/inputs-interleaved'
FROZEN=ROOT/'_artifacts/v2_usb_format_20261022/source-freeze'
TREE=HERE/'inputs';PIPE=ROOT/'Core/Src/xe_np_usb_download_pipeline.inc'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def emit(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
def replace(s,a,b):assert s.count(a)==1,a[:70];return s.replace(a,b)
def prepare():
 assert not TREE.exists()
 shutil.copytree(INPUTS,TREE)
 core=TREE/'Core/Src';shutil.copyfile(PIPE,core/PIPE.name)
 p=core/'xe_np_usb_unified.inc';s=p.read_text(encoding='utf-8-sig')
 inc='#include "../../Tools/V1Capture/SdLogger/np_sd_usb_download.inc"'
 s=replace(s,inc,'''#ifndef XE_NP_USB_DOWNLOAD_PIPELINE
#define XE_NP_USB_DOWNLOAD_PIPELINE 0U
#endif
#if XE_NP_USB_DOWNLOAD_PIPELINE
#define NP_SD_UsbService NP_SD_UsbServiceLegacy
#define NP_SD_UsbComplete NP_SD_UsbCompleteLegacy
#define NP_SD_UsbReset NP_SD_UsbResetLegacy
#endif
'''+inc+'''
#if XE_NP_USB_DOWNLOAD_PIPELINE
#undef NP_SD_UsbService
#undef NP_SD_UsbComplete
#undef NP_SD_UsbReset
#include "xe_np_usb_download_pipeline.inc"
#endif''')
 s=replace(s,'if(XE_NP_UsbUnified_IsDownload())return np_download_state || np_download_burst_armed;',
 '''if(XE_NP_UsbUnified_IsDownload())return np_download_state || np_download_burst_armed
#if XE_NP_USB_DOWNLOAD_PIPELINE
        || np_pipe.read<3U || np_pipe.tx<3U
#endif
        ;''')
 s=replace(s,'!XE_NP_UsbMode_Arm(&xe_np_usb_mode,r->wValue,xe_np_usb_mode_busy(),HAL_GetTick())){',
 '''
#if XE_NP_USB_DOWNLOAD_PIPELINE
           (XE_NP_UsbUnified_IsDownload() && !np_pipe_maintenance_idle()) ||
#endif
           !XE_NP_UsbMode_Arm(&xe_np_usb_mode,r->wValue,xe_np_usb_mode_busy(),HAL_GetTick())){''')
 p.write_text(s,encoding='utf-8',newline='\n')
 p=core/'xe_np_usb_catalog.inc';s=(FROZEN/'Core/Src'/p.name).read_text(encoding='utf-8-sig')
 s=replace(s,'    if(np_download_prefetch.valid)return 0;',
 '''    if(np_download_prefetch.valid
#if XE_NP_USB_DOWNLOAD_PIPELINE
       && !np_pipe_maintenance_idle()
#endif
       )return 0;''')
 p.write_text(s,encoding='utf-8',newline='\n')
 p=core/'xe_np_usb_selftest.inc';s=p.read_text(encoding='utf-8-sig')
 s=replace(s,'static int xe_np_usb_selftest_other_busy(void)\n{',
 '''static int xe_np_usb_selftest_other_busy(void)
{
#if XE_NP_USB_DOWNLOAD_PIPELINE
    if(XE_NP_UsbUnified_IsDownload() && !np_pipe_maintenance_idle())return 1;
#endif''')
 p.write_text(s,encoding='utf-8',newline='\n')
 assert digest(TREE/'Tools/V1Capture/SdLogger/np_sd_usb_download.inc')=='06243EB98E15FC3554C45E70445127A5AC6585EBBC7D452AF9DADA66AE1D21CB'
 index={p.relative_to(TREE).as_posix():digest(p) for p in sorted(TREE.rglob('*')) if p.is_file()}
 emit(HERE/'prepared-inputs.json',{'files':index,'baseline_usb':'13ED1F8E','baseline_body_sha256':digest(BASE/'application.bin'),
  'scope':'Exact13ED stream tree plus opt-in V2 pipeline, mode/catalog/selftest loan barriers. CRC/header/wire/NP/IMU source unchanged.',
  'third_loan':{'base':'200D0000','bytes':524288,'pinned_ring_bytes':737280,'role':'raw NP source ring; reset-separated download only'},'built':False,'hardware_access':False})
 print('Prepared source-only opt-in pipeline; no build or hardware access.')
def build():
 index=load(HERE/'prepared-inputs.json')['files']
 assert all(digest(TREE/n)==h for n,h in index.items())
 native=load(HERE/'native-final/result.json');assert native['status']=='PASS' and native['pipeline_sha256']==digest(PIPE)
 assert digest(PIPE)==digest(TREE/'Core/Src'/PIPE.name)
 sys.path[:0]=[str(ROOT/'Tools/V2Usb'),str(ROOT/'Tools/V2SdLogger'),str(ROOT/'Tools/Power')]
 from build_np_start_anchor import build as incremental
 from build_checked_np_start_anchor import seal
 import validate_np2_live_sd_memory as ram
 baseline=load(BASE/'incremental-build.json');assert baseline['body_crc32']=='13ED1F8E'
 mapped=(BASE/'application.map').read_text()
 assert re.search(r'(?m)^\s*ring\s+0x200d0000\s+Data\s+737280\s+xe_np_np2_usb_source.o\(NP_CAPTURE\)',mapped)
 flags=baseline['compiler_args_by_unit']['xe_np_usb_stream']
 cleaned=[];i=0
 while i<len(flags):
  if flags[i] in ('-I','-iquote'):
   folder=Path(flags[i+1]).resolve();key=flags[i];i+=2
   if folder in ((INPUTS/'Core/Src').resolve(),(ROOT/'Core/Src').resolve()):continue
   cleaned += [key,str(folder)]
  else:cleaned.append(flags[i]);i+=1
 cleaned+=['-DXE_NP_USB_DOWNLOAD_PIPELINE=1U']
 ram.CMSIS=FROZEN/'Drivers/CMSIS/Device/ST/STM32U5xx/Include/stm32u595xx.h'
 incremental('USB',str(BASE.relative_to(ROOT)),baseline['body_sha256'],{'xe_np_usb_stream':cleaned},
  sources={'xe_np_usb_stream':TREE/'Core/Src/xe_np_usb_stream.c'},includes=[TREE/'Core/Src',FROZEN/'Core/Inc',FROZEN/'Core/Src'],work=HERE/'build')
 out=HERE/'build/usb';r=load(out/'incremental-build.json')
 assert r['reused_object_sha256']['D:/Code/XE_NP_V2/_artifacts/v2_usb_imu_sr_20261013/usb/main.o']=='4DFDB1A929FFE48BAD5A8B9470BF3346D1350895B85EFEDD99F5E3D660B570C4'
 r.update(prepared_inputs_sha256=digest(HERE/'prepared-inputs.json'),native_receipt_sha256=digest(HERE/'native-final/result.json'),
  exact_main_retained=True,app_recovery_settings_changed=False,hardware_access=False,hardware_validated=False,installed=False,published=False,
  scope='Private async-SD/CPU-CRC/USB pipeline; exact EFD main and all non-stream objects retained. Existing eight RAM reservations preserved; third packet borrows the reset-separated raw NP source ring.')
 seal(out,'USB')
 p=out/'timing_candidate.hex';p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
 r.update(hex_sha256=digest(p),manifest_sha256=digest(out/'application.manifest.bin'))
 emit(out/'incremental-build.json',r)
 print('Private candidate '+r['body_crc32']+' bodySHA '+r['body_sha256']+'; not installed or hardware accepted')
if __name__=='__main__':
 if sys.argv[1:]==['--prepare']:prepare()
 elif sys.argv[1:]==['--build']:build()
 else:raise SystemExit('--prepare | --build')
