#ifndef XE_NP_ONLINE_H
#define XE_NP_ONLINE_H
#include <stdint.h>
/* Shared V1/V2 PC-time protocol. RAM mapping only: no RTC/PLL adjustment.
 * The device adapter supplies state and explicit permission to commit. */
#define NP_ONLINE_REQUEST 0x3254504eU
#define NP_ONLINE_REPLY   0x3252504eU
typedef struct {
    uint32_t tick, generation, uncertainty_us, valid, last_id;
    uint64_t utc_us;
    uint8_t last_request[64];
} XE_NP_OnlineClock;
#endif
