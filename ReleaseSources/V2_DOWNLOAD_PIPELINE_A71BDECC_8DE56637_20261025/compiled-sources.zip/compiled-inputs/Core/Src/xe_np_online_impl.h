#ifndef XE_NP_ONLINE_IMPL_H
#define XE_NP_ONLINE_IMPL_H
#include "xe_np_online.h"
#include <string.h>
static inline uint32_t xe_np_online_word(const uint8_t *p)
{return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static inline void xe_np_online_put(uint8_t *p,uint32_t v)
{for(unsigned i=0;i<4;i++)p[i]=(uint8_t)(v>>(8*i));}
static inline uint32_t xe_np_online_crc(const uint8_t *p)
{
    uint32_t c=~0U;
    for(unsigned n=0;n<60;n++){c^=p[n];for(unsigned b=0;b<8;b++)c=(c>>1)^((0U-(c&1U))&0xedb88320U);}
    return ~c;
}
static inline void XE_NP_Online_Init(XE_NP_OnlineClock *c){memset(c,0,sizeof(*c));}
static inline uint64_t XE_NP_Online_Utc(const XE_NP_OnlineClock *c,uint32_t now)
{
    /* A mapping older than half the tick wrap is no longer usable. */
    uint32_t elapsed=now-c->tick;
    return c->valid && elapsed<0x80000000U?c->utc_us+(uint64_t)elapsed*1000U:0;
}
static inline int XE_NP_Online_Exchange(XE_NP_OnlineClock *c,const uint8_t in[64],
    uint8_t out[64],uint32_t received,uint32_t sent,uint32_t state,int can_commit)
{
    if(!c||!in||!out||xe_np_online_word(in)!=NP_ONLINE_REQUEST||xe_np_online_word(in+4)!=1||
       !xe_np_online_word(in+12)||xe_np_online_word(in+60)!=xe_np_online_crc(in))return -1;
    uint32_t op=xe_np_online_word(in+8),id=xe_np_online_word(in+12),error=0;
    for(unsigned i=36;i<60;i++)if(in[i])error=1;
    if(op==0){for(unsigned i=16;i<36;i++)if(in[i])error=1;}
    else if(op==1){
        uint32_t reference=xe_np_online_word(in+16),uncertainty=xe_np_online_word(in+28);
        uint64_t epoch=(uint64_t)xe_np_online_word(in+20)|((uint64_t)xe_np_online_word(in+24)<<32);
        if(id==c->last_id){if(memcmp(in,c->last_request,64))error=6;}
        else if(!error){
            if(!can_commit)error=2;
            else if((uint32_t)(received-reference)>10000U || uncertainty<1000 ||
                uncertainty>5000000 || epoch<1577836800000000ULL || epoch>4102444800000000ULL ||
                xe_np_online_word(in+32)!=c->generation)error=3;
            else{
                c->tick=reference;c->utc_us=epoch;c->uncertainty_us=uncertainty;c->valid=1;
                if(++c->generation==0)c->generation=1;
                c->last_id=id;memcpy(c->last_request,in,64);
            }
        }
    }else error=4;
    memset(out,0,64);
    uint64_t utc=XE_NP_Online_Utc(c,sent);
    uint32_t values[15]={NP_ONLINE_REPLY,1,op,id,error,received,sent,
        c->generation,c->uncertainty_us,utc?1U:0U,(uint32_t)utc,(uint32_t)(utc>>32),state,1000,0};
    for(unsigned i=0;i<15;i++)xe_np_online_put(out+4*i,values[i]);
    xe_np_online_put(out+60,xe_np_online_crc(out));return 0;
}


#endif

