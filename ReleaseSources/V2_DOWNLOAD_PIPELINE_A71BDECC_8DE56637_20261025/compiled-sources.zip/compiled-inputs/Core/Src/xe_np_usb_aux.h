#ifndef XE_NP_USB_AUX_H
#define XE_NP_USB_AUX_H
#include "xe_np_hal.h"
#ifndef XE_NP_V2_AUX_ENABLE
#define XE_NP_V2_AUX_ENABLE 0U
#endif
#if XE_NP_V2_AUX_ENABLE
/* Optional second IN endpoint on the same WinUSB interface. NP2 EP81 and
 * its packet/retention contract are unchanged. Foreground owns all work;
 * callbacks only deliver completion or cancellation tokens. */
#define XE_NP_USB_AUX_EP 0x82U
#define XE_NP_USB_AUX_CAMERA 1U
#define XE_NP_USB_AUX_ADC 2U
#define XE_NP_USB_AUX_IMU 4U
#define XE_NP_USB_AUX_SAFE 256U
#define XE_NP_USB_AUX_AV_ONLY 512U
int XE_NP_UsbAux_Request(PCD_HandleTypeDef *,uint8_t request,uint8_t direction,
                        uint16_t value,uint16_t index,uint16_t length);
int XE_NP_UsbAux_PrepareCombined(void);
void XE_NP_UsbAux_RequestStop(void);
void XE_NP_UsbAux_Service(void);
void XE_NP_UsbAux_Complete(void);
void XE_NP_UsbAux_Interrupted(void);
uint32_t XE_NP_UsbAux_IsBusy(void);
uint32_t XE_NP_UsbAux_IsRunning(void);
uint32_t XE_NP_UsbAux_HoldsVcc(void);
int XE_NP_UsbAux_InitAdc(void);
int XE_NP_Board_SetAvCoreClock(void);
#else
#define XE_NP_UsbAux_PrepareCombined() 0
#define XE_NP_UsbAux_RequestStop() ((void)0)
#define XE_NP_UsbAux_Service() ((void)0)
#define XE_NP_UsbAux_IsBusy() 0U
#define XE_NP_UsbAux_IsRunning() 0U
#define XE_NP_UsbAux_HoldsVcc() 0U
#endif
#endif
