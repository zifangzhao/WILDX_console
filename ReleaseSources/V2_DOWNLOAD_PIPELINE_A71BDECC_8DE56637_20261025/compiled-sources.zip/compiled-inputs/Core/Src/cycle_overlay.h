#include "xe_np_cycle_clock.h"
void XE_NP_Np2CapturePort_CycleClockInit(void);
void XE_NP_Np2CapturePort_CycleClockInvalidate(void);
void XE_NP_Np2CapturePort_GetCycleClock(uint32_t,uint32_t,XE_NP_CycleClockSnapshot *);
