#ifndef XE_NP_USB_TIMING_H
#define XE_NP_USB_TIMING_H
#include "xe_np_online_impl.h"

/* Shared V1/V2 R2. Optional timing records never describe an ADC edge.
 * Token = host-issued HAL-counter lifetime, not a physical boot identifier.
 * Callers serialize state publication; these helpers only encode/check bytes. */
#define NP_TIMING_CONTROL 0x80U
#define NP_TIMING_INFO 0x4954504eUL /* NPTI */
#define NP_TIMING_NEGOTIATE 0x4e54504eUL /* NPTN */
#define NP_TIMING_QUERY 0x5154504eUL /* NPTQ */
#define NP_TIMING_BODY 0x4d54504eUL /* NPTM */
#define NP_TIMING_ENVELOPE 0x4254504eUL /* NPTB */
#define NP_TIMING_BYTES 108U
#define NP_TIMING_VALID 1U
#define NP_TIMING_PREARM 4U
#define NP_TIMING_BUSY_SEEN 8U
#define NP_TIMING_REJECTED_SEEN 16U

static inline uint64_t xe_np_timing_u64(const uint8_t *p)
{return (uint64_t)xe_np_online_word(p)|((uint64_t)xe_np_online_word(p+4U)<<32U);}
static inline void xe_np_timing_put64(uint8_t *p,uint64_t value)
{xe_np_online_put(p,(uint32_t)value);xe_np_online_put(p+4U,(uint32_t)(value>>32U));}
static inline int xe_np_timing_zero(const uint8_t *p,uint32_t start,uint32_t end)
{for(uint32_t i=start;i<end;i++)if(p[i])return 0;return 1;}
static inline int xe_np_timing_frame(const uint8_t *p,uint32_t magic,uint32_t op)
{return xe_np_online_word(p)==magic && xe_np_online_word(p+4U)==(1U|(op<<16U)) &&
        xe_np_online_word(p+60U)==xe_np_online_crc(p);}
static inline int xe_np_timing_negotiate(const uint8_t p[64],const uint32_t uid[3])
{
    uint32_t op=xe_np_online_word(p+4U)>>16U;
    return op<=1U && xe_np_timing_frame(p,NP_TIMING_NEGOTIATE,op) &&
        (op?xe_np_timing_u64(p+8U)!=0U:xe_np_timing_u64(p+8U)==0U) &&
        !memcmp(p+16U,uid,12U) && xe_np_timing_zero(p,28U,60U);
}
static inline int xe_np_timing_query(const uint8_t p[64],uint64_t token,
                                    uint32_t generation,uint32_t last_id)
{
    /* A high-water ID is bounded replay/reorder detection. No ID wrap/reuse
     * within a token; the host negotiates a new token before UINT32_MAX. */
    return xe_np_timing_frame(p,NP_TIMING_QUERY,1U) &&
        xe_np_online_word(p+8U)>last_id && !xe_np_online_word(p+12U) &&
        xe_np_timing_u64(p+16U)==token && token &&
        xe_np_online_word(p+24U)==generation && xe_np_timing_zero(p,28U,60U);
}
static inline uint32_t xe_np_timing_crc104(const uint8_t *p)
{
    uint32_t c=~0U;
    for(uint32_t n=0U;n<104U;n++){
        c^=p[n];for(unsigned b=0U;b<8U;b++)c=(c>>1)^((0U-(c&1U))&0xedb88320U);
    }
    return ~c;
}
static inline void xe_np_timing_ms_body(uint8_t p[64],uint32_t id,uint32_t flags,
    uint32_t generation,uint32_t received,uint32_t sealed,const uint32_t uid[3])
{
    const uint32_t w[15]={NP_TIMING_BODY,1U,id,flags|(2U<<8U),0U,generation,
        received,sealed,0U,0U,1000U,0U,uid[0],uid[1],uid[2]};
    for(unsigned i=0U;i<15U;i++)xe_np_online_put(p+4U*i,w[i]);
    xe_np_online_put(p+60U,xe_np_online_crc(p));
}
static inline void xe_np_timing_wrap(uint8_t p[NP_TIMING_BYTES],uint32_t kind,
    uint64_t token,uint32_t generation,const uint32_t uid[3],uint64_t sequence,
    const uint8_t body[64])
{
    xe_np_online_put(p,NP_TIMING_ENVELOPE);xe_np_online_put(p+4U,1U|(kind<<16U));
    xe_np_timing_put64(p+8U,token);xe_np_online_put(p+16U,generation);
    memcpy(p+20U,uid,12U);xe_np_timing_put64(p+32U,sequence);memcpy(p+40U,body,64U);
    xe_np_online_put(p+104U,xe_np_timing_crc104(p));
}
#endif
