#ifndef XE_NP_CYCLE_CLOCK_H
#define XE_NP_CYCLE_CLOCK_H
#include "xe_np_online_impl.h"

/* Optional C0/7F,64B, nonzero ID=wValue|(wIndex<<16). No BLE contract here.
 * Host must use fresh IDs across reconnect/reset and never reuse a domain token.
 * Tokens are software counter-lifetime evidence, NOT hardware boot identifiers.
 * No pre-query/root token => no precise mapping. NPAR/SDUTC2 stay unchanged. */
#define NP_CYCLE_REPLY 0x5248504eUL /* NPHR */
#define NP_CYCLE_VALID 1U
#define NP_CYCLE_CONTINUOUS 2U
#define NP_CYCLE_ANCHOR_SAME 4U
typedef struct {
    uint32_t token,hz,anchor_token,anchor_generation;
} XE_NP_CycleClockState;
typedef struct {
    uint32_t flags,token,generation,ms_before,ms_after;
    uint32_t cycles_before,cycles_after,hz,anchor_token;
} XE_NP_CycleClockSnapshot;

static inline void XE_NP_CycleClock_Invalidate(XE_NP_CycleClockState *s)
{s->token=0U;s->hz=0U;}
static inline void XE_NP_CycleClock_Anchor(XE_NP_CycleClockState *s,
    uint32_t generation,uint32_t hz,uint32_t cycles_valid)
{
    if(!cycles_valid || s->hz!=hz)XE_NP_CycleClock_Invalidate(s);
    s->anchor_generation=generation;
    s->anchor_token=s->token;
}
static inline uint32_t XE_NP_CycleClock_Observe(XE_NP_CycleClockState *s,
    uint32_t id,uint32_t hz,uint32_t enabled,uint32_t continuous,
    uint32_t generation,uint32_t anchor_valid)
{
    if(!id || !hz || !enabled || !continuous){XE_NP_CycleClock_Invalidate(s);return 0U;}
    if(s->hz!=hz)XE_NP_CycleClock_Invalidate(s);
    s->hz=hz;if(!s->token)s->token=id;
    return NP_CYCLE_VALID|NP_CYCLE_CONTINUOUS|
        (anchor_valid && s->anchor_token && s->anchor_token==s->token &&
         s->anchor_generation==generation?NP_CYCLE_ANCHOR_SAME:0U);
}
static inline void XE_NP_CycleClock_Reply(const XE_NP_CycleClockSnapshot *s,
    uint32_t id,const uint32_t uid[3],uint8_t out[64])
{
    const uint32_t w[15]={NP_CYCLE_REPLY,1U,id,s->flags,s->token,s->generation,
        s->ms_before,s->ms_after,s->cycles_before,s->cycles_after,s->hz,
        s->anchor_token,uid[0],uid[1],uid[2]};
    for(unsigned i=0U;i<15U;i++)xe_np_online_put(out+4U*i,w[i]);
    xe_np_online_put(out+60U,xe_np_online_crc(out));
}
#endif
