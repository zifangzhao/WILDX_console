#include "xe_np_acquisition_anchor.h"
int XE_NP_Np2CapturePort_GetAnchor(XE_NP_AcquisitionAnchor *);
