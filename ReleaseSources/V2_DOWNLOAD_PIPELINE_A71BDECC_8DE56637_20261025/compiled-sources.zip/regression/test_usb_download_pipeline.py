"""Host-only extraction test for the opt-in V2 three-bank download pipeline."""
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[3]
VC = Path("C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat")

MODEL = r'''
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define __attribute__(x)
typedef enum {HAL_OK,HAL_ERROR,HAL_BUSY,HAL_TIMEOUT} HAL_StatusTypeDef;
typedef uint32_t IRQn_Type;
typedef struct {uint32_t IDMACTRL,STA,DCTRL,DCOUNT,RESPCMD,RESP1;} SDMMC_TypeDef;
typedef struct {SDMMC_TypeDef *Instance;uint32_t State,Context,ErrorCode; struct {uint32_t LogBlockNbr;} SdCard;} SD_HandleTypeDef;
typedef struct {int unused;} DCACHE_HandleTypeDef;
typedef struct {void *Instance;} PCD_HandleTypeDef; typedef struct {uint32_t DIEPCTL,DIEPINT;} USB_OTG_INEndpointTypeDef;
#define USB_OTG_IN_ENDPOINT_BASE 0U
#define USB_OTG_EP_REG_SIZE 0U
#define USB_OTG_DIEPCTL_EPENA 1U
enum {HAL_SD_STATE_READY=1U,HAL_SD_CARD_TRANSFER=4U,HAL_SD_ERROR_NONE=0U,HAL_SD_ERROR_DATA_CRC_FAIL=2U,HAL_SD_ERROR_DATA_TIMEOUT=8U,HAL_SD_ERROR_RX_OVERRUN=0x20U,HAL_SD_ERROR_GENERAL_UNKNOWN_ERR=0x10000U,HAL_SD_ERROR_DMA=0x40000000U,HAL_SD_ERROR_TIMEOUT=0x80000000U};
enum {SDMMC_STA_DPSMACT=1U,SDMMC_STA_CPSMACT=2U,SDMMC_STA_BUSYD0=4U,SDMMC_FLAG_DCRCFAIL=8U,SDMMC_FLAG_DTIMEOUT=16U,SDMMC_FLAG_RXOVERR=32U,SDMMC_FLAG_IDMATE=64U,SDMMC_FLAG_DATAEND=128U,SDMMC_DCTRL_DTEN=1U,SDMMC1_IRQn=49U,XE_NP_USB_STREAM_IN_EP=0x81U};
#define SDMMC1 (&peripheral)
#define __DMB() ((void)0)
#define __DSB() ((void)0)
static SDMMC_TypeDef peripheral; static USB_OTG_INEndpointTypeDef endpoint; static PCD_HandleTypeDef pcd;
static SD_HandleTypeDef hsd1;
static DCACHE_HandleTypeDef hdcache1;
__declspec(align(32)) static uint8_t np_download0[32U+1020U*512U],np_download1[32U+1020U*512U],np_third[32U+1020U*512U];
static struct {uint32_t configured,tx_busy;PCD_HandleTypeDef *hpcd;} xe_np_usb_state;
static struct {uint32_t valid;} np_download_prefetch;
static volatile uint32_t np_download_state,np_download_slot,np_download_epoch,np_download_sequence;
static uint32_t np_download_burst_remaining,np_download_burst_armed,np_download_lba,np_download_next_lba,np_download_tx_tick,np_download_perf[8],xe_np_usb_download_crc_diag[4];
static uint32_t tick,read_calls,irq_calls,clean_calls,clean_payload_bytes,tx_clean_calls,tx_clean_bytes,invalidate_calls,tx_calls,legacy_reset,legacy_complete,nv_enabled,download_mode=1U,crc_reset_once;
static uint32_t __get_PRIMASK(void){return 0U;} static void __disable_irq(void){} static void __set_PRIMASK(uint32_t x){(void)x;}
static uint32_t HAL_GetTick(void){return ++tick;} static int NVIC_GetEnableIRQ(IRQn_Type x){assert(x==SDMMC1_IRQn);return (int)nv_enabled;} static void NVIC_DisableIRQ(IRQn_Type x){assert(x==SDMMC1_IRQn);nv_enabled=0U;} static void NVIC_EnableIRQ(IRQn_Type x){assert(x==SDMMC1_IRQn);nv_enabled=1U;} static void NVIC_ClearPendingIRQ(IRQn_Type x){assert(x==SDMMC1_IRQn);}
static int XE_NP_UsbUnified_IsDownload(void){return (int)download_mode;} static uint32_t NP_SD_DownloadCapacity(void){return hsd1.SdCard.LogBlockNbr;} static uint8_t *NP_SD_DownloadBuffer(unsigned n){return n?np_download1:np_download0;}
static int xe_np_usb_download_retry_idle(uint32_t cap){return cap==hsd1.SdCard.LogBlockNbr && hsd1.State==HAL_SD_STATE_READY && !hsd1.Context && !peripheral.IDMACTRL && !(peripheral.DCTRL&SDMMC_DCTRL_DTEN);}
static HAL_StatusTypeDef HAL_DCACHE_CleanByAddr(DCACHE_HandleTypeDef *c,const uint32_t *p,uint32_t n){assert(c==&hdcache1 && !((uintptr_t)p&31U) && n && !(n&511U));++clean_calls;clean_payload_bytes+=n;return HAL_OK;}
static HAL_StatusTypeDef HAL_DCACHE_InvalidateByAddr(DCACHE_HandleTypeDef *c,const uint32_t *p,uint32_t n){assert(c==&hdcache1 && !((uintptr_t)p&31U) && n && !(n&511U));++invalidate_calls;return HAL_OK;}
static HAL_StatusTypeDef HAL_SD_ReadBlocks_DMA(SD_HandleTypeDef *c,uint8_t *p,uint32_t lba,uint32_t blocks){assert(c==&hsd1 && blocks && blocks<=1020U && lba+blocks<=c->SdCard.LogBlockNbr);++read_calls;memset(p,0x5a,blocks*512U);c->State=2U;c->Context=1U;peripheral.IDMACTRL=1U;peripheral.DCTRL=SDMMC_DCTRL_DTEN;peripheral.DCOUNT=blocks*512U;return HAL_OK;}
static void HAL_SD_IRQHandler(SD_HandleTypeDef *c){assert(c==&hsd1);++irq_calls;c->State=HAL_SD_STATE_READY;c->Context=0U;peripheral.IDMACTRL=peripheral.DCTRL=peripheral.DCOUNT=0U;}
static uint32_t HAL_SD_GetCardState(SD_HandleTypeDef *c){assert(c==&hsd1);peripheral.RESPCMD=13U;peripheral.RESP1=1U<<8U;return 4U;}
static void NP_SD_UsbReset(void);
static uint32_t np_download_crc(const uint8_t *p,uint32_t n){(void)p;if(crc_reset_once && n>28U){crc_reset_once=0U;NP_SD_UsbReset();}return 0x12345678U;} static int np_download_crc_test(void){return 1;}
static void XE_NP_UsbStream_DCacheCleanTx(uint8_t *p,uint32_t n){assert(p && !((uintptr_t)p&31U) && n==32U);++tx_clean_calls;tx_clean_bytes=n;} static void XE_NP_UsbStream_AbortBulkInTransfer(void){}
static HAL_StatusTypeDef HAL_PCD_EP_Transmit(PCD_HandleTypeDef *p,uint8_t ep,uint8_t *data,uint32_t n){(void)p;assert(ep==XE_NP_USB_STREAM_IN_EP && n>=32U);++tx_calls;assert(((uint32_t *)data)[0]==0x3142504eU);return HAL_OK;}
static void NP_SD_UsbResetLegacy(void){++legacy_reset;} static void NP_SD_UsbCompleteLegacy(void){++legacy_complete;xe_np_usb_state.tx_busy=0U;}
#include "pipeline_actual.inc"
static void fresh(void){memset(&peripheral,0,sizeof(peripheral));memset(&hsd1,0,sizeof(hsd1));memset(np_download0,0,sizeof(np_download0));memset(np_download1,0,sizeof(np_download1));memset(np_third,0,sizeof(np_third));memset(&np_download_prefetch,0,sizeof(np_download_prefetch));memset(np_download_perf,0,sizeof(np_download_perf));memset(xe_np_usb_download_crc_diag,0,sizeof(xe_np_usb_download_crc_diag));memset(&np_pipe,0,sizeof(np_pipe));hsd1.Instance=SDMMC1;hsd1.State=HAL_SD_STATE_READY;pcd.Instance=&endpoint;xe_np_usb_state.hpcd=&pcd;hsd1.SdCard.LogBlockNbr=2048U;xe_np_usb_state.configured=1U;download_mode=1U;nv_enabled=1U;np_pipe.tx=np_pipe.read=NP_PIPE_NONE;np_download_state=np_download_slot=np_download_epoch=np_download_sequence=np_download_burst_remaining=np_download_burst_armed=np_download_lba=np_download_next_lba=np_download_tx_tick=0U;tick=read_calls=irq_calls=clean_calls=clean_payload_bytes=tx_clean_calls=tx_clean_bytes=invalidate_calls=tx_calls=legacy_reset=legacy_complete=crc_reset_once=0U;}
static void demand(uint32_t lba){np_download_lba=lba;np_download_state=1U;NP_SD_UsbService();assert(np_download_state==2U && np_pipe.read<3U && np_download_prefetch.valid);}
static void settle(uint32_t error){hsd1.State=HAL_SD_STATE_READY;hsd1.Context=0U;peripheral.IDMACTRL=peripheral.DCTRL=peripheral.DCOUNT=0U;hsd1.ErrorCode=error;NP_SD_UsbService();}
static void to_usb(uint32_t error){settle(error);NP_SD_UsbService();assert(np_download_state==3U && np_pipe.tx<3U && np_pipe.slot[np_pipe.tx].state==NP_PIPE_USB);}
int main(void){
 fresh();demand(0U);assert(read_calls==1U && np_pipe.read==0U && xe_np_usb_download_pipeline_diag[6]==1U && clean_calls==1U && clean_payload_bytes==1020U*512U && !tx_clean_calls);settle(0U);assert(read_calls==2U && np_pipe.tx==0U && np_pipe.slot[0].state==NP_PIPE_USB && np_pipe.read==1U && np_download_state==3U && tx_clean_calls==1U && tx_clean_bytes==32U && xe_np_usb_download_pipeline_diag[4]==1U);NP_SD_UsbComplete();assert(legacy_complete==1U && np_pipe.slot[0].state==NP_PIPE_FREE);
 /* A real next-LBA request promotes legacy one-ahead only after prior delivery; a seek demotes it. */
 np_download_lba=1020U;np_download_state=1U;NP_SD_UsbService();assert(np_pipe.sequential && xe_np_usb_download_pipeline_diag[2]==1U);settle(0U);assert(xe_np_usb_download_pipeline_diag[7]>=1U);np_download_lba=0U;np_download_state=1U;NP_SD_UsbService();assert(!np_pipe.sequential && xe_np_usb_download_pipeline_diag[3]==1U);
 fresh();demand(2043U);assert(np_pipe.slot[np_pipe.read].blocks==5U);to_usb(0U);assert(((uint32_t *)np_pipe_buffer(np_pipe.tx))[3]==5U);
 fresh();demand(0U);to_usb(HAL_SD_ERROR_DATA_TIMEOUT);assert(((uint32_t *)np_pipe_buffer(np_pipe.tx))[3]==0U && ((int32_t *)np_pipe_buffer(np_pipe.tx))[4]==-2);
 fresh();demand(0U);settle(HAL_SD_ERROR_DATA_CRC_FAIL);assert(read_calls==2U && np_pipe.retry==1U && xe_np_usb_download_crc_diag[0]==1U);settle(0U);NP_SD_UsbService();assert(xe_np_usb_download_crc_diag[1]==1U);
 /* A far backwards seek frees only retired speculative cache; an in-flight destination retains its loan. */
 fresh();hsd1.SdCard.LogBlockNbr=8192U;demand(1020U);np_pipe.slot[2].state=NP_PIPE_READY;np_pipe.slot[2].epoch=np_download_epoch;np_pipe.slot[2].lba=5100U;np_pipe.slot[2].blocks=1020U;demand(0U);assert(np_pipe.request_lba==0U && np_pipe.read<3U && (np_pipe.slot[2].state==NP_PIPE_FREE || (np_pipe.slot[2].state==NP_PIPE_READING && np_pipe.slot[2].epoch==np_download_epoch && np_pipe.slot[2].lba==0U)));
 fresh();demand(0U);np_pipe.have_prior=np_pipe.sequential=1U;NP_SD_UsbReset();NP_SD_UsbService();assert(np_download_state==4U && np_download_prefetch.valid);settle(0U);NP_SD_UsbService();assert(np_download_state==0U && !np_download_prefetch.valid && !np_pipe.have_prior && !np_pipe.sequential && legacy_reset==1U);NP_SD_UsbComplete();assert(!legacy_complete);
 fresh();demand(0U);to_usb(0U);endpoint.DIEPCTL=USB_OTG_DIEPCTL_EPENA;NP_SD_UsbReset();NP_SD_UsbService();assert(np_download_state==4U && np_download_prefetch.valid);endpoint.DIEPCTL=0U;settle(0U);assert(np_download_state==0U && endpoint.DIEPINT==0xFB7FU);
 /* Reset inside the actual CPU CRC leaves the completed bank unpublished; the next old-host demand reopens only after idle. */
 fresh();demand(0U);crc_reset_once=1U;settle(0U);assert(np_download_state==4U && np_pipe.slot[0].state==NP_PIPE_CRC);NP_SD_UsbService();assert(np_download_state==4U && np_download_prefetch.valid);settle(0U);NP_SD_UsbService();assert(np_download_state==0U && !np_download_prefetch.valid);demand(1020U);assert(np_pipe.request_lba==1020U && np_pipe.read<3U);
 /* A real retired READY cache is cancelled without publication; maintenance independently discards a cache under a new epoch. */
 fresh();demand(0U);settle(0U);settle(0U);assert(np_pipe.slot[1].state==NP_PIPE_READY);NP_SD_UsbReset();settle(0U);assert(np_download_state==0U && !np_download_prefetch.valid);demand(1020U);assert(np_pipe.request_lba==1020U && np_pipe.read<3U);
 fresh();np_download_epoch=7U;np_pipe.epoch=7U;np_pipe.have_prior=np_pipe.sequential=1U;np_pipe.slot[0].state=NP_PIPE_READY;np_pipe.slot[0].epoch=7U;np_download_prefetch.valid=1U;assert(np_pipe_maintenance_idle()==1 && np_download_epoch==8U && np_pipe.slot[0].state==NP_PIPE_FREE && !np_download_prefetch.valid && !np_pipe.have_prior && !np_pipe.sequential);demand(0U);assert(np_pipe.request_lba==0U && np_pipe.read<3U);
 /* Explicit bounded plan fills exactly the three owned pipeline stages. */
 fresh();np_download_burst_remaining=3U;demand(0U);settle(0U);settle(0U);assert(xe_np_usb_download_pipeline_diag[1]==3U && np_pipe.slot[0].state==NP_PIPE_USB && np_pipe.slot[1].state==NP_PIPE_READY && np_pipe.slot[2].state==NP_PIPE_READING);
 fresh();download_mode=0U;NP_SD_UsbService();assert(!read_calls && !tx_calls);
 puts("PASS extracted pipeline: header-only clean, legacy/sequential staging, bounded three-stage plan, CRC/READY cancellation, maintenance epoch discard and idle reopen");return 0;}
'''


class DownloadPipelineTests(unittest.TestCase):
    def test_actual_pipeline(self):
        source = (ROOT / 'Core/Src/xe_np_usb_download_pipeline.inc').read_text()
        self.assertEqual(source.count('(uint8_t *)0x200D0000U'), 1)
        source = source.replace('(uint8_t *)0x200D0000U', 'np_third')
        with tempfile.TemporaryDirectory(prefix='v2-download-pipeline-') as temp:
            out = Path(temp)
            (out / 'pipeline_actual.inc').write_text(source)
            (out / 'test.c').write_text(MODEL)
            command = (f'call "{VC}" >nul && cl /nologo /std:c11 /TC /O2 /W4 /WX /wd4100 /DXE_NP_USB_UNIFIED_ENABLE=1 /DXE_NP_USB_DOWNLOAD_IDMA_READ_ENABLE=1 /DNP_SD_USB_READ_BLOCKS=1020 '
                       f'/I"{out}" "{out / "test.c"}" /Fe"{out / "pipeline.exe"}"')
            result = subprocess.run(f'cmd /d /s /c "{command}"', capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            subprocess.run([str(out / 'pipeline.exe')], check=True)


if __name__ == '__main__':
    unittest.main()