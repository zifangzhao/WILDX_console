#include "xe_np_np2_dual_sd_run.h"
#include <limits.h>

_Static_assert(XE_NP_NP2_DUAL_SD_BYTES_PER_BLOCK ==
               XE_NP_NP2_DUAL_SD_SECTORS_PER_BLOCK*512U,
               "NP2 dual stream block must be sector aligned");
_Static_assert(XE_NP_NP2_DUAL_SD_SECTORS_PER_RU ==
               XE_NP_NP2_DUAL_SD_SECTORS_PER_BLOCK*XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU,
               "NP2 dual CMD25 unit changed");

uint32_t XE_NP_Np2DualSd_ProfileTicks(uint32_t mask,uint32_t sample_hz)
{
    if(sample_hz!=7500U && sample_hz!=15000U && sample_hz!=20000U && sample_hz!=30000U)return 0U;
    if(mask==1U)return XE_NP_NP2_SINGLE_SD_TICKS_PER_BLOCK;
    if(mask==3U)return XE_NP_NP2_DUAL_SD_TICKS_PER_BLOCK;
    if(mask==7U)return XE_NP_NP2_TRIPLE_SD_TICKS_PER_BLOCK;
    return 0U;
}

int XE_NP_Np2DualSd_Plan(uint32_t sample_hz,uint32_t start,uint32_t end,
                        uint32_t card_blocks,XE_NP_Np2DualSdRun *out)
{return XE_NP_Np2DualSd_PlanProfile(3U,sample_hz,start,end,card_blocks,out);}

int XE_NP_Np2DualSd_PlanProfile(uint32_t mask,uint32_t sample_hz,uint32_t start,
                               uint32_t end,uint32_t card_blocks,XE_NP_Np2DualSdRun *out)
{
    uint32_t ticks=XE_NP_Np2DualSd_ProfileTicks(mask,sample_hz);
    if(!out || !ticks || start<8192U ||
       end<=start || end>card_blocks)return -1;
    uint32_t rus=(end-start)/XE_NP_NP2_DUAL_SD_SECTORS_PER_RU;
    if(!rus || rus>UINT32_MAX/XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU)return -1;
    uint32_t blocks=rus*XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU;
    uint32_t mclk=sample_hz*1600U;
    out->probe_mask=mask;out->sample_hz=sample_hz;out->mclk_hz=mclk;
    out->payload_start_lba=start;
    out->payload_end_lba=start+rus*XE_NP_NP2_DUAL_SD_SECTORS_PER_RU;
    out->max_rus=rus;out->max_blocks=blocks;
    out->max_source_ticks=(uint64_t)blocks*ticks;
    out->max_duration_ms=out->max_source_ticks*1000U/mclk;
    return 0;
}

uint32_t XE_NP_Np2DualSd_StopTarget(uint32_t produced,uint32_t partial,
                                    uint64_t sampled_ticks,
                                    const XE_NP_Np2DualSdRun *run)
{
    if(!run)return 0U;
    uint32_t ticks=XE_NP_Np2DualSd_ProfileTicks(run->probe_mask,run->sample_hz);
    if(!ticks || run->mclk_hz!=run->sample_hz*1600U ||
       run->max_source_ticks!=(uint64_t)run->max_blocks*ticks ||
       run->max_blocks<XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU ||
       run->max_blocks%XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU ||
       run->max_rus!=run->max_blocks/XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU ||
       produced>run->max_blocks || (partial && produced==run->max_blocks) ||
       sampled_ticks>run->max_source_ticks)return 0U;
    uint32_t needed=produced+(partial!=0U);
    uint64_t sampled_blocks=sampled_ticks/ticks+(sampled_ticks%ticks!=0U);
    if(sampled_blocks>needed)needed=(uint32_t)sampled_blocks;
    if(!needed)needed=1U;
    uint32_t units=needed/XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU;
    if(needed%XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU)units++;
    if(units>run->max_rus)return 0U;
    return units*XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU;
}
