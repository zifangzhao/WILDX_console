#include "xe_np_np2_sd_append.h"
#include "xe_np_np2_usb_wire.h"
#include <string.h>

static uint32_t read32(const uint8_t *p)
{return (uint32_t)p[0]|((uint32_t)p[1]<<8U)|((uint32_t)p[2]<<16U)|((uint32_t)p[3]<<24U);}
static void write32(uint8_t *p,uint32_t v)
{p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8U);p[2]=(uint8_t)(v>>16U);p[3]=(uint8_t)(v>>24U);}
uint32_t XE_NP_Np2DualSd_Crc32(const uint8_t *p,uint32_t count)
{
    static const uint32_t table[16]={0U,0x1DB71064U,0x3B6E20C8U,0x26D930ACU,
        0x76DC4190U,0x6B6B51F4U,0x4DB26158U,0x5005713CU,0xEDB88320U,
        0xF00F9344U,0xD6D6A3E8U,0xCB61B38CU,0x9B64C2B0U,0x86D3D2D4U,
        0xA00AE278U,0xBDBDF21CU};
    uint32_t c=UINT32_MAX;
    while(count--){c^=*p++;c=(c>>4U)^table[c&15U];c=(c>>4U)^table[c&15U];}
    return ~c;
}
static int legacy_au_valid(uint32_t blocks)
{
    static const uint32_t units[]={2048U,4096U,8192U,16384U,24576U,32768U,
                                   49152U,65536U,131072U};
    for(uint32_t i=0U;i<sizeof(units)/sizeof(units[0]);i++)if(blocks==units[i])return 1;
    return 0;
}
static int valid_meta(const XE_NP_Np2DualSdMeta *m)
{
    XE_NP_Np2DualSdRun expected;
    if(!m || !m->session_id || m->reservation_start_lba<8192U ||
       m->reservation_start_lba%8192U || m->reservation_end_lba%16384U ||
       m->reservation_end_lba>m->card_blocks)return 0;
    uint64_t header_start=(uint64_t)m->reservation_start_lba+8192U;
    uint64_t payload=header_start+((0U-header_start)&16383U);
    if(m->au_blocks && m->legacy_au_blocks)return 0;
    uint32_t unit=m->au_blocks?m->au_blocks:m->legacy_au_blocks;
    uint32_t limit=m->reservation_end_lba;
    if(unit){
        if((m->au_blocks && (unit<1024U || unit%1024U)) ||
           (m->legacy_au_blocks && !legacy_au_valid(unit)))return 0;
        payload=((payload+unit-1U)/unit)*unit;
        uint64_t au_end=((uint64_t)m->run.payload_end_lba+unit-1U)/unit*unit;
        uint64_t allocation=(au_end+16383U)&~UINT64_C(16383);
        if(payload>=m->run.payload_end_lba || allocation!=m->reservation_end_lba ||
           (m->au_blocks && (payload/1024U>0x3FFFFFU ||
                             (au_end-unit)/1024U>0x3FFFFFU)))return 0;
        limit=m->run.payload_end_lba; /* Exact recording bound, not unused AU tail. */
    }
    if(payload>=limit || payload!=m->run.payload_start_lba ||
       XE_NP_Np2DualSd_PlanProfile(m->run.probe_mask,m->run.sample_hz,
                                  (uint32_t)payload,limit,m->card_blocks,&expected))return 0;
    return m->run.mclk_hz==expected.mclk_hz &&
           m->run.payload_end_lba==expected.payload_end_lba &&
           m->run.max_blocks==expected.max_blocks && m->run.max_rus==expected.max_rus &&
           m->run.max_source_ticks==expected.max_source_ticks &&
           m->run.max_duration_ms==expected.max_duration_ms;
}
static int seal_valid(const uint8_t sector[512])
{
    if(!sector || read32(sector+508U)!=XE_NP_Np2DualSd_Crc32(sector,508U))return 0;
    uint32_t version=read32(sector+8U);
    if(version!=XE_NP_NP2_DUAL_SD_META_VERSION && version!=XE_NP_NP2_DUAL_SD_META_AU_VERSION &&
       version!=XE_NP_NP2_DUAL_SD_META_LEGACY_AU_VERSION)return 0;
    for(uint32_t i=version==XE_NP_NP2_DUAL_SD_META_VERSION?128U:132U;i<508U;i++)if(sector[i])return 0;
    return 1;
}

int XE_NP_Np2DualSd_EncodeDescriptor(uint8_t out[512],const XE_NP_Np2DualSdMeta *m)
{
    if(!out || !valid_meta(m))return -1;
    memset(out,0,512U);memcpy(out,"N2SDLOG1",8U);
    uint32_t version=m->au_blocks?XE_NP_NP2_DUAL_SD_META_AU_VERSION:
                     m->legacy_au_blocks?XE_NP_NP2_DUAL_SD_META_LEGACY_AU_VERSION:
                     XE_NP_NP2_DUAL_SD_META_VERSION;
    write32(out+8U,version);
    write32(out+12U,m->session_id);write32(out+16U,m->run.sample_hz);
    write32(out+20U,m->run.mclk_hz);write32(out+24U,m->run.probe_mask);
    write32(out+28U,XE_NP_Np2UsbV3_WireMask(m->run.probe_mask));
    write32(out+32U,m->run.probe_mask==7U?XE_NP_NP2_USB_V3_CODEC_PSSI8_SPI_D8:
                                         XE_NP_NP2_USB_V3_CODEC_PACKED);
    write32(out+36U,m->run.probe_mask==1U?3U:m->run.probe_mask==3U?6U:9U);
    write32(out+40U,XE_NP_NP2_DUAL_SD_BYTES_PER_BLOCK);
    write32(out+44U,XE_NP_Np2DualSd_ProfileTicks(m->run.probe_mask,m->run.sample_hz));
    write32(out+48U,XE_NP_NP2_DUAL_SD_SECTORS_PER_BLOCK);
    write32(out+52U,XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU);
    write32(out+56U,m->reservation_start_lba);
    write32(out+60U,m->run.payload_start_lba);
    write32(out+64U,m->run.payload_end_lba);
    write32(out+68U,m->reservation_end_lba);
    write32(out+72U,m->card_blocks);write32(out+76U,m->config_crc);
    for(uint32_t i=0U;i<4U;i++)write32(out+80U+4U*i,m->cid[i]);
    write32(out+96U,m->au_blocks?31U:m->legacy_au_blocks?47U:15U);
    write32(out+100U,XE_NP_NP2_DUAL_SD_META_RESERVED);
    if(m->au_blocks || m->legacy_au_blocks)write32(out+128U,m->au_blocks?m->au_blocks:m->legacy_au_blocks);
    write32(out+508U,XE_NP_Np2DualSd_Crc32(out,508U));return 0;
}

int XE_NP_Np2DualSd_DecodeDescriptor(const uint8_t sector[512],XE_NP_Np2DualSdMeta *out)
{
    if(!out || !seal_valid(sector) || memcmp(sector,"N2SDLOG1",8U))return -1;
    uint32_t version=read32(sector+8U);
    uint32_t flags=version==XE_NP_NP2_DUAL_SD_META_AU_VERSION?31U:
                   version==XE_NP_NP2_DUAL_SD_META_LEGACY_AU_VERSION?47U:15U;
    if(read32(sector+40U)!=XE_NP_NP2_DUAL_SD_BYTES_PER_BLOCK ||
       read32(sector+48U)!=XE_NP_NP2_DUAL_SD_SECTORS_PER_BLOCK ||
       read32(sector+52U)!=XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU ||
       read32(sector+96U)!=flags ||
       read32(sector+100U)!=XE_NP_NP2_DUAL_SD_META_RESERVED ||
       read32(sector+104U) || read32(sector+108U) || read32(sector+112U) ||
       read32(sector+116U) || read32(sector+120U) || read32(sector+124U))return -1;
    uint32_t mask=read32(sector+24U);
    uint32_t ticks=XE_NP_Np2DualSd_ProfileTicks(mask,read32(sector+16U));
    if(!ticks || read32(sector+28U)!=XE_NP_Np2UsbV3_WireMask(mask) ||
       read32(sector+32U)!=(mask==7U?XE_NP_NP2_USB_V3_CODEC_PSSI8_SPI_D8:
                                   XE_NP_NP2_USB_V3_CODEC_PACKED) ||
       read32(sector+36U)!=(mask==1U?3U:mask==3U?6U:9U) || read32(sector+44U)!=ticks)return -1;
    XE_NP_Np2DualSdMeta m={0};
    if(version==XE_NP_NP2_DUAL_SD_META_AU_VERSION){
        m.au_blocks=read32(sector+128U);if(!m.au_blocks)return -1;
    }else if(version==XE_NP_NP2_DUAL_SD_META_LEGACY_AU_VERSION){
        m.legacy_au_blocks=read32(sector+128U);if(!legacy_au_valid(m.legacy_au_blocks))return -1;
    }
    m.session_id=read32(sector+12U);m.run.probe_mask=mask;m.run.sample_hz=read32(sector+16U);
    m.run.mclk_hz=read32(sector+20U);
    m.reservation_start_lba=read32(sector+56U);
    m.run.payload_start_lba=read32(sector+60U);
    m.run.payload_end_lba=read32(sector+64U);
    m.reservation_end_lba=read32(sector+68U);
    m.card_blocks=read32(sector+72U);m.config_crc=read32(sector+76U);
    for(uint32_t i=0U;i<4U;i++)m.cid[i]=read32(sector+80U+4U*i);
    if(XE_NP_Np2DualSd_PlanProfile(mask,m.run.sample_hz,m.run.payload_start_lba,
                                   (m.au_blocks||m.legacy_au_blocks)?m.run.payload_end_lba:m.reservation_end_lba,m.card_blocks,&m.run) ||
       m.run.mclk_hz!=read32(sector+20U) ||
       m.run.payload_end_lba!=read32(sector+64U) || !valid_meta(&m))return -1;
    *out=m;return 0;
}

int XE_NP_Np2DualSd_EncodeFooter(uint8_t out[512],const XE_NP_Np2DualSdMeta *m,
                                 uint32_t state,uint32_t error,uint32_t blocks)
{
    if(!out || !valid_meta(m) || blocks>m->run.max_blocks ||
       blocks%XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU ||
       (state==XE_NP_NP2_DUAL_SD_META_COMPLETE && (!blocks || error)) ||
       (state==XE_NP_NP2_DUAL_SD_META_FAILED && !error) ||
       (state==XE_NP_NP2_DUAL_SD_META_RESERVED && (blocks || !error)) ||
       (state!=XE_NP_NP2_DUAL_SD_META_COMPLETE &&
        state!=XE_NP_NP2_DUAL_SD_META_FAILED &&
        state!=XE_NP_NP2_DUAL_SD_META_RESERVED))return -1;
    if(XE_NP_Np2DualSd_EncodeDescriptor(out,m))return -1;
    memcpy(out,"N2SDEND1",8U);write32(out+100U,state);write32(out+104U,error);
    write32(out+108U,blocks);
    write32(out+112U,blocks/XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU);
    write32(out+116U,m->run.payload_start_lba+
            (blocks/XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU)*XE_NP_NP2_DUAL_SD_SECTORS_PER_RU);
    uint64_t ticks=(uint64_t)blocks*XE_NP_Np2DualSd_ProfileTicks(m->run.probe_mask,m->run.sample_hz);
    write32(out+120U,(uint32_t)ticks);write32(out+124U,(uint32_t)(ticks>>32U));
    write32(out+508U,XE_NP_Np2DualSd_Crc32(out,508U));return 0;
}

int XE_NP_Np2DualSd_DecodeFooter(const uint8_t descriptor[512],const uint8_t footer[512],
                                 uint32_t *state,uint32_t *error,uint32_t *blocks)
{
    XE_NP_Np2DualSdMeta m;
    if(!state || !error || !blocks ||
       XE_NP_Np2DualSd_DecodeDescriptor(descriptor,&m) ||
       !seal_valid(footer) || memcmp(footer,"N2SDEND1",8U) ||
       memcmp(footer+8U,descriptor+8U,92U) ||
       read32(footer+128U)!=(m.au_blocks?m.au_blocks:m.legacy_au_blocks))return -1;
    uint32_t status=read32(footer+100U),fault=read32(footer+104U);
    uint32_t count=read32(footer+108U);
    uint64_t ticks=(uint64_t)read32(footer+120U)|((uint64_t)read32(footer+124U)<<32U);
    if(count>m.run.max_blocks || count%XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU ||
       read32(footer+112U)!=count/XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU ||
       read32(footer+116U)!=m.run.payload_start_lba+
         count/XE_NP_NP2_DUAL_SD_BLOCKS_PER_RU*XE_NP_NP2_DUAL_SD_SECTORS_PER_RU ||
       ticks!=(uint64_t)count*XE_NP_Np2DualSd_ProfileTicks(m.run.probe_mask,m.run.sample_hz) ||
       (status==XE_NP_NP2_DUAL_SD_META_COMPLETE && (!count || fault)) ||
       (status==XE_NP_NP2_DUAL_SD_META_FAILED && !fault) ||
       (status==XE_NP_NP2_DUAL_SD_META_RESERVED && (count || !fault)) ||
       (status!=XE_NP_NP2_DUAL_SD_META_COMPLETE &&
        status!=XE_NP_NP2_DUAL_SD_META_FAILED &&
        status!=XE_NP_NP2_DUAL_SD_META_RESERVED))return -1;
    *state=status;*error=fault;*blocks=count;return 0;
}

static void append_mark(uint8_t sector[512])
{
    write32(sector+8U,XE_NP_NP2_SD_APPEND_VERSION);
    write32(sector+96U,read32(sector+96U)|XE_NP_NP2_SD_APPEND_FLAG);
    write32(sector+508U,XE_NP_Np2DualSd_Crc32(sector,508U));
}

int XE_NP_Np2SdAppend_EncodeDescriptor(uint8_t out[512],const XE_NP_Np2DualSdMeta *m)
{
    if(XE_NP_Np2DualSd_EncodeDescriptor(out,m))return -1;
    append_mark(out);return 0;
}

int XE_NP_Np2SdAppend_DecodeDescriptor(const uint8_t sector[512],XE_NP_Np2DualSdMeta *out)
{
    if(!sector || !out || read32(sector+8U)!=XE_NP_NP2_SD_APPEND_VERSION ||
       read32(sector+508U)!=XE_NP_Np2DualSd_Crc32(sector,508U))return -1;
    uint32_t version,flags=read32(sector+96U);
    if(flags==79U)version=XE_NP_NP2_DUAL_SD_META_VERSION;
    else if(flags==95U)version=XE_NP_NP2_DUAL_SD_META_AU_VERSION;
    else if(flags==111U)version=XE_NP_NP2_DUAL_SD_META_LEGACY_AU_VERSION;
    else return -1;
    uint8_t legacy[512];memcpy(legacy,sector,512U);
    write32(legacy+8U,version);write32(legacy+96U,flags&~XE_NP_NP2_SD_APPEND_FLAG);
    write32(legacy+508U,XE_NP_Np2DualSd_Crc32(legacy,508U));
    return XE_NP_Np2DualSd_DecodeDescriptor(legacy,out);
}

static int append_counts_valid(const XE_NP_Np2DualSdMeta *m,uint32_t state,uint32_t error,
                               const XE_NP_Np2SdAppendCounts *c)
{
    if(!m || !c || c->physical_blocks%4U || c->logical_prefix_blocks%4U ||
       c->logical_high_water_blocks%4U || c->logical_prefix_blocks>c->physical_blocks ||
       c->physical_blocks>c->logical_high_water_blocks ||
       c->logical_high_water_blocks>m->run.max_blocks ||
       (!c->physical_blocks && c->logical_high_water_blocks) ||
       ((c->logical_prefix_blocks==c->physical_blocks)!=
        (c->logical_high_water_blocks==c->physical_blocks)))return 0;
    /* Counts cannot certify payload uniqueness. A gap is nevertheless enough
     * to reject a Complete or fully-written verification checkpoint here. */
    if((state==XE_NP_NP2_DUAL_SD_META_COMPLETE ||
        (state==XE_NP_NP2_DUAL_SD_META_FAILED && error==XE_NP_NP2_DUAL_SD_META_VERIFY_PENDING)) &&
       (!c->physical_blocks || c->logical_prefix_blocks!=c->physical_blocks))return 0;
    return 1;
}

int XE_NP_Np2SdAppend_EncodeFooter(uint8_t out[512],const XE_NP_Np2DualSdMeta *m,
                                  uint32_t state,uint32_t error,
                                  const XE_NP_Np2SdAppendCounts *c)
{
    if(!append_counts_valid(m,state,error,c) ||
       XE_NP_Np2DualSd_EncodeFooter(out,m,state,error,c->physical_blocks))return -1;
    write32(out+XE_NP_NP2_SD_APPEND_PREFIX_OFFSET,c->logical_prefix_blocks);
    write32(out+XE_NP_NP2_SD_APPEND_HIGH_WATER_OFFSET,c->logical_high_water_blocks);
    append_mark(out);return 0;
}

int XE_NP_Np2SdAppend_DecodeFooter(const uint8_t descriptor[512],const uint8_t footer[512],
                                  uint32_t *state,uint32_t *error,XE_NP_Np2SdAppendCounts *counts)
{
    XE_NP_Np2DualSdMeta m;
    if(!footer || !state || !error || !counts ||
       XE_NP_Np2SdAppend_DecodeDescriptor(descriptor,&m))return -1;
    uint32_t status=read32(footer+100U),fault=read32(footer+104U);
    XE_NP_Np2SdAppendCounts c={read32(footer+108U),
        read32(footer+XE_NP_NP2_SD_APPEND_PREFIX_OFFSET),
        read32(footer+XE_NP_NP2_SD_APPEND_HIGH_WATER_OFFSET)};
    /* Canonical reconstruction reuses every existing geometry/identity/tick/
     * reserved-byte/state/CRC rule. No second permissive metadata parser. */
    uint8_t expected[512];
    if(XE_NP_Np2SdAppend_EncodeFooter(expected,&m,status,fault,&c) ||
       memcmp(expected,footer,512U))return -1;
    *state=status;*error=fault;*counts=c;return 0;
}
