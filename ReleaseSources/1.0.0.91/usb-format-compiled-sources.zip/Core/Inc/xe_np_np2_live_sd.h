#ifndef XE_NP_NP2_LIVE_SD_H
#define XE_NP_NP2_LIVE_SD_H

#include <stdint.h>
#include "xe_np_np2_direct_layout.h"

#ifndef XE_NP_NP2_LIVE_SD_ENABLE
#define XE_NP_NP2_LIVE_SD_ENABLE 0U
#endif

/* One copied SRAM/PSRAM writer, with a stopped-only dual/triple profile
 * selection. Legacy diagnostic/direct builds keep their fixed geometry. */
#ifndef XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
#define XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES 0U
#endif
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES!=0U && XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES!=1U
#error "Runtime SD profiles must be an explicit boolean"
#endif

/* Private stopped-startup clock trial. Keep108MHz on the high-ingress modes. */
#ifndef XE_NP_NP2_SD_PROFILE_BUS54_TEST
#define XE_NP_NP2_SD_PROFILE_BUS54_TEST 0U
#endif
#if XE_NP_NP2_SD_PROFILE_BUS54_TEST!=0U && XE_NP_NP2_SD_PROFILE_BUS54_TEST!=1U
#error "Profile SD-bus clock trial must be an explicit boolean"
#endif
/* Narrow the existing stopped-startup SD54 trial to dual15 only. */
#ifndef XE_NP_NP2_SD_DUAL15_BUS54_TEST
#define XE_NP_NP2_SD_DUAL15_BUS54_TEST 0U
#endif
#if (XE_NP_NP2_SD_DUAL15_BUS54_TEST!=0U && XE_NP_NP2_SD_DUAL15_BUS54_TEST!=1U) || \
    (XE_NP_NP2_SD_DUAL15_BUS54_TEST && !XE_NP_NP2_SD_PROFILE_BUS54_TEST)
#error "Dual15 SD54 trial is boolean and requires the profile SD54 trial"
#endif
/* Private dual20 timing/power comparison; no live or other-profile clock change. */
#ifndef XE_NP_NP2_SD_DUAL20_BUS54_TEST
#define XE_NP_NP2_SD_DUAL20_BUS54_TEST 0U
#endif
#if (XE_NP_NP2_SD_DUAL20_BUS54_TEST!=0U && XE_NP_NP2_SD_DUAL20_BUS54_TEST!=1U) || \
    (XE_NP_NP2_SD_DUAL20_BUS54_TEST && \
     (!XE_NP_NP2_SD_PROFILE_BUS54_TEST || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
      !XE_NP_NP2_DUAL_SD_APP_ENABLE))
#error "Dual20 SD54 trial requires the copied runtime profile clock policy"
#endif
/* One-configuration power trial; keep every other divider unchanged. */
#ifndef XE_NP_NP2_SD_SINGLE7500_BUS54_TEST
#define XE_NP_NP2_SD_SINGLE7500_BUS54_TEST 0U
#endif
#if (XE_NP_NP2_SD_SINGLE7500_BUS54_TEST!=0U && XE_NP_NP2_SD_SINGLE7500_BUS54_TEST!=1U) || \
    (XE_NP_NP2_SD_SINGLE7500_BUS54_TEST && \
     (!XE_NP_NP2_SD_PROFILE_BUS54_TEST || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES))
#error "Single7500 SD54 trial requires runtime per-profile SD bus selection"
#endif
/* RAW9 low-rate clock comparison; retain the closed policy for all other tuples. */
#ifndef XE_NP_NP2_SD_TRIPLE7500_BUS54_TEST
#define XE_NP_NP2_SD_TRIPLE7500_BUS54_TEST 0U
#endif
#if (XE_NP_NP2_SD_TRIPLE7500_BUS54_TEST!=0U && XE_NP_NP2_SD_TRIPLE7500_BUS54_TEST!=1U) || \
    (XE_NP_NP2_SD_TRIPLE7500_BUS54_TEST && \
     (!XE_NP_NP2_SD_PROFILE_BUS54_TEST || !XE_NP_NP2_SD_DUAL15_BUS54_TEST || \
      !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES))
#error "Triple7500 SD54 trial requires runtime closed per-profile SD bus selection"
#endif

/* Private matched-mode power comparison; no other profile may drive SDR50
 * with this APP's108MHz kernel/divider0 policy. Published builds keep SDR104. */
#ifndef XE_NP_NP2_SD_SDR50_POWER_TEST
#define XE_NP_NP2_SD_SDR50_POWER_TEST 0U
#endif
#if (XE_NP_NP2_SD_SDR50_POWER_TEST!=0U && XE_NP_NP2_SD_SDR50_POWER_TEST!=1U) || \
    (XE_NP_NP2_SD_SDR50_POWER_TEST && \
     (!XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_NP2_SD_DUAL15_BUS54_TEST))
#error "SDR50 power diagnostic requires the closed runtime dual15 SD54 policy"
#endif

/* Private AU-aligned, sequential VSC integration. Default recording and the
 * published v11 catalog remain unchanged until matched host readers and HIL. */
#ifndef XE_NP_NP2_LIVE_SD_VSC_TEST
#define XE_NP_NP2_LIVE_SD_VSC_TEST 0U
#endif
/* Private card/writer isolation, never a recording or a public profile. */
#ifndef XE_NP_NP2_SD_VSC_FEED_TEST
#define XE_NP_NP2_SD_VSC_FEED_TEST 0U
#endif
#if XE_NP_NP2_SD_VSC_FEED_TEST!=0U && XE_NP_NP2_SD_VSC_FEED_TEST!=1U
#error "Stopped VSC feeder must be an explicit boolean"
#endif
#if XE_NP_NP2_SD_VSC_FEED_TEST
#define XE_NP_NP2_SD_VSC_FEED_START 167772160U
#define XE_NP_NP2_SD_VSC_FEED_AU 16384U
#define XE_NP_NP2_SD_VSC_FEED_BLOCKS 4096U
#define XE_NP_NP2_SD_VSC_FEED_END 168148992U
#endif
/* Private stopped-only policy trial, reusing the fixed1024 writer. */
#ifndef XE_NP_NP2_SD_PROFILE_CLASSIC_TEST
#define XE_NP_NP2_SD_PROFILE_CLASSIC_TEST 0U
#endif
#if XE_NP_NP2_SD_PROFILE_CLASSIC_TEST!=0U && XE_NP_NP2_SD_PROFILE_CLASSIC_TEST!=1U
#error "Per-profile classic SD trial must be an explicit boolean"
#endif
/* Stopped-only private policy. Four pinned RUs leave too little ingress
 * retention for the measured770..785ms classic stalls in1p20/30/3p7.5.
 * The remaining classic modes still require physical repeated-stall gates. */
#ifndef XE_NP_NP2_SD_CLASSIC_BUFFER_POLICY_TEST
#define XE_NP_NP2_SD_CLASSIC_BUFFER_POLICY_TEST 0U
#endif
#if (XE_NP_NP2_SD_CLASSIC_BUFFER_POLICY_TEST!=0U && XE_NP_NP2_SD_CLASSIC_BUFFER_POLICY_TEST!=1U) || \
    (XE_NP_NP2_SD_CLASSIC_BUFFER_POLICY_TEST && !XE_NP_NP2_SD_PROFILE_CLASSIC_TEST)
#error "Classic buffer policy is boolean and requires the mixed SD APP"
#endif
/* Keep only the already long-qualified lowest profile on the classic path. */
#ifndef XE_NP_NP2_SD_LOWEST_CLASSIC_ONLY_TEST
#define XE_NP_NP2_SD_LOWEST_CLASSIC_ONLY_TEST 0U
#endif
#if (XE_NP_NP2_SD_LOWEST_CLASSIC_ONLY_TEST!=0U && XE_NP_NP2_SD_LOWEST_CLASSIC_ONLY_TEST!=1U) || \
    (XE_NP_NP2_SD_LOWEST_CLASSIC_ONLY_TEST && \
     (!XE_NP_NP2_SD_PROFILE_CLASSIC_TEST || XE_NP_NP2_SD_CLASSIC_BUFFER_POLICY_TEST))
#error "Lowest classic policy is boolean, requires the mixed SD APP, and excludes the buffer policy"
#endif
/* Private 7.5 kHz comparison: all three supported probe masks use classic
 * writes; every other rate remains on the VSC writer. */
#ifndef XE_NP_NP2_SD_ALL7500_CLASSIC_ONLY_TEST
#define XE_NP_NP2_SD_ALL7500_CLASSIC_ONLY_TEST 0U
#endif
#if (XE_NP_NP2_SD_ALL7500_CLASSIC_ONLY_TEST!=0U && XE_NP_NP2_SD_ALL7500_CLASSIC_ONLY_TEST!=1U) || \
    (XE_NP_NP2_SD_ALL7500_CLASSIC_ONLY_TEST && \
     (!XE_NP_NP2_SD_PROFILE_CLASSIC_TEST || XE_NP_NP2_SD_CLASSIC_BUFFER_POLICY_TEST || \
      XE_NP_NP2_SD_LOWEST_CLASSIC_ONLY_TEST || !defined(XE_NP_NP2_SD_CLASSIC7500_CORE96_TEST) || \
      !XE_NP_NP2_SD_CLASSIC7500_CORE96_TEST))
#error "All-7500 classic policy requires the mixed SD APP, core96 3p7500, and no other classic policy"
#endif
#if defined(XE_NP_NP2_SD_CLASSIC7500_CORE96_TEST) && XE_NP_NP2_SD_CLASSIC7500_CORE96_TEST && !XE_NP_NP2_SD_PROFILE_CLASSIC_TEST
#error "Classic7500 core96 requires the mixed classic/VSC policy"
#endif
/* Writer policy is independent of the stopped CPU-clock experiment. */
#ifndef XE_NP_NP2_SD_CLASSIC15_TEST
#if defined(XE_NP_NP2_SD_CLASSIC15_CORE192_TEST) && XE_NP_NP2_SD_CLASSIC15_CORE192_TEST
#define XE_NP_NP2_SD_CLASSIC15_TEST 1U
#else
#define XE_NP_NP2_SD_CLASSIC15_TEST 0U
#endif
#endif
#if (XE_NP_NP2_SD_CLASSIC15_TEST!=0U && XE_NP_NP2_SD_CLASSIC15_TEST!=1U) || \
    (XE_NP_NP2_SD_CLASSIC15_TEST && !XE_NP_NP2_SD_PROFILE_CLASSIC_TEST)
#error "Classic15 is boolean and requires the mixed classic/VSC policy"
#endif
#if defined(XE_NP_NP2_SD_CLASSIC15_CORE192_TEST) && XE_NP_NP2_SD_CLASSIC15_CORE192_TEST && !XE_NP_NP2_SD_CLASSIC15_TEST
#error "Classic15 core192 requires the classic15 writer policy"
#endif
/* Private stopped-startup comparison; capture clocks and geometry stay fixed. */
#ifndef XE_NP_NP2_SD_CLASSIC_HIGH_TEST
#define XE_NP_NP2_SD_CLASSIC_HIGH_TEST 0U
#endif
#if (XE_NP_NP2_SD_CLASSIC_HIGH_TEST!=0U && XE_NP_NP2_SD_CLASSIC_HIGH_TEST!=1U) || \
    (XE_NP_NP2_SD_CLASSIC_HIGH_TEST && !XE_NP_NP2_SD_PROFILE_CLASSIC_TEST)
#error "Classic high-rate trial is boolean and requires the mixed policy"
#endif
/* Current all-7500 baseline: compare only the two highest-ingress tuples.
 * Keep the other nine selectors and all clocks/recording formats unchanged. */
#ifndef XE_NP_NP2_SD_HIGH_TWO_CLASSIC_TEST
#define XE_NP_NP2_SD_HIGH_TWO_CLASSIC_TEST 0U
#endif
#if (XE_NP_NP2_SD_HIGH_TWO_CLASSIC_TEST!=0U && XE_NP_NP2_SD_HIGH_TWO_CLASSIC_TEST!=1U) || \
    (XE_NP_NP2_SD_HIGH_TWO_CLASSIC_TEST && \
     (!XE_NP_NP2_SD_PROFILE_CLASSIC_TEST || !XE_NP_NP2_SD_ALL7500_CLASSIC_ONLY_TEST || \
      !XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST || !XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST || \
      XE_NP_NP2_SD_CLASSIC15_TEST || XE_NP_NP2_SD_CLASSIC_HIGH_TEST))
#error "High-two classic trial requires the unchanged all-7500 sequential/legacy-AU policy"
#endif
/* Session-start-only geometry trial. The lower nine modes keep fixed windows. */
#ifndef XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_TEST
#define XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_TEST 0U
#endif
#ifndef XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_VSC_TEST
#define XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_VSC_TEST 0U
#endif
#if (XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_TEST!=0U && XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_TEST!=1U) || \
    (XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_TEST && \
     !XE_NP_NP2_SD_HIGH_TWO_CLASSIC_TEST && !XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_VSC_TEST)
#error "High-two whole-RU geometry requires the closed classic or VSC comparison"
#endif
#if (XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_VSC_TEST!=0U && XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_VSC_TEST!=1U) || \
    (XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_VSC_TEST && \
     (!XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_TEST || XE_NP_NP2_SD_HIGH_TWO_CLASSIC_TEST || \
      !XE_NP_NP2_SD_PROFILE_CLASSIC_TEST || !XE_NP_NP2_SD_ALL7500_CLASSIC_ONLY_TEST || \
      !XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST || !XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST || \
      !XE_NP_NP2_LIVE_SD_VSC_TEST || XE_NP_NP2_SD_CLASSIC15_TEST || XE_NP_NP2_SD_CLASSIC_HIGH_TEST))
#error "Whole-RU VSC comparison requires the unchanged all-7500 mixed policy without high-two classic"
#endif
static inline uint32_t XE_NP_Np2LiveSd_UsesWholeRuProfile(uint32_t mask,uint32_t rate)
{
#if XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_TEST
    return (mask==3U && rate==30000U) || (mask==7U && rate==20000U);
#else
    (void)mask;(void)rate;return 0U;
#endif
}
#if XE_NP_NP2_SD_ALL7500_CLASSIC_ONLY_TEST && \
    (XE_NP_NP2_SD_CLASSIC15_TEST || XE_NP_NP2_SD_CLASSIC_HIGH_TEST)
#error "All-7500 classic policy keeps 15/20/30 kHz on VSC"
#endif
/* Private low-rate comparison: preserve all released clocks and the other
 * ten write policies. UHS-only cards need not advertise VSC for this rate. */
#ifndef XE_NP_NP2_SD_SINGLE15_CLASSIC_TEST
#define XE_NP_NP2_SD_SINGLE15_CLASSIC_TEST 0U
#endif
#if (XE_NP_NP2_SD_SINGLE15_CLASSIC_TEST!=0U && XE_NP_NP2_SD_SINGLE15_CLASSIC_TEST!=1U) || \
    (XE_NP_NP2_SD_SINGLE15_CLASSIC_TEST && \
     (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_SD_PROFILE_CLASSIC_TEST || \
      !XE_NP_NP2_SD_ALL7500_CLASSIC_ONLY_TEST || !XE_NP_NP2_LIVE_SD_VSC_TEST || \
      !XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST || !XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST))
#error "Single15 classic requires the unchanged all-7500 sequential/legacy-AU SD APP"
#endif
/* SINGLE7500_WINDOW_GUARDS_BEGIN */
/* Private command-size comparison, not a recording-format or clock change. */
#ifndef XE_NP_NP2_SD_SINGLE7500_WINDOW2048_TEST
#define XE_NP_NP2_SD_SINGLE7500_WINDOW2048_TEST 0U
#endif
#if (XE_NP_NP2_SD_SINGLE7500_WINDOW2048_TEST!=0U && XE_NP_NP2_SD_SINGLE7500_WINDOW2048_TEST!=1U) || \
    (XE_NP_NP2_SD_SINGLE7500_WINDOW2048_TEST && \
     (!defined(XE_NP_IMAGE_ROLE) || XE_NP_IMAGE_ROLE!=1U || \
      !XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
      !XE_NP_NP2_SD_PROFILE_CLASSIC_TEST || !XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST || \
      XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U || \
      !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || \
      XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST || \
      XE_NP_NP2_SD_ORDERED_BATCH3_TEST))
#error "Single7500 window requires the copied runtime sequential fixed-sector SD APP"
#endif
/* Extend the same cold-selected window only after the P1/15 profile is classic. */
#ifndef XE_NP_NP2_SD_SINGLE15_WINDOW2048_TEST
#define XE_NP_NP2_SD_SINGLE15_WINDOW2048_TEST 0U
#endif
#if (XE_NP_NP2_SD_SINGLE15_WINDOW2048_TEST!=0U && XE_NP_NP2_SD_SINGLE15_WINDOW2048_TEST!=1U) || \
    (XE_NP_NP2_SD_SINGLE15_WINDOW2048_TEST && \
     (!XE_NP_NP2_SD_SINGLE7500_WINDOW2048_TEST || !XE_NP_NP2_SD_SINGLE15_CLASSIC_TEST))
#error "Single15 window requires the checked Single7500 machinery and classic P1/15 profile"
#endif
/* Card capability alone is not a session mode. Init latches the prepared
 * allocation kind before this private P1/20 window can be selected. */
#ifndef XE_NP_NP2_SD_SINGLE20_WINDOW2048_TEST
#define XE_NP_NP2_SD_SINGLE20_WINDOW2048_TEST 0U
#endif
#if (XE_NP_NP2_SD_SINGLE20_WINDOW2048_TEST!=0U && XE_NP_NP2_SD_SINGLE20_WINDOW2048_TEST!=1U) || \
    (XE_NP_NP2_SD_SINGLE20_WINDOW2048_TEST && \
     (!XE_NP_NP2_SD_SINGLE7500_WINDOW2048_TEST || !XE_NP_NP2_SD_CARD_AU_POLICY_TEST || \
      !XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST))
#error "Single20 window requires checked single-window machinery and prepared classic UHS AU policy"
#endif
#ifndef XE_NP_NP2_SD_DUAL7500_WINDOW2048_TEST
#define XE_NP_NP2_SD_DUAL7500_WINDOW2048_TEST 0U
#endif
#if (XE_NP_NP2_SD_DUAL7500_WINDOW2048_TEST!=0U && XE_NP_NP2_SD_DUAL7500_WINDOW2048_TEST!=1U) || \
    (XE_NP_NP2_SD_DUAL7500_WINDOW2048_TEST && \
     (!XE_NP_NP2_SD_SINGLE7500_WINDOW2048_TEST || !XE_NP_NP2_SD_ALL7500_CLASSIC_ONLY_TEST))
#error "Dual7500 window requires the checked single-window machinery and all-7500 classic policy"
#endif
#ifndef XE_NP_NP2_SD_TRIPLE7500_WINDOW1536_TEST
#define XE_NP_NP2_SD_TRIPLE7500_WINDOW1536_TEST 0U
#endif
#if (XE_NP_NP2_SD_TRIPLE7500_WINDOW1536_TEST!=0U && XE_NP_NP2_SD_TRIPLE7500_WINDOW1536_TEST!=1U) || \
    (XE_NP_NP2_SD_TRIPLE7500_WINDOW1536_TEST && \
     (!XE_NP_NP2_SD_SINGLE7500_WINDOW2048_TEST || !XE_NP_NP2_SD_ALL7500_CLASSIC_ONLY_TEST || \
      !defined(XE_NP_NP2_SD_CLASSIC7500_CORE96_TEST) || !XE_NP_NP2_SD_CLASSIC7500_CORE96_TEST))
#error "Triple7500 window requires checked classic RAW9/D8 geometry and core96"
#endif
/* Private P1/15 middle window. P1/20 retains1024 after its matched power test
 * showed no saving. Clocks and active session allocations stay unchanged. */
#ifndef XE_NP_NP2_SD_SINGLE_MID_WINDOW1536_TEST
#define XE_NP_NP2_SD_SINGLE_MID_WINDOW1536_TEST 0U
#endif
#if (XE_NP_NP2_SD_SINGLE_MID_WINDOW1536_TEST!=0U && XE_NP_NP2_SD_SINGLE_MID_WINDOW1536_TEST!=1U) || \
    (XE_NP_NP2_SD_SINGLE_MID_WINDOW1536_TEST && \
     (!XE_NP_NP2_SD_SINGLE7500_WINDOW2048_TEST || !XE_NP_NP2_SD_SINGLE15_CLASSIC_TEST || \
      !XE_NP_NP2_SD_CARD_AU_POLICY_TEST || !XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST || \
      !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || \
      XE_NP_NP2_SD_SINGLE15_WINDOW2048_TEST || XE_NP_NP2_SD_SINGLE20_WINDOW2048_TEST || \
      XE_NP_NP2_SD_TRIPLE7500_WINDOW1536_TEST))
#error "Single mid1536 requires checked classic P1 window machinery without competing window trials"
#endif
/* Private P1/30 comparison; reuse the checked six-owner1536 machinery.
 * Select only before recording; every other profile keeps its own window. */
#ifndef XE_NP_NP2_SD_SINGLE30_WINDOW1536_TEST
#define XE_NP_NP2_SD_SINGLE30_WINDOW1536_TEST 0U
#endif
#if (XE_NP_NP2_SD_SINGLE30_WINDOW1536_TEST!=0U && XE_NP_NP2_SD_SINGLE30_WINDOW1536_TEST!=1U) || \
    (XE_NP_NP2_SD_SINGLE30_WINDOW1536_TEST && !XE_NP_NP2_SD_SINGLE_MID_WINDOW1536_TEST)
#error "Single30 window1536 requires the checked single-mid1536 machinery"
#endif
/* Private P1/30 one-MiB comparison; reuse the seven-owner/eighteen-node
 * window without changing clocks, formats, acquisition or retirement. */
#ifndef XE_NP_NP2_SD_SINGLE30_WINDOW2048_TEST
#define XE_NP_NP2_SD_SINGLE30_WINDOW2048_TEST 0U
#endif
#if (XE_NP_NP2_SD_SINGLE30_WINDOW2048_TEST!=0U && XE_NP_NP2_SD_SINGLE30_WINDOW2048_TEST!=1U) || \
    (XE_NP_NP2_SD_SINGLE30_WINDOW2048_TEST && \
     (!XE_NP_NP2_SD_SINGLE7500_WINDOW2048_TEST || !XE_NP_NP2_SD_CARD_AU_POLICY_TEST || \
      !XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST || XE_NP_NP2_SD_SINGLE30_WINDOW1536_TEST))
#error "Single30 window2048 requires checked single-window machinery and classic UHS AU without window1536"
#endif
/* DUAL20_WINDOW1536_GUARDS_BEGIN */
/* Private command-size comparison with the closed SD108/96 clock policy. Reuse six
 * immutable owners/eighteen nodes, not the seven-owner2048 geometry. */
#ifndef XE_NP_NP2_SD_DUAL20_WINDOW1536_TEST
#define XE_NP_NP2_SD_DUAL20_WINDOW1536_TEST 0U
#endif
#if (XE_NP_NP2_SD_DUAL20_WINDOW1536_TEST!=0U && XE_NP_NP2_SD_DUAL20_WINDOW1536_TEST!=1U) || \
    (XE_NP_NP2_SD_DUAL20_WINDOW1536_TEST && \
     (!defined(XE_NP_IMAGE_ROLE) || XE_NP_IMAGE_ROLE!=1U || \
      !XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
      !XE_NP_NP2_SD_PROFILE_CLASSIC_TEST || !XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST || \
      !XE_NP_NP2_SD_CARD_AU_POLICY_TEST || !XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST || \
      XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U || \
      XE_NP_NP2_LIVE_SD_WRITE_RUS!=6U || XE_NP_NP2_LIVE_SD_WRITE_CAP_RUS!=6U || \
      !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || \
      !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || !XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS || \
      XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST || \
      XE_NP_NP2_SD_ORDERED_BATCH3_TEST || XE_NP_NP2_SD_KERNEL80_POWER_TEST || \
      XE_NP_NP2_SD_HIGH_RATE_KERNEL120_TEST || \
      XE_NP_NP2_SD_DUAL20_BUS54_TEST))
#error "Dual20 window1536 requires the copied sequential fixed1024 six-owner SD108/96 APP"
#endif
/* DUAL20_WINDOW1536_GUARDS_END */
/* SINGLE7500_WINDOW_GUARDS_END */
/* CARD_AU_POLICY_GUARDS_BEGIN */
/* Stopped-only card capability selection; recorded allocation selects the
 * writer mode. No status query, fallback or policy mutation while recording. */
#ifndef XE_NP_NP2_SD_CARD_AU_POLICY_TEST
#define XE_NP_NP2_SD_CARD_AU_POLICY_TEST 0U
#endif
#if (XE_NP_NP2_SD_CARD_AU_POLICY_TEST!=0U && XE_NP_NP2_SD_CARD_AU_POLICY_TEST!=1U) || \
    (XE_NP_NP2_SD_CARD_AU_POLICY_TEST && \
     (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
      !XE_NP_NP2_SD_PROFILE_CLASSIC_TEST || !XE_NP_NP2_LIVE_SD_VSC_TEST || \
      !XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST || !XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST))
#error "Card AU policy requires the runtime sequential classic/VSC SD APP"
#endif
/* CARD_AU_POLICY_GUARDS_END */
/* ORDERED_BATCH3_GUARDS_BEGIN */
#ifndef XE_NP_NP2_SD_ORDERED_BATCH3_TEST
#define XE_NP_NP2_SD_ORDERED_BATCH3_TEST 0U
#endif
#if (XE_NP_NP2_SD_ORDERED_BATCH3_TEST!=0U && XE_NP_NP2_SD_ORDERED_BATCH3_TEST!=1U) || \
    (XE_NP_NP2_SD_ORDERED_BATCH3_TEST && \
     (XE_NP_IMAGE_ROLE!=1U || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
      !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_NP2_SD_CARD_AU_POLICY_TEST || \
      !XE_NP_NP2_SD_PROFILE_CLASSIC_TEST || !XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST || \
      !XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_TEST || !XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_VSC_TEST || \
      XE_NP_NP2_SD_HIGH_TWO_CLASSIC_TEST || XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U || \
      !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || \
      !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || XE_NP_NP2_LIVE_SD_DIRECT || \
      XE_NP_NP2_LIVE_SD_LAST_FREE_PREFETCH_TEST || XE_NP_NP2_SD_HIGH_TWO_PSRAM_IDMA_TEST))
#error "Ordered batch3 requires the runtime card-policy ordered whole-RU SD APP"
#endif
/* ORDERED_BATCH3_GUARDS_END */
/* Private classic feed reuses the existing mixed fixed-window DMA backend.
 * Select only at stopped setup; it never changes clocks or payload owners. */
/* INTERNAL_SRAM_CACHE_GUARDS_BEGIN */
/* DCACHE1 is bypassed in hardware for U595 internal SRAM. Private until the
 * recording/power gate passes; never change external PSRAM maintenance. */
#ifndef XE_NP_NP2_SD_INTERNAL_SRAM_CACHE_BYPASS_TEST
#define XE_NP_NP2_SD_INTERNAL_SRAM_CACHE_BYPASS_TEST 0U
#endif
#if (XE_NP_NP2_SD_INTERNAL_SRAM_CACHE_BYPASS_TEST!=0U && \
     XE_NP_NP2_SD_INTERNAL_SRAM_CACHE_BYPASS_TEST!=1U) || \
    (XE_NP_NP2_SD_INTERNAL_SRAM_CACHE_BYPASS_TEST && \
     (!defined(STM32U595xx) || XE_NP_IMAGE_ROLE!=1U || \
      !XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES))
#error "Internal SRAM cache bypass requires the U595 runtime SD APP"
#endif
/* INTERNAL_SRAM_CACHE_GUARDS_END */
#ifndef XE_NP_NP2_SD_HIGH_TWO_CLASSIC_PSRAM_IDMA_TEST
#define XE_NP_NP2_SD_HIGH_TWO_CLASSIC_PSRAM_IDMA_TEST 0U
#endif
/* Private v14 storage trial. Linking this writer never changes an old Init
 * caller's layout: only InitExtentAppendProfile explicitly opts in. */
#ifndef XE_NP_NP2_SD_APPEND_ORDER_TEST
#define XE_NP_NP2_SD_APPEND_ORDER_TEST 0U
#endif
#if (XE_NP_NP2_SD_APPEND_ORDER_TEST!=0U && XE_NP_NP2_SD_APPEND_ORDER_TEST!=1U) || \
    (XE_NP_NP2_SD_APPEND_ORDER_TEST && \
     (XE_NP_IMAGE_ROLE!=1U || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
      !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_NP2_SD_CARD_AU_POLICY_TEST || \
      !XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST || !XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST || \
      XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U || \
      !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA || !XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER || \
      !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || XE_NP_NP2_LIVE_SD_DIRECT || \
      XE_NP_NP2_SD_ORDERED_BATCH3_TEST || XE_NP_NP2_LIVE_SD_LAST_FREE_PREFETCH_TEST || \
      (XE_NP_NP2_SD_HIGH_TWO_PSRAM_IDMA_TEST && \
       !XE_NP_NP2_SD_HIGH_TWO_CLASSIC_PSRAM_IDMA_TEST) || XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST || \
      XE_NP_NP2_SD_RAW_INGRESS_RU_TEST))
#error "Append trial requires the original copied fixed1024 runtime card-policy SD APP"
#endif
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST && \
    (!XE_NP_NP2_SD_APPEND_ORDER_TEST || !XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE || \
     XE_NP_NP2_LIVE_SD_SYNTHETIC_SOURCE || XE_NP_NP2_SD_INGRESS_DMA_TEST || \
     XE_NP_NP2_SD_HIGH_TWO_PSRAM_IDMA_TEST || XE_NP_NP2_SD_HIGH_TWO_CLASSIC_PSRAM_IDMA_TEST || \
     XE_NP_V2_MEDIA_ENABLE || XE_NP_V2_AUX_ENABLE || XE_NP_NP2_DIRECT_D8_RAW_PHASE)
#error "Runtime direct PSSI requires the unchanged neural append writer and independent SPI2 D8"
#endif
/* One-variable dual30 delivery experiment: one immutable RU per CMD25.
 * Other append profiles and all legacy callers retain their current cap. */
#ifndef XE_NP_NP2_SD_APPEND_DUAL30_CMD1_TEST
#define XE_NP_NP2_SD_APPEND_DUAL30_CMD1_TEST 0U
#endif
#if (XE_NP_NP2_SD_APPEND_DUAL30_CMD1_TEST!=0U && XE_NP_NP2_SD_APPEND_DUAL30_CMD1_TEST!=1U) || \
    (XE_NP_NP2_SD_APPEND_DUAL30_CMD1_TEST && !XE_NP_NP2_SD_APPEND_ORDER_TEST)
#error "Dual30 CMD1 trial is boolean and requires the explicit append writer"
#endif
static inline uint32_t XE_NP_Np2LiveSd_UsesOrderedBatch3Profile(uint32_t mask,uint32_t rate,
                                                           uint32_t uses_vsc)
{
#if XE_NP_NP2_SD_ORDERED_BATCH3_TEST
    return !uses_vsc && ((mask==3U && rate==30000U) || (mask==7U && rate==20000U));
#else
    (void)mask;(void)rate;(void)uses_vsc;return 0U;
#endif
}
static inline uint32_t XE_NP_Np2LiveSd_UsesVscProfile(uint32_t mask,uint32_t rate)
{
#if XE_NP_NP2_SD_PROFILE_CLASSIC_TEST
#if XE_NP_NP2_SD_SINGLE15_CLASSIC_TEST
    if(mask==1U && rate==15000U)return 0U;
#endif
#if XE_NP_NP2_SD_HIGH_TWO_CLASSIC_TEST
    if((mask==3U && rate==30000U) || (mask==7U && rate==20000U))return 0U;
#endif
#if XE_NP_NP2_SD_ALL7500_CLASSIC_ONLY_TEST
    return !((mask==1U || mask==3U || mask==7U) && rate==7500U);
#elif XE_NP_NP2_SD_LOWEST_CLASSIC_ONLY_TEST
    return !(mask==1U && rate==7500U);
#elif XE_NP_NP2_SD_CLASSIC_BUFFER_POLICY_TEST
    return !((mask==1U && (rate==7500U || rate==15000U)) ||
             (mask==3U && rate==7500U));
#else
#if XE_NP_NP2_SD_CLASSIC_HIGH_TEST
    if(((mask==3U || mask==7U) && rate==20000U) ||
       (mask==3U && rate==30000U))return 0U;
#endif
#if XE_NP_NP2_SD_CLASSIC15_TEST
    if((mask==3U || mask==7U) && rate==15000U)return 0U;
#endif
#if defined(XE_NP_NP2_SD_CLASSIC7500_CORE96_TEST) && XE_NP_NP2_SD_CLASSIC7500_CORE96_TEST
    if(mask==7U && rate==7500U)return 0U;
#endif
    return mask!=1U && !(mask==3U && rate==7500U);
#endif
#else
    (void)mask;(void)rate;
    return XE_NP_NP2_LIVE_SD_VSC_TEST;
#endif
}
static inline uint32_t XE_NP_Np2LiveSd_UsesReservedAu(uint32_t mask,uint32_t rate,
                                                  uint32_t au,uint32_t allocation_end)
{
#if XE_NP_NP2_SD_CARD_AU_POLICY_TEST
    if(au)return allocation_end?0U:1U;
#else
    (void)au;(void)allocation_end;
#endif
    return XE_NP_Np2LiveSd_UsesVscProfile(mask,rate);
}
static inline uint32_t XE_NP_Np2LiveSd_UsesBus54Profile(uint32_t mask,uint32_t rate)
{
#if XE_NP_NP2_SD_PROFILE_BUS54_TEST
#if XE_NP_NP2_SD_DUAL20_BUS54_TEST
    if(mask==3U && rate==20000U)return 1U;
#endif
#if XE_NP_NP2_SD_SINGLE7500_BUS54_TEST
    if(mask==1U && rate==7500U)return 1U;
#endif
#if XE_NP_NP2_SD_TRIPLE7500_BUS54_TEST
    if(mask==7U && rate==7500U)return 1U;
#endif
#if XE_NP_NP2_SD_DUAL15_BUS54_TEST
    return mask==3U && rate==15000U;
#else
    return mask==1U || rate==7500U || (mask==3U && rate==15000U);
#endif
#else
    (void)mask;(void)rate;
    return 0U;
#endif
}
/* Private mid-rate PWRSAV comparisons; no live clock mutation. */
#ifndef XE_NP_NP2_SD_DUAL15_CLOCK_SAVE_TEST
#define XE_NP_NP2_SD_DUAL15_CLOCK_SAVE_TEST 0U
#endif
#if (XE_NP_NP2_SD_DUAL15_CLOCK_SAVE_TEST!=0U && XE_NP_NP2_SD_DUAL15_CLOCK_SAVE_TEST!=1U) || \
    (XE_NP_NP2_SD_DUAL15_CLOCK_SAVE_TEST && \
     (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
      !XE_NP_NP2_SD_PROFILE_CLASSIC_TEST || !XE_NP_NP2_LIVE_SD_VSC_TEST))
#error "Dual15 clock-save trial is boolean and requires the runtime mixed-policy SD APP"
#endif
#ifndef XE_NP_NP2_SD_DUAL20_CLOCK_SAVE_TEST
#define XE_NP_NP2_SD_DUAL20_CLOCK_SAVE_TEST 0U
#endif
#if (XE_NP_NP2_SD_DUAL20_CLOCK_SAVE_TEST!=0U && XE_NP_NP2_SD_DUAL20_CLOCK_SAVE_TEST!=1U) || \
    (XE_NP_NP2_SD_DUAL20_CLOCK_SAVE_TEST && \
     (!XE_NP_NP2_DUAL_SD_APP_ENABLE || !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || \
      !XE_NP_NP2_SD_PROFILE_CLASSIC_TEST || !XE_NP_NP2_LIVE_SD_VSC_TEST))
#error "Dual20 clock-save trial is boolean and requires the runtime mixed-policy SD APP"
#endif
/* Select only at stopped startup. Unless explicitly requalified above,
 * retain continuous SD service for dual15/20/30 and triple15/20, including
 * the all-7500 classic-writer build. */
static inline uint32_t XE_NP_Np2LiveSd_UsesClockSaveProfile(uint32_t mask,uint32_t rate)
{
#if XE_NP_NP2_SD_PROFILE_CLASSIC_TEST
#if XE_NP_NP2_SD_DUAL15_CLOCK_SAVE_TEST
    if(mask==3U && rate==15000U)return 1U;
#endif
#if XE_NP_NP2_SD_DUAL20_CLOCK_SAVE_TEST
    if(mask==3U && rate==20000U)return 1U;
#endif
    return mask==1U || (mask==3U && rate==7500U) ||
           (mask==7U && rate==7500U);
#else
    (void)mask;(void)rate;
    return 1U;
#endif
}
/* Fresh-session comparison: contiguous fixed512 classic writes. The mixed
 * policy retains VSC for its five higher-rate profiles. Never switch a running
 * OOO session whose completed count can contain holes. */
#ifndef XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST
#define XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST 0U
#endif
#if XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST!=0U && XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST!=1U
#error "Classic sequential trial must be an explicit boolean"
#endif
/* Private stopped allocation/erase trial. No VSC semantics in v13 metadata. */
#ifndef XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST
#define XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST 0U
#endif
#if XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST!=0U && XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST!=1U
#error "Classic UHS AU trial must be an explicit boolean"
#endif
#if XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST && \
    (!XE_NP_NP2_SD_PROFILE_CLASSIC_TEST || !XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST)
#error "Classic UHS AU trial requires the mixed sequential runtime policy"
#endif
/* Legacy CMD20 Start Recording (argument0, VSC bit clear) before acquisition.
 * No priming writes or command retries; all data-path policy is unchanged. */
#ifndef XE_NP_NP2_LIVE_SD_CLASSIC_PREPARE_TEST
#define XE_NP_NP2_LIVE_SD_CLASSIC_PREPARE_TEST 0U
#endif
#if XE_NP_NP2_LIVE_SD_CLASSIC_PREPARE_TEST!=0U && XE_NP_NP2_LIVE_SD_CLASSIC_PREPARE_TEST!=1U
#error "Classic preparation trial must be an explicit boolean"
#endif
/* Private immutable FIFO-to-IDMA feed; no restore copies or clock changes.
 * Requires the existing copied packed-dual sequential VSC/fixed512 path. */
#ifndef XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST
#define XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST 0U
#endif
#if XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST!=0U && XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST!=1U
#error "Direct VSC PSRAM feed must be an explicit boolean experiment"
#endif
#if XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST && !XE_NP_NP2_LIVE_SD_VSC_TEST
#error "Direct PSRAM feed requires sequential live VSC"
#endif
/* Cold-selected comparison: external FIFO IDMA only for the two highest
 * ingress profiles. Keep the other nine on their copied/refilled policy. */
#ifndef XE_NP_NP2_SD_HIGH_TWO_PSRAM_IDMA_TEST
#define XE_NP_NP2_SD_HIGH_TWO_PSRAM_IDMA_TEST 0U
#endif
#if (XE_NP_NP2_SD_HIGH_TWO_PSRAM_IDMA_TEST!=0U && XE_NP_NP2_SD_HIGH_TWO_PSRAM_IDMA_TEST!=1U) || \
    (XE_NP_NP2_SD_HIGH_TWO_PSRAM_IDMA_TEST && \
     (!XE_NP_NP2_SD_PROFILE_CLASSIC_TEST || !XE_NP_NP2_SD_ALL7500_CLASSIC_ONLY_TEST || \
      !XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST || !XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST || \
      !XE_NP_NP2_LIVE_SD_VSC_TEST || XE_NP_NP2_LIVE_SD_VSC_DIRECT_PSRAM_TEST || \
      XE_NP_NP2_SD_HIGH_TWO_CLASSIC_TEST || XE_NP_NP2_SD_HIGH_TWO_WHOLE_RU_TEST))
#error "High-two PSRAM IDMA requires the unchanged all-7500 mixed fixed-window policy"
#endif
/* CLASSIC_PSRAM_IDMA_GUARDS_BEGIN */
#if (XE_NP_NP2_SD_HIGH_TWO_CLASSIC_PSRAM_IDMA_TEST!=0U && \
     XE_NP_NP2_SD_HIGH_TWO_CLASSIC_PSRAM_IDMA_TEST!=1U) || \
    (XE_NP_NP2_SD_HIGH_TWO_CLASSIC_PSRAM_IDMA_TEST && \
     (XE_NP_IMAGE_ROLE!=1U || !XE_NP_NP2_SD_HIGH_TWO_PSRAM_IDMA_TEST || \
      !XE_NP_NP2_SD_APPEND_ORDER_TEST || !XE_NP_NP2_SD_CARD_AU_POLICY_TEST || \
      !XE_NP_NP2_LIVE_SD_CLASSIC_SEQUENTIAL_TEST || !XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST))
#error "Classic PSRAM IDMA requires the private prepared-classic high-two append APP"
#endif
/* CLASSIC_PSRAM_IDMA_GUARDS_END */
static inline uint32_t XE_NP_Np2LiveSd_UsesPsramIdmaProfile(uint32_t mask,uint32_t rate)
{
#if XE_NP_NP2_SD_HIGH_TWO_PSRAM_IDMA_TEST
    return (mask==3U && rate==30000U) || (mask==7U && rate==20000U);
#else
    (void)mask;(void)rate;return 0U;
#endif
}
static inline uint32_t XE_NP_Np2LiveSd_UsesAppendProfile(uint32_t mask,uint32_t rate,
                                                     uint32_t uses_vsc,uint32_t legacy_au_blocks)
{
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
#if XE_NP_NP2_SD_HIGH_TWO_CLASSIC_PSRAM_IDMA_TEST
    if(XE_NP_Np2LiveSd_UsesPsramIdmaProfile(mask,rate))return 0U;
#endif
    return !uses_vsc && legacy_au_blocks &&
        ((mask==3U && rate==30000U) || (mask==7U && (rate==15000U || rate==20000U)));
#else
    (void)mask;(void)rate;(void)uses_vsc;(void)legacy_au_blocks;return 0U;
#endif
}

#ifndef XE_NP_NP2_LIVE_SD_PROBE_MASK
#define XE_NP_NP2_LIVE_SD_PROBE_MASK 7U
#endif

#ifndef XE_NP_NP2_LIVE_SD_DURATION_SECONDS
#define XE_NP_NP2_LIVE_SD_DURATION_SECONDS 10U
#endif
#ifndef XE_NP_NP2_LIVE_SD_BLOCK_LIMIT
#define XE_NP_NP2_LIVE_SD_BLOCK_LIMIT 0U
#endif

#ifndef XE_NP_NP2_LIVE_SD_WRITE_RUS
#define XE_NP_NP2_LIVE_SD_WRITE_RUS 1U
#endif

#ifndef XE_NP_NP2_LIVE_SD_PREERASE_HINT
#define XE_NP_NP2_LIVE_SD_PREERASE_HINT 0U
#endif

#ifndef XE_NP_NP2_LIVE_SD_COUNTED_WRITES
#define XE_NP_NP2_LIVE_SD_COUNTED_WRITES 0U
#endif

/* Private long-run command-termination discriminator. Keep the same counted
 * writer/owners, but use HAL's existing CMD12 path for dual20 only. */
#ifndef XE_NP_NP2_SD_DUAL20_EXPLICIT_STOP_TEST
#define XE_NP_NP2_SD_DUAL20_EXPLICIT_STOP_TEST 0U
#endif
#if (XE_NP_NP2_SD_DUAL20_EXPLICIT_STOP_TEST!=0U && XE_NP_NP2_SD_DUAL20_EXPLICIT_STOP_TEST!=1U) || \
    (XE_NP_NP2_SD_DUAL20_EXPLICIT_STOP_TEST && \
     (XE_NP_IMAGE_ROLE!=1U || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
      !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_NP2_LIVE_SD_COUNTED_WRITES || \
      XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U || !XE_NP_NP2_SD_APPEND_ORDER_TEST))
#error "Dual20 explicit stop requires the counted runtime fixed1024 append APP"
#endif

/* Private response-clock discriminator, NOT the RM's SDR104 configuration.
 * Bypass DLYB using the board's external CKIN for dual20 only, before arm.
 * All other profiles restore RX2. No launch edge, clock or voltage change. */
#ifndef XE_NP_NP2_SD_DUAL20_DIRECT_CKIN_TEST
#define XE_NP_NP2_SD_DUAL20_DIRECT_CKIN_TEST 0U
#endif
#if (XE_NP_NP2_SD_DUAL20_DIRECT_CKIN_TEST!=0U && XE_NP_NP2_SD_DUAL20_DIRECT_CKIN_TEST!=1U) || \
    (XE_NP_NP2_SD_DUAL20_DIRECT_CKIN_TEST && \
     (!defined(STM32U595xx) || XE_NP_IMAGE_ROLE!=1U || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
      !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_NP2_SD_PROFILE_BUS54_TEST || \
      XE_NP_BOARD_SD_PLL2Q_HZ!=108000000UL || XE_NP_BOARD_SD_RX_CLOCK_TEST!=2U || \
      XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_STAGED_CAPTURE || \
      XE_NP_NP2_SD_KERNEL96_POWER_TEST || XE_NP_NP2_SD_DUAL20_EXPLICIT_STOP_TEST))
#error "Dual20 CKIN discriminator requires the original copied U595 SD108/RX2 APP"
#endif

/* Private one-CMD13 retry after proven DATAEND. Never replay CMD25 or retry
 * data errors. Reuses SDFT's spare words; default recording is unchanged. */
#ifndef XE_NP_NP2_SD_DUAL20_STATUS_RETRY_TEST
#define XE_NP_NP2_SD_DUAL20_STATUS_RETRY_TEST 0U
#endif
#if (XE_NP_NP2_SD_DUAL20_STATUS_RETRY_TEST!=0U && XE_NP_NP2_SD_DUAL20_STATUS_RETRY_TEST!=1U) || \
    (XE_NP_NP2_SD_DUAL20_STATUS_RETRY_TEST && \
     (!defined(STM32U595xx) || XE_NP_IMAGE_ROLE!=1U || !XE_NP_NP2_DUAL_SD_APP_ENABLE || \
      !XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES || !XE_NP_NP2_LIVE_SD_IDMA_LINKED_LIST || \
      XE_NP_NP2_LIVE_SD_FIXED_SECTORS_TEST!=1024U || !XE_NP_SD_FAILURE_TRACE_ENABLE || \
      !XE_NP_NP2_LIVE_SD_OVERFLOW_FAULT_DIAG || XE_NP_NP2_LIVE_SD_DIRECT || \
      XE_NP_NP2_STAGED_CAPTURE || XE_NP_NP2_LIVE_SD_ROLLING_CMD25 || \
      XE_NP_NP2_SD_DUAL20_DIRECT_CKIN_TEST || XE_NP_NP2_SD_DUAL20_EXPLICIT_STOP_TEST))
#error "Dual20 status retry requires the copied fixed1024 runtime APP and SDFT receipt"
#endif

/* Private timing discriminator: only the already-admitted failed CMD13 retry
 * uses /2. Payload clocks, DLYB, source timing and the deadline stay unchanged. */
#ifndef XE_NP_NP2_SD_DUAL20_STATUS_SLOW_QUERY_TEST
#define XE_NP_NP2_SD_DUAL20_STATUS_SLOW_QUERY_TEST 0U
#endif
#if (XE_NP_NP2_SD_DUAL20_STATUS_SLOW_QUERY_TEST!=0U && XE_NP_NP2_SD_DUAL20_STATUS_SLOW_QUERY_TEST!=1U) || \
    (XE_NP_NP2_SD_DUAL20_STATUS_SLOW_QUERY_TEST && \
     (!XE_NP_NP2_SD_DUAL20_STATUS_RETRY_TEST || \
      (!XE_NP_NP2_SD_KERNEL96_POWER_TEST && XE_NP_BOARD_SD_PLL2Q_HZ!=108000000UL) || \
      (XE_NP_NP2_SD_KERNEL96_POWER_TEST && XE_NP_BOARD_SD_PLL2Q_HZ!=96000000UL) || \
      XE_NP_BOARD_SD_RX_CLOCK_TEST!=2U))
#error "Slow status query requires the one-attempt paired SD108/96/RX2 retry experiment"
#endif

#ifndef XE_NP_NP2_LIVE_SD_IDLE_SLEEP
#define XE_NP_NP2_LIVE_SD_IDLE_SLEEP 0U
#endif

/* Private hardware idle-clock gating; active SD transfers keep their clock. */
#ifndef XE_NP_NP2_SD_ACTIVE_CLOCK_SAVE_TEST
#define XE_NP_NP2_SD_ACTIVE_CLOCK_SAVE_TEST 0U
#endif
#if XE_NP_NP2_SD_ACTIVE_CLOCK_SAVE_TEST!=0U && XE_NP_NP2_SD_ACTIVE_CLOCK_SAVE_TEST!=1U
#error "Active SD clock saving must be an explicit boolean experiment"
#endif
#if XE_NP_NP2_SD_DUAL20_CLOCK_SAVE_TEST && !XE_NP_NP2_SD_ACTIVE_CLOCK_SAVE_TEST
#error "Dual20 clock-save trial requires active clock-save selection"
#endif
#if XE_NP_NP2_SD_DUAL15_CLOCK_SAVE_TEST && !XE_NP_NP2_SD_ACTIVE_CLOCK_SAVE_TEST
#error "Dual15 clock-save trial requires active clock-save selection"
#endif

#ifndef XE_NP_NP2_LIVE_SD_PSRAM_PROBE
#define XE_NP_NP2_LIVE_SD_PSRAM_PROBE 0U
#endif

/* Opt-in SRAM headroom trial; ordinary copied/direct layouts are unchanged. */
#ifndef XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS
#define XE_NP_NP2_LIVE_SD_COPIED_DUAL_NINE_RUS 0U
#endif

/* SRAM-first acquisition; PSRAM holds only completed overflow RUs. */
#ifndef XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
#define XE_NP_NP2_LIVE_SD_OVERFLOW_DMA 0U
#endif

/* Single-variable C14 bus-blocking trial; legacy spill/default remain burst4. */
#ifndef XE_NP_NP2_LIVE_SD_OVERFLOW_DMA_BURST_WORDS
#define XE_NP_NP2_LIVE_SD_OVERFLOW_DMA_BURST_WORDS 4U
#endif
#if (XE_NP_NP2_LIVE_SD_OVERFLOW_DMA_BURST_WORDS != 1U) && \
    (XE_NP_NP2_LIVE_SD_OVERFLOW_DMA_BURST_WORDS != 4U)
#error "Overflow DMA burst length must be one or four words"
#endif
#if !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA && \
    (XE_NP_NP2_LIVE_SD_OVERFLOW_DMA_BURST_WORDS != 4U)
#error "Short memory bursts require the opt-in overflow DMA backend"
#endif

/* Fixed-LBA SRAM bypass of older external-memory holes; never a live default. */
#ifndef XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER
#define XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER 0U
#endif
#if XE_NP_NP2_LIVE_SD_OVERFLOW_OUT_OF_ORDER && !XE_NP_NP2_LIVE_SD_OVERFLOW_DMA
#error "Fixed-LBA bypass requires the opt-in SRAM-first overflow DMA backend"
#endif
/* Private copied-overflow trial: keep PSRAM on port1, SRAM on port0. */
#ifndef XE_NP_NP2_LIVE_SD_COPY_SPLIT_PORTS_TEST
#define XE_NP_NP2_LIVE_SD_COPY_SPLIT_PORTS_TEST 0U
#endif
#if XE_NP_NP2_LIVE_SD_COPY_SPLIT_PORTS_TEST!=0U && XE_NP_NP2_LIVE_SD_COPY_SPLIT_PORTS_TEST!=1U
#error "Copy split-ports trial is boolean"
#endif

#if XE_NP_NP2_LIVE_SD_ENABLE
#include "stm32u5xx_hal.h"

#define XE_NP_NP2_LIVE_SD_MAILBOX_MAGIC   0x4453324EU /* "N2SD" */
#define XE_NP_NP2_LIVE_SD_MAILBOX_VERSION 1U

enum {
    XE_NP_NP2_LIVE_SD_BOOT=0U,
    XE_NP_NP2_LIVE_SD_PREPARING=1U,
    XE_NP_NP2_LIVE_SD_CONFIGURING=2U,
    XE_NP_NP2_LIVE_SD_CAPTURING=3U,
    XE_NP_NP2_LIVE_SD_DRAINING=4U,
    XE_NP_NP2_LIVE_SD_VERIFYING=5U,
    XE_NP_NP2_LIVE_SD_COMPLETE=6U,
    XE_NP_NP2_LIVE_SD_FAILED=255U
};

enum {
    XE_NP_NP2_LIVE_SD_ERROR_NONE=0U,
    XE_NP_NP2_LIVE_SD_ERROR_ARGUMENT=1U,
    XE_NP_NP2_LIVE_SD_ERROR_CARD=2U,
    XE_NP_NP2_LIVE_SD_ERROR_RANGE=3U,
    XE_NP_NP2_LIVE_SD_ERROR_ERASE=4U,
    XE_NP_NP2_LIVE_SD_ERROR_SOURCE=5U,
    XE_NP_NP2_LIVE_SD_ERROR_CAPTURE=6U,
    XE_NP_NP2_LIVE_SD_ERROR_RING=7U,
    XE_NP_NP2_LIVE_SD_ERROR_WRITE_START=8U,
    XE_NP_NP2_LIVE_SD_ERROR_WRITE=9U,
    XE_NP_NP2_LIVE_SD_ERROR_STOP=10U,
    XE_NP_NP2_LIVE_SD_ERROR_READ=11U,
    XE_NP_NP2_LIVE_SD_ERROR_HEADER=12U,
    XE_NP_NP2_LIVE_SD_ERROR_WIRE=13U,
    XE_NP_NP2_LIVE_SD_ERROR_CACHE=14U,
    XE_NP_NP2_LIVE_SD_ERROR_TIMEOUT=15U
};

typedef struct {
    uint32_t magic,version,state,error;
    uint32_t cpu_hz,mclk_hz,sample_hz,probe_mask,wire_mask,codec,stored_bits;
    uint32_t start_lba,end_lba,target_blocks,stream_block_bytes,ru_bytes,ru_count;
    uint32_t card_blocks,sd_speed_mode,sd_kernel_hz,sd_bus_hz,signal_1v8;
    uint32_t source_state,source_error,source_flags,source_i2c_error;
    uint32_t produced_blocks,written_rus,verified_blocks,ring_peak;
    uint32_t max_capture_cycles,max_write_cycles,max_write_busy_cycles;
    uint32_t max_cmd25_setup_cycles,max_irq_to_service_cycles,max_service_interval_cycles;
    uint32_t source_produced_lo,source_produced_hi,source_consumed_lo,source_consumed_hi;
    uint32_t source_max_backlog,source_irq_count,capture_setup_stage,d8_error;
    uint32_t sd_error,sd_sta,fault_sequence,fault_detail;
    uint32_t recording_ms,drain_ms,verify_ms;
    uint32_t phase0,phase1,phase2;
} XE_NP_Np2LiveSdMailbox;

/* Stopped-only profiling; the recording mailbox/wire format stay unchanged. */
typedef struct {
    uint32_t magic,version,max_write_rus,write_calls,completed_calls;
    uint32_t capture_calls,clean_calls,largest_write_rus,producer_error,producer_state;
    uint64_t capture_cycles,clean_cycles,write_cycles,data_cycles,busy_cycles,irq_cycles;
    uint32_t fault_write_age_cycles,fault_dcount,fault_dma_active;
    uint32_t fault_irq_dataend,fault_irq_return,fault_dma_units;
    uint32_t max_launch_gap_cycles,prepare_waits;
    uint64_t launch_gap_cycles;
    uint32_t counted_write_batches,counted_write_fallbacks;
    uint32_t launch_wait_no_ready_events,launch_wait_card_not_idle_events;
    /* Staged diagnostic reuses the reserved word for peak PSRAM spill RUs.
     * Copied packed-dual perf v6 uses it for completed CMD25 wall milliseconds;
     * v4/v5 layouts and the fixed-address mailbox remain unchanged. */
    uint32_t launch_wait_below_min_events,launch_wait_reserved;
    uint64_t launch_wait_no_ready_cycles,launch_wait_card_not_idle_cycles;
    uint64_t launch_wait_below_min_cycles;
    /* Mutually exclusive bench diagnostics in the existing 16-byte tail:
     * v5 CMD25 histogram, explicitly tagged v7 packing-call timing, or v8
     * raw-triple PSSI/D8 copy timing, or v9/v10 foreground DATA samples.
     * These counts are workload-biased observations, not stall durations. */
    union {
        struct {
            uint32_t write_batch_rus_1_4,write_batch_rus_5,write_batch_rus_6;
            uint32_t write_batch_rus_7_11;
        } batch;
        struct {uint64_t cycles;uint32_t calls,max_cycles;} pack;
        struct {uint64_t pssi_copy_cycles,d8_copy_cycles;} triple_copy;
        struct {
            uint32_t previous_dcount,active_polls;
            uint32_t busy_full_stall_polls,empty_stall_polls;
        } data_phase;
        struct {
            uint32_t previous_dcount,active_polls;
            uint32_t unchanged_polls,unchanged_sta_or;
        } data_detail;
    } diagnostic;
} XE_NP_Np2LiveSdPerf;
extern volatile XE_NP_Np2LiveSdPerf xe_np_np2_live_sd_perf;

extern volatile XE_NP_Np2LiveSdMailbox xe_np_np2_live_sd_mailbox;
void XE_NP_Np2LiveSd_Init(SD_HandleTypeDef *,DCACHE_HandleTypeDef *);
/* Caller must already own/reserve the AU-aligned card extent. The writer
 * accepts only whole four-block SD units and never allocates card space.
 * Init() retains the fixed scratch extent for bounded HIL builds. */
void XE_NP_Np2LiveSd_InitExtent(SD_HandleTypeDef *,DCACHE_HandleTypeDef *,
                               uint32_t payload_start_lba,uint32_t block_count);
/* Packed two-probe profile can select 20 or 30 kHz before source startup.
 * Other HIL profiles retain their build-selected rate. */
void XE_NP_Np2LiveSd_InitExtentRate(SD_HandleTypeDef *,DCACHE_HandleTypeDef *,
                                   uint32_t payload_start_lba,uint32_t block_count,
                                   uint32_t sample_hz);
/* Capability is the actual compiled writer, not just a media-format tuple.
 * Profile initialization only replaces a fully quiescent completed session. */
int XE_NP_Np2LiveSd_SupportsProfile(uint32_t probe_mask,uint32_t sample_hz);
void XE_NP_Np2LiveSd_InitExtentProfile(SD_HandleTypeDef *,DCACHE_HandleTypeDef *,
                                      uint32_t payload_start_lba,uint32_t block_count,
                                      uint32_t probe_mask,uint32_t sample_hz);
#if XE_NP_NP2_SD_APPEND_ORDER_TEST
#include "xe_np_np2_sd_append.h"
/* v14 ONLY: caller already reserved/encoded an append descriptor and owns
 * this classic UHS-AU extent. Phase1 accepts 2p30/3p20, not actual VSC.
 * Returns0 only for a newly admitted Init; never infer success from a stale
 * CONFIGURING mailbox left by a refused request. */
int XE_NP_Np2LiveSd_InitExtentAppendProfile(SD_HandleTypeDef *,DCACHE_HandleTypeDef *,
                                            uint32_t payload_start_lba,uint32_t block_count,
                                            uint32_t probe_mask,uint32_t sample_hz,
                                            uint32_t legacy_au_blocks,uint32_t allocation_end_lba);
/* Terminal-only, last card-confirmed counts. A refusal leaves out unchanged;
 * equal counts alone are NOT independent proof of unique payload coverage. */
int XE_NP_Np2LiveSd_GetAppendCounts(XE_NP_Np2SdAppendCounts *out);
#endif
#if XE_NP_NP2_LIVE_SD_VSC_TEST
/* The stopped catalog owns ALL touched AUs and has registered DIR slot0.
 * au_blocks must be freshly read VSC_AU_SIZE, not UHS_AU_SIZE. */
void XE_NP_Np2LiveSd_InitExtentAuRate(SD_HandleTypeDef *,DCACHE_HandleTypeDef *,
                                     uint32_t payload_start_lba,uint32_t block_count,
                                     uint32_t sample_hz,uint32_t au_blocks);
void XE_NP_Np2LiveSd_InitExtentAuProfile(SD_HandleTypeDef *,DCACHE_HandleTypeDef *,
                                        uint32_t payload_start_lba,uint32_t block_count,
                                        uint32_t probe_mask,uint32_t sample_hz,
                                        uint32_t au_blocks);
#if XE_NP_NP2_SD_VSC_FEED_TEST
/* Caller has admitted the exact cold card/scratch and registered scratch DIR0.
 * Repeating physical-RU templates test stored bytes, NOT sample continuity. */
int XE_NP_Np2LiveSd_StoppedVscFeed(SD_HandleTypeDef *,DCACHE_HandleTypeDef *,
                                  uint32_t sample_hz,uint32_t nonce,
                                  volatile uint32_t diagnostic[32]);
#endif
#if XE_NP_NP2_SD_CLASSIC_UHS_AU_TEST
/* v13: caller owns the whole declared allocation. The exact recording bound
 * stays separate from the whole-UHS-AU erase end; no VSC AU is registered. */
void XE_NP_Np2LiveSd_InitExtentClassicAuProfile(SD_HandleTypeDef *,DCACHE_HandleTypeDef *,
                                               uint32_t payload_start_lba,uint32_t block_count,
                                               uint32_t probe_mask,uint32_t sample_hz,
                                               uint32_t legacy_au_blocks,uint32_t allocation_end_lba);
#endif
#endif
void XE_NP_Np2LiveSd_Service(void);
/* Foreground-only BLE yield during stopped verification; never services the
 * app or starts another SD operation. Startup/capture reads are excluded. */
void XE_NP_Np2LiveSd_VerifyBleService(SD_HandleTypeDef *);
void XE_NP_Np2LiveSd_Irq(SD_HandleTypeDef *);
/* Foreground-only controlled stop for the copied packed two-probe profile.
 * Finish the current four-block SD unit, then drain and verify as usual. */
int XE_NP_Np2LiveSd_RequestStop(void);
int XE_NP_Np2LiveSd_CancelPrepared(void);

#endif
#endif
