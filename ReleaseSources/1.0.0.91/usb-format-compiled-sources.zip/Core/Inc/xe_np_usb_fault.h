#ifndef XE_NP_USB_FAULT_H
#define XE_NP_USB_FAULT_H

/*
 * First-fault capture for OTG-HS EP1 IN.  This observer neither acknowledges
 * interrupts nor changes endpoint state: HAL remains the sole register owner.
 */
#include "xe_np_hal.h"

#define XE_NP_USB_FAULT_MAGIC   0x31504655UL /* "UFP1" */
#define XE_NP_USB_FAULT_VERSION 1UL

/* Values are raw DIEPINT bit positions, retained so host tooling can
 * distinguish an AHB/DMA fault from a timeout or an unexpected disable. */
#define XE_NP_USB_FAULT_CAUSE_EPDISD (1UL << 1U)
#define XE_NP_USB_FAULT_CAUSE_AHBERR (1UL << 2U)
#define XE_NP_USB_FAULT_CAUSE_TOC    (1UL << 3U)

/* Fixed 64-byte wire/debug record.  New fields must consume reserved words or
 * require an explicit version bump. */
typedef struct
{
    uint32_t magic;
    uint32_t version;
    uint32_t fault_count;
    uint32_t cause;
    uint32_t tick_ms;
    uint32_t gintsts;
    uint32_t daint;
    uint32_t diepint1;
    uint32_t diepctl1;
    uint32_t dieptsiz1;
    uint32_t dtxfsts1;
    uint32_t gahbcfg;
    uint32_t diepmsk;
    uint32_t daintmsk;
    uint32_t ep1_active;
    uint32_t reserved;
} XE_NP_UsbFaultSnapshot;

_Static_assert(sizeof(XE_NP_UsbFaultSnapshot) == 64U,
               "USB fault snapshot ABI must remain 64 bytes");

/* Set before an EP1 IN transfer is submitted, and clear before any intentional
 * EP1 abort/flush or disconnect.  A normal teardown therefore cannot be
 * mistaken for the unexpected EPDISD condition being investigated. */
void XE_NP_UsbFault_SetEp1Active(uint32_t active);

/* Call immediately before HAL_PCD_IRQHandler().  This only samples/latches;
 * it never clears status, aborts, retries, or enables any interrupt source. */
void XE_NP_UsbFault_BeforeIrq(PCD_HandleTypeDef *hpcd);

/* Clear at the beginning of a new host transfer/session, not from an IRQ. */
void XE_NP_UsbFault_Clear(void);
const volatile XE_NP_UsbFaultSnapshot *XE_NP_UsbFault_GetSnapshot(void);

#endif
