#ifndef XE_NP_CAPTURE_H
#define XE_NP_CAPTURE_H

#include "dataMGR.h"
#include "xe_np_board.h"
#include "xe_np_hal.h"

#define XE_NP_CAPTURE_PROBE1_MASK 0x01U
#define XE_NP_CAPTURE_PROBE2_MASK 0x02U
#define XE_NP_CAPTURE_PROBE3_MASK 0x04U
#define XE_NP_CAPTURE_ALL_PROBES_MASK 0x07U
#define XE_NP_CAPTURE_SELFTEST_GPIOE_DUAL_MASK 0x08U
#if (XE_NP_BOARD_V2_PSSI_NP1_ENABLE != 0U)
#define XE_NP_CAPTURE_SELFTEST_REQUIRED_MASK XE_NP_CAPTURE_PROBE1_MASK
#else
#define XE_NP_CAPTURE_SELFTEST_REQUIRED_MASK \
    (XE_NP_CAPTURE_ALL_PROBES_MASK | XE_NP_CAPTURE_SELFTEST_GPIOE_DUAL_MASK)
#endif

/* NP1 codec geometry only. NP2 raw capture uses 100 ticks / 16 frames below
 * the API; never repurpose this NP1 decoder or its LFP ultraframe for NP2. */
#define XE_NP_CAPTURE_FRAME_WORD_BITS 10U
#define XE_NP_CAPTURE_FRAME_WORD_COUNT 6U
#define XE_NP_CAPTURE_FRAME_DATA_LINES 7U
#define XE_NP_CAPTURE_FRAME_ADC_WORDS 32U
#define XE_NP_CAPTURE_FRAME_BIT_COUNT (XE_NP_CAPTURE_FRAME_WORD_BITS * XE_NP_CAPTURE_FRAME_WORD_COUNT)
#define XE_NP_CAPTURE_FRAMES_PER_SUPERFRAME 13U
#define XE_NP_CAPTURE_SUPERFRAMES_PER_ULTRAFRAME 12U
#define XE_NP_CAPTURE_FRAMES_PER_ULTRAFRAME \
    (XE_NP_CAPTURE_FRAMES_PER_SUPERFRAME * XE_NP_CAPTURE_SUPERFRAMES_PER_ULTRAFRAME)
#define XE_NP_CAPTURE_RING_TIGHT_WINDOW_US 10000UL
#define XE_NP_CAPTURE_RING_SHORT_WINDOW_US 5000UL
#define XE_NP_CAPTURE_DMA_STRESS_BYTES_PER_SEC 45000000UL
/*
 * Keep the raw capture ring on one geometry that is friendly to all three
 * active consumers: 60-byte Neuropixels PSB frames, 512-byte USB bulk/SD
 * block granularity, and HT/TC half-window publication. 61440 bytes gives:
 * - 1024 full PSB frames per node
 * - 120 full 512-byte blocks per node
 * - 30720-byte half-nodes, still aligned to both 60 and 512
 */
#ifndef XE_NP_CAPTURE_DMA_NODE_BYTES
#define XE_NP_CAPTURE_DMA_NODE_BYTES 61440UL
#endif
#define XE_NP_CAPTURE_DMA_NODE_COUNT_MAX 128U
#define XE_NP_CAPTURE_DCACHE_LINE_BYTES 32U

/*
 * RW_NP_CAPTURE in the scatter file reserves this contiguous SRAM3+SRAM5
 * window for producer-owned PSSI DMA. The production profile leaves it
 * cacheable and performs explicit maintenance only for CPU readers; the USB
 * and SD staging DMA engines observe the PSSI DMA writes directly. SRAM3 and
 * SRAM5 are contiguous on the fitted STM32U595QIIx, so V2 uses both banks for
 * stall tolerance without consuming SRAM1 USB/SD staging space. Historical
 * API names retain "Sram3" for source compatibility but cover the full arena.
 */
#define XE_NP_CAPTURE_SRAM3_BASE_ADDR 0x200D0000UL
#define XE_NP_CAPTURE_SRAM3_SIZE_BYTES 0x00180000UL
#ifndef XE_NP_CAPTURE_SRAM3_MPU_NONCACHEABLE
#define XE_NP_CAPTURE_SRAM3_MPU_NONCACHEABLE 0U
#endif

static inline uint8_t XE_NP_Capture_Sram3RangeContained(const void *addr, uint32_t size_bytes)
{
    uintptr_t start_addr;
    uintptr_t end_addr;
    uintptr_t capture_start;
    uintptr_t capture_end;

    if((addr == NULL) || (size_bytes == 0U))
    {
        return 0U;
    }

    start_addr = (uintptr_t)addr;
    end_addr = start_addr + (uintptr_t)size_bytes;
    if(end_addr < start_addr)
    {
        return 0U;
    }

    capture_start = (uintptr_t)XE_NP_CAPTURE_SRAM3_BASE_ADDR;
    capture_end = capture_start + (uintptr_t)XE_NP_CAPTURE_SRAM3_SIZE_BYTES;
    return ((start_addr >= capture_start) && (end_addr <= capture_end)) ? 1U : 0U;
}

#if XE_NP_BOARD_V2_NP2_CAPTURE_ENABLE
/* HT/TC windows must be packable/cache-aligned; NP2 frame boundaries may cross
 * DMA nodes. Each probe's origin is independent of this memory geometry. */
#if ((XE_NP_CAPTURE_DMA_NODE_BYTES % 256UL) != 0UL)
#error "NP2 half-nodes must be whole 128-tick packing quanta"
#endif
#elif ((XE_NP_CAPTURE_DMA_NODE_BYTES % XE_NP_CAPTURE_FRAME_BIT_COUNT) != 0UL)
#error "XE_NP_CAPTURE_DMA_NODE_BYTES must be PSB-frame aligned"
#endif

#if ((XE_NP_CAPTURE_DMA_NODE_BYTES % 512UL) != 0UL)
#error "XE_NP_CAPTURE_DMA_NODE_BYTES must be 512-byte aligned"
#endif

#ifndef XE_NP_CAPTURE_SELFTEST_ENABLE
#define XE_NP_CAPTURE_SELFTEST_ENABLE 0U
#endif

#define XE_NP_PSB_SYNC_WORD_FRAME 0x00CFU
#define XE_NP_PSB_SYNC_WORD_SUPERFRAME 0x0330U
#define XE_NP_PSB_FIXED_WORD_INDEX 2U
#define XE_NP_PSB_COUNTER1_WORD_INDEX 3U
#define XE_NP_PSB_COUNTER0_WORD_INDEX 4U
#define XE_NP_PSB_FILL_WORD_INDEX 5U

#define XE_NP_CAPTURE_FLAG_GPIOE_ACTIVE 0x00000001UL
#define XE_NP_CAPTURE_FLAG_GPIOD_ACTIVE 0x00000002UL
#define XE_NP_CAPTURE_FLAG_TIMERS_READY 0x00000004UL
#define XE_NP_CAPTURE_FLAG_RAW_ONLY 0x00000008UL
#define XE_NP_CAPTURE_FLAG_CLOCK_MODE_UNSUPPORTED 0x00000010UL
#define XE_NP_CAPTURE_FLAG_BUFFER_TIGHT 0x00000020UL
#define XE_NP_CAPTURE_FLAG_BUFFER_SHORT 0x00000040UL
#define XE_NP_CAPTURE_FLAG_DMA_RATE_STRESSED 0x00000080UL
#define XE_NP_CAPTURE_FLAG_TIMER_MISSING 0x00000100UL
#define XE_NP_CAPTURE_FLAG_UNSUPPORTED_PROBE_MASK 0x00000200UL
#define XE_NP_CAPTURE_FLAG_STORAGE_LAYOUT_UNSUPPORTED 0x00000400UL
#define XE_NP_CAPTURE_FLAG_GPIO_LAYOUT_UNSUPPORTED 0x00000800UL

#define XE_NP_PSB_FRAME_FLAG_SYNC_VALID 0x00000001UL
#define XE_NP_PSB_FRAME_FLAG_SUPERFRAME 0x00000002UL
#define XE_NP_PSB_FRAME_FLAG_FILL_ERROR 0x00000004UL
#define XE_NP_PSB_FRAME_FLAG_COUNTER_VALID 0x00000008UL
#define XE_NP_PSB_FRAME_FLAG_SIZE_ERROR 0x00000010UL
#define XE_NP_PSB_FRAME_FLAG_FIXED_PRESENT 0x00000020UL
#define XE_NP_PSB_FRAME_FLAG_HEARTBEAT_ERROR 0x00000040UL

#define XE_NP_PSB_VALIDATOR_FLAG_COUNTER_JUMP 0x00000001UL
#define XE_NP_PSB_VALIDATOR_FLAG_SYNC_ERROR 0x00000002UL
#define XE_NP_PSB_VALIDATOR_FLAG_FILL_ERROR 0x00000004UL
#define XE_NP_PSB_VALIDATOR_FLAG_SUPERFRAME_MISMATCH 0x00000008UL
#define XE_NP_PSB_VALIDATOR_FLAG_HEARTBEAT_ERROR 0x00000010UL
#define XE_NP_PSB_VALIDATOR_FLAG_FIXED_MISMATCH 0x00000020UL
#define XE_NP_CAPTURE_VALIDATOR_PROBE_SHIFT 8U

#define XE_NP_ELECTRODE_PACKET_FLAG_SIZE_ERROR 0x00000001UL
#define XE_NP_ELECTRODE_PACKET_FLAG_SYNC_ERROR 0x00000002UL
#define XE_NP_ELECTRODE_PACKET_FLAG_FRAME_ERROR 0x00000004UL

#define XE_NP_ELECTRODE_STATUS_FLAG_TRIGGER 0x0001U
#define XE_NP_ELECTRODE_STATUS_FLAG_LFP_NAP 0x0002U
#define XE_NP_ELECTRODE_STATUS_FLAG_COUNT_ERROR 0x0004U
#define XE_NP_ELECTRODE_STATUS_FLAG_SERDES_ERROR 0x0008U
#define XE_NP_ELECTRODE_STATUS_FLAG_LOCK_ERROR 0x0010U
#define XE_NP_ELECTRODE_STATUS_FLAG_POP_ERROR 0x0020U
#define XE_NP_ELECTRODE_STATUS_FLAG_EXT_IN 0x0040U
#define XE_NP_ELECTRODE_STATUS_FLAG_SYNC_ERROR 0x0080U

typedef enum
{
    XE_NP_CAPTURE_LAYOUT_NONE = 0,
    XE_NP_CAPTURE_LAYOUT_GPIOE_ONLY = 1,
    XE_NP_CAPTURE_LAYOUT_GPIOD_ONLY = 2,
    XE_NP_CAPTURE_LAYOUT_GPIOE_AND_GPIOD = 3
} XE_NP_CaptureLayout;

typedef struct
{
    TIM_HandleTypeDef *htim;
    dataMGR raw_mgr;
    uint8_t *storage;
    uint32_t storage_bytes;
    uint32_t storage_physical_bytes;
    uint64_t total_bytes_captured;
    uint32_t dma_windows_captured;
    uint8_t active_probe_mask;
    uint8_t bytes_per_tick;
    uint8_t validated_probe_mask;
    uint8_t frame_alignment_locked;
    uint8_t reserved0;
    uint16_t frame_alignment_ticks;
    uint32_t raw_bytes_per_sec;
    uint32_t ring_window_us;
} XE_NP_CapturePort;

typedef struct
{
    uint16_t sync_word;
    uint16_t fixed_word;
    uint16_t line_words[XE_NP_CAPTURE_FRAME_DATA_LINES][XE_NP_CAPTURE_FRAME_WORD_COUNT];
    uint32_t counter_value;
    uint32_t flags;
} XE_NP_PsbFrame;

typedef struct
{
    uint32_t frames_seen;
    uint32_t superframes_seen;
    uint32_t counter_errors;
    uint32_t sync_errors;
    uint32_t fill_errors;
    uint32_t heartbeat_errors;
    uint32_t fixed_word_errors;
    uint32_t superframe_errors;
    uint32_t last_counter_value;
    uint16_t last_fixed_word;
    uint16_t last_sync_word;
    uint16_t expected_fixed_word;
    uint8_t have_counter;
    uint8_t have_superframe_phase;
    uint8_t superframe_counter_mod;
    uint8_t expected_fixed_word_valid;
} XE_NP_PsbValidator;

typedef struct
{
    XE_NP_CapturePort gpioe;
    XE_NP_CapturePort gpiod;
    XE_NP_PsbValidator validators[XE_NP_NEUROPIXELS_MAX_PROBES];
    uint8_t *raw_storage;
    uint32_t raw_storage_bytes;
    uint8_t active_probe_mask;
    uint8_t active_probe_count;
    uint8_t active_port_count;
    uint8_t bytes_per_tick;
    XE_NP_CaptureLayout layout;
    uint32_t psb_clk_hz;
    uint32_t frame_rate_hz;
    uint32_t superframe_rate_hz;
    uint32_t ultraframe_rate_hz;
    uint32_t raw_bytes_per_sec;
    uint32_t decoded_bytes_per_sec;
    uint32_t raw_bytes_per_frame;
    uint32_t raw_bytes_per_superframe;
    uint32_t raw_bytes_per_ultraframe;
    uint32_t ring_window_us;
    uint32_t flags;
} XE_NP_CaptureState;

typedef struct
{
    uint32_t timestamp[XE_NP_CAPTURE_SUPERFRAMES_PER_ULTRAFRAME];
    uint16_t ap_data[XE_NP_CAPTURE_SUPERFRAMES_PER_ULTRAFRAME][XE_NP_NEUROPIXELS_CHANNELS_PER_PROBE];
    uint16_t lfp_data[XE_NP_NEUROPIXELS_CHANNELS_PER_PROBE];
    /* Mirrors the documented Neuropixels electrodePacket status byte per superframe. */
    uint16_t status[XE_NP_CAPTURE_SUPERFRAMES_PER_ULTRAFRAME];
    uint32_t flags;
} XE_NP_ElectrodePacket;

void XE_NP_Capture_Init(XE_NP_CaptureState *state, uint8_t *storage, uint32_t storage_bytes);
void XE_NP_Capture_BindTimers(
    XE_NP_CaptureState *state,
    TIM_HandleTypeDef *tim_gpioe,
    TIM_HandleTypeDef *tim_gpiod);
int XE_NP_Capture_Configure(XE_NP_CaptureState *state, uint8_t active_probe_mask, uint32_t psb_clk_hz);
/*
 * Split the byte-wide GPIOE ring into two virtual, time-interleaved lanes.
 * The second port is storage-only: it contains alternate GPIOE samples and
 * must be interleaved with the first port before PSB decoding.
 */
int XE_NP_Capture_EnableGpioeInterleavedLanes(XE_NP_CaptureState *state);
uint32_t XE_NP_Capture_MinimumBytesPerTick(uint8_t active_probe_mask);
uint32_t XE_NP_Capture_DecodedBytesPerSecond(uint8_t active_probe_mask);
int XE_NP_Capture_IsDmaPacedFeasible(const XE_NP_CaptureState *state);
void XE_NP_Capture_RecordGpioeBytes(XE_NP_CaptureState *state, uint32_t nbytes);
void XE_NP_Capture_RecordGpiodBytes(XE_NP_CaptureState *state, uint32_t nbytes);
void XE_NP_Capture_DCacheInvalidate(const void *addr, uint32_t size_bytes);
void XE_NP_PsbFrame_Reset(XE_NP_PsbFrame *frame);
int XE_NP_PsbFrame_Decode(XE_NP_PsbFrame *frame, const uint8_t *lane_bytes, size_t lane_count);
int XE_NP_PsbFrame_DecodeFromSnapshots(
    XE_NP_PsbFrame *frame,
    const uint16_t *snapshots,
    size_t tick_count,
    uint8_t probe_index);
void XE_NP_PsbValidator_Init(XE_NP_PsbValidator *validator);
void XE_NP_PsbValidator_SetExpectedSyncValue(XE_NP_PsbValidator *validator, uint8_t sync_value);
uint32_t XE_NP_PsbValidator_ConsumeFrame(XE_NP_PsbValidator *validator, const XE_NP_PsbFrame *frame);
uint32_t XE_NP_Capture_ValidateSnapshotBurst(
    XE_NP_CaptureState *state,
    const uint16_t *snapshots,
    size_t tick_count,
    uint8_t port_index);
uint32_t XE_NP_Capture_ValidateSnapshotPrefix(
    XE_NP_CaptureState *state,
    const uint16_t *snapshots,
    size_t tick_count,
    uint8_t port_index,
    size_t sample_frames);
void XE_NP_ElectrodePacket_Reset(XE_NP_ElectrodePacket *packet);
int XE_NP_PsbFrame_ExtractAdcWords(
    const XE_NP_PsbFrame *frame,
    uint16_t *adc_words,
    size_t adc_word_count);
int XE_NP_ElectrodePacket_DecodeUltraframe(
    XE_NP_ElectrodePacket *packet,
    const XE_NP_PsbFrame *frames,
    size_t frame_count);
int XE_NP_ElectrodePacket_DecodeUltraframeFromAlignedSnapshots(
    XE_NP_ElectrodePacket *packet,
    const uint16_t *snapshots,
    size_t tick_count,
    uint8_t probe_index);
int XE_NP_Capture_RunSelfTestMask(uint8_t *pass_mask);
int XE_NP_Capture_RunSelfTest(void);

/*
 * V1 direct GPIO captures use bit0=SYNC and bits1..7=DATA0..6. V2 PSSI
 * captures are already compact bytes with bits0..6=DATA0..6 and bit7=SYNC.
 */
CE32_FORCE_INLINE uint8_t XE_NP_Capture_ExtractNp1LaneByte(uint16_t gpioe_snapshot)
{
    return (uint8_t)(gpioe_snapshot & 0x00FFU);
}

CE32_FORCE_INLINE uint8_t XE_NP_Capture_ExtractNp2LaneByte(uint16_t gpioe_snapshot)
{
    return (uint8_t)((gpioe_snapshot >> 8U) & 0x00FFU);
}

CE32_FORCE_INLINE uint8_t XE_NP_Capture_ExtractNp3LaneByte(uint16_t gpiod_snapshot)
{
    return (uint8_t)((gpiod_snapshot >> 8U) & 0x00FFU);
}

#endif
