#ifndef XE_NP_MEDIA_ADC_H
#define XE_NP_MEDIA_ADC_H

#include "xe_np_board.h"
#include "xe_np_media_profile.h"

#ifndef XE_NP_V2_AUX_ENABLE
#define XE_NP_V2_AUX_ENABLE 0U
#endif

#if XE_NP_V2_MEDIA_ENABLE || XE_NP_V2_AUX_ENABLE
#include "xe_np_hal.h"

/* ADC1/PB0 (IN15), TIM8 and GPDMA1 channel 7 belong exclusively to this
 * backend. The caller retires their old owners, supplies an initialized
 * ADC1 READY handle, powers the ADC and fixes clocks before Prepare.
 * Prepare/Arm/Stop/Copy are foreground-only (working HAL tick); only DmaIrq
 * is IRQ-safe. The caller does not write/reassign the ring before Stop.
 * PCM is unsigned little-endian 14-bit, shifted left by two, at 200 kHz. */
#define XE_NP_MEDIA_ADC_ERROR_CONFIG     0x01000000U
#define XE_NP_MEDIA_ADC_ERROR_STATE      0x02000000U
#define XE_NP_MEDIA_ADC_ERROR_STOP       0x04000000U
#define XE_NP_MEDIA_ADC_ERROR_ADC        0x08000000U
#define XE_NP_MEDIA_ADC_ERROR_CACHE      0x10000000U
#define XE_NP_MEDIA_ADC_ERROR_RETENTION  0x20000000U

/* Four equal, 32-byte-aligned DMA nodes. Legacy media supplies 4x32768;
 * the combined NP role supplies its caller-owned 4x8192 arena. */
int XE_NP_MediaAdc_Prepare(ADC_HandleTypeDef *admitted_adc,
                           uint8_t *caller_owned_ring, uint32_t ring_bytes);
int XE_NP_MediaAdc_Arm(uint32_t start_ms);
int XE_NP_MediaAdc_Stop(void);
uint64_t XE_NP_MediaAdc_ProducedBytes(void);
/* 0: copied; 1: not yet produced; -1: invalid/faulted. A rejected copy must
 * not be published. Copies are even-sized, at most COPY_BYTES, and use a
 * pre/post retention guard; no consumer cursor is changed by this API. */
int XE_NP_MediaAdc_Copy(uint64_t cursor, uint8_t *dest, uint32_t bytes);
uint32_t XE_NP_MediaAdc_Error(void);
uint32_t XE_NP_MediaAdc_IsRunning(void);
uint32_t XE_NP_MediaAdc_StartTick(void);
/* The root-owned DMA7 vector dispatches here. No HAL/cache/copy in IRQ. */
void XE_NP_MediaAdc_DmaIrq(void);
#endif

#endif
