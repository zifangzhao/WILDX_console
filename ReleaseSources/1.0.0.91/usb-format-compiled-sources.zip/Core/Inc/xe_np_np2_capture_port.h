#ifndef XE_NP_NP2_CAPTURE_PORT_H
#define XE_NP_NP2_CAPTURE_PORT_H
#include "xe_np_np2_producer.h"
#include "xe_np_np2_direct_layout.h"
#include "xe_np_np2_live_sd.h"
#ifndef XE_NP_NP2_CAPTURE_PORT_ENABLE
#define XE_NP_NP2_CAPTURE_PORT_ENABLE 0U
#endif
#ifndef XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE
#define XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE 0U
#endif
/* Opt in only in the live-SD experiment until stopped-media verification
 * qualifies the new copy path. Existing USB builds retain their copy loop. */
#ifndef XE_NP_NP2_SPI2_D8_WORD_COPY
#define XE_NP_NP2_SPI2_D8_WORD_COPY 0U
#endif
#ifndef XE_NP_NP2_DIRECT_D8_RAW_PHASE
#define XE_NP_NP2_DIRECT_D8_RAW_PHASE 0U
#endif
#ifndef XE_NP_NP2_SPI2_D8_DIAG_ENABLE
#define XE_NP_NP2_SPI2_D8_DIAG_ENABLE 0U
#endif
#if XE_NP_NP2_CAPTURE_PORT_ENABLE
/* Experimental generation-specific adapter; exclusive PSSI/GPDMA1 channel12.
 * Bind uses the reserved logical token at 0x200D0000. Copied and direct
 * profiles have different logical lengths and physical DMA destinations.
 * Caller must complete cold power/MCO/NRST and both control configurations
 * before Session arms this port. Bind alone performs no hardware writes;
 * both owned NVIC lines must already be disabled with no pending interrupt.
 * Link this TU + producer/session into a NEW NP2 application, never NP1's app.
 * Existing full-NP2 application compile gate remains deliberately closed. */
int XE_NP_Np2CapturePort_Bind(uint8_t *ring,uint32_t bytes,XE_NP_Np2ProducerIo *);
#if XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
/* Cold copied-APP selection: mask3 is PSSI-only, mask7 adds SPI2-D8.
 * A bound IDLE profile is immutable; changing it requires a clean Stop.
 * The writer must exclude physical RU4 while the triple D8 overlay owns it. */
int XE_NP_Np2CapturePort_BindProfile(uint8_t *ring,uint32_t bytes,
                                    XE_NP_Np2ProducerIo *,uint32_t probe_mask);
/* New-session admission only, after the old raw9 extent was fully verified.
 * Retire its post-target lookahead without changing saved recording counters.
 * Never call from capture/Stop or to discard an unverified pending prefix. */
int XE_NP_Np2CapturePort_RetireStoppedTail(uint64_t recorded_ticks);
#endif
/* Finite copied-SD capture: install/update the absolute event-aligned source
 * boundary under the capture lock. Refuse a target below published data or
 * extension of a frozen capture. Bind resets the default to continuous. */
int XE_NP_Np2CapturePort_SetStopTicks(uint64_t ticks);
void XE_NP_Np2CapturePort_Stop(void);
int XE_NP_Np2CapturePort_Armed(void);
void XE_NP_Np2CapturePort_DmaIrq(void);
void XE_NP_Np2CapturePort_PssiIrq(void);
/* Last stopped-only setup checkpoint. It is diagnostic-only and is retained
 * across an arm failure so a safe test image can identify the rejected gate. */
uint32_t XE_NP_Np2CapturePort_LastSetupStage(void);
/* Read-only diagnostic snapshot; foreground only. Never reset/rebase it. */
void XE_NP_Np2CapturePort_Diagnostics(XE_NP_Np2Producer *);
#if XE_NP_NP2_LIVE_SD_DIRECT || XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
/* Cheap lock-free readiness gate from the latest DMA-IRQ-published low tick
 * count. The owned DMA-TC snapshot checks the full peripheral/clock/power
 * state; DirectPrepare uses the published active gate and rechecks sticky
 * faults/D8 lookahead. In the current direct-to-SD sink, release follows
 * completed SD IDMA nodes; an experimental staged sink must instead release
 * only after its GPDMA acquisition handoff completes. */
int XE_NP_Np2CapturePort_DirectReady(uint32_t end_tick_low);
/* READY only after both DMA lanes and SPI lookahead are present. */
int XE_NP_Np2CapturePort_DirectPrepare(uint32_t sequence);
/* Full producer snapshot plus missed-IRQ watchdog; poll at millisecond scale. */
int XE_NP_Np2CapturePort_DirectProgress(uint64_t *published);
/* Retire a sequential absolute RU count after the downstream owner has
 * consumed its bytes (SD IDMA in the current direct sink, GPDMA in staging).
 * The port keeps the producer-ring commit atomic without 64-bit checks inside
 * the interrupt-masked section. */
int XE_NP_Np2CapturePort_DirectRetireRUs(uint32_t end_ru);
#endif

/* Bounded bring-up telemetry for the V2 U$4 D8/SPI2 path.  This diagnostic is
 * compiled only into explicit test images; production uses a circular packed
 * D8 ring and the same SPI2/GPDMA ownership. */
#define XE_NP_NP2_SPI2_D8_DIAG_MAGIC 0x44383253UL /* "S28D" */
#define XE_NP_NP2_SPI2_D8_ERR_STOP          0x00000100UL
#define XE_NP_NP2_SPI2_D8_ERR_ALIGNMENT     0x00000200UL
#define XE_NP_NP2_SPI2_D8_ERR_PSSI_SYNC     0x00000400UL
#define XE_NP_NP2_SPI2_D8_ERR_D8_SYNC       0x00000800UL
typedef struct {
    uint32_t magic,version,state,error;
    uint32_t buffer_address,buffer_capacity,bytes_captured;
    uint32_t kernel_hz,bit_hz;
    uint32_t dma_csr,dma_remaining;
    uint32_t spi_sr,spi_cr1,spi_cfg1,spi_cfg2;
    uint32_t cpol,cpha,first_bit;
    uint32_t calibrated_offset_bits,calibrated_phase,calibration_matches;
} XE_NP_Np2Spi2D8Diag;
extern volatile XE_NP_Np2Spi2D8Diag xe_np_np2_spi2_d8_diag;
#if (XE_NP_NP2_SPI2_D8_DIAG_ENABLE != 0U)
#define XE_NP_NP2_SPI2_D8_DIAG_BYTES 65520U
extern uint8_t xe_np_np2_spi2_d8_samples[XE_NP_NP2_SPI2_D8_DIAG_BYTES];
#endif
#if (XE_NP_NP2_SPI2_D8_CAPTURE_ENABLE != 0U)
#if XE_NP_NP2_LIVE_SD_DIRECT
#define XE_NP_NP2_SPI2_D8_RING_BYTES (NP2_DIRECT_RING_TICKS/8U)
#else
#define XE_NP_NP2_SPI2_D8_RING_BYTES 92160U
#endif
/* Copy chronological D8 bits for a PSSI source span. Source/tick counts are
 * absolute PSSI ticks; destination receives ticks/8 bytes, LSB first. */
int XE_NP_Np2CapturePort_CopyD8(const uint8_t *pssi,uint64_t source_start,uint32_t ticks,
                               uint8_t *destination,uint32_t capacity);
#endif
#endif
#endif
