#ifndef XE_NP_MEDIA_CAMERA_H
#define XE_NP_MEDIA_CAMERA_H

#include "main.h"
#include "xe_np_board.h"
#include "xe_np_media_profile.h"
#include <stdint.h>
#include "../../Firmware/V1/Core/Inc/np_media_metadata.h"

#ifndef XE_NP_V2_AUX_ENABLE
#define XE_NP_V2_AUX_ENABLE 0U
#endif
#if XE_NP_V2_AUX_ENABLE!=0U && XE_NP_V2_AUX_ENABLE!=1U
#error "V2 AUX camera selection must be boolean"
#endif
#if XE_NP_V2_AUX_ENABLE && XE_NP_V2_MEDIA_ENABLE
#error "AUX and dedicated media have different exclusive camera arenas"
#endif

#if XE_NP_V2_MEDIA_ENABLE || XE_NP_V2_AUX_ENABLE
/* Legacy Prepare retains the dedicated150MHz/50Hz profile. The caller retires
 * SPI1 and supplies its role's32-byte-aligned SRAM5 arena. */
int XE_NP_MediaCamera_Prepare(SPI_HandleTypeDef *spi, uint8_t *arena,
                              uint32_t arena_bytes);
#if XE_NP_V2_AUX_ENABLE
/* Cold, foreground only, after NP preparation's DMA reset and before arm.
 * Two immutable160000-byte frames must lie wholly in20220000..20270000.
 * No clock change is performed. A changed kernel requires Release/Prepare. */
int XE_NP_MediaCamera_PrepareRate(SPI_HandleTypeDef *spi,uint8_t *arena,
    uint32_t arena_bytes,uint32_t hz,uint32_t safe_profile);
int XE_NP_MediaCamera_SetRate(uint32_t hz,uint32_t safe_profile);
uint32_t XE_NP_MediaCamera_MaxRate(uint32_t safe_profile);
/* AUX fault/STOP: request only; keep shared power, handle, IRQ and arena owned.
 * Poll IsRetired from foreground until DMA15 and RX binding have retired.
 * A restore failure remains false/sticky; no cold retry or neural teardown. */
void XE_NP_MediaCamera_Retire(void);
int XE_NP_MediaCamera_IsRetired(void);
#endif
/* Idle-only private warmups, immediately before Arm and after stopped I/O. */
int XE_NP_MediaCamera_Settle(void);
int XE_NP_MediaCamera_Arm(uint32_t start_ms);
void XE_NP_MediaCamera_Service(uint32_t now_ms);
/* Retains completed rasters until ConsumeFrame; Release discards them. */
void XE_NP_MediaCamera_StopCapture(void);
int XE_NP_MediaCamera_FinishCapture(void);
int XE_NP_MediaCamera_Release(void);
const uint8_t *XE_NP_MediaCamera_GetFrame(uint32_t *id, uint32_t *tick);
void XE_NP_MediaCamera_ConsumeFrame(void);
uint32_t XE_NP_MediaCamera_MissedCadences(void);
int XE_NP_MediaCamera_Error(void);
uint32_t XE_NP_MediaCamera_CompletedFrames(void);
uint32_t XE_NP_MediaCamera_ConfigurationFlags(void);
int XE_NP_MediaCamera_SetExposure(uint8_t rows,uint8_t gain,uint8_t automatic);
void XE_NP_MediaCamera_ObserveFrame(const uint8_t *frame,uint32_t id,uint32_t tick);
void XE_NP_MediaCamera_Snapshot(NpMediaMetadata *out);
/* Main owns vector/callback dispatch. These are not vector definitions. */
void XE_NP_MediaCamera_DmaIrq(void);
void XE_NP_MediaCamera_SpiIrq(void);
void XE_NP_MediaCamera_HalRxComplete(SPI_HandleTypeDef *spi);
void XE_NP_MediaCamera_HalError(SPI_HandleTypeDef *spi);
#endif

#endif
