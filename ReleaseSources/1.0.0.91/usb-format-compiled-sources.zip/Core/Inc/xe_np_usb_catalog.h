#ifndef XE_NP_USB_CATALOG_H
#define XE_NP_USB_CATALOG_H
#include <stdint.h>
#ifndef XE_NP_USB_CATALOG_REPAIR_ENABLE
#define XE_NP_USB_CATALOG_REPAIR_ENABLE 0U
#endif
#if XE_NP_USB_CATALOG_REPAIR_ENABLE!=0U && XE_NP_USB_CATALOG_REPAIR_ENABLE!=1U
#error "USB catalog repair must be an explicit boolean"
#endif
/* Idle download personality only. GET is a cached64-byte receipt; both OUT
 * commands have no data, with a nonzero32-bit nonce in wIndex:wValue.
 * Foreground performs metadata work, never the SETUP interrupt. No format,
 * erase, rewind, recording START or payload-write operation is defined. */
#define XE_NP_USB_CATALOG_REPORT 0xA0U
#define XE_NP_USB_CATALOG_INSPECT 0xA1U
#define XE_NP_USB_CATALOG_REPAIR 0xA2U
#define XE_NP_USB_CATALOG_CAPABILITY 0x10U
#define XE_NP_USB_CATALOG_MAGIC 0x3152434EU /* NCR1 */
enum { XE_NP_USB_CATALOG_IDLE=0, XE_NP_USB_CATALOG_QUEUED=1,
       XE_NP_USB_CATALOG_RUNNING=2, XE_NP_USB_CATALOG_COMPLETE=3,
       XE_NP_USB_CATALOG_FAILED=4 };
enum { XE_NP_USB_CATALOG_OK=0, XE_NP_USB_CATALOG_BAD_REQUEST=1,
       XE_NP_USB_CATALOG_BUSY=2, XE_NP_USB_CATALOG_NONCE=3,
       XE_NP_USB_CATALOG_IDENTITY=4, XE_NP_USB_CATALOG_IO=5,
       XE_NP_USB_CATALOG_CATALOG=6, XE_NP_USB_CATALOG_CANCELLED=7,
       XE_NP_USB_CATALOG_CLOCK=8 };
/* words: magic, ABI1, operation(A1/A2), state, nonce, error, capacity,
 * catalogflags, nextLBA, CIDcrc32, CID[4], inspectedNonce, USBepoch.
 * REPAIR requires a successful INSPECT from this epoch and the next nonce.
 * COMPLETE does not imply recorded payload integrity or lossless recording. */
#endif
