#ifndef XE_NP_NP2_PRODUCER_H
#define XE_NP_NP2_PRODUCER_H
#include "xe_np_np2_session.h"

#ifndef XE_NP_NP2_CAPTURE_BYTE_DMA
#define XE_NP_NP2_CAPTURE_BYTE_DMA 0U
#endif

#ifndef XE_NP_NP2_SD_RAW_INGRESS_RU_TEST
#define XE_NP_NP2_SD_RAW_INGRESS_RU_TEST 0U
#endif
#if XE_NP_NP2_SD_RAW_INGRESS_RU_TEST!=0U && XE_NP_NP2_SD_RAW_INGRESS_RU_TEST!=1U
#error "Raw-ingress RU trial must be an explicit boolean"
#endif
/* The direct-PSSI trial owns its separate physical layout.  Keep this include
 * after the raw-ingress default above because the layout rejects overlapping
 * experiments at preprocessing time. */
#include "xe_np_np2_direct_layout.h"
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
#if NP2_DIRECT_TICKS!=40960U || NP2_DIRECT_SLOTS!=32U || \
    NP2_DIRECT_RING_TICKS!=(8U*163840U)
#error "Runtime direct PSSI requires the fixed eight-RU, 32-slot geometry"
#endif
#endif
#ifndef XE_NP_NP2_RING_BYTES
#if XE_NP_NP2_SD_RAW_INGRESS_RU_TEST
/* Nine unchanged DMA nodes trade three raw nodes for one copied SD RU. */
#define XE_NP_NP2_RING_BYTES 552960U
#else
#define XE_NP_NP2_RING_BYTES 737280U
#endif
#endif
#ifndef XE_NP_NP2_NODE_BYTES
#define XE_NP_NP2_NODE_BYTES 30720U
#endif
#ifndef XE_NP_NP2_FULL_NODE_IRQ
#define XE_NP_NP2_FULL_NODE_IRQ 0U
#endif
#ifndef XE_NP_NP2_IRQ_REPEAT_BLOCKS
#define XE_NP_NP2_IRQ_REPEAT_BLOCKS 1U
#endif
#if XE_NP_NP2_SD_RAW_INGRESS_RU_TEST && \
    (XE_NP_NP2_RING_BYTES!=552960U || XE_NP_NP2_NODE_BYTES!=61440U || \
     XE_NP_NP2_FULL_NODE_IRQ || XE_NP_NP2_IRQ_REPEAT_BLOCKS!=1U)
#error "Raw-ingress RU trial requires the exact nine-node HT geometry"
#endif
#ifndef XE_NP_NP2_EVENT_LATE_MARGIN_BYTES
/* Measured GPDMA TC assertion can precede the serviced CDAR snapshot by
 * several 16-byte PSSI bursts. Bound that latency without accepting a second
 * missed/coalesced record completion. */
#define XE_NP_NP2_EVENT_LATE_MARGIN_BYTES 256U
#endif
#if (XE_NP_NP2_IRQ_REPEAT_BLOCKS != 1U) && (XE_NP_NP2_IRQ_REPEAT_BLOCKS != 4U)
#error "NP2 full-node repeated-block profile supports one or four DMA blocks"
#endif
#if XE_NP_NP2_IRQ_REPEAT_BLOCKS != 1U && !XE_NP_NP2_FULL_NODE_IRQ
#error "Repeated-block publication requires full-node TC-only mode"
#endif
#if (XE_NP_NP2_NODE_BYTES > 65535U) || (XE_NP_NP2_NODE_BYTES % 128U) || \
    (XE_NP_NP2_NODE_BYTES % 32U)
#error "NP2 GPDMA node must fit the 16-bit block count and 128-tick/cache quanta"
#endif
#if (XE_NP_NP2_RING_BYTES % (XE_NP_NP2_NODE_BYTES * XE_NP_NP2_IRQ_REPEAT_BLOCKS)) || \
    (XE_NP_NP2_RING_BYTES < 4U * XE_NP_NP2_NODE_BYTES * XE_NP_NP2_IRQ_REPEAT_BLOCKS)
#error "NP2 ring must contain at least four complete GPDMA nodes"
#endif
#define XE_NP_NP2_HALF_BYTES (XE_NP_NP2_NODE_BYTES/2U)
/* Use the selected live-SD MCLK when compile-time known, otherwise the
 * slowest runtime stream: SD7.5k at12Mbyte/s, ordinary USB15k at24Mbyte/s. */
#ifndef XE_NP_NP2_SOURCE_BYTE_RATE_HZ
#if defined(XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES) && XE_NP_NP2_LIVE_SD_RUNTIME_PROFILES
#if XE_NP_NP2_DUAL_SD_APP_ENABLE
#define XE_NP_NP2_SOURCE_BYTE_RATE_HZ 12000000UL
#else
#define XE_NP_NP2_SOURCE_BYTE_RATE_HZ 24000000UL
#endif
#elif defined(XE_NP_NP2_LIVE_SD_SAMPLE_HZ)
#define XE_NP_NP2_SOURCE_BYTE_RATE_HZ (XE_NP_NP2_LIVE_SD_SAMPLE_HZ*1600UL)
#else
#define XE_NP_NP2_SOURCE_BYTE_RATE_HZ 24000000UL
#endif
#endif
#if XE_NP_NP2_SOURCE_BYTE_RATE_HZ == 0UL
#error "NP2 source byte rate must be nonzero"
#endif
#if XE_NP_NP2_FULL_NODE_IRQ
#define XE_NP_NP2_EVENT_BYTES (XE_NP_NP2_NODE_BYTES * XE_NP_NP2_IRQ_REPEAT_BLOCKS)
#define XE_NP_NP2_EVENT_LEAD_MAX (XE_NP_NP2_EVENT_BYTES+XE_NP_NP2_EVENT_LATE_MARGIN_BYTES)
#define XE_NP_NP2_FIRST_EVENT XE_NP_NP2_EVENT_TC
#if XE_NP_NP2_IRQ_REPEAT_BLOCKS > 1U
#define XE_NP_NP2_UNPUBLISHED_BOUND (XE_NP_NP2_EVENT_BYTES+XE_NP_NP2_EVENT_LATE_MARGIN_BYTES)
#else
#define XE_NP_NP2_UNPUBLISHED_BOUND (3U*XE_NP_NP2_HALF_BYTES)
#endif
#define XE_NP_NP2_RETENTION_LIMIT (XE_NP_NP2_RING_BYTES-XE_NP_NP2_EVENT_BYTES)
#else
#define XE_NP_NP2_EVENT_BYTES XE_NP_NP2_HALF_BYTES
#define XE_NP_NP2_EVENT_LEAD_MAX XE_NP_NP2_NODE_BYTES
#define XE_NP_NP2_FIRST_EVENT XE_NP_NP2_EVENT_HT
#define XE_NP_NP2_UNPUBLISHED_BOUND (3U*XE_NP_NP2_HALF_BYTES)
#define XE_NP_NP2_RETENTION_LIMIT (XE_NP_NP2_RING_BYTES-XE_NP_NP2_NODE_BYTES)
#endif
/* Two SysTick ticks beyond the rounded-up event interval cover arm/start
 * skew and foreground latency in both IRQ profiles. A 61440-byte node's HT
 * interval is2.56ms at SD7.5k (1.28ms at15k). Position,
 * coalescence and retention checks remain independent and unchanged. */
#define XE_NP_NP2_STALL_TIMEOUT_MS \
    (2U+((XE_NP_NP2_EVENT_BYTES*1000U+XE_NP_NP2_SOURCE_BYTE_RATE_HZ-1U)/ \
         XE_NP_NP2_SOURCE_BYTE_RATE_HZ))
/* Conservative bound for in-flight DMA data plus the input FIFO pipeline.
 * Repeated-block direct mode raises it to one complete RU plus a burst. */
enum { XE_NP_NP2_EVENT_HT=1U, XE_NP_NP2_EVENT_TC=2U };
enum { XE_NP_NP2_PRODUCER_IDLE=0, XE_NP_NP2_PRODUCER_ACTIVE,
       XE_NP_NP2_PRODUCER_STOPPED, XE_NP_NP2_PRODUCER_FAILED,
       XE_NP_NP2_PRODUCER_FROZEN };
enum { XE_NP_NP2_PRODUCER_ARGUMENT=1, XE_NP_NP2_PRODUCER_HW,
       XE_NP_NP2_PRODUCER_IRQ, XE_NP_NP2_PRODUCER_POSITION,
       XE_NP_NP2_PRODUCER_STALL, XE_NP_NP2_PRODUCER_OVERWRITE,
       XE_NP_NP2_PRODUCER_CACHE };
typedef struct {
    uint32_t offset; /* DAR-base, 0..ring bytes inclusive; word aligned */
    uint32_t events; /* OR of status reads before/after DAR; no flags cleared */
    uint32_t now_ms;
    uint32_t fault;  /* raw DMA/PSSI/config/clock fault, sticky at hardware port */
    uint8_t active;
} XE_NP_Np2DmaSnapshot;

/* Single core, foreground consumer + owned DMA IRQ. Critical sections must
 * mask that IRQ, return/restore prior PRIMASK, and include memory barriers.
 * begin initializes the actual 24-node static word DMA with PSSI disabled,
 * then enables PSSI LAST. No I2C/reset/SD work in begin. snapshot is bounded
 * and read-only. stop disables PSSI/DMA, preserves errors during quiescence
 * in a final snapshot, and may assert shared reset, but never power off SD.
 * Cache operations return 0 only on success; no callback may auto-restart. */
typedef struct {
    void *user;
    uint32_t (*lock)(void *);
    void (*unlock)(void *,uint32_t);
    int (*begin)(void *,uint8_t *,uint32_t);
    void (*snapshot)(void *,XE_NP_Np2DmaSnapshot *);
    void (*ack)(void *,uint32_t event);
    void (*stop)(void *,XE_NP_Np2DmaSnapshot *);
    int (*invalidate)(void *,const uint8_t *,uint32_t);
    uint32_t (*now_ms)(void *);
    /* Optional post-W1C recheck. Fill only events/fault/active; a null
     * callback preserves the conservative full-snapshot recheck. */
    void (*irq_recheck)(void *,XE_NP_Np2DmaSnapshot *);
} XE_NP_Np2DmaIo;

typedef struct {
    XE_NP_Np2DmaIo hw;
    uint8_t *ring;
    uint64_t produced,consumed; /* logical ticks, never DMA byte offsets */
    XE_NP_Np2Span held;
    XE_NP_Np2DmaSnapshot last_fault;
    uint32_t published_offset,consumer_offset,last_irq_ms,irq_count,max_backlog;
    /* Diagnostic-only invalidation trace. The mask separates ownership
     * violations from a hardware cache-maintenance failure. */
    uint32_t invalidate_calls,invalidate_fail_mask,last_invalidate_address,last_invalidate_count;
    uint8_t state,error,expected,borrowed,source_bytes_per_tick;
#if XE_NP_NP2_SD_RUNTIME_DIRECT_PSSI_TEST
    /* Cold-selected geometry.  The ordinary build deliberately retains the
     * historical 152-byte producer layout. */
    uint32_t ring_bytes,event_bytes,event_lead_max,unpublished_bound,retention_limit,
             stall_timeout_ms;
    uint8_t full_node_irq;
#endif
} XE_NP_Np2Producer;

/* Modular low-word test for a monotonic tick counter. Safe while producer to
 * consumer distance stays below 2^31 ticks (the NP2 DMA ring is <2^21). */
static inline int XE_NP_Np2Producer_LowCounterReached(uint32_t current,uint32_t target)
{ return (int32_t)(current-target)>=0; }

/* Fresh zeroed state, exclusive ring and callbacks. Bind doesn't start DMA.
 * State/counters/borrow are set BEFORE begin enables capture. No IRQ-side
 * data copy, dynamic allocation, descriptor queue, or counter rebasing. */
int XE_NP_Np2Producer_Bind(XE_NP_Np2Producer *,uint8_t *ring,uint32_t bytes,
                         const XE_NP_Np2DmaIo *,XE_NP_Np2ProducerIo *);
/* Extended PSSI stores one little-endian uint16_t per logical tick. This entry
 * point keeps DMA/ring offsets in bytes while every public source counter and
 * take limit remains in ticks. The established Bind wrapper selects stride1. */
int XE_NP_Np2Producer_BindWithStride(XE_NP_Np2Producer *,uint8_t *ring,
                         uint32_t bytes,uint8_t source_bytes_per_tick,
                         const XE_NP_Np2DmaIo *,XE_NP_Np2ProducerIo *);
void XE_NP_Np2Producer_Irq(XE_NP_Np2Producer *);
/* Finite capture only: limit is an absolute, event-aligned published tick
 * boundary. Zero preserves continuous IRQ semantics. Quiescence occurs at
 * that real publication, not after downstream copying/writing catches up. */
void XE_NP_Np2Producer_IrqUntil(XE_NP_Np2Producer *,uint64_t limit);
/* Certified immutable drain: stop the hardware, retaining the current held
 * span and queued published data. Stop/Abort retain their existing contracts. */
int XE_NP_Np2Producer_Freeze(XE_NP_Np2Producer *);
void XE_NP_Np2Producer_Stop(XE_NP_Np2Producer *);
void XE_NP_Np2Producer_Abort(XE_NP_Np2Producer *);
#endif
