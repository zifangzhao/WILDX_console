#ifndef XE_NP_USB_UNIFIED_H
#define XE_NP_USB_UNIFIED_H
#include <stdint.h>
#ifndef XE_NP_USB_UNIFIED_ENABLE
#define XE_NP_USB_UNIFIED_ENABLE 0U
#endif
#ifndef XE_NP_USB_TX_MPU_NONCACHEABLE
#define XE_NP_USB_TX_MPU_NONCACHEABLE 0U
#endif
#define XE_NP_USB_TX_ARENA_BASE 0x20030000UL
#define XE_NP_USB_TX_ARENA_BYTES 0x00080000UL
#define XE_NP_USB_MODE_MAGIC 0x3253504EU /* NPS2: distinct from V1 */
enum { XE_NP_USB_MODE_SD=1, XE_NP_USB_MODE_STREAM=2,
       XE_NP_USB_MODE_DOWNLOAD=3, XE_NP_USB_MODE_RECOVERY=4 };
typedef struct { volatile uint32_t target, acknowledged, tick; } XE_NP_UsbMode;
static inline int XE_NP_UsbMode_Arm(XE_NP_UsbMode *m,uint32_t target,int busy,uint32_t tick)
{
    if(busy || m->target || target<1U || target>4U)return 0;
    m->acknowledged=0;m->tick=tick;m->target=target;return 1;
}
static inline void XE_NP_UsbMode_Cancel(XE_NP_UsbMode *m){m->target=0;m->acknowledged=0;}
static inline void XE_NP_UsbMode_Ack(XE_NP_UsbMode *m){if(m->target)m->acknowledged=1;}
static inline int XE_NP_UsbMode_Ready(XE_NP_UsbMode *m,uint32_t now)
{
    if(!m->target)return 0;
    if(now-m->tick>=2000U){XE_NP_UsbMode_Cancel(m);return 0;}
    return m->acknowledged && now-m->tick>=50U;
}
/* V1's sticky enumeration policy, armed ONLY by the automatic mailbox.
 * Explicit download/stream/update sessions have checked=1 from the start. */
typedef struct {
    volatile uint32_t attached_ms,enumerated,checked,pending;
} XE_NP_UsbAutoApp;
static inline int XE_NP_UsbAutoApp_Due(const XE_NP_UsbAutoApp *a,
                                      uint32_t now,int busy,uint32_t target)
{
    return !a->enumerated && !a->checked && !busy && !target &&
        (uint32_t)(now-a->attached_ms)>=2000U;
}
static inline void XE_NP_UsbAutoApp_Cancel(XE_NP_UsbAutoApp *a,XE_NP_UsbMode *m)
{
    if(a->pending && a->enumerated){
        if(m->target==XE_NP_USB_MODE_SD)XE_NP_UsbMode_Cancel(m);
        a->pending=0U;
    }
}
static inline void XE_NP_UsbAutoApp_Interrupted(XE_NP_UsbAutoApp *a,uint32_t now)
{
    /* USB reset/disconnect may abort the internal status-free transition.
     * Retry only an unenumerated automatic session, never an explicit mode. */
    if(a->pending){
        a->pending=0U;a->checked=a->enumerated!=0U;a->attached_ms=now;
    }
}
void XE_NP_UsbUnified_SelectBootMode(void);
int XE_NP_UsbUnified_IsDownload(void);
void XE_NP_UsbUnified_Prepare(void);
#endif
