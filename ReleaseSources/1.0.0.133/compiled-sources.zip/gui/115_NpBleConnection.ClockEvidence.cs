using System;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using CE32_console;

namespace USB512_interface {
    internal sealed partial class NpBleConnection {
        NpBleClockContext clockContext;
        CancellationTokenSource recordingClockCancel;
        Task<byte[]> recordingClockTask=Task.FromResult<byte[]>(null);
        internal bool ClockPending {get{return !recordingClockTask.IsCompleted;}}
        internal bool PreviewLowerPriorityBusy {get{return ImuPending || ClockPending;}}
        internal void SetClockContext(string uid,string folder,NpSdStatus status) {
            SetClockContext(0,uid,folder,status);
        }
        internal void SetClockContext(int family,string uid,string folder,NpSdStatus status) {
            lock(clockJournalLock)clockContext=new NpBleClockContext {
                device_family=family==1 || family==2?family:0,
                device_uid=Regex.IsMatch(uid??"","\\A[0-9A-Fa-f]{24}\\z")?uid.ToUpperInvariant():null,
                host_recording_receipt=folder,status_state=status==null?(uint?)null:status.State,
                status_start_lba=status==null?(uint?)null:status.Start,status_sample_hz=status==null?(uint?)null:status.Hz,
                status_probe_mask=status==null?(uint?)null:status.Mask};
        }
        internal void CancelRecordingClock() {
            var cancel=recordingClockCancel;try{if(cancel!=null)cancel.Cancel();}catch(ObjectDisposedException){}
        }
        internal async Task RetireRecordingClock() {
            CancelRecordingClock();
            try{await recordingClockTask;}catch{} // Failure belongs to its own evidence, never to IMU/control.
        }
        internal Task<byte[]> ReadRecordingClock(uint id,CancellationToken cancel) {
            if(ImuPending || ClockPending || !Connected)return Task.FromResult<byte[]>(null);
            var lifetime=CancellationTokenSource.CreateLinkedTokenSource(cancel);recordingClockCancel=lifetime;
            recordingClockTask=ReadRecordingClockCore(id,lifetime);return recordingClockTask;
        }
        async Task<byte[]> ReadRecordingClockCore(uint id,CancellationTokenSource lifetime) {
            try {
                lifetime.CancelAfter(750);
                if(ImuPending)return null;
                return await ExchangeAsync(0xb9,NpV2OnlineClock.Request(0,id),lifetime.Token,true);
            }finally{if(recordingClockCancel==lifetime)recordingClockCancel=null;lifetime.Dispose();}
        }
        internal void ClockCoverageGap(string reason) {
            lock(clockJournalLock){if(clockJournal!=null)clockJournal.ClockGap(clockContext,reason,Stopwatch.GetTimestamp());}
        }
    }
}
