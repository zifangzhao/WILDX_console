using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Web.Script.Serialization;
using System.Threading;
using System.Linq;

namespace USB512_interface
{
    // Optional startup evidence only. Never called from a sample/USB completion loop.
    internal sealed class NpAcquisitionAnchor
    {
        internal const uint RequestMagic=0x5141504e, ReplyMagic=0x5241504e;
        internal uint Flags,Generation,BeforeMs,AfterMs,BeforeCycles,AfterCycles,CounterHz,SourceHz,SampleHz;
        internal ulong Origin;
        internal bool SourceValid { get { return (Flags&13)==13; } }
        internal static byte[] Request(uint id) {
            if(id==0)throw new ArgumentOutOfRangeException("id");
            var b=new byte[64];Put(b,0,RequestMagic);Put(b,4,1);Put(b,8,id);Put(b,60,Crc(b,60));return b;
        }
        internal static NpAcquisitionAnchor Parse(byte[] b,uint id,int version) {
            if(b==null || b.Length!=64 || U(b,0)!=ReplyMagic || U(b,4)!=1 || U(b,8)!=id || U(b,60)!=Crc(b,60) || U(b,56)!=1000)
                throw new InvalidDataException("Invalid acquisition anchor receipt.");
            var a=new NpAcquisitionAnchor {Flags=U(b,12),Generation=U(b,16),BeforeMs=U(b,20),AfterMs=U(b,24),
                BeforeCycles=U(b,28),AfterCycles=U(b,32),CounterHz=U(b,36),SourceHz=U(b,40),Origin=BitConverter.ToUInt64(b,44),SampleHz=U(b,52)};
            if((version!=1 && version!=2) || (a.Flags&~0xff0fU)!=0 || (a.Flags!=0 && (a.Flags>>8)!=(uint)version) ||
                ((a.Flags&1)!=0 && (a.Generation==0 || unchecked(a.AfterMs-a.BeforeMs)>=0x80000000U)) ||
                ((a.Flags&2)!=0 && a.CounterHz==0) || ((a.Flags&4)!=0 && (!a.SourceValid || a.SampleHz==0 || a.SourceHz!=(ulong)a.SampleHz*(version==1?780U:1600U))))
                throw new InvalidDataException("Invalid acquisition anchor domain, flags or rates.");
            return a;
        }
        internal static uint U(byte[] b,int at) { return BitConverter.ToUInt32(b,at); }
        internal static void Put(byte[] b,int at,uint value) { Buffer.BlockCopy(BitConverter.GetBytes(value),0,b,at,4); }
        internal static uint Crc(byte[] b,int count) {
            uint c=UInt32.MaxValue;for(int i=0;i<count;i++){c^=b[i];for(int j=0;j<8;j++)c=(c>>1)^((c&1)==0?0:0xedb88320U);}return ~c;
        }
    }

    // Optional C0/7F read-only reply. HAL milliseconds select the DWT wrap;
    // they do not supply fractional phase or precision to the PC mapping.
    internal sealed class NpCycleClockReply
    {
        internal const uint Magic=0x5248504e;
        public uint Id,Flags,Domain,Generation,BeforeMs,AfterMs,BeforeCycles,AfterCycles,CounterHz,AnchorDomain;
        public string Uid;
        internal static NpCycleClockReply Parse(byte[] bytes,uint id,int family)
        {
            if(bytes==null||bytes.Length!=64||NpAcquisitionAnchor.U(bytes,0)!=Magic||NpAcquisitionAnchor.U(bytes,4)!=1||id==0||
                NpAcquisitionAnchor.U(bytes,8)!=id||NpAcquisitionAnchor.U(bytes,60)!=NpAcquisitionAnchor.Crc(bytes,60))
                throw new InvalidDataException("Invalid high-resolution clock receipt.");
            var p=new NpCycleClockReply {Id=id,Flags=NpAcquisitionAnchor.U(bytes,12),Domain=NpAcquisitionAnchor.U(bytes,16),Generation=NpAcquisitionAnchor.U(bytes,20),
                BeforeMs=NpAcquisitionAnchor.U(bytes,24),AfterMs=NpAcquisitionAnchor.U(bytes,28),BeforeCycles=NpAcquisitionAnchor.U(bytes,32),AfterCycles=NpAcquisitionAnchor.U(bytes,36),
                CounterHz=NpAcquisitionAnchor.U(bytes,40),AnchorDomain=NpAcquisitionAnchor.U(bytes,44),
                Uid=NpAcquisitionAnchor.U(bytes,48).ToString("X8")+NpAcquisitionAnchor.U(bytes,52).ToString("X8")+NpAcquisitionAnchor.U(bytes,56).ToString("X8")};
            if((family!=1&&family!=2)||(p.Flags&~0x307U)!=0||p.Flags!=0&&(p.Flags>>8)!=(uint)family||
                p.Uid==new string('0',24)||p.Uid==new string('F',24)||
                (p.Flags&1)!=0&&(p.Domain==0||p.CounterHz<1000000||p.CounterHz>1000000000||
                    unchecked(p.AfterMs-p.BeforeMs)>2||unchecked(p.AfterCycles-p.BeforeCycles)>p.CounterHz/200)||
                (p.Flags&2)!=0&&(p.Flags&1)==0|| (p.Flags&4)!=0&&(p.Domain==0||p.AnchorDomain!=p.Domain||p.Generation==0))
                throw new InvalidDataException("Invalid high-resolution clock domain or bounds.");
            return p;
        }
        internal static long Unwrap(NpCycleClockReply origin,uint milliseconds,uint cycles)
        {
            uint elapsed=unchecked(milliseconds-origin.BeforeMs);
            if(elapsed>=0x80000000U)throw new InvalidDataException("Ambiguous device clock epoch.");
            double expected=elapsed*(double)origin.CounterHz/1000;
            long raw=unchecked(cycles-origin.BeforeCycles);
            long value=raw+checked((long)Math.Round((expected-raw)/4294967296.0))*4294967296L;
            if(value<0||Math.Abs(value-expected)>origin.CounterHz*.003)
                throw new InvalidDataException("Counter wrap/reset or HAL/DWT clock conflict.");
            return value;
        }
    }

    internal sealed class NpSampleSegment {
        public long row_offset,row_count;public ulong first_source_tick;
        internal NpSampleSegment(long offset,long count,ulong tick){row_offset=offset;row_count=count;first_source_tick=tick;}
    }

    internal sealed class NpFirstSampleRow
    {
        internal int Probe;internal string Band;internal ulong? SourceTick;internal uint SampleHz;internal string Note;
        internal string DataFile;internal int Channels;internal long DataRows;internal uint RateNumerator,RateDenominator;
        internal List<NpSampleSegment> Segments;
        internal NpFirstSampleRow ForData(string path,int channels,long rows,uint numerator,uint denominator=1,IEnumerable<NpSampleSegment> segments=null) {
            DataFile=path;Channels=channels;DataRows=rows;RateNumerator=numerator;RateDenominator=denominator;
            Segments=segments==null?(SourceTick.HasValue?new List<NpSampleSegment>{new NpSampleSegment(0,rows,SourceTick.Value)}:null):new List<NpSampleSegment>(segments);return this;
        }
        internal NpFirstSampleRow(int probe,string band,ulong? tick,uint hz,string note=null) {Probe=probe;Band=band;SourceTick=tick;SampleHz=hz;Note=note;}
    }

    internal sealed class NpAcquisitionTiming
    {
        readonly string folder,identity,epoch=NpHostClock.Epoch;readonly int version;
        readonly long hostUtc=NpHostClock.OriginUtcUs,hostTick=NpHostClock.OriginTicks;
        readonly List<ClockPoint> clock=new List<ClockPoint>();
        readonly List<CyclePoint> cycleClock=new List<CyclePoint>();
        readonly HashSet<uint> cycleIds=new HashSet<uint>();
        static int cycleSequence=BitConverter.ToInt32(Guid.NewGuid().ToByteArray(),0);
        bool cycleUnavailable;string cycleError;
        NpAcquisitionAnchor anchor;byte[] raw;string error;
        sealed class ClockPoint {public uint DeviceMs;public long PcUs,SendPcUs,ReceivePcUs;public double UncertaintyUs;}
        internal sealed class CyclePoint {public bool AfterCapture;public long SendPcUs,ReceivePcUs;public NpCycleClockReply Reply;public string RawHex;}
        internal NpAcquisitionTiming(string directory,string deviceIdentity,int deviceVersion) {folder=directory;identity=deviceIdentity;version=deviceVersion;}
        long Now {get{return hostUtc+(long)((Stopwatch.GetTimestamp()-hostTick)*1000000.0/Stopwatch.Frequency);}}
        // The delegate must return a freshly sampled device tick, NOT a cached sensor publication.
        internal void Observe(Func<uint> freshTick) {
            try {long before=Now;uint tick=freshTick();long after=Now;
                if(after-before>5000000)throw new IOException("Clock request exceeded observation limit.");
                clock.Add(new ClockPoint {DeviceMs=tick,PcUs=before+(after-before)/2,SendPcUs=before,ReceivePcUs=after,UncertaintyUs=(after-before)/2.0+1000+NpHostClock.AnchorHalfWidthUs});
            }catch(Exception ex){error=ex.Message;}
        }
        internal void Read(Func<byte[]> query,uint requestId=0) {
            anchor=null;raw=null;
            try {raw=query();anchor=NpAcquisitionAnchor.Parse(raw,requestId,version);}
            catch(Exception ex){error=ex.Message;}
        }
        internal void Accept(byte[] bytes,uint requestId) {Read(()=>bytes,requestId);}
        internal void ObserveCycleClock(Func<uint,byte[]> query,bool afterCapture=false)
        {
            if(cycleUnavailable)return;
            for(int i=0;i<8;i++)try {
                uint id;do{id=unchecked((uint)Interlocked.Increment(ref cycleSequence));}while(id==0||cycleIds.Contains(id));cycleIds.Add(id);
                long before=(long)Math.Floor(NpHostClock.UnixUs(Stopwatch.GetTimestamp()));byte[] bytes=query(id);
                long after=(long)Math.Ceiling(NpHostClock.UnixUs(Stopwatch.GetTimestamp()));
                var reply=NpCycleClockReply.Parse(bytes,id,version);cycleIds.Add(reply.Domain);cycleIds.Add(reply.AnchorDomain);
                if((reply.Flags&3)!=3||identity.IndexOf(reply.Uid,StringComparison.OrdinalIgnoreCase)<0||after<before||after-before>5000000)
                    throw new InvalidDataException("Continuous device cycle clock unavailable or device identity changed.");
                cycleClock.Add(new CyclePoint {AfterCapture=afterCapture,SendPcUs=before,ReceivePcUs=after,Reply=reply,RawHex=BitConverter.ToString(bytes).Replace("-","")});
            }catch(Exception ex){cycleUnavailable=true;cycleError=ex.Message;break;}
        }
        internal void AcceptCyclePoint(byte[] bytes,uint id,bool afterCapture,long sendPcUs,long receivePcUs)
        {cycleClock.Add(new CyclePoint {AfterCapture=afterCapture,SendPcUs=sendPcUs,ReceivePcUs=receivePcUs,Reply=NpCycleClockReply.Parse(bytes,id,version)});}
        static bool PrecedesRoot(NpCycleClockReply point,NpAcquisitionAnchor root)
        {
            try{return NpCycleClockReply.Unwrap(point,root.BeforeMs,root.BeforeCycles)>=NpCycleClockReply.Unwrap(point,point.AfterMs,point.AfterCycles);}
            catch(InvalidDataException){return false;}
        }
        bool ApplyCycleBounds(Dictionary<string,object> row,ulong sourceTick)
        {
            try {
                if(cycleUnavailable||anchor==null||!anchor.SourceValid||(anchor.Flags&2)==0)return false;
                var post=cycleClock.Where(p=>p.AfterCapture&&(p.Reply.Flags&7)==7&&p.Reply.Generation==anchor.Generation)
                    .OrderBy(p=>p.ReceivePcUs-p.SendPcUs).FirstOrDefault();
                if(post==null)return false;
                var pre=cycleClock.Where(p=>!p.AfterCapture&&p.Reply.Domain==post.Reply.AnchorDomain&&
                    PrecedesRoot(p.Reply,anchor)).OrderBy(p=>p.ReceivePcUs-p.SendPcUs).FirstOrDefault();
                if(pre==null)return false;
                var root=pre.Reply;var end=post.Reply;
                if((root.Flags&3)!=3||end.Domain!=root.Domain||end.CounterHz!=root.CounterHz||end.Uid!=root.Uid||identity.IndexOf(root.Uid,StringComparison.OrdinalIgnoreCase)<0||
                    root.CounterHz!=anchor.CounterHz||(end.Flags&7)!=7||end.Generation!=anchor.Generation||end.AnchorDomain!=root.Domain||
                    pre.ReceivePcUs<pre.SendPcUs||post.ReceivePcUs<post.SendPcUs||post.SendPcUs<=pre.ReceivePcUs)
                    throw new InvalidDataException("High-resolution clock reset, generation, identity or frequency mismatch.");
                double preEnd=NpCycleClockReply.Unwrap(root,root.AfterMs,root.AfterCycles);
                double postStart=NpCycleClockReply.Unwrap(root,end.BeforeMs,end.BeforeCycles),postEnd=NpCycleClockReply.Unwrap(root,end.AfterMs,end.AfterCycles);
                double offset=(double)sourceTick*anchor.CounterHz/anchor.SourceHz;
                double first=NpCycleClockReply.Unwrap(root,anchor.BeforeMs,anchor.BeforeCycles)+offset;
                double last=NpCycleClockReply.Unwrap(root,anchor.AfterMs,anchor.AfterCycles)+offset;
                if(first<preEnd||last<first||last>postStart||postStart<=preEnd||postEnd<postStart)
                    throw new InvalidDataException("First source row lies outside fresh cycle-clock observations.");
                double lowFraction=(first-preEnd)/(postEnd-preEnd),highFraction=last/postStart;
                row["pc_us_lower"]=Math.Floor(pre.SendPcUs+lowFraction*(post.SendPcUs-pre.SendPcUs)-NpHostClock.AnchorHalfWidthUs);
                row["pc_us_upper"]=Math.Ceiling(pre.ReceivePcUs+highFraction*(post.ReceivePcUs-pre.ReceivePcUs)+NpHostClock.AnchorHalfWidthUs);
                row["pc_time_valid"]=true;row["pc_mapping"]="dwt_cycle_affine_interval";row["counter_domain"]=root.Domain;
                row["pc_interval_width_us"]=Convert.ToDouble(row["pc_us_upper"])-Convert.ToDouble(row["pc_us_lower"]);
                row["pre_clock_query_id"]=root.Id;row["post_clock_query_id"]=end.Id;
                row["cycle_us_per_tick"]=(post.SendPcUs+(post.ReceivePcUs-post.SendPcUs)/2.0-pre.SendPcUs-(pre.ReceivePcUs-pre.SendPcUs)/2.0)/((postStart+postEnd-preEnd)/2.0);
                row["clock_interval_scope"]="Positive affine DWT-to-PC clock between fresh pre/post queries; query/counter brackets propagated. HAL ms selects wraps only; no physical ADC/GPIO latency calibration.";
                return true;
            }catch(Exception ex){cycleError=ex.Message;return false;}
        }
        internal static ulong V2FirstRowTick(int phase) {
            if(phase<0 || phase>=1600)throw new ArgumentOutOfRangeException("phase");return (ulong)((1600-phase)%1600);
        }
        internal void Save(IEnumerable<NpFirstSampleRow> rows) {
            try {
                Directory.CreateDirectory(folder);if(raw!=null)File.WriteAllBytes(Path.Combine(folder,"acquisition_anchor.bin"),raw);
                var report=new Dictionary<string,object> {{"schema",1},{"device_identity",identity},{"logger_version",version},{"host_epoch",epoch},
                    {"recording_folder",Path.GetFullPath(folder)},{"raw_receipt_file",raw==null?null:"acquisition_anchor.bin"},{"optional_error",error},
                    {"pc_reference","PC wall clock at host epoch, advanced with Stopwatch; no network correction"},
                    {"limitation","Software receiver-enable/source-row timing; not analog conversion latency. Clock precision is identified by each row's pc_mapping. Two endpoint PC mapping assumes linear device clock between stopped observations."},
                    {"pc_clock",NpHostClock.Receipt},{"clock_observations",clock},{"cycle_clock_observations",cycleClock},{"rows",BuildRows(rows)}};
                report["cycle_clock_error"]=cycleError;
                if(anchor!=null)report["anchor"]=new Dictionary<string,object>{{"flags",anchor.Flags},{"generation",anchor.Generation},{"before_ms",anchor.BeforeMs},{"after_ms",anchor.AfterMs},
                    {"before_cycles",anchor.BeforeCycles},{"after_cycles",anchor.AfterCycles},{"counter_hz",anchor.CounterHz},{"source_hz",anchor.SourceHz},{"sample_hz",anchor.SampleHz},
                    {"exported_source_origin",anchor.Origin},{"source_valid",anchor.SourceValid},{"epoch_quantization_us",1000}};
                File.WriteAllText(Path.Combine(folder,"first_sample_timestamps.json"),new JavaScriptSerializer().Serialize(report));
            }catch { /* Optional timing must never change recording/export completion. */ }
        }
        List<Dictionary<string,object>> BuildRows(IEnumerable<NpFirstSampleRow> rows) {
            var result=new List<Dictionary<string,object>>();
            foreach(var row in rows) {
                var item=new Dictionary<string,object>{{"probe",row.Probe},{"band",row.Band},{"decoder_first_row_source_tick",row.SourceTick},
                    {"row_reference",version==1?"NP1 superframe start; AP channel serialization is not an analog conversion timestamp":"NP2 frame-0 source tick"},
                    {"note",row.Note},{"device_time_valid",false},{"pc_time_valid",false}};
                AddData(item,row,version);result.Add(item);
                if(anchor==null || !anchor.SourceValid || !row.SourceTick.HasValue || row.SampleHz!=anchor.SampleHz)continue;
                ulong total;try{total=checked(anchor.Origin+row.SourceTick.Value);}catch(OverflowException){continue;}
                decimal offset=total*1000000m/anchor.SourceHz;
                decimal lower=anchor.BeforeMs*1000m+offset,upper=(anchor.BeforeMs+(ulong)unchecked(anchor.AfterMs-anchor.BeforeMs))*1000m+offset+1000;
                item["device_time_valid"]=true;item["physical_source_tick"]=total;item["device_us_lower"]=Math.Floor(lower);item["device_us_upper"]=Math.Ceiling(upper);
                if(ApplyCycleBounds(item,total))continue;
                if(clock.Count<2)continue;
                ClockPoint first=clock[0],last=clock[clock.Count-1];uint span=unchecked(last.DeviceMs-first.DeviceMs),root=unchecked(anchor.BeforeMs-first.DeviceMs);
                if(span==0 || span>=0x80000000U || root>span)continue;
                double slope=(last.PcUs-first.PcUs)/(double)span;
                double position=root+(double)offset/1000.0;
                if(slope<900 || slope>1100 || position>span)continue;
                double uncertainty=Math.Max(first.UncertaintyUs,last.UncertaintyUs)+1000;
                item["pc_time_valid"]=true;item["pc_us_lower"]=Math.Floor(first.PcUs+position*slope-uncertainty);
                item["pc_us_upper"]=Math.Ceiling(first.PcUs+(position+unchecked(anchor.AfterMs-anchor.BeforeMs)+1)*slope+uncertainty);
                item["device_ms_to_pc_us_slope"]=slope;
                item["pc_mapping"]="hal_millisecond_affine_interval";
            }
            return result;
        }

        static void AddData(Dictionary<string,object> item,NpFirstSampleRow row,int version) {
            item["data_file"]=row.DataFile;item["channels"]=row.Channels;item["dat_rows"]=row.DataRows;
            item["rate_numerator"]=row.RateNumerator;item["rate_denominator"]=row.RateDenominator;
            item["source_hz"]=(ulong)row.SampleHz*(version==1?780U:1600U);item["segments"]=row.Segments;
            item["bound_scope"]="Conditional software source epoch; excludes unmeasured receiver acceptance and probe ADC/filter/serialization delay, clock nonlinearity and physical GPIO latency.";
        }

        // UTC1 is historical ARM timing. Only self-describing UTC2 attests exported source tick zero.
        internal static void SaveSd(string folder,byte[] sector,uint session,int version,uint sampleHz,IEnumerable<NpFirstSampleRow> rows) {
            try {
                // Preserve the exact optional on-card evidence beside the decoded data, including legacy/invalid sectors.
                if(sector!=null && sector.Length==512)File.WriteAllBytes(Path.Combine(folder,"recorded_clock.bin"),sector);
                bool valid=(version==1 || version==2) && sector!=null && sector.Length==512 && System.Text.Encoding.ASCII.GetString(sector,0,8)==(version==1?"N1SDUTC2":"N2SDUTC2") &&
                    NpAcquisitionAnchor.U(sector,8)==2 && NpAcquisitionAnchor.U(sector,12)==session &&
                    NpAcquisitionAnchor.U(sector,508)==NpAcquisitionAnchor.Crc(sector,508) && NpAcquisitionAnchor.U(sector,72)==sampleHz &&
                    NpAcquisitionAnchor.U(sector,76)==1000;
                uint flags=valid?NpAcquisitionAnchor.U(sector,16):0;
                valid=valid && (flags&~(version==2?15U:7U))==0 && (flags&3)==3 && NpAcquisitionAnchor.U(sector,20)!=0;
                if(valid)for(int i=version==2 && (flags&8U)!=0?112:80;i<508;i++)if(sector[i]!=0){valid=false;break;}
                ulong utc=valid?BitConverter.ToUInt64(sector,32):0;
                uint uncertainty=valid?NpAcquisitionAnchor.U(sector,24):0;
                valid=valid && utc>=1577836800000000UL && utc<=4102444800000000UL && uncertainty>=1000 && uncertainty<=5000000;
                uint before=valid?NpAcquisitionAnchor.U(sector,version==1?64:48):0,after=valid?NpAcquisitionAnchor.U(sector,version==1?68:52):0;
                ulong lo=valid?BitConverter.ToUInt64(sector,version==1?48:56):0,hi=valid?BitConverter.ToUInt64(sector,version==1?56:64):0;
                uint dt=valid?unchecked(before-NpAcquisitionAnchor.U(sector,28)):0,span=unchecked(after-before);
                valid=valid && dt<0x80000000U && span<0x80000000U && (ulong)dt+span<0x80000000UL &&
                    lo==utc+(ulong)dt*1000 && hi==lo+(ulong)span*1000;
                var output=new List<Dictionary<string,object>>();
                foreach(var row in rows){var item=new Dictionary<string,object>{{"probe",row.Probe},{"band",row.Band},{"decoder_first_row_source_tick",row.SourceTick},
                        {"pc_time_valid",valid && row.SourceTick.HasValue && row.SampleHz==sampleHz},{"note",row.Note}};AddData(item,row,version);output.Add(item);
                    if(!(bool)item["pc_time_valid"])continue;
                    decimal offset=row.SourceTick.Value*1000000m/(sampleHz*(version==1?780m:1600m));
                    item["pc_us_lower"]=Math.Floor(lo+offset-uncertainty);item["pc_us_upper"]=Math.Ceiling(hi+offset+uncertainty+1000);
                }
                File.WriteAllText(Path.Combine(folder,"first_sample_timestamps.json"),new JavaScriptSerializer().Serialize(new {schema=1,session_id=session,logger_version=version,
                    reference="Recorded PC clock mapping; network correction separate",raw_receipt_file=sector!=null && sector.Length==512?"recorded_clock.bin":null,source=valid?"SDUTC2 exported source origin":"unavailable; legacy or invalid optional timestamp",
                    limitation="Software source-row timing, not analog conversion latency; nominal source rate, millisecond epoch",rows=output}));
            }catch { }
        }
    }
}
