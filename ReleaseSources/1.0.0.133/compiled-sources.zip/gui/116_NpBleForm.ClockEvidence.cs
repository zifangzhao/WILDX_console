using System;
using System.Threading.Tasks;
using CE32_console;

namespace USB512_interface {
    internal sealed partial class NpBleForm {
        readonly NpBleRecordingClockSchedule recordingClockSchedule=new NpBleRecordingClockSchedule();
        Task bleClockTask=Task.CompletedTask;
        bool recordingClockGapPending;
        void ObserveRecordingClockStatus(NpSdStatus status) {
            long now=bleImuClock.ElapsedMilliseconds;
            recordingClockSchedule.Status(status!=null && NpBleRecordingClockSchedule.Confirmed(recorderVersion,status.State,status.Error,status.Fault),
                status!=null && NpBleRecordingClockSchedule.Capable(recorderVersion,status.Flags),now);
            connection.SetClockContext(recorderVersion,bleDeviceUid,bleRecordingMetadata!=null?bleMetadataFolder:null,status);
        }
        async Task RetireBleRecordingClock(){await connection.RetireRecordingClock();try{await bleClockTask;}catch{}}
        void ResetRecordingClock(){recordingClockSchedule.Reset();recordingClockGapPending=false;}
        async Task PollRecordingClockIfDue() {
            long now=bleImuClock.ElapsedMilliseconds;
            if(!recordingClockSchedule.Due(now))return;
            if(closing || !connection.Connected || busy || hostBusy || stopRequested || stopping || pendingStop!=null ||
                !refreshTask.IsCompleted || !bleImuTask.IsCompleted || connection.ImuPending || !bleClockTask.IsCompleted) {
                recordingClockGapPending=true;return;
            }
            recordingClockSchedule.Attempt(now);bleClockTask=PollRecordingClock();await bleClockTask;
        }
        async Task PollRecordingClock() {
            int epoch=connection.Epoch;
            try {
                if(recordingClockGapPending){connection.ClockCoverageGap("periodic read deferred for recording/control/IMU priority");recordingClockGapPending=false;}
                byte[] reply=await connection.ReadRecordingClock(Next(),System.Threading.CancellationToken.None);
                if(reply==null){recordingClockGapPending=true;return;}
                if(connection.Epoch!=epoch)return;
                // The evidence path parses/stores the raw observation. It never
                // commits a clock or pretends an AP-to-MCU pair was measured.
            }catch(Exception) {
                if(connection.Epoch!=epoch)return;
                recordingClockGapPending=true;recordingClockSchedule.Failed(bleImuClock.ElapsedMilliseconds);
            }
        }
    }
}
