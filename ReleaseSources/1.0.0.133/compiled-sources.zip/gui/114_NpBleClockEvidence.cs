using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Web.Script.Serialization;
using CE32_console;

namespace USB512_interface {
    internal sealed class NpBleClockContext {
        public string device_uid,host_recording_receipt;
        public int device_family;
        public uint? status_state,status_start_lba,status_sample_hz,status_probe_mask;
        public bool on_card_recording_association_verified=false;
    }
    internal sealed class NpBleClockAttempt {
        internal uint Id;internal long SendQpc;internal byte[] Request;internal NpBleClockContext Context;
    }
    // Evidence only: no fitting, AP timestamps, device writes or clock commits.
    internal sealed class NpBleClockEvidence : IDisposable {
        readonly object gate=new object();readonly JavaScriptSerializer json=new JavaScriptSerializer();
        readonly string transport,session=Guid.NewGuid().ToString("N");readonly int epoch;
        readonly HashSet<uint> pending=new HashSet<uint>();
        StreamWriter writer,mirror;string mirrorPath;bool closed;
        internal string Error {get;private set;}
        internal NpBleClockEvidence(string folder,string transportIdentity,int connectionEpoch) {
            transport=transportIdentity;epoch=connectionEpoch;
            try{Directory.CreateDirectory(folder);writer=Open(Path.Combine(folder,"ble_clock_exchange_evidence.jsonl"),false);Write(null,Row("connection_opened",Stopwatch.GetTimestamp()));}
            catch(Exception ex){Error=ex.Message;}
        }
        static StreamWriter Open(string path,bool append){return new StreamWriter(new FileStream(path,append?FileMode.Append:FileMode.CreateNew,FileAccess.Write,FileShare.Read,16384),new UTF8Encoding(false));}
        Dictionary<string,object> Row(string kind,long qpc) {
            return new Dictionary<string,object>{{"schema",1},{"event",kind},{"transport_identity",transport},{"connection_epoch",epoch},
                {"journal_session",session},{"host_epoch",NpHostClock.Epoch},{"host_qpc",qpc},{"host_pc_unix_us",NpHostClock.UnixUs(qpc)},
                {"pc_clock",NpHostClock.Receipt},{"reference","shared_PC_monotonic_anchor; network correction separate"},
                {"ap_source_pair",null},{"device_boot_domain",null},{"acquisition_generation",null}};
        }
        void Write(NpBleClockContext context,Dictionary<string,object> row) {
            if(closed || writer==null)return;
            row["context"]=context;row["identity_scope"]=context!=null && context.device_uid!=null?"exact_MCU_UID":"BLE_transport_identity_only";
            try {
                string line=json.Serialize(row);writer.WriteLine(line);writer.Flush();
                string path=context==null?mirrorPath:String.IsNullOrEmpty(context.host_recording_receipt)?null:
                    Path.Combine(context.host_recording_receipt,"ble_clock_"+session+".jsonl");
                if(path!=mirrorPath){if(mirror!=null)mirror.Dispose();mirror=null;mirrorPath=path;
                    if(path!=null)mirror=Open(path,File.Exists(path));}
                if(mirror!=null){mirror.WriteLine(line);mirror.Flush();}
            }catch(Exception ex){Error=ex.Message;} // Metadata I/O cannot fail a command.
        }
        internal NpBleClockAttempt Begin(byte[] request,long sendQpc,NpBleClockContext context) {
            lock(gate) {
                if(closed || !NpBleConnection.IsReadOnlyClockRequest(0xb9,request))return null;
                var captured=context==null?null:new NpBleClockContext {device_uid=context.device_uid,host_recording_receipt=context.host_recording_receipt,device_family=context.device_family,
                    status_state=context.status_state,status_start_lba=context.status_start_lba,status_sample_hz=context.status_sample_hz,status_probe_mask=context.status_probe_mask};
                var attempt=new NpBleClockAttempt {Id=BitConverter.ToUInt32(request,12),SendQpc=sendQpc,Request=(byte[])request.Clone(),Context=captured};
                pending.Add(attempt.Id);var row=Row("exchange_started",sendQpc);row["request_id"]=attempt.Id;row["request_hex"]=Hex(attempt.Request);
                row["host_send_qpc"]=sendQpc;Write(captured,row);return attempt;
            }
        }
        internal void Finish(NpBleClockAttempt attempt,byte[] response,long receiveQpc,Exception error) {
            lock(gate) {
                if(attempt==null || closed)return;
                pending.Remove(attempt.Id);var row=Row("exchange_finished",receiveQpc);
                row["request_id"]=attempt.Id;row["request_hex"]=Hex(attempt.Request);row["reply_hex"]=response==null?null:Hex(response);
                row["host_send_qpc"]=attempt.SendQpc;row["host_receive_qpc"]=receiveQpc;
                row["host_send_pc_unix_us"]=NpHostClock.UnixUs(attempt.SendQpc);row["host_receive_pc_unix_us"]=NpHostClock.UnixUs(receiveQpc);
                row["receive_scope"]="QPC observed after matching receipt; includes host scheduling, not radio packet timing";
                row["outcome"]=error==null?"reply_unqualified":error is OperationCanceledException?"cancelled":error is TimeoutException?"timeout":"transport_error";
                row["error"]=error==null?null:error.Message;
                if(response!=null)try {
                    var reply=NpV2OnlineClock.Parse(response,0,attempt.Id);
                    row["mcu_rx_ms"]=reply.Rx;row["mcu_tx_ms"]=reply.Tx;row["mcu_counter_hz"]=1000;
                    row["clock_mapping_generation"]=reply.Generation;row["device_reported_mapping_valid"]=reply.Valid;
                    row["device_state"]=reply.State;row["device_reported_mapping_uncertainty_us"]=reply.Uncertainty;
                    row["device_reported_mapping_pc_us"]=reply.Utc;
                    if(error==null)row["outcome"]=receiveQpc>=attempt.SendQpc?"reply_validated":"host_counter_conflict";
                }catch(Exception ex){row["receipt_error"]=ex.Message;}
                Write(attempt.Context,row);
            }
        }
        internal void Gap(NpBleClockContext context,string reason,long qpc) {
            lock(gate){var row=Row("coverage_gap",qpc);row["reason"]=reason;Write(context,row);}
        }
        internal void Close(long qpc,string reason) {
            lock(gate) {
                if(closed)return;
                var row=Row("connection_closed",qpc);row["reason"]=reason;row["unfinished_request_ids"]=new List<uint>(pending);
                Write(null,row);closed=true;try{if(writer!=null)writer.Dispose();if(mirror!=null)mirror.Dispose();}catch(Exception ex){Error=ex.Message;}
                writer=mirror=null;
            }
        }
        public void Dispose(){Close(Stopwatch.GetTimestamp(),"journal_disposed; reconnect requires a new transport epoch");}
        static string Hex(byte[] bytes){return BitConverter.ToString(bytes).Replace("-","");}
    }
    internal sealed class NpBleRecordingClockSchedule {
        long lastStatus=Int64.MinValue,next;bool recording,supported;
        internal static bool Confirmed(int family,uint state,uint error,uint fault){return (family==1 || family==2) && error==0 && fault==0 && state==(family==1?1U:3U);}
        internal static bool Capable(int family,uint flags){return (family==1 || family==2) && (flags&256U)!=0;}
        internal void Status(bool active,bool capability,long now){recording=active;supported=capability;lastStatus=now;}
        internal bool Due(long now){return recording && supported && now>=lastStatus && now-lastStatus<=5000 && now>=next;}
        internal void Attempt(long now){next=now+5000;}
        internal void Failed(long now){next=now+15000;}
        internal void Reset(){lastStatus=Int64.MinValue;next=0;recording=supported=false;}
    }
}
