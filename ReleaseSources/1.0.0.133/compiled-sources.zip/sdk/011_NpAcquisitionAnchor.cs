using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Web.Script.Serialization;

namespace USB512_interface
{
    // Optional startup evidence only. Never called from a sample/USB completion loop.
    internal sealed class NpAcquisitionAnchor
    {
        internal const uint RequestMagic=0x5141504e, ReplyMagic=0x5241504e;
        internal uint Flags,Generation,BeforeMs,AfterMs,BeforeCycles,AfterCycles,CounterHz,SourceHz,SampleHz;
        internal ulong Origin;
        internal bool SourceValid { get { return (Flags&13)==13; } }
        internal static byte[] Request(uint id) {
            if(id==0)throw new ArgumentOutOfRangeException("id");
            var b=new byte[64];Put(b,0,RequestMagic);Put(b,4,1);Put(b,8,id);Put(b,60,Crc(b,60));return b;
        }
        internal static NpAcquisitionAnchor Parse(byte[] b,uint id,int version) {
            if(b==null || b.Length!=64 || U(b,0)!=ReplyMagic || U(b,4)!=1 || U(b,8)!=id || U(b,60)!=Crc(b,60) || U(b,56)!=1000)
                throw new InvalidDataException("Invalid acquisition anchor receipt.");
            var a=new NpAcquisitionAnchor {Flags=U(b,12),Generation=U(b,16),BeforeMs=U(b,20),AfterMs=U(b,24),
                BeforeCycles=U(b,28),AfterCycles=U(b,32),CounterHz=U(b,36),SourceHz=U(b,40),Origin=BitConverter.ToUInt64(b,44),SampleHz=U(b,52)};
            if((version!=1 && version!=2) || (a.Flags&~0xff0fU)!=0 || (a.Flags!=0 && (a.Flags>>8)!=(uint)version) ||
                ((a.Flags&1)!=0 && (a.Generation==0 || unchecked(a.AfterMs-a.BeforeMs)>=0x80000000U)) ||
                ((a.Flags&2)!=0 && a.CounterHz==0) || ((a.Flags&4)!=0 && (!a.SourceValid || a.SampleHz==0 || a.SourceHz!=(ulong)a.SampleHz*(version==1?780U:1600U))))
                throw new InvalidDataException("Invalid acquisition anchor domain, flags or rates.");
            return a;
        }
        internal static uint U(byte[] b,int at) { return BitConverter.ToUInt32(b,at); }
        internal static void Put(byte[] b,int at,uint value) { Buffer.BlockCopy(BitConverter.GetBytes(value),0,b,at,4); }
        internal static uint Crc(byte[] b,int count) {
            uint c=UInt32.MaxValue;for(int i=0;i<count;i++){c^=b[i];for(int j=0;j<8;j++)c=(c>>1)^((c&1)==0?0:0xedb88320U);}return ~c;
        }
    }

    internal sealed class NpSampleSegment {
        public long row_offset,row_count;public ulong first_source_tick;
        internal NpSampleSegment(long offset,long count,ulong tick){row_offset=offset;row_count=count;first_source_tick=tick;}
    }

    internal sealed class NpFirstSampleRow
    {
        internal int Probe;internal string Band;internal ulong? SourceTick;internal uint SampleHz;internal string Note;
        internal string DataFile;internal int Channels;internal long DataRows;internal uint RateNumerator,RateDenominator;
        internal List<NpSampleSegment> Segments;
        internal NpFirstSampleRow ForData(string path,int channels,long rows,uint numerator,uint denominator=1,IEnumerable<NpSampleSegment> segments=null) {
            DataFile=path;Channels=channels;DataRows=rows;RateNumerator=numerator;RateDenominator=denominator;
            Segments=segments==null?(SourceTick.HasValue?new List<NpSampleSegment>{new NpSampleSegment(0,rows,SourceTick.Value)}:null):new List<NpSampleSegment>(segments);return this;
        }
        internal NpFirstSampleRow(int probe,string band,ulong? tick,uint hz,string note=null) {Probe=probe;Band=band;SourceTick=tick;SampleHz=hz;Note=note;}
    }

    internal sealed class NpAcquisitionTiming
    {
        readonly string folder,identity,epoch=NpHostClock.Epoch;readonly int version;
        readonly long hostUtc=NpHostClock.OriginUtcUs,hostTick=NpHostClock.OriginTicks;
        readonly List<ClockPoint> clock=new List<ClockPoint>();
        NpAcquisitionAnchor anchor;byte[] raw;string error;
        sealed class ClockPoint {public uint DeviceMs;public long PcUs,SendPcUs,ReceivePcUs;public double UncertaintyUs;}
        internal NpAcquisitionTiming(string directory,string deviceIdentity,int deviceVersion) {folder=directory;identity=deviceIdentity;version=deviceVersion;}
        long Now {get{return hostUtc+(long)((Stopwatch.GetTimestamp()-hostTick)*1000000.0/Stopwatch.Frequency);}}
        // The delegate must return a freshly sampled device tick, NOT a cached sensor publication.
        internal void Observe(Func<uint> freshTick) {
            try {long before=Now;uint tick=freshTick();long after=Now;
                if(after-before>5000000)throw new IOException("Clock request exceeded observation limit.");
                clock.Add(new ClockPoint {DeviceMs=tick,PcUs=before+(after-before)/2,SendPcUs=before,ReceivePcUs=after,UncertaintyUs=(after-before)/2.0+1000+NpHostClock.AnchorHalfWidthUs});
            }catch(Exception ex){error=ex.Message;}
        }
        internal void Read(Func<byte[]> query,uint requestId=0) {
            anchor=null;raw=null;
            try {raw=query();anchor=NpAcquisitionAnchor.Parse(raw,requestId,version);}
            catch(Exception ex){error=ex.Message;}
        }
        internal void Accept(byte[] bytes,uint requestId) {Read(()=>bytes,requestId);}
        internal static ulong V2FirstRowTick(int phase) {
            if(phase<0 || phase>=1600)throw new ArgumentOutOfRangeException("phase");return (ulong)((1600-phase)%1600);
        }
        internal void Save(IEnumerable<NpFirstSampleRow> rows) {
            try {
                Directory.CreateDirectory(folder);if(raw!=null)File.WriteAllBytes(Path.Combine(folder,"acquisition_anchor.bin"),raw);
                var report=new Dictionary<string,object> {{"schema",1},{"device_identity",identity},{"logger_version",version},{"host_epoch",epoch},
                    {"recording_folder",Path.GetFullPath(folder)},{"raw_receipt_file",raw==null?null:"acquisition_anchor.bin"},{"optional_error",error},
                    {"pc_reference","PC wall clock at host epoch, advanced with Stopwatch; no network correction"},
                    {"limitation","Software receiver-enable/source-row timing; not analog conversion latency. Millisecond epoch quantization remains. Two endpoint PC mapping assumes linear device clock between stopped observations."},
                    {"pc_clock",NpHostClock.Receipt},{"clock_observations",clock},{"rows",BuildRows(rows)}};
                if(anchor!=null)report["anchor"]=new Dictionary<string,object>{{"flags",anchor.Flags},{"generation",anchor.Generation},{"before_ms",anchor.BeforeMs},{"after_ms",anchor.AfterMs},
                    {"before_cycles",anchor.BeforeCycles},{"after_cycles",anchor.AfterCycles},{"counter_hz",anchor.CounterHz},{"source_hz",anchor.SourceHz},{"sample_hz",anchor.SampleHz},
                    {"exported_source_origin",anchor.Origin},{"source_valid",anchor.SourceValid},{"epoch_quantization_us",1000}};
                File.WriteAllText(Path.Combine(folder,"first_sample_timestamps.json"),new JavaScriptSerializer().Serialize(report));
            }catch { /* Optional timing must never change recording/export completion. */ }
        }
        List<Dictionary<string,object>> BuildRows(IEnumerable<NpFirstSampleRow> rows) {
            var result=new List<Dictionary<string,object>>();
            foreach(var row in rows) {
                var item=new Dictionary<string,object>{{"probe",row.Probe},{"band",row.Band},{"decoder_first_row_source_tick",row.SourceTick},
                    {"row_reference",version==1?"NP1 superframe start; AP channel serialization is not an analog conversion timestamp":"NP2 frame-0 source tick"},
                    {"note",row.Note},{"device_time_valid",false},{"pc_time_valid",false}};
                AddData(item,row,version);result.Add(item);
                if(anchor==null || !anchor.SourceValid || !row.SourceTick.HasValue || row.SampleHz!=anchor.SampleHz)continue;
                ulong total;try{total=checked(anchor.Origin+row.SourceTick.Value);}catch(OverflowException){continue;}
                decimal offset=total*1000000m/anchor.SourceHz;
                decimal lower=anchor.BeforeMs*1000m+offset,upper=(anchor.BeforeMs+(ulong)unchecked(anchor.AfterMs-anchor.BeforeMs))*1000m+offset+1000;
                item["device_time_valid"]=true;item["physical_source_tick"]=total;item["device_us_lower"]=Math.Floor(lower);item["device_us_upper"]=Math.Ceiling(upper);
                if(clock.Count<2)continue;
                ClockPoint first=clock[0],last=clock[clock.Count-1];uint span=unchecked(last.DeviceMs-first.DeviceMs),root=unchecked(anchor.BeforeMs-first.DeviceMs);
                if(span==0 || span>=0x80000000U || root>span)continue;
                double slope=(last.PcUs-first.PcUs)/(double)span;
                double position=root+(double)offset/1000.0;
                if(slope<900 || slope>1100 || position>span)continue;
                double uncertainty=Math.Max(first.UncertaintyUs,last.UncertaintyUs)+1000;
                item["pc_time_valid"]=true;item["pc_us_lower"]=Math.Floor(first.PcUs+position*slope-uncertainty);
                item["pc_us_upper"]=Math.Ceiling(first.PcUs+(position+unchecked(anchor.AfterMs-anchor.BeforeMs)+1)*slope+uncertainty);
                item["device_ms_to_pc_us_slope"]=slope;
            }
            return result;
        }

        static void AddData(Dictionary<string,object> item,NpFirstSampleRow row,int version) {
            item["data_file"]=row.DataFile;item["channels"]=row.Channels;item["dat_rows"]=row.DataRows;
            item["rate_numerator"]=row.RateNumerator;item["rate_denominator"]=row.RateDenominator;
            item["source_hz"]=(ulong)row.SampleHz*(version==1?780U:1600U);item["segments"]=row.Segments;
            item["bound_scope"]="Conditional software source epoch; excludes unmeasured receiver acceptance and probe ADC/filter/serialization delay, clock nonlinearity and physical GPIO latency.";
        }

        // UTC1 is historical ARM timing. Only self-describing UTC2 attests exported source tick zero.
        internal static void SaveSd(string folder,byte[] sector,uint session,int version,uint sampleHz,IEnumerable<NpFirstSampleRow> rows) {
            try {
                // Preserve the exact optional on-card evidence beside the decoded data, including legacy/invalid sectors.
                if(sector!=null && sector.Length==512)File.WriteAllBytes(Path.Combine(folder,"recorded_clock.bin"),sector);
                bool valid=(version==1 || version==2) && sector!=null && sector.Length==512 && System.Text.Encoding.ASCII.GetString(sector,0,8)==(version==1?"N1SDUTC2":"N2SDUTC2") &&
                    NpAcquisitionAnchor.U(sector,8)==2 && NpAcquisitionAnchor.U(sector,12)==session &&
                    NpAcquisitionAnchor.U(sector,508)==NpAcquisitionAnchor.Crc(sector,508) && NpAcquisitionAnchor.U(sector,72)==sampleHz &&
                    NpAcquisitionAnchor.U(sector,76)==1000;
                uint flags=valid?NpAcquisitionAnchor.U(sector,16):0;
                valid=valid && (flags&~(version==2?15U:7U))==0 && (flags&3)==3 && NpAcquisitionAnchor.U(sector,20)!=0;
                if(valid)for(int i=version==2 && (flags&8U)!=0?112:80;i<508;i++)if(sector[i]!=0){valid=false;break;}
                ulong utc=valid?BitConverter.ToUInt64(sector,32):0;
                uint uncertainty=valid?NpAcquisitionAnchor.U(sector,24):0;
                valid=valid && utc>=1577836800000000UL && utc<=4102444800000000UL && uncertainty>=1000 && uncertainty<=5000000;
                uint before=valid?NpAcquisitionAnchor.U(sector,version==1?64:48):0,after=valid?NpAcquisitionAnchor.U(sector,version==1?68:52):0;
                ulong lo=valid?BitConverter.ToUInt64(sector,version==1?48:56):0,hi=valid?BitConverter.ToUInt64(sector,version==1?56:64):0;
                uint dt=valid?unchecked(before-NpAcquisitionAnchor.U(sector,28)):0,span=unchecked(after-before);
                valid=valid && dt<0x80000000U && span<0x80000000U && (ulong)dt+span<0x80000000UL &&
                    lo==utc+(ulong)dt*1000 && hi==lo+(ulong)span*1000;
                var output=new List<Dictionary<string,object>>();
                foreach(var row in rows){var item=new Dictionary<string,object>{{"probe",row.Probe},{"band",row.Band},{"decoder_first_row_source_tick",row.SourceTick},
                        {"pc_time_valid",valid && row.SourceTick.HasValue && row.SampleHz==sampleHz},{"note",row.Note}};AddData(item,row,version);output.Add(item);
                    if(!(bool)item["pc_time_valid"])continue;
                    decimal offset=row.SourceTick.Value*1000000m/(sampleHz*(version==1?780m:1600m));
                    item["pc_us_lower"]=Math.Floor(lo+offset-uncertainty);item["pc_us_upper"]=Math.Ceiling(hi+offset+uncertainty+1000);
                }
                File.WriteAllText(Path.Combine(folder,"first_sample_timestamps.json"),new JavaScriptSerializer().Serialize(new {schema=1,session_id=session,logger_version=version,
                    reference="Recorded PC clock mapping; network correction separate",raw_receipt_file=sector!=null && sector.Length==512?"recorded_clock.bin":null,source=valid?"SDUTC2 exported source origin":"unavailable; legacy or invalid optional timestamp",
                    limitation="Software source-row timing, not analog conversion latency; nominal source rate, millisecond epoch",rows=output}));
            }catch { }
        }
    }
}
