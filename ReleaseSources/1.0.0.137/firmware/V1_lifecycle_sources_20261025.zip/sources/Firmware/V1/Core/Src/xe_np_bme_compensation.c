/* Upstream BSD-3-Clause code, unmodified; see Middlewares/Bosch/README.md. */
#define BME280_DOUBLE_ENABLE
#include "bme280.c"
