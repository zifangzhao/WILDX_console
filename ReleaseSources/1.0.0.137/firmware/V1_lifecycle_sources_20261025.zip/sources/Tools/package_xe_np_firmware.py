#!/usr/bin/env python3
"""Create transactional XE_NP update and factory-programming artifacts."""

from __future__ import annotations

import argparse
import hashlib
import pathlib
import struct
import zlib

FLASH_BASE = 0x08000000
LOADER_LIMIT = 0x0801C000
CONFIG_BASE = 0x0801C000
MANIFEST_BASE = 0x0801E000
APP_BASE = 0x08020000
APP_LIMIT = 0x0817E000
USB_MANIFEST_BASE = 0x0817E000
USB_BASE = 0x08180000
USB_LIMIT = 0x08200000
MAIN_SRAM_BASE = 0x20000000
MAIN_SRAM_LIMIT = 0x20270000
SRAM4_BASE = 0x28000000
SRAM4_LIMIT = 0x28004000
MANIFEST_MAGIC = 0x31464E4D504E4558
MANIFEST_FORMAT = 1
MANIFEST_STATE_VALID = 0x56414C44
IMAGE_ID_APPLICATION = 0x41505031
IMAGE_ID_USB_SERVICE = 0x55534231
LOADER_ABI_VERSION = 3
MANIFEST_PREFIX = struct.Struct("<Q9I32s2I10I")


def valid_initial_stack_pointer(vector_sp: int) -> bool:
    in_main_sram = MAIN_SRAM_BASE < vector_sp <= MAIN_SRAM_LIMIT
    in_sram4 = SRAM4_BASE < vector_sp <= SRAM4_LIMIT
    return vector_sp & 7 == 0 and (in_main_sram or in_sram4)


def read_intel_hex(path: pathlib.Path) -> dict[int, int]:
    memory: dict[int, int] = {}
    upper = 0
    for line_number, raw in enumerate(path.read_text(encoding="ascii").splitlines(), 1):
        line = raw.strip()
        if not line:
            continue
        if not line.startswith(":"):
            raise ValueError(f"{path}:{line_number}: invalid Intel HEX record")
        record = bytes.fromhex(line[1:])
        if (sum(record) & 0xFF) != 0:
            raise ValueError(f"{path}:{line_number}: checksum mismatch")
        count = record[0]
        address = (record[1] << 8) | record[2]
        record_type = record[3]
        data = record[4 : 4 + count]
        if len(record) != count + 5:
            raise ValueError(f"{path}:{line_number}: malformed record length")
        if record_type == 0:
            absolute = upper + address
            for offset, value in enumerate(data):
                target = absolute + offset
                if target in memory and memory[target] != value:
                    raise ValueError(f"{path}:{line_number}: conflicting byte at 0x{target:08X}")
                memory[target] = value
        elif record_type == 1:
            break
        elif record_type == 4:
            if count != 2:
                raise ValueError(f"{path}:{line_number}: malformed extended address")
            upper = int.from_bytes(data, "big") << 16
        elif record_type in (2, 3, 5):
            continue
        else:
            raise ValueError(f"{path}:{line_number}: unsupported record type {record_type}")
    return memory


def _hex_record(address: int, record_type: int, data: bytes) -> str:
    body = bytes((len(data), (address >> 8) & 0xFF, address & 0xFF, record_type)) + data
    checksum = (-sum(body)) & 0xFF
    return ":" + (body + bytes((checksum,))).hex().upper()


def write_intel_hex(path: pathlib.Path, memory: dict[int, int]) -> None:
    lines: list[str] = []
    current_upper: int | None = None
    addresses = sorted(memory)
    index = 0
    while index < len(addresses):
        start = addresses[index]
        upper = start >> 16
        if upper != current_upper:
            lines.append(_hex_record(0, 4, upper.to_bytes(2, "big")))
            current_upper = upper
        chunk = bytearray((memory[start],))
        index += 1
        while (
            index < len(addresses)
            and len(chunk) < 16
            and addresses[index] == start + len(chunk)
            and (addresses[index] >> 16) == upper
        ):
            chunk.append(memory[addresses[index]])
            index += 1
        lines.append(_hex_record(start & 0xFFFF, 0, bytes(chunk)))
    lines.append(_hex_record(0, 1, b""))
    path.write_text("\n".join(lines) + "\n", encoding="ascii")


def image_from_hex(memory: dict[int, int], base: int = APP_BASE, limit: int = APP_LIMIT) -> bytes:
    if not memory:
        raise ValueError("application HEX is empty")
    low = min(memory)
    high = max(memory) + 1
    if low != base:
        raise ValueError(f"image begins at 0x{low:08X}, expected 0x{base:08X}")
    if high > limit:
        raise ValueError(f"image ends at 0x{high:08X}, beyond 0x{limit:08X}")
    return bytes(memory.get(address, 0xFF) for address in range(base, high))


def build_manifest(image: bytes, generation: int = 1, image_id: int = IMAGE_ID_APPLICATION) -> bytes:
    if image_id == IMAGE_ID_APPLICATION:
        base, limit = APP_BASE, APP_LIMIT
    elif image_id == IMAGE_ID_USB_SERVICE:
        base, limit = USB_BASE, USB_LIMIT
    else:
        raise ValueError("unknown image ID")
    if len(image) < 8 or len(image) > limit - base:
        raise ValueError("application image size is outside the boot contract")
    vector_sp, vector_reset = struct.unpack_from("<II", image)
    reset_address = vector_reset & ~1
    if not valid_initial_stack_pointer(vector_sp):
        raise ValueError(f"invalid initial stack pointer 0x{vector_sp:08X}")
    if not (vector_reset & 1) or not (base <= reset_address < base + len(image)):
        raise ValueError(f"invalid reset vector 0x{vector_reset:08X}")
    image_crc = zlib.crc32(image) & 0xFFFFFFFF
    build_id = hashlib.sha256(image).hexdigest()[:32].encode("ascii")
    prefix = MANIFEST_PREFIX.pack(
        MANIFEST_MAGIC,
        MANIFEST_FORMAT,
        MANIFEST_STATE_VALID,
        image_id,
        generation,
        base,
        len(image),
        image_crc,
        vector_sp,
        vector_reset,
        build_id,
        0,
        LOADER_ABI_VERSION,
        *([0] * 10),
    )
    assert len(prefix) == 124
    return prefix + struct.pack("<I", zlib.crc32(prefix) & 0xFFFFFFFF)


def validate_loader(memory: dict[int, int]) -> None:
    if not memory:
        raise ValueError("bootloader HEX is empty")
    low = min(memory)
    high = max(memory) + 1
    if low != FLASH_BASE or high > LOADER_LIMIT:
        raise ValueError(
            f"bootloader range 0x{low:08X}..0x{high:08X} violates "
            f"0x{FLASH_BASE:08X}..0x{LOADER_LIMIT:08X}"
        )


def sealed_slot_memory(image: bytes, manifest: bytes) -> dict[int, int]:
    """One flashable slot, with its seal, never loader/settings/other slots."""
    if len(manifest) != 128 or struct.unpack_from("<Q", manifest)[0] != MANIFEST_MAGIC:
        raise ValueError("invalid sealed-slot manifest")
    role = struct.unpack_from("<I", manifest, 16)[0]
    if role == IMAGE_ID_APPLICATION:
        base, seal = APP_BASE, MANIFEST_BASE
    elif role == IMAGE_ID_USB_SERVICE:
        base, seal = USB_BASE, USB_MANIFEST_BASE
    else:
        raise ValueError("unknown sealed-slot role")
    # Recheck vectors/range before emitting address-bearing firmware.
    build_manifest(image, image_id=role)
    if (struct.unpack_from("<II", manifest, 8) != (MANIFEST_FORMAT, MANIFEST_STATE_VALID) or
            struct.unpack_from("<I", manifest, 20)[0] == 0 or
            struct.unpack_from("<III", manifest, 24) != (base, len(image), zlib.crc32(image)) or
            manifest[36:44] != image[:8] or
            manifest[44:76] != hashlib.sha256(image).hexdigest()[:32].encode("ascii") or
            any(manifest[84:124]) or
            struct.unpack_from("<I", manifest, 124)[0] != zlib.crc32(manifest[:124])):
        raise ValueError("sealed-slot body/manifest CRC mismatch")
    memory = {base + i: value for i, value in enumerate(image)}
    memory.update({seal + i: value for i, value in enumerate(manifest)})
    return memory


def package(bootloader_hex: pathlib.Path, app_hex: pathlib.Path, output_dir: pathlib.Path,
            generation: int, usb_service_hex: pathlib.Path | None = None) -> None:
    bootloader = read_intel_hex(bootloader_hex)
    application = read_intel_hex(app_hex)
    validate_loader(bootloader)
    image = image_from_hex(application)
    manifest = build_manifest(image, generation)

    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "XE_NP_Application.bin").write_bytes(image)
    (output_dir / "XE_NP_Application.manifest.bin").write_bytes(manifest)
    (output_dir / "XE_NP_Application.xenp").write_bytes(manifest + image)
    write_intel_hex(output_dir / "XE_NP_Application.hex", sealed_slot_memory(image, manifest))

    combined = dict(bootloader)
    for offset, value in enumerate(manifest):
        combined[MANIFEST_BASE + offset] = value
    for address, value in application.items():
        if address in combined and combined[address] != value:
            raise ValueError(f"bootloader/application overlap at 0x{address:08X}")
        combined[address] = value
    if usb_service_hex is not None:
        service = read_intel_hex(usb_service_hex)
        service_image = image_from_hex(service, USB_BASE, USB_LIMIT)
        service_manifest = build_manifest(service_image, generation, IMAGE_ID_USB_SERVICE)
        (output_dir / "XE_NP_UsbService.bin").write_bytes(service_image)
        (output_dir / "XE_NP_UsbService.manifest.bin").write_bytes(service_manifest)
        write_intel_hex(output_dir / "XE_NP_UsbService.hex",
                        sealed_slot_memory(service_image, service_manifest))
        combined.update(service)
        combined.update({USB_MANIFEST_BASE+i: byte for i, byte in enumerate(service_manifest)})
    write_intel_hex(output_dir / "XE_NP_V2_factory.hex", combined)

    print(f"loader:  0x{min(bootloader):08X}..0x{max(bootloader) + 1:08X}")
    print(f"app:     0x{APP_BASE:08X}..0x{APP_BASE + len(image):08X} ({len(image)} bytes)")
    print(f"crc32:   0x{zlib.crc32(image) & 0xFFFFFFFF:08X}")
    print(f"factory: {output_dir / 'XE_NP_V2_factory.hex'}")
    print(f"app HEX: {output_dir / 'XE_NP_Application.hex'} (application + matching manifest only)")
    print(f"update:  {output_dir / 'XE_NP_Application.xenp'}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bootloader", type=pathlib.Path, required=True)
    parser.add_argument("--application", type=pathlib.Path, required=True)
    parser.add_argument("--output-dir", type=pathlib.Path, required=True)
    parser.add_argument("--generation", type=int, default=1)
    parser.add_argument("--usb-service", type=pathlib.Path)
    args = parser.parse_args()
    package(args.bootloader, args.application, args.output_dir, args.generation, args.usb_service)


if __name__ == "__main__":
    main()
