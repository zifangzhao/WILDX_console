"""V1 four-image sparse factory package; application-only USB updates."""
from pathlib import Path
import sys, struct, zlib, json, hashlib, argparse
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import package_xe_np_firmware as base

MAGIC=0x31464e4d31504e58
ABI=257
SLOTS={'app':(0x08020000,0x0817e000,0x0801e000,0x41505031),
       'stream':(0x08180000,0x081be000,0x0817e000,0x55534231),
       'download':(0x081c0000,0x08200000,0x081be000,0x444c4431)}

def manifest(image,role):
    start,limit,_,image_id=SLOTS[role]
    if not 8<=len(image)<=limit-start:raise ValueError('Image size')
    sp,pc=struct.unpack_from('<II',image)
    if not base.valid_initial_stack_pointer(sp) or not pc&1 or not start<=pc&~1<start+len(image):raise ValueError('Invalid vectors')
    head=base.MANIFEST_PREFIX.pack(MAGIC,1,0x56414c44,image_id,1,start,len(image),zlib.crc32(image),sp,pc,hashlib.sha256(image).hexdigest()[:32].encode(),0,ABI,*([0]*10))
    return head+struct.pack('<I',zlib.crc32(head))

def package(loader,images,out):
    out.mkdir(parents=True,exist_ok=False)
    memory=base.read_intel_hex(loader);base.validate_loader(memory)
    # Validate loader vectors too: malformed entry must never be packaged.
    loader_image=base.image_from_hex(memory,base.FLASH_BASE,base.LOADER_LIMIT)
    sp,pc=struct.unpack_from('<II',loader_image)
    if not base.valid_initial_stack_pointer(sp) or not pc&1 or not base.FLASH_BASE<=pc&~1<base.FLASH_BASE+len(loader_image):raise ValueError('Loader vectors')
    report={'abi':ABI,'hardware_tested':False,'card_writes_during_build':False,'images':{}}
    for role,path in images.items():
        start,limit,meta,_=SLOTS[role];code=base.read_intel_hex(path)
        data=base.image_from_hex(code,start,limit);m=manifest(data,role)
        if set(memory).intersection(code):raise ValueError('Overlap')
        memory.update(code);memory.update({meta+i:b for i,b in enumerate(m)})
        (out/f'{role}.bin').write_bytes(data);(out/f'{role}.manifest.bin').write_bytes(m)
        if role=='app':(out/'V1_SD_Application.xenp').write_bytes(m+data)
        report['images'][role]={'base':start,'limit':limit,'manifest':meta,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    if any(0x0801c000<=a<0x0801e000 for a in memory):raise ValueError('Config page included')
    base.write_intel_hex(out/'V1_factory.hex',memory)
    (out/'package.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--loader',type=Path,required=True)
    for role in SLOTS:p.add_argument('--'+role,type=Path,required=True)
    p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    package(a.loader,{r:getattr(a,r) for r in SLOTS},a.out)
