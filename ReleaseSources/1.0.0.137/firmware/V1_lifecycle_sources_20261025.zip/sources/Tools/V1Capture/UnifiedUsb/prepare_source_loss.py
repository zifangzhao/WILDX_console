"""Prepare a paired-USB producer overlay; never edit verified input snapshots."""
from pathlib import Path
import argparse


def once(text, before, after):
    if text.count(before) != 1:
        raise ValueError('USB source-loss anchor changed: ' + before[:80])
    return text.replace(before, after)


def prepare(text):
    text = once(text,
        'static void np3_reset(void)\n{',
        '#include "np_usb_source_loss.h"\nstatic void np3_reset(void)\n{\n    np_usb_loss_reset();')
    text = once(text,
        '    int ready=np3_observe(bytes);if(ready<=0)return ready;',
        '    if(np_usb_loss_pending){int moving=np_usb_loss_ready();if(moving<=0)return moving;}\n'
        '    int ready=np3_observe(bytes);\n'
        '    if(ready<0 && np_usb_loss_recover())return 0;\n'
        '    if(ready<=0)return ready;\n'
        '    np_usb_loss_resynced();')
    text = once(text,
        '    if(!xe_np_quad_dma_active || !np3_valid || np3_claimed)return np3_fail(15);\n'
        '    return np3_observe(0U);',
        '    if(!xe_np_quad_dma_active || np3_claimed)return np3_fail(15);\n'
        '    if(np_usb_loss_pending)return np_usb_loss_ready()<0?-1:0;\n'
        '    if(!np3_valid)return np3_fail(15);\n'
        '    int ready=np3_observe(0U);\n'
        '    if(ready<0 && np_usb_loss_recover())return 0;\n'
        '    return ready;')
    return text


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit('Fresh output required')
    args.output.write_text(prepare(args.input.read_text()), encoding='utf-8', newline='\n')
