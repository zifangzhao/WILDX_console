"""Actual paired producer/planner: recover only unclaimed native20k history."""
from pathlib import Path
import argparse
import subprocess
from prepare_source_loss import prepare, once


EXTRA = r'''
    setup(need);for(unsigned i=0;i<4;i++)regs[i].CCR=DMA_CCR_EN;
    assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(!XE_NP_App_CommitUsbQuadDmaBatch(&a));
    tick=20;heads(need+payload*2U);
    assert(!XE_NP_App_CheckUsbQuadDmaRetention());
    assert(!np3_diag[1] && np_usb_loss_pending && np_usb_loss_diag[0]==1);
    for(unsigned i=0;i<8;i++)assert(!XE_NP_App_CheckUsbQuadDmaRetention());
    assert(!XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)); /* no new head progress */
    heads(need+payload*2U+16U);
    assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(!np_usb_loss_pending && np_usb_loss_diag[0]==1 && np_usb_loss_diag[1]==1);
    assert(!XE_NP_App_CommitUsbQuadDmaBatch(&a));
    tick=40;heads(need+payload*2U+32U);
    assert(!XE_NP_App_BeginUsbQuadDmaBatch(payload,&a));
    heads(need+payload*2U+48U);
    assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(np_usb_loss_diag[0]==2 && np_usb_loss_diag[1]==2);
    assert(!XE_NP_App_CommitUsbQuadDmaBatch(&a));
    for(unsigned fault=0;fault<3;fault++){
        setup(need);for(unsigned i=0;i<4;i++)regs[i].CCR=DMA_CCR_EN;
        assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
        assert(!XE_NP_App_CommitUsbQuadDmaBatch(&a));tick=20;
        if(fault==0)regs[2].CSR|=DMA_FLAG_DTE;
        if(fault==1)regs[2].CDAR=0;
        if(fault==2)regs[2].CCR=0;
        assert(XE_NP_App_CheckUsbQuadDmaRetention()<0);
        assert(!np_usb_loss_diag[0] && !np_usb_loss_pending);
        assert(np3_diag[1]==(fault==1?12U:11U));
    }
    setup(need);for(unsigned i=0;i<4;i++)regs[i].CCR=DMA_CCR_EN;
    assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    tick=20;assert(XE_NP_App_CommitUsbQuadDmaBatch(&a)<0);
    assert(!np_usb_loss_recover() && np3_claimed && !np_usb_loss_diag[0]);
    XE_NP_App_CancelUsbQuadDmaBatch();
    np_mode_hz=15000;assert(!np_usb_loss_recover() && np3_diag[1]==10);
    np_mode_hz=20000;np_usb_loss_diag[0]=UINT32_MAX;
    assert(np_usb_loss_recover() && np_usb_loss_diag[0]==UINT32_MAX);
    np3_reset();assert(!np_usb_loss_pending && !np_usb_loss_diag[0]);
'''


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.baseline = args.baseline.resolve()
    root = Path(__file__).resolve().parents[3]
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    (out / 'np3_producer.inc').write_text(prepare(args.baseline.read_text()), newline='\n')
    fixture = (root / 'Tools/V1Capture/Release/test_usb20_paired.c').read_text()
    fixture = once(fixture, '#define DMA_FLAG_TC 1U', '#define DMA_CCR_EN 1U\n#define DMA_FLAG_TC 1U')
    fixture = once(fixture, 'typedef struct {uint32_t CSR,CDAR;}', 'typedef struct {uint32_t CSR,CDAR,CCR;}')
    fixture = once(fixture, 'static int emulate(', '#if !defined(PAIRED_RAW)\nstatic int emulate(')
    fixture = once(fixture, 'int main(void){', '#endif\nint main(void){')
    marker = '    puts("PASS paired raw producer/planner:'
    if fixture.count(marker) != 1:
        raise ValueError('Planner fixture changed')
    fixture = fixture.replace(marker, EXTRA + '\n' + marker)
    (out / 'test.c').write_text(fixture, newline='\n')
    vc = 'C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars32.bat'
    cmd = (f'call "{vc}" >nul && cl /nologo /std:c11 /TC /O2 /W4 /WX '
           f'/DPAIRED_RAW /DNP_DIRECT_GROUPS=28 /I"{out}" '
           f'/I"{args.baseline.parent.parent / "Inc"}" '
           f'/I"{root / "Firmware/V1/Core/Inc"}" "{out / "test.c"}" '
           f'/Fo"{out / "test.obj"}" /Fe"{out / "test.exe"}" && "{out / "test.exe"}"')
    subprocess.run(cmd, shell=True, check=True, cwd=out)
    print('PASS native20k unclaimed source loss: counted resume after fresh head progress; claimed/hard errors and other rates remain strict')
