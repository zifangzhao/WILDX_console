"""Merge current verified V1 recovery/USB and APP HEX; no historical inputs."""
from pathlib import Path
import argparse
import hashlib
import struct
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from package_xe_np_firmware import read_intel_hex, write_intel_hex

FLASH, CONFIG, APP_META, APP, USB_META, USB, END = (
    0x08000000, 0x0801c000, 0x0801e000, 0x08020000,
    0x0817e000, 0x08180000, 0x08200000)


def merge(dfu, app):
    if not dfu or not app or dfu.keys() & app.keys():
        raise ValueError('Two nonempty, nonoverlapping verified inputs required')
    if any(not (FLASH <= a < CONFIG or USB_META <= a < END) for a in dfu):
        raise ValueError('DFU/boot+USB input escapes its partitions')
    if any(not APP_META <= a < USB_META for a in app):
        raise ValueError('APP input escapes its partition')
    result = {**dfu, **app}
    for meta in (APP_META, USB_META):
        if any(meta+i not in result for i in range(128)):
            raise ValueError('Verified input is missing its manifest')
    for start, limit in ((FLASH, CONFIG), (APP, USB_META), (USB, END)):
        try: sp, pc = struct.unpack('<II', bytes(result[start+i] for i in range(8)))
        except KeyError: raise ValueError('Missing recovery/APP/USB vector') from None
        stack_ok = 0x20000000 < sp <= 0x20270000 or 0x28000000 < sp <= 0x28004000
        if (not stack_ok or sp & 7 or not pc & 1 or
                not start <= pc-1 < limit or pc-1 not in result):
            raise ValueError('Entry vector or stack exceeds V1 memory bounds')
    # WILDX distinguishes a full fused image by complete firmware coverage.
    # Preserve verified bytes and represent unused flash as erased; never
    # include the retained configuration page. Validate sparse inputs first
    # so padding cannot disguise a missing manifest or entry vector.
    for start, limit in ((FLASH, CONFIG), (APP_META, END)):
        for address in range(start, limit):
            result.setdefault(address, 0xff)
    return result


def self_test():
    dfu, app = {}, {}
    for target, start in ((dfu, FLASH), (dfu, USB), (app, APP)):
        target.update(enumerate(struct.pack('<II', 0x20010000, start+9), start))
        target[start+8] = 0
    for target, meta in ((dfu, USB_META), (app, APP_META)):
        target.update((meta+i, 0) for i in range(128))
    merged = merge(dfu, app)
    assert len(merged) == END-FLASH-(APP_META-CONFIG)
    assert all(merged[a] == b for a,b in {**dfu, **app}.items())
    assert not any(CONFIG <= a < APP_META for a in merged)
    assert merged[FLASH+9] == merged[APP+9] == 0xff
    for bad_dfu, bad_app in (
        ({**dfu, CONFIG:0}, app), ({**dfu, END:0}, app),
        ({**dfu, APP:0}, app), (dfu, {**app, FLASH:0}),
        (dfu, {**app, APP+4:0}),
        ({a:b for a,b in dfu.items() if a != FLASH}, app),
        (dfu, {a:b for a,b in app.items() if a != APP_META})):
        try: merge(bad_dfu, bad_app)
        except ValueError: pass
        else: raise AssertionError('Unsafe layout accepted')
    print('PASS direct merge and layout/entry rejection checks')


def main():
    if sys.argv[1:] == ['--self-test']:
        self_test(); return
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('dfu', 'app', 'output'): parser.add_argument(name, type=Path)
    args = parser.parse_args()
    if args.output.exists(): raise FileExistsError('Use a fresh output path')
    result = merge(read_intel_hex(args.dfu), read_intel_hex(args.app))
    write_intel_hex(args.output, result)
    data = args.output.read_bytes().replace(b'\r\n', b'\n')
    args.output.write_bytes(data)
    print(f'{args.output} sha256={hashlib.sha256(data).hexdigest()} bytes={len(data)}')


if __name__ == '__main__': main()
