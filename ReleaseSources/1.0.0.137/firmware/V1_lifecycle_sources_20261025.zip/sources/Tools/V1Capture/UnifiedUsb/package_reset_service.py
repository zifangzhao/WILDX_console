"""Package only the V1 ABI258 USB service and its manifest; leave SD/app intact."""
from pathlib import Path
import argparse
from datetime import datetime, timezone
import importlib.util
import json
import sys
import struct
import zlib

module_path = Path(__file__).resolve().parent.parent / 'Split/package.py'
spec = importlib.util.spec_from_file_location('v1_split_package', module_path)
package = importlib.util.module_from_spec(spec)
spec.loader.exec_module(package)
package.ABI = 258
package.SLOTS['stream'] = (0x08180000, 0x08200000, 0x0817E000, 0x55534231)
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from firmware_identity import artifact_name, identity


def build(image_path, output_path, version=None, unified_default=False):
    image_path, output_path = Path(image_path), Path(output_path)
    version, stamp = identity(version, datetime.fromtimestamp(image_path.stat().st_mtime, timezone.utc))
    named = output_path.with_name(artifact_name('V1_USB_service_candidate', '.hex', version, stamp))
    receipt = named.with_suffix('.json')
    if output_path.exists() or named.exists() or receipt.exists():
        raise ValueError('Fresh service package paths required')
    code = package.base.read_intel_hex(image_path)
    start, limit, manifest_address, _ = package.SLOTS['stream']
    if not code or any(address < start or address >= limit for address in code):
        raise ValueError('Image escapes the V1 USB service slot')
    image = package.base.image_from_hex(code, start, limit)
    manifest = bytearray(package.manifest(image, 'stream'))
    if unified_default:
        struct.pack_into('<I', manifest, 76, 1)
        struct.pack_into('<I', manifest, 124, zlib.crc32(manifest[:124]))
    code.update({manifest_address + offset: value for offset, value in enumerate(manifest)})
    package.base.write_intel_hex(output_path, code)
    if named != output_path:
        named.write_bytes(output_path.read_bytes())
    receipt.write_text(json.dumps(dict(version=version, build_utc=stamp,
        build_timestamp_source='linked HEX mtime UTC', versioned_service_package=named.name,
        role='USB service only', abi=258, hardware_programmed=False,
        implant_deployment_qualified=False, protected_app_updater_accepts_this=False,
        unified_usb_default=unified_default), indent=2)+'\n')
    print('V1 USB-service-only ABI258 HEX generated; SD app, loader and card untouched.')


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('image', type=Path); p.add_argument('output', type=Path); p.add_argument('--version')
    p.add_argument('--unified-default',action='store_true')
    a = p.parse_args(); build(a.image, a.output, a.version, a.unified_default)
