param([string]$OutputDirectory='_artifacts/sensors_20260909/tests')
$ErrorActionPreference='Stop'
$taskRoot=Split-Path -Parent $PSScriptRoot
$taskOut=if([IO.Path]::IsPathRooted($OutputDirectory)){$OutputDirectory}else{Join-Path $taskRoot $OutputDirectory}
New-Item -ItemType Directory -Force $taskOut | Out-Null
$taskVc='C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat'
$taskSources=@('Tools/tests/test_np_sensors.c','Core/Src/xe_np_sensors.c','Core/Src/xe_np_bme_compensation.c','Core/Src/xe_np_bmm_compensation.c')
$taskSourcesArg=($taskSources | ForEach-Object { '"'+(Join-Path $taskRoot $_)+'"' }) -join ' '
$taskExe=Join-Path $taskOut 'test_np_sensors.exe'
$taskCmd='call "'+$taskVc+'" >nul && cl /nologo /std:c11 /W4 /WX /TC /Od /I"'+(Join-Path $taskRoot 'Core/Inc')+'" '+$taskSourcesArg+' /Fo"'+$taskOut+'/" /Fe"'+$taskExe+'"'
& $env:ComSpec /d /c $taskCmd
if($LASTEXITCODE -ne 0) { throw 'Sensor native test compilation failed' }
& $taskExe
if($LASTEXITCODE -ne 0) { throw 'Sensor native tests failed' }
