#include "xe_np_sensors_port.h"
#include "xe_np_sensor_queue.h"
#ifndef NP_SD_BME_WIRING_CONFIRMED
#define NP_SD_BME_WIRING_CONFIRMED 0
#endif
#include <string.h>

static XE_NP_Sensors sensors;
static XE_NP_SensorQueue record_queue;
volatile uint32_t np_sd_sensor_queue_diag[6]; /* active,count,peak,pushed,popped,overflow */
static void queue_diag(void)
{
    np_sd_sensor_queue_diag[0]=record_queue.active;np_sd_sensor_queue_diag[1]=record_queue.count;
    np_sd_sensor_queue_diag[2]=record_queue.peak;np_sd_sensor_queue_diag[3]=record_queue.pushed;
    np_sd_sensor_queue_diag[4]=record_queue.popped;np_sd_sensor_queue_diag[5]=record_queue.overflow;
}
static I2C_HandleTypeDef *buses[2];
static uint32_t tokens[2];
static uint8_t initialized;
XE_NP_SensorSnapshot xe_np_sensor_snapshot[2];
volatile uint32_t xe_np_sensor_snapshot_index;
XE_NP_SensorFault xe_np_sensor_fault[2];
static const IRQn_Type event_irq[2]={I2C5_EV_IRQn,I2C6_EV_IRQn};
static const IRQn_Type error_irq[2]={I2C5_ER_IRQn,I2C6_ER_IRQn};
typedef char sensor_snapshot_wire_size[(sizeof(XE_NP_SensorSnapshot)==140U)?1:-1];

static int start(void *ctx,uint8_t bus,uint8_t address,uint8_t reg,uint8_t *data,
                 uint16_t length,uint8_t write,uint32_t token)
{
    HAL_StatusTypeDef status;I2C_HandleTypeDef *h=buses[bus];(void)ctx;
    if(!h||!h->Instance)return -1;
    tokens[bus]=token;__DMB();
    /* U5 Mem_*_IT returns HAL_BUSY immediately, without a polling timeout. */
    status=write?HAL_I2C_Mem_Write_IT(h,(uint16_t)(address<<1),reg,I2C_MEMADD_SIZE_8BIT,data,length):
                 HAL_I2C_Mem_Read_IT(h,(uint16_t)(address<<1),reg,I2C_MEMADD_SIZE_8BIT,data,length);
    return status==HAL_OK?0:(status==HAL_BUSY?1:-1);
}
static void stop(void *ctx,uint8_t bus)
{
    I2C_HandleTypeDef *h=buses[bus];(void)ctx;
    HAL_NVIC_DisableIRQ(event_irq[bus]);HAL_NVIC_DisableIRQ(error_irq[bus]);
    if(h&&h->Instance) {
        /* No DMA. Disable IRQs and PE before relinquishing the buffer, even
         * when SDA stays low or a STOP never arrives. No waits or GPIO clocks. */
        CLEAR_BIT(h->Instance->CR1,I2C_CR1_TXIE|I2C_CR1_RXIE|I2C_CR1_ADDRIE|
            I2C_CR1_NACKIE|I2C_CR1_STOPIE|I2C_CR1_TCIE|I2C_CR1_ERRIE|I2C_CR1_PE);
        __DSB();h->XferISR=NULL;
    }
    HAL_NVIC_ClearPendingIRQ(event_irq[bus]);HAL_NVIC_ClearPendingIRQ(error_irq[bus]);
}
static int recover(void *ctx,uint8_t bus)
{
    I2C_HandleTypeDef *h=buses[bus];(void)ctx;
    if(!h||!h->Instance)return -1;
    /* Called only at idle, never in an IRQ or during NP recording. */
    stop(ctx,bus);
    if(HAL_I2C_DeInit(h)!=HAL_OK||HAL_I2C_Init(h)!=HAL_OK)return -1;
    if(HAL_I2CEx_ConfigAnalogFilter(h,I2C_ANALOGFILTER_ENABLE)!=HAL_OK||
       HAL_I2CEx_ConfigDigitalFilter(h,0)!=HAL_OK)return -1;
    HAL_NVIC_EnableIRQ(event_irq[bus]);HAL_NVIC_EnableIRQ(error_irq[bus]);return 0;
}
static void publish(uint32_t now)
{
    uint32_t inactive=xe_np_sensor_snapshot_index^1U;
    XE_NP_Sensors_Snapshot(&sensors,&xe_np_sensor_snapshot[inactive],now);
    memcpy(xe_np_sensor_fault,sensors.fault,sizeof(xe_np_sensor_fault));
    (void)xe_np_sensor_queue_push(&record_queue,&xe_np_sensor_snapshot[inactive]);queue_diag();
    __DMB();xe_np_sensor_snapshot_index=inactive;
}
void XE_NP_SensorsPort_Init(I2C_HandleTypeDef *imu,I2C_HandleTypeDef *environment)
{
    XE_NP_SensorIo io={NULL,start,stop,recover};uint32_t enabled=XE_NP_SENSOR_MASK_BMX;
    buses[0]=imu;buses[1]=environment;
#if NP_SD_BME_WIRING_CONFIRMED
    enabled|=XE_NP_SENSOR_MASK_BME;
#endif
    XE_NP_Sensors_Init(&sensors,&io,enabled,HAL_GetTick());
    for(uint8_t i=0;i<2;i++) {
        HAL_NVIC_SetPriority(event_irq[i],7U,0U);HAL_NVIC_SetPriority(error_irq[i],7U,0U);
        if((enabled&(1UL<<i))&&buses[i]&&buses[i]->Instance) {
            HAL_NVIC_ClearPendingIRQ(event_irq[i]);HAL_NVIC_ClearPendingIRQ(error_irq[i]);
            HAL_NVIC_EnableIRQ(event_irq[i]);HAL_NVIC_EnableIRQ(error_irq[i]);
        } else stop(NULL,i);
    }
    initialized=1;publish(HAL_GetTick());
}
void XE_NP_SensorsPort_Service(uint8_t recording)
{
    uint32_t now;
    if(!initialized)return;
    now=HAL_GetTick();XE_NP_Sensors_Service(&sensors,now,recording);
    if(xe_np_sensor_snapshot[xe_np_sensor_snapshot_index].published_ms!=now)publish(now);
}
int XE_NP_SensorsPort_Complete(I2C_HandleTypeDef *h,uint32_t error)
{
    if(!initialized)return 0;
    for(uint8_t i=0;i<2;i++)if(h==buses[i]) {
        __DMB();XE_NP_Sensors_Complete(&sensors,i,tokens[i],error,HAL_GetTick());__DMB();return 1;
    }
    return 0;
}
const XE_NP_SensorSnapshot *XE_NP_SensorsPort_GetSnapshot(void)
{
    uint32_t index=xe_np_sensor_snapshot_index;__DMB();return &xe_np_sensor_snapshot[index];
}
void XE_NP_SensorsPort_RecordBegin(void)
{xe_np_sensor_queue_begin(&record_queue,XE_NP_SensorsPort_GetSnapshot());queue_diag();}
void XE_NP_SensorsPort_RecordEnd(void)
{record_queue.active=0;queue_diag();}
uint32_t XE_NP_SensorsPort_RecordFault(void)
{return 0U; /* Missing IMU publications are reported by sequence, not fatal to NP data. */}
const XE_NP_SensorSnapshot *XE_NP_SensorsPort_RecordSnapshot(void)
{
    (void)xe_np_sensor_queue_take_latest(&record_queue,XE_NP_SensorsPort_GetSnapshot());
    XE_NP_Sensors_RefreshValidity(&record_queue.last,HAL_GetTick());queue_diag();
    return &record_queue.last;
}
uint32_t XE_NP_SensorsPort_RecordOverflow(void)
{return record_queue.active?record_queue.overflow:0U;}
const XE_NP_SensorSnapshot *XE_NP_SensorsPort_RecordOrderedSnapshot(void)
{
    const XE_NP_SensorSnapshot *latest=XE_NP_SensorsPort_GetSnapshot();
    (void)xe_np_sensor_queue_pop(&record_queue);
    /* Old queued observations must not re-enable a component that has failed.
     * Preserve their source sequences/timestamps, but apply current health. */
    record_queue.last.enabled&=latest->enabled;
    record_queue.last.valid&=XE_NP_Sensors_StreamMask(latest);
    memcpy(record_queue.last.error,latest->error,sizeof(latest->error));
    XE_NP_Sensors_RefreshValidity(&record_queue.last,HAL_GetTick());queue_diag();
    return &record_queue.last;
}

/* Dedicated interrupt-driven buses. No GPDMA channel is allocated. */
void I2C5_EV_IRQHandler(void) { HAL_I2C_EV_IRQHandler(buses[0]); }
void I2C5_ER_IRQHandler(void) { HAL_I2C_ER_IRQHandler(buses[0]); }
void I2C6_EV_IRQHandler(void) { HAL_I2C_EV_IRQHandler(buses[1]); }
void I2C6_ER_IRQHandler(void) { HAL_I2C_ER_IRQHandler(buses[1]); }
void HAL_I2C_MemTxCpltCallback(I2C_HandleTypeDef *h)
{ (void)XE_NP_SensorsPort_Complete(h,0U); }
