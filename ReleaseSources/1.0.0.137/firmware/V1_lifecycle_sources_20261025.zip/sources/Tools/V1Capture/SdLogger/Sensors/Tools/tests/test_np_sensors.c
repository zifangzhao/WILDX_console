#include "xe_np_sensors.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

typedef struct {
    XE_NP_Sensors sensors;
    uint8_t regs[2][256],mag[256],cal[26],hcal[7];
    struct { uint32_t token,due,error;uint8_t pending; } transfer[2];
    uint32_t now,starts[2],stops[2],recoveries[2],writes[2];
    uint32_t accel_command,gyro_command,last_mag_tick,aux_due;
    uint8_t stall[2],nack[2],busy[2],immediate,bme_stuck,no_drdy,bad_mag_sample;
    uint8_t reserved_bits,bad_reg,bad_xor,pmu_stuck,transient_mag_error,address[2];
    uint32_t pmu_ready;
} Fake;
static unsigned checks;
#define CHECK(x) do { checks++;assert(x); } while(0)
static void put16(uint8_t *p,int32_t v) { p[0]=(uint8_t)v;p[1]=(uint8_t)((uint32_t)v>>8); }
static void put20(uint8_t *p,uint32_t v) { p[0]=(uint8_t)(v>>12);p[1]=(uint8_t)(v>>4);p[2]=(uint8_t)(v<<4); }
static void raw_imu(uint8_t *p,uint32_t time)
{
    memset(p,0,23);put16(p,320*8);put16(p+2,-640*8);put16(p+4,128*2);
    put16(p+6,10000*4+1);put16(p+8,164);put16(p+10,-164);put16(p+12,0);
    put16(p+14,4096);put16(p+16,-4096);put16(p+18,-32768);
    p[20]=(uint8_t)time;p[21]=(uint8_t)(time>>8);p[22]=(uint8_t)(time>>16);
}
static void raw_bme(uint8_t *p)
{ put20(p,415148);put20(p+3,519888);p[6]=0x75;p[7]=0x30; }
static int start(void *context,uint8_t bus,uint8_t address,uint8_t reg,uint8_t *data,
                 uint16_t length,uint8_t write,uint32_t token)
{
    Fake *f=context;CHECK(bus<2 && length>0 && length<=32);
    CHECK(!f->transfer[bus].pending);f->starts[bus]++;
    if(f->busy[bus])return 1;
    if(write) {
        CHECK(f->sensors.snapshot.chip_id[bus]==(bus?0x60U:0xd8U));f->writes[bus]++;
        f->regs[bus][reg]=data[0];
        if(!bus && reg==0x7e) {
            if(data[0]==0x11)f->accel_command=f->now;
            if(data[0]==0x15) { CHECK((uint32_t)(f->now-f->accel_command)>=5U);f->gyro_command=f->now; }
            if(data[0]==0x19)CHECK((uint32_t)(f->now-f->gyro_command)>=85U);
            if(data[0]==0x18)f->regs[0][3]=0x14;
            if(data[0]==0x19)f->regs[0][3]=0x15;
        }
        if(!bus && (reg==0x4e || reg==0x4d)) {
            CHECK(f->now>=f->aux_due);f->aux_due=f->now+17U;
            if(reg==0x4e)f->mag[data[0]]=f->regs[0][0x4f];
        }
        if(bus && reg==0xf4) { CHECK(f->regs[1][0xf2]==1);f->regs[1][0xf4]&=0xfcU; }
    } else if(!bus && reg==0x04) {
        if(f->regs[0][0x4c]&0x80U) { CHECK(f->now>=f->aux_due);memcpy(data,f->mag+f->regs[0][0x4d],length); }
        else {
            CHECK(length==23);raw_imu(data,(uint32_t)(((uint64_t)f->now*128U/5U)&0xffffffU));
            if(f->bad_mag_sample)data[6]=data[7]=0U;
            if(f->sensors.device[0].status&0x20U)f->last_mag_tick=f->now;
        }
    } else if(!bus && reg==0x0c) {
        uint8_t raw[23];CHECK(length==15);raw_imu(raw,(uint32_t)(((uint64_t)f->now*128U/5U)&0xffffffU));memcpy(data,raw+8,15);
    } else if(!bus && reg==0x1b) {
        data[0]=(uint8_t)(0xc0U|((uint32_t)(f->now-f->last_mag_tick)>=40U?0x20U:0)|(f->now<f->aux_due?4U:0U));
        if(f->no_drdy)data[0]&=0x3fU;
    } else if(bus && reg==0x88)memcpy(data,f->cal,length);
    else if(bus && reg==0xe1)memcpy(data,f->hcal,length);
    else if(bus && reg==0xf7)raw_bme(data);
    else if(bus && reg==0xf3)data[0]=f->bme_stuck?8U:0U;
    else memcpy(data,&f->regs[bus][reg],length);
    if(!write && !bus) {
        for(uint16_t i=0;i<length;i++) {
            uint8_t r=(uint8_t)(reg+i);
            if(f->reserved_bits) {
                if(r==3)data[i]|=0xc0U;
                if(r==0x41 || r==0x44)data[i]|=0xf0U;
                if(r==0x43)data[i]|=0xf8U;
                if(r==0x4c)data[i]|=0x40U;
            }
            if(r==3 && (f->pmu_stuck || f->now<f->pmu_ready))data[i]&=0xc0U;
            if(r==f->bad_reg)data[i]^=f->bad_xor;
        }
    }
    if(!write && !bus && reg==2 && f->transient_mag_error)f->regs[0][2]=0;
    f->transfer[bus].token=token;f->transfer[bus].due=f->now+1U;
    f->transfer[bus].error=(f->nack[bus] || address!=f->address[bus])?1U:0U;
    if(f->immediate)XE_NP_Sensors_Complete(&f->sensors,bus,token,f->transfer[bus].error,f->now);
    else f->transfer[bus].pending=1;
    return 0;
}
static void stop(void *context,uint8_t bus) { Fake *f=context;f->stops[bus]++;f->transfer[bus].pending=0; }
static int recover(void *context,uint8_t bus) { Fake *f=context;f->recoveries[bus]++;return 0; }
static void init(Fake *f,uint32_t enabled,uint32_t tick)
{
    static const int32_t coefficients[12]={27504,26435,-1000,36477,-10685,3024,2855,140,-7,15500,-14600,6000};
    XE_NP_SensorIo io={f,start,stop,recover};memset(f,0,sizeof(*f));f->now=tick;
    f->address[0]=0x68;f->address[1]=0x76;
    f->regs[0][0]=0xd8;f->regs[0][3]=0x15;f->regs[1][0xd0]=0x60;
    f->mag[0x40]=0x32;put16(f->mag+0x68,16384);put16(f->mag+0x6a,32768);
    put16(f->mag+0x6c,10000);
    for(unsigned i=0;i<12;i++)put16(f->cal+i*2,coefficients[i]);
    f->cal[25]=75;put16(f->hcal,362);f->hcal[2]=0;f->hcal[3]=20;
    f->hcal[4]=0x25;f->hcal[5]=3;f->hcal[6]=30; /* H4=325 H5=50 */
    XE_NP_Sensors_Init(&f->sensors,&io,enabled,tick);
}
static void step(Fake *f,uint8_t recording)
{
    for(uint8_t bus=0;bus<2;bus++)if(f->transfer[bus].pending&&!f->stall[bus]&&
        (int32_t)(f->now-f->transfer[bus].due)>=0) {
        f->transfer[bus].pending=0;
        XE_NP_Sensors_Complete(&f->sensors,bus,f->transfer[bus].token,f->transfer[bus].error,f->now);
    }
    uint32_t a=f->starts[0],b=f->starts[1];
    XE_NP_Sensors_Service(&f->sensors,f->now,recording);
    CHECK(f->starts[0]-a<=1 && f->starts[1]-b<=1);
    f->now++;
}
static void run(Fake *f,uint32_t duration,uint8_t recording) { for(uint32_t n=0;n<duration;n++)step(f,recording); }
static void normal_and_math(void)
{
    Fake f;XE_NP_SensorSnapshot out;uint8_t raw[23],original[23];
    init(&f,3,0);run(&f,5000,0);XE_NP_Sensors_Snapshot(&f.sensors,&out,f.now);
    CHECK(out.valid==7 && out.error[0]==0 && out.error[1]==0);
    CHECK(out.imu_sequence>850 && out.imu_sequence<=1000);
    CHECK(out.mag_sequence>90 && out.mag_sequence<=125 && out.env_sequence==5);
    CHECK(out.accel_micro_g[0]==1000000 && out.accel_micro_g[1]==-1000000 && out.accel_micro_g[2]==-8000000);
    CHECK(out.gyro_milli_dps[0]==10000 && out.gyro_milli_dps[1]==-10000);
    CHECK(out.mag_nano_tesla[0]==100000 && out.mag_nano_tesla[1]==-200000);
    CHECK(abs(out.mag_nano_tesla[2]-(int32_t)(128.0*2048.0/26384.0*1000.0))<=1);
    CHECK(out.temperature_centi_c==2508 && out.pressure_pa==100653);
    CHECK(out.humidity_milli_percent==50727);
    CHECK(out.missed_imu_samples==0 && f.recoveries[0]==0 && f.recoveries[1]==0);
    raw_imu(raw,0xffff80U);memcpy(original,raw,23);f.sensors.have_sensor_time=0;
    CHECK(XE_NP_Sensors_DecodeImu(&f.sensors,raw,0xe0,5000)==0);
    CHECK(memcmp(raw,original,23)==0); /* upstream compensation mutates only its scratch */
    raw_imu(raw,0);CHECK(XE_NP_Sensors_DecodeImu(&f.sensors,raw,0xc0,5005)==0);
    CHECK(f.sensors.snapshot.missed_imu_samples==0);
    CHECK(XE_NP_Sensors_DecodeImu(&f.sensors,raw,0xc0,5006)==-1);
    raw_imu(raw,256);CHECK(XE_NP_Sensors_DecodeImu(&f.sensors,raw,0xc0,5015)==0);
    CHECK(f.sensors.snapshot.missed_imu_samples==1);
    raw_imu(raw,384);put16(raw,-32768);CHECK(XE_NP_Sensors_DecodeImu(&f.sensors,raw,0xe0,5020)==0);
    CHECK(!(f.sensors.snapshot.valid&2) && f.sensors.snapshot.invalid_mag_samples==1);
    CHECK(f.sensors.mag_calibrated && f.sensors.mag_bad_samples==1 && f.sensors.snapshot.error[0]==0);
    CHECK((XE_NP_Sensors_StreamMask(&f.sensors.snapshot)&3U)==XE_NP_SENSOR_VALID_AG);
    raw_imu(raw,512);CHECK(XE_NP_Sensors_DecodeImu(&f.sensors,raw,0xe0,5025)==0);
    CHECK(f.sensors.mag_calibrated && f.sensors.mag_bad_samples==0 && (f.sensors.snapshot.valid&2));
    XE_NP_Sensors_Snapshot(&f.sensors,&out,10000);CHECK(out.valid==0);
    out.valid=7;XE_NP_Sensors_RefreshValidity(&out,15000);CHECK(out.valid==0 && out.published_ms==15000);
    f.hcal[3]=0xf9;f.hcal[4]=0x8c;f.hcal[5]=0xf3; /* H4=-100 H5=-200 */
    CHECK(XE_NP_Sensors_ParseBmeCalibration(f.cal,f.hcal,&f.sensors.bme_calibration)==0);
    CHECK(f.sensors.bme_calibration.dig_h4==-100 && f.sensors.bme_calibration.dig_h5==-200);
    memset(f.cal,0,26);CHECK(XE_NP_Sensors_ParseBmeCalibration(f.cal,f.hcal,&f.sensors.bme_calibration)==-1);
    printf("Normal: IMU=%lu MAG=%lu ENV=%lu, T=%ld P=%lu RH=%lu\n",(unsigned long)out.imu_sequence,
        (unsigned long)out.mag_sequence,(unsigned long)out.env_sequence,(long)out.temperature_centi_c,
        (unsigned long)out.pressure_pa,(unsigned long)out.humidity_milli_percent);
}
static void isolation_and_faults(void)
{
    Fake f;XE_NP_SensorSnapshot out;uint32_t old_token,starts,samples,env;
    init(&f,1,0);run(&f,1000,0);CHECK(f.starts[1]==0 && f.sensors.snapshot.error[1]==XE_NP_SENSOR_ERR_DISABLED);
    init(&f,3,0);f.regs[0][0]=0x24;run(&f,1000,0);
    CHECK(f.writes[0]==0 && f.sensors.snapshot.error[0]==XE_NP_SENSOR_ERR_ID && f.sensors.snapshot.env_sequence==1);
    init(&f,3,0);f.regs[1][0xd0]=0x58;run(&f,1000,0);
    CHECK(f.writes[1]==0 && f.sensors.snapshot.error[1]==XE_NP_SENSOR_ERR_ID && f.sensors.snapshot.imu_sequence>100);
    /* Prepare idle, then inject runtime bus faults during active polling. */
    init(&f,3,0);run(&f,1000,0);samples=f.sensors.snapshot.imu_sequence;
    f.stall[0]=1;run(&f,100,1);old_token=f.transfer[0].token;
    CHECK(f.stops[0]==1 && f.sensors.snapshot.timeouts[0]==1);
    starts=f.starts[0];run(&f,5000,1);CHECK(f.starts[0]==starts && f.recoveries[0]==0 && f.sensors.snapshot.env_sequence>=5);
    XE_NP_Sensors_Complete(&f.sensors,0,old_token,0,f.now);
    CHECK(f.sensors.snapshot.ignored_completions==1 && f.sensors.snapshot.imu_sequence==samples);
    f.stall[0]=0;run(&f,1000,0);CHECK(f.recoveries[0]==1 && f.sensors.snapshot.imu_sequence>samples);
    init(&f,3,0);run(&f,1000,0);env=f.sensors.snapshot.env_sequence;f.nack[0]=1;run(&f,1000,1);
    CHECK(f.sensors.snapshot.io_errors[0]==1 && f.sensors.snapshot.env_sequence>env && f.recoveries[0]==0);
    init(&f,3,0);run(&f,1000,0);env=f.sensors.snapshot.env_sequence;f.busy[0]=1;run(&f,1000,1);
    CHECK(f.sensors.snapshot.error[0]==XE_NP_SENSOR_ERR_BUSY && f.sensors.snapshot.env_sequence>env && f.recoveries[0]==0);
    init(&f,3,0);f.immediate=1;run(&f,1000,0);
    CHECK(f.sensors.snapshot.imu_sequence>100 && f.sensors.snapshot.env_sequence==1);
    init(&f,3,0xfffffe00U);run(&f,3000,0);
    XE_NP_Sensors_Snapshot(&f.sensors,&out,f.now);CHECK(out.valid==7 && out.env_sequence==3);
    init(&f,3,0);run(&f,1000,0);f.bme_stuck=1;run(&f,1500,1);
    CHECK(f.sensors.snapshot.timeouts[1]==1 && f.sensors.snapshot.imu_sequence>200);
    /* Cancellation followed by a new request must not accept an old token. */
    init(&f,1,0);run(&f,21,0);old_token=f.transfer[0].token;f.stall[0]=1;run(&f,25,0);
    f.stall[0]=0;run(&f,2000,0);
    XE_NP_Sensors_Complete(&f.sensors,0,old_token,0,f.now);
    CHECK(f.sensors.snapshot.ignored_completions==1);
    init(&f,3,0);f.mag[0x40]=0;run(&f,1500,0);
    CHECK(f.sensors.snapshot.error[0]==XE_NP_SENSOR_ERR_MAG_UNAVAILABLE);
    CHECK(f.sensors.snapshot.imu_sequence>100 && f.sensors.snapshot.env_sequence>=1);
    CHECK((f.sensors.snapshot.valid&3)==1 && f.sensors.snapshot.mag_sequence==0);
}
static void register_validation(void)
{
    Fake f;
    /* Configuration, including injected register failures, is idle-only.
     * Retain a full active interval afterward to check health/no recovery.
     * Reproduce valid 0x95/0xD5 PMU values rejected by full-byte checks and
     * exercise both 9-axis initialization and the working AG fallback. */
    init(&f,3,0);f.reserved_bits=1;run(&f,1500,0);run(&f,1500,1);
    CHECK(f.sensors.snapshot.valid==7 && f.sensors.fault[0].count==0);
    init(&f,1,0);f.reserved_bits=1;f.mag[0x40]=0;run(&f,1500,0);run(&f,1500,1);
    CHECK((f.sensors.snapshot.valid&3)==1 && f.sensors.snapshot.imu_sequence>100);
    CHECK(f.sensors.fault[0].count==1 && f.sensors.fault[0].reg==4);
    CHECK(f.sensors.fault[0].actual==0 && f.sensors.fault[0].expected==0x32);
    /* Do not turn a wrong range or ODR into an accepted configuration. */
    for(uint8_t r=0x40;r<=0x44;r++) {
        init(&f,3,0);f.reserved_bits=1;f.bad_reg=r;f.bad_xor=1;run(&f,1500,0);run(&f,1500,1);
        CHECK(!(f.sensors.snapshot.valid&3) && f.sensors.snapshot.env_sequence>0);
        CHECK(f.sensors.fault[0].count==1 && f.sensors.fault[0].reg==r);
        CHECK(f.sensors.fault[0].error==XE_NP_SENSOR_ERR_CONFIG);
    }
    init(&f,1,0);f.bad_reg=0x4c;f.bad_xor=1;run(&f,1500,0);run(&f,1500,1);
    CHECK(f.sensors.fault[0].reg==0x4c && f.sensors.fault[0].mask==0xbf);
    CHECK(f.sensors.snapshot.imu_sequence==0);
    /* PMU readiness is polled, not assumed from a single fixed delay. */
    init(&f,1,0);f.pmu_ready=210;run(&f,1500,0);run(&f,1500,1);
    CHECK(f.sensors.snapshot.imu_sequence>100 && f.sensors.fault[0].count==0);
    init(&f,3,0);f.reserved_bits=1;f.pmu_stuck=1;run(&f,1500,0);run(&f,1500,1);
    CHECK(f.sensors.snapshot.imu_sequence==0 && f.recoveries[0]==0);
    CHECK(f.sensors.fault[0].reg==3 && f.sensors.fault[0].mask==0x3f);
    CHECK(f.sensors.fault[0].actual==0xc0 && f.sensors.fault[0].expected==0x15);
    CHECK(f.sensors.snapshot.env_sequence>0);
    /* Real error flags must remain fatal to initialization. */
    init(&f,1,0);f.regs[0][2]=0x40;run(&f,1500,0);run(&f,1500,1);
    CHECK(f.sensors.fault[0].reg==2 && f.sensors.snapshot.imu_sequence==0);
    init(&f,1,0);f.regs[0][2]=0x80;run(&f,1500,0);run(&f,1500,1);
    CHECK(f.sensors.snapshot.imu_sequence>100 && (f.sensors.snapshot.valid&3)==1);
    CHECK(f.sensors.snapshot.error[0]==XE_NP_SENSOR_ERR_MAG_UNAVAILABLE);
    CHECK(f.sensors.fault[0].reg==2 && f.sensors.fault[0].actual==0x80);
    init(&f,1,0);f.regs[0][2]=0x80;f.transient_mag_error=1;run(&f,1500,0);run(&f,1500,1);
    CHECK((f.sensors.snapshot.valid&3)==3 && f.sensors.snapshot.imu_sequence>100);
    CHECK(f.sensors.snapshot.error[0]==0 && f.sensors.snapshot.mag_sequence>0);
    init(&f,1,0);f.regs[0][2]=0x81;run(&f,1500,0);run(&f,1500,1);
    CHECK(f.sensors.snapshot.imu_sequence==0 && !(f.sensors.snapshot.valid&3));
}
static void disabled_streams(void)
{
    Fake f;XE_NP_SensorSnapshot out;uint32_t starts;
    init(&f,3,0);CHECK(f.sensors.snapshot.enabled==0);
    run(&f,1500,0);run(&f,1500,1);CHECK(f.sensors.snapshot.enabled==3);
    CHECK(XE_NP_Sensors_StreamMask(&f.sensors.snapshot)==7);
    f.nack[0]=1;run(&f,25,1);starts=f.starts[0];
    XE_NP_Sensors_Snapshot(&f.sensors,&out,f.now);
    CHECK(out.enabled==XE_NP_SENSOR_MASK_BME && out.valid==XE_NP_SENSOR_VALID_ENV);
    CHECK(out.accel_micro_g[0]==0 && out.gyro_milli_dps[0]==0 && out.mag_nano_tesla[0]==0);
    run(&f,5000,1);CHECK(f.starts[0]==starts && f.recoveries[0]==0);
    CHECK(f.sensors.snapshot.env_sequence>5); /* healthy sensor continues */
    f.nack[1]=1;run(&f,1100,1);starts=f.starts[1];
    CHECK(!f.sensors.snapshot.enabled && !f.sensors.snapshot.valid);
    CHECK(!f.sensors.snapshot.pressure_pa && !f.sensors.snapshot.temperature_centi_c);
    run(&f,5000,1);CHECK(f.starts[1]==starts && f.recoveries[1]==0);
    init(&f,3,0);f.no_drdy=1;run(&f,1500,0);run(&f,1500,1);
    CHECK(f.sensors.snapshot.error[0]==XE_NP_SENSOR_ERR_TIMEOUT);
    CHECK(!(f.sensors.snapshot.enabled&XE_NP_SENSOR_MASK_BMX));
    CHECK(f.sensors.snapshot.env_sequence>0);
    init(&f,1,0);f.mag[0x40]=0;run(&f,1500,0);run(&f,1500,1);
    CHECK(f.sensors.snapshot.enabled==XE_NP_SENSOR_MASK_BMX);
    CHECK(XE_NP_Sensors_StreamMask(&f.sensors.snapshot)==XE_NP_SENSOR_VALID_AG);
    init(&f,3,0);f.regs[0][0]=0;f.regs[1][0xd0]=0;run(&f,1000,0);run(&f,5000,1);
    CHECK(!f.sensors.snapshot.enabled && !f.sensors.snapshot.valid);
    CHECK(f.writes[0]==0 && f.writes[1]==0);
    init(&f,3,0);run(&f,1500,0);f.bad_mag_sample=1;run(&f,200,1);
    CHECK(!f.sensors.mag_calibrated && f.sensors.snapshot.error[0]==XE_NP_SENSOR_ERR_MAG_UNAVAILABLE);
    CHECK((f.sensors.snapshot.valid&3U)==XE_NP_SENSOR_VALID_AG);
    starts=f.sensors.snapshot.mag_sequence;uint32_t imu=f.sensors.snapshot.imu_sequence;
    f.bad_mag_sample=0;run(&f,200,1);
    CHECK(f.sensors.snapshot.mag_sequence==starts && f.sensors.snapshot.imu_sequence>imu);
    CHECK(f.recoveries[0]==0); /* no failed MAG stream re-enable during recording */
}
static void address_recovery(void)
{
    Fake f;uint32_t samples,starts;
    /* A missing primary address can still discover the alternate while idle. */
    init(&f,1,0);f.address[0]=0x69;run(&f,3500,0);
    CHECK(f.sensors.device[0].address==0x69 && f.recoveries[0]==1);
    CHECK(f.sensors.snapshot.imu_sequence>100 && f.sensors.snapshot.error[0]==0);
    /* A transient NACK after identification is not evidence of a new address.
     * No bus recovery or address scan may run alongside active NP capture. */
    init(&f,1,0);run(&f,1000,0);samples=f.sensors.snapshot.imu_sequence;
    f.nack[0]=1;run(&f,25,1);starts=f.starts[0];
    f.nack[0]=0;run(&f,3000,1);
    CHECK(f.starts[0]==starts && f.recoveries[0]==0);
    run(&f,1,0);
    CHECK(f.sensors.device[0].address==0x68 && f.recoveries[0]==1);
    run(&f,1000,0);
    CHECK(f.sensors.snapshot.imu_sequence>samples && f.sensors.snapshot.error[0]==0);
    CHECK(f.recoveries[0]==1); /* no second retry spent on the wrong address */
}
static void magnetic_conversion_recovery(void)
{
    Fake f;uint8_t raw[23];uint32_t sequence,time;
    init(&f,1,0);run(&f,1500,0); /* idle preparation before active/raw sample checks */
    CHECK(f.sensors.mag_calibrated && (f.sensors.snapshot.valid&3)==3);
    sequence=f.sensors.snapshot.mag_sequence;time=f.sensors.previous_sensor_time;
    /* BMI shadow DRDY alone does not prove the BMM150 conversion was ready.
     * Drop the sample, then accept the next valid conversion without bus I/O. */
    raw_imu(raw,time+=128);raw[6]&=0xfeU;
    CHECK(XE_NP_Sensors_DecodeImu(&f.sensors,raw,0xe0,f.now)==0);
    CHECK(f.sensors.snapshot.mag_sequence==sequence && !(f.sensors.snapshot.valid&2));
    CHECK(f.sensors.mag_calibrated && f.sensors.snapshot.error[0]==0);
    raw_imu(raw,time+=128);
    CHECK(XE_NP_Sensors_DecodeImu(&f.sensors,raw,0xe0,f.now+5)==0);
    CHECK(f.sensors.snapshot.mag_sequence==sequence+1 && f.sensors.mag_bad_samples==0);
    /* Missing Hall data repeatedly is a failed MAG stream, not valid zeroes. */
    for(unsigned i=0;i<3;i++) {
        raw_imu(raw,time+=128);raw[6]=raw[7]=0;
        CHECK(XE_NP_Sensors_DecodeImu(&f.sensors,raw,0xe0,f.now+10+i*5)==0);
        CHECK(f.sensors.mag_calibrated==(i<2));
    }
    CHECK(f.sensors.snapshot.error[0]==XE_NP_SENSOR_ERR_MAG_UNAVAILABLE);
    CHECK(XE_NP_Sensors_StreamMask(&f.sensors.snapshot)==XE_NP_SENSOR_VALID_AG);
    CHECK(f.recoveries[0]==0 && f.stops[0]==0);
    /* Integrated polling must survive one invalid conversion as well. */
    init(&f,1,0);run(&f,1500,0);sequence=f.sensors.snapshot.mag_sequence;
    f.bad_mag_sample=1;
    for(unsigned i=0;i<100 && f.sensors.snapshot.invalid_mag_samples==0;i++)step(&f,1);
    CHECK(f.sensors.snapshot.invalid_mag_samples==1 && f.sensors.mag_calibrated && f.sensors.mag_bad_samples==1);
    f.bad_mag_sample=0;run(&f,150,1);
    CHECK(f.sensors.snapshot.mag_sequence>sequence && (f.sensors.snapshot.valid&3)==3);
    CHECK(f.sensors.snapshot.error[0]==0 && f.recoveries[0]==0);
}
int main(void)
{
    CHECK(sizeof(XE_NP_SensorSnapshot)==140U);
    CHECK(sizeof(XE_NP_SensorFault)==40U);
    normal_and_math();isolation_and_faults();register_validation();disabled_streams();address_recovery();magnetic_conversion_recovery();
    printf("PASS: %u asynchronous sensor/configuration/compensation/ownership/isolation checks\n",checks);
    return 0;
}
