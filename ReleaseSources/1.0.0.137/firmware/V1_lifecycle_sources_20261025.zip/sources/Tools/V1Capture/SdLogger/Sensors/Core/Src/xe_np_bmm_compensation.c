/* Upstream BSD-3-Clause code, unmodified; see Middlewares/Bosch/README.md. */
#define BMM150_USE_FLOATING_POINT
#ifdef _MSC_VER
/* Upstream's unused advanced self-test narrows a float to int16_t. Keep the
 * vendor file verbatim and all warnings enabled for our driver/test code. */
#pragma warning(push)
#pragma warning(disable:4244)
#endif
#include "../../Middlewares/Bosch/BMM150_SensorAPI/bmm150.c"
#ifdef _MSC_VER
#pragma warning(pop)
#endif
