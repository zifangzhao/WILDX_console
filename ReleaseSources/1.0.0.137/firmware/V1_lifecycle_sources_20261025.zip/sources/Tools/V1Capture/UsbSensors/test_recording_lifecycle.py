"""One actual-driver check: defer sensor configuration, not healthy polling.

Reuses the established asynchronous Fake bus helpers without its boot-during-
recording expectations. Run: python this.py REPO FRESH_OUTPUT_DIRECTORY
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess


TEST = r'''
static unsigned failures;
#define EXPECT(x) do {checks++;if(!(x)){failures++;printf("FAIL line %u: %s\n",__LINE__,#x);}}while(0)
static void active_startup(void)
{
    Fake f;uint32_t starts,writes;
    init(&f,3U,0U);run(&f,1000U,1U);
    EXPECT(!f.starts[0]&&!f.starts[1]&&!f.writes[0]&&!f.writes[1]);
    EXPECT(!f.sensors.snapshot.enabled&&!f.sensors.snapshot.imu_sequence);
    run(&f,1500U,0U);
    EXPECT(f.sensors.snapshot.valid==7U);
    /* IDENTIFY was admitted idle; completion must not issue the reset after
     * capture/preparation starts. An already pending transfer may retire. */
    init(&f,1U,0U);run(&f,21U,0U);EXPECT(f.transfer[0].pending);
    starts=f.starts[0];run(&f,1000U,1U);
    EXPECT(f.starts[0]==starts&&!f.writes[0]);
    run(&f,1500U,0U);EXPECT((f.sensors.snapshot.valid&3U)==3U);
    /* The reset itself was already sent idle. Its completion and settling
     * interval must not continue into configuration during active NP. */
    init(&f,1U,0U);run(&f,22U,0U);EXPECT(f.sensors.device[0].pending);
    starts=f.starts[0];writes=f.writes[0];run(&f,1000U,1U);
    EXPECT(f.starts[0]==starts&&f.writes[0]==writes);
    run(&f,1500U,0U);EXPECT((f.sensors.snapshot.valid&3U)==3U);
    /* Explicitly cover every partially prepared state on each device. No
     * transfer has been admitted, so not even a configuration read is due. */
    const uint8_t states[]={RESET_SENSOR,CONFIGURE,AUX_WAIT,AG_CONFIG,
        BME_NVM,BME_CAL1,BME_CAL2,BME_CONFIG};
    for(unsigned i=0;i<sizeof(states);i++){
        unsigned bus=i<4U?0U:1U;init(&f,1U<<bus,0U);
        f.sensors.snapshot.chip_id[bus]=bus?0x60U:0xd8U;
        f.sensors.device[bus].state=states[i];
        f.sensors.device[bus].next_due=0U;
        run(&f,100U,1U);
        EXPECT(!f.starts[bus]&&!f.writes[bus]&&!f.recoveries[bus]);
    }
}
static void healthy_polling_and_failure(void)
{
    Fake f;uint32_t imu,mag,env,writes,starts;
    init(&f,3U,0U);run(&f,1500U,0U);
    EXPECT(f.sensors.snapshot.valid==7U);
    imu=f.sensors.snapshot.imu_sequence;mag=f.sensors.snapshot.mag_sequence;
    env=f.sensors.snapshot.env_sequence;writes=f.writes[0];
    run(&f,1200U,1U);
    EXPECT(f.sensors.snapshot.imu_sequence>imu+180U);
    EXPECT(f.sensors.snapshot.mag_sequence>mag+20U&&f.sensors.snapshot.env_sequence>env);
    EXPECT(f.writes[0]==writes&&!f.recoveries[0]&&!f.recoveries[1]);
    EXPECT(!f.stops[0]&&!f.stops[1]&&f.sensors.snapshot.valid==7U);
    /* Runtime MAG failure must not send the AG fallback's 0x7e/0x18 suspend
     * command during NP. Keep usable AG publishing with MAG explicitly invalid. */
    f.bad_mag_sample=1U;imu=f.sensors.snapshot.imu_sequence;
    run(&f,220U,1U);
    EXPECT(!f.sensors.mag_calibrated&&f.sensors.snapshot.error[0]==XE_NP_SENSOR_ERR_MAG_UNAVAILABLE);
    EXPECT(f.writes[0]==writes&&!f.recoveries[0]&&!f.stops[0]);
    EXPECT(f.sensors.snapshot.imu_sequence>imu+20U);
    EXPECT(XE_NP_Sensors_StreamMask(&f.sensors.snapshot)==(XE_NP_SENSOR_VALID_AG|XE_NP_SENSOR_VALID_ENV));
    mag=f.sensors.snapshot.mag_sequence;imu=f.sensors.snapshot.imu_sequence;
    f.bad_mag_sample=0U;run(&f,200U,1U);
    EXPECT(f.writes[0]==writes&&f.sensors.snapshot.mag_sequence==mag);
    EXPECT(f.sensors.snapshot.imu_sequence>imu+20U&&f.sensors.device[0].configured);
    run(&f,30U,0U);
    EXPECT(f.writes[0]==writes+1U&&f.regs[0][0x7e]==0x18U);
    EXPECT((f.sensors.snapshot.valid&3U)==XE_NP_SENSOR_VALID_AG);
    writes=f.writes[0];run(&f,200U,0U);EXPECT(f.writes[0]==writes);
    /* Ordinary I/O failure stays disabled until idle; no hidden retry or
     * sensor reset is introduced alongside the healthy sensor's polling. */
    f.nack[0]=1U;run(&f,25U,1U);starts=f.starts[0];f.nack[0]=0U;
    run(&f,3000U,1U);
    EXPECT(f.starts[0]==starts&&!f.recoveries[0]);
    EXPECT(!(f.sensors.snapshot.enabled&XE_NP_SENSOR_MASK_BMX));
    run(&f,1500U,0U);
    EXPECT(f.recoveries[0]==1U&&(f.sensors.snapshot.valid&3U)==3U);
}
int main(void)
{
    setvbuf(stdout,NULL,_IONBF,0);
    _Static_assert(sizeof(XE_NP_SensorSnapshot)==140U&&sizeof(XE_NP_SensorFault)==40U,"Sensor wire/diagnostic ABI changed");
    active_startup();healthy_polling_and_failure();
    printf("%s %u actual-driver/Fake checks, %u failures; no hardware\n",failures?"FAIL":"PASS",checks,failures);
    return failures?1:0;
}
'''


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    root, out = args.root.resolve(), args.output.resolve()
    source = root / 'Firmware/V1/Core/Src/xe_np_sensors.c'
    mirror = root / 'Tools/V1Capture/SdLogger/Sensors/Core/Src/xe_np_sensors.c'
    if source.read_bytes() != mirror.read_bytes():
        raise ValueError('Maintained and helper sensor driver copies differ')
    fixture = root / 'Tools/V1Capture/SdLogger/Sensors/Tools/tests/test_np_sensors.c'
    helpers = fixture.read_text().split('static void normal_and_math(void)', 1)[0]
    if not helpers.endswith('\n') or 'static void run(' not in helpers:
        raise ValueError('Unexpected established Fake helper boundary')
    out.mkdir(parents=True, exist_ok=False)
    test = out / 'test.c'
    test.write_text('#include "' + source.as_posix() + '"\n' + helpers + TEST)
    includes = root / 'Firmware/V1/Core/Inc'
    compensation = [root / ('Firmware/V1/Core/Src/' + name) for name in
                    ('xe_np_bme_compensation.c', 'xe_np_bmm_compensation.c')]
    bosch = root / 'Tools/V1Capture/SdLogger/Sensors/Middlewares/Bosch'
    include_args = ' '.join('/I"' + str(p) + '"' for p in
                            (includes, bosch / 'BME280_SensorAPI', bosch / 'BMM150_SensorAPI'))
    vc = Path('C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat')
    sources = ' '.join('"' + str(p) + '"' for p in [test] + compensation)
    command = (f'call "{vc}" >nul && cl /nologo /std:c11 /O2 /W4 /WX /TC '
               f'{include_args} {sources} /Fo"{out}/" /Fe"{out}/test.exe"')
    built = subprocess.run(command, shell=True, capture_output=True, text=True)
    output = built.stdout + built.stderr
    run = None if built.returncode else subprocess.run([str(out / 'test.exe')], capture_output=True, text=True)
    if run is not None:
        output += run.stdout + run.stderr
    print(output, end='')
    result = dict(source=str(source), source_sha256=sha(source), mirror_sha256=sha(mirror),
                  fake_fixture_sha256=sha(fixture), fake_helpers_sha256=hashlib.sha256(helpers.encode()).hexdigest(),
                  compile_exit=built.returncode, test_exit=None if run is None else run.returncode,
                  hardware_access=False)
    (out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    (out / 'run.log').write_text(output)
    raise SystemExit(built.returncode if run is None else run.returncode)


if __name__ == '__main__':
    main()
