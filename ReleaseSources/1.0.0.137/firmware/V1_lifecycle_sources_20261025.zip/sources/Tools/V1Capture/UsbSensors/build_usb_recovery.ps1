# One USB APP-provider compile: add only the native-tested unclaimed20k recovery
# to the checked40AB provider, retaining the checked sensor/service/download objects.
$ErrorActionPreference='Stop'
$root=(Resolve-Path "$PSScriptRoot/../../..").Path.Replace('\','/')
$task="$root/_artifacts/v1_lifecycle_release_20261025"
$out="$task/usb_recovery_build";$source="$task/usb_recovery_source"
if(Test-Path $out){throw 'Fresh incremental output required'}
$native=Get-Content "$task/usb_recovery_native/result.json" -Raw|ConvertFrom-Json
$manifest=Get-Content "$source/source_manifest.json" -Raw|ConvertFrom-Json
if($native.result -notlike 'PASS*' -or (Get-FileHash "$source/source_manifest.json").Hash -ne $native.source_manifest_sha256){throw 'Recovery source/test mismatch'}
foreach($entry in @($manifest.inputs)+@($manifest.outputs)){if((Get-FileHash $entry.path).Hash -ne $entry.sha256){throw "Checked input changed: $($entry.path)"}}
$prior="$task/usb_build";$r2="$root/_artifacts/v1_usb_timing_r2_20261024"
$original="$r2/source_r4/xe_np_app.c"
if((Get-FileHash $original).Hash -ne '53B8902E9C4A33582E5D66D1E97A0873C41A4554144C0A9B52CA363BDD7E38FF'){throw 'Frozen provider changed'}
$inputs=Get-Content "$r2/source_r5/source_manifest.json" -Raw|ConvertFrom-Json
foreach($entry in @($inputs.inputs)+@($inputs.outputs)){if((Get-FileHash $entry.path).Hash -ne $entry.sha256){throw "Frozen input changed: $($entry.path)"}}
$receipt=Get-Content "$prior/build.json" -Raw|ConvertFrom-Json
if((Get-FileHash "$prior/lifecycle.axf").Hash -ne $receipt.axf_sha256){throw 'Checked lifecycle graph changed'}
$old="$r2/build_r3/xe_np_app.o";$known=@{}
foreach($entry in $receipt.reused_objects){$known[[IO.Path]::GetFullPath($entry.path)]=$entry.sha256}
$known[[IO.Path]::GetFullPath("$prior/xe_np_sensors.o")]='5F2A1B4531CBF3074C726F0035A8C80BEB7E535EA8F560DFFB49E10128F3F637'
$parent="$root/_artifacts/v1_usb_fast_startup_r79r2_20261006/source"
$paired="$root/_artifacts/v1_usb_integrity_20261016/paired_restore"
$via=[IO.File]::ReadAllText("$prior/lifecycle.lnp").Replace('\','/')
if([regex]::Matches($via,[regex]::Escape($old)).Count -ne 1){throw 'Provider replacement not unique'}
$reused=@()
foreach($line in $via -split "`n"){
 if($line.Trim() -match '^"(.+\.o)"$' -and $Matches[1] -ne $old){
  $path=$Matches[1];if(![IO.Path]::IsPathRooted($path)){$path="$parent/MDK-ARM/$path"}
  $path=[IO.Path]::GetFullPath($path);$hash=(Get-FileHash $path).Hash
  if(!$known.ContainsKey($path) -or $known[$path] -ne $hash){throw "Unchecked reused object: $path"}
  $reused+=@{path=$path;sha256=$hash}
 }
}
if($reused.Count -ne 73){throw 'Expected73 unchanged objects'}
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile("$parent/Tools/run_np_sync_validation_bench.ps1",[ref]$tokens,[ref]$errors)
$fn=@($ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Get-CommonCompileArgs'},$true))
if($fn.Count -ne 1 -or $errors.Count){throw 'Pinned compile flags unavailable'}
Invoke-Expression $fn[0].Extent.Text
$defs=(Get-Content "$paired/build/build_receipt.json" -Raw|ConvertFrom-Json).app_defines
$args=@('-I',$source,'-I',"$paired/source/Core/Inc",'-I',"$paired/source/Core/Src")+@(Get-CommonCompileArgs)+@('-I',"$root/_artifacts/v1_usb_config_hold_20261016/fixed_source/Core/Src",'-I',"$parent/Core/Src",'-I',"$root/Firmware/V1/Core/Inc")+@($defs|ForEach-Object{"-D$_"})
New-Item -ItemType Directory $out|Out-Null
Copy-Item -LiteralPath $original -Destination "$source/xe_np_app.c"
$via=$via.Replace($old,"$out/xe_np_app.o").Replace("$prior/lifecycle.map","$out/lifecycle.map").Replace("$prior/lifecycle.axf","$out/lifecycle.axf")
[IO.File]::WriteAllText("$out/lifecycle.lnp",$via)
$cc='C:/Keil_v5/ARM/ARMCLANG/bin'
Push-Location "$parent/MDK-ARM"
try{
 & "$cc/armclang.exe" @args "$source/xe_np_app.c" -o "$out/xe_np_app.o" -MD 2>&1|Tee-Object "$out/compile.log"
 if($LASTEXITCODE){throw 'Recovery provider compile failed'}
 & "$cc/armlink.exe" --via "$out/lifecycle.lnp" 2>&1|Tee-Object "$out/link.log"
 if($LASTEXITCODE){throw 'Recovery link failed'}
 & "$cc/fromelf.exe" --i32combined --output "$out/lifecycle_UNSEALED.hex" "$out/lifecycle.axf"
 if($LASTEXITCODE){throw 'HEX export failed'}
}finally{Pop-Location}
foreach($entry in @($inputs.inputs)+@($inputs.outputs)+@($manifest.inputs)+@($manifest.outputs)+@($reused)){if((Get-FileHash $entry.path).Hash -ne $entry.sha256){throw 'Input changed during build'}}
[ordered]@{stage='USB_SENSOR_AND_UNCLAIMED20K_RECOVERY';parent_crc32='412D4D02';compiled_units=@('USB APP provider');source_manifest_sha256=(Get-FileHash "$source/source_manifest.json").Hash;provider_sha256=(Get-FileHash "$source/xe_np_app.c").Hash;compiler_args=$args;compiler_cwd="$parent/MDK-ARM";reused_objects=$reused;axf_sha256=(Get-FileHash "$out/lifecycle.axf").Hash;raw_hex_sha256=(Get-FileHash "$out/lifecycle_UNSEALED.hex").Hash;hardware_access=$false;published=$false}|ConvertTo-Json -Depth 5|Set-Content "$out/build.json"
'PASS one provider compile;73 checked lifecycle objects reused'
