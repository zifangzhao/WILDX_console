param([Parameter(Mandatory=$true)][string]$OutputDirectory)
# Replace one sensor object in the checked USB40AB graph; never rebuild transport.
$ErrorActionPreference='Stop'
$root=(Resolve-Path "$PSScriptRoot/../../..").Path.Replace('\','/')
$out=[IO.Path]::GetFullPath($OutputDirectory).Replace('\','/')
if(!$out.StartsWith("$root/_artifacts/",[StringComparison]::OrdinalIgnoreCase) -or (Test-Path $out)){throw 'Fresh workspace artifact output required'}
$prior="$root/_artifacts/v1_usb_timing_r2_20261024/build_r3"
$parent="$root/_artifacts/v1_usb_fast_startup_r79r2_20261006/source"
$old="$root/_artifacts/v1_usb_receive_policy_r80_20261007/image/_build/xe_np_sensors_usb_sensors.o"
$source="$root/Firmware/V1/Core/Src/xe_np_sensors.c"
if((Get-FileHash $source).Hash -ne '7D141A4A4029CADB10E23C06DA25C50BE30A36FC5BE9397597CA93269B5390C8'){throw 'Driver differs from checked lifecycle source'}
if((Get-FileHash "$parent/Core/Src/xe_np_sensors.c").Hash -ne '7E96F7AA5A3A94ED033E7B1FE7C324D049E65B0B0AA3E3F9D49FA97CFF2DBED6'){throw 'Frozen sensor preimage differs'}
if((Get-FileHash "$parent/Core/Inc/xe_np_sensors.h").Hash -ne '5078FBF2C159C2C7D4F53A60B3B596F38E16387F2F8A115AC79C4D01B22AE642'){throw 'Frozen sensor ABI differs'}
if((Get-FileHash "$root/_artifacts/v1_sensor_lifecycle_20261025/after/result.json").Hash -ne '9B5FE1BC55F6EFEC6358BA73DDE3CC22F25A761CD4BDCAA4C535003D0B0C5396'){throw 'Targeted evidence changed'}
if((Get-FileHash "$root/_artifacts/v1_sensor_lifecycle_20261025/existing_suite/result.json").Hash -ne 'A10D9D4EC5DF3503F7CCB93B189768356D9BB3CA108B3366AD6B7FDB36349F4B'){throw 'Sensor suite evidence changed'}
$receipt=Get-Content "$prior/build.json" -Raw|ConvertFrom-Json
if((Get-FileHash "$prior/timing.axf").Hash -ne $receipt.axf_sha256){throw 'Checked USB image changed'}
$known=@{}
foreach($entry in $receipt.reused_objects){$known[[IO.Path]::GetFullPath($entry.path)]=$entry.sha256}
$known[[IO.Path]::GetFullPath("$prior/xe_np_app.o")]=$receipt.successful_app_object_sha256
# Service object is frozen with the exact checked AXF and its retained source receipt.
$service="$prior/xe_np_usb_stream.o"
$known[[IO.Path]::GetFullPath($service)]=(Get-FileHash $service).Hash
$via=[IO.File]::ReadAllText("$prior/timing.lnp").Replace('\','/')
if([regex]::Matches($via,[regex]::Escape($old)).Count -ne 1){throw 'Sensor object must occur exactly once'}
$reused=@()
foreach($line in $via -split "`n"){
    if($line.Trim() -match '^"(.+\.o)"$' -and $Matches[1] -ne $old){
        $path=$Matches[1];if(![IO.Path]::IsPathRooted($path)){$path="$parent/MDK-ARM/$path"}
        $path=[IO.Path]::GetFullPath($path);$hash=(Get-FileHash -LiteralPath $path).Hash
        if(!$known.ContainsKey($path) -or $known[$path] -ne $hash){throw "Unchecked object: $path"}
        $reused+=@{path=$path;sha256=$hash}
    }
}
if($reused.Count -ne 73){throw 'Expected 73 unchanged objects'}
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile("$parent/Tools/run_np_sync_validation_bench.ps1",[ref]$tokens,[ref]$errors)
$f=@($ast.FindAll({param($n)$n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Get-CommonCompileArgs'},$true))
if($f.Count -ne 1 -or $errors.Count){throw 'Pinned compiler flags unavailable'}
Invoke-Expression $f[0].Extent.Text
$common=@(Get-CommonCompileArgs)
New-Item -ItemType Directory $out|Out-Null
$via=$via.Replace($old,"$out/xe_np_sensors.o").Replace("$prior/timing.map","$out/lifecycle.map").Replace("$prior/timing.axf","$out/lifecycle.axf")
[IO.File]::WriteAllText("$out/lifecycle.lnp",$via)
$cc='C:/Keil_v5/ARM/ARMCLANG/bin'
Push-Location "$parent/MDK-ARM"
try{
    & "$cc/armclang.exe" @common $source -o "$out/xe_np_sensors.o" -MD 2>&1|Tee-Object "$out/compile.log"
    if($LASTEXITCODE){throw 'Sensor compile failed'}
    & "$cc/armlink.exe" --via "$out/lifecycle.lnp" 2>&1|Tee-Object "$out/link.log"
    if($LASTEXITCODE){throw 'USB sensor link failed'}
    & "$cc/fromelf.exe" --i32combined --output "$out/lifecycle_UNSEALED.hex" "$out/lifecycle.axf"
    if($LASTEXITCODE){throw 'USB HEX export failed'}
}finally{Pop-Location}
foreach($entry in $reused){if((Get-FileHash -LiteralPath $entry.path).Hash -ne $entry.sha256){throw 'Reused object changed during build'}}
if((Get-FileHash $source).Hash -ne '7D141A4A4029CADB10E23C06DA25C50BE30A36FC5BE9397597CA93269B5390C8'){throw 'Source changed during build'}
[ordered]@{stage='USB_SENSOR_LIFECYCLE_INCREMENTAL_UNSEALED';parent_crc32='40ABED9F';compiled_units=@('xe_np_sensors.c');source=$source;source_sha256=(Get-FileHash $source).Hash;compiler_args=$common;compiler_cwd="$parent/MDK-ARM";reused_objects=$reused;stack_report=(Select-String "$out/lifecycle.htm" -Pattern 'Maximum Stack Usage =').Line;axf_sha256=(Get-FileHash "$out/lifecycle.axf").Hash;raw_hex_sha256=(Get-FileHash "$out/lifecycle_UNSEALED.hex").Hash;hardware_access=$false;published=$false}|ConvertTo-Json -Depth 5|Set-Content "$out/build.json"
'PASS one sensor compile; 73 checked USB40AB objects reused'
