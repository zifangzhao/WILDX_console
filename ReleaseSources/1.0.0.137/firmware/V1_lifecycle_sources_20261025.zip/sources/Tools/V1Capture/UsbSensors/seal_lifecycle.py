"""Seal the explicitly checked lifecycle component once; no hardware or fusion."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import sys
import zlib

ROOT = Path(__file__).resolve().parents[3]
TASK = ROOT / '_artifacts/v1_lifecycle_release_20261025'
sys.path.insert(0, str(ROOT / 'Tools/V1Capture/UnifiedUsb'))
from package_reset_service import package


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('role', choices=['USB', 'APP'])
    p.add_argument('raw', type=Path)
    p.add_argument('label')
    p.add_argument('--output', type=Path)
    a = p.parse_args()
    raw = a.raw.resolve()
    assert raw.is_relative_to(TASK) and raw.name.endswith('_UNSEALED.hex')
    build = raw.parent
    maps = list(build.glob('*.map'))
    axfs = list(build.glob('*.axf'))
    graphs = list(build.glob('*.htm'))
    assert len(maps) == len(axfs) == len(graphs) == 1
    mapping, graph = maps[0].read_text(), graphs[0].read_text()
    regions = []
    for name, base, size, maximum in re.findall(
            r'Execution Region (\w+) \(Exec base: 0x([0-9a-fA-F]+), Load base: 0x[0-9a-fA-F]+, Size: 0x([0-9a-fA-F]+), Max: 0x([0-9a-fA-F]+)', mapping):
        size, maximum = int(size, 16), int(maximum, 16)
        assert size <= maximum, name
        regions.append(dict(name=name, base=int(base, 16), size=size, maximum=maximum))
    assert regions
    stack = int(re.search(r'Maximum Stack Usage =\s+(\d+) bytes', graph)[1])
    stack_symbol = re.search(r'^\s*Stack_Mem\s+0x[0-9a-fA-F]+\s+Data\s+(\d+)\b', mapping, re.M)
    assert stack_symbol
    stack_allocation = int(stack_symbol[1])
    assert stack_allocation == (4096 if a.role == 'USB' else 8192)
    assert stack < stack_allocation
    if a.role == 'USB':
        rx = re.search(r'^\s*xe_np_usb_out\s+0x([0-9a-fA-F]+)\s+Data\s+(\d+)\b', mapping, re.M)
        assert rx and int(rx[1], 16) == 0x2001c000 and int(rx[2]) == 512
        # Verify the retained R2 callback's real linked closure, not just its source.
        nodes = {}
        for node in re.split(r'(?=<P><STRONG><a name=)', graph):
            head = re.match(r'<P><STRONG><a name="\[([^]]+)\]"></a>([^<]+)</STRONG>', node)
            if head:
                calls = node.split('[Calls]<UL>', 1)[1].split('</UL>', 1)[0] if '[Calls]<UL>' in node else ''
                nodes[head[1]] = (head[2], re.findall(r'href="#\[([^]]+)\]"', calls))
        todo = [k for k, (name, _) in nodes.items() if name == 'NP_UsbTimingReceive']
        assert len(todo) == 1
        seen = set()
        while todo:
            key = todo.pop()
            if key in seen:
                continue
            seen.add(key)
            name, children = nodes[key]
            assert not any(x in name for x in ('DCACHE', 'DCache', 'HAL_Delay', 'HAL_I2C', 'HAL_SPI', 'HAL_ADC'))
            todo.extend(children)
    role = 'stream' if a.role == 'USB' else 'app'
    start, limit, meta, _ = package.SLOTS[role]
    code = package.base.read_intel_hex(raw)
    assert code and all(start <= address < limit for address in code)
    body = package.base.image_from_hex(code, start, limit)
    manifest = bytearray(package.manifest(body, role))
    if a.role == 'USB':
        struct.pack_into('<I', manifest, 76, 1)
        struct.pack_into('<I', manifest, 124, zlib.crc32(manifest[:124]))
    assert struct.unpack_from('<I', manifest, 80)[0] == 258
    code.update({start + i: b for i, b in enumerate(body)})
    code.update({meta + i: b for i, b in enumerate(manifest)})
    out = a.output.resolve() if a.output else TASK / (a.role.lower() + '_sealed')
    assert out.is_relative_to(TASK)
    out.mkdir(exist_ok=False)
    image = out / ('V1_' + a.role + '_' + a.label + '.hex')
    package.base.write_intel_hex(image, code)
    image.write_bytes(image.read_bytes().replace(b'\r\n', b'\n'))
    assert package.base.read_intel_hex(image) == code
    report = dict(role=a.role, label=a.label, abi=258, image=str(image), sha256=sha(image),
                  crc32=f'{zlib.crc32(body):08X}', bytes=len(body),
                  sp=f'{struct.unpack_from("<I", body)[0]:08X}', pc=f'{struct.unpack_from("<I", body, 4)[0]:08X}',
                  buildIdHex=bytes(manifest[44:76]).hex().upper(), manifest_address=f'{meta:08X}',
                  manifest_hex=manifest.hex().upper(), input=str(raw), input_sha256=sha(raw),
                  axf_sha256=sha(axfs[0]), execution_regions=regions, known_stack_bytes=stack,
                  stack_allocation_bytes=stack_allocation, stack_unknown='Cycles, Untraceable Function Pointers',
                  hardware_tested=False, published=False, fused=False)
    (out / 'identity.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('role', 'crc32', 'bytes', 'sha256', 'known_stack_bytes')}, indent=2))


if __name__ == '__main__':
    main()
