# One APP compile against the reviewed frozen alternative, one link; no hardware.
$ErrorActionPreference='Stop'
$root=(Resolve-Path "$PSScriptRoot/../../..").Path.Replace('\','/')
$task="$root/_artifacts/v1_lifecycle_release_20261025"
$source="$task/app_source";$out="$task/app_build"
if(Test-Path $out){throw 'Fresh APP build output required'}
if((Get-FileHash "$source/source_manifest.json").Hash -ne '59D2C76F244C97234CEF1A68E0D2245EE329D2DB703FD40C8879B5047F2ED328'){throw 'Reviewed source manifest changed'}
$m=Get-Content "$source/source_manifest.json" -Raw|ConvertFrom-Json
$known=@{}
foreach($d in $m.source_dependencies){
 if((Get-FileHash -LiteralPath $d.candidate_path).Hash -ne $d.candidate_sha256){throw "Frozen input changed: $($d.candidate_path)"}
 $known[[IO.Path]::GetFullPath($d.candidate_path)]=$d.candidate_sha256
}
foreach($d in $m.object_reuse.inputs){if((Get-FileHash -LiteralPath $d.path).Hash -ne $d.sha256){throw 'Checked reused APP object changed'}}
$sensor="$task/usb_build/xe_np_sensors.o"
$sensorReceipt=Get-Content "$task/usb_build/build.json" -Raw|ConvertFrom-Json
if($sensorReceipt.source_sha256 -ne $m.sensor_lifecycle_source.sha256){throw 'Sensor input mismatch'}
# Same sensor struct/wire layout; only the Bosch header include spellings differ.
$oldHeader=[IO.File]::ReadAllText("$root/_artifacts/v1_usb_fast_startup_r79r2_20261006/source/Core/Inc/xe_np_sensors.h")
$oldHeader=$oldHeader.Replace('../../Middlewares/Bosch/BME280_SensorAPI/bme280.h','bme280.h').Replace('../../Middlewares/Bosch/BMM150_SensorAPI/bmm150.h','bmm150.h')
if($oldHeader -ne [IO.File]::ReadAllText("$source/Core/Inc/xe_np_sensors.h")){throw 'USB/APP sensor ABI differs'}
if((Get-FileHash "$root/Firmware/V1/MDK-ARM/app.sct").Hash -ne '9B38DFC80E4E58A37D1ABA509E5C12161E253636116E2F5D4849F8A5CC20BE61'){throw 'APP scatter changed'}
$flags=@('-xc','-std=c11','--target=arm-arm-none-eabi','-mcpu=cortex-m33','-mfpu=fpv5-sp-d16','-mfloat-abi=hard','-c','-fno-rtti','-funsigned-char','-fshort-enums','-fshort-wchar','-gdwarf-4','-O3','-ffunction-sections','-Wno-packed','-Wno-nonportable-include-path')
foreach($inc in @("$source/Core/Inc","$source/Drivers/STM32U5xx_HAL_Driver/Inc","$root/Drivers/STM32U5xx_HAL_Driver/Inc","$root/Drivers/STM32U5xx_HAL_Driver/Inc/Legacy","$root/Drivers/CMSIS/Device/ST/STM32U5xx/Include","$root/Drivers/CMSIS/Include","$root/Firmware/V1/MDK-ARM/RTE/_USB384_NP_BGA_MMC","$root/Middlewares/Bosch/BME280_SensorAPI","$root/Middlewares/Bosch/BMM150_SensorAPI")){$flags+=@('-I',$inc)}
$args=$flags+@($m.defines|ForEach-Object{"-D$_"})
New-Item -ItemType Directory $out|Out-Null
$compiler='C:/Keil_v5/ARM/ARMCLANG/bin';$object="$out/xe_np_app.o"
& "$compiler/armclang.exe" @args -M -MF "$out/app.d" "$source/Core/Src/xe_np_app.c"
if($LASTEXITCODE){throw 'Frozen APP dependency discovery failed'}
$deps=([IO.File]::ReadAllText("$out/app.d") -replace '\\\r?\n',' ')
$deps=$deps.Substring($deps.IndexOf(': ')+2).Trim()-split '\s+'
$identities=@()
foreach($d in $deps){
 $path=[IO.Path]::GetFullPath($d);$hash=(Get-FileHash -LiteralPath $path).Hash
 if(!$known.ContainsKey($path) -or $known[$path] -ne $hash){throw "Unreviewed compiler dependency: $path"}
 $identities+=@{path=$path;sha256=$hash}
}
if($identities.Count -ne $m.dependency_count){throw 'Frozen dependency count differs'}
& "$compiler/armclang.exe" @args "$source/Core/Src/xe_np_app.c" -o $object 2>&1|Tee-Object "$out/compile.log"
if($LASTEXITCODE){throw 'Frozen APP compile failed'}
$via=[IO.File]::ReadAllText($m.link_response).Replace('\','/')
$appOld="$root/_artifacts/v1_capture_anchor_20261023/app_build_r5/xe_np_app_syncbench.o"
$sensorOld="$root/_artifacts/v1_canonical_baseline_20261006/xe_np_sensors_sensors.o"
foreach($old in @($appOld,$sensorOld)){if([regex]::Matches($via,[regex]::Escape($old)).Count -ne 1){throw 'Changed APP object must occur once'}}
$via=$via.Replace($appOld,$object).Replace($sensorOld,$sensor)
$oldName="$root/_artifacts/v1_capture_anchor_20261023/app_build_r5/USB384_NP_BGA_MMC_syncbench"
$via=$via.Replace("$oldName.map","$out/lifecycle.map").Replace("$oldName.axf","$out/lifecycle.axf")
[IO.File]::WriteAllText("$out/lifecycle.lnp",$via)
& "$compiler/armlink.exe" --via "$out/lifecycle.lnp" 2>&1|Tee-Object "$out/link.log"
if($LASTEXITCODE){throw 'Frozen APP link failed'}
& "$compiler/fromelf.exe" --i32combined --output "$out/lifecycle_UNSEALED.hex" "$out/lifecycle.axf"
if($LASTEXITCODE){throw 'APP HEX export failed'}
foreach($d in $identities){if((Get-FileHash -LiteralPath $d.path).Hash -ne $d.sha256){throw 'APP input changed during build'}}
[ordered]@{stage='APP_LIFECYCLE_ALTERNATIVE_INCREMENTAL_UNSEALED';basis=$m.basis;source_manifest_sha256=(Get-FileHash "$source/source_manifest.json").Hash;compiled_units=@('xe_np_app.c');source_dependencies=$identities;defines=$m.defines;reused_objects=@($m.object_reuse.inputs|Where-Object{$_.path.Replace('\','/') -ne $sensorOld});sensor_object=$sensor;sensor_object_sha256=(Get-FileHash $sensor).Hash;axf_sha256=(Get-FileHash "$out/lifecycle.axf").Hash;raw_hex_sha256=(Get-FileHash "$out/lifecycle_UNSEALED.hex").Hash;hardware_access=$false;published=$false}|ConvertTo-Json -Depth 6|Set-Content "$out/build.json"
'PASS one frozen APP compile;73 checked APP objects and newly checked sensor object reused'
