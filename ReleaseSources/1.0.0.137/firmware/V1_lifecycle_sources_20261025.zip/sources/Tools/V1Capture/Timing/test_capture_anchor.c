#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#ifdef _MSC_VER
#define __attribute__(x)
#endif
typedef struct {uint32_t CR1,PSC,CNT,SMCR,CCMR1,CCR2;} TIM_TypeDef;
typedef struct {TIM_TypeDef *Instance;} TIM_HandleTypeDef;
typedef enum {HAL_OK=0,HAL_ERROR=1} HAL_StatusTypeDef;
static TIM_TypeDef root_regs,other_regs;
#define TIM2 (&root_regs)
#define TIM_CR1_CEN 1U
#define TIM_SMCR_SMS 0x10007U
#define TIM_SLAVEMODE_RESET 4U
#define TIM_CCMR1_OC2M_0 0x1000U
#define TIM_CCMR1_OC2M_1 0x2000U
#define TIM_CCMR1_OC2M_2 0x4000U
#define TIM_CCMR1_OC2M 0x1007000U
#define TIM_CCMR1_IC1F 0xf0U
static struct {uint32_t DEMCR,DHCSR;} debug_regs;
static struct {uint32_t CTRL,CYCCNT;} dwt_regs;
#define CoreDebug (&debug_regs)
#define DWT (&dwt_regs)
#define CoreDebug_DEMCR_TRCENA_Msk 1U
#define CoreDebug_DHCSR_C_DEBUGEN_Msk 1U
#define DWT_CTRL_CYCCNTENA_Msk 1U
#define DWT_CTRL_NOCYCCNT_Msk 2U
static uint32_t irq,tick,clock_reads,prepared,root_calls;
static HAL_StatusTypeDef start_result=HAL_OK;
uint32_t np_mode_hz=15000U,np_mode_mask=3U,SystemCoreClock=187200000U;
static uint32_t __get_PRIMASK(void){return irq;}
static void __disable_irq(void){irq=1U;}
static void __set_PRIMASK(uint32_t value){irq=value;}
static void __DMB(void){}
static void __DSB(void){}
static uint32_t HAL_GetTick(void){clock_reads++;return tick;}
static uint32_t HAL_GetUIDw0(void){return 0x001d0006U;}
static uint32_t HAL_GetUIDw1(void){return 0x5942500bU;}
static uint32_t HAL_GetUIDw2(void){return 0x20313354U;}
static uint32_t fresh_step=9U;
static uint32_t fresh_cycles(void)
{uint32_t value=dwt_regs.CYCCNT;dwt_regs.CYCCNT+=fresh_step;return value;}
#define NP_CAPTURE_CLOCK_CYCLES() fresh_cycles()
static HAL_StatusTypeDef HAL_TIM_Base_Start(TIM_HandleTypeDef *h)
{
    if(h->Instance==TIM2){assert(irq && prepared);root_calls++;dwt_regs.CYCCNT+=68U;}
    if(start_result==HAL_OK)h->Instance->CR1=1U;
    return start_result;
}
static void *anchor_memset(void *p,int value,size_t bytes);
#define memset anchor_memset
#include "../../../Firmware/V1/Core/Src/np_capture_anchor_port.inc"
#undef memset
static void *anchor_memset(void *p,int value,size_t bytes)
{
    if(p==&np_capture_anchor){
        uint8_t r[64];NP_CaptureAnchor_Query(r,1U);
        assert(!(xe_np_online_word(r+12)&NP_ANCHOR_ROOT_VALID));
    }
    return memset(p,value,bytes);
}
typedef struct {uint32_t CCR,CSR,CDAR,CBR1;} DMA_Channel_TypeDef;
#define DMA_CCR_EN 1U
#define DMA_FLAG_TC 1U
#define DMA_FLAG_HT 2U
#define DMA_FLAG_DTE 4U
#define DMA_FLAG_ULE 8U
#define DMA_FLAG_USE 16U
#define DMA_FLAG_TO 32U
static DMA_Channel_TypeDef channels[12];
static int paired,paired_double_offset;
static uint32_t test_ring=62400U;
static uint8_t np3_valid,np3_claimed;
static DMA_Channel_TypeDef *np3_channel(unsigned i){return &channels[paired && i<8U?i&3U:i];}
#define NP_ANCHOR_RING() test_ring
#define NP_ANCHOR_FIRST_BYTES() 62400U
#define NP_ANCHOR_MASK() np_mode_mask
#define NP_ANCHOR_WIDTH(i) (paired && (i)<8U?2U:1U)
#define NP_ANCHOR_OFFSET(i) ((paired && (i)<8U?(i)&3U:(i))*5200U/(paired && (i)<8U && !paired_double_offset?2U:1U))
#define NP_ANCHOR_BASE(i,n) (0x20000000U+(paired && (i)<8U?((i)&3U)*2U:(i))*(n))
static uint32_t XE_NP_Board_GetRuntimeExpectedPsbClkHz(void){return np_mode_hz*780U;}
/* Match the APP: diagnostic defaults are defined AFTER anchor_port. */
#ifndef TEST_QUIET
#define TEST_QUIET 0U
#endif
#ifndef TEST_DRYRUN
#define TEST_DRYRUN 0U
#endif
#define XE_NP_APP_QUAD_DMA_QUIET_ENABLE TEST_QUIET
#define XE_NP_APP_QUAD_DMA_NO_PROBE_DRYRUN TEST_DRYRUN
#include "../../../Firmware/V1/Core/Src/np_capture_origin_producer.inc"
#include "../../../Firmware/V1/Core/Inc/np_ble_schedule.h"
static NpBleSchedule npl_schedule;
static struct {struct {uint32_t session,start_lba,ap_hz;} config;} np_sd_log;
static uint8_t np_sd_metadata[512],saved_clock[512];
#define npl_put xe_np_online_put
static uint32_t npl_crc(const uint8_t *p,unsigned bytes)
{
    uint32_t c=~0U;
    for(unsigned n=0;n<bytes;n++){c^=p[n];for(unsigned b=0;b<8;b++)c=(c>>1)^((0U-(c&1U))&0xedb88320U);}
    return ~c;
}
static int np_sd_metadata_write(uint32_t lba,const uint8_t *data)
{assert(lba==np_sd_log.config.start_lba+5U);memcpy(saved_clock,data,512);return 0;}
/* Extracted verbatim from the production port by the test runner. */
#include "sd_clock.inc"
typedef struct {unsigned unused;} PCD_HandleTypeDef;
typedef struct {uint8_t bmRequest,bRequest;uint16_t wValue,wIndex,wLength;} XE_NP_UsbSetup;
static uint32_t stalls,sends;
static uint8_t sent[64];
static struct {uint32_t streaming,tx_busy,tx_pending;} xe_np_usb_state;
static uint32_t word_fault;
static uint32_t XE_NP_App_UsbWordFault(void){return word_fault;}
static void XE_NP_UsbStream_Stall(PCD_HandleTypeDef *h){(void)h;stalls++;}
static int XE_NP_UsbStream_CtlSend(PCD_HandleTypeDef *h,const uint8_t *p,uint32_t n,uint32_t requested)
{(void)h;assert(n==64U && requested==64U);memcpy(sent,p,64);sends++;return 0;}
#include "../../../Firmware/V1/Core/Src/np_capture_anchor_usb.inc"
static void seal(uint8_t p[64]){xe_np_online_put(p+60,xe_np_online_crc(p));}
static void prepare_anchor(void)
{
    irq=0;paired=0;paired_double_offset=1;test_ring=62400U;
    np_mode_mask=3U;np_mode_hz=15000U;SystemCoreClock=187200000U;
    tick=123U;dwt_regs.CTRL=0;dwt_regs.CYCCNT=1000U;start_result=HAL_OK;prepared=1U;
    memset(&root_regs,0,sizeof(root_regs));
    root_regs.SMCR=TIM_SLAVEMODE_RESET;root_regs.CCMR1=0x7000U;root_regs.CCR2=6U;
    np_capture_anchor_arm();
    for(unsigned i=0;i<12U;i++){
        DMA_Channel_TypeDef *c=np3_channel(i);
        c->CCR=DMA_CCR_EN;c->CSR=0U;
        c->CDAR=NP_ANCHOR_BASE(i,62400U)+NP_ANCHOR_OFFSET(i)*NP_ANCHOR_WIDTH(i);
        c->CBR1=62400U-NP_ANCHOR_OFFSET(i)*NP_ANCHOR_WIDTH(i);
    }
}
static void start_anchor(void)
{
    TIM_HandleTypeDef root={TIM2};
    assert(np_capture_anchor_start_root(&root,NP_CaptureAnchor_Prearmed())==HAL_OK);
}
static void witness(uint32_t total)
{
    for(unsigned i=0;i<12U;i++){
        DMA_Channel_TypeDef *c=np3_channel(i);
        c->CSR=DMA_FLAG_TC;
        c->CDAR=NP_ANCHOR_BASE(i,test_ring)+
            ((total+NP_ANCHOR_OFFSET(i))%test_ring)*NP_ANCHOR_WIDTH(i);
    }
    dwt_regs.CYCCNT=np_capture_anchor.before_cycles+total*64U+68U;
    tick=np_capture_anchor.before_ms+(total*64U+68U)/187200U;
}
static void test_origin(void)
{
    uint64_t origin=0;
    XE_NP_AcquisitionAnchor a={0};
    a.flags=NP_ANCHOR_ROOT_VALID|NP_ANCHOR_CYCLES_VALID;
    a.before_ms=123U;a.after_ms=123U;a.before_cycles=1000U;a.after_cycles=1068U;
    a.counter_hz=187200000U;a.source_hz=11700000U;
#define PROVE(total,head,cursor,tc) np_capture_origin(&a,62400U,head,cursor,tc, \
    a.before_cycles+(total)*64U+68U,a.before_ms+((total)*64U+68U)/187200U,187200000U,11700000U,&origin)
    assert(PROVE(63400U,1000U,39840U,62400U) && origin==159360U);
    assert(PROVE(40000U,40000U,16000U,31200U) && origin==64000U);
    assert(!PROVE(125800U,1000U,39840U,62400U)); /* Two possible laps, even at nominal best fit. */
    assert(!PROVE(125800U,1000U,39840U,62400U)); /* Same head after a full-lap stall is not evidence. */
    assert(!PROVE(63500U,1000U,39840U,62400U)); /* Short stall/delayed post-head witness. */
    assert(!PROVE(22000U,22000U,60848U,20800U)); /* Staggered P3 TC before initialized history. */
    a.before_cycles=0xfffffff0U;a.after_cycles=52U;a.before_ms=UINT32_MAX-10U;
    assert(PROVE(63400U,1000U,39840U,62400U) && origin==159360U); /* Bounded wraps. */
    assert(!np_capture_origin(&a,62400U,1000U,39840U,62400U,
        a.before_cycles+0x80000000U,a.before_ms+21U,187200000U,11700000U,&origin));
    assert(!np_capture_origin(&a,62400U,1000U,39840U,62400U,
        a.before_cycles+63400U*64U+68U,a.before_ms+300U,187200000U,11700000U,&origin));
    assert(!np_capture_origin(&a,62400U,1000U,39840U,62400U,
        a.before_cycles+63400U*64U+68U,a.before_ms+21U,124800000U,11700000U,&origin));
    a.source_hz=11699996U;assert(!PROVE(63400U,1000U,39840U,62400U));
    a.source_hz=11700000U;a.flags=NP_ANCHOR_ROOT_VALID;
    assert(!PROVE(63400U,1000U,39840U,62400U));
#undef PROVE
    /* Exercise actual prearm/first-cursor helpers and their one-shot behavior. */
    prepare_anchor();assert(NP_CaptureAnchor_Prearmed());
    for(unsigned kind=0;kind<4U;kind++){
        DMA_Channel_TypeDef save=channels[0];
        if(kind==0U)channels[0].CSR=DMA_FLAG_TC;
        if(kind==1U)channels[0].CDAR+=4U;
        if(kind==2U)channels[0].CBR1-=4U;
        if(kind==3U)channels[0].CCR=0;
        assert(!NP_CaptureAnchor_Prearmed());channels[0]=save;
    }
    for(unsigned kind=0;kind<7U;kind++){
        prepare_anchor();
        if(kind==0U)root_regs.CNT=1U;
        if(kind==1U)root_regs.CR1=TIM_CR1_CEN;
        if(kind==2U)root_regs.CCMR1=0x6000U; /* PWM1 is not safe here. */
        if(kind==3U)root_regs.CCMR1|=0x10U;
        if(kind==4U)root_regs.CCR2=0U;
        if(kind==5U)root_regs.CCR2=16U;
        if(kind==6U)root_regs.SMCR=0U;
        start_anchor();assert(!np_capture_origin_phase);
    }
    for(unsigned kind=0;kind<6U;kind++){
        prepare_anchor();start_anchor();assert(np_capture_origin_phase);
        witness(63400U);
        if(kind==0U)channels[0].CSR=0U;
        if(kind==1U)channels[0].CDAR=NP_ANCHOR_BASE(0,62400U)-4U;
        if(kind==2U)channels[0].CDAR+=1U;
        if(kind==3U)channels[4].CSR|=DMA_FLAG_DTE;
        if(kind==4U)channels[0].CCR=0U;
        if(kind==5U)dwt_regs.CYCCNT+=100U*64U;
        np_capture_origin_selected(62400U,0U,39840U);
        assert(np_capture_origin_attempted && !(np_capture_anchor.flags&NP_ANCHOR_SOURCE_VALID));
        uint32_t reads=clock_reads;
        np_capture_origin_selected(62400U,0U,39840U);assert(clock_reads==reads);
    }
    prepare_anchor();start_anchor();witness(63400U);
    np_capture_origin_selected(62400U,0U,39840U);
    assert(np_capture_anchor.flags&NP_ANCHOR_SOURCE_VALID);
    assert(np_capture_anchor.origin_lo==159360U && !np_capture_anchor.origin_hi);
    uint32_t before,after;assert(NP_CaptureAnchor_GetExportMs(&before,&after));
    assert(before==136U && after==137U);
    np_sd_log.config.session=99U;np_sd_log.config.start_lba=4096U;np_sd_log.config.ap_hz=np_mode_hz;
    memset(&npl_schedule,0,sizeof(npl_schedule));
    npl_schedule.clock.valid=1U;npl_schedule.clock.tick=100U;
    npl_schedule.clock.utc_us=1792773000000000ULL;
    NP_SD_BleArmStamp(999U);assert(!npl_schedule.valid); /* Root is not source zero. */
    assert(npl_save_clock()==0 && npl_schedule.valid);
    assert(!memcmp(saved_clock,"N1SDUTC2",8) && xe_np_online_word(saved_clock+8)==2U && (xe_np_online_word(saved_clock+16)&2U));
    assert(xe_np_online_word(saved_clock+64)==136U && xe_np_online_word(saved_clock+68)==137U);
    assert(xe_np_online_word(saved_clock+76)==1000U && xe_np_online_word(saved_clock+508)==npl_crc(saved_clock,508U));
    np_capture_anchor.before_ms=UINT32_MAX-10U;np_capture_anchor.after_ms=UINT32_MAX-10U;
    assert(NP_CaptureAnchor_GetExportMs(&before,&after) && before==2U && after==3U);
    np_capture_anchor.origin_lo=UINT32_MAX;np_capture_anchor.origin_hi=UINT32_MAX;
    assert(!NP_CaptureAnchor_GetExportMs(&before,&after));
    prepare_anchor();assert(!NP_CaptureAnchor_GetExportMs(&before,&after));
    assert(npl_save_clock()==0 && !(xe_np_online_word(saved_clock+16)&2U));
    np_mode_mask=0;npl_schedule.valid=1U;NP_SD_BleArmStamp(456U);
    assert(npl_save_clock()==0 && npl_schedule.valid && npl_schedule.after==456U);
    assert(!memcmp(saved_clock,"N1SDUTC1",8) && xe_np_online_word(saved_clock+8)==1U); /* Media unchanged. */
    prepare_anchor();paired=1; /* Recreate paired physical descriptors, including aliases. */
    for(unsigned i=0;i<12U;i++){
        DMA_Channel_TypeDef *c=np3_channel(i);c->CCR=DMA_CCR_EN;c->CSR=0U;
        c->CDAR=NP_ANCHOR_BASE(i,62400U)+NP_ANCHOR_OFFSET(i)*NP_ANCHOR_WIDTH(i);
        c->CBR1=62400U-NP_ANCHOR_OFFSET(i)*NP_ANCHOR_WIDTH(i);
    }
    assert(np3_channel(0U)==np3_channel(4U) && NP_CaptureAnchor_Prearmed());
    start_anchor();witness(40000U);np_capture_origin_selected(62400U,0U,16000U);
    assert((np_capture_anchor.flags&NP_ANCHOR_SOURCE_VALID) && np_capture_anchor.origin_lo==64000U);
    prepare_anchor();paired=1;paired_double_offset=0;test_ring=31200U;
    for(unsigned i=0;i<8U;i++){
        DMA_Channel_TypeDef *c=np3_channel(i);c->CCR=DMA_CCR_EN;c->CSR=0U;
        c->CDAR=NP_ANCHOR_BASE(i,test_ring)+NP_ANCHOR_OFFSET(i)*NP_ANCHOR_WIDTH(i);
        c->CBR1=NP_ANCHOR_FIRST_BYTES()-NP_ANCHOR_OFFSET(i)*NP_ANCHOR_WIDTH(i);
    }
    assert(NP_CaptureAnchor_Prearmed()); /* USB pair: full physical block / half-size logical ring. */
    start_anchor();witness(32200U);np_capture_origin_selected(test_ring,0U,10000U);
    assert((np_capture_anchor.flags&NP_ANCHOR_SOURCE_VALID) && np_capture_anchor.origin_lo==40000U);
    uint32_t generation=np_capture_anchor.generation;
    prepare_anchor();assert(np_capture_anchor.generation==generation+1U &&
                           !(np_capture_anchor.flags&NP_ANCHOR_SOURCE_VALID));
}
typedef struct {unsigned unused;} XE_NP_Runtime;
static struct {uint8_t initialized,i2c_ready,base_configured;} xe_np_probe_state;
static uint32_t xe_np_dma_start_error_seen,admit_calls,admit_failures;
static HAL_StatusTypeDef admit_result;
#define XE_NP_APP_EXPERIMENT_GPIOE_QUAD_DMA_INTERLEAVE_ENABLE 1U
#define XE_NP_APP_LEGACY_FS_ENABLE 0U
#define XE_NP_APP_BENCH_CAPTURE_WITHOUT_STORAGE 1U
#define XE_NP_APP_RAW_SD_SINK_ENABLE 0U
#define XE_NP_APP_RAW_SD_DEDICATED_CAPTURE_ENABLE 0U
#define XE_NP_APP_PROBE_STAGE_WAIT_CAPTURE_LOCK 8U
#define XE_NP_APP_PROBE_DIAG_FAILURE_DMA_START_FAIL 9U
static HAL_StatusTypeDef XE_NP_App_StartCaptureDma(XE_NP_Runtime *runtime)
{assert(runtime && !xe_np_probe_state.initialized && NP_CaptureAnchor_Unpublished());admit_calls++;return admit_result;}
static void XE_NP_App_UpdateProbeDiag(XE_NP_Runtime *r,void *p,unsigned stage,unsigned probe,unsigned fault,HAL_StatusTypeDef status)
{assert(r && !p && stage==8U && !probe && fault==9U && status==HAL_ERROR);}
static void XE_NP_App_SetProbeStartupFailureState(XE_NP_Runtime *r,unsigned ready,unsigned configured)
{(void)ready;(void)configured;assert(r);admit_failures++;}
static void admit(void)
{
    XE_NP_Runtime state={0},*runtime=&state;
    switch(1){case 1:
#include "../../../Firmware/V1/Core/Src/np_capture_admit.inc"
        xe_np_probe_state.initialized=1U;break;
    }
}
static void test_admission(void)
{
    np3_valid=np3_claimed=0;xe_np_probe_state.initialized=0;admit_result=HAL_OK;
    admit();assert(admit_calls==1U && !admit_failures && xe_np_probe_state.initialized);
    admit();assert(admit_calls==1U && admit_failures==1U); /* No restart of an admitted capture. */
    for(unsigned kind=0;kind<3U;kind++){
        xe_np_probe_state.initialized=0;np3_valid=(uint8_t)(kind==0U);np3_claimed=(uint8_t)(kind==1U);
        admit_result=HAL_ERROR;admit();assert(!xe_np_probe_state.initialized);
    }
    assert(admit_calls==2U && admit_failures==4U && xe_np_dma_start_error_seen);
}
#undef XE_NP_APP_LEGACY_FS_ENABLE
#undef XE_NP_APP_BENCH_CAPTURE_WITHOUT_STORAGE
#define XE_NP_APP_LEGACY_FS_ENABLE 1U
#define XE_NP_APP_BENCH_CAPTURE_WITHOUT_STORAGE 0U
static void test_legacy_not_reprimed(void)
{
    XE_NP_Runtime state={0},*runtime=&state;
    switch(1){case 1:
#include "../../../Firmware/V1/Core/Src/np_capture_admit.inc"
        assert(runtime && admit_calls==2U);break;
    }
}
static void test_fresh_clock(void)
{
    uint8_t r[64];
    np_capture_clock_domain=np_capture_clock_hz=np_capture_clock_root_domain=0U;
    irq=0;debug_regs.DHCSR=0;dwt_regs.CTRL=0;fresh_step=9U;
    SystemCoreClock=187200000U;dwt_regs.CYCCNT=1000U;tick=123U;
    NP_CaptureClock_Query(r,100U,1);
    int diagnostic=XE_NP_APP_QUAD_DMA_QUIET_ENABLE || XE_NP_APP_QUAD_DMA_NO_PROBE_DRYRUN;
    if(diagnostic){
        assert(xe_np_online_word(r+12)==0x100U && !xe_np_online_word(r+16));
        assert(dwt_regs.CYCCNT==1000U);return;
    }
    assert(xe_np_online_word(r)==NP_CLOCK_REPLY && xe_np_online_word(r+8)==100U);
    assert(xe_np_online_word(r+12)==0x103U && xe_np_online_word(r+16)==100U);
    assert(xe_np_online_word(r+44)==0U && xe_np_online_word(r+40)==187200000U);
    assert(xe_np_online_word(r+48)==HAL_GetUIDw0() && xe_np_online_word(r+52)==HAL_GetUIDw1());
    assert(xe_np_online_word(r+56)==HAL_GetUIDw2() && xe_np_online_word(r+60)==xe_np_online_crc(r));
    uint32_t generation=np_capture_anchor.generation;
    np_capture_anchor_arm();prepared=1U;start_result=HAL_OK;
    TIM_HandleTypeDef root={TIM2};
    assert(np_capture_anchor_start_root(&root,0)==HAL_OK);
    NP_CaptureClock_Query(r,101U,1);
    assert(xe_np_online_word(r+12)==0x107U && xe_np_online_word(r+16)==100U);
    assert(xe_np_online_word(r+44)==100U && xe_np_online_word(r+20)==generation+1U);
    /* Raw DWT rollover remains valid. Host must prove the unique long wrap. */
    dwt_regs.CYCCNT=0xfffffffcU;NP_CaptureClock_Query(r,102U,1);
    assert(xe_np_online_word(r+12)==0x107U);
    assert(xe_np_online_word(r+36)-xe_np_online_word(r+32)==9U);
    assert(xe_np_online_word(r+16)==100U);
    dwt_regs.CTRL=0;NP_CaptureClock_Query(r,103U,1);
    assert(xe_np_online_word(r+16)==103U && xe_np_online_word(r+44)==0U);
    SystemCoreClock=124800000U;NP_CaptureClock_Query(r,104U,1);
    assert(xe_np_online_word(r+16)==104U && xe_np_online_word(r+44)==0U);
    fresh_step=0;NP_CaptureClock_Query(r,105U,1);
    assert(xe_np_online_word(r+12)==0x100U && !xe_np_online_word(r+16));
    fresh_step=9;NP_CaptureClock_Query(r,106U,1);assert(xe_np_online_word(r+16)==106U);
    debug_regs.DHCSR=1;NP_CaptureClock_Query(r,107U,1);
    assert(xe_np_online_word(r+12)==0x100U && !xe_np_online_word(r+16));
    debug_regs.DHCSR=0;NP_CaptureClock_Query(r,108U,1);assert(xe_np_online_word(r+16)==108U);
    dwt_regs.CTRL|=DWT_CTRL_NOCYCCNT_Msk;NP_CaptureClock_Query(r,109U,1);
    assert(xe_np_online_word(r+12)==0x100U && !xe_np_online_word(r+16));
    dwt_regs.CTRL&=~DWT_CTRL_NOCYCCNT_Msk;
    /* A reboot's cleared RAM cannot silently reuse an earlier domain token. */
    np_capture_clock_domain=np_capture_clock_hz=np_capture_clock_root_domain=0U;
    NP_CaptureClock_Query(r,110U,1);assert(xe_np_online_word(r+16)==110U);
    PCD_HandleTypeDef pcd={0};XE_NP_UsbSetup q={0xc0U,0x7fU,0x5678U,0x1234U,64U};
    assert(np_capture_anchor_usb_request(&pcd,&q));
    assert(xe_np_online_word(sent+8)==0x12345678U && (xe_np_online_word(sent+12)&3U)==3U);
    uint32_t reads=clock_reads,oldcycles=dwt_regs.CYCCNT;
    xe_np_usb_state.streaming=1U;q.wValue++;
    assert(np_capture_anchor_usb_request(&pcd,&q));
    assert(xe_np_online_word(sent+12)==0x100U && clock_reads==reads && dwt_regs.CYCCNT==oldcycles);
    xe_np_usb_state.streaming=0U;word_fault=1U;q.wValue++;
    assert(np_capture_anchor_usb_request(&pcd,&q) && xe_np_online_word(sent+12)==0x100U);
    word_fault=0;q.wValue=q.wIndex=0;uint32_t failed=stalls;
    assert(np_capture_anchor_usb_request(&pcd,&q) && stalls==failed+1U);
    q.wValue=1;q.wLength=63;
    assert(np_capture_anchor_usb_request(&pcd,&q) && stalls==failed+2U);
    q.wLength=64;q.bmRequest=0x40;
    assert(np_capture_anchor_usb_request(&pcd,&q) && stalls==failed+3U);
    irq=1U;NP_CaptureClock_Query(r,111U,1);assert(irq==1U);irq=0U;
    /* Arm must not hide an observed counter stop by re-enabling it. */
    dwt_regs.CTRL=0;np_capture_anchor_arm();
    assert(np_capture_anchor_start_root(&root,0)==HAL_OK);
    NP_CaptureClock_Query(r,120U,1);
    assert(xe_np_online_word(r+16)==120U && !xe_np_online_word(r+44));
    assert(xe_np_online_word(r+12)==0x103U);
    /* Unavailable replies still invalidate explicitly observed unsafe state. */
    dwt_regs.CTRL=0;NP_CaptureClock_Query(r,121U,0);
    assert(xe_np_online_word(r+12)==0x100U && !xe_np_online_word(r+16));
    dwt_regs.CTRL=DWT_CTRL_CYCCNTENA_Msk;NP_CaptureClock_Query(r,122U,1);
    assert(xe_np_online_word(r+16)==122U && !xe_np_online_word(r+44));
    debug_regs.DHCSR=1;NP_CaptureClock_Query(r,123U,0);
    assert(xe_np_online_word(r+12)==0x100U && !xe_np_online_word(r+16));
    debug_regs.DHCSR=0;NP_CaptureClock_Query(r,124U,1);
    assert(xe_np_online_word(r+16)==124U);
    SystemCoreClock=187200000U;NP_CaptureClock_Query(r,125U,0);
    assert(xe_np_online_word(r+12)==0x100U && !xe_np_online_word(r+16));
    NP_CaptureClock_Query(r,126U,1);assert(xe_np_online_word(r+16)==126U);
}
int main(void)
{
    uint8_t q[64]={0},r[64];uint32_t before,after;
    TIM_HandleTypeDef root={TIM2},other={&other_regs};
    NP_CaptureAnchor_Query(r,7U);assert(!(xe_np_online_word(r+12)&NP_ANCHOR_ROOT_VALID));
    assert(!NP_CaptureAnchor_GetMs(&before,&after));
    np_capture_anchor_arm();assert(np_capture_anchor.generation==1U);
    assert(debug_regs.DEMCR==1U && dwt_regs.CTRL==1U);
    prepared=1U;tick=123U;dwt_regs.CYCCNT=0xfffffff0U;
    assert(np_capture_anchor_start_root(&root,0)==HAL_OK && !irq && root_calls==1U);
    assert(clock_reads==2U && NP_CaptureAnchor_GetMs(&before,&after));
    assert(before==123U && after==123U);
    NP_CaptureAnchor_Query(r,9U);
    assert(xe_np_online_word(r)==NP_ANCHOR_REPLY && xe_np_online_word(r+8)==9U);
    assert(xe_np_online_word(r+12)==(NP_ANCHOR_V1_GPIO_EDGE|NP_ANCHOR_ROOT_VALID|NP_ANCHOR_CYCLES_VALID|NP_ANCHOR_SOFTWARE));
    assert(!(xe_np_online_word(r+12)&NP_ANCHOR_SOURCE_VALID));
    assert((uint32_t)(xe_np_online_word(r+32)-xe_np_online_word(r+28))==68U);
    assert(xe_np_online_word(r+40)==11700000U && xe_np_online_word(r+52)==15000U);
    assert(xe_np_online_word(r+56)==1000U && xe_np_online_word(r+60)==xe_np_online_crc(r));
    for(unsigned i=0;i<100U;i++)NP_CaptureAnchor_Query(r,i);
    assert(clock_reads==2U && root_calls==1U); /* Queries never sample clocks. */
    assert(np_capture_anchor_start_root(&other,0)==HAL_OK && clock_reads==2U);
    xe_np_online_put(q,NP_ANCHOR_REQUEST);xe_np_online_put(q+4,1U);xe_np_online_put(q+8,19U);seal(q);
    assert(XE_NP_AcquisitionAnchor_Request(q));
    for(unsigned i=12U;i<60U;i++){q[i]=1U;seal(q);assert(!XE_NP_AcquisitionAnchor_Request(q));q[i]=0;}
    seal(q);q[60]^=1U;assert(!XE_NP_AcquisitionAnchor_Request(q));
    PCD_HandleTypeDef pcd={0};XE_NP_UsbSetup setup={0xc0U,0x7eU,0,0,64};
    assert(np_capture_anchor_usb_request(&pcd,&setup)==1 && sends==1U && !stalls);
    assert(xe_np_online_word(sent+8)==0U && xe_np_online_word(sent+60)==xe_np_online_crc(sent));
    setup.wLength=63;assert(np_capture_anchor_usb_request(&pcd,&setup)==1 && stalls==1U);
    setup.wLength=64;setup.bmRequest=0x40;assert(np_capture_anchor_usb_request(&pcd,&setup)==1 && stalls==2U);
    setup.bRequest=0x72;assert(!np_capture_anchor_usb_request(&pcd,&setup));
    np_capture_anchor_invalidate();assert(!NP_CaptureAnchor_GetMs(&before,&after));
    np_capture_anchor_arm();start_result=HAL_ERROR;
    assert(np_capture_anchor_start_root(&root,0)==HAL_ERROR);
    assert(!(np_capture_anchor.flags&NP_ANCHOR_ROOT_VALID));
    assert(np_capture_anchor.generation==2U);
    np_capture_anchor.generation=UINT32_MAX;np_capture_anchor_arm();assert(np_capture_anchor.generation==1U);
    dwt_regs.CTRL|=DWT_CTRL_NOCYCCNT_Msk;
    start_result=HAL_OK;assert(np_capture_anchor_start_root(&root,0)==HAL_OK);
    assert(!(np_capture_anchor.flags&NP_ANCHOR_CYCLES_VALID));
    start_result=HAL_OK;irq=1U;assert(np_capture_anchor_start_root(&root,0)==HAL_OK && irq==1U);
    test_origin();
    test_admission();
    test_legacy_not_reprimed();
    test_fresh_clock();
    puts("PASS actual V1 startup/origin/SD compatibility + fresh DWT wire, wrap, epoch, clock, busy and debug rejection");
    return 0;
}
