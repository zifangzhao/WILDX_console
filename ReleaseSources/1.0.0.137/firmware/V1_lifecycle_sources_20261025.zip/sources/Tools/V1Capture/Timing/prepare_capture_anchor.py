"""Add only the one-shot anchor to the checked USB APP translation unit."""
import argparse
import hashlib
import json
from pathlib import Path


def once(text, before, after):
    if text.count(before) != 1:
        raise ValueError('Changed USB startup source anchor: ' + before[:70])
    return text.replace(before, after)


def prepare(text, root):
    text = once(text, '#include <string.h>', '#include <string.h>\n#include "' +
                (root / 'Firmware/V1/Core/Src/np_capture_anchor_port.inc').as_posix() + '"')
    old = 'HAL_TIM_Base_Start(capture_port->htim)'
    if text.count(old) != 3:
        raise ValueError('Expected three mutually exclusive root-start sites')
    text = text.replace(old, 'np_capture_anchor_start_root(capture_port->htim,0)', 2)
    text = text.replace(old, 'np_capture_anchor_start_root(capture_port->htim,NP_CaptureAnchor_Prearmed())')
    text = once(text, '    xe_np_capture_shutdown_reason = 0U;\n    XE_NP_App_StopCaptureDma();',
                '    xe_np_capture_shutdown_reason = 0U;\n    XE_NP_App_StopCaptureDma();\n    np_capture_anchor_arm();')
    text = once(text, '            xe_np_capture_validation_enabled =\n',
                '            #include "' + (root / 'Firmware/V1/Core/Src/np_capture_admit.inc').as_posix() + '"\n'
                '            xe_np_capture_validation_enabled =\n')
    return once(text, '    xe_np_usb_capture_port_index = port_index;\n    xe_np_usb_capture_requested = 1U;',
                '    xe_np_usb_capture_port_index = port_index;\n'
                '    if(!xe_np_usb_capture_requested)np_capture_anchor_invalidate();\n'
                '    xe_np_usb_capture_requested = 1U;')


def prepare_producer(text, root):
    # The checked USB producer has different geometry from the maintained APP.
    # Overlay its existing file locally; never rewrite a verified build input.
    port = (root / 'Firmware/V1/Core/Src/np_capture_origin_producer.inc').as_posix()
    adapter = '''#ifdef NP_CAPTURE_ANCHOR_ENABLED
#define NP_ANCHOR_RING() (xe_np_runtime.capture.raw_storage_bytes/(NP_USB20_PAIRED()?24U:12U))
#define NP_ANCHOR_FIRST_BYTES() (XE_NP_APP_GPIOE_QUAD_DMA_INTERLEAVE_BLOCK_BYTES*XE_NP_APP_GPIOE_DUAL_DMA_INTERLEAVE_REPEAT_COUNT)
#define NP_ANCHOR_MASK() NP_PRODUCER_MASK()
#define NP_ANCHOR_WIDTH(i) (NP_USB20_PAIRED()?2U:1U)
#define NP_ANCHOR_OFFSET(i) (xe_np_quad_dma_initial_offsets[NP_USB20_PAIRED()?((i)&3U):(i)]/NP_ANCHOR_WIDTH(i))
#define NP_ANCHOR_BASE(i,n) (xe_np_runtime.capture.raw_storage+(NP_USB20_PAIRED()?((i)&3U)*2U*(n):(i)*(n)))
#include "''' + port + '''"
#endif
'''
    text = once(text, 'static int np3_fail(uint32_t fault)', adapter + 'static int np3_fail(uint32_t fault)')
    return once(text, '        np3_valid=1;',
                '        np_capture_origin_selected(n,first,common);\n        np3_valid=1;')


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('output', type=Path)
    args = p.parse_args()
    root = Path(__file__).resolve().parents[3]
    seed = root / '_artifacts/v1_usb30k_recheck_20261020/candidate_r1'
    source = seed / 'xe_np_app.c'
    receipt = json.loads((seed / 'build.json').read_text())
    if hashlib.sha256(source.read_bytes()).hexdigest().upper() != receipt['source_sha256'].upper():
        raise ValueError('Checked input source identity changed')
    if args.output.exists():
        raise ValueError('Fresh output required')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(prepare(source.read_text(), root), encoding='utf-8', newline='\n')
    producer = root / '_artifacts/v1_usb_integrity_20261016/paired_restore/source/Core/Src/np3_producer.inc'
    args.output.with_name('np3_producer.inc').write_text(
        prepare_producer(producer.read_text(), root), encoding='utf-8', newline='\n')
