#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define DMA_FLAG_TC 1U
#define DMA_FLAG_DTE 2U
#define DMA_FLAG_ULE 4U
#define DMA_FLAG_USE 8U
#define DMA_FLAG_TO 16U
#define XE_NP_APP_GPIOE_QUAD_DMA_INTERLEAVE_USB_GUARD_BYTES 4096U
#define N 63360U
typedef struct {uint32_t CSR,CDAR;} DMA_Channel_TypeDef;
typedef struct {struct {DMA_Channel_TypeDef *Instance;} hdma;} Lane;
typedef struct {const uint8_t *source[4][2];uint16_t source_bytes[4][2],payload_bytes_per_lane;
                uint8_t source_segment_count[4];} XE_NP_AppUsbQuadDmaBatch;
static struct {struct {uint8_t *raw_storage;uint32_t raw_storage_bytes;} capture;} xe_np_runtime;
static Lane xe_np_quad_dma_lanes[4],xe_np_fullport_quad_dma_gpioe_high_lanes[4],xe_np_fullport_quad_dma_gpiod_high_lanes[4];
static uint32_t xe_np_quad_dma_initial_offsets[12],xe_np_quad_usb_word_diag[8],tick;
static unsigned xe_np_quad_dma_active=1,np_mode_mask=3,np_mode_hz=20000;
#define NP_USB20_PAIRED() (np_mode_hz==20000U && np_mode_mask==3U)
static uint32_t HAL_GetTick(void){return tick;}
#include <np3_producer.inc>
static DMA_Channel_TypeDef regs[4];
static void heads(unsigned logical){
    for(unsigned i=0;i<4;i++)regs[i].CDAR=0x200d0000U+i*N+
        ((logical+xe_np_quad_dma_initial_offsets[i]/2U)%(N/2U))*2U;
}
static void setup(unsigned logical){
    xe_np_runtime.capture.raw_storage=(uint8_t *)0x200d0000U;
    xe_np_runtime.capture.raw_storage_bytes=12U*N;tick=0;
    for(unsigned i=0;i<4;i++){
        xe_np_quad_dma_lanes[i].hdma.Instance=&regs[i];
        xe_np_quad_dma_initial_offsets[i]=i*N/12U;regs[i].CSR=DMA_FLAG_TC;
        /* The P2 DMA handles are deliberately NULL: no duplicate GPIO read. */
    }
    heads(logical);np3_reset();
}
#include <np_direct_packets.h>
static __declspec(align(32)) uint16_t samples[4][N/2];
static __declspec(align(32)) uint8_t packet[NP_DIRECT_WIRE_BYTES];
static unsigned selected;
#if defined(PAIRED_RAW)
static int copy_pair(void *c,const uint8_t *s,uint8_t *d,uint32_t n){
    (void)c;assert(!(((uintptr_t)s | (uintptr_t)d | n)&3U));
    memcpy(d,s,n);return 0;
}
#endif
static int emulate(void *c,const uint8_t *s,uint8_t *d,uint32_t n){
    (void)c;
    assert(!((uintptr_t)s&3U) && !(n&1U));
    for(unsigned i=0;i<n;i+=2){
        uint32_t raw=(uint32_t)s[i*2U]|((uint32_t)s[i*2U+1]<<8)|
            ((uint32_t)s[i*2U+2]<<16)|((uint32_t)s[i*2U+3]<<24);
        uint32_t sbx=(raw&0xff0000ffU)|((raw&0x0000ff00U)<<8)|((raw&0x00ff0000U)>>8);
        uint16_t out=(uint16_t)(sbx>>(selected*16U));
        d[i]=(uint8_t)out;d[i+1]=(uint8_t)(out>>8);
    }
    return 0;
}
int main(void){
#if defined(PAIRED_RAW)
    XE_NP_AppUsbQuadDmaBatch a;
    unsigned payload=NP_DIRECT_GROUPS*252U,need=payload+2048;
    setup(need);regs[0].CSR=0;assert(!XE_NP_App_BeginUsbQuadDmaBatch(payload,&a));
    setup(need);assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(NP_Triple_Probe()==1 && XE_NP_App_CommitUsbQuadDmaBatch(&a)==0);
    assert(!XE_NP_App_BeginUsbQuadDmaBatch(payload,&a));
    tick=2;heads(need+payload);assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(NP_Triple_Probe()==1 && XE_NP_App_CommitUsbQuadDmaBatch(&a)==0);
    for(unsigned l=0;l<4;l++)for(unsigned i=0;i<N/2;i++)samples[l][i]=(uint16_t)(i+l*199U);
    unsigned offsets[]={0,2,504,N/2-2,N/2-504,N/2-payload};
    for(unsigned k=0;k<6;k++){
        const uint8_t *src[4][2];uint16_t sizes[4][2];uint8_t counts[4];uint32_t nodes;
        for(unsigned l=0;l<4;l++){
            unsigned start=(offsets[k]+l*504U)%(N/2),first=N/2-start;
            if(first>payload)first=payload;
            src[l][0]=(uint8_t *)(samples[l]+start);src[l][1]=(uint8_t *)samples[l];
            sizes[l][0]=(uint16_t)first;sizes[l][1]=(uint16_t)(payload-first);counts[l]=first<payload?2:1;
        }
        memset(packet,0xa5,sizeof(packet));
        assert(!NpDirectVisitFormat(src,sizes,counts,packet,sizeof(packet),copy_pair,0,&nodes,2,1));
        for(unsigned g=0;g<NP_DIRECT_GROUPS;g++)for(unsigned l=0;l<4;l++){
            unsigned start=(offsets[k]+l*504U)%(N/2),at=(g*4+l)*512U;
            for(unsigned h=0;h<8;h++)assert(packet[at+h]==0xa5);
            for(unsigned i=0;i<252;i++){
                uint16_t value=samples[l][(start+g*252U+i)%(N/2)];
                assert(packet[at+8+i*2U]==(uint8_t)value && packet[at+9+i*2U]==(uint8_t)(value>>8));
            }
        }
        src[3][0]+=2;memset(packet,0xa5,sizeof(packet));
        assert(NpDirectVisitFormat(src,sizes,counts,packet,sizeof(packet),copy_pair,0,&nodes,2,1)<0 && !nodes);
        for(unsigned i=0;i<sizeof(packet);i++)assert(packet[i]==0xa5);
    }
    puts("PASS paired raw producer/planner: single retirement of both samples; word alignment, ring wrap, exact low/high bytes, 8-byte headers untouched");
#else
    XE_NP_AppUsbQuadDmaBatch a,b;unsigned payload=NP_DIRECT_LANE_BYTES,need=payload+2048;
    setup(need);regs[0].CSR=0;assert(!XE_NP_App_BeginUsbQuadDmaBatch(payload,&a));
    setup(need);assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(NP_Triple_Probe()==1 && XE_NP_App_CommitUsbQuadDmaBatch(&a)==0);
    assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&b)==1 && NP_Triple_Probe()==2);
    for(unsigned l=0;l<4;l++)assert(a.source[l][0]==b.source[l][0]);
    assert(XE_NP_App_CommitUsbQuadDmaBatch(&b)==0);
    assert(!XE_NP_App_BeginUsbQuadDmaBatch(payload,&a));
    tick=3;heads(need+payload);assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(XE_NP_App_CommitUsbQuadDmaBatch(&a)==0);
    assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&b)==1);
    assert(XE_NP_App_CommitUsbQuadDmaBatch(&b)==0);
    tick+=10;assert(XE_NP_App_CheckUsbQuadDmaRetention()<0 && np3_diag[1]==10);
    setup(need);regs[2].CSR|=DMA_FLAG_DTE;
    assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)<0 && np3_diag[1]==11);
    for(unsigned l=0;l<4;l++)for(unsigned i=0;i<N/2;i++)
        samples[l][i]=(uint16_t)((uint8_t)(i+l*17U) | ((uint16_t)(uint8_t)(i*3U+l*29U)<<8));
    unsigned offsets[]={0,2,506,N/2-2,N/2-506,N/2-payload};
    for(unsigned k=0;k<6;k++)for(selected=0;selected<2;selected++){
        const uint8_t *src[4][2];uint16_t sizes[4][2];uint8_t counts[4];uint32_t nodes;
        for(unsigned l=0;l<4;l++){
            unsigned start=(offsets[k]+l*506U)%(N/2),first=N/2-start;
            if(first>payload)first=payload;
            src[l][0]=(uint8_t *)(samples[l]+start);src[l][1]=(uint8_t *)samples[l];
            sizes[l][0]=(uint16_t)first;sizes[l][1]=(uint16_t)(payload-first);counts[l]=first<payload?2:1;
        }
        memset(packet,0xa5,sizeof(packet));
        assert(!NpDirectVisitStride(src,sizes,counts,packet,sizeof(packet),emulate,0,&nodes,2));
        for(unsigned g=0;g<NP_DIRECT_GROUPS;g++)for(unsigned l=0;l<4;l++){
            unsigned start=(offsets[k]+l*506U)%(N/2),at=(g*4+l)*512U;
            for(unsigned h=0;h<6;h++)assert(packet[at+h]==0xa5);
            for(unsigned i=0;i<506;i++)assert(packet[at+6+i]==
                (uint8_t)(samples[l][(start+g*506U+i)%(N/2)]>>(selected*8U)));
        }
    }
    puts("PASS real paired producer/planner: shared DMA ownership, both probes, wrap, stale history, overrun/fault rejection and exact tagged payload/header preservation");
#endif
}
