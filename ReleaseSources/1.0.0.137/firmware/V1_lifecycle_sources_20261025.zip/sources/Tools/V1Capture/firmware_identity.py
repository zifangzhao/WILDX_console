"""Versioned artifact names; UTC timestamps describe builds, not qualification."""
from datetime import datetime, timezone
from pathlib import Path
import re

VERSION_FILE = Path(__file__).with_name('FIRMWARE_VERSION')


def identity(version=None, build_utc=None):
    version = VERSION_FILE.read_text().strip() if version is None else version
    if not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+(?:-[A-Za-z0-9]+(?:[.-][A-Za-z0-9]+)*)?', version):
        raise ValueError('Explicit filename-safe firmware version required')
    if build_utc is None:
        build_utc = datetime.now(timezone.utc)
    if isinstance(build_utc, str):
        build_utc = datetime.strptime(build_utc, '%Y%m%dT%H%M%SZ').replace(tzinfo=timezone.utc)
    if build_utc.tzinfo is None:
        raise ValueError('Timezone-aware build timestamp required')
    stamp = build_utc.astimezone(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    return version, stamp


def artifact_name(role, suffix, version=None, build_utc=None):
    if not re.fullmatch(r'V1_[A-Za-z0-9_]+', role) or suffix not in ('.bin', '.hex', '.xenp', '.json'):
        raise ValueError('Unsupported V1 artifact role or suffix')
    version, stamp = identity(version, build_utc)
    return f'{role}_v{version}_{stamp}{suffix}'
