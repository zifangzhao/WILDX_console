"""Exercise the actual V1 CE32 recording backend's pending-START cancellation.

Only unrelated configuration/storage boundaries are stubbed. No device access.
Run: python test_ce32_pending_stop.py REPO OUTPUT_DIRECTORY
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess


def function(text, name):
    match = re.search(r'^(?:static )?int\s+' + re.escape(name) +
                      r'\([^;{}]*\)\s*\{', text, re.M)
    if match is None:
        raise ValueError('Missing production function: ' + name)
    depth, end = 1, match.end()
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[match.start():end]


UNIT = r'''#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define HAL_RTC_MODULE_ENABLED 1
typedef struct {uint8_t WeekDay,Month,Date,Year;} RTC_DateTypeDef;
typedef struct {uint8_t Hours,Minutes,Seconds,TimeFormat;uint32_t SubSeconds,SecondFraction,DayLightSaving,StoreOperation;} RTC_TimeTypeDef;
#include "ce32_wire.h"
#include "np_sd_control.h"
#include "np_sd_log.h"
#define NP_SD_STORE_V2 0
#define NP_CE64_CONTAINER_TAG 0x4e500000U
#define NP_CAMERA_SENSOR_MAX_HZ 50U
#define NP_MIC_HZ 200000U
#define __DMB() ((void)0)
typedef struct {struct {uint32_t LogBlockNbr;} SdCard;} TestCard;
static TestCard card={{1000000U}};
static struct {CE32_systemParam sys_param;TestCard *hsd_card;} xe_np_runtime;
volatile uint32_t np_mode_mask=3U,np_mode_hz=20000U;
static struct {unsigned state;} np_sd_log;
static struct {unsigned enabled;} np_sd_camera;
static struct {unsigned active,waiting;} npl_schedule;
static struct {uint32_t command,inverse;} np_sd_mailbox;
static struct {uint32_t command;} np_sd_readback;
static struct {unsigned state;} np_ce64_diag;
static struct {unsigned block;uint32_t start;} np_ce64_dir;
static unsigned npl_mode_target,npl_ce32_start_receipt,npl_ce32_stop_receipt;
static unsigned npl_delete_phase;
static unsigned xe_np_sd_init_failed;
static uint32_t SystemCoreClock=187200000U;
static const char *npl_ce32_start_error;
static int npl_delete_blocks(uint8_t c){(void)c;return 0;}
static int npl_idle(void){return 1;}
static int npl_same_gpio_high_rate(uint32_t m,uint32_t h){(void)m;(void)h;return 1;}
static int npl_select(uint32_t m,uint32_t h){(void)m;(void)h;return 1;}
static uint32_t NP_SD_RateCoreHz(void){return SystemCoreClock;}
static uint32_t HAL_GetTick(void){return 123U;}
static int npl_apply(void *context,const uint32_t *w){
    (void)context;
    if(w[2]!=NPL_START)return NPL_RANGE;
    np_sd_mailbox.inverse=~0x53544152U;np_sd_mailbox.command=0x53544152U;
    return NPL_OK;
}
static void np_media_save_settings(void){}
static int NP_CE64_ReadLogBlock(uint16_t b){(void)b;return 0;}
static int NP_CE64_DeleteAllowed(void){return 1;}
static int NP_ConfigTransferPending(void){return 0;}
int NP_SD_ControlTransferPending(void){return 0;}
#include "actual_backend.inc"
static unsigned checks;
#define CHECK(x) do {checks++;if(!(x)){printf("FAIL line %u: %s\n",__LINE__,#x);return 1;}}while(0)
int main(void)
{
    const uint8_t stop[]={0x31U},wrong[]={0x30U},long_stop[]={0x31U,0U};
    const uint32_t commands[]={0U,0x53544152U,0x4D4F554EU,0x464D4154U};
    for(unsigned state=NP_SD_IDLE;state<=NP_SD_FAILED;state++){
        for(unsigned c=0;c<sizeof(commands)/sizeof(commands[0]);c++){
            np_sd_log.state=state;np_sd_mailbox.command=commands[c];
            np_sd_mailbox.inverse=~commands[c];
            npl_schedule.active=npl_schedule.waiting=1U;
            npl_ce32_start_receipt=1U;npl_ce32_stop_receipt=0U;
            CHECK(!NP_SD_Ce32RecordingCommandBackend(0x31U,stop,sizeof(stop)));
            CHECK(!npl_schedule.active&&!npl_schedule.waiting);
            CHECK(!npl_ce32_start_receipt&&npl_ce32_stop_receipt);
            if(state==NP_SD_RUNNING||state==NP_SD_DRAINING||commands[c]==0x53544152U){
                CHECK(np_sd_mailbox.command==0x53544F50U);
                CHECK(np_sd_mailbox.inverse==~0x53544F50U);
            }else CHECK(np_sd_mailbox.command==commands[c]);
            /* Repeated STOP cannot recreate START or its confirmation. */
            CHECK(!NP_SD_Ce32RecordingCommandBackend(0x31U,stop,sizeof(stop)));
            CHECK(np_sd_mailbox.command!=0x53544152U&&!npl_ce32_start_receipt);
        }
    }
    np_sd_mailbox.command=0x53544152U;np_sd_mailbox.inverse=~np_sd_mailbox.command;
    npl_ce32_start_receipt=1U;npl_ce32_stop_receipt=0U;
    npl_schedule.active=npl_schedule.waiting=1U;
    CHECK(NP_SD_Ce32RecordingCommandBackend(0x31U,NULL,1U)<0);
    CHECK(NP_SD_Ce32RecordingCommandBackend(0x31U,stop,0U)<0);
    CHECK(NP_SD_Ce32RecordingCommandBackend(0x31U,wrong,sizeof(wrong))<0);
    CHECK(NP_SD_Ce32RecordingCommandBackend(0x31U,long_stop,sizeof(long_stop))<0);
    CHECK(np_sd_mailbox.command==0x53544152U&&npl_ce32_start_receipt&&!npl_ce32_stop_receipt);
    CHECK(npl_schedule.active&&npl_schedule.waiting);
    /* Async START is still idle while camera DMA retires. Stop removes it;
     * after the foreground STOP retires, a deliberate new START is admitted. */
    xe_np_runtime.hsd_card=&card;np_ce64_dir.start=8192U;np_ce64_diag.state=1U;
    np_sd_log.state=NP_SD_IDLE;
    CHECK(!NP_SD_Ce32RecordingCommandBackend(0x31U,stop,sizeof(stop)));
    CHECK(np_sd_mailbox.command==0x53544F50U&&!npl_ce32_start_receipt);
    np_sd_mailbox.command=0U; /* foreground STOP consumed, no START remains */
    CHECK(!NP_SD_Ce32RecordingCommandBackend(0x30U,wrong,sizeof(wrong)));
    CHECK(np_sd_mailbox.command==0x53544152U&&npl_ce32_start_receipt);
    printf("PASS %u actual CE32 backend pending-START/STOP checks; no hardware\n",checks);
    return 0;
}
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    root, out = args.root.resolve(), args.output.resolve()
    source = root / 'Firmware/V1/Core/Src/np_sd_control.inc'
    backend = '\n\n'.join(function(source.read_text(), name) for name in
                          ('npl_ce32_start', 'NP_SD_Ce32RecordingCommandBackend'))
    out.mkdir(parents=True, exist_ok=False)
    (out / 'actual_backend.inc').write_text(backend + '\n')
    test = out / 'test.c'
    test.write_text(UNIT)
    vc = Path('C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars64.bat')
    command = (f'call "{vc}" >nul && cl /nologo /std:c11 /O2 /W3 /WX /TC '
               f'/I"{root}/Firmware/V1/Core/Inc" "{test}" '
               f'/Fo"{out}/test.obj" /Fe"{out}/test.exe"')
    built = subprocess.run(command, shell=True, capture_output=True, text=True)
    print(built.stdout + built.stderr, end='')
    run = None if built.returncode else subprocess.run([str(out / 'test.exe')], capture_output=True, text=True)
    output = built.stdout + built.stderr
    if run is not None:
        output += run.stdout + run.stderr
        print(run.stdout + run.stderr, end='')
    result = dict(source=str(source), source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                  actual_backend_sha256=hashlib.sha256(backend.encode()).hexdigest(),
                  compile_exit=built.returncode, test_exit=None if run is None else run.returncode,
                  hardware_access=False)
    (out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    (out / 'run.log').write_text(output)
    raise SystemExit(built.returncode if run is None else run.returncode)


if __name__ == '__main__':
    main()
