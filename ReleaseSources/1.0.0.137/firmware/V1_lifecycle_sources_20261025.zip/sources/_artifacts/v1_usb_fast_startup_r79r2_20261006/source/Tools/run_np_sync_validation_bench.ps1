param(
    [string]$OutputDirectory = "",
    [int]$Seconds = 3,
    [int]$PortIndex = 0,
    [int]$ActiveProbeMask = 0,
    # The calibrated NP1 fallback samples on the rising PA0 PSB edge with a
    # seven-timer-tick aperture.  Keeping the command-line defaults aligned
    # with xe_np_app.c is essential: an omitted option must not silently turn
    # a known-clean 7.5 kHz build into the falling-edge/4-tick experiment.
    [int]$TimingCandidate = 1,
    [int]$DelayTicks = 7,
    [bool]$SkipChain2 = $true,
    [int]$EnumerateTimeoutSeconds = 30,
    [int]$EnumeratePollSeconds = 1,
    [switch]$EnableHalfBoundaryProbe,
    [switch]$EnableHalfBoundaryProbeIsrSnapshot,
    [switch]$EnableHalfWindowQueueReserve,
    # One-NP 30 kS/s experiment: place the four GPIO DMA lanes in the
    # dedicated upper SRAM1 capture region rather than SRAM3.
    [switch]$EnableCaptureSram1,
    # Place the capture ring in the independently memory-mapped APS6404 PSRAM
    # after its boot qualification has succeeded.
    [switch]$EnableCapturePsram,
    [int]$CaptureStorageOffsetBytes = 0,
    [switch]$EnableSyncWatchdog,
    [switch]$EnableNp2PsbPullup,
    [switch]$EnableNp2PsbPulldown,
    [switch]$EnablePsbClkPullup,
    [switch]$EnablePsbClkPulldown,
    [switch]$EnableUsbLaneValidator,
    [switch]$EnableUsbSeamProbe,
    [switch]$EnableUsbInternalDma,
    # Make the OTG-HS internal DMA issue single AHB beats rather than the
    # default INCR4 bursts. Intended for 30 kHz GPIO timing qualification.
    [switch]$EnableUsbInternalDmaSingleBurst,
    # Move completed paired DDR lane payloads through a low-priority GPDMA
    # SRAM3-to-SRAM1 staging channel instead of foreground CPU copies.
    [switch]$EnableUsbInterleavedStagingDma,
    # Use GPDMA1 channel 10 for the four-lane recorder's private SRAM3->SRAM1
    # staging work. Channels 12..15 remain capture-only.
    [switch]$EnableUsbQuadStagingDma,
    # OTG-HS reads a completed physical lane range directly, with no CPU or
    # GPDMA staging. The host must use raw-read mode for this bare-lane test.
    [switch]$EnableUsbQuadZeroCopy,
    # Move the four-lane SRAM3->SRAM1 staging work to the separate LPDMA
    # controller; a direct test of cross-controller isolation.
    [switch]$EnableUsbQuadLpdmaStaging,
    # Deliberately raise only the SRAM3-to-SRAM1 staging channel to the same
    # arbitration priority as GPIO capture.  This is a diagnostic experiment:
    # it distinguishes an idle/never-serviced low-priority exporter from one
    # that competes destructively with the two capture lanes.
    [switch]$EnableUsbInterleavedStagingHighPriority,
    # Keep the completed SRAM3 capture ranges cacheable.  The exporter
    # explicitly invalidates each range before it reads it; this avoids a
    # byte-by-byte CPU/SRAM3 arbitration stream at 30 kHz.
    [switch]$EnableUsbCaptureSram3Cacheable,
    [switch]$EnableDmaDirectRepeat,
    [switch]$EnableDmaSelfLink,
    [switch]$EnableDmaSingle2dCircular,
    [switch]$EnableDmaDarOnlyCircular,
    # Two alternating GPIO lanes, each using the minimal CDAR-only circular
    # reload. This is the 30 kS/s hardware-only qualification topology.
    [switch]$EnableDmaDualDarOnlyCircular,
    # Validated production-style topology for one NP1/NP2 GPIO lane at
    # 15 kS/s: GPDMA circular reloads CDAR only, while USB copies completed
    # half-rings into its private SRAM1 endpoint buffers.
    [switch]$EnableUsb15kDarOnly,
    # Diagnostic placement only: keep the OTG-HS DMA endpoint buffers in the
    # separate 64 KiB SRAM2 bank, rather than the upper half of SRAM1.  The
    # capture ring remains exclusively in SRAM3 in either case.
    [switch]$UsbDmaSram2,
    [switch]$EnableDmaDynamicQueue,
    [switch]$EnableDmaDualInterleave,
    [switch]$EnableDmaDualInterleavePublish,
    [switch]$EnableDmaDualInterleaveStorage,
    # Use the full two-ring capture geometry without an SD recorder or a
    # WinUSB transfer. Intended for SWD-only stability validation.
    [switch]$EnableDmaDualInterleaveIsolatedStorage,
    # Capture both phases of every 15 kHz PSB cell (CC2 and CC3) to diagnose
    # a narrow data-valid eye; intended for SWD frozen-buffer analysis.
    [switch]$EnableDmaDualPhaseProbe,
    [int]$DdrPhaseADelayTicks = 4,
    [int]$DdrPhaseBDelayTicks = 12,
    # Split full-rate GPIO capture across TIM8 CH1/CH2/CH3/update and four
    # GPDMA lanes. This is SWD-only until its frozen raw ring validates.
    [switch]$EnableDmaQuadInterleaveIsolated,
    # One-NP only: alternate complete four-lane epochs so the exporter can
    # consume an inactive epoch rather than a guarded live cursor.
    [switch]$EnableDmaQuadPingPong,
    # Three-lane variant: TIM8 CH1/CH2/update route consecutive samples to
    # GPDMA 12/13/14. It reduces per-lane request pressure without CH3.
    [switch]$EnableDmaTripleInterleaveIsolated,
    # Build the 15 kHz paired-lane image for WinUSB recording only.  This keeps
    # SDMMC completely out of the capture session, including before enumeration.
    [switch]$EnableUsbStreamOnly,
    # Full-rate 30 kHz recorder: TIM8 CH1..CH4 feed four independent GPIO DMA
    # lanes.  USB receives only guarded private copies, never the SRAM3 rings.
    [switch]$EnableUsbQuadStreamOnly,
    # Full three-probe capture-load qualification: four timer phases capture
    # each wired GPIO byte independently (twelve GPDMA lanes).  This preserves
    # the byte timing used by the single-probe DDR capture.
    # This is deliberately SWD/frozen only; it has no SRAM3 consumer.
    [switch]$EnableDmaFullPortQuadInterleaveIsolated,
    # Use GPDMA channels 0..3 and one circular linear node per capture lane.
    # This is the low-latency alternative to the 2D-capable channels 12..15.
    [switch]$EnableDmaQuadLinearChannels,
    # V1 capture-only qualification: one CDAR word per circular lane reload.
    [switch]$EnableDmaQuadDarOnly,
    [switch]$EnableDmaQuadStagger,
    [switch]$EnableDmaQuadQuiet,
    [switch]$EnableQuadDescriptorSram2,
    [switch]$EnableQuadPackedWords,
    [switch]$EnableQuadCpuGuard,
    [switch]$QuadCpuGuardNegative,
    [switch]$NoProbeDryRun,
    [switch]$EnableQuadUsbWordExport,
    [switch]$EnableQuadUsbPaced,
    [ValidateRange(0,3)][int]$QuadChannelRotation = 0,
    # Timer-gated four-lane SRAM3->SRAM1 shadow: each low-priority copy shares
    # its capture lane's TIM8 event and never free-runs between samples.
    [switch]$EnableDmaQuadTimedShadow,
    # USB-only validation of the normal single GPIO-DMA topology.  Unlike
    # EnableUsbStreamOnly this does not enable the paired-lane interleaver;
    # combine it with EnableDmaDirectRepeat to exercise the no-reload path.
    [switch]$EnableUsbSingleDirect,
    # Enumeration-only A/B diagnostic: leave OTG HS internal DMA disabled so
    # control replies are written through the CPU FIFO. Not a capture build.
    [switch]$EnableUsbCpuFifoTest,
    # Exercise only the WinUSB bulk-IN transport with generated packets.  This
    # separates endpoint/controller faults from the GPIO capture producer.
    [switch]$EnableUsbSyntheticTest,
    # Assert only the Neuropixels VCC rail during a synthetic USB stream.
    # Hardware-isolation diagnostic; no probe or capture is started.
    [switch]$EnableUsbSyntheticNpVccTest,
    # Assert VCC plus both NP resets during synthetic USB. This isolates the
    # probe data-output activation from DMA and I2C programming.
    [switch]$EnableUsbSyntheticNpResetReleaseTest,
    # Keep the real GPIO/DMA session armed, while sending generated packets.
    # This isolates USB controller contention from paired-ring export logic.
    [switch]$EnableUsbRealCaptureSyntheticPayload,
    # Detach the app capture-port from a real-session synthetic endpoint test.
    [switch]$EnableUsbRealCaptureSyntheticDetachPort,
    # After real NP bring-up, restart the endpoint through the exact
    # synthetic lifecycle. USB isolation diagnostic only.
    [switch]$EnableUsbRealCaptureRestartSynthetic,
    # Omit app capture-window retirement from USB IN completion. Endpoint
    # isolation only; never a recording mode.
    [switch]$EnableUsbRealCaptureSkipRelease,
    # Keep the real exporter lifecycle but overwrite completed TX payloads
    # with the synthetic pattern. Endpoint cache isolation only.
    [switch]$EnableUsbRealExportSyntheticPacket,
    # Set paired GPIO-DMA arbitration to low/high-weight while preserving its
    # timer request schedule; diagnostic for USB-master coexistence.
    [switch]$EnableCaptureDmaLowPriority,
    # Keep the full NP power/reset/MCLK bring-up but do not arm GPDMA. This is
    # solely a USB coexistence isolation control.
    [switch]$EnableCaptureSuppressDma,
    # Bypass NRIC I2C ping/programming in a disposable hardware-isolation
    # image; use only with synthetic USB payloads.
    [switch]$EnableSkipNricConfig,
    [switch]$EnableDmaDualInterleaveDelayedPwm2,
    # Number of 180-byte PSB blocks represented by each paired-lane 2D node.
    # 256 provides frequent publish events; 2048 creates one full-ring node
    # for verifying that descriptor transitions are not the source of errors.
    [int]$DmaDualInterleaveRepeatCount = 256,
    [int]$RawSdBlocksPerWrite = 64,
    # Characterization only: arm the raw SD sink even when the card has not
    # passed the production UHS throughput gate.
    [switch]$EnableUnqualifiedSdRaw,
    # Characterization only: permit SD writes while the idle USB device is
    # enumerated, so SDMMC traffic can be measured over SWD without USB Start.
    [switch]$EnableSdSinkWhileUsbIdle,
    # Characterization only: run the SDMMC writer even if online paired-lane
    # qualification is not available; this produces a transport stress result,
    # never a valid recording result.
    [switch]$EnableUnqualifiedSdCaptureLock,
    # Enable SDMMC host initialization for an autonomous raw-SD stress image.
    # The bench default deliberately keeps SDMMC disabled for USB isolation.
    [switch]$EnableSdTransportDiagnostic,
    # Issue sustained SDMMC IDMA writes from a private SRAM1 buffer while the
    # paired capture lanes run.  This is an arbitration experiment, not a
    # recorder: it never reads the live capture rings.
    [switch]$EnableSdStressWriter,
    # Run the board's custom no-CMD12 SDMMC IDMA linked-list benchmark at
    # boot.  This is a transport-ceiling test, not a recording image.
    [switch]$EnableSdLinkedListBench,
    # Number of circular node-pair iterations per linked-list SD command.
    # One exercises a recorder-sized 127 KiB command; the default 258
    # measures the transport ceiling with a 32 MiB command.
    [int]$SdLinkedListTransferCycles = 258,
    # Blocks per IDMA descriptor; 120 is the 61,440-byte GPIO DMA node size
    # used by the retargeting recorder candidate.
    [int]$SdLinkedListNodeBlocks = 127,
    # Compare the normal HAL DATAEND/CMD12 completion path with the custom
    # CMD23-bounded no-CMD12 recorder candidate.
    [switch]$DisableSdLinkedListNoCmd12,
    # Place the benchmark source buffer in the same SRAM3 bank as the GPIO
    # rings.  This isolates SDMMC IDMA source accessibility from recorder
    # scheduling without reading a live capture buffer.
    [switch]$EnableSdLinkedListBenchSourceSram3,
    # Write four distinct patterns through a circular IDMA list, retarget both
    # descriptors after their first completion, then read the sectors back.
    # This qualifies the recorder's descriptor reload mechanism, not speed.
    [switch]$EnableSdLinkedListRetargetIntegrityTest,
    # Replace the raw-SD sink's CPU memcpy from the live SRAM3 lane with a
    # low-priority Channel 14 SRAM3-to-SRAM1 DMA stage.  The SDMMC IDMA then
    # owns only the private SRAM1 snapshot.
    [switch]$EnableRawSdDmaStaging,
    # Experimental direct recorder: SDMMC IDMA reads guarded SRAM3 raw-ring
    # spans through a retargetable two-node linked list.
    [switch]$EnableRawSdLinkedStream,
    # Use four 61,440-byte circular IDMA nodes and replace each completed
    # descriptor once. This produces one chronological 480 KiB SD batch from
    # a single physical GPIO ring without a SRAM1 staging copy.
    [switch]$EnableRawSdLinkedRetarget,
    [switch]$EnableMinimalDmaIrqDispatch,
    [int]$DmaLinkAllocatedPort = 1,
    # Source GPIO remains on GPDMA port 0. Select the master port used for
    # the capture-memory write; 1 is the qualified SRAM3 default.
    [ValidateSet(0, 1)]
    [int]$CaptureDmaDestPort = 1,
    [int]$DmaDestBurstLength = 1,
    # Absolute RCC MCO prescaler, not a divisor relative to the board default.
    # This board's normal 93.6 MHz Neuropixels MCLK is PLL1R (187.2 MHz) / 2;
    # use 4 for 46.8 MHz (15 kS/s) and 8 for 23.4 MHz (7.5 kS/s).
    [int]$NeuropixelsMcoDivider = 0,
    [uint32]$NeuropixelsExpectedMclkHz = 0,
    # Exact 20 kS/s profile: PLL1R/HCLK 124.8 MHz, MCO /2 = 62.4 MHz.
    [switch]$EnableCore1248Mhz,
    # Extreme SWD-recoverable timing experiment: HCLK 249.6 MHz, MCO /4 =
    # 62.4 MHz. This is far outside the MCU data-sheet clock limit.
    [switch]$EnableCore2496Mhz,
    # Bracket the out-of-spec core limit. PLL1R/HCLK is 2.4 MHz times N;
    # MCO /4 yields an NP MCLK of 0.6 MHz times N.
    [ValidateRange(0, 104)]
    [int]$ExperimentalCorePll1N = 0,
    [string]$NeuropixelsMcoGpioSpeed = "",
    [switch]$EnablePsbHalfRate,
    # Read the complete, aligned GPIOE IDR halfword for NP2 instead of the
    # normal high-byte lane. SWD-only diagnostic for 15 kHz signal timing.
    [switch]$EnableNp2HalfwordCapture,
    [switch]$EnablePsbTim2Etr,
    [switch]$EnableTim2PsbArmedFreerun,
    [switch]$EnableTim2PsbEdgeReset,
    [switch]$DisableCaptureRateMonitor,
    [switch]$EnableKeepSessionOnHostStop,
    [switch]$EnableStableWindowDefer,
    [int]$StableWindowReleaseBytes = 0,
    [int]$UsbWindowChunkBytes = 0,
    # Private USB aggregation for stress/latency characterization.  The
    # default remains the production 63 packets per transfer.
    [int]$UsbPacketsPerTransfer = 63,
    [int]$CaptureDmaNodeBytes = 0,
    [int]$CaptureStorageBytes = 0,
    [switch]$DisableUsbRingHeadroom,
    [switch]$EnableFullNodeWindowPublication,
    [int]$FreezeCaptureAfterMs = 0,
    [switch]$FreezeQuiesceOnly,
    [switch]$BuildOnly,
    [switch]$SwdOnly,
    [switch]$KeepBenchImageFlashed
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
if ($PSVersionTable.PSVersion.Major -ge 7) {
    $PSNativeCommandUseErrorActionPreference = $false
}

$useUsb15kDarOnly = $EnableUsb15kDarOnly.IsPresent
if ($EnableUsbInterleavedStagingDma.IsPresent -and
    -not $PSBoundParameters.ContainsKey('DmaDualInterleaveRepeatCount')) {
    # The paired-lane DMA staging exporter owns the completed physical rings.
    # Keep each ring in one repeated block so GPDMA never has a descriptor
    # boundary in the 30 kHz real-time path.  The shorter 256-repeat geometry
    # is useful for ISR/publication diagnostics, but it is not a transport
    # qualification topology with a compact (184320-byte) test allocation.
    $DmaDualInterleaveRepeatCount = 2048
}
if ($useUsb15kDarOnly) {
    if (($NeuropixelsMcoDivider -ne 0) -and ($NeuropixelsMcoDivider -ne 4)) {
        throw "EnableUsb15kDarOnly requires NeuropixelsMcoDivider 4 (46.8 MHz MCLK)."
    }
    if (($NeuropixelsExpectedMclkHz -ne 0) -and ($NeuropixelsExpectedMclkHz -ne 46800000)) {
        throw "EnableUsb15kDarOnly requires NeuropixelsExpectedMclkHz 46800000."
    }
    if ($SwdOnly.IsPresent) {
        throw "EnableUsb15kDarOnly is a USB recording topology and cannot be combined with SwdOnly."
    }
    $NeuropixelsMcoDivider = 4
    $NeuropixelsExpectedMclkHz = 46800000
    if (-not $PSBoundParameters.ContainsKey('DelayTicks')) {
        # Live USB qualification at the 46.8 MHz / 15 kS/s rate established
        # the first tick after the PA0 rising-edge reset as the wide, clean
        # aperture.  The normal 7.5 kS/s fallback deliberately remains at 7.
        $DelayTicks = 1
    }
    if (-not $PSBoundParameters.ContainsKey('UsbPacketsPerTransfer')) {
        # 16 KiB private USB buffers kept the exporter comfortably inside the
        # 30,720-byte half-ring guard in the qualifying hardware runs.
        $UsbPacketsPerTransfer = 32
    }
}

if ([string]::IsNullOrWhiteSpace($OutputDirectory)) {
    $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $artifactRoot = Join-Path (Split-Path $PSScriptRoot -Parent) "_artifacts"
    $OutputDirectory = Join-Path (Join-Path $artifactRoot "np_sync_validation") ("np_sync_validation_" + $stamp)
}

if ($TimingCandidate -lt 0 -or $TimingCandidate -gt 7) {
    throw "TimingCandidate must be in the range 0..7."
}
if ($ActiveProbeMask -lt 0 -or $ActiveProbeMask -gt 7) {
    throw "ActiveProbeMask must be in the range 0..7."
}
if ($DelayTicks -lt 0 -or $DelayTicks -gt 15) {
    throw "DelayTicks must be in the range 0..15."
}
if ($StableWindowReleaseBytes -lt 0) {
    throw "StableWindowReleaseBytes must be >= 0."
}
if ($UsbWindowChunkBytes -lt 0) {
    throw "UsbWindowChunkBytes must be >= 0."
}
if ($UsbPacketsPerTransfer -lt 1 -or $UsbPacketsPerTransfer -gt 127) {
    throw "UsbPacketsPerTransfer must be in the range 1..127."
}
if ($CaptureDmaNodeBytes -lt 0) {
    throw "CaptureDmaNodeBytes must be >= 0."
}
if ($DdrPhaseADelayTicks -lt 0 -or $DdrPhaseADelayTicks -gt 15 -or
    $DdrPhaseBDelayTicks -lt 0 -or $DdrPhaseBDelayTicks -gt 15) {
    throw "DdrPhaseADelayTicks and DdrPhaseBDelayTicks must be in the range 0..15."
}
if ($CaptureStorageBytes -lt 0) {
    throw "CaptureStorageBytes must be >= 0."
}
if ($CaptureStorageOffsetBytes -lt 0) {
    throw "CaptureStorageOffsetBytes must be >= 0."
}
if ($FreezeCaptureAfterMs -lt 0) {
    throw "FreezeCaptureAfterMs must be >= 0."
}
if ($DmaLinkAllocatedPort -lt 0 -or $DmaLinkAllocatedPort -gt 1) {
    throw "DmaLinkAllocatedPort must be 0 or 1."
}
if ($DmaDestBurstLength -lt 1 -or $DmaDestBurstLength -gt 64) {
    throw "DmaDestBurstLength must be in the range 1..64."
}
if ($RawSdBlocksPerWrite -lt 1 -or $RawSdBlocksPerWrite -gt 128) {
    throw "RawSdBlocksPerWrite must be in the range 1..128."
}
if (($EnableUsbStreamOnly.IsPresent -or $EnableUsbQuadStreamOnly.IsPresent -or $EnableUsbSingleDirect.IsPresent -or $useUsb15kDarOnly) -and
    -not $EnableUsbInternalDma.IsPresent -and -not $useUsb15kDarOnly -and
    -not $EnableUsbCpuFifoTest.IsPresent) {
    throw "USB stream bench modes require EnableUsbInternalDma so USB transfers do not consume endpoint FIFO service on the CPU."
}
if ($EnableUsbSingleDirect.IsPresent -and -not $EnableDmaDirectRepeat.IsPresent) {
    throw "EnableUsbSingleDirect requires EnableDmaDirectRepeat; otherwise this is not the validated no-reload single-DMA topology."
}
if (($NeuropixelsMcoDivider -ne 0) -and @(
        1, 2, 4, 8, 16
    ) -notcontains $NeuropixelsMcoDivider) {
    throw "NeuropixelsMcoDivider must be one of 0, 1, 2, 4, 8, 16."
}
if (($NeuropixelsMcoDivider -gt 0) -and ($NeuropixelsExpectedMclkHz -eq 0)) {
    throw "NeuropixelsExpectedMclkHz must be set when NeuropixelsMcoDivider is used."
}
if ((-not [string]::IsNullOrWhiteSpace($NeuropixelsMcoGpioSpeed)) -and @(
        "LOW", "MEDIUM", "HIGH", "VERY_HIGH"
    ) -notcontains $NeuropixelsMcoGpioSpeed.ToUpperInvariant()) {
    throw "NeuropixelsMcoGpioSpeed must be one of LOW, MEDIUM, HIGH, VERY_HIGH."
}
if ($EnumerateTimeoutSeconds -lt 1) {
    throw "EnumerateTimeoutSeconds must be >= 1."
}
if ($EnumeratePollSeconds -lt 1) {
    throw "EnumeratePollSeconds must be >= 1."
}

$workspace = Split-Path $PSScriptRoot -Parent
$powershellExe = Join-Path $env:WINDIR "System32\WindowsPowerShell\v1.0\powershell.exe"
if (-not [System.IO.Path]::IsPathRooted($OutputDirectory)) {
    $OutputDirectory = Join-Path $workspace $OutputDirectory
}
$OutputDirectory = [System.IO.Path]::GetFullPath($OutputDirectory)
$mdkArm = Join-Path $workspace "MDK-ARM"
$projectDir = Join-Path $mdkArm "USB384_NP_BGA_MMC"
$uv4 = "C:\Keil_v5\UV4\UV4.exe"
$armclang = "C:\Keil_v5\ARM\ARMCLANG\bin\armclang.exe"
$armlink = "C:\Keil_v5\ARM\ARMCLANG\bin\armlink.exe"
$fromelf = "C:\Keil_v5\ARM\ARMCLANG\bin\fromelf.exe"
$stprog = "C:\Program Files\STMicroelectronics\STM32Cube\STM32CubeProgrammer\bin\STM32_Programmer_CLI.exe"
$loggerArtifact = Join-Path $workspace "_artifacts\NPUsbTools\NPUsbLogger.exe"
$loggerBuildOutput = Join-Path $workspace "Tools\NPUsbLogger\bin\Release\net8.0-windows\NPUsbLogger.exe"
# Prefer the project output when it exists.  The archived artifact is useful
# for a clean checkout but otherwise silently runs an older logger after a
# host-side diagnostic or decoder change.
$logger = if (Test-Path -LiteralPath $loggerBuildOutput) {
    $loggerBuildOutput
} else {
    $loggerArtifact
}
if ($EnableCore1248Mhz.IsPresent) {
    if (($NeuropixelsMcoDivider -ne 0) -and ($NeuropixelsMcoDivider -ne 2)) {
        throw "EnableCore1248Mhz requires NeuropixelsMcoDivider 2."
    }
    if (($NeuropixelsExpectedMclkHz -ne 0) -and ($NeuropixelsExpectedMclkHz -ne 62400000)) {
        throw "EnableCore1248Mhz requires NeuropixelsExpectedMclkHz 62400000."
    }
    $NeuropixelsMcoDivider = 2
    $NeuropixelsExpectedMclkHz = 62400000
}
if ($EnableCore2496Mhz.IsPresent) {
    if ($EnableCore1248Mhz.IsPresent) {
        throw "Select only one experimental core clock profile."
    }
    if (($NeuropixelsMcoDivider -ne 0) -and ($NeuropixelsMcoDivider -ne 4)) {
        throw "EnableCore2496Mhz requires NeuropixelsMcoDivider 4."
    }
    if (($NeuropixelsExpectedMclkHz -ne 0) -and ($NeuropixelsExpectedMclkHz -ne 62400000)) {
        throw "EnableCore2496Mhz requires NeuropixelsExpectedMclkHz 62400000."
    }
    $NeuropixelsMcoDivider = 4
    $NeuropixelsExpectedMclkHz = 62400000
}
if ($ExperimentalCorePll1N -ne 0) {
    if ($EnableCore1248Mhz.IsPresent -or $EnableCore2496Mhz.IsPresent) {
        throw "ExperimentalCorePll1N cannot be combined with a named core clock profile."
    }
    if ($ExperimentalCorePll1N -lt 79) {
        throw "ExperimentalCorePll1N is reserved for the above-187.2 MHz sweep (79..104)."
    }
    $expectedMclk = [uint32](600000 * $ExperimentalCorePll1N)
    if (($NeuropixelsMcoDivider -ne 0) -and ($NeuropixelsMcoDivider -ne 4)) {
        throw "ExperimentalCorePll1N requires NeuropixelsMcoDivider 4."
    }
    if (($NeuropixelsExpectedMclkHz -ne 0) -and ($NeuropixelsExpectedMclkHz -ne $expectedMclk)) {
        throw "ExperimentalCorePll1N requires NeuropixelsExpectedMclkHz $expectedMclk."
    }
    $NeuropixelsMcoDivider = 4
    $NeuropixelsExpectedMclkHz = $expectedMclk
}
$linkVia = Join-Path $projectDir "USB384_NP_BGA_MMC.lnp"
$defaultHex = Join-Path $projectDir "USB384_NP_BGA_MMC.hex"

$nricSource = Join-Path $workspace "Core\Src\xe_np_nric.c"
$appSource = Join-Path $workspace "Core\Src\xe_np_app.c"
$captureSource = Join-Path $workspace "Core\Src\xe_np_capture.c"
$runtimeSource = Join-Path $workspace "Core\Src\xe_np_runtime.c"
$boardSource = Join-Path $workspace "Core\Src\xe_np_board.c"
$usbSource = Join-Path $workspace "Core\Src\xe_np_usb_stream.c"
$interruptSource = Join-Path $workspace "Core\Src\stm32u5xx_it.c"
$mainSource = Join-Path $workspace "Core\Src\main.c"
$failurePlotScript = Join-Path $workspace "Tools\plot_np_failure_debug.ps1"

function Invoke-LoggedCommand {
    param(
        [string]$FilePath,
        [string[]]$ArgumentList,
        [string]$WorkingDirectory
    )

    Push-Location $WorkingDirectory
    try {
        # Start-Process serializes the inherited environment before launching
        # the child. Some developer shells contain both PATH and Path; Windows
        # accepts that environment, but Start-Process rejects it as duplicate
        # dictionary keys. Invoke directly so the bench remains runnable from
        # those shells as well as a clean command prompt.
        $savedErrorActionPreference = $ErrorActionPreference
        try {
            # Native tools such as armlink write normal diagnostics to stderr.
            # Do not turn that successful output into a terminating PowerShell
            # error before checking the actual process exit status.
            $ErrorActionPreference = 'Continue'
            $output = & $FilePath @ArgumentList 2>&1 | Out-String
            if ($LASTEXITCODE -ne 0) {
                throw "Command failed: $FilePath $($ArgumentList -join ' ')`n$output"
            }
            return $output
        }
        finally {
            $ErrorActionPreference = $savedErrorActionPreference
        }
    }
    finally {
        Pop-Location
    }
}

function Get-CommonCompileArgs {
    return @(
        "-xc", "-std=c11", "--target=arm-arm-none-eabi", "-mcpu=cortex-m33",
        "-mfpu=fpv5-sp-d16", "-mfloat-abi=hard", "-c",
        "-fno-rtti", "-funsigned-char", "-fshort-enums", "-fshort-wchar",
        "-gdwarf-4", "-O3", "-ffunction-sections",
        "-Wno-packed", "-Wno-missing-variable-declarations", "-Wno-missing-prototypes",
        "-Wno-missing-noreturn", "-Wno-sign-conversion", "-Wno-nonportable-include-path",
        "-Wno-reserved-id-macro", "-Wno-unused-macros", "-Wno-documentation-unknown-command",
        "-Wno-documentation", "-Wno-license-management", "-Wno-parentheses-equality",
        "-Wno-reserved-identifier",
        "-I", "..\Core\Inc",
        "-I", "..\Drivers\STM32U5xx_HAL_Driver\Inc",
        "-I", "..\Drivers\STM32U5xx_HAL_Driver\Inc\Legacy",
        "-I", "..\Drivers\CMSIS\Device\ST\STM32U5xx\Include",
        "-I", "..\Drivers\CMSIS\Include",
        "-I", ".\RTE\_USB384_NP_BGA_MMC",
        "-I", "C:\Users\aeria\AppData\Local\Arm\Packs\ARM\CMSIS\6.1.0\CMSIS\Core\Include",
        "-D__UVISION_VERSION=537",
        "-D_RTE_",
        "-DSTM32U595xx",
        "-DUSE_HAL_DRIVER"
    )
}

function Convert-ToLinkerPath {
    param([string]$Path)

    return ($Path -replace "\\", "/")
}

function Get-TimingConfig {
    param([int]$Candidate)

    $timingTable = @(
        @{ Rising = 0; Filter = 0 },
        @{ Rising = 1; Filter = 0 },
        @{ Rising = 0; Filter = 1 },
        @{ Rising = 1; Filter = 1 },
        @{ Rising = 0; Filter = 2 },
        @{ Rising = 1; Filter = 2 },
        @{ Rising = 0; Filter = 4 },
        @{ Rising = 1; Filter = 4 }
    )
    return $timingTable[$Candidate]
}

function Compile-SourceOverride {
    param(
        [string]$SourcePath,
        [string]$ObjectPath,
        [string]$DepPath,
        [string[]]$ExtraDefines
    )

    $args = New-Object System.Collections.Generic.List[string]
    foreach ($arg in (Get-CommonCompileArgs)) {
        $args.Add([string]$arg)
    }
    foreach ($define in $ExtraDefines) {
        $args.Add("-D$define")
    }
    $args.Add($SourcePath)
    $args.Add("-o")
    $args.Add($ObjectPath)
    $args.Add("-MD")

    Invoke-LoggedCommand -FilePath $armclang -ArgumentList $args.ToArray() -WorkingDirectory $mdkArm | Out-Null
}

function Build-DefaultImage {
    Invoke-LoggedCommand -FilePath $uv4 -ArgumentList @("-b", "USB384_NP_BGA_MMC.uvprojx", "-j0", "-o", "uv4_batch_output.txt") -WorkingDirectory $mdkArm | Out-Null
}

function New-CustomLinkVia {
    param(
        [hashtable]$ObjectOverrides,
        [string]$OutputAxf,
        [string]$OutputMap,
        [string]$OutputVia,
        [string]$ScatterPath
    )

    $content = Get-Content -Raw $linkVia
    $content = [regex]::Replace(
        $content,
        '--strict\s+--scatter\s+"[^"]+"',
        ('--strict --scatter "' + (Convert-ToLinkerPath $ScatterPath) + '"'))
    foreach ($entry in $ObjectOverrides.GetEnumerator()) {
        $replacement = '"' + (Convert-ToLinkerPath $entry.Value) + '"'
        $content = $content.Replace($entry.Key, $replacement)
    }

    $outputLine = '--list "USB384_NP_BGA_MMC.map" -o USB384_NP_BGA_MMC\USB384_NP_BGA_MMC.axf'
    $replacementLine =
        '--list "' + (Convert-ToLinkerPath $OutputMap) + '" -o "' + (Convert-ToLinkerPath $OutputAxf) + '"'
    $content = $content.Replace($outputLine, $replacementLine)
    Set-Content -Path $OutputVia -Value $content -Encoding ASCII
}

function Build-BenchImage {
    $objectOverrides = @{}
    $systemObject = Join-Path $benchBuildDir 'system_split.o'
    Compile-SourceOverride -SourcePath (Join-Path $workspace 'Core/Src/system_stm32u5xx.c') -ObjectPath $systemObject -DepPath ($systemObject+'.d') -ExtraDefines @('VECT_TAB_OFFSET=0x180000U')
    $objectOverrides['"usb384_np_bga_mmc\system_stm32u5xx.o"']=$systemObject
    $contractObject = Join-Path $benchBuildDir 'boot_contract_split.o'
    Compile-SourceOverride -SourcePath (Join-Path $workspace 'Core/Src/xe_np_boot_contract.c') -ObjectPath $contractObject -DepPath ($contractObject+'.d') -ExtraDefines @()

    $timing = Get-TimingConfig -Candidate $TimingCandidate
    $commonBenchDefines = New-Object System.Collections.Generic.List[string]
    if ($EnableQuadUsbPaced.IsPresent) {
        if (-not $EnableQuadUsbWordExport.IsPresent) { throw 'Paced export requires the word-stage qualifier' }
        $commonBenchDefines.Add('XE_NP_APP_QUAD_USB_PACED=1U')
    }
    if ($EnableQuadUsbWordExport.IsPresent) {
        if ($NeuropixelsMcoDivider -ne 4 -or $DelayTicks -lt 1 -or $DelayTicks -gt 7 -or
            -not $EnableUsbInternalDma.IsPresent -or
            ($UsbPacketsPerTransfer -ne 0 -and $UsbPacketsPerTransfer -lt 56)) {
            throw 'Word USB qualifier requires MCO/2, delay 1..7, USB IDMA, and at least 56 packet slots'
        }
        if ($EnableQuadUsbPaced.IsPresent -and $DelayTicks -eq 4) {
            throw 'The paced compare must not coincide with timer reset (CCR3=0)'
        }
        if (-not $EnableUsbQuadStreamOnly.IsPresent -or -not $EnableUsbQuadStagingDma.IsPresent -or
            -not $EnableQuadPackedWords.IsPresent -or -not $EnableDmaQuadStagger.IsPresent -or
            -not $EnableDmaQuadDarOnly.IsPresent -or -not $EnableQuadDescriptorSram2.IsPresent -or
            $EnableDmaQuadQuiet.IsPresent -or $EnableQuadCpuGuard.IsPresent -or $NoProbeDryRun.IsPresent -or
            $EnableUsbQuadZeroCopy.IsPresent -or $EnableUsbQuadLpdmaStaging.IsPresent -or $FreezeCaptureAfterMs -ne 0) {
            throw 'USB word qualifier requires packed/staggered/DAR/SRAM2 capture plus quad DMA staging, without quiet/freeze/zero-copy'
        }
        $commonBenchDefines.Add('XE_NP_APP_QUAD_USB_WORD_EXPORT=1U')
    }
    if ($NoProbeDryRun.IsPresent) {
        if (-not $SwdOnly.IsPresent -or -not $EnableDmaQuadQuiet.IsPresent) {
            throw 'NoProbeDryRun requires finite SWD-only quiet capture'
        }
        $commonBenchDefines.Add('XE_NP_APP_QUAD_DMA_NO_PROBE_DRYRUN=1U')
    }
    if ($EnableQuadDescriptorSram2.IsPresent -or $EnableQuadPackedWords.IsPresent -or $EnableQuadCpuGuard.IsPresent) {
        if (-not $EnableDmaQuadDarOnly.IsPresent) { throw 'Isolation/packing probes require quad DAR-only' }
    }
    if ($EnableQuadDescriptorSram2.IsPresent) {
        if ($UsbDmaSram2.IsPresent) { throw 'SRAM2 cannot simultaneously own USB buffers and capture descriptors' }
        $commonBenchDefines.Add('XE_NP_APP_QUAD_DMA_LLI_SRAM2=1U')
    }
    if ($EnableQuadPackedWords.IsPresent) {
        if (-not $EnableDmaQuadLinearChannels.IsPresent -or
            (90L * $DmaDualInterleaveRepeatCount) % 16 -ne 0) {
            throw 'Packed qualification requires compact channels and word-aligned quarter-lane offsets'
        }
        $commonBenchDefines.Add('XE_NP_APP_QUAD_DMA_PACK_WORDS=1U')
    }
    if ($EnableQuadCpuGuard.IsPresent) {
        if (-not $EnableDmaQuadQuiet.IsPresent -or $EnableCaptureSram1.IsPresent) {
            throw 'CPU guard requires quiet capture in SRAM3'
        }
        $commonBenchDefines.Add('XE_NP_APP_QUAD_DMA_CPU_GUARD=1U')
    }
    if ($QuadCpuGuardNegative.IsPresent) {
        if (-not $EnableQuadCpuGuard.IsPresent) { throw 'Negative CPU read requires the MPU guard' }
        $commonBenchDefines.Add('XE_NP_APP_QUAD_DMA_CPU_GUARD_NEGATIVE=1U')
    }
    if ($QuadChannelRotation -ne 0) {
        if (-not $EnableDmaQuadDarOnly.IsPresent) { throw 'Channel rotation requires quad DAR-only' }
        $commonBenchDefines.Add("XE_NP_APP_QUAD_DMA_CHANNEL_ROTATION=$QuadChannelRotation"+'U')
    }
    if ($EnableDmaQuadStagger.IsPresent -or $EnableDmaQuadQuiet.IsPresent) {
        if (-not $EnableDmaQuadDarOnly.IsPresent) { throw 'Stagger/quiet requires EnableDmaQuadDarOnly' }
        if ($EnableDmaQuadStagger.IsPresent) {
            if ((90L * $DmaDualInterleaveRepeatCount) % 4 -ne 0) { throw 'Stagger requires lane bytes divisible by four' }
            $commonBenchDefines.Add('XE_NP_APP_QUAD_DMA_STAGGER_ENABLE=1U')
        }
        if ($EnableDmaQuadQuiet.IsPresent) {
            if (-not $FreezeQuiesceOnly.IsPresent -or $FreezeCaptureAfterMs -lt 50 -or
                $EnableUsbInternalDma.IsPresent -or $EnableSdStressWriter.IsPresent) {
                throw 'Quiet capture requires >=50 ms quiesced freeze with USB/SD DMA disabled'
            }
            $commonBenchDefines.Add('XE_NP_APP_QUAD_DMA_QUIET_ENABLE=1U')
        }
    }
    if ($EnableDmaQuadDarOnly.IsPresent) {
        if ((-not $EnableDmaQuadInterleaveIsolated.IsPresent -and -not $EnableQuadUsbWordExport.IsPresent) -or
            ($EnableUsbQuadStreamOnly.IsPresent -and -not $EnableQuadUsbWordExport.IsPresent) -or $EnableDmaQuadPingPong.IsPresent -or
            $EnableDmaFullPortQuadInterleaveIsolated.IsPresent -or
            $EnableDmaQuadTimedShadow.IsPresent -or $EnableDmaTripleInterleaveIsolated.IsPresent) {
            throw "Quad DAR-only requires isolated four-lane single-probe capture without a consumer."
        }
        if (90L * $DmaDualInterleaveRepeatCount -gt 65535 -or $DmaDualInterleaveRepeatCount -lt 1) {
            throw "Quad DAR-only lane size must be 1..65535 bytes."
        }
        $commonBenchDefines.Add("XE_NP_APP_QUAD_DMA_DAR_ONLY_ENABLE=1U")
    }
    if ($CaptureDmaNodeBytes -gt 0) {
        $commonBenchDefines.Add("XE_NP_CAPTURE_DMA_NODE_BYTES=$CaptureDmaNodeBytes" + "UL")
    }
    if ($CaptureStorageBytes -gt 0) {
        $commonBenchDefines.Add("XE_NP_APP_CAPTURE_STORAGE_BYTES=$CaptureStorageBytes" + "UL")
    }
    if ($NeuropixelsMcoDivider -gt 0) {
        $commonBenchDefines.Add("XE_NP_BOARD_EXPERIMENT_MCO_DIVIDER=$NeuropixelsMcoDivider" + "U")
        $commonBenchDefines.Add("XE_NP_BOARD_EXPERIMENT_EXPECTED_MCO_HZ=$NeuropixelsExpectedMclkHz" + "UL")
    }
    if ($EnableCore1248Mhz.IsPresent) {
        $commonBenchDefines.Add("XE_NP_BOARD_EXPERIMENTAL_1872MHZ_CORE=0U")
        $commonBenchDefines.Add("XE_NP_BOARD_EXPERIMENTAL_1248MHZ_CORE=1U")
    }
    if ($EnableCore2496Mhz.IsPresent) {
        $commonBenchDefines.Add("XE_NP_BOARD_EXPERIMENTAL_1872MHZ_CORE=0U")
        $commonBenchDefines.Add("XE_NP_BOARD_EXPERIMENTAL_2496MHZ_CORE=1U")
    }
    if ($ExperimentalCorePll1N -ne 0) {
        $commonBenchDefines.Add("XE_NP_BOARD_EXPERIMENTAL_1872MHZ_CORE=0U")
        $commonBenchDefines.Add("XE_NP_BOARD_EXPERIMENTAL_PLL1N_CORE=$ExperimentalCorePll1N" + "U")
    }
    if ($EnableSdTransportDiagnostic.IsPresent) {
        $commonBenchDefines.Add("XE_NP_BOARD_EXPERIMENT_DISABLE_SD_INIT=0U")
    }
    if ($EnableSdLinkedListBench.IsPresent) {
        if ($SdLinkedListTransferCycles -lt 1 -or $SdLinkedListTransferCycles -gt 258) {
            throw "SdLinkedListTransferCycles must be in the range 1..258."
        }
        if ($SdLinkedListNodeBlocks -lt 1 -or $SdLinkedListNodeBlocks -gt 127) {
            throw "SdLinkedListNodeBlocks must be in the range 1..127."
        }
        $commonBenchDefines.Add("XE_NP_BOARD_SD_WRITE_BENCH_IMAGE=1U")
        $commonBenchDefines.Add("XE_NP_BOARD_EXPERIMENT_DISABLE_SD_INIT=0U")
        $commonBenchDefines.Add("XE_NP_SD_BENCH_LL_TRANSFER_CYCLES=$SdLinkedListTransferCycles" + "UL")
        $commonBenchDefines.Add("XE_NP_SD_BENCH_LL_NODE_BLOCKS=$SdLinkedListNodeBlocks" + "UL")
        if ($DisableSdLinkedListNoCmd12.IsPresent) {
            $commonBenchDefines.Add("XE_NP_SD_BENCH_USE_CMD23_NO_CMD12=0U")
        }
        if ($EnableSdLinkedListBenchSourceSram3.IsPresent) {
            $commonBenchDefines.Add("XE_NP_SD_BENCH_SOURCE_SRAM3=1U")
        }
        if ($EnableSdLinkedListRetargetIntegrityTest.IsPresent) {
            if ($DisableSdLinkedListNoCmd12.IsPresent) {
                throw "EnableSdLinkedListRetargetIntegrityTest requires the custom CMD23/no-CMD12 path."
            }
            if ($SdLinkedListNodeBlocks -ne 120) {
                throw "EnableSdLinkedListRetargetIntegrityTest requires -SdLinkedListNodeBlocks 120 to match the 61,440-byte recorder node."
            }
            $commonBenchDefines.Add("XE_NP_SD_BENCH_RETARGET_INTEGRITY_TEST=1U")
        }
    }
    elseif ($EnableSdLinkedListRetargetIntegrityTest.IsPresent) {
        throw "EnableSdLinkedListRetargetIntegrityTest requires EnableSdLinkedListBench."
    }
    if ($UsbPacketsPerTransfer -ne 63) {
        $commonBenchDefines.Add("XE_NP_USB_STREAM_PACKETS_PER_TRANSFER=$UsbPacketsPerTransfer" + "U")
    }
    if (($EnableUsbStreamOnly.IsPresent -or $EnableUsbQuadStreamOnly.IsPresent) -and -not $EnableUsbCaptureSram3Cacheable.IsPresent) {
        # The 15 kHz paired-lane bench owns all of RW_NP_CAPTURE in SRAM3.
        # Mark only that producer ring non-cacheable so the foreground pair
        # copier never spends its narrow guard window invalidating both lanes.
        $commonBenchDefines.Add("XE_NP_CAPTURE_SRAM3_MPU_NONCACHEABLE=1U")
    }
    if ($EnableNp2HalfwordCapture.IsPresent) {
        $commonBenchDefines.Add("XE_NP_APP_CAPTURE_FORCE_NP2_HALFWORD_DIAG=1U")
    }
    if ($EnableDmaDualPhaseProbe.IsPresent) {
        $commonBenchDefines.Add("XE_NP_APP_EXPERIMENT_GPIOE_DUAL_DMA_PHASE_PROBE_ENABLE=1U")
        $commonBenchDefines.Add("XE_NP_APP_GPIOE_DDR_PHASE_A_DELAY_TICKS=$DdrPhaseADelayTicks" + "U")
        $commonBenchDefines.Add("XE_NP_APP_GPIOE_DDR_PHASE_B_DELAY_TICKS=$DdrPhaseBDelayTicks" + "U")
    }
    if (-not [string]::IsNullOrWhiteSpace($NeuropixelsMcoGpioSpeed)) {
        $commonBenchDefines.Add("XE_NP_BOARD_EXPERIMENT_MCO_GPIO_SPEED=GPIO_SPEED_FREQ_$($NeuropixelsMcoGpioSpeed.ToUpperInvariant())")
    }

    $captureObject = Join-Path $benchBuildDir "xe_np_capture_syncbench.o"
    $captureDep = Join-Path $benchBuildDir "xe_np_capture_syncbench.d"
    Compile-SourceOverride -SourcePath $captureSource -ObjectPath $captureObject -DepPath $captureDep -ExtraDefines $commonBenchDefines.ToArray()
    $objectOverrides['"usb384_np_bga_mmc\xe_np_capture.o"'] = $captureObject

    $runtimeObject = Join-Path $benchBuildDir "xe_np_runtime_syncbench.o"
    $runtimeDep = Join-Path $benchBuildDir "xe_np_runtime_syncbench.d"
    $runtimeDefines = New-Object System.Collections.Generic.List[string]
    foreach ($define in $commonBenchDefines) {
        $runtimeDefines.Add($define)
    }
    if ($ActiveProbeMask -gt 0) {
        $runtimeDefines.Add("XE_NP_RUNTIME_DEFAULT_PROBE_MASK=$ActiveProbeMask" + "U")
    }
    Compile-SourceOverride -SourcePath $runtimeSource -ObjectPath $runtimeObject -DepPath $runtimeDep -ExtraDefines $runtimeDefines.ToArray()
    $objectOverrides['"usb384_np_bga_mmc\xe_np_runtime.o"'] = $runtimeObject

    $boardObject = Join-Path $benchBuildDir "xe_np_board_syncbench.o"
    $boardDep = Join-Path $benchBuildDir "xe_np_board_syncbench.d"
    Compile-SourceOverride -SourcePath $boardSource -ObjectPath $boardObject -DepPath $boardDep -ExtraDefines $commonBenchDefines.ToArray()
    $objectOverrides['"usb384_np_bga_mmc\xe_np_board.o"'] = $boardObject

    $nricObject = Join-Path $benchBuildDir "xe_np_nric_syncbench.o"
    $nricDep = Join-Path $benchBuildDir "xe_np_nric_syncbench.d"
    $nricDefines = New-Object System.Collections.Generic.List[string]
    foreach ($define in $commonBenchDefines) {
        $nricDefines.Add($define)
    }
    $nricDefines.Add("XE_NP_NRIC_DIAG_SKIP_CHAIN2_PROGRAM=$([int]$SkipChain2)U")
    if ($EnablePsbHalfRate.IsPresent) {
        $nricDefines.Add("XE_NP_NRIC_USE_PSB_HALF_RATE=1U")
    }
    Compile-SourceOverride -SourcePath $nricSource -ObjectPath $nricObject -DepPath $nricDep -ExtraDefines $nricDefines
    $objectOverrides['"usb384_np_bga_mmc\xe_np_nric.o"'] = $nricObject

    $appDefines = New-Object System.Collections.Generic.List[string]
    foreach ($define in $commonBenchDefines) {
        $appDefines.Add($define)
    }
    $appDefines.Add("XE_NP_APP_GPIOE_CAPTURE_TIM2_RISING_EDGE=$($timing.Rising)U")
    $appDefines.Add("XE_NP_APP_GPIOE_CAPTURE_TIM2_FILTER=$($timing.Filter)U")
    $appDefines.Add("XE_NP_APP_GPIOE_CAPTURE_TIM2_DELAY_TICKS=$DelayTicks" + "U")
    if ($EnableDmaDualPhaseProbe.IsPresent) {
        # xe_np_app.c owns the TIM2 CC2/CC3 routing.  These definitions must
        # be applied to that object as well as the common capture objects.
        $appDefines.Add("XE_NP_APP_EXPERIMENT_GPIOE_DUAL_DMA_PHASE_PROBE_ENABLE=1U")
        $appDefines.Add("XE_NP_APP_GPIOE_DDR_PHASE_A_DELAY_TICKS=$DdrPhaseADelayTicks" + "U")
        $appDefines.Add("XE_NP_APP_GPIOE_DDR_PHASE_B_DELAY_TICKS=$DdrPhaseBDelayTicks" + "U")
    }
    if ($CaptureStorageBytes -gt 0) {
        $appDefines.Add("XE_NP_APP_CAPTURE_STORAGE_BYTES=$CaptureStorageBytes" + "UL")
    }
    if ($EnableKeepSessionOnHostStop.IsPresent) {
        $appDefines.Add("XE_NP_APP_USB_CAPTURE_KEEP_SESSION_ON_HOST_STOP=1U")
    }
    if ($ActiveProbeMask -eq 1) {
        $appDefines.Add("XE_NP_GENERATED_PROBE_CONFIG_INDEX=0U")
    }
    elseif ($ActiveProbeMask -eq 2) {
        $appDefines.Add("XE_NP_GENERATED_PROBE_CONFIG_INDEX=1U")
    }
    elseif ($ActiveProbeMask -eq 4) {
        $appDefines.Add("XE_NP_GENERATED_PROBE_CONFIG_INDEX=2U")
    }
    if ($EnableCaptureSram1.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_CAPTURE_SRAM1_ENABLE=1U")
    }
    if ($EnableCapturePsram.IsPresent) {
        $appDefines.Add("XE_NP_APP_CAPTURE_PSRAM_ENABLE=1U")
    }
    if ($EnableDmaDirectRepeat.IsPresent) {
        $appDefines.Add("XE_NP_APP_CAPTURE_DMA_DIRECT_REPEAT_DIAG_ENABLE=1U")
    }
    if ($EnableDmaSelfLink.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_DMA_SELF_LINK_ENABLE=1U")
    }
    if ($EnableDmaSingle2dCircular.IsPresent) {
        # Use the normal HAL circular-queue path with one 2D repeated-block
        # node. This removes intermediate descriptor handoffs without the
        # hand-built self-link used by EnableDmaSelfLink.
        $appDefines.Add("XE_NP_APP_CAPTURE_DMA_SINGLE_2D_NODE_ENABLE=1U")
    }
    if ($EnableDmaDarOnlyCircular.IsPresent -or $useUsb15kDarOnly) {
        # ST's optimized circular mode: a one-word LLI restores only CDAR,
        # rather than reloading a full linked-list item at the wrap.
        $appDefines.Add("XE_NP_APP_CAPTURE_DMA_DAR_ONLY_CIRCULAR_ENABLE=1U")
    }
    if ($EnableDmaDualDarOnlyCircular.IsPresent) {
        if (-not ($EnableDmaDualInterleaveIsolatedStorage.IsPresent -or
                  $EnableDmaDualInterleaveStorage.IsPresent -or
                  $EnableUsbStreamOnly.IsPresent)) {
            throw "EnableDmaDualDarOnlyCircular requires an alternating dual-lane topology."
        }
        $appDefines.Add("XE_NP_APP_DUAL_DMA_DAR_ONLY_CIRCULAR_ENABLE=1U")
    }
    if ($SwdOnly.IsPresent -and
        ($EnableDmaDirectRepeat.IsPresent -or $EnableDmaSelfLink.IsPresent)) {
        # SWD-only benches have no USB control request to release the
        # host-triggered safety gate used by the no-reload experiments.
        $appDefines.Add("XE_NP_APP_EXPERIMENT_HOST_TRIGGERED_BRINGUP_ONLY=0U")
    }
    if ($EnableDmaDynamicQueue.IsPresent) {
        $appDefines.Add("XE_NP_APP_CAPTURE_DMA_DYNAMIC_QUEUE_ENABLE=1U")
    }
    if ($EnableDmaDualInterleave.IsPresent -or
        $EnableDmaDualInterleavePublish.IsPresent -or
        $EnableDmaDualInterleaveStorage.IsPresent -or
        $EnableDmaDualInterleaveIsolatedStorage.IsPresent -or
        $EnableDmaDualPhaseProbe.IsPresent -or
        $EnableUsbStreamOnly.IsPresent) {
        # TIM2 phase-locks every PSB sample edge; TIM8 alternates that edge
        # stream between two GPDMA channels and yields reconstructable lanes.
        $appDefines.Add("XE_NP_APP_EXPERIMENT_GPIOE_DUAL_DMA_INTERLEAVE_ENABLE=1U")
    }
    if ($EnableDmaDualPhaseProbe.IsPresent) {
        # Two timer compares, not alternating-cell TIM8 requests.  Each GPDMA
        # lane samples one independently positioned NP1 DDR data-valid eye.
        # The phase settings are common build definitions because both the
        # capture-state geometry and the TIM2 scheduler must agree on them.
    }
    if ($EnableDmaQuadInterleaveIsolated.IsPresent -or
        $EnableDmaQuadPingPong.IsPresent -or
        $EnableUsbQuadStreamOnly.IsPresent -or
        $EnableDmaTripleInterleaveIsolated.IsPresent -or
        $EnableDmaFullPortQuadInterleaveIsolated.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_GPIOE_QUAD_DMA_INTERLEAVE_ENABLE=1U")
        if ($CaptureStorageBytes -eq 0) {
            if ($EnableDmaFullPortQuadInterleaveIsolated.IsPresent) {
                # Three wired GPIO bytes, four phases each.  Keep every
                # byte-wide linear lane at 46,080 bytes: below GPDMA's 16-bit
                # block limit while retaining a 7.9 ms lane history.
                $appDefines.Add("XE_NP_APP_CAPTURE_STORAGE_BYTES=552960UL")
            } elseif ($EnableDmaQuadPingPong.IsPresent) {
                # Four lanes, two 46,080-byte epochs each.  The inactive
                # epoch is the only range permitted to USB staging.
                $appDefines.Add("XE_NP_APP_CAPTURE_STORAGE_BYTES=368640UL")
            } elseif ($EnableNp2HalfwordCapture.IsPresent) {
                # Four 16-bit lanes require the same 46,080-byte per-lane
                # hardware block for a valid compact-channel qualification.
                $appDefines.Add("XE_NP_APP_CAPTURE_STORAGE_BYTES=184320UL")
            } else {
                # The physical byte-lane rings share the 720 KiB raw backing store.
                $appDefines.Add("XE_NP_APP_CAPTURE_STORAGE_BYTES=737280UL")
            }
        }
        if ($EnableDmaTripleInterleaveIsolated.IsPresent) {
            $appDefines.Add("XE_NP_APP_GPIOE_QUAD_DMA_INTERLEAVE_LANE_COUNT=3U")
            $appDefines.Add("XE_NP_APP_GPIOE_QUAD_DMA_INTERLEAVE_BLOCK_BYTES=120U")
        } elseif ($EnableDmaFullPortQuadInterleaveIsolated.IsPresent) {
            if ($EnableUsbQuadStreamOnly.IsPresent -or $EnableDmaQuadTimedShadow.IsPresent) {
                throw "The full-port quad qualifier cannot run an SRAM3 consumer."
            }
            if (-not $PSBoundParameters.ContainsKey('DmaDualInterleaveRepeatCount')) {
                # 12 lanes * 90-byte repeated block * 512 repeats exactly
                # occupies the 540 KiB qualifier arena.  Each byte-wide linear
                # node is 46,080 bytes, safely below the GPDMA block limit.
                $DmaDualInterleaveRepeatCount = 512
            }
            $appDefines.Add("XE_NP_APP_GPIOE_QUAD_DMA_INTERLEAVE_BLOCK_BYTES=90U")
            $appDefines.Add("XE_NP_APP_EXPERIMENT_GPIO_FULLPORT_QUAD_STRESS_ENABLE=1U")
        } elseif ($EnableDmaQuadPingPong.IsPresent) {
            if (-not $PSBoundParameters.ContainsKey('DmaDualInterleaveRepeatCount')) {
                $DmaDualInterleaveRepeatCount = 512
            }
            $appDefines.Add("XE_NP_APP_GPIOE_QUAD_DMA_INTERLEAVE_BLOCK_BYTES=90U")
            $appDefines.Add("XE_NP_APP_EXPERIMENT_GPIOE_QUAD_DMA_PINGPONG_ENABLE=1U")
        } elseif ($EnableNp2HalfwordCapture.IsPresent) {
            # A halfword DMA item represents one complete GPIOE sample, so
            # retain 90 timer requests per repeated block as 180 bytes.
            $appDefines.Add("XE_NP_APP_GPIOE_QUAD_DMA_INTERLEAVE_BLOCK_BYTES=180U")
        } else {
            $appDefines.Add("XE_NP_APP_GPIOE_QUAD_DMA_INTERLEAVE_BLOCK_BYTES=90U")
        }
        # The four-lane storage geometry is block-by-repeat-count per lane.
        # Keep its firmware expectation synchronized with the requested raw
        # allocation; previously this argument was applied only to dual lanes.
        $appDefines.Add("XE_NP_APP_GPIOE_DUAL_DMA_INTERLEAVE_REPEAT_COUNT=$DmaDualInterleaveRepeatCount" + "U")
        if ($EnableUsbQuadStreamOnly.IsPresent) {
            $appDefines.Add("XE_NP_APP_EXPERIMENT_GPIOE_QUAD_DMA_INTERLEAVE_USB_ENABLE=1U")
        }
        if ($EnableDmaQuadLinearChannels.IsPresent -or
            $EnableDmaQuadPingPong.IsPresent -or
            $EnableDmaFullPortQuadInterleaveIsolated.IsPresent) {
            if ($EnableDmaTripleInterleaveIsolated.IsPresent) {
                throw "EnableDmaQuadLinearChannels supports the four-lane topology only."
            }
            $appDefines.Add("XE_NP_APP_EXPERIMENT_GPIOE_QUAD_DMA_LINEAR_CHANNELS_ENABLE=1U")
        }
        if ($EnableDmaQuadTimedShadow.IsPresent) {
            if ($EnableDmaTripleInterleaveIsolated.IsPresent) {
                throw "EnableDmaQuadTimedShadow supports the four-lane topology only."
            }
            if (-not $EnableDmaQuadLinearChannels.IsPresent) {
                throw "EnableDmaQuadTimedShadow requires EnableDmaQuadLinearChannels (channels 12..15 are reserved for the shadows)."
            }
            $appDefines.Add("XE_NP_APP_EXPERIMENT_GPIOE_QUAD_DMA_TIMED_SHADOW_ENABLE=1U")
        }
    }
    if ((-not ($EnableDmaQuadInterleaveIsolated.IsPresent -or
                $EnableDmaQuadPingPong.IsPresent -or
                $EnableUsbQuadStreamOnly.IsPresent -or
                $EnableDmaTripleInterleaveIsolated.IsPresent -or
                $EnableDmaFullPortQuadInterleaveIsolated.IsPresent)) -and
        ($EnableDmaQuadLinearChannels.IsPresent -or $EnableDmaQuadTimedShadow.IsPresent)) {
        throw "The quad linear/timed-shadow options require a four-lane quad capture mode."
    }
    if ($EnableDmaDualInterleavePublish.IsPresent -or
        $EnableDmaDualInterleaveStorage.IsPresent -or
        $EnableDmaDualInterleaveIsolatedStorage.IsPresent -or
        $EnableDmaDualPhaseProbe.IsPresent -or
        $EnableUsbStreamOnly.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_GPIOE_DUAL_DMA_INTERLEAVE_PUBLISH_ENABLE=1U")
    }
    if ($EnableDmaDualInterleaveDelayedPwm2.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_GPIOE_DUAL_DMA_INTERLEAVE_DELAYED_PWM2_ENABLE=1U")
    }
    if ($EnableDmaDualInterleaveStorage.IsPresent -or
        $EnableDmaDualInterleaveIsolatedStorage.IsPresent -or
        $EnableDmaDualPhaseProbe.IsPresent -or
        $EnableUsbStreamOnly.IsPresent) {
        # Persist each physical lane separately. USB-only and SWD-isolated
        # modes deliberately do not arm the SD sink.
        $appDefines.Add("XE_NP_APP_EXPERIMENT_GPIOE_DUAL_DMA_INTERLEAVE_STORAGE_ENABLE=1U")
        if (-not $EnableUsbStreamOnly.IsPresent -and
            ((-not $EnableDmaDualInterleaveIsolatedStorage.IsPresent) -or
             $EnableSdStressWriter.IsPresent) -and
            -not $EnableDmaDualPhaseProbe.IsPresent) {
            $appDefines.Add("XE_NP_APP_RAW_SD_SINK_ENABLE=1U")
            $appDefines.Add("XE_NP_APP_BENCH_CAPTURE_WITHOUT_STORAGE=0U")
        }
        # A lane alone is not a PSB stream. The firmware reconstructs a small
        # completed two-lane window before it allows SD recording to arm.
        $appDefines.Add("XE_NP_APP_EXPERIMENT_SYNC_WATCHDOG_ENABLE=1U")
        if ($CaptureStorageBytes -eq 0) {
            # Eight 2D nodes per physical lane (180 * 256 bytes) consume
            # the same 720 KiB across both lanes, but report a completed
            # lane span every ~8 ms instead of once per 63 ms ring wrap.
            $appDefines.Add("XE_NP_APP_CAPTURE_STORAGE_BYTES=737280UL")
        }
        $appDefines.Add("XE_NP_APP_GPIOE_DUAL_DMA_INTERLEAVE_BLOCK_BYTES=180U")
        $appDefines.Add("XE_NP_APP_GPIOE_DUAL_DMA_INTERLEAVE_REPEAT_COUNT=$DmaDualInterleaveRepeatCount" + "U")
        $appDefines.Add("XE_NP_APP_RAW_SD_MAX_BLOCKS_PER_WRITE=$RawSdBlocksPerWrite" + "U")
        if ($EnableUnqualifiedSdRaw.IsPresent) {
            $appDefines.Add("XE_NP_APP_EXPERIMENT_ALLOW_UNQUALIFIED_SD_RAW=1U")
        }
        if ($EnableSdSinkWhileUsbIdle.IsPresent) {
            $appDefines.Add("XE_NP_APP_EXPERIMENT_SD_SINK_IGNORE_USB_CONFIG=1U")
        }
        if ($EnableUnqualifiedSdCaptureLock.IsPresent) {
            $appDefines.Add("XE_NP_APP_EXPERIMENT_ALLOW_UNQUALIFIED_SD_CAPTURE_LOCK=1U")
        }
    }
    elseif ($EnableDmaDualInterleavePublish.IsPresent) {
        # The published paired-lane path needs one 180 * 2048-byte circular
        # DMA node per lane.  Keep that geometry when neither SD nor USB is
        # enabled so SWD can validate capture in isolation.
        $appDefines.Add("XE_NP_APP_GPIOE_DUAL_DMA_INTERLEAVE_BLOCK_BYTES=180U")
    }
    if ($EnableSdStressWriter.IsPresent) {
        if (-not $EnableSdTransportDiagnostic.IsPresent) {
            throw "EnableSdStressWriter requires EnableSdTransportDiagnostic."
        }
        if (-not ($EnableDmaDualInterleaveStorage.IsPresent -or
                  $EnableDmaDualInterleaveIsolatedStorage.IsPresent -or
                  $EnableDmaQuadInterleaveIsolated.IsPresent)) {
            throw "EnableSdStressWriter requires a paired- or quad-lane capture topology."
        }
        $appDefines.Add("XE_NP_APP_EXPERIMENT_SD_STRESS_WRITER_ENABLE=1U")
        if ($EnableDmaQuadInterleaveIsolated.IsPresent) {
            # The 30 kS/s four-lane qualifier has no dataMGR producer.  The
            # private SRAM1 stress writer only needs an active GPIO producer,
            # so arm the raw-SD service explicitly without adding any reader
            # of the live SRAM3 lanes.
            $appDefines.Add("XE_NP_APP_RAW_SD_SINK_ENABLE=1U")
            $appDefines.Add("XE_NP_APP_BENCH_CAPTURE_WITHOUT_STORAGE=0U")
            $appDefines.Add("XE_NP_APP_RAW_SD_MAX_BLOCKS_PER_WRITE=$RawSdBlocksPerWrite" + "U")
            if ($EnableUnqualifiedSdRaw.IsPresent) {
                $appDefines.Add("XE_NP_APP_EXPERIMENT_ALLOW_UNQUALIFIED_SD_RAW=1U")
            }
            if ($EnableSdSinkWhileUsbIdle.IsPresent) {
                $appDefines.Add("XE_NP_APP_EXPERIMENT_SD_SINK_IGNORE_USB_CONFIG=1U")
            }
        }
    }
    if ($EnableRawSdDmaStaging.IsPresent) {
        if (-not $EnableDmaDualInterleaveStorage.IsPresent) {
            throw "EnableRawSdDmaStaging requires EnableDmaDualInterleaveStorage."
        }
        if (-not $EnableSdTransportDiagnostic.IsPresent) {
            throw "EnableRawSdDmaStaging requires EnableSdTransportDiagnostic."
        }
        $appDefines.Add("XE_NP_APP_RAW_SD_DMA_STAGING_ENABLE=1U")
        # The storage experiment owns the capture lanes. Keep all preview,
        # decoder, and USB-window bookkeeping out of the GPIO DMA IRQ path.
        $appDefines.Add("XE_NP_APP_RAW_SD_DEDICATED_CAPTURE_ENABLE=1U")
    }
    if ($EnableRawSdLinkedStream.IsPresent) {
        if (-not $EnableDmaDualInterleaveStorage.IsPresent -or
            -not $EnableSdTransportDiagnostic.IsPresent) {
            throw "EnableRawSdLinkedStream requires paired storage and SD transport."
        }
        $appDefines.Add("XE_NP_APP_RAW_SD_LINKED_STREAM_ENABLE=1U")
        $appDefines.Add("XE_NP_APP_RAW_SD_DEDICATED_CAPTURE_ENABLE=1U")
        if ($EnableRawSdLinkedRetarget.IsPresent) {
            $appDefines.Add("XE_NP_APP_RAW_SD_LINKED_RETARGET_ENABLE=1U")
        }
    }
    elseif ($EnableRawSdLinkedRetarget.IsPresent) {
        throw "EnableRawSdLinkedRetarget requires EnableRawSdLinkedStream."
    }
    if ($EnableMinimalDmaIrqDispatch.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_DMA_MINIMAL_IRQ_DISPATCH_ENABLE=1U")
    }
    $appDefines.Add("XE_NP_APP_CAPTURE_DMA_DEST_BURST_LENGTH=$DmaDestBurstLength" + "U")
    $appDefines.Add("XE_NP_APP_CAPTURE_DMA_DEST_ALLOCATED_PORT=DMA_DEST_ALLOCATED_PORT$CaptureDmaDestPort")
    $appDefines.Add("XE_NP_APP_EXPERIMENT_DMA_LINK_ALLOCATED_PORT=$DmaLinkAllocatedPort" + "U")
    if ($EnablePsbTim2Etr.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_GPIOE_CAPTURE_TIM2_PSB_ETR_ENABLE=1U")
    }
    if ($EnableTim2PsbArmedFreerun.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_TIM2_PSB_ARMED_FREERUN_ENABLE=1U")
    }
    if ($EnableTim2PsbEdgeReset.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_TIM2_RESET_EACH_PSB_EDGE_ENABLE=1U")
    }
    if ($DisableCaptureRateMonitor.IsPresent) {
        # A characterization image measures the cadence directly from its
        # frozen ring; do not reject an intentionally new clock topology using
        # the production rate monitor's legacy expectation.
        $appDefines.Add("XE_NP_APP_EXPERIMENT_DISABLE_CAPTURE_RATE_MONITOR=1U")
    }
    if ($EnableStableWindowDefer.IsPresent -or ($StableWindowReleaseBytes -gt 0)) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_USB_STABLE_WINDOW_DEFER_ENABLE=1U")
        $appDefines.Add("XE_NP_APP_EXPERIMENT_USB_STABLE_WINDOW_DEFER_BYTES=$StableWindowReleaseBytes" + "U")
    }
    if ($UsbWindowChunkBytes -gt 0) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_USB_WINDOW_CHUNK_BYTES=$UsbWindowChunkBytes" + "U")
    }
    if ($DisableUsbRingHeadroom.IsPresent -or $useUsb15kDarOnly) {
        $appDefines.Add("XE_NP_APP_USB_RING_PACKET_HEADROOM_ENABLE=0U")
    }
    if ($EnableFullNodeWindowPublication.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_FULL_NODE_WINDOW_PUBLICATION_ENABLE=1U")
    }
    if ($FreezeCaptureAfterMs -gt 0) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_FREEZE_CAPTURE_AFTER_MS=$FreezeCaptureAfterMs" + "U")
    }
    if ($FreezeQuiesceOnly.IsPresent) {
        if ($FreezeCaptureAfterMs -le 0) {
            throw "FreezeQuiesceOnly requires FreezeCaptureAfterMs."
        }
        $appDefines.Add("XE_NP_APP_EXPERIMENT_FREEZE_QUIESCE_ONLY=1U")
    }
    if ($EnableSyncWatchdog.IsPresent -and -not $EnableDmaDualInterleaveStorage.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_SYNC_WATCHDOG_ENABLE=1U")
    }
    if ($EnableHalfBoundaryProbe.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_HALF_BOUNDARY_PROBE_ENABLE=1U")
    }
    if ($EnableHalfBoundaryProbeIsrSnapshot.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_HALF_BOUNDARY_PROBE_ISR_SNAPSHOT_ENABLE=1U")
    }
    if ($EnableHalfWindowQueueReserve.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_HALF_WINDOW_QUEUE_RESERVE_ENABLE=1U")
    }
    if ($CaptureStorageOffsetBytes -gt 0) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_CAPTURE_STORAGE_OFFSET_BYTES=$CaptureStorageOffsetBytes" + "U")
    }
    if ($EnableNp2PsbPullup.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_NP2_PSB_PULLUP_ENABLE=1U")
    }
    if ($EnableNp2PsbPulldown.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_NP2_PSB_PULLDOWN_ENABLE=1U")
    }
    if ($EnablePsbClkPullup.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_PSB_CLK_PULLUP_ENABLE=1U")
    }
    if ($EnablePsbClkPulldown.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_PSB_CLK_PULLDOWN_ENABLE=1U")
    }
    if ($EnableCaptureDmaLowPriority.IsPresent) {
        $appDefines.Add("XE_NP_APP_CAPTURE_LINKED_LIST_PRIORITY=DMA_LOW_PRIORITY_HIGH_WEIGHT")
    }
    if ($EnableCaptureSuppressDma.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_CAPTURE_SUPPRESS_DMA_ENABLE=1U")
    }
    if ($EnableSkipNricConfig.IsPresent) {
        $appDefines.Add("XE_NP_APP_EXPERIMENT_SKIP_NRIC_CONFIG_ENABLE=1U")
    }
    $appObject = Join-Path $benchBuildDir "xe_np_app_syncbench.o"
    $appDep = Join-Path $benchBuildDir "xe_np_app_syncbench.d"
    Compile-SourceOverride `
        -SourcePath $appSource `
        -ObjectPath $appObject `
        -DepPath $appDep `
        -ExtraDefines $appDefines.ToArray()
    $objectOverrides['"usb384_np_bga_mmc\xe_np_app.o"'] = $appObject

    $mainObject = Join-Path $benchBuildDir "main_syncbench.o"
    $mainDep = Join-Path $benchBuildDir "main_syncbench.d"
    $mainDefines = New-Object System.Collections.Generic.List[string]
    foreach ($define in $commonBenchDefines) {
        $mainDefines.Add($define)
    }
    # Keep SD host bring-up tied directly to the translation unit that owns
    # MX_SDMMC1_SD_Init.  This is intentionally repeated instead of relying on
    # a common-definition propagation path: a disabled host leaves the raw-SD
    # diagnostic permanently zero and makes a staging test look like a capture
    # failure.
    if ($EnableSdTransportDiagnostic.IsPresent) {
        $mainDefines.Add("XE_NP_BOARD_EXPERIMENT_DISABLE_SD_INIT=0U")
    }
    if ($EnableUsbInternalDma.IsPresent -or $useUsb15kDarOnly) {
        $mainDefines.Add("XE_NP_BOARD_USB_OTG_HS_INTERNAL_DMA=1U")
    }
    if ($EnableUsbInternalDmaSingleBurst.IsPresent) {
        if (-not ($EnableUsbInternalDma.IsPresent -or $useUsb15kDarOnly)) {
            throw "EnableUsbInternalDmaSingleBurst requires EnableUsbInternalDma."
        }
        $mainDefines.Add("XE_NP_BOARD_USB_OTG_HS_IDMA_SINGLE_BURST=1U")
    }
    Compile-SourceOverride `
        -SourcePath $mainSource `
        -ObjectPath $mainObject `
        -DepPath $mainDep `
        -ExtraDefines $mainDefines.ToArray()
    $objectOverrides['"usb384_np_bga_mmc\main.o"'] = $mainObject

    $usbObject = Join-Path $benchBuildDir "xe_np_usb_stream_syncbench.o"
    $usbDep = Join-Path $benchBuildDir "xe_np_usb_stream_syncbench.d"
    $usbDefines = New-Object System.Collections.Generic.List[string]
    foreach ($define in $commonBenchDefines) {
        $usbDefines.Add($define)
    }
    if ($EnableCaptureSram1.IsPresent) {
        $usbDefines.Add("XE_NP_USB_STREAM_CAPTURE_SRAM1_ENABLE=1U")
    }
    if ($EnableUsbLaneValidator.IsPresent) {
        $usbDefines.Add("XE_NP_USB_STREAM_LANE_VALIDATOR_ENABLE=1U")
    }
    if ($EnableUsbSeamProbe.IsPresent) {
        $usbDefines.Add("XE_NP_USB_STREAM_SEAM_PROBE_ENABLE=1U")
        $usbDefines.Add("XE_NP_USB_STREAM_EDGE_HASH_ENABLE=1U")
    }
    if ($EnableUsbRealCaptureSyntheticPayload.IsPresent) {
        $usbDefines.Add("XE_NP_USB_STREAM_REAL_CAPTURE_SYNTHETIC_PAYLOAD_ENABLE=1U")
    }
    if ($EnableUsbRealCaptureSyntheticDetachPort.IsPresent) {
        $usbDefines.Add("XE_NP_USB_STREAM_REAL_CAPTURE_SYNTHETIC_DETACH_PORT_ENABLE=1U")
    }
    if ($EnableUsbRealCaptureRestartSynthetic.IsPresent) {
        $usbDefines.Add("XE_NP_USB_STREAM_REAL_CAPTURE_RESTART_SYNTHETIC_ENABLE=1U")
    }
    if ($EnableUsbRealCaptureSkipRelease.IsPresent) {
        $usbDefines.Add("XE_NP_USB_STREAM_REAL_CAPTURE_SKIP_RELEASE_ENABLE=1U")
    }
    if ($EnableUsbRealExportSyntheticPacket.IsPresent) {
        $usbDefines.Add("XE_NP_USB_STREAM_REAL_EXPORT_SYNTHETIC_PACKET_ENABLE=1U")
    }
    if ($EnableUsbInterleavedStagingDma.IsPresent) {
        if (-not $EnableUsbStreamOnly.IsPresent) {
            throw "EnableUsbInterleavedStagingDma requires EnableUsbStreamOnly."
        }
        $usbDefines.Add("XE_NP_USB_STREAM_INTERLEAVED_STAGING_DMA_ENABLE=1U")
        if ($EnableUsbInterleavedStagingHighPriority.IsPresent) {
            $usbDefines.Add("XE_NP_USB_STREAM_INTERLEAVED_STAGING_DMA_PRIORITY=DMA_HIGH_PRIORITY")
        }
    }
    if ($EnableUsbQuadStagingDma.IsPresent) {
        if ($EnableUsbQuadLpdmaStaging.IsPresent) {
            throw "Choose either EnableUsbQuadStagingDma or EnableUsbQuadLpdmaStaging."
        }
        if (-not $EnableUsbQuadStreamOnly.IsPresent) {
            throw "EnableUsbQuadStagingDma requires EnableUsbQuadStreamOnly."
        }
        # The four-lane route has its own linked-list producer.  It performs
        # every guarded SRAM3 read with low-priority GPDMA and leaves the CPU
        # to packet headers/descriptors in SRAM1 only.
        $usbDefines.Add("XE_NP_USB_STREAM_QUAD_STAGING_DMA_ENABLE=1U")
        $usbDefines.Add('XE_NP_USB_STREAM_INTERLEAVED_STAGING_DMA_CHANNEL=14U')
    }
    if ($EnableUsbQuadZeroCopy.IsPresent) {
        if (-not $EnableUsbQuadStreamOnly.IsPresent) {
            throw "EnableUsbQuadZeroCopy requires EnableUsbQuadStreamOnly."
        }
        if ($EnableUsbQuadStagingDma.IsPresent -or $EnableUsbQuadLpdmaStaging.IsPresent) {
            throw "EnableUsbQuadZeroCopy cannot be combined with a staging DMA."
        }
        $usbDefines.Add("XE_NP_USB_STREAM_QUAD_ZEROCOPY_ENABLE=1U")
    }
    if ($EnableUsbQuadLpdmaStaging.IsPresent) {
        if (-not $EnableUsbQuadStreamOnly.IsPresent) {
            throw "EnableUsbQuadLpdmaStaging requires EnableUsbQuadStreamOnly."
        }
        $usbDefines.Add("XE_NP_USB_STREAM_QUAD_STAGING_DMA_ENABLE=1U")
        $usbDefines.Add("XE_NP_USB_STREAM_QUAD_STAGING_LPDMA_ENABLE=1U")
    }
    if ($EnableUsbSyntheticNpVccTest.IsPresent) {
        $usbDefines.Add("XE_NP_USB_STREAM_SYNTHETIC_ENABLE_NP_VCC_TEST=1U")
    }
    if ($EnableUsbSyntheticNpResetReleaseTest.IsPresent) {
        $usbDefines.Add("XE_NP_USB_STREAM_SYNTHETIC_RELEASE_NP_RESETS_TEST=1U")
    }
    Compile-SourceOverride `
        -SourcePath $usbSource `
        -ObjectPath $usbObject `
        -DepPath $usbDep `
        -ExtraDefines $usbDefines.ToArray()
    $objectOverrides['"usb384_np_bga_mmc\xe_np_usb_stream.o"'] = $usbObject
    if ($EnableUsbInterleavedStagingDma.IsPresent -or
        $EnableUsbQuadStagingDma.IsPresent -or
        $EnableUsbQuadLpdmaStaging.IsPresent -or
        $EnableRawSdDmaStaging.IsPresent -or $EnableQuadCpuGuard.IsPresent) {
        # Channel 14 has a project-local completion IRQ.  Override the cached
        # MDK object as well as the USB stream implementation so the test image
        # actually dispatches that callback.
        $interruptObject = Join-Path $benchBuildDir "stm32u5xx_it_syncbench.o"
        $interruptDep = Join-Path $benchBuildDir "stm32u5xx_it_syncbench.d"
        Compile-SourceOverride `
            -SourcePath $interruptSource `
            -ObjectPath $interruptObject `
            -DepPath $interruptDep `
            -ExtraDefines $usbDefines.ToArray()
        $objectOverrides['"usb384_np_bga_mmc\stm32u5xx_it.o"'] = $interruptObject
    }

    $scatterPath = Join-Path $mdkArm "USB384_NP_BGA_MMC_custom.sct"
    if ($EnableQuadDescriptorSram2.IsPresent) {
        $scatterPath = Join-Path $benchBuildDir 'USB384_NP_BGA_MMC_lli_sram2.sct'
        $scatterContent = Get-Content -Raw (Join-Path $mdkArm 'USB384_NP_BGA_MMC_custom.sct')
        if ($scatterContent -notmatch 'RW_IRAM1 0x20000000') { throw 'Unknown V1 linker layout' }
        $scatterContent = $scatterContent.Replace('  RW_IRAM1 0x20000000',
            "  RW_NP_LLI 0x200C0000 0x00000200 {`r`n   *(NP_CAPTURE_LLI)`r`n  }`r`n`r`n  RW_IRAM1 0x20000000")
        Set-Content -LiteralPath $scatterPath -Value $scatterContent -Encoding ASCII
    }
    if ($UsbDmaSram2.IsPresent) {
        # Do not edit the shared scatter file during a bench.  Give this
        # artifact a private linker layout so an A/B placement test cannot
        # change the normal firmware's SRAM1 endpoint placement.
        $scatterPath = Join-Path $benchBuildDir "USB384_NP_BGA_MMC_usb_sram2.sct"
        $scatterContent = Get-Content -Raw (Join-Path $mdkArm "USB384_NP_BGA_MMC_custom.sct")
        $scatterContent = $scatterContent.Replace(
            "RW_USB_DMA 0x20050000 UNINIT 0x00010000",
            "RW_USB_DMA 0x200C0000 UNINIT 0x00010000")
        Set-Content -LiteralPath $scatterPath -Value $scatterContent -Encoding ASCII
    }
    New-CustomLinkVia -ObjectOverrides $objectOverrides -OutputAxf $benchAxf -OutputMap $benchMap -OutputVia $benchLinkVia -ScatterPath $scatterPath
    $sensorObjects=@()
    foreach($unit in @('xe_np_sensors','xe_np_sensors_port','xe_np_bme_compensation','xe_np_bmm_compensation','CE32_system_compat','CE32_BMX160')) {
        $obj=Join-Path $benchBuildDir ($unit+'_usb_sensors.o')
        Compile-SourceOverride -SourcePath (Join-Path $workspace ('Core/Src/'+$unit+'.c')) -ObjectPath $obj -DepPath ($obj+'.d') -ExtraDefines $commonBenchDefines.ToArray()
        if($unit.StartsWith('xe_np_')) {$sensorObjects+='"'+(Convert-ToLinkerPath $obj)+'"'}
        else {$objectOverrides['"usb384_np_bga_mmc\'+$unit.ToLowerInvariant()+'.o"']=$obj}
    }
    New-CustomLinkVia -ObjectOverrides $objectOverrides -OutputAxf $benchAxf -OutputMap $benchMap -OutputVia $benchLinkVia -ScatterPath $scatterPath
    Add-Content -LiteralPath $benchLinkVia -Value $sensorObjects -Encoding ASCII
    Add-Content -LiteralPath $benchLinkVia -Value ('"'+$contractObject+'"')
    foreach($unit in @('np_config','np_config_port','CE32_UART_INTERCOM')) {
        $obj=Join-Path $benchBuildDir ($unit+'_npconfig.o')
        Compile-SourceOverride -SourcePath (Join-Path $workspace ('Core/Src/'+$unit+'.c')) -ObjectPath $obj -DepPath ($obj+'.d') -ExtraDefines $commonBenchDefines.ToArray()
        if($unit -eq 'CE32_UART_INTERCOM') {
            $via=[IO.File]::ReadAllText($benchLinkVia)
            $old='"usb384_np_bga_mmc\ce32_uart_intercom.o"'
            if(!$via.ToLowerInvariant().Contains($old)){throw 'UART link entry changed'}
            $via=[regex]::Replace($via,[regex]::Escape($old),('"'+(Convert-ToLinkerPath $obj)+'"'),'IgnoreCase')
            [IO.File]::WriteAllText($benchLinkVia,$via)
        } else {Add-Content -LiteralPath $benchLinkVia -Value ('"'+(Convert-ToLinkerPath $obj)+'"')}
    }
    Invoke-LoggedCommand -FilePath $armlink -ArgumentList @("--via", $benchLinkVia) -WorkingDirectory $mdkArm | Out-Null
    Invoke-LoggedCommand -FilePath $fromelf -ArgumentList @("--i32combined", "--output", $benchHex, $benchAxf) -WorkingDirectory $mdkArm | Out-Null
}

function Flash-Hex {
    param([string]$HexPath)

    $attempts = @(
        @("-c", "port=SWD", "mode=HOTPLUG", "-w", $HexPath, "-v", "-rst"),
        @("-c", "port=SWD", "mode=UR", "reset=HWrst", "freq=1000", "-w", $HexPath, "-v", "-rst")
    )
    $errors = New-Object System.Collections.Generic.List[string]

    for ($attemptIndex = 0; $attemptIndex -lt $attempts.Count; $attemptIndex++) {
        Get-Process STM32_Programmer_CLI -ErrorAction SilentlyContinue | Stop-Process -Force
        Start-Sleep -Milliseconds 750
        try {
            Invoke-LoggedCommand -FilePath $stprog -ArgumentList $attempts[$attemptIndex] -WorkingDirectory $workspace | Out-Null
            return
        }
        catch {
            $errors.Add("attempt $($attemptIndex + 1): $($_.Exception.Message)")
            Start-Sleep -Milliseconds 750
        }
    }

    throw ($errors -join "`n`n")
}

function Wait-ForDevice {
    $deadline = (Get-Date).AddSeconds($EnumerateTimeoutSeconds)
    $lastList = ""

    while ((Get-Date) -lt $deadline) {
        $lastList = Invoke-LoggedCommand -FilePath $logger -ArgumentList @("--list-devices") -WorkingDirectory $workspace
        if (($lastList -match "(?m)^custom_path=") -or ($lastList -match "(?m)^fallback_path=")) {
            return $lastList
        }
        Start-Sleep -Seconds $EnumeratePollSeconds
    }

    throw "Timed out waiting for USB enumeration.`n$lastList"
}

function Run-Capture {
    param([string]$OutDir)

    $attempts = 0
    while ($attempts -lt 3) {
        $attempts++
        try {
            $loggerArgs = @(
                "--out", $OutDir,
                "--port", "$PortIndex",
                "--seconds", "$Seconds",
                "--decode"
            )
            if ($EnableUsbSyntheticTest.IsPresent) {
                $loggerArgs += "--synthetic"
            }
            return Invoke-LoggedCommand -FilePath $logger -ArgumentList $loggerArgs -WorkingDirectory $workspace
        }
        catch {
            $message = $_.Exception.Message
            if (($attempts -ge 3) -or ($message -notmatch "No XE NP WinUSB device found")) {
                throw
            }
            Start-Sleep -Seconds $EnumeratePollSeconds
        }
    }

    throw "Unreachable capture retry state."
}

function Get-BenchSymbolAddress {
    param([string]$Name)

    $symbols = Select-String -LiteralPath $benchMap -Pattern ('^\s*' + [regex]::Escape($Name) + '\s+0x([0-9A-Fa-f]+)')
    $symbol = $symbols | Select-Object -First 1
    if ($null -eq $symbol) {
        throw "Could not locate $Name in $benchMap"
    }
    $match = [regex]::Match($symbol.Line, '0x([0-9A-Fa-f]+)')
    if (-not $match.Success) {
        throw "Could not parse $Name address from: $($symbol.Line)"
    }

    return ('0x' + $match.Groups[1].Value)
}

function Capture-SwdDiagnostics {
    param([string]$OutDir)

    Start-Sleep -Seconds $Seconds
    $address = Get-BenchSymbolAddress -Name 'xe_np_capture_bench_diag'
    $dump = Invoke-LoggedCommand -FilePath $stprog -ArgumentList @(
        '-c', 'port=SWD', 'mode=HOTPLUG', 'freq=3300', '-r32', $address, '840'
    ) -WorkingDirectory $workspace
    $dumpPath = Join-Path $OutDir 'capture_bench_swd.txt'
    Set-Content -LiteralPath $dumpPath -Value $dump -Encoding ASCII
    return $dumpPath
}

function Capture-SwdRawSnapshot {
    param([string]$OutDir)

    $address = Get-BenchSymbolAddress -Name 'xe_np_raw_capture_storage'
    $snapshotPath = Join-Path $OutDir 'capture_raw_snapshot.bin'
    $nodeBytes = if ($CaptureDmaNodeBytes -gt 0) { $CaptureDmaNodeBytes } else { 61440 }
    $storageBytes = if ($CaptureStorageBytes -gt 0) {
        $CaptureStorageBytes
    } elseif ($EnableDmaFullPortQuadInterleaveIsolated.IsPresent) {
        552960
    } elseif ($EnableDmaDualInterleaveStorage.IsPresent -or
              $EnableDmaDualInterleaveIsolatedStorage.IsPresent -or
              $EnableDmaDualPhaseProbe.IsPresent -or
               $EnableUsbStreamOnly.IsPresent -or
               $EnableUsbSingleDirect.IsPresent -or
              $EnableDmaQuadInterleaveIsolated.IsPresent -or
              $EnableDmaTripleInterleaveIsolated.IsPresent) {
        # Keep the SWD diagnostic snapshot in sync with the recorder default.
        737280
    } else {
        245760
    }
    $storageBytes = [int]([math]::Floor($storageBytes / $nodeBytes) * $nodeBytes)
    Invoke-LoggedCommand -FilePath $stprog -ArgumentList @(
        '-c', 'port=SWD', 'mode=HOTPLUG', 'freq=3300', '-r', $address, "$storageBytes", $snapshotPath
    ) -WorkingDirectory $workspace | Out-Null
    if (-not (Test-Path -LiteralPath $snapshotPath)) {
        throw "STM32CubeProgrammer did not create $snapshotPath"
    }
    if ($EnableDmaQuadInterleaveIsolated.IsPresent -and $FreezeQuiesceOnly.IsPresent) {
        $diagAddress = Get-BenchSymbolAddress -Name 'xe_np_quad_dma_freeze_diag'
        $diagPath = Join-Path $OutDir 'quad_freeze_diag.bin'
        Invoke-LoggedCommand -FilePath $stprog -ArgumentList @(
            '-c', 'port=SWD', 'mode=HOTPLUG', 'freq=3300', '-r', $diagAddress, '108', $diagPath
        ) -WorkingDirectory $workspace | Out-Null
        if (-not (Test-Path -LiteralPath $diagPath)) { throw 'Missing frozen DMA diagnostic' }
        if ($EnableQuadCpuGuard.IsPresent) {
            $guardAddress = Get-BenchSymbolAddress -Name 'xe_np_quad_cpu_guard_diag'
            Invoke-LoggedCommand -FilePath $stprog -ArgumentList @(
                '-c', 'port=SWD', 'mode=HOTPLUG', 'freq=3300', '-r', $guardAddress, '36',
                (Join-Path $OutDir 'quad_cpu_guard_diag.bin')
            ) -WorkingDirectory $workspace | Out-Null
        }
    }
    return $snapshotPath
}

function Capture-SwdRawSdDiagnostics {
    param([string]$OutDir)

    $address = Get-BenchSymbolAddress -Name 'xe_np_raw_sd_diag'
    $dump = Invoke-LoggedCommand -FilePath $stprog -ArgumentList @(
        '-c', 'port=SWD', 'mode=HOTPLUG', 'freq=3300', '-r32', $address, '160'
    ) -WorkingDirectory $workspace
    $dumpPath = Join-Path $OutDir 'raw_sd_sink_swd.txt'
    Set-Content -LiteralPath $dumpPath -Value $dump -Encoding ASCII
    return $dumpPath
}

function Capture-SwdProbeDiagnostics {
    param([string]$OutDir)

    $address = Get-BenchSymbolAddress -Name 'xe_np_probe_diag'
    $dump = Invoke-LoggedCommand -FilePath $stprog -ArgumentList @(
        '-c', 'port=SWD', 'mode=HOTPLUG', 'freq=3300', '-r32', $address, '32'
    ) -WorkingDirectory $workspace
    $dumpPath = Join-Path $OutDir 'probe_diag_swd.txt'
    Set-Content -LiteralPath $dumpPath -Value $dump -Encoding ASCII
    return $dumpPath
}

function Write-RunSummary {
    param(
        [string]$StdoutText,
        [string]$OutDir
    )

    $timing = Get-TimingConfig -Candidate $TimingCandidate

    $summary = [ordered]@{
        output = $OutDir
        seconds = $Seconds
        port = $PortIndex
        active_probe_mask = $(if($ActiveProbeMask -gt 0){$ActiveProbeMask}else{2})
        timing_candidate = $TimingCandidate
        timing = ("cand{0}:{1}:f{2}" -f $TimingCandidate, ($(if($timing.Rising -ne 0){'rising'} else {'falling'})), $timing.Filter)
        timing_rising_edge = $timing.Rising
        timing_filter = $timing.Filter
        delay_ticks = $DelayTicks
        ddr_phase_a_delay_ticks = $DdrPhaseADelayTicks
        ddr_phase_b_delay_ticks = $DdrPhaseBDelayTicks
        skip_chain2 = $SkipChain2
        stable_window_defer = ($EnableStableWindowDefer.IsPresent -or ($StableWindowReleaseBytes -gt 0))
        stable_window_release_bytes = $StableWindowReleaseBytes
        usb_window_chunk_bytes = $UsbWindowChunkBytes
        capture_dma_node_bytes = $(if($CaptureDmaNodeBytes -gt 0){$CaptureDmaNodeBytes}else{61440})
        capture_storage_bytes = $(
            if($CaptureStorageBytes -gt 0){
                $CaptureStorageBytes
            } elseif($EnableDmaFullPortQuadInterleaveIsolated.IsPresent) {
                552960
            } elseif($EnableDmaDualInterleaveStorage.IsPresent -or
                     $EnableDmaDualInterleaveIsolatedStorage.IsPresent -or
                     $EnableUsbStreamOnly.IsPresent -or
                     $EnableUsbSingleDirect.IsPresent -or
                     $useUsb15kDarOnly -or
                     $EnableDmaQuadInterleaveIsolated.IsPresent -or
                     $EnableDmaTripleInterleaveIsolated.IsPresent) {
                737280
            } else {
                245760
            })
        capture_storage_offset_bytes = $CaptureStorageOffsetBytes
        neuropixels_mco_divider = $NeuropixelsMcoDivider
        neuropixels_expected_mclk_hz = $NeuropixelsExpectedMclkHz
        neuropixels_mco_gpio_speed = $(if([string]::IsNullOrWhiteSpace($NeuropixelsMcoGpioSpeed)){'default'}else{$NeuropixelsMcoGpioSpeed.ToUpperInvariant()})
        usb_ring_headroom = (-not ($DisableUsbRingHeadroom.IsPresent -or $useUsb15kDarOnly))
        full_node_window_publication = $EnableFullNodeWindowPublication.IsPresent
        dual_dma_delayed_pwm2 = $EnableDmaDualInterleaveDelayedPwm2.IsPresent
        sync_watchdog = ($EnableSyncWatchdog.IsPresent -or
                          $EnableDmaDualInterleaveStorage.IsPresent -or
                          $EnableDmaDualInterleaveIsolatedStorage.IsPresent)
        np2_psb_pullup = $EnableNp2PsbPullup.IsPresent
        np2_psb_pulldown = $EnableNp2PsbPulldown.IsPresent
        psb_clk_pullup = $EnablePsbClkPullup.IsPresent
        psb_clk_pulldown = $EnablePsbClkPulldown.IsPresent
        usb_lane_validator = $EnableUsbLaneValidator.IsPresent
        usb_seam_probe = $EnableUsbSeamProbe.IsPresent
        usb_internal_dma = ($EnableUsbInternalDma.IsPresent -or $useUsb15kDarOnly)
        usb_single_direct = $EnableUsbSingleDirect.IsPresent
        psb_tim2_etr = $EnablePsbTim2Etr.IsPresent
        dma_direct_repeat = $EnableDmaDirectRepeat.IsPresent
        dma_self_link = $EnableDmaSelfLink.IsPresent
        dma_single_2d_circular = $EnableDmaSingle2dCircular.IsPresent
        usb_15k_dar_only = $useUsb15kDarOnly
        dma_dynamic_queue = $EnableDmaDynamicQueue.IsPresent
        dma_dual_interleave = ($EnableDmaDualInterleave.IsPresent -or $EnableDmaDualInterleavePublish.IsPresent -or $EnableDmaDualInterleaveStorage.IsPresent -or $EnableDmaDualInterleaveIsolatedStorage.IsPresent)
        dma_dual_interleave_publish = ($EnableDmaDualInterleavePublish.IsPresent -or $EnableDmaDualInterleaveStorage.IsPresent -or $EnableDmaDualInterleaveIsolatedStorage.IsPresent)
        dma_dual_interleave_storage = $EnableDmaDualInterleaveStorage.IsPresent
        dma_dual_interleave_isolated_storage = $EnableDmaDualInterleaveIsolatedStorage.IsPresent
        dma_quad_interleave_isolated = $EnableDmaQuadInterleaveIsolated.IsPresent
        dma_triple_interleave_isolated = $EnableDmaTripleInterleaveIsolated.IsPresent
        raw_sd_blocks_per_write = $(if($EnableDmaDualInterleaveStorage.IsPresent){$RawSdBlocksPerWrite}else{0})
        minimal_dma_irq_dispatch = $EnableMinimalDmaIrqDispatch.IsPresent
        dma_dest_burst_length = $DmaDestBurstLength
        psb_half_rate = $EnablePsbHalfRate.IsPresent
        tim2_psb_armed_freerun = $EnableTim2PsbArmedFreerun.IsPresent
        tim2_psb_edge_reset = $EnableTim2PsbEdgeReset.IsPresent
        payload_bytes = 0
        packets = 0
        seq_gaps = -1
        source_gaps = -1
        payload_hash_mismatches = -1
        alignment_mod = -1
        frame_errors = -1
        best_clean_frames = -1
        relocks = -1
    }

    if ($StdoutText -match "Captured (\d+) payload bytes in (\d+) packets") {
        $summary.payload_bytes = [int64]$Matches[1]
        $summary.packets = [int]$Matches[2]
    }
    if ($StdoutText -match "Packet diagnostics: seq-gaps=(\d+), .*source-gaps=(\d+), payload-hash-mismatches=(\d+)") {
        $summary.seq_gaps = [int]$Matches[1]
        $summary.source_gaps = [int]$Matches[2]
        $summary.payload_hash_mismatches = [int]$Matches[3]
    }
    if ($StdoutText -match "alignment_mod=(\d+), frame_errors=(\d+), .*best_clean_frames=(\d+), relocks=(\d+)") {
        $summary.alignment_mod = [int]$Matches[1]
        $summary.frame_errors = [int]$Matches[2]
        $summary.best_clean_frames = [int]$Matches[3]
        $summary.relocks = [int]$Matches[4]
    }

    $summaryPath = Join-Path $OutDir "bench_summary.txt"
    ($summary.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value)" }) | Set-Content -Path $summaryPath -Encoding ASCII
    [pscustomobject]$summary
}

New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null
$benchBuildDir = Join-Path $OutputDirectory "_build"
New-Item -ItemType Directory -Force -Path $benchBuildDir | Out-Null
$benchLinkVia = Join-Path $benchBuildDir "USB384_NP_BGA_MMC_syncbench.lnp"
$benchAxf = Join-Path $benchBuildDir "USB384_NP_BGA_MMC_syncbench.axf"
$benchMap = Join-Path $benchBuildDir "USB384_NP_BGA_MMC_syncbench.map"
$benchHex = Join-Path $benchBuildDir "USB384_NP_BGA_MMC_syncbench.hex"

$stdoutPath = Join-Path $OutputDirectory "logger_stdout.txt"
$restoreAttempted = $false
$restoreFlashed = $false
$swdDiagPath = ""
$swdRawPath = ""
$swdRawSdDiagPath = ""
$swdProbeDiagPath = ""

try {
    Build-BenchImage
    if ($BuildOnly.IsPresent) {
        Write-Host "Bench image built without flashing the target."
        return
    }
    Flash-Hex -HexPath $benchHex
    if ($SwdOnly.IsPresent) {
        $swdDiagPath = Capture-SwdDiagnostics -OutDir $OutputDirectory
        Write-Host ("swd_capture_bench=" + $swdDiagPath)
        $swdProbeDiagPath = Capture-SwdProbeDiagnostics -OutDir $OutputDirectory
        Write-Host ("swd_probe_diag=" + $swdProbeDiagPath)
        if ($EnableDmaDualInterleaveStorage.IsPresent) {
            $swdRawSdDiagPath = Capture-SwdRawSdDiagnostics -OutDir $OutputDirectory
            Write-Host ("swd_raw_sd_sink=" + $swdRawSdDiagPath)
        }
        if ($FreezeCaptureAfterMs -gt 0) {
            $swdRawPath = Capture-SwdRawSnapshot -OutDir $OutputDirectory
            Write-Host ("swd_capture_raw=" + $swdRawPath)
        }
    }
    else {
        $enumText = Wait-ForDevice
        Set-Content -Path (Join-Path $OutputDirectory "enumeration.txt") -Value $enumText -Encoding ASCII
        $stdoutText = Run-Capture -OutDir $OutputDirectory
        Set-Content -Path $stdoutPath -Value $stdoutText -Encoding ASCII
        $summary = Write-RunSummary -StdoutText $stdoutText -OutDir $OutputDirectory
        $failureCsv = Join-Path $OutputDirectory "decode_failures.csv"
        if ((Test-Path $failurePlotScript) -and (Test-Path $failureCsv)) {
            try {
                Invoke-LoggedCommand -FilePath $powershellExe -ArgumentList @(
                    "-ExecutionPolicy", "Bypass",
                    "-File", $failurePlotScript,
                    "-RunDirectory", $OutputDirectory
                ) -WorkingDirectory $workspace | Out-Null
            }
            catch {
                Write-Warning ("Failed to generate decode failure plot: " + $_.Exception.Message)
            }
        }
        $summary | Format-List | Out-String | Write-Host
    }
}
finally {
    if ((-not $KeepBenchImageFlashed.IsPresent) -and (-not $BuildOnly.IsPresent)) {
        $restoreAttempted = $true
        try {
            Build-DefaultImage
            Flash-Hex -HexPath $defaultHex
            $restoreFlashed = $true
        }
        catch {
            Write-Warning ("Failed to restore default image: " + $_.Exception.Message)
        }
    }
}

Write-Host ""
Write-Host ("output=" + $OutputDirectory)
Write-Host ("restore_attempted=" + $restoreAttempted)
Write-Host ("restore_flashed=" + $restoreFlashed)
