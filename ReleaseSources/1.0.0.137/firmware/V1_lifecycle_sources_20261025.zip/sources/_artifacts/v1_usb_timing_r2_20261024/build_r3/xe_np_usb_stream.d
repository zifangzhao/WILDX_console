C:/Frank/Code/XE_NP/_artifacts/v1_usb_timing_r2_20261024/build_r3/xe_np_usb_stream.o: \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_timing_r2_20261024\source_r5\xe_np_usb_stream.c \
  ..\Core\Inc\np_config_port.h ..\Core\Inc\np_config.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\stdint.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\stddef.h \
  ..\Core\Inc\xe_np_nric.h ..\Core\Inc\xe_np_board.h \
  ..\Core\Inc\xe_np_hal.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\string.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal.h \
  ..\Core\Inc\stm32u5xx_hal_conf.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_rcc.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_def.h \
  ..\Drivers\CMSIS\Device\ST\STM32U5xx\Include\stm32u5xx.h \
  ..\Drivers\CMSIS\Device\ST\STM32U5xx\Include\stm32u595xx.h \
  ..\Drivers\CMSIS\Include\core_cm33.h \
  ..\Drivers\CMSIS\Include\cmsis_version.h \
  ..\Drivers\CMSIS\Include\cmsis_compiler.h \
  ..\Drivers\CMSIS\Include\cmsis_armclang.h \
  ..\Drivers\CMSIS\Include\mpu_armv8.h \
  ..\Drivers\CMSIS\Device\ST\STM32U5xx\Include\system_stm32u5xx.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\Legacy\stm32_hal_legacy.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\math.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_rcc_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_gpio.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_gpio_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_icache.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_dcache.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_dma.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_dma_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_cortex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_adc.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_ll_adc.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_adc_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_dac.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_dac_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_flash.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_flash_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_i2c.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_i2c_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_opamp.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_opamp_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_pwr.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_pwr_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_ospi.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_ll_dlyb.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_sd.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_ll_sdmmc.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_sd_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_spi.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_spi_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_tim.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_tim_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_uart.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_uart_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_pcd.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_ll_usb.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_pcd_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_exti.h \
  ..\Core\Inc\xe_np_sensors_port.h ..\Core\Inc\xe_np_sensors.h \
  ..\Core\Inc\..\..\Middlewares\Bosch\BME280_SensorAPI\bme280.h \
  ..\Core\Inc\..\..\Middlewares\Bosch\BME280_SensorAPI\bme280_defs.h \
  ..\Core\Inc\..\..\Middlewares\Bosch\BMM150_SensorAPI\bmm150.h \
  ..\Core\Inc\..\..\Middlewares\Bosch\BMM150_SensorAPI\bmm150_defs.h \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_timing_r2_20261024\source_r5\np_usb_misc.h \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_integrity_20261016\paired_restore\source\Core\Inc\np_direct_packets.h \
  ..\Core\Inc\np_modes.h ..\Core\Inc\np_usb20_release.h \
  ..\Core\Inc\mode_policy.h \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Inc\np_usb_auto_sd.h \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Inc\mode_policy.h \
  ..\Core\Inc\xe_np_boot_contract.h ..\Core\Inc\np_sd_usb_identity.h \
  ..\Core\Inc\np_sd_dma_chain.h ..\Core\Inc\xe_np_usb_stream.h \
  ..\Core\Inc\dataMGR.h ..\Core\Inc\ce32_wire.h ..\Core\Inc\main.h \
  ..\Core\Inc\xe_np_app.h ..\Core\Inc\xe_np_runtime.h \
  ..\Core\Inc\CE32_COMMAND.h ..\Core\Inc\CE32_Sync.h \
  ..\Core\Inc\xe_np_capture.h ..\Core\Inc\xe_np_psram.h \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_fast_startup_r79r2_20261006\source\Core\Src\np_sd_usb_ep0.inc \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_uhs200_restore_20261020\retained-r2\source\np_usb_backend.inc \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_fast_startup_r79r2_20261006\source\Core\Src\np_usb_camera_arena.h \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\np_sd_read_crc.inc \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_integrity_20261016\paired_restore\source\Core\Src\np_usb_camera_driver.inc \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_fast_startup_r79r2_20261006\source\Core\Src\np_camera_timing.h \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_integrity_20261016\paired_restore\source\Core\Src\usb512_camera.h \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_fast_startup_r79r2_20261006\source\Core\Src\np_camera_storage.inc \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_integrity_20261016\paired_restore\source\Core\Src\np_usb_camera_transport.inc \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_fast_startup_r79r2_20261006\source\Core\Src\np_usb_camera_submit.inc \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_fast_startup_r79r2_20261006\source\Core\Src\np_camera_hardware.inc \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_integrity_20261016\paired_restore\source\Core\Src\np_usb_camera_only.inc \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\np_sd_usb_download.inc \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Inc\np_usb_download_link.h \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\np_usb_download_retire.inc \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\np_usb_modes.inc \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Inc\np_usb_catalog.h \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\np_capture_anchor_usb.inc \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\..\Inc\np_capture_anchor.h \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\..\Inc\xe_np_acquisition_anchor.h \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\..\Inc\xe_np_online_impl.h \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\..\Inc\xe_np_online.h \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\np_usb_timing_port.inc \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\..\Inc\np_usb_timing.h \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_fast_startup_r79r2_20261006\source\Core\Src\np_usb_sd_reset.inc \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_integrity_20261016\paired_restore\source\Core\Src\np_config_usb.inc \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_integrity_20261016\paired_restore\source\Core\Src\np_usb_config_hold.inc \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_integrity_20261016\paired_restore\source\Core\Src\np_modes_usb.inc \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_fast_startup_r79r2_20261006\source\Core\Src\startup_diag_usb.inc \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_fast_startup_r79r2_20261006\source\Core\Src\startup_admission_usb.inc \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_fast_startup_r79r2_20261006\source\Core\Src\np_phase_sweep_usb.inc \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\np_usb_sd_format.inc \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\..\Inc\np_usb_sd_format.h \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\..\Inc\np_sd_fast_crc.h \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_timing_r2_20261024\source_r5\np_usb_sensors.inc \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_timing_r2_20261024\source_r5\np_usb_private_queue.inc
