#ifndef NP_USB_MISC_H
#define NP_USB_MISC_H
#include "xe_np_sensors.h"
#include <string.h>
_Static_assert(sizeof(XE_NP_SensorSnapshot)==140U,"Sensor wire ABI changed");
static inline void np_misc_u32(uint8_t *p,uint32_t v)
{p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);p[2]=(uint8_t)(v>>16);p[3]=(uint8_t)(v>>24);}
static inline uint32_t np_misc_crc(const uint8_t *p,uint32_t n)
{
    uint32_t c=0xffffffffU;
    static const uint32_t table[16]={0,0x1db71064,0x3b6e20c8,0x26d930ac,
        0x76dc4190,0x6b6b51f4,0x4db26158,0x5005713c,
        0xedb88320,0xf00f9344,0xd6d6a3e8,0xcb61b38c,
        0x9b64c2b0,0x86d3d2d4,0xa00ae278,0xbdbdf21c};
    while(n--){c^=*p++;c=(c>>4)^table[c&15];c=(c>>4)^table[c&15];}
    return ~c;
}
/* USB512 compact header, independent stream-5 sequence. Payload begins with
 * the exact SD NPSENS01 v4 record. Additional fields are not sample timestamps:
 * NP packet anchor is the exclusive end of the preceding staged NP batch.
 * Millisecond ticks and sensor-time are separate clocks, not PC wall time. */
static inline void np_usb_misc_packet(uint8_t *p,const XE_NP_SensorSnapshot *source,
    uint32_t sequence,uint32_t now,uint32_t session,uint32_t np_packets,uint32_t overflow)
{
    XE_NP_SensorSnapshot s=*source;
    XE_NP_Sensors_RefreshValidity(&s,now);
    memset(p,0,512);p[0]=0x12;p[1]=0xa5;p[2]=5;p[3]=8;
    p[4]=(uint8_t)sequence;p[5]=(uint8_t)(sequence>>8);
    uint8_t *b=p+6;
    memcpy(b,"NPSENS01",8);np_misc_u32(b+8,sequence);np_misc_u32(b+12,now);
    np_misc_u32(b+16,140);memcpy(b+20,&s,140);np_misc_u32(b+160,np_misc_crc(b,160));
    memcpy(b+164,"NPUSB001",8);np_misc_u32(b+172,1);
    np_misc_u32(b+176,session);np_misc_u32(b+180,np_packets);
    np_misc_u32(b+184,overflow);
    /* IMU, misc and optional camera transport are implemented. */
    np_misc_u32(b+188,7);NP_UsbTimingSlot(p,sequence);np_misc_u32(b+502,np_misc_crc(b,502));
}
#endif
