#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define DMA_CCR_EN 1U
#define DMA_FLAG_TC 1U
#define DMA_FLAG_DTE 2U
#define DMA_FLAG_ULE 4U
#define DMA_FLAG_USE 8U
#define DMA_FLAG_TO 16U
#define XE_NP_APP_GPIOE_QUAD_DMA_INTERLEAVE_USB_GUARD_BYTES 4096U
#define N 63360U
typedef struct {uint32_t CSR,CDAR,CCR,CBR1;} DMA_Channel_TypeDef;
typedef struct {struct {DMA_Channel_TypeDef *Instance;} hdma;} Lane;
typedef struct {const uint8_t *source[4][2];uint16_t source_bytes[4][2],payload_bytes_per_lane;
                uint8_t source_segment_count[4];} XE_NP_AppUsbQuadDmaBatch;
static struct {struct {uint8_t *raw_storage;uint32_t raw_storage_bytes;} capture;} xe_np_runtime;
static Lane xe_np_quad_dma_lanes[4],xe_np_fullport_quad_dma_gpioe_high_lanes[4],xe_np_fullport_quad_dma_gpiod_high_lanes[4];
static uint32_t xe_np_quad_dma_initial_offsets[12],xe_np_quad_usb_word_diag[8],tick;
static unsigned xe_np_quad_dma_active=1,np_mode_mask=3,np_mode_hz=20000;
#define NP_USB20_PAIRED() (np_mode_hz==20000U && np_mode_mask==3U)
static uint32_t HAL_GetTick(void){return tick;}

#define NP_CAPTURE_ANCHOR_ENABLED 1U
#define NP_SD_APP 0U
#define XE_NP_APP_QUAD_DMA_QUIET_ENABLE 0U
#define XE_NP_APP_QUAD_DMA_NO_PROBE_DRYRUN 0U
#define XE_NP_APP_GPIOE_QUAD_DMA_INTERLEAVE_BLOCK_BYTES 90U
#define XE_NP_APP_GPIOE_DUAL_DMA_INTERLEAVE_REPEAT_COUNT 704U
#define DMA_FLAG_HT 32U
static struct {uint32_t CYCCNT;} recovery_dwt;
#define DWT (&recovery_dwt)
static uint32_t np_capture_origin_attempted,origin_calls;
typedef struct {uint32_t ring,head,cursor,first,cycles,ms,hz,healthy;} OriginWitness;
static OriginWitness origin_witness;
static uint32_t XE_NP_Board_GetRuntimeExpectedPsbClkHz(void){return np_mode_hz*780U;}
/* Lower anchor algorithm is not requalified here. The ACTUAL producer hook
 * must prevent a second call even after np3_valid is cleared for recovery. */
static void np_capture_anchor_try_origin(uint32_t ring,uint32_t head,uint32_t cursor,
    uint32_t first,uint32_t cycles,uint32_t ms,uint32_t hz,int healthy)
{
    assert(!np_capture_origin_attempted);
    np_capture_origin_attempted=1U;origin_calls++;
    origin_witness=(OriginWitness){ring,head,cursor,first,cycles,ms,hz,(uint32_t)healthy};
}

#include <np3_producer.inc>
static DMA_Channel_TypeDef regs[4];
static void heads(unsigned logical){
    for(unsigned i=0;i<4;i++)regs[i].CDAR=0x200d0000U+i*N+
        ((logical+xe_np_quad_dma_initial_offsets[i]/2U)%(N/2U))*2U;
}
static void setup(unsigned logical){
    xe_np_runtime.capture.raw_storage=(uint8_t *)0x200d0000U;
    xe_np_runtime.capture.raw_storage_bytes=12U*N;tick=0;
    for(unsigned i=0;i<4;i++){
        xe_np_quad_dma_lanes[i].hdma.Instance=&regs[i];
        xe_np_quad_dma_initial_offsets[i]=i*N/12U;regs[i].CSR=DMA_FLAG_TC;
        /* The P2 DMA handles are deliberately NULL: no duplicate GPIO read. */
    }
    np_capture_origin_attempted=origin_calls=0U;memset(&origin_witness,0,sizeof(origin_witness));
    heads(logical);np3_reset();
}
#include <np_direct_packets.h>
static __declspec(align(32)) uint16_t samples[4][N/2];
static __declspec(align(32)) uint8_t packet[NP_DIRECT_WIRE_BYTES];
static unsigned selected;
#if defined(PAIRED_RAW)
static int copy_pair(void *c,const uint8_t *s,uint8_t *d,uint32_t n){
    (void)c;assert(!(((uintptr_t)s | (uintptr_t)d | n)&3U));
    memcpy(d,s,n);return 0;
}
#endif
#if !defined(PAIRED_RAW)
static int emulate(void *c,const uint8_t *s,uint8_t *d,uint32_t n){
    (void)c;
    assert(!((uintptr_t)s&3U) && !(n&1U));
    for(unsigned i=0;i<n;i+=2){
        uint32_t raw=(uint32_t)s[i*2U]|((uint32_t)s[i*2U+1]<<8)|
            ((uint32_t)s[i*2U+2]<<16)|((uint32_t)s[i*2U+3]<<24);
        uint32_t sbx=(raw&0xff0000ffU)|((raw&0x0000ff00U)<<8)|((raw&0x00ff0000U)>>8);
        uint16_t out=(uint16_t)(sbx>>(selected*16U));
        d[i]=(uint8_t)out;d[i+1]=(uint8_t)(out>>8);
    }
    return 0;
}
#endif

static void recovery_more(void)
{
    XE_NP_AppUsbQuadDmaBatch a;
    const unsigned payload=NP_DIRECT_GROUPS*252U,need=payload+2048U;
    const uint32_t faults[]={DMA_FLAG_DTE,DMA_FLAG_ULE,DMA_FLAG_USE,DMA_FLAG_TO};
    for(unsigned k=0;k<4U;k++){
        setup(need);for(unsigned i=0;i<4U;i++)regs[i].CCR=DMA_CCR_EN;
        assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
        assert(!XE_NP_App_CommitUsbQuadDmaBatch(&a));tick=20U;regs[2].CSR|=faults[k];
        assert(XE_NP_App_CheckUsbQuadDmaRetention()<0 && np3_diag[1]==11U);
        assert(!np_usb_loss_pending && !np_usb_loss_diag[0]);
    }
    setup(need);for(unsigned i=0;i<4U;i++)regs[i].CCR=DMA_CCR_EN;
    assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(!XE_NP_App_CommitUsbQuadDmaBatch(&a));tick=20U;regs[2].CDAR+=2U;
    assert(XE_NP_App_CheckUsbQuadDmaRetention()<0 && np3_diag[1]==12U && !np_usb_loss_diag[0]);
    for(unsigned k=0;k<2U;k++){
        setup(need);for(unsigned i=0;i<4U;i++)regs[i].CCR=DMA_CCR_EN;
        assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
        if(k==0U)a.payload_bytes_per_lane^=4U;else np3_available[0]=payload-4U;
        assert(XE_NP_App_CommitUsbQuadDmaBatch(&a)<0 && np3_diag[1]==16U+k);
        assert(!np_usb_loss_recover() && np3_claimed && !np_usb_loss_diag[0]);
        XE_NP_App_CancelUsbQuadDmaBatch();assert(!np_usb_loss_recover() && !np_usb_loss_diag[0]);
    }
    /* The observed BADA0013 branch: exact unclaimed retention threshold. */
    setup(need);for(unsigned i=0;i<4U;i++)regs[i].CCR=DMA_CCR_EN;
    assert(np_capture_clock_profile_continuous());
    assert(NP_CaptureAnchor_Unpublished() && !NP_CaptureAnchor_Prearmed());
    assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(!XE_NP_App_CommitUsbQuadDmaBatch(&a));
    OriginWitness first=origin_witness;assert(origin_calls==1U);
    tick=1U;heads(need+(N/2U-1024U-2048U));
    assert(!XE_NP_App_CheckUsbQuadDmaRetention());
    assert(np_usb_loss_pending && np_usb_loss_diag[0]==1U && np_usb_loss_diag[2]==14U);
    heads(need+16U);assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(!np_usb_loss_pending && np_usb_loss_diag[1]==1U);
    assert(origin_calls==1U && np_capture_origin_attempted && !memcmp(&first,&origin_witness,sizeof(first)));
    assert(!XE_NP_App_CommitUsbQuadDmaBatch(&a));
    puts("PASS exact unclaimed threshold14 recovery; all DMA/ownership/claimed faults hard; actual origin hook stays one-shot");
}

int main(void){
#if defined(PAIRED_RAW)
    XE_NP_AppUsbQuadDmaBatch a;
    unsigned payload=NP_DIRECT_GROUPS*252U,need=payload+2048;
    setup(need);regs[0].CSR=0;assert(!XE_NP_App_BeginUsbQuadDmaBatch(payload,&a));
    setup(need);assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(NP_Triple_Probe()==1 && XE_NP_App_CommitUsbQuadDmaBatch(&a)==0);
    assert(!XE_NP_App_BeginUsbQuadDmaBatch(payload,&a));
    tick=2;heads(need+payload);assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(NP_Triple_Probe()==1 && XE_NP_App_CommitUsbQuadDmaBatch(&a)==0);
    for(unsigned l=0;l<4;l++)for(unsigned i=0;i<N/2;i++)samples[l][i]=(uint16_t)(i+l*199U);
    unsigned offsets[]={0,2,504,N/2-2,N/2-504,N/2-payload};
    for(unsigned k=0;k<6;k++){
        const uint8_t *src[4][2];uint16_t sizes[4][2];uint8_t counts[4];uint32_t nodes;
        for(unsigned l=0;l<4;l++){
            unsigned start=(offsets[k]+l*504U)%(N/2),first=N/2-start;
            if(first>payload)first=payload;
            src[l][0]=(uint8_t *)(samples[l]+start);src[l][1]=(uint8_t *)samples[l];
            sizes[l][0]=(uint16_t)first;sizes[l][1]=(uint16_t)(payload-first);counts[l]=first<payload?2:1;
        }
        memset(packet,0xa5,sizeof(packet));
        assert(!NpDirectVisitFormat(src,sizes,counts,packet,sizeof(packet),copy_pair,0,&nodes,2,1));
        for(unsigned g=0;g<NP_DIRECT_GROUPS;g++)for(unsigned l=0;l<4;l++){
            unsigned start=(offsets[k]+l*504U)%(N/2),at=(g*4+l)*512U;
            for(unsigned h=0;h<8;h++)assert(packet[at+h]==0xa5);
            for(unsigned i=0;i<252;i++){
                uint16_t value=samples[l][(start+g*252U+i)%(N/2)];
                assert(packet[at+8+i*2U]==(uint8_t)value && packet[at+9+i*2U]==(uint8_t)(value>>8));
            }
        }
        src[3][0]+=2;memset(packet,0xa5,sizeof(packet));
        assert(NpDirectVisitFormat(src,sizes,counts,packet,sizeof(packet),copy_pair,0,&nodes,2,1)<0 && !nodes);
        for(unsigned i=0;i<sizeof(packet);i++)assert(packet[i]==0xa5);
    }

    setup(need);for(unsigned i=0;i<4;i++)regs[i].CCR=DMA_CCR_EN;
    assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(!XE_NP_App_CommitUsbQuadDmaBatch(&a));
    tick=20;heads(need+payload*2U);
    assert(!XE_NP_App_CheckUsbQuadDmaRetention());
    assert(!np3_diag[1] && np_usb_loss_pending && np_usb_loss_diag[0]==1);
    OriginWitness frozen=origin_witness;assert(origin_calls==1U);
    for(unsigned i=0;i<8;i++)assert(!XE_NP_App_CheckUsbQuadDmaRetention());
    assert(!XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)); /* no new head progress */
    heads(need+payload*2U+16U);
    assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(!np_usb_loss_pending && np_usb_loss_diag[0]==1 && np_usb_loss_diag[1]==1);
    assert(origin_calls==1U && !memcmp(&frozen,&origin_witness,sizeof(frozen)));
    assert(!XE_NP_App_CommitUsbQuadDmaBatch(&a));
    tick=40;heads(need+payload*2U+32U);
    assert(!XE_NP_App_BeginUsbQuadDmaBatch(payload,&a));
    heads(need+payload*2U+48U);
    assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(np_usb_loss_diag[0]==2 && np_usb_loss_diag[1]==2);
    assert(origin_calls==1U && !memcmp(&frozen,&origin_witness,sizeof(frozen)));
    assert(!XE_NP_App_CommitUsbQuadDmaBatch(&a));
    for(unsigned fault=0;fault<3;fault++){
        setup(need);for(unsigned i=0;i<4;i++)regs[i].CCR=DMA_CCR_EN;
        assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
        assert(!XE_NP_App_CommitUsbQuadDmaBatch(&a));tick=20;
        if(fault==0)regs[2].CSR|=DMA_FLAG_DTE;
        if(fault==1)regs[2].CDAR=0;
        if(fault==2)regs[2].CCR=0;
        assert(XE_NP_App_CheckUsbQuadDmaRetention()<0);
        assert(!np_usb_loss_diag[0] && !np_usb_loss_pending);
        assert(np3_diag[1]==(fault==1?12U:11U));
    }
    setup(need);for(unsigned i=0;i<4;i++)regs[i].CCR=DMA_CCR_EN;
    assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    tick=20;assert(XE_NP_App_CommitUsbQuadDmaBatch(&a)<0);
    assert(!np_usb_loss_recover() && np3_claimed && !np_usb_loss_diag[0]);
    XE_NP_App_CancelUsbQuadDmaBatch();
    np_mode_hz=15000;assert(!np_usb_loss_recover() && np3_diag[1]==10);
    np_mode_hz=20000;np_usb_loss_diag[0]=UINT32_MAX;
    assert(np_usb_loss_recover() && np_usb_loss_diag[0]==UINT32_MAX);
    np3_reset();assert(!np_usb_loss_pending && !np_usb_loss_diag[0]);

    recovery_more();
    puts("PASS paired raw producer/planner: single retirement of both samples; word alignment, ring wrap, exact low/high bytes, 8-byte headers untouched");
#else
    XE_NP_AppUsbQuadDmaBatch a,b;unsigned payload=NP_DIRECT_LANE_BYTES,need=payload+2048;
    setup(need);regs[0].CSR=0;assert(!XE_NP_App_BeginUsbQuadDmaBatch(payload,&a));
    setup(need);assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(NP_Triple_Probe()==1 && XE_NP_App_CommitUsbQuadDmaBatch(&a)==0);
    assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&b)==1 && NP_Triple_Probe()==2);
    for(unsigned l=0;l<4;l++)assert(a.source[l][0]==b.source[l][0]);
    assert(XE_NP_App_CommitUsbQuadDmaBatch(&b)==0);
    assert(!XE_NP_App_BeginUsbQuadDmaBatch(payload,&a));
    tick=3;heads(need+payload);assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(XE_NP_App_CommitUsbQuadDmaBatch(&a)==0);
    assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&b)==1);
    assert(XE_NP_App_CommitUsbQuadDmaBatch(&b)==0);
    tick+=10;assert(XE_NP_App_CheckUsbQuadDmaRetention()<0 && np3_diag[1]==10);
    setup(need);regs[2].CSR|=DMA_FLAG_DTE;
    assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)<0 && np3_diag[1]==11);
    for(unsigned l=0;l<4;l++)for(unsigned i=0;i<N/2;i++)
        samples[l][i]=(uint16_t)((uint8_t)(i+l*17U) | ((uint16_t)(uint8_t)(i*3U+l*29U)<<8));
    unsigned offsets[]={0,2,506,N/2-2,N/2-506,N/2-payload};
    for(unsigned k=0;k<6;k++)for(selected=0;selected<2;selected++){
        const uint8_t *src[4][2];uint16_t sizes[4][2];uint8_t counts[4];uint32_t nodes;
        for(unsigned l=0;l<4;l++){
            unsigned start=(offsets[k]+l*506U)%(N/2),first=N/2-start;
            if(first>payload)first=payload;
            src[l][0]=(uint8_t *)(samples[l]+start);src[l][1]=(uint8_t *)samples[l];
            sizes[l][0]=(uint16_t)first;sizes[l][1]=(uint16_t)(payload-first);counts[l]=first<payload?2:1;
        }
        memset(packet,0xa5,sizeof(packet));
        assert(!NpDirectVisitStride(src,sizes,counts,packet,sizeof(packet),emulate,0,&nodes,2));
        for(unsigned g=0;g<NP_DIRECT_GROUPS;g++)for(unsigned l=0;l<4;l++){
            unsigned start=(offsets[k]+l*506U)%(N/2),at=(g*4+l)*512U;
            for(unsigned h=0;h<6;h++)assert(packet[at+h]==0xa5);
            for(unsigned i=0;i<506;i++)assert(packet[at+6+i]==
                (uint8_t)(samples[l][(start+g*506U+i)%(N/2)]>>(selected*8U)));
        }
    }
    puts("PASS real paired producer/planner: shared DMA ownership, both probes, wrap, stale history, overrun/fault rejection and exact tagged payload/header preservation");
#endif
}
