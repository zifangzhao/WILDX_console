"""One isolated native producer/planner recovery check; no ARM build or hardware."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
TASK = ROOT / '_artifacts/v1_lifecycle_release_20261025'
OUT = Path(__file__).resolve().parent
SOURCE = TASK / 'usb_recovery_source'
BASE = ROOT / '_artifacts/v1_usb_timing_r2_20261024/source_r4/np3_producer.inc'
HELPER = ROOT / 'Firmware/V1/Core/Inc/np_usb_source_loss.h'
OLD = ROOT / '_artifacts/v1_recording20_best_effort_20261021'
RECIPE = ROOT / 'Tools/V1Capture/UnifiedUsb/prepare_source_loss.py'
ORIGIN = ROOT / 'Firmware/V1/Core/Src/np_capture_origin_producer.inc'
PLANNER = ROOT / '_artifacts/v1_usb_integrity_20261016/paired_restore/source/Core/Inc/np_direct_packets.h'
sys.path.insert(0, str(RECIPE.parent))
from prepare_source_loss import prepare, once
from test_source_loss import EXTRA


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest().upper()


ANCHOR = r'''
#define NP_CAPTURE_ANCHOR_ENABLED 1U
#define NP_SD_APP 0U
#define XE_NP_APP_QUAD_DMA_QUIET_ENABLE 0U
#define XE_NP_APP_QUAD_DMA_NO_PROBE_DRYRUN 0U
#define XE_NP_APP_GPIOE_QUAD_DMA_INTERLEAVE_BLOCK_BYTES 90U
#define XE_NP_APP_GPIOE_DUAL_DMA_INTERLEAVE_REPEAT_COUNT 704U
#define DMA_FLAG_HT 32U
static struct {uint32_t CYCCNT;} recovery_dwt;
#define DWT (&recovery_dwt)
static uint32_t np_capture_origin_attempted,origin_calls;
typedef struct {uint32_t ring,head,cursor,first,cycles,ms,hz,healthy;} OriginWitness;
static OriginWitness origin_witness;
static uint32_t XE_NP_Board_GetRuntimeExpectedPsbClkHz(void){return np_mode_hz*780U;}
/* Lower anchor algorithm is not requalified here. The ACTUAL producer hook
 * must prevent a second call even after np3_valid is cleared for recovery. */
static void np_capture_anchor_try_origin(uint32_t ring,uint32_t head,uint32_t cursor,
    uint32_t first,uint32_t cycles,uint32_t ms,uint32_t hz,int healthy)
{
    assert(!np_capture_origin_attempted);
    np_capture_origin_attempted=1U;origin_calls++;
    origin_witness=(OriginWitness){ring,head,cursor,first,cycles,ms,hz,(uint32_t)healthy};
}
'''

HARD = r'''
static void recovery_more(void)
{
    XE_NP_AppUsbQuadDmaBatch a;
    const unsigned payload=NP_DIRECT_GROUPS*252U,need=payload+2048U;
    const uint32_t faults[]={DMA_FLAG_DTE,DMA_FLAG_ULE,DMA_FLAG_USE,DMA_FLAG_TO};
    for(unsigned k=0;k<4U;k++){
        setup(need);for(unsigned i=0;i<4U;i++)regs[i].CCR=DMA_CCR_EN;
        assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
        assert(!XE_NP_App_CommitUsbQuadDmaBatch(&a));tick=20U;regs[2].CSR|=faults[k];
        assert(XE_NP_App_CheckUsbQuadDmaRetention()<0 && np3_diag[1]==11U);
        assert(!np_usb_loss_pending && !np_usb_loss_diag[0]);
    }
    setup(need);for(unsigned i=0;i<4U;i++)regs[i].CCR=DMA_CCR_EN;
    assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(!XE_NP_App_CommitUsbQuadDmaBatch(&a));tick=20U;regs[2].CDAR+=2U;
    assert(XE_NP_App_CheckUsbQuadDmaRetention()<0 && np3_diag[1]==12U && !np_usb_loss_diag[0]);
    for(unsigned k=0;k<2U;k++){
        setup(need);for(unsigned i=0;i<4U;i++)regs[i].CCR=DMA_CCR_EN;
        assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
        if(k==0U)a.payload_bytes_per_lane^=4U;else np3_available[0]=payload-4U;
        assert(XE_NP_App_CommitUsbQuadDmaBatch(&a)<0 && np3_diag[1]==16U+k);
        assert(!np_usb_loss_recover() && np3_claimed && !np_usb_loss_diag[0]);
        XE_NP_App_CancelUsbQuadDmaBatch();assert(!np_usb_loss_recover() && !np_usb_loss_diag[0]);
    }
    /* The observed BADA0013 branch: exact unclaimed retention threshold. */
    setup(need);for(unsigned i=0;i<4U;i++)regs[i].CCR=DMA_CCR_EN;
    assert(np_capture_clock_profile_continuous());
    assert(NP_CaptureAnchor_Unpublished() && !NP_CaptureAnchor_Prearmed());
    assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(!XE_NP_App_CommitUsbQuadDmaBatch(&a));
    OriginWitness first=origin_witness;assert(origin_calls==1U);
    tick=1U;heads(need+(N/2U-1024U-2048U));
    assert(!XE_NP_App_CheckUsbQuadDmaRetention());
    assert(np_usb_loss_pending && np_usb_loss_diag[0]==1U && np_usb_loss_diag[2]==14U);
    heads(need+16U);assert(XE_NP_App_BeginUsbQuadDmaBatch(payload,&a)==1);
    assert(!np_usb_loss_pending && np_usb_loss_diag[1]==1U);
    assert(origin_calls==1U && np_capture_origin_attempted && !memcmp(&first,&origin_witness,sizeof(first)));
    assert(!XE_NP_App_CommitUsbQuadDmaBatch(&a));
    puts("PASS exact unclaimed threshold14 recovery; all DMA/ownership/claimed faults hard; actual origin hook stays one-shot");
}
'''


def main():
    if (OUT / 'result.json').exists() or (OUT / 'test.exe').exists():
        raise SystemExit('Completed native regression must not be repeated')
    prior = {Path(x['Path']).name: x['Hash'] for x in json.loads((OLD / 'source-inputs.json').read_text())}
    assert sha(HELPER) == prior[HELPER.name]
    assert sha(RECIPE) == prior[RECIPE.name]
    checked = json.loads((OLD / 'usb/build.json').read_text())
    assert sha(HELPER) == checked['loss_policy_sha256']
    before = BASE.read_text()
    after = prepare(before)
    hook = '        np_capture_origin_selected(n,first,common);'
    assert before.count(hook) == after.count(hook) == 1
    if SOURCE.exists():
        assert (SOURCE / 'np3_producer.inc').read_text() == after
        assert sha(SOURCE / 'np_usb_source_loss.h') == sha(HELPER)
    else:
        SOURCE.mkdir()
        (SOURCE / 'np3_producer.inc').write_text(after, encoding='utf-8', newline='\n')
        (SOURCE / 'np_usb_source_loss.h').write_bytes(HELPER.read_bytes())
    patch = ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='source_r4/np3_producer.inc', tofile='usb_recovery_source/np3_producer.inc'))
    (SOURCE / 'minimal.patch').write_text(patch, encoding='utf-8', newline='\n')
    fixture_path = ROOT / 'Tools/V1Capture/Release/test_usb20_paired.c'
    fixture = fixture_path.read_text()
    fixture = once(fixture, '#define DMA_FLAG_TC 1U', '#define DMA_CCR_EN 1U\n#define DMA_FLAG_TC 1U')
    fixture = once(fixture, 'typedef struct {uint32_t CSR,CDAR;}', 'typedef struct {uint32_t CSR,CDAR,CCR,CBR1;}')
    fixture = once(fixture, '#include <np3_producer.inc>', ANCHOR + '\n#include <np3_producer.inc>')
    fixture = once(fixture, '    heads(logical);np3_reset();', '    np_capture_origin_attempted=origin_calls=0U;memset(&origin_witness,0,sizeof(origin_witness));\n    heads(logical);np3_reset();')
    fixture = once(fixture, 'static int emulate(', '#if !defined(PAIRED_RAW)\nstatic int emulate(')
    fixture = once(fixture, 'int main(void){', '#endif\n' + HARD + '\nint main(void){')
    extra = once(EXTRA, '    assert(!np3_diag[1] && np_usb_loss_pending && np_usb_loss_diag[0]==1);',
                 '    assert(!np3_diag[1] && np_usb_loss_pending && np_usb_loss_diag[0]==1);\n    OriginWitness frozen=origin_witness;assert(origin_calls==1U);')
    extra = once(extra, '    assert(!np_usb_loss_pending && np_usb_loss_diag[0]==1 && np_usb_loss_diag[1]==1);',
                 '    assert(!np_usb_loss_pending && np_usb_loss_diag[0]==1 && np_usb_loss_diag[1]==1);\n    assert(origin_calls==1U && !memcmp(&frozen,&origin_witness,sizeof(frozen)));')
    extra = once(extra, '    assert(np_usb_loss_diag[0]==2 && np_usb_loss_diag[1]==2);',
                 '    assert(np_usb_loss_diag[0]==2 && np_usb_loss_diag[1]==2);\n    assert(origin_calls==1U && !memcmp(&frozen,&origin_witness,sizeof(frozen)));')
    marker = '    puts("PASS paired raw producer/planner:'
    fixture = once(fixture, marker, extra + '\n    recovery_more();\n' + marker)
    (OUT / 'test.c').write_text(fixture, encoding='utf-8', newline='\n')
    inputs = [BASE, HELPER, RECIPE, ORIGIN, PLANNER, fixture_path, RECIPE.with_name('test_source_loss.py'), Path(__file__)]
    manifest = {'stage':'SOURCE_ONLY_UNCLAIMED_NATIVE20K_RECOVERY', 'helper_matches_checked_20261021':True,
                'minimal_recipe_edits':3, 'origin_hook_unchanged':True,
                'inputs':[{'path':str(p),'sha256':sha(p)} for p in inputs],
                'outputs':[{'path':str(SOURCE / n),'sha256':sha(SOURCE / n)} for n in ('np3_producer.inc','np_usb_source_loss.h','minimal.patch')],
                'firmware_build':False,'hardware_access':False,'published':False}
    (SOURCE / 'source_manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    vc = 'C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars32.bat'
    cmd = (f'call "{vc}" >nul && cl /nologo /std:c11 /TC /O2 /W4 /WX /DPAIRED_RAW /DNP_DIRECT_GROUPS=28 '
           f'/I"{SOURCE}" /I"{PLANNER.parent}" "{OUT / "test.c"}" /Fo"{OUT / "test.obj"}" /Fe"{OUT / "test.exe"}" && "{OUT / "test.exe"}"')
    result = subprocess.run(cmd, shell=True, cwd=OUT, capture_output=True, text=True)
    print(result.stdout, end='');print(result.stderr, end='')
    log = OUT / ('native-r' + str(1+len(list(OUT.glob('native*.log')))) + '.log')
    log.write_text(result.stdout+result.stderr)
    result.check_returncode()
    (OUT / 'result.json').write_text(json.dumps({'result':'PASS one actual paired producer/planner native regression',
        'compiler':'MSVC x86 /std:c11 /O2 /W4 /WX; one C translation unit',
        'fixture_sha256':sha(OUT / 'test.c'),'source_manifest_sha256':sha(SOURCE / 'source_manifest.json'),
        'coverage':['prior paired planner/gap regression','unclaimed reasons10/14 only','fresh four-head progress before resync',
                    'DTE/ULE/USE/TO, address/alignment, disabled DMA and ownership16/17 stay hard','claimed-stage remains hard',
                    'actual source-origin hook one-shot across repeated recovery','explicit saturating unknown-gap counters'],
        'host_dependency':'Firmware loss counters remain SRAM-only. Host must detect NP counter discontinuity/relock, retain unknown-gap evidence and never extrapolate through loss.',
        'limits':'No ARM image, hardware, timing, physical source-origin requalification or lossless claim. Lower anchor sink is counted, not physical timing emulation. BADA000A unresolved.',
        'native_output':result.stdout.strip(),'hardware_access':False,'published':False},indent=2)+'\n')


if __name__ == '__main__':
    main()
