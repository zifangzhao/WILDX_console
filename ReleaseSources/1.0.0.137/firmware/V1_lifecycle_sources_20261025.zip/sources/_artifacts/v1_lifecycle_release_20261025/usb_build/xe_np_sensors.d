C:/Frank/Code/XE_NP/_artifacts/v1_lifecycle_release_20261025/usb_build/xe_np_sensors.o: \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\xe_np_sensors.c \
  ..\Core\Inc\xe_np_sensors.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\stdint.h \
  ..\Core\Inc\..\..\Middlewares\Bosch\BME280_SensorAPI\bme280.h \
  ..\Core\Inc\..\..\Middlewares\Bosch\BME280_SensorAPI\bme280_defs.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\stddef.h \
  ..\Core\Inc\..\..\Middlewares\Bosch\BMM150_SensorAPI\bmm150.h \
  ..\Core\Inc\..\..\Middlewares\Bosch\BMM150_SensorAPI\bmm150_defs.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\math.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\string.h
