C:/Frank/Code/XE_NP/_artifacts/v1_lifecycle_release_20261025/usb_recovery_build/xe_np_app.o: \
  C:\Frank\Code\XE_NP\_artifacts\v1_lifecycle_release_20261025\usb_recovery_source\xe_np_app.c \
  ..\Core\Inc\np_config_port.h ..\Core\Inc\np_config.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\stdint.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\stddef.h \
  ..\Core\Inc\xe_np_nric.h ..\Core\Inc\xe_np_board.h \
  ..\Core\Inc\xe_np_hal.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\string.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal.h \
  ..\Core\Inc\stm32u5xx_hal_conf.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_rcc.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_def.h \
  ..\Drivers\CMSIS\Device\ST\STM32U5xx\Include\stm32u5xx.h \
  ..\Drivers\CMSIS\Device\ST\STM32U5xx\Include\stm32u595xx.h \
  ..\Drivers\CMSIS\Include\core_cm33.h \
  ..\Drivers\CMSIS\Include\cmsis_version.h \
  ..\Drivers\CMSIS\Include\cmsis_compiler.h \
  ..\Drivers\CMSIS\Include\cmsis_armclang.h \
  ..\Drivers\CMSIS\Include\mpu_armv8.h \
  ..\Drivers\CMSIS\Device\ST\STM32U5xx\Include\system_stm32u5xx.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\Legacy\stm32_hal_legacy.h \
  C:\Keil_v5\ARM\ARMCLANG\bin\..\include\math.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_rcc_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_gpio.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_gpio_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_icache.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_dcache.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_dma.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_dma_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_cortex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_adc.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_ll_adc.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_adc_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_dac.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_dac_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_flash.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_flash_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_i2c.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_i2c_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_opamp.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_opamp_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_pwr.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_pwr_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_ospi.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_ll_dlyb.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_sd.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_ll_sdmmc.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_sd_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_spi.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_spi_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_tim.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_tim_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_uart.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_uart_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_pcd.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_ll_usb.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_pcd_ex.h \
  ..\Drivers\STM32U5xx_HAL_Driver\Inc\stm32u5xx_hal_exti.h \
  ..\Core\Inc\np_modes.h ..\Core\Inc\np_usb20_release.h \
  ..\Core\Inc\xe_np_app.h ..\Core\Inc\xe_np_runtime.h \
  ..\Core\Inc\CE32_COMMAND.h ..\Core\Inc\CE32_Sync.h \
  ..\Core\Inc\ce32_wire.h ..\Core\Inc\dataMGR.h \
  ..\Core\Inc\xe_np_capture.h ..\Core\Inc\CE32_system.h \
  ..\Core\Inc\CE32_ADC.h ..\Core\Inc\stm32f4xx_hal.h \
  ..\Core\Inc\CE32_macro.h ..\Core\Inc\CE32_BMX160.h \
  ..\Core\Inc\CE32_HJ580.h ..\Core\Inc\main.h \
  ..\Core\Inc\CE32_UART_INTERCOM.h ..\Core\Inc\CE32_filesystem.h \
  ..\Core\Inc\HD32_SD_driver.h ..\Core\Inc\CE32_ClosedLoop.h \
  ..\Core\Inc\xe_np_legacy_fs.h ..\Core\Inc\xe_np_psram.h \
  ..\Core\Inc\xe_np_probe_config_generated.h \
  ..\Core\Inc\xe_np_usb_stream.h \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\np_capture_anchor_port.inc \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\..\Inc\np_capture_anchor.h \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\..\Inc\xe_np_acquisition_anchor.h \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\..\Inc\xe_np_online_impl.h \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\..\Inc\xe_np_online.h \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\..\Inc\np_capture_origin.h \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_fast_startup_r79r2_20261006\source\Core\Src\np_capture_timer_stop.inc \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_integrity_20261016\paired_restore\source\Core\Src\np_usb20_pair_capture.inc \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_fast_startup_r79r2_20261006\source\Core\Src\np_continuous_clock_reset.inc \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\np_capture_admit.inc \
  C:\Frank\Code\XE_NP\_artifacts\v1_lifecycle_release_20261025\usb_recovery_source\np3_producer.inc \
  C:\Frank\Code\XE_NP\Firmware\V1\Core\Src\np_capture_origin_producer.inc \
  C:\Frank\Code\XE_NP\_artifacts\v1_lifecycle_release_20261025\usb_recovery_source\np_usb_source_loss.h \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_fast_startup_r79r2_20261006\source\Core\Src\startup_diag_app.inc \
  ..\Core\Inc\probe_identity.h \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_integrity_20261016\paired_restore\source\Core\Src\startup_admission_app.inc \
  ..\Core\Inc\startup_admission.h \
  C:\Frank\Code\XE_NP\_artifacts\v1_usb_integrity_20261016\paired_restore\source\Core\Src\np_usb_config_held_query.inc
