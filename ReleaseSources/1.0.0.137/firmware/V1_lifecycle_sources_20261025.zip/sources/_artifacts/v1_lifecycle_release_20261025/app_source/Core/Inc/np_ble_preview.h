#ifndef NP_BLE_PREVIEW_H
#define NP_BLE_PREVIEW_H
#include "xe_np_online_impl.h"
#define NP1_PREVIEW_MAGIC 0x3156504eU
#define NP1_PREVIEW_FRAGMENT 160U
#define NP1_PREVIEW_SLOTS 4U
/* V1-only wire identity. One raw 10-bit serial ADC word/sample, 16 samples
 * per packet, <=500 Hz AP or decimated LFP. All decoding stays on the PC.
 * Kind 0 snapshots 1560 chronological bytes for PC sync/counter alignment;
 * kind 2 streams a selected channel; 3 stops; 4 renews the 2 s lease.
 * Request words: magic,1,kind,id,probe,channel,ultraframe_phase,session,band.
 * phase is the first session superframe offset, never counter %156 (which
 * changes across the 20-bit counter rollover). Band 0 AP, 1 LFP.
 * No new DMA/channel, live-ring reads, ownership pinning, or cache operations. */
typedef struct {
    uint8_t data[1560];
    uint32_t id,session,hz,kind,probe,channel,phase,band;
    uint32_t active,ready,lease,total,used,offset,stride,word_bytes;
    uint32_t read_slot,write_slot,queued,armed,dropped,bad_word;
    uint32_t masks[NP1_PREVIEW_SLOTS];
    uint64_t origins[NP1_PREVIEW_SLOTS],first,next,expected;
} NpBlePreview;
static inline void np_ble_preview_stop(NpBlePreview *p)
{p->active=p->ready=p->queued=p->used=p->word_bytes=p->armed=0;}
static inline int np_ble_preview_request(NpBlePreview *p,const uint8_t *b,
    uint32_t session,uint32_t hz,uint32_t mask,int recording,uint32_t now)
{
    if(xe_np_online_word(b)!=NP1_PREVIEW_MAGIC)return 0;
    if(xe_np_online_word(b+4)!=1 || !xe_np_online_word(b+12) ||
       xe_np_online_word(b+60)!=xe_np_online_crc(b))return 1;
    uint32_t w[15];for(unsigned i=0;i<15;i++)w[i]=xe_np_online_word(b+i*4);
    for(unsigned i=9;i<15;i++)if(w[i])return 1;
    if(w[2]==3 || w[2]==4){
        if(w[3]==p->id && w[7]==p->session && w[4]==p->probe &&
           w[5]==p->channel && w[6]==p->phase && w[8]==p->band){
            if(w[2]==3)np_ble_preview_stop(p);
            else if(recording && session==p->session)p->lease=now+2000U;
        }
        return 1;
    }
    if(p->active || p->ready || !recording || !session || (w[2]!=0 && w[2]!=2) ||
       w[4]<1 || w[4]>3 || !(mask&(1U<<(w[4]-1U))) || w[5]>=384 ||
       w[6]>=9360 || w[8]>1 || (w[2] && w[7]!=session) || hz<500)return 1;
    memset(p,0,sizeof(*p));p->id=w[3];p->session=session;p->hz=hz;p->kind=w[2];
    p->probe=w[4];p->channel=w[5];p->phase=w[6];p->band=w[8];
    p->total=p->kind?160U:1560U;p->lease=now+2000U;p->active=1;
    p->stride=p->band?((hz+5999U)/6000U)*9360U:((hz+499U)/500U)*780U;
    return 1;
}
/* Read only a private staging-complete chunk. Four 15,360-byte time lanes.
 * Packed GPIOE halfwords contain simultaneous probe 1/2 values. */
static inline uint8_t np_ble_preview_byte(const uint8_t *raw,uint32_t at,
    unsigned packed,unsigned probe)
{
    return packed?raw[(at&3U)*15360U+(at>>2)*2U+probe-1U]:
                  raw[(at&3U)*15360U+(at>>2)];
}
static inline void np_ble_preview_tap(NpBlePreview *p,const uint8_t *raw,
    uint64_t first,uint32_t ticks,unsigned packed,unsigned probe,int pressure)
{
    if(!p->active || (packed?p->probe>2:p->probe!=probe))return;
    uint64_t end=first+ticks;
    if(!p->armed || (p->expected && p->expected!=first)){
        p->used=p->word_bytes=p->bad_word=0;
        if(!p->kind){p->first=first;p->next=first;}
        else {
            uint32_t adc=(p->channel/24U)*2U+(p->channel&1U);
            uint32_t sample=(p->channel%24U)/2U;
            uint32_t word=adc<30?adc%5U:adc-30U;
            uint32_t period=p->band?9360U:780U;
            uint32_t offset=p->phase+(p->band?sample*780U:(sample+1U)*60U)+word*10U;
            p->next=first+(offset%period+period-(uint32_t)(first%period))%period;
        }
        p->armed=1;
    }
    p->expected=end;
    if(!p->kind){
        if(pressure){np_ble_preview_stop(p);p->dropped++;return;}
        uint32_t n=p->total-p->used;if(n>ticks)n=ticks;
        for(uint32_t i=0;i<n;i++)p->data[p->used+i]=np_ble_preview_byte(raw,i,packed,p->probe);
        p->used+=n;
        if(p->used==p->total){p->active=0;p->ready=1;}return;
    }
    if(p->queued==NP1_PREVIEW_SLOTS){p->armed=0;p->dropped++;return;}
    while(p->next<end){
        if(!p->used){p->origins[p->write_slot]=p->next;p->masks[p->write_slot]=0;}
        uint32_t n=10U-p->word_bytes;if(p->next+n>end)n=(uint32_t)(end-p->next);
        if(pressure)p->bad_word=1;
        else if(!p->bad_word)for(uint32_t i=0;i<n;i++)
            p->data[p->write_slot*160U+p->used+i]=np_ble_preview_byte(raw,(uint32_t)(p->next-first)+i,packed,p->probe);
        p->next+=n;p->used+=n;p->word_bytes+=n;
        if(p->word_bytes==10U){
            if(!p->bad_word)p->masks[p->write_slot]|=1U<<(p->used/10U-1U);
            else p->dropped++;
            p->word_bytes=p->bad_word=0;p->next+=p->stride-10U;
        }
        if(p->used==160U){
            if(!p->masks[p->write_slot]){p->used=0;continue;}
            p->write_slot=(p->write_slot+1U)%NP1_PREVIEW_SLOTS;
            p->queued++;p->ready=1;p->used=0;
            if(p->queued==NP1_PREVIEW_SLOTS)return;
        }
    }
}
/* Fixed 224-byte body, same CE32 AD BA .. DA DA envelope as V2. */
static inline void np_ble_preview_fragment(const NpBlePreview *p,uint8_t *b)
{
    memset(b,0,224);uint64_t first=p->kind?p->origins[p->read_slot]:p->first;
    uint32_t w[8]={NP1_PREVIEW_MAGIC,p->id,p->session,p->hz,(uint32_t)first,
        (uint32_t)(first>>32),p->kind?(160U<<16)|p->masks[p->read_slot]:p->offset|(p->total<<16),
        p->probe|(p->kind<<8)|(p->band<<12)|(p->channel<<16)};
    for(unsigned i=0;i<8;i++)xe_np_online_put(b+4*i,w[i]);
    uint32_t n=p->kind?160U:p->total-p->offset;if(n>160U)n=160U;
    memcpy(b+32,p->data+(p->kind?p->read_slot*160U:p->offset),n);
    xe_np_online_put(b+192,p->stride);xe_np_online_put(b+196,p->dropped);
}
static inline void np_ble_preview_retire(NpBlePreview *p)
{
    if(p->kind){p->read_slot=(p->read_slot+1U)%NP1_PREVIEW_SLOTS;p->queued--;p->ready=p->queued!=0;}
    else {p->offset+=160U;if(p->offset>=p->total)p->ready=0;}
}
#endif
