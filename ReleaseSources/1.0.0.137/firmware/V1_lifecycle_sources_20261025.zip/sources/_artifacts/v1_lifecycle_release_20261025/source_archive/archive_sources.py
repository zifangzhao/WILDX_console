"""Preserve exact admitted V1 source closures, not firmware or binary objects."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile


ROOT = Path('C:/Frank/Code/XE_NP').resolve()
TASK = ROOT / '_artifacts/v1_lifecycle_release_20261025'
OUT = Path(__file__).resolve().parent
CWD = ROOT / '_artifacts/v1_usb_fast_startup_r79r2_20261006/source/MDK-ARM'
ZIP = OUT / 'V1_lifecycle_sources_20261025.zip'
BLOCKED = {'.o', '.obj', '.axf', '.exe', '.dll', '.hex', '.bin', '.dat', '.mp4', '.map', '.htm'}


def sha(data):
    return hashlib.sha256(data).hexdigest().upper()


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def dependencies(path):
    text = re.sub(r'\\\r?\n', ' ', path.read_text())
    _, body = text.split(': ', 1)
    # Clang Make dependencies retain Windows backslashes; only escaped spaces
    # are Make escapes here, not arbitrary backslash-letter sequences.
    tokens = re.findall(r'(?:\\[ \t]|[^\s])+', body)
    result = []
    for token in tokens:
        token = token.replace('\\ ', ' ').replace('\\\t', '\t')
        p = Path(token)
        result.append((p if p.is_absolute() else CWD / p).resolve())
    return result


def main():
    if OUT != TASK / 'source_archive' or any((OUT / n).exists() for n in
            ('sources', ZIP.name, 'archive_manifest.json', 'verification.json')):
        raise ValueError('Fresh, exact source_archive output required')
    entries, external, known, groups = {}, {}, {}, {}

    def pin(path, digest):
        p = Path(path).resolve()
        digest = digest.upper()
        previous = known.get(str(p).casefold())
        if previous is not None and previous != digest:
            raise ValueError('Conflicting recorded source identities: ' + str(p))
        known[str(p).casefold()] = digest

    app_receipt = TASK / 'app_build/build.json'
    app = read_json(app_receipt)
    usb = read_json(TASK / 'usb_build/build.json')
    recovery = read_json(TASK / 'usb_recovery_build/build.json')
    if Path(usb['compiler_cwd']).resolve() != CWD or Path(recovery['compiler_cwd']).resolve() != CWD:
        raise ValueError('Unexpected USB compiler cwd')
    for x in app['source_dependencies']:
        pin(x['path'], x['sha256'])
    pin(usb['source'], usb['source_sha256'])
    for m in (TASK / 'usb_recovery_source/source_manifest.json',
              ROOT / '_artifacts/v1_usb_timing_r2_20261024/source_r5/source_manifest.json'):
        d = read_json(m)
        for key in ('inputs', 'outputs'):
            for x in d.get(key, []):
                pin(x['path'], x['sha256'])

    def add(path, group, expected=None):
        p = Path(path).resolve()
        raw = p.read_bytes()
        digest = sha(raw)
        required = expected.upper() if expected else known.get(str(p).casefold())
        if required and digest != required:
            raise ValueError('Recorded input changed: ' + str(p))
        if not p.is_relative_to(ROOT):
            key = str(p).casefold()
            item = external.setdefault(key, dict(original_path=str(p), sha256=digest,
                bytes=len(raw), groups=[], reason='External Keil proprietary/toolchain header; reference only, not redistributed'))
            if not p.is_relative_to(Path('C:/Keil_v5').resolve()):
                item['reason'] = 'Outside project workspace; reference only, not redistributed'
            if group not in item['groups']:
                item['groups'].append(group)
            return
        relative = p.relative_to(ROOT)
        if p.suffix.lower() in BLOCKED or any(part in ('.git', '.codex', '.aws') for part in relative.parts):
            raise ValueError('Non-source/private artifact in allowlist: ' + str(p))
        member = 'sources/' + relative.as_posix()
        item = entries.setdefault(member, dict(original_path=str(p), archive_member=member,
                    sha256=digest, bytes=len(raw), groups=[], matched_recorded_hash=required is not None))
        if item['sha256'] != digest:
            raise ValueError('Source changed during inventory: ' + str(p))
        if group not in item['groups']:
            item['groups'].append(group)

    if len(app['source_dependencies']) != 159:
        raise ValueError('APP compiler source closure must have159 inputs')
    for x in app['source_dependencies']:
        add(x['path'], 'APP159', x['sha256'])
    depfiles = [TASK / 'usb_recovery_build/xe_np_app.d', TASK / 'usb_build/xe_np_sensors.d',
                ROOT / '_artifacts/v1_usb_timing_r2_20261024/build_r3/xe_np_usb_stream.d']
    for depfile in depfiles:
        closure = dependencies(depfile)
        label = depfile.relative_to(ROOT).as_posix()
        groups[label] = dict(dependency_file=str(depfile), compiler_cwd=str(CWD),
                             dependency_count=len(closure))
        add(depfile, 'compiler_dependency_records')
        for p in closure:
            add(p, label)

    extras = [
        'Tools/V1Capture/UsbSensors/build_lifecycle.ps1',
        'Tools/V1Capture/UsbSensors/build_app_lifecycle.ps1',
        'Tools/V1Capture/UsbSensors/build_usb_recovery.ps1',
        'Tools/V1Capture/UsbSensors/seal_lifecycle.py',
        'Tools/V1Capture/UsbSensors/test_recording_lifecycle.py',
        'Tools/V1Capture/Ble/test_ce32_pending_stop.py',
        'Tools/V1Capture/Timing/test_capture_anchor.c',
        'Tools/V1Capture/Timing/prepare_capture_anchor.py',
        'Tools/V1Capture/UnifiedUsb/prepare_source_loss.py',
        'Tools/V1Capture/UnifiedUsb/test_source_loss.py',
        'Tools/V1Capture/UnifiedUsb/package_reset_service.py',
        'Tools/V1Capture/UnifiedUsb/merge_verified_hex.py',
        'Tools/V1Capture/Split/package.py',
        'Tools/V1Capture/firmware_identity.py',
        'Tools/package_xe_np_firmware.py',
        'Tools/V1Capture/Release/test_usb20_paired.c',
        'Tools/V1Capture/SdLogger/Sensors/Tools/tests/test_np_sensors.c',
        'Tools/V1Capture/SdLogger/Sensors/Tools/test_np_sensors.ps1',
        'Firmware/V1/Core/Src/xe_np_sensors.c',
        'Firmware/V1/Core/Src/xe_np_bme_compensation.c',
        'Firmware/V1/Core/Src/xe_np_bmm_compensation.c',
        'Firmware/V1/MDK-ARM/app.sct',
        '_artifacts/v1_usb_fast_startup_r79r2_20261006/source/Tools/run_np_sync_validation_bench.ps1',
        '_artifacts/v1_usb_fast_startup_r79r2_20261006/source/Core/Src/xe_np_sensors.c',
        '_artifacts/v1_sensor_lifecycle_20261025/sensor_lifecycle.patch',
        '_artifacts/v1_sensor_lifecycle_20261025/lineage.json',
        '_artifacts/v1_ble_remaining_20261025/app654_pending_stop.patch',
        '_artifacts/v1_ble_remaining_20261025/app654_overlay_admission.json',
    ]
    for prefix in ('Middlewares/Bosch', 'Tools/V1Capture/SdLogger/Sensors/Middlewares/Bosch'):
        for api, stem in (('BME280_SensorAPI', 'bme280'), ('BMM150_SensorAPI', 'bmm150')):
            for name in (stem + '.c', stem + '.h', stem + '_defs.h', 'LICENSE'):
                extras.append(prefix + '/' + api + '/' + name)
    for name in ('xe_np_sensors.c', 'xe_np_sensors_port.c', 'xe_np_bme_compensation.c', 'xe_np_bmm_compensation.c'):
        extras.append('Tools/V1Capture/SdLogger/Sensors/Core/Src/' + name)
    for name in ('xe_np_sensors.h', 'xe_np_sensors_port.h'):
        extras.append('Tools/V1Capture/SdLogger/Sensors/Core/Inc/' + name)
    for relative in extras:
        add(ROOT / relative, 'helpers_fixtures_patches_licenses')
    for relative in ('app_source/source_manifest.json', 'usb_recovery_source/source_manifest.json',
                     'usb_recovery_source/minimal.patch', 'app_build/build.json', 'app_build/app.d',
                     'usb_build/build.json', 'usb_recovery_build/build.json', 'app_sealed/identity.json',
                     'usb_recovery_sealed/identity.json', 'app_native_check/run.py',
                     'app_native_check/r2/test.c', 'app_native_check/r2/sd_clock.inc',
                     'app_native_check/r2/result.json', 'usb_recovery_native/run.py',
                     'usb_recovery_native/test.c', 'usb_recovery_native/result.json'):
        add(TASK / relative, 'source_manifests_and_native_fixtures')
    add(ROOT / '_artifacts/v1_usb_timing_r2_20261024/source_r5/source_manifest.json', 'checked_service_lineage')
    add(ROOT / '_artifacts/v1_usb_timing_r2_20261024/build_r3/build.json', 'checked_service_lineage')
    add(Path(__file__), 'archive_helper')

    # Scatter text is a source/build input; preserve it, never linked payloads.
    for relative in ('app_build/lifecycle.lnp', 'usb_build/lifecycle.lnp', 'usb_recovery_build/lifecycle.lnp'):
        p = TASK / relative
        add(p, 'link_response_identity_records')
        text = p.read_text()
        match = re.search(r'--scatter\s+(?:"([^"]+)"|(\S+))', text)
        if match:
            scatter = Path(match[1] or match[2])
            add(scatter if scatter.is_absolute() else CWD / scatter, 'scatter_sources')

    records = sorted(entries.values(), key=lambda x: x['archive_member'])
    for item in records:
        p = Path(item['original_path'])
        if sha(p.read_bytes()) != item['sha256']:
            raise ValueError('Source changed before preservation: ' + str(p))
        target = OUT / item['archive_member']
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, target)
        if sha(target.read_bytes()) != item['sha256']:
            raise ValueError('Preserved source hash mismatch: ' + str(target))
    manifest = dict(schema='v1-lifecycle-source-preservation-v1', app_compiler_inputs=159,
        compiler_cwd=str(CWD), closures=groups, entries=records,
        external_dependencies=sorted(external.values(), key=lambda x: x['original_path']),
        reused_object_identity_records={str(p):read_json(p)['reused_objects'] for p in
             (app_receipt, TASK / 'usb_build/build.json', TASK / 'usb_recovery_build/build.json')},
        limitations=[
            'Source preservation only, not a complete clean-rebuild claim; incremental builds reused checked objects whose identities, not bytes or every historic source closure, are recorded.',
            'Keil proprietary standard headers/compiler/runtime are external version/hash references, never redistributed.',
            'Workspace-relative source paths and source/manifests/helpers are preserved byte-for-byte; original scripts retain their recorded absolute build paths.',
            'No objects, AXFs, firmware HEX/BIN images, raw recordings, capture payloads, installer, release/Git operation or hardware access.',
            'No new code audit, compiler run, sealing, package qualification or physical validation is performed by this archive.'])
    manifest_path = OUT / 'archive_manifest.json'
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    with zipfile.ZipFile(ZIP, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for item in records:
            info = zipfile.ZipInfo(item['archive_member'], date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, (OUT / item['archive_member']).read_bytes())
        z.write(manifest_path, 'archive_manifest.json')
    expected_names = {x['archive_member'] for x in records} | {'archive_manifest.json'}
    with zipfile.ZipFile(ZIP) as z:
        if len(z.namelist()) != len(expected_names) or set(z.namelist()) != expected_names:
            raise ValueError('ZIP member identity/count mismatch')
        for item in records:
            if sha(z.read(item['archive_member'])) != item['sha256']:
                raise ValueError('ZIP read-back hash mismatch: ' + item['archive_member'])
        if z.read('archive_manifest.json') != manifest_path.read_bytes():
            raise ValueError('ZIP manifest mismatch')
    result = dict(result='PASS exact-source ZIP read-back', zip=str(ZIP), sha256=sha(ZIP.read_bytes()),
        bytes=ZIP.stat().st_size, source_entries=len(records), zip_entries=len(expected_names),
        source_bytes=sum(x['bytes'] for x in records), external_reference_count=len(external),
        manifest_sha256=sha(manifest_path.read_bytes()), hardware_access=False,
        compiler_run=False, published=False)
    (OUT / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
