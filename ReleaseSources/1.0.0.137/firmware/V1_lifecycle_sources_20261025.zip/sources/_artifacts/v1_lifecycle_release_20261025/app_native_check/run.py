"""One native SD-APP anchor regression using the exact frozen APP overlay."""
from pathlib import Path
import hashlib
import json
import re
import subprocess


ROOT = Path('C:/Frank/Code/XE_NP')
TASK = ROOT / '_artifacts/v1_lifecycle_release_20261025'
OVERLAY = TASK / 'app_source'
OUT = Path(__file__).resolve().parent / 'r2'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest().upper()


def function(text, name):
    m = re.search(r'^(?:static )?(?:int|void)\s+' + re.escape(name) + r'\([^;{}]*\)\s*\{', text, re.M)
    if not m:
        raise ValueError('Missing actual function: ' + name)
    end, depth = m.end(), 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[m.start():end]


def main():
    manifest = OVERLAY / 'source_manifest.json'
    if sha(manifest) != '59D2C76F244C97234CEF1A68E0D2245EE329D2DB703FD40C8879B5047F2ED328':
        raise ValueError('Frozen APP manifest changed')
    receipt = json.loads(manifest.read_text())
    for x in receipt['source_dependencies']:
        if sha(Path(x['candidate_path'])) != x['candidate_sha256']:
            raise ValueError('Frozen APP input changed: ' + x['candidate_path'])
    original = ROOT / 'Tools/V1Capture/Timing/test_capture_anchor.c'
    text = original.read_text()
    prefix = text[:text.index('typedef struct {unsigned unused;} PCD_HandleTypeDef;')]
    for name in ('HAL_GetUIDw0', 'HAL_GetUIDw1', 'HAL_GetUIDw2'):
        prefix = re.sub(r'^static uint32_t ' + name + r'\(void\)\{[^\n]*\}\n', '', prefix, flags=re.M)
    prefix = prefix.replace('static uint32_t fresh_step=9U;\n', '')
    a = prefix.index('static uint32_t fresh_cycles(void)')
    b = prefix.index('static HAL_StatusTypeDef HAL_TIM_Base_Start', a)
    prefix = prefix[:a] + prefix[b:]
    middle = text[text.index('static void seal(uint8_t p[64])'):text.index('static void test_fresh_clock(void)')]
    a = middle.index('    prepare_anchor();paired=1;paired_double_offset=0;test_ring=31200U;')
    b = middle.index('    uint32_t generation=np_capture_anchor.generation;', a)
    middle = middle[:a] + middle[b:]
    main_text = text[text.index('int main(void)'):]
    a = main_text.index('    PCD_HandleTypeDef pcd={0};')
    b = main_text.index('    np_capture_anchor_invalidate();', a)
    main_text = main_text[:a] + main_text[b:]
    main_text = main_text.replace('    test_fresh_clock();\n', '')
    main_text = main_text.replace('    puts("PASS actual V1 startup/origin/SD compatibility + fresh DWT wire, wrap, epoch, clock, busy and debug rejection");',
                                  '    printf("PASS %u frozen APP anchor/root/origin/NPAQ-NPAR/UTC2/admission checks; no hardware\\n", app_checks);')
    adapted = '#define NP_SD_APP 1U\n' + prefix + middle + main_text
    adapted = adapted.replace('#include <assert.h>', '#include <assert.h>\n#include <stdlib.h>\n#include <stdio.h>\n'
        'static unsigned app_checks;\nstatic void app_check(int ok,const char *s,unsigned line)\n'
        '{app_checks++;if(!ok){printf("FAIL line %u: %s\\n",line,s);exit(1);}}\n'
        '#undef assert\n#define assert(x) app_check(!!(x),#x,__LINE__)')
    adapted = adapted.replace('"../../../Firmware/V1/', '"' + OVERLAY.as_posix() + '/')
    if '../../../Firmware/V1/' in adapted or 'test_fresh_clock' in adapted:
        raise ValueError('Unexpected canonical/USB fixture dependency')
    online = OVERLAY / 'Core/Src/np_ble_online_port.inc'
    stamp = '\n\n'.join(function(online.read_text(), name) for name in ('NP_SD_BleArmStamp', 'npl_save_clock')) + '\n'
    OUT.mkdir(parents=True, exist_ok=False)
    (OUT / 'sd_clock.inc').write_text(stamp)
    test = OUT / 'test.c'
    test.write_text(adapted)
    vc = Path('C:/Program Files (x86)/Microsoft Visual Studio/2019/Community/VC/Auxiliary/Build/vcvars32.bat')
    command = (f'call "{vc}" >nul && cl /nologo /std:c11 /W4 /WX /TC /O2 '
               f'/I"{OUT}" "{test}" /Fo"{OUT}/test.obj" /Fe"{OUT}/test.exe"')
    built = subprocess.run(command, shell=True, capture_output=True, text=True)
    output = built.stdout + built.stderr
    run = None if built.returncode else subprocess.run([str(OUT / 'test.exe')], capture_output=True, text=True)
    if run is not None:
        output += run.stdout + run.stderr
    print(output, end='')
    inputs = [original, online] + [OVERLAY / rel for rel in (
        'Core/Src/np_capture_anchor_port.inc', 'Core/Src/np_capture_origin_producer.inc',
        'Core/Src/np_capture_admit.inc', 'Core/Inc/np_capture_anchor.h',
        'Core/Inc/xe_np_acquisition_anchor.h', 'Core/Inc/np_capture_origin.h',
        'Core/Inc/np_ble_schedule.h', 'Core/Inc/xe_np_online_impl.h')]
    result = dict(stage='NATIVE_FROZEN_SD_APP_ANCHOR_ONLY', manifest_sha256=sha(manifest),
        compile_exit=built.returncode, test_exit=None if run is None else run.returncode,
        reused_fixture_sha256=sha(original), adapted_fixture_sha256=sha(test),
        extracted_UTC2_sha256=sha(OUT / 'sd_clock.inc'), inputs=[dict(path=str(p),sha256=sha(p)) for p in inputs],
        scope='Exact frozen APP code under fake TIM2/DWT/DMA/HAL: receiver-root bracket, source-valid/ambiguous/invalid and one-shot origin, cached NPAQ-NPAR/CRC/generation, exported-source-zero UTC2 and legacy media UTC1 serialization, startup admission.',
        excluded='USB EP0/fresh-counter/R2 checks and USB-only half-ring geometry; no physical ADC/GPIO alignment, real DMA/IRQ latency, SD writes or hardware qualification.',
        arm_build=False,hardware_access=False,overlay_modified=False,published=False)
    (OUT / 'result.json').write_text(json.dumps(result,indent=2)+'\n')
    (OUT / 'run.log').write_text(output)
    raise SystemExit(built.returncode if run is None else run.returncode)


if __name__ == '__main__':
    main()
