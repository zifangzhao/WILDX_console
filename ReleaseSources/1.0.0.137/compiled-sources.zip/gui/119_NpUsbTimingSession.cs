using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Web.Script.Serialization;

namespace USB512_interface {
    // Optional control/evidence owner. No read/rearm slot or neural buffer ownership.
    internal sealed class NpUsbTimingSession : IDisposable {
        sealed class Received {internal byte[] Bytes;internal ulong Sequence;internal long Qpc;}
        readonly string folder,uid;readonly int family;readonly ulong token;
        readonly BlockingCollection<Received> inbox=new BlockingCollection<Received>(32);
        readonly JavaScriptSerializer json=new JavaScriptSerializer();readonly object fileGate=new object();
        StreamWriter file;Thread worker;NpUsbTimingOut output;Action<byte[]> write;
        volatile bool stopQueries,disposed;uint nextId=1,generation,pendingId;long nextQuery,pendingSince;
        long dropped;internal string Error {get;private set;}
        internal bool Enabled {get;private set;}
        internal ulong Token {get{return token;}}
        static string Hex(byte[] b){return b==null?null:BitConverter.ToString(b).Replace("-","");}
        static ulong NewToken(){ulong value;do{value=BitConverter.ToUInt64(Guid.NewGuid().ToByteArray(),0);}while(value==0);return value;}
        NpUsbTimingSession(string directory,string identity,int version,ulong value=0){folder=directory;uid=(identity??"").ToUpperInvariant();family=version;token=value==0?NewToken():value;}
        void Log(object row){lock(fileGate){if(file!=null){file.WriteLine(json.Serialize(row));file.Flush();}}}
        internal static NpUsbTimingSession Prepare(string folder,string uid,int family,Func<byte[]> info,Action<byte[]> enable,Func<uint,byte[]> prearm,Func<NpUsbTimingOut> makeOutput) {
            var session=new NpUsbTimingSession(folder,uid,family);bool negotiated=false;
            try {
                var first=NpUsbTimingWire.ParseInfo(info(),uid,family);
                if((first.Flags&5)!=5||(first.Caps&3)!=3)return session;
                enable(NpUsbTimingWire.Enable(uid,session.token));negotiated=true;
                var ready=NpUsbTimingWire.ParseInfo(info(),uid,family);
                if(!ready.Ready||ready.Token!=session.token)throw new IOException("Timing negotiation was not confirmed.");
                session.file=new StreamWriter(new FileStream(Path.Combine(folder,NpUsbTimingEvidence.FileName),FileMode.CreateNew,FileAccess.Write,FileShare.Read,65536));
                session.Log(new {kind="metadata",schema=2,device_uid=session.uid,device_family=family,token_hex=session.token.ToString("X16"),host_epoch=NpHostClock.Epoch,clock=NpHostClock.Receipt,
                    reference="Request-correlated MCU counters; USB completion is a causal bound, not sample arrival latency.",record_bytes=108});
                long before=Stopwatch.GetTimestamp();uint id=session.nextId++;
                session.Log(new {kind="request",phase="prearm",request_id=id,generation=ready.Generation,send_qpc=before,raw_hex=(string)null});
                byte[] raw=prearm(id);long after=Stopwatch.GetTimestamp();
                var record=NpUsbTimingWire.Parse(raw,uid,family,session.token,UInt64.MaxValue);
                if(record.Kind!=1||!record.Valid||!record.Prearm||record.Id!=id||record.Generation!=ready.Generation)throw new IOException("Pre-arm timing reply is unbound.");
                session.Log(new {kind="record",outcome="accepted",receive_qpc=after,container_sequence=UInt64.MaxValue.ToString(CultureInfo.InvariantCulture),raw_hex=Hex(raw)});
                session.output=makeOutput();session.write=session.output.Write;session.Enabled=true;
            } catch(Exception ex) {
                session.Error=ex.Message;
                if(negotiated)try{enable(NpUsbTimingWire.Enable(uid,0,false));}catch(Exception disable){session.Error+="; disable unavailable: "+disable.Message;}
                if(session.output!=null)try{session.output.Dispose();}catch{}session.output=null;
                if(session.file!=null){try{session.file.Dispose();}catch{}session.file=null;}
            }
            return session;
        }
        internal void Start() {
            if(!Enabled||worker!=null)return;
            try{worker=new Thread(Run){IsBackground=true,Name="NP optional USB timing"};worker.Start();}
            catch(Exception ex){Error=ex.Message;stopQueries=true;}
        }
        internal void FeedV2(byte[] block,int offset,long qpc) {
            if(!Enabled||disposed||block==null||offset<0||block.Length-offset<512)return;
            if((BitConverter.ToUInt32(block,offset+52)&512)==0)return;
            Feed(block,offset+396,BitConverter.ToUInt64(block,offset+24),qpc);
        }
        internal void FeedV1(byte[] b,int offset,int length,long qpc) {
            if(!Enabled||disposed||b==null||offset<0||length!=506||b.Length-offset<506)return;
            if((BitConverter.ToUInt32(b,offset+188)&8)==0)return;
            // This may run when misc saving is off, so validate the wrapper here too.
            if(System.Text.Encoding.ASCII.GetString(b,offset,8)!="NPSENS01"||System.Text.Encoding.ASCII.GetString(b,offset+164,8)!="NPUSB001"||
                BitConverter.ToUInt32(b,offset+160)!=NpUsbSensors.Crc(b,offset,160)||BitConverter.ToUInt32(b,offset+502)!=NpUsbSensors.Crc(b,offset,502)){
                Interlocked.Increment(ref dropped);return;
            }
            Feed(b,offset+192,BitConverter.ToUInt32(b,offset+8),qpc);
        }
        void Feed(byte[] bytes,int offset,ulong sequence,long qpc) {
            if(qpc<=0||NpUsbTimingWire.IsAbsent(bytes,offset))return;
            var copy=new byte[108];Buffer.BlockCopy(bytes,offset,copy,0,108);
            try{if(!inbox.TryAdd(new Received{Bytes=copy,Sequence=sequence,Qpc=qpc}))Interlocked.Increment(ref dropped);}
            catch(InvalidOperationException){Interlocked.Increment(ref dropped);}
        }
        void Run() {
            try {
                while(!inbox.IsCompleted) {
                    Received packet;
                    if(inbox.TryTake(out packet,100)) {
                        string outcome="accepted",why=null;
                        try {
                            var r=NpUsbTimingWire.Parse(packet.Bytes,uid,family,token,packet.Sequence);
                            if(r.Kind!=1) {
                                if(generation!=0&&generation!=r.Generation){stopQueries=true;throw new InvalidDataException("Acquisition generation changed.");}
                                if(r.Generation!=0)generation=r.Generation;
                            } else {
                                if(r.Id!=pendingId||r.Prearm||r.Generation!=generation)throw new InvalidDataException("Clock reply has no matching active request.");
                                pendingId=0;
                            }
                        }catch(Exception ex){outcome="rejected";why=ex.Message;}
                        Log(new {kind="record",outcome,error=why,receive_qpc=packet.Qpc,container_sequence=packet.Sequence.ToString(CultureInfo.InvariantCulture),raw_hex=Hex(packet.Bytes)});
                    }
                    long now=Stopwatch.GetTimestamp();
                    if(pendingId!=0&&now-pendingSince>=10*Stopwatch.Frequency){Log(new {kind="unanswered",request_id=pendingId});pendingId=0;}
                    if(!stopQueries&&pendingId==0&&generation!=0&&now>=nextQuery) {
                        if(nextId==UInt32.MaxValue){stopQueries=true;Error="Timing ID lifetime exhausted.";continue;}
                        uint id=nextId++;byte[] request=NpUsbTimingWire.Query(id,token,generation);long send=Stopwatch.GetTimestamp();nextQuery=send+5*Stopwatch.Frequency;pendingId=id;pendingSince=send;
                        Log(new {kind="request",phase="active",request_id=id,generation,send_qpc=send,raw_hex=Hex(request)});
                        try{write(request);}catch(Exception ex){if(!stopQueries)Error=ex.Message;Log(new {kind=stopQueries?"request_cancelled":"write_error",request_id=id,error=ex.Message});stopQueries=true;}
                    }
                }
            }catch(Exception ex){Error=ex.Message;stopQueries=true;}
        }
        internal void StopQueries() {
            stopQueries=true;
            var writer=output;if(writer!=null){writer.Abort();writer.Dispose();output=null;}
        }
        public void Dispose() {
            if(disposed)return;StopQueries();disposed=true;inbox.CompleteAdding();if(worker!=null)worker.Join();
            try{Log(new {kind="close",error=Error,dropped_records=Interlocked.Read(ref dropped),unanswered_request_id=pendingId});}catch(Exception ex){Error=ex.Message;}
            if(file!=null){try{file.Dispose();}catch(Exception ex){Error=ex.Message;}file=null;}inbox.Dispose();
            if(!Enabled&&Error==null)return;
            try{File.WriteAllText(Path.Combine(folder,"usb_timing_status.json"),json.Serialize(new {schema=2,enabled=Enabled,error=Error,dropped_records=dropped,
                limitation="Optional request-correlated counter evidence only; no physical ADC/filter/trigger calibration or inferred missing interval."}));}catch{}
        }
    }
}
